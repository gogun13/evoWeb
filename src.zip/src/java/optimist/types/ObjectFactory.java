
package optimist.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the optimist.types package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AttachFinancialInformationV1Response_QNAME = new QName("urn:Optimist/types", "attachFinancialInformation_V1Response");
    private final static QName _AttachFinancialInformationV1_QNAME = new QName("urn:Optimist/types", "attachFinancialInformation_V1");
    private final static QName _AttachFinancialInformationV1ResponseTypeFailureDescription_QNAME = new QName("", "failureDescription");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: optimist.types
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FinancialModelType }
     * 
     */
    public FinancialModelType createFinancialModelType() {
        return new FinancialModelType();
    }

    /**
     * Create an instance of {@link AttachFinancialInformationV1ResponseType }
     * 
     */
    public AttachFinancialInformationV1ResponseType createAttachFinancialInformationV1ResponseType() {
        return new AttachFinancialInformationV1ResponseType();
    }

    /**
     * Create an instance of {@link AttachFinancialInformationV1Response }
     * 
     */
    public AttachFinancialInformationV1Response createAttachFinancialInformationV1Response() {
        return new AttachFinancialInformationV1Response();
    }

    /**
     * Create an instance of {@link AttachFinancialInformationV1 }
     * 
     */
    public AttachFinancialInformationV1 createAttachFinancialInformationV1() {
        return new AttachFinancialInformationV1();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttachFinancialInformationV1Response }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:Optimist/types", name = "attachFinancialInformation_V1Response")
    public JAXBElement<AttachFinancialInformationV1Response> createAttachFinancialInformationV1Response(AttachFinancialInformationV1Response value) {
        return new JAXBElement<AttachFinancialInformationV1Response>(_AttachFinancialInformationV1Response_QNAME, AttachFinancialInformationV1Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttachFinancialInformationV1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:Optimist/types", name = "attachFinancialInformation_V1")
    public JAXBElement<AttachFinancialInformationV1> createAttachFinancialInformationV1(AttachFinancialInformationV1 value) {
        return new JAXBElement<AttachFinancialInformationV1>(_AttachFinancialInformationV1_QNAME, AttachFinancialInformationV1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "failureDescription", scope = AttachFinancialInformationV1ResponseType.class)
    public JAXBElement<String> createAttachFinancialInformationV1ResponseTypeFailureDescription(String value) {
        return new JAXBElement<String>(_AttachFinancialInformationV1ResponseTypeFailureDescription_QNAME, String.class, AttachFinancialInformationV1ResponseType.class, value);
    }

}
