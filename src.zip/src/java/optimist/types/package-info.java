@javax.xml.bind.annotation.XmlSchema(namespace = "urn:Optimist/types")
package optimist.types;
