
package optimist.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for attachFinancialInformation_V1Response complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="attachFinancialInformation_V1Response">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="result" type="{urn:Optimist/types}AttachFinancialInformation_V1ResponseType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "attachFinancialInformation_V1Response", propOrder = {
    "result"
})
public class AttachFinancialInformationV1Response {

    @XmlElement(required = true, nillable = true)
    protected AttachFinancialInformationV1ResponseType result;

    /**
     * Gets the value of the result property.
     * 
     * @return
     *     possible object is
     *     {@link AttachFinancialInformationV1ResponseType }
     *     
     */
    public AttachFinancialInformationV1ResponseType getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     * @param value
     *     allowed object is
     *     {@link AttachFinancialInformationV1ResponseType }
     *     
     */
    public void setResult(AttachFinancialInformationV1ResponseType value) {
        this.result = value;
    }

}
