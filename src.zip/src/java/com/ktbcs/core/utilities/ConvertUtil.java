/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.utilities;

import com.ktbcs.core.vo.UMAuthorizationInfoObj;
import com.ktbcs.core.vo.UMUserDetailResponse;
import com.ktbcs.core.vo.UserData;
import com.thoughtworks.xstream.XStream;
import java.math.BigDecimal;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

/**
 *
 * @author aon
 */
public class ConvertUtil {

    private static final Logger logger = Logger.getLogger(ConvertUtil.class);

    public static String convertPasswordBase64(String password) throws Exception {
        String base64Password = "";
        try {
            if (password == null) {
                password = "";
            }
            byte[] buf = Base64.encodeBase64(password.getBytes());
            base64Password = new String(buf);
        } catch (Exception ex) {
            throw ex;
        }
        return base64Password;
    }

    public static UserData convertUMUser2LoanUser(UMUserDetailResponse umUser) throws ClassCastException , Exception{
        UserData loanUser = new UserData();
        if (umUser != null) {
            loanUser.setEmpNo(umUser.getEmpId());
            loanUser.setEmail(umUser.getEmpMail());
            loanUser.setEmpNameThai(umUser.getEmpNameThai());
            loanUser.setEmpSurnameThai(umUser.getEmpSurnameThai());
            loanUser.setTitleNameThai(umUser.getTitleNameThai());
            if (umUser.getUmAuthorizationInfoObjList() != null) {
                loanUser.setDeptCode(umUser.getUmAuthorizationInfoObjList().get(0).getDeptCode());
                for (UMAuthorizationInfoObj authorize : umUser.getUmAuthorizationInfoObjList()) {
                    UserData.Authorize item = new UserData.Authorize();
                    item.setDivisionCode(authorize.getDivisionCode());
                    item.setDivisionName(authorize.getDivisionName());
                    item.setJobCode(authorize.getJobCode());
                    item.setJobDesc(authorize.getJobDesc());
                    item.setKtbFieldMapCode(authorize.getKtbFieldMapCode());
                    item.setKtbFieldMapDesc(authorize.getKtbFieldMapDesc());
                    item.setRegionCode(authorize.getRegionCode());
                    item.setRegionName(authorize.getRegionName());
                    item.setResponseUnitCode(authorize.getResponseUnitCode());
                    item.setResponseUnitName(authorize.getResponseUnitName());
                    item.setResponseUnitType(authorize.getResponseUnitType());
                    item.setRoleDesc(authorize.getRoleDesc());
                    item.setRoleId(authorize.getRoleId());
                    item.setSectionCode(authorize.getSectionCode());
                    item.setSectionName(authorize.getSectionName());
                    item.setSeqId(authorize.getSeqId());

                    item.setDeptCode(authorize.getDeptCode());
                    item.setDeptName(authorize.getDeptName());
                    item.setDeptPhone(authorize.getDeptPhone());

                    loanUser.getAuthorizeList().add(item);
                }
            }

        } else {
            throw new Exception();
        }
        return loanUser;
    }

    public static boolean isNumeric(String str) {
        try {
            double d = Double.parseDouble(str);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public static String objectToXML(Object targetObject){
        String xml = new String();
        XStream xstream = new XStream();
        xml = xstream.toXML(targetObject);
        return xml;
    }

    public static Object xmlToObject(String xml){
        XStream xstream = new XStream();
        Object targetObject = xstream.fromXML(xml);
        return targetObject;
    }
    
    public static String colorMapping(int value) {
        String color = "#FFFFFF";
        String[] colorList = new String[]{"#FFFFCC","#CCFFCC","#CCCCFF","#CCFF66","#D2F4FF","#DACF96","#CACAFF","#C0C0C0"};
        
        int index = BigDecimal.valueOf(value%colorList.length).intValue();
        if(index<colorList.length){
            color = colorList[index];
        }else{
            color = colorList[colorList.length-1];
        }
        return color;
    }  
}
