package com.ktbcs.core.utilities;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;

/**
 * Initial version with minimum features
 * @author Newz
 */
public class MailMessageBundle {
    public static final String RESOURCE_BUNDLE_NAME = "mail";

    /************************* messages.properties *************************/

    private static Logger logger = Logger.getLogger(MailMessageBundle.class);

    public static ResourceBundle getResourceBundle() {
        return ResourceBundle.getBundle(RESOURCE_BUNDLE_NAME);
    }
    public static ResourceBundle getResourceBundle(Locale locale) {
        return ResourceBundle.getBundle(RESOURCE_BUNDLE_NAME, locale);
    }

    public static String getMessage(String key) {
        if (logger.isDebugEnabled()) {
            logger.debug("Get MessageBundle with key:"+key);
        }
        return getResourceBundle().getString(key);
    }

    public static String getMessage(Locale locale, String key) {
        return getResourceBundle(locale).getString(key);
    }

    public static String getMessage(String key, Object ... arguments) {
        return MessageFormat.format(getMessage(key), arguments);
    }

    public static String getMessage(Locale locale, String key, Object ... arguments) {
        return MessageFormat.format(getMessage(locale, key), arguments);
    }
}
