/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.utilities;

import com.ktbcs.core.vo.HeaderArea;
import com.ktbcs.core.vo.HeaderExcel;
import com.ktbcs.core.vo.ItemObject;
import com.ktbcs.core.vo.ReportExcelObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
/**
 *
 * @author KTBDevLoan
 */
public class ExportUtil {
    

    public static final String[] excelColumnName = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
    public static final String monthNameTH[] = {"\u0E21\u0E01\u0E23\u0E32\u0E04\u0E21",
        "\u0E01\u0E38\u0E21\u0E20\u0E32\u0E1E\u0E31\u0E19\u0E18\u0E4C",
        "\u0E21\u0E35\u0E19\u0E32\u0E04\u0E21",
        "\u0E40\u0E21\u0E29\u0E32\u0E22\u0E19",
        "\u0E1E\u0E24\u0E29\u0E20\u0E32\u0E04\u0E21",
        "\u0E21\u0E34\u0E16\u0E38\u0E19\u0E32\u0E22\u0E19",
        "\u0E01\u0E23\u0E01\u0E0F\u0E32\u0E04\u0E21",
        "\u0E2A\u0E34\u0E07\u0E2B\u0E32\u0E04\u0E21",
        "\u0E01\u0E31\u0E19\u0E22\u0E32\u0E22\u0E19",
        "\u0E15\u0E38\u0E25\u0E32\u0E04\u0E21",
        "\u0E1E\u0E24\u0E28\u0E08\u0E34\u0E01\u0E32\u0E22\u0E19",
        "\u0E18\u0E31\u0E19\u0E27\u0E32\u0E04\u0E21"
    };
    public static String EXFORMAT_INTEGER = "INTEGER";
    public static String EXFORMAT_NUMBER = "NUMBER";

    public static String[] getDayInMonth(int month) {

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, month - 1);
        int lastDate = calendar.getActualMaximum(Calendar.DATE);
        if (month == 2) {
            lastDate = 29;
        }
        String dayName[] = new String[lastDate];
        for (int i = 1; i < lastDate + 1; i++) {
            dayName[i - 1] = String.valueOf(i);
        }
        return dayName;
    }

    public static InputStream exportExcel(ArrayList<ReportExcelObject> listSheet) throws Exception {
        InputStream stream = null;
        try {

            HSSFWorkbook wb = new HSSFWorkbook();
            ReportExcelObject rptExcelObject =null;
            for(ReportExcelObject item1:listSheet){
                rptExcelObject = item1;
                List<ItemObject> list = (List) rptExcelObject.getListData();
                HeaderExcel[][] excelTopic = rptExcelObject.getHeaderList();
                HSSFSheet sheet ;
                if(rptExcelObject.getSheetName()!=null&&!"".equals(rptExcelObject.getSheetName())){
                    sheet = wb.createSheet(rptExcelObject.getSheetName());
                }else{
                    sheet = wb.createSheet();
                }
                HSSFRow row = null;
                HSSFCell cell = null;

                HSSFCellStyle headStyle = wb.createCellStyle();
                HSSFCellStyle topicStyle = wb.createCellStyle();
                HSSFCellStyle celTotalStyle = wb.createCellStyle();
                HSSFDataFormat dataFormat = wb.createDataFormat();

                HSSFFont celFont = wb.createFont();
                HSSFFont headFont = wb.createFont();
                headFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);

                HSSFCellStyle doubleStyle = wb.createCellStyle();
                short sFormatNumber = dataFormat.getFormat("#,##0.00");
                doubleStyle.setDataFormat(sFormatNumber);
                doubleStyle.setFont(celFont);
                doubleStyle.setWrapText(false);
                doubleStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                doubleStyle.setLeftBorderColor(HSSFColor.BLACK.index);
                doubleStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                doubleStyle.setRightBorderColor(HSSFColor.BLACK.index);
                doubleStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                doubleStyle.setBottomBorderColor(HSSFColor.BLACK.index);

                HSSFCellStyle intStyle = wb.createCellStyle();
                short sFormatInt = dataFormat.getFormat("#,##0");
                intStyle.setDataFormat(sFormatInt);
                intStyle.setFont(celFont);
                intStyle.setWrapText(false);
                intStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                intStyle.setLeftBorderColor(HSSFColor.BLACK.index);
                intStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                intStyle.setRightBorderColor(HSSFColor.BLACK.index);
                intStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                intStyle.setBottomBorderColor(HSSFColor.BLACK.index);

                HSSFCellStyle intStyleNoBorder = wb.createCellStyle();
                short sFormatIntNoBorder = dataFormat.getFormat("#,##0");
                intStyleNoBorder.setDataFormat(sFormatIntNoBorder);
                intStyleNoBorder.setFont(celFont);
                intStyleNoBorder.setWrapText(false);
                
                
                HSSFCellStyle celStyleNoBorder = wb.createCellStyle();
                celStyleNoBorder.setFont(celFont);
                celStyleNoBorder.setWrapText(false);
                
                HSSFCellStyle celStyle = wb.createCellStyle();
                celStyle.setFont(celFont);
                celStyle.setWrapText(false);
                celStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                celStyle.setLeftBorderColor(HSSFColor.BLACK.index);
                celStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                celStyle.setRightBorderColor(HSSFColor.BLACK.index);
                celStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                celStyle.setBottomBorderColor(HSSFColor.BLACK.index);

                headStyle.setFont(headFont);
                headStyle.setWrapText(false);
                headStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                headStyle.setBottomBorderColor(HSSFColor.BLACK.index);
                headStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                headStyle.setLeftBorderColor(HSSFColor.BLACK.index);
                headStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                headStyle.setRightBorderColor(HSSFColor.BLACK.index);
                headStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                headStyle.setTopBorderColor(HSSFColor.BLACK.index);
                headStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                headStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
                headStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
                headStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

                topicStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                topicStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                topicStyle.setLeftBorderColor(HSSFColor.BLACK.index);
                topicStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                topicStyle.setRightBorderColor(HSSFColor.BLACK.index);
                topicStyle.setFont(headFont);
                topicStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                topicStyle.setBottomBorderColor(HSSFColor.BLACK.index);
                topicStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
                topicStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                topicStyle.setTopBorderColor(HSSFColor.BLACK.index);
                topicStyle.setWrapText(true);

                celTotalStyle.setFont(headFont);
                celTotalStyle.setWrapText(false);
                celTotalStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
                celTotalStyle.setBottomBorderColor(HSSFColor.BLACK.index);
                celTotalStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
                celTotalStyle.setLeftBorderColor(HSSFColor.BLACK.index);
                celTotalStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
                celTotalStyle.setRightBorderColor(HSSFColor.BLACK.index);
                celTotalStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
                celTotalStyle.setTopBorderColor(HSSFColor.BLACK.index);
                celTotalStyle.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
                celTotalStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
                celTotalStyle.setFillForegroundColor(HSSFColor.GOLD.index);
                celTotalStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

                HSSFCellStyle dateStyle = wb.createCellStyle();
                dateStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("dd/mm/yyyy hh:mm"));

                sheet.setColumnWidth((short) 0, (short) (15 * 256));

                int rowWidth[] = new int[rptExcelObject.MAX_DATA_COL + 1];
                for (int k = 0; k < rptExcelObject.MAX_DATA_COL + 1; k++) {
                    if (excelTopic[2][k] != null && excelTopic[2][k].getChrWidth() > 0) {
                        rowWidth[k] = excelTopic[2][k].getChrWidth();
                    } else if (excelTopic[1][k] != null && excelTopic[1][k].getChrWidth() > 0) {
                        rowWidth[k] = excelTopic[1][k].getChrWidth();
                    } else if (excelTopic[0][k] != null && excelTopic[0][k].getChrWidth() > 0) {
                        rowWidth[k] = excelTopic[0][k].getChrWidth();
                    }
                }

                for (int m = 0; m < rptExcelObject.MAX_DATA_COL + 1; m++) {
                    if (rowWidth[m] > 0) {
                        sheet.setColumnWidth((short) m, (short) (rowWidth[m] * 256));
                    } else {
                        sheet.setColumnWidth((short) m, (short) (20 * 256));
                    }
                }

                //create topic row
                row = sheet.createRow((short) 0);
                cell = row.createCell((short) 0);
                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                cell.setCellValue(rptExcelObject.getHeaderName());
                cell.setCellStyle(topicStyle);

                for (int n = 1; n < rptExcelObject.MAX_DATA_COL + 1; n++) {
                    cell = row.createCell((short) n);
                    cell.setCellStyle(headStyle);
                }

                sheet.addMergedRegion(new org.apache.poi.hssf.util.Region(0, (short) 0, 0, (short) rptExcelObject.MAX_DATA_COL));

                for (int i = 1; i < 4; i++) {
                    row = sheet.createRow((short) i);
                    for (int j = 0; j < rptExcelObject.MAX_DATA_COL + 1; j++) {
                        cell = row.createCell((short) j);
                        cell.setCellType(HSSFCell.CELL_TYPE_STRING);

                        cell.setCellValue(excelTopic[i - 1][j] != null ? excelTopic[i - 1][j].getColName() : "");
                        cell.setCellStyle(headStyle);

                    }
                }

                ArrayList<HeaderArea> listMergedRegion = rptExcelObject.getListHeaderArea(3, rptExcelObject.MAX_DATA_COL + 1);
                for (HeaderArea item : listMergedRegion) {
                    sheet.addMergedRegion(new org.apache.poi.hssf.util.Region(item.startY + 1, (short) item.startX, item.endY + 1, (short) item.endX));
                }

                if (list != null) {
                    int runRow = 4;
                    int runCol = 0;

                    int rowPerRecord = rptExcelObject.getRowValue().size();
                    if (rowPerRecord < 1) {
                        rptExcelObject.getRowValue().add(rptExcelObject.getColumnValue());
                        rowPerRecord = 1;
                    }

                    String[] compareText = new String[]{"", "", "", "", "", ""};
                    for (ReportExcelObject.ItemObject item : rptExcelObject.getListData()) {
                        for (int r = 0; r < rowPerRecord; r++) {
                            String[] columnName = rptExcelObject.getRowValue().get(r);
                            row = sheet.createRow((short) runRow);
                            runCol = 0;
                            if (item.getDataExcel() != null && item.getDataExcel().size() > 0) {

                                for (int i = 0; i < columnName.length; i++) {  // create column in a row

                                    Object value = new Object();
                                    if (item.getDataExcel().get(columnName[i]) != null) {
                                        value = item.getDataExcel().get(columnName[i]);
                                    } else {
                                        //value = new String(columnName[i]);
                                        value = new String("");
                                    }

                                    cell = row.createCell((short) runCol);
                                    if (value.getClass().equals(String.class)) {
                                        cell.setCellType(HSSFCell.CELL_TYPE_STRING);

                                        if (i < rptExcelObject.getCompareTextNum() && r == 0) {
                                            if (!compareText[i].equals((String) value)) {
                                                cell.setCellValue((String) value);
                                                compareText[i] = (String) value;
                                            } else {
                                                cell.setCellValue((String) "");
                                            }
                                        } else {
                                            cell.setCellValue((String) value);
                                        }

                                        cell.setCellStyle(celStyle);
                                    } else if (value.getClass().equals(Integer.class)) {
                                        cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                                        cell.setCellValue((Integer) value);
                                        cell.setCellStyle(intStyle);
                                    } else if (value.getClass().equals(Double.class)) {
                                        cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                                        cell.setCellValue((Double) value);
                                        cell.setCellStyle(doubleStyle);
                                    } else if (value.getClass().equals(BigDecimal.class)) {
                                        cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                                        cell.setCellValue(((BigDecimal) value).doubleValue());
                                        cell.setCellStyle(doubleStyle);
                                    } else if (value.getClass().equals(java.util.Date.class)) {
                                        cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                        cell.setCellValue((String) value);
                                        cell.setCellStyle(celStyle);
                                    } else {
                                        if (value != null) {
                                            cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                            cell.setCellValue(value.toString());
                                            cell.setCellStyle(celStyle);
                                        }
                                    }
                                    runCol++;
                                }

                                runRow++;
                            }
                        }
                    }

                    if (rptExcelObject.isShowTotal()) {

                        row = sheet.createRow((short) runRow);
                        cell = row.createCell((short) 0);
                        cell.setCellStyle(celStyle);
                        cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                        cell.setCellValue("" + rptExcelObject.getTotalName());

                        HSSFRow smRow = sheet.getRow((short) 4);
                        HSSFCell smCell;
                        boolean isEnd = false;
                        int endMergeCell = 0;
                        for (int col = 1; col < rptExcelObject.MAX_DATA_COL + 1; col++) {
                            smCell = smRow.getCell((short) col);
                            if (smCell != null && smCell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
                                cell = row.createCell((short) col);
                                cell.setCellStyle(doubleStyle);
                                cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                                cell.setCellFormula("SUM(" + ExportUtil.excelColumnName[col] + "5:" + ExportUtil.excelColumnName[col] + "" + (runRow) + ")");
                                isEnd = true;
                            } else {
                                cell = row.createCell((short) col);
                                cell.setCellStyle(celStyle);
                                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(new String(""));
                            }
                            if (!isEnd) {
                                endMergeCell++;
                            }
                        }
                        sheet.addMergedRegion(new org.apache.poi.hssf.util.Region(runRow, (short) 0, runRow, (short) endMergeCell));
                        runRow++;
                    }
                    
                    if (rptExcelObject.isIsShowSummary()) {

                        row = sheet.createRow((short) runRow);
                        for(int i=0;i< rptExcelObject.getSummaryColumn().length;i++){
                            if(i==0 && rptExcelObject.getSummaryColumn()[i] >0){
                                cell = row.createCell((short) rptExcelObject.getSummaryColumn()[i]-1 );
                                cell.setCellStyle(celStyleNoBorder);
                                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue("รวม");
                            }
                            
                            cell = row.createCell((short) rptExcelObject.getSummaryColumn()[i]);
                            cell.setCellStyle(intStyleNoBorder);
                            cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                            cell.setCellValue((String)rptExcelObject.getSummaryTotal().get(i));

                        }
                        
                        runRow++;
                    }
                  
                    
                    if (rptExcelObject.isShowAverage()) {
                        int tmpRunRow = runRow;
                        if (rptExcelObject.isShowTotal()) {
                            tmpRunRow--;
                        }
                        row = sheet.createRow((short) runRow);
                        cell = row.createCell((short) 0);
                        cell.setCellStyle(doubleStyle);
                        cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                        cell.setCellValue("" + rptExcelObject.getTotalName2());
                        for (int col = 1; col < rptExcelObject.MAX_DATA_COL + 1; col++) {
                            cell = row.createCell((short) col);
                            cell.setCellStyle(celStyle);
                            cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);

                            if ((col == 1 || col == 2) && (rptExcelObject.MAX_DATA_COL == 6)) {
                                cell.setCellFormula("SUM(" + ExportUtil.excelColumnName[col] + "5:" + ExportUtil.excelColumnName[col] + "" + (tmpRunRow) + ")/" + (rptExcelObject.getNumDay1()) + "");
                            } else if ((col == 3 || col == 4) && (rptExcelObject.MAX_DATA_COL == 6)) {
                                cell.setCellFormula("SUM(" + ExportUtil.excelColumnName[col] + "5:" + ExportUtil.excelColumnName[col] + "" + (tmpRunRow) + ")/" + (rptExcelObject.getNumDay2()) + "");
                            } else if (col == 5) {
                                cell.setCellFormula("" + ExportUtil.excelColumnName[3] + "" + (tmpRunRow + 1) + "-" + ExportUtil.excelColumnName[1] + "" + (tmpRunRow + 1) + "");
                            } else if (col == 6) {
                                cell.setCellFormula("(" + ExportUtil.excelColumnName[3] + "" + (tmpRunRow + 1) + "-" + ExportUtil.excelColumnName[1] + "" + (tmpRunRow + 1) + ")*100/" + ExportUtil.excelColumnName[1] + "" + (tmpRunRow + 1) + "");
                            } else {
                                cell.setCellFormula("SUM(" + ExportUtil.excelColumnName[col] + "5:" + ExportUtil.excelColumnName[col] + "" + (tmpRunRow) + ")/" + (tmpRunRow - 4) + "");
                            }
                        }
                        runRow++;
                    }
                }
            }

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            bos.close();
            byte[] bytes = bos.toByteArray();

            stream = new ByteArrayInputStream(bytes);
        } catch (Exception e) {
            throw e;
        }
        return stream;
    }
}
