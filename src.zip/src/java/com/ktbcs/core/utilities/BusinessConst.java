package com.ktbcs.core.utilities;

/**
 *
 * @author Administrator
 */
public interface BusinessConst {

    public interface ActiveType {

        String ACTIVE = "ACT";
        String IN_ACTIVE = "INA";
        String APPROVE = "APV";
        String WAIT_ACTIVE = "WACT";
    }

    public interface Session {

        String LOGIN_KEY = "LOGIN";
        String TITLE_KEY = "TITLE";
        String WARNING_TYPE_SESSION_KEY = "WARNING_TYPE_SESSION";
        String LOG_PATH = "LOG_PATH";
        String PIPELINE_CRITERIA_SEARCH_SORT = "PIPELINE_CRITERIA_SEARCH_SORT";
        String CUSTOMER_PORTFOLIO_CRITERIA_SEARCH = "CUSTOMER_PORTFOLIO_CRITERIA_SEARCH";
        String RISK_MIGRATION_SEARCH_ALL_CIF = "RISK_MIGRATION_SEARCH_ALL_CIF";
        String QUESTION_HISTORY_KEY = "ACTION_HISTORY_KEY";
        String FINANCE_HISTORY_KEY = "FINANCE_HISTORY_KEY";
        String URL_FROM_SESSION = "URL_FROM_SESSION";
        String CLOSE_JOB_CRITERIA_SEARCH_SORT = "CLOSE_JOB_CRITERIA_SEARCH_SORT";
        String FOR_BACK_PAGE_TASK_DETAIL = "FOR_BACK_PAGE_TASK_DETAIL";
        String PERMISSION_ACCESS = "NOPERMISSION";
    }

    public interface System {

        String EWSSME = "EWSSME";
    }

    public interface UserRole {

        String RM = "RM";
        String MONITOR = "MT";
        String RISK_MONITOR = "RMT";
        String RISK_EDITOR = "RE";
        //String REVIEWER = "RV";
        String CREDIT_CONTROLER = "CC"; //-- Credit Review
        String TURNAROUND = "TA";
        String BC_APPROVER = "BC";
        String ADMIN = "AD";
        String SENIOR_ACCOUNT_OFFICER = "SAO";
        String CM = "CM";
        String SCM = "SCM";
        String BCM = "BCM";
        String VIEWER = "VW";
        String RISK_VIEWER = "RV";
        String AE = "AE";
        String AO = "AO";
        String VIWER_1 = "VW1";
        String VIWER_2 = "VW2";
        String VIWER_3 = "VW3";
        String VIWER_4 = "VW4";
        String VIWER_5 = "VW5";
        
        String CO_RM = "CO_RM";
        String CO_AE = "CO_AE";
        String CO_AO = "CO_AO";
        String CO_BCM = "CO_BCM";
        
        String AMD = "AMD";
    }

    public interface WSChannel {
        String EWS_CHANNEL = "EWS";
        String EWS_L_CHANNEL = "EWSL"; 
    }

    public interface ProjectName {
        String SME_PROJECT = "SME_Questionnaire";
        String EQUS_PROJECT = "ELQUS";
        String FIN_PROJECT = "ELFFU";
        String EWSQ_PROJECT = "ELFRL";
        String TRIGGER_PROJECT = "ELRAA";//EFRL";
        String LATEPAYMENT_PROJECT = "ELRAA";
    }

    public interface QuestionId {

        String QCAAGRI = "QCAAGRI";
    }

    public interface FileUpload {

        long INS_MAX_SIZE = 25242880;
    }

    public interface SQLType {

        String SELECT = "SELECT";
        String UPDATE = "UPDATE";
        String DELETE = "DELETE";
        String PROCEDURE = "PROCEDURE";
    }

    public interface RemarkType {

        String INFO = "INFO";
    }

    public interface BgColor {

        String WHITE = "#FFFFFF";
    }

    public interface Flag {

        String Y = "Y";
        String N = "N";
        String INPROCESS = "I";
        String COMPLETE = "C";
        String WAIT = "W";
        String DRAFT = "D";
        String NA = "NA";
        String RMP = "RMP";
        String RMF = "RMF";
        String BRMP = "BRMP";
        String BCA = "BCA";
        String CMP = "CMP";
        String CMF = "CMF";
        String SCMP = "SCMP";
        int ACTIVE = 1;
        int INACTIVE = 0;
        int APPROVE = 1;
        int NOTAPPROVE = 0;
        String CASE_TYPE_TURNAROUND = "T";
        String CASE_TYPE_CREDIT_RENEWAL = "R";
        String CASE_TYPE_ALL = "A";
        String BBCA = "BBCA";
        String BRMF = "BRMF";
        String APPROVE_QCA = "A";
        String CLOSE_JOB = "R";
        String CANCEL = "CC";
        String P = "P";// Protest
        String PRMP = "PRMP";
        String OVER_LIMIT_SLA = "O";
        String E = "E";
        String DEFAULT = "D";
        String RX = "RX";
        String TRUE = "TRUE";
        String FAIL = "FAIL";
        String VIEW = "VIEW";
        String EDIT = "EDIT";
    }

    public interface Batch {

        String AUTOSYS = "AUTOSYS";
        String SPLITTER = "|";
    }

    public interface BatchType {

        String RECEIVE = "RECEIVE";
        String SEND = "SEND";
    }

    public interface SearchTitle {

        String CIF = "CIF";
        String NAME = "NAME";
        String COSTCENTER = "COSTCENTER";
        String RM_NAME = "RM_NAME";
        String COSTCENTER_NAME = "COSTCENTER_NAME";
        String ORGANIZATION_TYPE = "ORGANIZATION_TYPE";
        String RM_ID = "RM_ID";
        String CO_RM_ID = "CO_RM_ID";
        String CO_OP_ID = "CO_OP_ID";
    }

    public interface WarningTypeCode {

        String FIN = "FIN";
        String EWSQ = "EWSQ";
        String TRIGANDPAY = "TRIGANDPAY";
        String TRIG = "TRIG";
        String PAY = "PAY";
        String TRIG01 = "TRIG01";
        String TRIG02 = "TRIG02";
        String TRIG03 = "TRIG03";
        String TRIG04 = "TRIG04";
        String TRIG05 = "TRIG05";
        String TRIG06 = "TRIG06";
        String TRIG07 = "TRIG07";
        String TRIG08 = "TRIG08";
        String TRIG09 = "TRIG09";
        String TRIG10 = "TRIG10";
        String TRIG11 = "TRIG11";
        String TRIG12 = "TRIG12";
        String TRIG13 = "TRIG13";
        String TRIG14 = "TRIG14";
        String TRIG15 = "TRIG15";
        String TRIG16 = "TRIG16";
        String TRIG17 = "TRIG17";
        String TRIG18 = "TRIG18";
        String TRIG19 = "TRIG19";
        String TRIG20 = "TRIG20";
        String CREDIT_REVIEW = "CR";
        String TURNAROUND = "TA";
        String LATE_PAY= "LATE_PAY";
        String WAY_OUT= "WAY_OUT";//ไม่ใช้แล้ว
        String ACTION1= "ACTION1";
        String ACTION2= "ACTION2";
        String CREDIT_RATING = "CREDIT_RATING";
        String CR    = "CR";
        String Trigger = "Trigger";
    }

    public interface ASSIGN_TASK {

        String NA = "N/A";
        String VL = "VL";
        String A = "A";
        String B = "B";
        String C = "C";
        String D = "D";
        String E1 = "E1";
        String E2 = "E2";
        String F = "F";
        String F1 = "F1";
        String F2 = "F2";
        String F3 = "F3";
        String F4 = "F4";
        String F5 = "F5";
    }

    public interface ASSIGN_ACTION {

        String AA = "AA";
        String BB = "BB";
        String CC = "CC";
        String DD = "DD";
        String EE = "EE";
        String FF = "FF";
        String NA = "N/A";
        String GG = "GG";
    }

    public interface GO_ACTION {

        String NAXT = "NAXT";
        String PREVIOUS = "PREVIOUS";
    }

    public interface CONFIG_PAGE {

        String CONFIG_GROUP_CODE = "RECORD_PER_PAGE";
        String ROW = "ROW";
        String PAGE = "PAGE";
    }

    public interface PARAMETER_TYPE_ID {
        String CLOSEJOB = "CLOSE_JOB";
        String CLOSEJOBBYTYPE = "CLOSE_JOB_TYPE";
        String CLOSE_BY_CIF_REASON = "CLOSE_BY_CIF_REASON";
    }

    public interface BREAK_BY {

        String DATA_NO_WORKLINE = "DATA_NO_WORKLINE";
        String HAVE_GROUP_CODE = "HAVE_GROUP_CODE";
        String HAVE_DEPARTMENT = "HAVE_DEPARTMENT";
        String SEARCH_BY_CUSTINFO = "SEARCH_BY_CUSTINFO";
    }

    public interface EWS_TYPE {

        String EWS_RISK_LEVEL = "RISK_FINAL";
        String EWS_QUANTITATIVE_BEHAVIOR_MODEL = "PD_1";
        String EWS_QUALITATIVE_ASSESSMENT = "PD_2";
    }

    public interface PAGE {

        String PIPELINE = "PIPELINE";
        String CUSTOMER_PORTFOLIO_SEARCH = "CUSTOMER_PORTFOLIO_SEARCH";
        String CUSTOMER_PORTFOLIO = "CUSTOMER_PORTFOLIO";
        String TASK_DETAIL = "TASK_DETAIL";
        String RISK_MIGRATION_DAILY = "RISK_MIGRATION_DAILY";
        String RISK_MIGRATION_MONTHLY = "RISK_MIGRATION_MONTHLY";
        String CLOSE_JOB_REPORT = "CLOSE_JOB_REPORT";
        String TODAY_MOVEMENT = "TODAY_MOVEMENT";
    }

    public interface WS_TRAN_TYPE {

        String REQUEST = "REQ";
        String RESPONSE = "RESP";
    }

    public interface SYSTEM_ID {

        String SCORE_ENGINE = "SCOREENGINE";
    }

    public interface ACTION_CODE {

        String PROSTEST = "Protest";
        String REJECT = "Reject";
        String RESET = "Reset";
        String APPROVE = "Approve";
        String SEND_JOB = "SendJob";
    }

    public interface CrAccountClass {

        String EXTEND_AUTO = "EXTEND_AUTO";
        String EXTEND_MANUAL = "EXTEND_MANUAL";
        String TERM_LOAN = "TERM_LOAN";
    }

    public interface KTB_FIELD_MAP_GROUP {

        int GROUP_RM = 1;
        int GROUP_BCM = 2;
        int GROUP_CM = 3;
        int GROUP_SCM = 4;
        int GROUP_AE = 5;
        int GROUP_RV = 6;
    }

    public interface LINK_FROM {
        /*String ROW_0_SUM_CIF = "ROW_0_SUM_CIF";
         String ROW_1_7_SUM_CIF = "ROW_1_7_SUM_CIF";
         String ROW_8_29_SUM_CIF = "ROW_8_29_SUM_CIF";
         String ROW_30_60_SUM_CIF = "ROW_30_60_SUM_CIF";
         String ROW_61_90_SUM_CIF = "ROW_61_90_SUM_CIF";
         String ROW_91_120_SUM_CIF = "ROW_91_120_SUM_CIF";
         String ROW_120_PLUS_SUM_CIF = "ROW_120_PLUS_SUM_CIF";*/

        String ROW_SUM_ALL_CIF = "ROW_SUM_ALL_CIF";
        /* String ROW_0_SUM_BILL_AMT = "ROW_0_SUM_BILL_AMT";
         String ROW_1_7_BILL_AMT = "ROW_1_7_BILL_AMT";
         String ROW_8_29_BILL_AMT = "ROW_8_29_BILL_AMT";
         String ROW_30_60_BILL_AMT = "ROW_30_60_BILL_AMT";
         String ROW_61_90_BILL_AMT = "ROW_61_90_BILL_AMT";
         String ROW_91_120_BILL_AMT = "ROW_91_120_BILL_AMT";
         String ROW_120_PLUS_BILL_AMT = "ROW_120_PLUS_BILL_AMT";*/
        String ROW_SUM_ALL_BILL_AMT = "ROW_SUM_ALL_BILL_AMT";
        /*String COLUMN_0_SUM_CIF = "COLUMN_0_SUM_CIF";
         String COLUMN_1_7_SUM_CIF = "COLUMN_1_7_SUM_CIF";
         String COLUMN_8_29_SUM_CIF = "COLUMN_8_29_SUM_CIF";
         String COLUMN_30_60_SUM_CIF = "COLUMN_30_60_SUM_CIF";
         String COLUMN_61_90_SUM_CIF = "COLUMN_61_90_SUM_CIF";
         String COLUMN_91_120_SUM_CIF = "COLUMN_91_120_SUM_CIF";
         String COLUMN_120_PLUS_SUM_CIF = "COLUMN_120_PLUS_SUM_CIF";
         String COLUMN_0_SUM_BILL_AMT = "COLUMN_0_SUM_BILL_AMT";
         String COLUMN_1_7_BILL_AMT = "COLUMN_1_7_BILL_AMT";
         String COLUMN_8_29_BILL_AMT = "COLUMN_8_29_BILL_AMT";
         String COLUMN_30_60_BILL_AMT = "COLUMN_30_60_BILL_AMT";
         String COLUMN_61_90_BILL_AMT = "COLUMN_61_90_BILL_AMT";
         String COLUMN_91_120_BILL_AMT = "COLUMN_91_120_BILL_AMT";
         String COLUMN_120_PLUS_BILL_AMT = "COLUMN_120_PLUS_BILL_AMT";*/
    }

    public interface TYPE_LINK {

        String BUSINESS_UNIT_CODE = "BUSINESS_UNIT_CODE";
        String GROUP_CODE = "GROUP_CODE";
    }

    public interface LINE_CASE_TYPE {

        String NORMAL = "NORMAL";
        String SUMMARY = "SUMMARY";
    }

    public interface DPD_BUCKET {

        String DPD_BUCKET_0 = "0";
        String DPD_BUCKET_1 = "1 to 7";
        String DPD_BUCKET_8 = "8 to 29";
        String DPD_BUCKET_30 = "30 to 60";
        String DPD_BUCKET_61 = "61 to 90";
        String DPD_BUCKET_91 = "91 to 120";
        String DPD_BUCKET_121 = "120+";
    }

    public interface DATA_DEFAULT {

        String KTB = "KTB";
    }

    public interface COLUMN_MT_RISK_LEVEL_MAPPING {

        String DISPLAY_ON_SCREEN_LEVEL_HISTORY = "RISK_LEVEL_HISTORY_DISP";
        String DISPLAY_ON_SCREEN_INDIVIDUAL_REPORT = "RISK_LEVEL_IND_RPT_DISP";
        String DISPLAY_ON_SCREEN_PIPELINE = "RISK_LEVEL_PIPELINE_DISP";
        String FOR_RENEWAL_DB = "RISK_LEVEL_RENEWAL_DISP";
    }

    public interface DISPLAY_TYPE {

        String HAVE_EWSQ_AND_ALREADY_GEN = "1";
        String NORMAL_CONFIRM_BT = "2";
        String ABNORMAL_REFUSE_BT = "3";
    }

    public interface FIELD_NAME {

        String INT_SLA_CAL = "INT_SLA_CAL";
        String DATE_DUEDATE = "DATE_DUEDATE";
    }
    
    public interface PARAMETER {
        String TYPE_ID_PAGE = "PAGE";
        String ID_PAGE_PER_PAGE = "PAGE_PER_PAGE";
        String ID_RECORD_PER_PAGE = "RECORD_PER_PAGE";
    }
    
    public interface WARNING_TYPE_GROUP{
      String ASSES = "ASSES";
      String MONITOR = "MONITOR";
      String REVIEW = "REVIEW";
    }
     public interface ACCESS_SYSTEM {
        String LOGIN_IN = "IN";
        String LOGIN_FAIL = "FAIL";
        String LOGOUT_OUT = "OUT";
        String LOGIN_SUCCESS = "LOGIN_SUCCESS";
        String LOGOUT_SUCCESS = "LOGOUT_SUCCESS";
        String EXPIRED = "EXPIRED";
        String EXP = "EXP";
    }
     
     public interface CONFIG_GROUP {

        String CLOSEJOB = "CLOSE_JOB";
        String CLOSEJOBBYTYPE = "CLOSE_JOB_TYPE";
        String TODAY_MOVEMENT_OD = "TODAY_MOVEMENT_OD";
    }
     
     public interface COMPLETE_FLAG_BY_WARNING_TYPE{
         String EWSQ_APPROVE = "H";
         String FIN_APPROVE = "J";
         String LATE_PAY_APPROVE = "E";
         String EWSQ_CLOSE = "C";
         String FIN_CLOSE = "D";
     }
     public interface FIN_STATE_TYPE {
        String R_ADJUST = "R";
        String A_AUDIT = "A";
    }
     
    public interface TEXT_STATIC {
       String EVENT_SAVE = "EVENT_SAVE";
       String EVENT_EDIT = "EVENT_EDIT";
    }
}
