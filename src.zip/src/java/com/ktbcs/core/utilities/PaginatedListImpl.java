/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.utilities;

import com.ktbcs.core.vo.UserData;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

/**
 *
 * @author KTB
 */
public class PaginatedListImpl<E> implements Serializable { 
    
    /** default page size */
    private static int DEFAULT_PAGE_SIZE = 10;
    private static int DEFAULT_DISPLAY_PAGE = 10;
    /** current page index, starts at 0 */
    private int index;
    /** number of results per page */
    private int pageSize;
    /** total results (records, not pages) */
    private int fullListSize;
    /** total number of page (fullListSize%pageSize) */
    private int totalPage;
    /** list of results in the current page */
    private ArrayList<E> list;
    private ArrayList<E> page;
    /** default sorting order */
    private SortOrderEnum sortDirection = SortOrderEnum.ASCENDING;
    /** sort criteria (sorting property name) */
    private String sortCriterion;
    private static final Logger logger = Logger.getLogger(PaginatedListImpl.class);
    private int beginPage = 1;
    private int endPage = 10;
    private int nextPage = 1;
    private int previousPage = 10;
    private UserData user;
    private transient Object objData;
    private int totalRecord;
    private String totalRecordStr;
    private String totalPageStr;
    private transient Object countObjData;
    /**
     * For tests: a page as big as possible, which is effectively the same as no paging
     * @return a page of Integer.MAX_VALUE size
     */
    public static PaginatedListImpl newHugeResponse() {
        PaginatedListImpl hugeResponse = new PaginatedListImpl();
        hugeResponse.setPageSize(Integer.MAX_VALUE);
        return hugeResponse;
    }

    public PaginatedListImpl() {
        // empty
    }

    public PaginatedListImpl(UserData user) {
        this.user = user;
    }

    /**
     * Factory-style constructor. Initializes properties with a request attributes
     */
    public PaginatedListImpl(Map paramMap) {

//        for (Iterator it = paramMap.keySet().iterator(); it.hasNext();) {
//            Object key = it.next();
//            Object value = paramMap.get(key);
//            System.out.println("key:" + key.toString() + ", value:" + value.toString());
////            if ("desc".equals(key)) {
////                sortDirection = "desc".equals(paramMap.get(key)) ? SortOrderEnum.DESCENDING : SortOrderEnum.ASCENDING;
////            } else if ("sort".equals(key)) {
////                sortCriterion =  paramMap.get(key).toString();
////            }
//        }

        for (Iterator it = paramMap.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            String key = (String) entry.getKey();
            String[] value = (String[]) entry.getValue();
            if (logger.isDebugEnabled()) {
                logger.debug("key:" + key + ", value:" + value[0]);
            }

            if ("dir".equals(key)) {
                sortDirection = "desc".equals(value[0]) ? SortOrderEnum.DESCENDING : SortOrderEnum.ASCENDING;
            } else if ("sort".equals(key)) {
                sortCriterion = value[0];
            }
        }


        if (pageSize == 0) {
            pageSize = DEFAULT_PAGE_SIZE;
        }

        String page = "1";
        index = page == null ? 0 : Integer.parseInt(page) - 1;

//        if (paramMap != null) {
//            sortCriterion = "jobNo";
//            String dir = "desc";
//            String page = "1";
//
//            //sortCriterion = request.getParameter("sort");
//            sortDirection = "desc".equals(dir) ? SortOrderEnum.DESCENDING : SortOrderEnum.ASCENDING;
//
//            pageSize = DEFAULT_PAGE_SIZE;
//            //String page = request.getParameter("page");
//            index = page == null ? 0 : Integer.parseInt(page) - 1;
//        } else {
//            pageSize = DEFAULT_PAGE_SIZE;
//            index = 0;
//        }
    }

    /**
     * @return A readable description of this instance state for logs
     */
    public String toString() {
        return "PageResponse { index = " + index + ", pageSize = " + pageSize + ", total = " + fullListSize + " }";
    }

    public void repaginate() {
        if (list.isEmpty()) {
            setPage(new ArrayList(0));
        } else {
            int start = (index - 1) * pageSize;
            int end = start + pageSize - 1;
            if (end >= list.size()) {
                end = list.size() - 1;
            }
            if (start >= list.size()) {
                index = 1;
                repaginate();
            } else if (start < 0) {
                index = (list.size() / pageSize) - 1;
                if (list.size() % pageSize == 0) {
                    index--;
                }
                repaginate();
            } else {
                setPage((ArrayList)list.subList(start, end + 1));
                setList((ArrayList)list.subList(start, end + 1));
            }
        }
    }

    public int getFirstRecordIndex() {
        return index * pageSize;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

   

    public void setManualList(ArrayList<E> results) {
        if (results != null) {
            int lastRecord = pageSize * index;
            if (lastRecord > results.size()) {
                lastRecord = results.size();
            }

            this.list = (ArrayList)results.subList((index - 1) * pageSize, lastRecord);
        } else {
            this.list = null;
        }
    }

    public int getFullListSize() {
        return fullListSize;
    }

    public void setFullListSize(int fullListSize) {
        this.fullListSize = fullListSize;
        if (this.pageSize > 0) {
            BigDecimal tpage = (new BigDecimal(fullListSize)).divide(new BigDecimal(pageSize), BigDecimal.ROUND_CEILING);
            System.out.println(tpage);
            tpage = tpage.setScale(0, BigDecimal.ROUND_CEILING);
            this.totalPage = tpage.intValue();

            if ((index - (pageSize / 2)) < 1) {
                beginPage = 1;
            } else {
                beginPage = index - (pageSize / 2);
            }

            endPage = beginPage + pageSize - 1;

            if (beginPage > totalPage && totalPage > 0) {
                beginPage = totalPage;
            }
            if (endPage > totalPage) {
                beginPage = totalPage - pageSize + 1;
                endPage = totalPage;
            }
            if (beginPage < 1) {
                beginPage = 1;
            }
            if (totalPage < 1) {
                beginPage = 1;
                endPage = 1;
            }
            nextPage = index + 1;
            previousPage = index - 1;
        }

    }

    public void setTotal(int total) {
        this.fullListSize = total;
    }

    public int getTotalPages() {
        return (int) Math.ceil(((double) fullListSize) / pageSize);
    }

    public int getObjectsPerPage() {
        return pageSize;
    }

    public int getPageNumber() {
        return index + 1;
    }

    public String getSearchId() {
        // unimplemented
        return null;
    }

    public String getSortCriterion() {
        return sortCriterion;
    }

    public SortOrderEnum getSortDirection() {
        return sortDirection;
    }

    public String getSqlSortDirection() {
        return SortOrderEnum.DESCENDING.equals(sortDirection) ? "desc" : "asc";
    }

    public void setSortCriterion(String sortCriterion) {
        this.sortCriterion = sortCriterion;
    }

    public void setSortDirection(SortOrderEnum sortDirection) {
        this.sortDirection = sortDirection;
    }

    /**
     * Adds the order by parameter to a query. If there is already an
     * order by, <b>prepends</b> the current order to the one included
     * in the query
     */
    public String addOrderBy(String query) {
        // no order by
        if (sortCriterion == null) {
            return query;
        }
        int pos = locateOrderBy(query);
        // order by one criteria
        if (pos == -1) {
            return query + " order by " + sortCriterion + " " + getSqlSortDirection();
        }
        // order by two criteria
        return query.substring(0, pos) + sortCriterion + " " + getSqlSortDirection() + ", " + query.substring(pos);
    }

    /**
     * Locates the "order by" clause, if there is one
     * @param query the QL query to inspect
     * @return The position of the first character after the "order by" clause if there is one, -1 if not.
     */
    private int locateOrderBy(String query) {
        int pos = query.lastIndexOf(" order ");
        if (pos != -1) {
            pos = query.lastIndexOf("by ", pos + 7);
            if (pos != -1) {
                return pos + 3;
            }
        }
        return pos;

    }

    /**
     * @return the totalPage
     */
    public int getTotalPage() {
        return totalPage;
    }

    /**
     * @param totalPage the totalPage to set
     */
    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    /**
     * @return the beginPage
     */
    public int getBeginPage() {
        return beginPage;
    }

    /**
     * @param beginPage the beginPage to set
     */
    public void setBeginPage(int beginPage) {
        this.beginPage = beginPage;
    }

    /**
     * @return the endPage
     */
    public int getEndPage() {
        return endPage;
    }

    /**
     * @param endPage the endPage to set
     */
    public void setEndPage(int endPage) {
        this.endPage = endPage;
    }

    /**
     * @return the nextPage
     */
    public int getNextPage() {
        return nextPage;
    }

    /**
     * @param nextPage the nextPage to set
     */
    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }

    /**
     * @return the previousPage
     */
    public int getPreviousPage() {
        return previousPage;
    }

    /**
     * @param previousPage the previousPage to set
     */
    public void setPreviousPage(int previousPage) {
        this.previousPage = previousPage;
    }

    public ArrayList<E> getList() {
        return list;
    }

    public void setList(ArrayList<E> list) {
        this.list = list;
    }

    public ArrayList<E> getPage() {
        return page;
    }

    public void setPage(ArrayList<E> page) {
        this.page = page;
    }

  

    public boolean isEmpty() {
        boolean empty = true;
        if (getList() != null && getList().size() > 0) {
            empty = false;
        }

        return empty;
    }

    /**
     * @return the user
     */
    public UserData getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(UserData user) {
        this.user = user;
    }

    public Object getObjData() {
        return objData;
    }

    public void setObjData(Object objData) {
        this.objData = objData;
    }
    
    public void setFullListSizeWithPaging(int fullListSize , int page) {
        this.fullListSize = fullListSize;
        if (this.pageSize > 0) {
            BigDecimal tpage = (new BigDecimal(fullListSize)).divide(new BigDecimal(pageSize), BigDecimal.ROUND_CEILING);
            System.out.println(tpage);
            tpage = tpage.setScale(0, BigDecimal.ROUND_CEILING);
            this.totalPage = tpage.intValue();
        if(page > 0){
            if ((index - (page / 2)) < 1) {
                beginPage = 1;
            } else {
                beginPage = index - (page / 2);
            }
        }else{
            if ((index - (pageSize / 2)) < 1) {
                beginPage = 1;
            } else {
                beginPage = index - (pageSize / 2);
            }
        }
            //---------Modify--------//
            if(page > 0){
               endPage = beginPage + page - 1; 
            }else{
               endPage = beginPage + pageSize - 1;
            }
            //-----------------//
           
            
            if (beginPage > totalPage && totalPage > 0) {
                beginPage = totalPage;
            }
            if (endPage > totalPage) {
                 if(page > 0){
                     beginPage = totalPage - page + 1;
                 }else{
                     beginPage = totalPage - pageSize + 1;
                 }
                endPage = totalPage;
            }
            if (beginPage < 1) {
                beginPage = 1;
            }
            if (totalPage < 1) {
                beginPage = 1;
                endPage = 1;
            }
            nextPage = index + 1;
            previousPage = index - 1;
        }

    }

    public int getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord) {
        this.totalRecord = totalRecord;
    }

    public String getTotalRecordStr() {
        return totalRecordStr;
    }

    public void setTotalRecordStr(String totalRecordStr) {
        this.totalRecordStr = totalRecordStr;
    }

    public String getTotalPageStr() {
        return totalPageStr;
    }

    public void setTotalPageStr(String totalPageStr) {
        this.totalPageStr = totalPageStr;
    }

    public Object getCountObjData() {
        return countObjData;
    }

    public void setCountObjData(Object countObjData) {
        this.countObjData = countObjData;
    }
    
}
