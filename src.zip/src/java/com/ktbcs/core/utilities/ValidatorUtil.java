/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.utilities;

/**
 *
 * @author KTBDevLoan
 */
public class ValidatorUtil {
    
    public static boolean isNullOrEmpty(Object strParam) {
        return (strParam == null || strParam.toString().length() == 0);
    }
    
}
