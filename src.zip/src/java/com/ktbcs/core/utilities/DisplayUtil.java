/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.utilities;

import com.ktb.ewsl.vo.TabDateReportVO;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public class DisplayUtil {
    
    public static final String SE_NA = "N/A";
    public static final String SE_NO = "NO";
    public static final String SE_NUM_9 = "-99999999";
    public static final String BLANK = "";
    public static final String SE_NUM_9_ONE_CHAR = "-";
    
    public static String getRiskLevelForDisplay(String data){
      String result = "";
      try{
         /* if(data != null){
            if(SE_NO.equals(data)|| SE_NUM_9.equals(data)|| SE_NUM_9_ONE_CHAR.equals(data) || SE_NA.equals(data)){
                  result = SE_NO;
            }/*else if(SE_NA.equals(data) ){
                  result = BLANK;
            }*--/else{
                  result = data ;
                  if(data.trim().length() > 1){
                      result = data.toString().substring(0, 1);
                  }
            }
          }*/
          
        //---FOR Defect phase 2.4.0
         if(ValidatorUtil.isNullOrEmpty(data)){ //-- NULL , ""
              result = BLANK;
          }else if(("H".equals(data.trim()))||("M".equals(data.trim()))||("L".equals(data.trim()))){ //-- H , M , L 
             result = data;
          }else{
             result = SE_NO;
          }
      }catch(Exception e){
         e.printStackTrace();
      }
      return result ;
    }
    
     public static String getCountBillForDisplay(int bill , BigDecimal amount){
      String data = "";
      if(amount == null && bill == 0){
         data = "-";
      }else{
        data = String.valueOf(bill);
      }
      return data;
    }
      public static String getNameMonthYearThai(int monthCalendar, Date date) throws Exception {
        String dailyMonthStr = DateUtil.getThaiMonthShort(monthCalendar) != null ? DateUtil.getThaiMonthShort(monthCalendar) : "";
        String dailyYearStr = DateUtil.getShortYearThaiFormat(date) != null ? DateUtil.getShortYearThaiFormat(date) : "";
        return dailyMonthStr.concat(dailyYearStr);
    }

    public static String getFullMonthYearThai(int monthCalendar, String year) throws Exception {
        String monthFull = DateUtil.getThaiMonthFull(monthCalendar).concat(" ");
        String currentFirstDT = DateUtil.getFirstDayOfMonthByMonthYear(monthCalendar, Integer.parseInt(year));
        String yearFull = DateUtil.getYearThaiFormat(new Date(currentFirstDT));
        return monthFull.concat(yearFull);
    }

    public static String getShiftFullMonthYearThai(int monthCalendar, int year) throws Exception {
        String currentFirstDT = DateUtil.getFirstDayOfMonthByMonthYear(monthCalendar, year);
        Date shiftMonth = DateUtil.parse(DateUtil.shiftMonthDownStartFirstMonth(currentFirstDT));
        int dailyMonth = DateUtil.getMonth(shiftMonth);

        String monthFull = DateUtil.getThaiMonthFull(dailyMonth).concat(" ");
        String yearFull = DateUtil.getYearThaiFormat(shiftMonth);
        return monthFull.concat(yearFull);
    }

    public static String getLastDateOfLastMonth() throws Exception {
        Date lastDate = DateUtil.getLastDateOfLastMonth(new Date());
        int date = DateUtil.getDayOfMonth(lastDate);
        int month = DateUtil.getMonth(lastDate);

        String monthFull = DateUtil.getThaiMonthFull(month).concat(" ");
        String yearFull = DateUtil.getYearThaiFormat(lastDate);
        return String.valueOf(date).concat(" ").concat(monthFull.concat(yearFull));
    }
   public static TabDateReportVO getDataTabDaily(Date currentDate) throws Exception {
        TabDateReportVO dailyTabVo = new TabDateReportVO();
            int dailyMonth = DateUtil.getMonth(currentDate);
            int dailyYear = DateUtil.getYear(currentDate);
            dailyTabVo.setMonth(dailyMonth);
            dailyTabVo.setYear(dailyYear);
            dailyTabVo.setDate(currentDate);
            dailyTabVo.setMonthDTThaiShort(getNameMonthYearThai(dailyMonth, currentDate));
        return dailyTabVo;
    }
    /* NOTE : 
     * java.util.Calendar
     * JANUARY = 0  , FEBRUARY = 1  , MARCH = 2      ,  APRIL = 3   , MAY = 4       , JUNE = 5 
     * JULY =  6    , AUGUST = 7    , SEPTEMBER = 8  ,  OCTOBER = 9 , NOVEMBER = 10 , DECEMBER = 11 
     */
      public static List<TabDateReportVO> getTab(Date currentDate) throws Exception {
        List<TabDateReportVO> tabVoList = new ArrayList<TabDateReportVO>();
            for (int i = 1; i <= 12; i++) {
                Date dataDateShift = DateUtil.shiftMonthDown(currentDate, i);
                int dailyMonth = DateUtil.getMonth(dataDateShift);
                int dailyYear = DateUtil.getYear(dataDateShift);
                TabDateReportVO dailyTabVo = new TabDateReportVO();
                dailyTabVo.setMonth(dailyMonth);
                dailyTabVo.setYear(dailyYear);
                dailyTabVo.setDate(currentDate);
                dailyTabVo.setMonthDTThaiShort(getNameMonthYearThai(dailyMonth, dataDateShift));
                tabVoList.add(dailyTabVo);
            }
        return tabVoList;
    }
      
      public static String getFullDateThai(Date date) throws Exception {
        String fullDateThai = "";
        if(date != null){
            int day = DateUtil.getDayOfMonth(date);
            String month = DateUtil.getThaiMonthFull(DateUtil.getMonth(date));
            String year = DateUtil.getYearThaiFormat(date);
            fullDateThai = day + " " + month + " " + year;
        }
        
        return fullDateThai;
    }
}
