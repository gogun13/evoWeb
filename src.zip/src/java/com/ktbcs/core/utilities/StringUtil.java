/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.utilities;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.web.util.HtmlUtils;

/**
 *
 * @author Administrator
 */
public class StringUtil {

    public static final String DEFAULT_CURRENCY_FORMAT = "###,###,##0.00";
    public static final String SIMPLE_DOUBLE = "0.00";
    public static final String INTEGER_FORMAT = "#,##0";
    public static final String BLANK = "";
    public static final String COMMA_SINGLE_QUOTE = ",'";
    public static final String COMMA = ",";
    public static final String SEMICOLON = ";";
    public static final String SINGLE_QUOTE = "'";
    public static final String TWO_SINGLE_QUOTE = "''";
    public static final String SHARP = "#";

    public static boolean isEmpty(String str) {
        return str == null || str.trim().length() == 0;
    }

    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    public static boolean isBlank(String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean isNotBlank(String str) {
        return !isBlank(str);
    }

    public static String formatCurrentcy(String format, BigDecimal currency) {
        NumberFormat df = new DecimalFormat(format);
        String formatStr = df.format(currency);
        return formatStr;
    }

    public static String formatCurrentcy(BigDecimal currency) {
        return formatCurrentcy(DEFAULT_CURRENCY_FORMAT, currency);
    }

    public static int removeNumberCommas(String numberWithComma) {
        if (isEmpty(numberWithComma)) {
            return 0;
        }
        if (numberWithComma != null && numberWithComma.indexOf(',') > 0) {
            return Integer.parseInt(numberWithComma.replace(",", ""));
        }
        return Integer.parseInt(numberWithComma.trim());
    }

    public static String notNull(String testStr) {
        return testStr == null ? BLANK : testStr;
    }

    public static String toString(Object obj) {
        return ToStringBuilder.reflectionToString(obj);
    }

    public static String removeStartWithZero(String text) {

        String result = text.replaceFirst("^0*", "");
        System.out.println("result: " + result);
        return result;
    }

    public static String replaceBackSlash(String source) {
        String newText = source.replaceAll("\\\\", "\\\\\\\\");
        return newText;
    }

    public static String htmlEscape(String source) {
        String newText = HtmlUtils.htmlEscape(source);
        return newText;
    }

    public static String htmlUnescape(String source) {
        String newText = HtmlUtils.htmlUnescape(source);
        return newText;
    }

    /**
     * *
     * Replace /xxx/ with replace string
     *
     * @param text ex., text= "select /a,b,c/ from orders ";
     * @param replaceWith ex., "1"
     * @return newSql = "select 1 from orders" if match else just return orginal
     * text sql
     */
    public static final String REGEX = "(/.+?/)";

    public static String replaceSql(String text, String replaceWith) {
        Pattern p = Pattern.compile(REGEX);
        Matcher m = p.matcher(text);
        boolean found = m.find();
        if (found) {
            return m.replaceAll(replaceWith);
        } else {
            return text;
        }
    }

    public static void main(String[] args) {
        String aa = "SELECT * FROM TBL_CUSTOMER WHERE CIF = '35004668'; ";
        String statementSelect = "SELECT";
        String statementInsert = "INSERT";
        String statementUpdate = "UPDATE";
        String statementDelete = "DELETE";
        
        System.out.println("aa1:" + aa.toUpperCase().indexOf(statementSelect));
        System.out.println("aa1:" + aa.toUpperCase().indexOf(statementInsert));
        System.out.println("aa1:" + aa.toUpperCase().indexOf(statementUpdate));
        System.out.println("aa1:" + aa.toUpperCase().indexOf(statementDelete));
         System.out.println("aa1 matches :" + aa.toUpperCase().matches(statementSelect));
 //String aa = "UPDATE TBL_CUSTOMER SET  UPDATED_BY = 'EWSL BATCH'  WHERE CIF = '35004668'; ";
    //     String aa = "1&2&3";
    //     String[] aa1 = aa.split("&",-1);
         
//        System.out.println("aa1:" + aa1.length);
//        for(String data :aa1 ){
//         System.out.println("data" + data);
//        }
       // String key = "108093_สำนักงานธุรกิจพัฒนาการ";
       //  String[] keyArr = key.split("_",-1);
       //  System.out.println("keyArr:" + keyArr.length);
       // printColumnNameCase();
//        printGenPrepareStatement();
//        printGetResultSetToVo();
//        BigDecimal bd = new BigDecimal(0.3434);
//        System.out.println("bd.toString: " + bd.doubleValue());
//        System.out.println("bd.toString: " + bd.toPlainString());
//        String num = formatCurrentcy("0.00", bd);
//        System.out.println("number: " + num);
//        StringBuilder sb = new StringBuilder();
//        sb.append("select /a,b,c/  from orders  ");
//        sb.append("select /d, e, f/ from separare ");
//        sb.append("select /a, b, ");
//        sb.append("c/ from tab ");
//        sb.append("select /*/ from table1 ");
//        sb.append("select ${b} from table2 ");
//        String result = replaceSql(sb.toString(), "1");
//        System.out.println("result:" + result);
//		Map map = new HashMap();
//		map.put("a", "a,b,c");
//		map.put("b", "d,e,f");
//		StrSubstitutor sub = new StrSubstitutor(map);
//		String x = sub.replace(sb);
//		System.out.println("x:" +x.toString());
//        List<String> data = new ArrayList<String>();
//        data.add("BCM");
////        data.add("AO");
////        data.add("AE");
//        String test = genSqlInStr(data);
//        System.out.println("test:" +test);
    }

    private static void printColumnNameCase() throws Exception{
        try {
            List allLine = FileUtils.readLines(new File("d:/TableColumns.txt"));
            for (int i = 0; i < allLine.size(); i++) {
                String line = (String) allLine.get(i);
                String[] words = StringUtils.splitByWholeSeparator(line, "\t");//{"OTHER_ID", "VARCHAR2(20 BYTE)"}
                String rawCap = WordUtils.capitalizeFully(words[0], new char[]{'_'});
                String result = StringUtils.replace(rawCap, "_", "");
                result = StringUtils.uncapitalize(result);
                System.out.println("private "+ convertToPrimitive(convertDBType2JavaType(words[1]))+" " + result + ";");
            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex);
        }
    }
    
    /**
     * *
     * Gen prepare statement 
     * ex., 
     * Column name APP_ID -> ps.setString(1, customer.getAppId());
     */
    private static void printGenPrepareStatement() throws Exception{
        try {
            List allLine = FileUtils.readLines(new File("d:/TableColumns.txt"));
            for (int i = 0; i < allLine.size(); i++) {
                String line = (String) allLine.get(i);
                String[] words = StringUtils.splitByWholeSeparator(line, "\t");//{"OTHER_ID", "VARCHAR2(20 BYTE)"}
                String rawCap = WordUtils.capitalizeFully(words[0], new char[]{'_'});
                String columnName = StringUtils.replace(rawCap, "_", "");
//                result = StringUtils.uncapitalize(result);
                String dataType = words[1];
                if(dataType.startsWith("DATE")){
                    System.out.println("ps.set"+convertDBType2JavaType(words[1])+"(i++, DateUtil.toSqlDate(item.get"+ columnName +"())); ");
                }else if(dataType.startsWith("TIMESTAMP")){
                    System.out.println("ps.set"+convertDBType2JavaType(words[1])+"(i++, DateUtil.toTimeStamp(item.get"+ columnName +"())); ");
                }else{
                    System.out.println("ps.set"+convertDBType2JavaType(words[1])+"(i++, item.get"+ columnName +"()); ");
                }
            
                
            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex);
        }
    }
    
    /**
     * *
     * Gen prepare statement 
     * ex., Column name APP_ID -> item.setAppId(rs.getString("APP_ID"));
     * 
     */
    //Becase at Excise project, Database is set as A.D. but set locale as Thai that conflict itself
    public static boolean isExcisePrj = true; //just maker to identify is Excise project
    private static void printGetResultSetToVo() throws Exception{
        try {
            List allLine = FileUtils.readLines(new File("d:/TableColumns.txt"));
            for (int i = 0; i < allLine.size(); i++) {
                String line = (String) allLine.get(i);
                String[] words = StringUtils.splitByWholeSeparator(line, "\t");//{"OTHER_ID", "VARCHAR2(20 BYTE)"}
                String rawCap = WordUtils.capitalizeFully(words[0], new char[]{'_'});
                String columnName = StringUtils.replace(rawCap, "_", "");
//                result = StringUtils.uncapitalize(result);
                String dbType = convertDBType2JavaType(words[1]);
                if(isExcisePrj && "Date".equalsIgnoreCase(dbType)){
                    System.out.println("item.set"+columnName+"(DateUtil.toDate(rs.get"+dbType+"(\""+words[0]+"\", Calendar.getInstance(Locale.US))));");  //print -> item.setAppId(rs.getString("APP_ID"));
                }else {
                    System.out.println("item.set"+columnName+"(rs.get"+dbType+"(\""+words[0]+"\"));");  //print -> item.setAppId(rs.getString("APP_ID"));
                }
                
            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex);
        }
    }
    
    private static String convertDBType2JavaType(String dbDataType) throws Exception{
//        System.out.println("type : " +dbDataType);
        if (isEmpty(dbDataType)) {
            throw new Exception("Invalide dbDataType parameter : " + dbDataType);
        }

        if (dbDataType.startsWith("VARCHAR") || dbDataType.startsWith("VARCHAR2") || dbDataType.startsWith("CHAR")) {
            return "String";
        } else if (dbDataType.startsWith("DATE") || dbDataType.startsWith("TIMESTAMP")) {
            return "Date";
        } else if (dbDataType.startsWith("NUMBER") || dbDataType.endsWith("INT")) {
            //that can be ex, NUMBER(12,2) or NUMBER(12,0)
            if (StringUtils.contains(dbDataType, ",")) {
                
                int openIdx = StringUtils.indexOf(dbDataType, "(");
                int closeIdx = StringUtils.indexOf(dbDataType, ")");
                String numVal = StringUtils.substring(dbDataType, openIdx+1, closeIdx);
//                System.out.println("numval: " + numVal);
                //vals[0] = number size
                //vals[1] = precision size
                String[] vals = StringUtils.splitByWholeSeparator(numVal, ",");
//                System.out.println("val[0]: "+vals[0] +", val[1]:" +vals[1]);
                if (Integer.parseInt(vals[1]) > 0) {
                    return "BigDecimal";
                } else if (Integer.parseInt(vals[0]) > 10) {
                    return "Long";
                } else {
                    return "Int";
                }
            // don't have comma , so can be Int or Long, ex., NUMBER(1) , NUMBER(12)   
            } else {
//                System.out.println("dbDataType : "+ dbDataType);
                if(!StringUtils.contains(dbDataType, "(")){
                    return "Int";
                }
                int openIdx = StringUtils.indexOf(dbDataType, "(");
                int closeIdx = StringUtils.indexOf(dbDataType, ")");
                String numVal = StringUtils.substring(dbDataType, openIdx+1, closeIdx);
                if (Integer.parseInt(numVal) > 10) {
                    return "Long";
                } else {
                    return "Int";
                }
            }
            

        }

        return null;
    }
    
    private static String convertToPrimitive(String objectType){
        if("BigDecimal".equals(objectType)){
            return "BigDecimal";
        }else if("Long".equals(objectType)) {
            return "long";
        }else if("Int".equals(objectType)) {
            return "int";
        } else {
            return objectType;
        }
    }

    public static boolean isValidCitizenId(String inputCitizenId) {

        String stringCitizenId = new String(inputCitizenId);
        System.out.println("stringCitizenId :: " + stringCitizenId);
        if (stringCitizenId == null || stringCitizenId.length() == 0
                || stringCitizenId == "") {
            return false;
        }

        int[] i_mul = new int[]{
            13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2};
        String gid = stringCitizenId;
        int l_strlen = stringCitizenId.length();
        int i_weight, i_dummy, r_chkmod, s_dummy, i_lastdigit;
        int i_sum = 0;

        /*
         * if (isNaN(gid)) { return false;
        }
         */
        System.out.println("pass :step--->1");
        if (l_strlen == 0) {
            return false;
        }
        if (l_strlen != 13) {
            return false;
        }
        System.out.println("pass :step--->2");

        s_dummy = gid.charAt(12) - '0';
        System.out.println("last digit :: " + s_dummy);
        i_lastdigit = s_dummy;
        for (int i = 0; i <= 11; i++) {
            s_dummy = gid.charAt(i) - '0';
            i_dummy = s_dummy;
            i_weight = i_dummy * i_mul[i];
            i_sum = i_sum + i_weight;
        }

        i_sum = i_sum % 11;
        r_chkmod = i_sum;

        int i_chkdigit;
        if (r_chkmod == 0) {
            i_chkdigit = 1;
        } else if (r_chkmod == 1) {
            i_chkdigit = 0;
        } else {
            i_chkdigit = 11 - r_chkmod;
        }
        System.out.println("cal :: " + i_chkdigit);
        System.out.println("pass :step--->3");
        if (i_chkdigit == i_lastdigit) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isValidEmail(String email) {

        //Set the email pattern string
        Pattern p = Pattern.compile(".+@.+\\.[a-z]+");

        //Match the given string with the pattern
        Matcher m = p.matcher(email);

        //check whether match is found
        boolean matchFound = m.matches();

        return matchFound;
    }

    public static String Unicode2ASCII(String unicode) {
        StringBuffer ascii = new StringBuffer(unicode);
        int code;
        for (int i = 0; i < unicode.length(); i++) {
            code = (int) unicode.charAt(i);
            if ((0xE01 <= code) && (code <= 0xE5B)) {
                ascii.setCharAt(i, (char) (code - 0xD60));
            }
        }
        return ascii.toString();
    }

    public static String ASCII2Unicode(String ascii) {
        StringBuffer unicode = new StringBuffer(ascii);
        int code;
        for (int i = 0; i < ascii.length(); i++) {
            code = (int) ascii.charAt(i);
            if ((0xA1 <= code) && (code <= 0xFB)) {
                unicode.setCharAt(i, (char) (code + 0xD60));
            }
        }
        return unicode.toString();
    }

    /**
     * *
     *
     * @param List of Id if listOfId = [a,b,c] convert to => 'a','b','c' if
     * listOfId = null convert to => ''
     * @return
     */
    public static String genSqlInStr(List listOfId) {
        StringBuilder allKey = new StringBuilder();
        for (int i = 0; i < listOfId.size(); i++) {
            if (i == 0) {
                allKey.append(SINGLE_QUOTE).append(listOfId.get(i)).append(SINGLE_QUOTE);
            } else {
                allKey.append(COMMA_SINGLE_QUOTE).append(listOfId.get(i)).append(SINGLE_QUOTE);
            }
        }
        if (isEmpty(allKey.toString())) {
            allKey.append(TWO_SINGLE_QUOTE); //Set empty in sql as ''
        }
        return allKey.toString();
    }

    public static String Left(String text, int length) {
        if (text != null) {
            return text.substring(0, text.length() >= length ? length : text.length());
        } else {
            return null;
        }
    }

    public static String Right(String text, int length) {
        if (text != null) {
            return text.substring(text.length() - (text.length() >= length ? length : text.length()), text.length());
        } else {
            return null;
        }

    }

    public static String Mid(String text, int start, int end) {
        if (text != null) {
            return text.substring(start, end);
        } else {
            return null;
        }

    }

    public static String Mid(String text, int start) {
        if (text != null) {
            return text.substring(start, text.length() - start);
        } else {
            return null;
        }

    }

    public static String changeEnStrFormatToTHDate(String input) {
        //20080612 --> 12/06/2551
        if (input != null && input.length() > 0) {
            String year = input.substring(0, 4);
            String month = input.substring(4, 6);
            String day = input.substring(6, input.length());
            year = String.valueOf(Integer.parseInt(year) + 543);
            input = day + "/" + month + "/" + year;
        } else {
            input = "";
        }
        return input;
    }
   
     public static void traceObject(Object sourceObj) {
        try {
            Method idMethods[] = sourceObj.getClass().getMethods();
            for (int j = 0; j < idMethods.length; j++) {
                try {
                    Method idMethod = idMethods[j];
                    if (idMethod.getName().startsWith("get") && !"getClass".equals(idMethod.getName())) {
                        System.out.println(sourceObj.getClass().getName()+" "+idMethod.getName() + " = " + idMethod.invoke(sourceObj));
                    }
                } catch (Exception e) {
                }
            }
        } catch (Exception ex) {
            //
        }
    }
    
    public static String getValue(String str) {
        String result = null;
        if(str != null){
           result = str.trim();
        }
        return result;
    }
   public static String replace(String source, String pattern, String replace) {
		if (source != null) {
			final int len = pattern.length();
			StringBuffer sb = new StringBuffer();
			int found = -1;
			int start = 0;

			while ((found = source.indexOf(pattern, start)) != -1) {
				sb.append(source.substring(start, found));
				sb.append(replace);
				start = found + len;
			}

			sb.append(source.substring(start));

			return sb.toString();
		} else {
			return "";
		}
	}
   
       
    public static String nullToStr(Object obj){
        
        return obj==null?"":obj.toString().trim();
        
    }
    
    public static int paresInt(Object obj){
        
        int ret = 0;
        
        try{
            return obj==null?0:Integer.parseInt(obj.toString());
        }catch(Exception e){
            ret = 0;
            e.printStackTrace();
        }
        return ret;
    }
}
