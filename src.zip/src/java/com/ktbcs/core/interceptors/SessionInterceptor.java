/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.interceptors;

import com.ktbcs.core.exceptions.SessionException;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import java.util.Map;

/**
 *
 * @author Tum_Surapong
 */
public class SessionInterceptor extends AbstractInterceptor {

    @Override
    public String intercept(ActionInvocation ai) throws Exception {

        Map<String, Object> session = ai.getInvocationContext().getSession();
        
        if (session.isEmpty()) {
            System.out.println("No Session");
            session.put("NOSESSION", "Y");
            throw new SessionException("No session");
//            return ""; // session is empty/expired
        }
        session.remove("NOSESSION");
        return ai.invoke();
    }
}
