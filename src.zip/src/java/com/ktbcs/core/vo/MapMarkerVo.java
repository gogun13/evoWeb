/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class MapMarkerVo {
    private String id;
    private String latitude;
    private String longtitude;
    private String address;
    private String description;
    private String makerTypeId;
    private String makerTypeIcon;
    private boolean bounds;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the latitude
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longtitude
     */
    public String getLongtitude() {
        return longtitude;
    }

    /**
     * @param longtitude the longtitude to set
     */
    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the makerTypeId
     */
    public String getMakerTypeId() {
        return makerTypeId;
    }

    /**
     * @param makerTypeId the makerTypeId to set
     */
    public void setMakerTypeId(String makerTypeId) {
        this.makerTypeId = makerTypeId;
    }

    /**
     * @return the makerTypeIcon
     */
    public String getMakerTypeIcon() {
        return makerTypeIcon;
    }

    /**
     * @param makerTypeIcon the makerTypeIcon to set
     */
    public void setMakerTypeIcon(String makerTypeIcon) {
        this.makerTypeIcon = makerTypeIcon;
    }

    /**
     * @return the bounds
     */
    public boolean isBounds() {
        return bounds;
    }

    /**
     * @param bounds the bounds to set
     */
    public void setBounds(boolean bounds) {
        this.bounds = bounds;
    }
    
    
}
