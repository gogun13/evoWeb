/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class UMAuthorizationInfoObj {

    private String divisionCode;
    private String divisionName;
    private String jobCode;
    private String jobDesc;
    private String ktbFieldMapCode;
    private String ktbFieldMapDesc;
    private String regionCode;
    private String regionName;
    private String responseUnitCode;
    private String responseUnitName;
    private String responseUnitType;
    private String roleDesc;
    private String roleId;
    private String sectionCode;
    private String sectionName;
    private String seqId;

    private String deptCode;
    private String deptName;
    private String deptPhone;

    /**
     * @return the divisionCode
     */
    public String getDivisionCode() {
        return divisionCode;
    }

    /**
     * @param divisionCode the divisionCode to set
     */
    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    /**
     * @return the divisionName
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     * @param divisionName the divisionName to set
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    /**
     * @return the jobCode
     */
    public String getJobCode() {
        return jobCode;
    }

    /**
     * @param jobCode the jobCode to set
     */
    public void setJobCode(String jobCode) {
        this.jobCode = jobCode;
    }

    /**
     * @return the jobDesc
     */
    public String getJobDesc() {
        return jobDesc;
    }

    /**
     * @param jobDesc the jobDesc to set
     */
    public void setJobDesc(String jobDesc) {
        this.jobDesc = jobDesc;
    }

    /**
     * @return the ktbFieldMapCode
     */
    public String getKtbFieldMapCode() {
        return ktbFieldMapCode;
    }

    /**
     * @param ktbFieldMapCode the ktbFieldMapCode to set
     */
    public void setKtbFieldMapCode(String ktbFieldMapCode) {
        this.ktbFieldMapCode = ktbFieldMapCode;
    }

    /**
     * @return the ktbFieldMapDesc
     */
    public String getKtbFieldMapDesc() {
        return ktbFieldMapDesc;
    }

    /**
     * @param ktbFieldMapDesc the ktbFieldMapDesc to set
     */
    public void setKtbFieldMapDesc(String ktbFieldMapDesc) {
        this.ktbFieldMapDesc = ktbFieldMapDesc;
    }

    /**
     * @return the regionCode
     */
    public String getRegionCode() {
        return regionCode;
    }

    /**
     * @param regionCode the regionCode to set
     */
    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    /**
     * @return the regionName
     */
    public String getRegionName() {
        return regionName;
    }

    /**
     * @param regionName the regionName to set
     */
    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    /**
     * @return the responseUnitCode
     */
    public String getResponseUnitCode() {
        return responseUnitCode;
    }

    /**
     * @param responseUnitCode the responseUnitCode to set
     */
    public void setResponseUnitCode(String responseUnitCode) {
        this.responseUnitCode = responseUnitCode;
    }

    /**
     * @return the responseUnitName
     */
    public String getResponseUnitName() {
        return responseUnitName;
    }

    /**
     * @param responseUnitName the responseUnitName to set
     */
    public void setResponseUnitName(String responseUnitName) {
        this.responseUnitName = responseUnitName;
    }

    /**
     * @return the responseUnitType
     */
    public String getResponseUnitType() {
        return responseUnitType;
    }

    /**
     * @param responseUnitType the responseUnitType to set
     */
    public void setResponseUnitType(String responseUnitType) {
        this.responseUnitType = responseUnitType;
    }

    /**
     * @return the roleDesc
     */
    public String getRoleDesc() {
        return roleDesc;
    }

    /**
     * @param roleDesc the roleDesc to set
     */
    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    /**
     * @return the roleId
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * @param roleId the roleId to set
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    /**
     * @return the sectionCode
     */
    public String getSectionCode() {
        return sectionCode;
    }

    /**
     * @param sectionCode the sectionCode to set
     */
    public void setSectionCode(String sectionCode) {
        this.sectionCode = sectionCode;
    }

    /**
     * @return the sectionName
     */
    public String getSectionName() {
        return sectionName;
    }

    /**
     * @param sectionName the sectionName to set
     */
    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    /**
     * @return the seqId
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * @param seqId the seqId to set
     */
    public void setSeqId(String seqId) {
        this.seqId = seqId;
    }

    /**
     * @return the deptCode
     */
    public String getDeptCode() {
        return deptCode;
    }

    /**
     * @param deptCode the deptCode to set
     */
    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the deptPhone
     */
    public String getDeptPhone() {
        return deptPhone;
    }

    /**
     * @param deptPhone the deptPhone to set
     */
    public void setDeptPhone(String deptPhone) {
        this.deptPhone = deptPhone;
    }
}
