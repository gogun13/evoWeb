/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class IMLNConfig {

    private String system;
    private String ecmhost;
    private String ecmport;
    private String ecmusername;
    private String ecmpassword;
    private String ecmdocbase;

    /**
     * @return the system
     */
    public String getSystem() {
        return system;
    }

    /**
     * @param system the system to set
     */
    public void setSystem(String system) {
        this.system = system;
    }

    /**
     * @return the ecmhost
     */
    public String getEcmhost() {
        return ecmhost;
    }

    /**
     * @param ecmhost the ecmhost to set
     */
    public void setEcmhost(String ecmhost) {
        this.ecmhost = ecmhost;
    }

    /**
     * @return the ecmport
     */
    public String getEcmport() {
        return ecmport;
    }

    /**
     * @param ecmport the ecmport to set
     */
    public void setEcmport(String ecmport) {
        this.ecmport = ecmport;
    }

    /**
     * @return the ecmusername
     */
    public String getEcmusername() {
        return ecmusername;
    }

    /**
     * @param ecmusername the ecmusername to set
     */
    public void setEcmusername(String ecmusername) {
        this.ecmusername = ecmusername;
    }

    /**
     * @return the ecmpassword
     */
    public String getEcmpassword() {
        return ecmpassword;
    }

    /**
     * @param ecmpassword the ecmpassword to set
     */
    public void setEcmpassword(String ecmpassword) {
        this.ecmpassword = ecmpassword;
    }

    /**
     * @return the ecmdocbase
     */
    public String getEcmdocbase() {
        return ecmdocbase;
    }

    /**
     * @param ecmdocbase the ecmdocbase to set
     */
    public void setEcmdocbase(String ecmdocbase) {
        this.ecmdocbase = ecmdocbase;
    }
}
