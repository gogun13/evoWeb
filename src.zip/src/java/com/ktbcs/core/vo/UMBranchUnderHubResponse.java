/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.util.ArrayList;

/**
 *
 * @author aon
 */
public class UMBranchUnderHubResponse extends UMBaseResponse {

    private ArrayList<UMBranchInfoObj> branchInfoObjList;

    /**
     * @return the branchInfoObjList
     */
    public ArrayList<UMBranchInfoObj> getBranchInfoObjList() {
        return branchInfoObjList;
    }

    /**
     * @param branchInfoObjList the branchInfoObjList to set
     */
    public void setBranchInfoObjList(ArrayList<UMBranchInfoObj> branchInfoObjList) {
        this.branchInfoObjList = branchInfoObjList;
    }
}
