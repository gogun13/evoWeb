/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.util.ArrayList;

/**
 *
 * @author aon
 */
public class UMUserDetailResponse extends UMBaseResponse {

    private String empId;
    private String empMail;
    private String empNameEng;
    private String empNameThai;
    private String empSurnameEng;
    private String empSurnameThai;
    private String titleNameEng;
    private String titleNameThai;
    private String jobCode;
    private String jobDesc;
    private String ktbFieldMapCode;
    private String ktbFieldMapDesc;
    private String responseUnitCode;
    private String responseUnitName;
    private String responseUnitType;
    private String seqId;
    private String typeDesc;
    private ArrayList<UMAuthorizationInfoObj> umAuthorizationInfoObjList;
    private int numAuthorize;

    private boolean selected;
    /**
     * @return the empId
     */
    public String getEmpId() {
        return empId;
    }

    /**
     * @param empId the empId to set
     */
    public void setEmpId(String empId) {
        this.empId = empId;
    }

    /**
     * @return the empMail
     */
    public String getEmpMail() {
        return empMail;
    }

    /**
     * @param empMail the empMail to set
     */
    public void setEmpMail(String empMail) {
        this.empMail = empMail;
    }

    /**
     * @return the empNameEng
     */
    public String getEmpNameEng() {
        return empNameEng;
    }

    /**
     * @param empNameEng the empNameEng to set
     */
    public void setEmpNameEng(String empNameEng) {
        this.empNameEng = empNameEng;
    }

    /**
     * @return the empNameThai
     */
    public String getEmpNameThai() {
        return empNameThai;
    }

    /**
     * @param empNameThai the empNameThai to set
     */
    public void setEmpNameThai(String empNameThai) {
        this.empNameThai = empNameThai;
    }

    /**
     * @return the empSurnameEng
     */
    public String getEmpSurnameEng() {
        return empSurnameEng;
    }

    /**
     * @param empSurnameEng the empSurnameEng to set
     */
    public void setEmpSurnameEng(String empSurnameEng) {
        this.empSurnameEng = empSurnameEng;
    }

    /**
     * @return the empSurnameThai
     */
    public String getEmpSurnameThai() {
        return empSurnameThai;
    }

    /**
     * @param empSurnameThai the empSurnameThai to set
     */
    public void setEmpSurnameThai(String empSurnameThai) {
        this.empSurnameThai = empSurnameThai;
    }

    /**
     * @return the titleNameEng
     */
    public String getTitleNameEng() {
        return titleNameEng;
    }

    /**
     * @param titleNameEng the titleNameEng to set
     */
    public void setTitleNameEng(String titleNameEng) {
        this.titleNameEng = titleNameEng;
    }

    /**
     * @return the titleNameThai
     */
    public String getTitleNameThai() {
        return titleNameThai;
    }

    /**
     * @param titleNameThai the titleNameThai to set
     */
    public void setTitleNameThai(String titleNameThai) {
        this.titleNameThai = titleNameThai;
    }

    /**
     * @return the umAuthorizationInfoObjList
     */
    public ArrayList<UMAuthorizationInfoObj> getUmAuthorizationInfoObjList() {
        return umAuthorizationInfoObjList;
    }

    /**
     * @param umAuthorizationInfoObjList the umAuthorizationInfoObjList to set
     */
    public void setUmAuthorizationInfoObjList(ArrayList<UMAuthorizationInfoObj> umAuthorizationInfoObjList) {
        this.numAuthorize = umAuthorizationInfoObjList!=null?umAuthorizationInfoObjList.size():0;
        this.umAuthorizationInfoObjList = umAuthorizationInfoObjList;
    }

    /**
     * @return the jobCode
     */
    public String getJobCode() {
        return jobCode;
    }

    /**
     * @param jobCode the jobCode to set
     */
    public void setJobCode(String jobCode) {
        this.jobCode = jobCode;
    }

    /**
     * @return the jobDesc
     */
    public String getJobDesc() {
        return jobDesc;
    }

    /**
     * @param jobDesc the jobDesc to set
     */
    public void setJobDesc(String jobDesc) {
        this.jobDesc = jobDesc;
    }

    /**
     * @return the ktbFieldMapCode
     */
    public String getKtbFieldMapCode() {
        return ktbFieldMapCode;
    }

    /**
     * @param ktbFieldMapCode the ktbFieldMapCode to set
     */
    public void setKtbFieldMapCode(String ktbFieldMapCode) {
        this.ktbFieldMapCode = ktbFieldMapCode;
    }

    /**
     * @return the ktbFieldMapDesc
     */
    public String getKtbFieldMapDesc() {
        return ktbFieldMapDesc;
    }

    /**
     * @param ktbFieldMapDesc the ktbFieldMapDesc to set
     */
    public void setKtbFieldMapDesc(String ktbFieldMapDesc) {
        this.ktbFieldMapDesc = ktbFieldMapDesc;
    }

    /**
     * @return the responseUnitCode
     */
    public String getResponseUnitCode() {
        return responseUnitCode;
    }

    /**
     * @param responseUnitCode the responseUnitCode to set
     */
    public void setResponseUnitCode(String responseUnitCode) {
        this.responseUnitCode = responseUnitCode;
    }

    /**
     * @return the responseUnitName
     */
    public String getResponseUnitName() {
        return responseUnitName;
    }

    /**
     * @param responseUnitName the responseUnitName to set
     */
    public void setResponseUnitName(String responseUnitName) {
        this.responseUnitName = responseUnitName;
    }

    /**
     * @return the seqId
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * @param seqId the seqId to set
     */
    public void setSeqId(String seqId) {
        this.seqId = seqId;
    }

    /**
     * @return the typeDesc
     */
    public String getTypeDesc() {
        return typeDesc;
    }

    /**
     * @param typeDesc the typeDesc to set
     */
    public void setTypeDesc(String typeDesc) {
        this.typeDesc = typeDesc;
    }

    /**
     * @return the selected
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * @param selected the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * @return the responseUnitType
     */
    public String getResponseUnitType() {
        return responseUnitType;
    }

    /**
     * @param responseUnitType the responseUnitType to set
     */
    public void setResponseUnitType(String responseUnitType) {
        this.responseUnitType = responseUnitType;
    }

    /**
     * @return the numAuthorize
     */
    public int getNumAuthorize() {
        return numAuthorize;
    }

    /**
     * @param numAuthorize the numAuthorize to set
     */
    public void setNumAuthorize(int numAuthorize) {
        this.numAuthorize = numAuthorize;
    }
}
