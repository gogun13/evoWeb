/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.util.Vector;

/**
 *
 * @author KTBDevLoan
 */
public class SpecialAdminVo {
    
    private Vector headerList;
    private Vector headerTypeList;
    private Vector dataList;
    private String message;

    public Vector getHeaderList() {
        return headerList;
    }

    public void setHeaderList(Vector headerList) {
        this.headerList = headerList;
    }

    public Vector getHeaderTypeList() {
        return headerTypeList;
    }

    public void setHeaderTypeList(Vector headerTypeList) {
        this.headerTypeList = headerTypeList;
    }

    public Vector getDataList() {
        return dataList;
    }

    public void setDataList(Vector dataList) {
        this.dataList = dataList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
