/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class UMBranchInfoObj {
    private java.lang.String branchCode;

    private java.lang.String branchName;

    /**
     * @return the branchCode
     */
    public java.lang.String getBranchCode() {
        return branchCode;
    }

    /**
     * @param branchCode the branchCode to set
     */
    public void setBranchCode(java.lang.String branchCode) {
        this.branchCode = branchCode;
    }

    /**
     * @return the branchName
     */
    public java.lang.String getBranchName() {
        return branchName;
    }

    /**
     * @param branchName the branchName to set
     */
    public void setBranchName(java.lang.String branchName) {
        this.branchName = branchName;
    }

}
