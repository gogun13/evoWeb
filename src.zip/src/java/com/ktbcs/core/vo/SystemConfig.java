/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

import java.math.BigDecimal;

/**
 *
 * @author aon
 */
public class SystemConfig extends BaseVo {
    private String configId;
    private String configDesc;
    private String value1;
    private String value2;
    private Integer value3;
    private BigDecimal value4;
    private java.util.Date value5;

    /**
     * @return the configId
     */
    public String getConfigId() {
        return configId;
    }

    /**
     * @param configId the configId to set
     */
    public void setConfigId(String configId) {
        this.configId = configId;
    }

    /**
     * @return the configDesc
     */
    public String getConfigDesc() {
        return configDesc;
    }

    /**
     * @param configDesc the configDesc to set
     */
    public void setConfigDesc(String configDesc) {
        this.configDesc = configDesc;
    }

    /**
     * @return the value1
     */
    public String getValue1() {
        return value1;
    }

    /**
     * @param value1 the value1 to set
     */
    public void setValue1(String value1) {
        this.value1 = value1;
    }

    /**
     * @return the value2
     */
    public String getValue2() {
        return value2;
    }

    /**
     * @param value2 the value2 to set
     */
    public void setValue2(String value2) {
        this.value2 = value2;
    }

    /**
     * @return the value3
     */
    public Integer getValue3() {
        return value3;
    }

    /**
     * @param value3 the value3 to set
     */
    public void setValue3(Integer value3) {
        this.value3 = value3;
    }

    /**
     * @return the value4
     */
    public BigDecimal getValue4() {
        return value4;
    }

    /**
     * @param value4 the value4 to set
     */
    public void setValue4(BigDecimal value4) {
        this.value4 = value4;
    }

    /**
     * @return the value5
     */
    public java.util.Date getValue5() {
        return value5;
    }

    /**
     * @param value5 the value5 to set
     */
    public void setValue5(java.util.Date value5) {
        this.value5 = value5;
    }
}
