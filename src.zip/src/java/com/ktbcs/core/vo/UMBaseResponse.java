/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class UMBaseResponse {
    private java.lang.String responseCode;

    private java.lang.String responseDate;

    private java.lang.String responseDesc;

    private java.lang.String responseTime;

    /**
     * @return the responseCode
     */
    public java.lang.String getResponseCode() {
        return responseCode;
    }

    /**
     * @param responseCode the responseCode to set
     */
    public void setResponseCode(java.lang.String responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * @return the responseDate
     */
    public java.lang.String getResponseDate() {
        return responseDate;
    }

    /**
     * @param responseDate the responseDate to set
     */
    public void setResponseDate(java.lang.String responseDate) {
        this.responseDate = responseDate;
    }

    /**
     * @return the responseDesc
     */
    public java.lang.String getResponseDesc() {
        return responseDesc;
    }

    /**
     * @param responseDesc the responseDesc to set
     */
    public void setResponseDesc(java.lang.String responseDesc) {
        this.responseDesc = responseDesc;
    }

    /**
     * @return the responseTime
     */
    public java.lang.String getResponseTime() {
        return responseTime;
    }

    /**
     * @param responseTime the responseTime to set
     */
    public void setResponseTime(java.lang.String responseTime) {
        this.responseTime = responseTime;
    }
}
