/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

import java.io.Serializable;

/**
 *
 * @author Administrator
 */
public class UMEmpInfoObj implements Serializable{

     private String empId;
     private String titleNameThai;
     private String empNameThai;
     private String empSurnameThai;
     private String titleNameEng;
     private String empNameEng;
     private String empSurnameEng;
     private String empMail;
     private String employedStatus;

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getEmpMail() {
        return empMail;
    }

    public void setEmpMail(String empMail) {
        this.empMail = empMail;
    }

    public String getEmpNameEng() {
        return empNameEng;
    }

    public void setEmpNameEng(String empNameEng) {
        this.empNameEng = empNameEng;
    }

    public String getEmpNameThai() {
        return empNameThai;
    }

    public void setEmpNameThai(String empNameThai) {
        this.empNameThai = empNameThai;
    }

    public String getEmpSurnameEng() {
        return empSurnameEng;
    }

    public void setEmpSurnameEng(String empSurnameEng) {
        this.empSurnameEng = empSurnameEng;
    }

    public String getEmpSurnameThai() {
        return empSurnameThai;
    }

    public void setEmpSurnameThai(String empSurnameThai) {
        this.empSurnameThai = empSurnameThai;
    }

    public String getEmployedStatus() {
        return employedStatus;
    }

    public void setEmployedStatus(String employedStatus) {
        this.employedStatus = employedStatus;
    }

    public String getTitleNameEng() {
        return titleNameEng;
    }

    public void setTitleNameEng(String titleNameEng) {
        this.titleNameEng = titleNameEng;
    }

    public String getTitleNameThai() {
        return titleNameThai;
    }

    public void setTitleNameThai(String titleNameThai) {
        this.titleNameThai = titleNameThai;
    }


     

}
