/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author KTBDevLoan
 */
public class ReportExcelObject {

    public static final int MAX_HEADER_ROW = 3;
    public static final int MAX_HEADER_COL = 100;
    public static final int GRAPH_TYPE_LINE = 1;
    public static final int GRAPH_TYPE_BAR = 1;
    public static final int GRAPH_TYPE_PIE = 1;
    private HeaderExcel[][] headerList = null;
    private ArrayList<ItemObject> listData = null;
    private ArrayList<String[]> rowValue = null;
    private String[] columnValue;
    private String exportFileName;
    private String sheetName;
    private String headerName;
    private String headerName2;
    private String totalName;
    private String totalName2;
    private boolean showTotal = false;
    private boolean showAverage = false;
    private byte[] imageGraph;
    public int MAX_DATA_COL = 0;
    private int graphType = 0;
    private int numDay;
    private int numDay1;
    private int numDay2;
    private int compareTextNum = 0;
    private static final Logger logger = Logger.getLogger(ReportExcelObject.class);
    private boolean isShowSummary;
    private int[] summaryColumn;
    private ArrayList summaryTotal;
    

    public boolean isIsShowSummary() {
        return isShowSummary;
    }

    public void setIsShowSummary(boolean isShowSummary) {
        this.isShowSummary = isShowSummary;
    }

    public int[] getSummaryColumn() {
        return summaryColumn;
    }

    public void setSummaryColumn(int[] summaryColumn) {
        this.summaryColumn = summaryColumn;
    }

    public ArrayList getSummaryTotal() {
        return summaryTotal;
    }

    public void setSummaryTotal(ArrayList summaryTotal) {
        this.summaryTotal = summaryTotal;
    }
    

    public ReportExcelObject() {
        headerList = new HeaderExcel[MAX_HEADER_ROW][MAX_HEADER_COL];
        listData = new ArrayList<ItemObject>();
        rowValue = new ArrayList<String[]>();
    }

    public ArrayList<ItemObject> getListData() {
        return listData;
    }

    public void setListData(ArrayList<ItemObject> listData) {
        this.listData = listData;
    }

    public void setListDataObject(ArrayList<Object> listData, String... columnName) throws NoSuchFieldException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException {
        columnValue = columnName;
        if (listData != null) {

            Field valueField;
            Object[] listObject = listData.toArray();
            Field[] allFields, valueFields;

            if (listObject.length > 0) {
                Object itemTemp = listObject[0];
                Class clsTemp = itemTemp.getClass();
                allFields = clsTemp.getDeclaredFields();
                ArrayList<Field> arlField = new ArrayList<Field>();
                int k = 0;
                for (int j = 0; j < allFields.length; j++) {
                    for (int n = 0; n < columnName.length; n++) {
                        if (allFields[j].getName().equals(columnName[n])) {
                            arlField.add(allFields[j]);
                            k++;
                            break;
                        }
                    }
                }
                valueFields = new Field[arlField.size()];
                k = 0;
                for (Field fl : arlField) {
                    valueFields[k] = fl;
                    k++;
                }

                for (int i = 0; i < listObject.length; i++) {
                    ItemObject itemObject = new ItemObject();
                    HashMap<String, Object> addItem = new HashMap<String, Object>();
                    Object item = listObject[i];
                    for (int j = 0; j < valueFields.length; j++) {
                        valueField = valueFields[j];
                        valueField.setAccessible(true);

                        addItem.put(valueField.getName(), (Object) valueField.get(item));
                    }
                    itemObject.setDataExcel(addItem);
                    this.getListData().add(itemObject);
                }
            }
        }
    }

    public void setListDataObject(ArrayList<Object> listData) throws NoSuchFieldException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException {

        if (listData != null) {

            Field valueField;
            Object[] listObject = listData.toArray();
            Field[] valueFields;

            if (listObject.length > 0) {
                Object itemTemp = listObject[0];
                Class clsTemp = itemTemp.getClass();
                valueFields = clsTemp.getDeclaredFields();

                for (int i = 0; i < listObject.length; i++) {
                    ItemObject itemObject = new ItemObject();
                    HashMap<String, Object> addItem = new HashMap<String, Object>();
                    Object item = listObject[i];
                    for (int j = 0; j < valueFields.length; j++) {
                        valueField = valueFields[j];
                        valueField.setAccessible(true);

                        addItem.put(valueField.getName(), (Object) valueField.get(item));
                    }
                    itemObject.setDataExcel(addItem);
                    this.getListData().add(itemObject);
                }
            }
        }
    }

    public void setListDataObject(List<HashMap<String, Object>> listData) throws NoSuchFieldException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException {
        if (listData != null) {
            if (listData.size() > 0) {
                ItemObject itemObject = null;
                for (int i = 0; i < listData.size(); i++) {
                    itemObject = new ItemObject();
                    itemObject.setDataExcel(listData.get(i));
                    this.getListData().add(itemObject);
                }
            }
        }
    }

    public ArrayList<HeaderArea> getListHeaderArea() {

        return getListHeaderArea(MAX_HEADER_ROW, MAX_HEADER_COL);
    }

    public ArrayList<HeaderArea> getListHeaderArea(int maxRow, int maxCol) {

        ArrayList<HeaderArea> headerAreaList = new ArrayList<HeaderArea>();
        int startX = 0;
        int startY = 0;
        int endX = 0;
        int endY = 0;
        for (int i = 0; i < maxRow; i++) {
            for (int j = 0; j < maxCol; j++) {
                if (headerList[i][j] != null && !headerList[i][j].getColName().equals("")) {
                    startX = j;
                    startY = i;
                    endX = maxCol - 1;
                    endY = maxRow - 1;
                    
                    for (int m = j + 1; m < maxCol; m++) {
                        boolean inBoundX = false;
                        for (HeaderArea item : headerAreaList) {
                            if (item.startX >= m && item.endX <= m) {
                                inBoundX = true;
                                endX = m - 1;
                                break;
                            }
                        }
                        if (!inBoundX) {
                            if (headerList[i][m] != null && (!headerList[i][m].getColName().equals("") || m == maxCol)) {
                                endX = m - 1;
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int n = i + 1; n < maxRow; n++) {

                        boolean inBoundY = false;
                        for (HeaderArea item : headerAreaList) {
                            if (item.startY >= n && item.endY <= n) {
                                inBoundY = true;
                                endY = n - 1;
                                break;
                            }
                        }
                        if (!inBoundY) {
                            if (headerList[n][j] != null && (!headerList[n][j].getColName().equals("") || n == maxRow)) {
                                endY = n - 1;
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                    if (startX != endX || startY != endY) {
                        HeaderArea item = new HeaderArea(startX, startY, endX, endY);
                        headerAreaList.add(item);
                    }
                }
            }
        }
        return headerAreaList;
    }

    public String getTotalName() {
        return totalName;
    }

    public void setTotalName(String totalName) {
        this.totalName = totalName;
    }

    public boolean isShowTotal() {
        return showTotal;
    }

    public void setShowTotal(boolean showTotal) {
        this.showTotal = showTotal;
    }

    public String getTotalName2() {
        return totalName2;
    }

    public void setTotalName2(String totalName2) {
        this.totalName2 = totalName2;
    }

    public String getHeaderName2() {
        return headerName2;
    }

    public void setHeaderName2(String headerName2) {
        this.headerName2 = headerName2;
    }

    public int getGraphType() {
        return graphType;
    }

    public void setGraphType(int graphType) {
        this.graphType = graphType;
    }

    public boolean isShowAverage() {
        return showAverage;
    }

    public void setShowAverage(boolean showAverage) {
        this.showAverage = showAverage;
    }

    public int getNumDay() {
        return numDay;
    }

    public void setNumDay(int numDay) {
        this.numDay = numDay;
    }

    public int getNumDay1() {
        return numDay1;
    }

    public void setNumDay1(int numDay1) {
        this.numDay1 = numDay1;
    }

    public int getNumDay2() {
        return numDay2;
    }

    public void setNumDay2(int numDay2) {
        this.numDay2 = numDay2;
    }

    public ArrayList<String[]> getRowValue() {
        return rowValue;
    }

    public void setRowValue(ArrayList<String[]> rowValue) {
        this.rowValue = rowValue;
    }

    public String[] getColumnValue() {
        return columnValue;
    }

    public void setColumnValue(String[] columnValue) {
        this.columnValue = columnValue;
    }

    public int getCompareTextNum() {
        return compareTextNum;
    }

    public void setCompareTextNum(int compareTextNum) {
        this.compareTextNum = compareTextNum;
    }

    /**
     * @return the sheetName
     */
    public String getSheetName() {
        return sheetName;
    }

    /**
     * @param sheetName the sheetName to set
     */
    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public HeaderExcel[][] getHeaderList() {
        return headerList;
    }

    public void setHeaderList(HeaderExcel[][] headerList) {
        this.headerList = headerList;
    }

    public void setHeaderList(int row, int col, String headerName, int colWidth) {
        if (row < MAX_HEADER_ROW && col < MAX_HEADER_COL) {
            if (this.headerList[row][col] == null) {
                this.headerList[row][col] = new HeaderExcel();
            }
            this.headerList[row][col].setColName(headerName != null ? headerName : "");
            if (colWidth > 0) {
                this.headerList[row][col].setChrWidth(colWidth);
            }
        }

        if (col > MAX_DATA_COL) {
            MAX_DATA_COL = col;
        }
    }

    public String getExportFileName() {
        return exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    public String getHeaderName() {
        return headerName;
    }

    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    public byte[] getImageGraph() {
        return imageGraph;
    }

    public void setImageGraph(byte[] imageGraph) {
        this.imageGraph = imageGraph;
    }
    
    public static class ItemObject {

        private HashMap<String, Object> dataExcel;

        public HashMap<String, Object> getDataExcel() {
            return dataExcel;
        }

        public void setDataExcel(HashMap<String, Object> dataExcel) {
            this.dataExcel = dataExcel;
        }
    }
}
