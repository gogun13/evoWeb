/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

/**
 *
 * @author kanate
 */
public class HeaderArea {

    public int startX;
    public int startY;
    public int endX;
    public int endY;

    public HeaderArea() {
    }

    public HeaderArea(int startX, int startY, int endX, int endY) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
    }
}
