/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class UMEmpNameByEmpIdResponse extends UMBaseResponse{

     private List<UMEmpInfoObj> empInfoObjList  = new ArrayList<UMEmpInfoObj>();

    public List<UMEmpInfoObj> getEmpInfoObjList() {
        return empInfoObjList;
    }

    public void setEmpInfoObjList(List<UMEmpInfoObj> empInfoObjList) {
        this.empInfoObjList = empInfoObjList;
    }

}
