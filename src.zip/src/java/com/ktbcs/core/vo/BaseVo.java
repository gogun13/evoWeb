/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.ToStringBuilder;

public class BaseVo implements Serializable {
    private String createdBy;
    private String createdIp;
    private java.util.Date createdDate;
    private java.sql.Timestamp createdDateTs;
    private String updatedBy;
    private String updatedIp;
    private java.util.Date updatedDate;
    private java.sql.Timestamp updatedDateTs;
    
    private String createdName;
    private String updatedName;

    private boolean withWarning;
    private String warningMessage;
    private java.util.Date endDate;
    private String createdDateStr;
    private String updatedDateStr;
    private String endDateStr;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    /**
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return the createdIp
     */
    public String getCreatedIp() {
        return createdIp;
    }

    /**
     * @param createdIp the createdIp to set
     */
    public void setCreatedIp(String createdIp) {
        this.createdIp = createdIp;
    }

    /**
     * @return the createdDate
     */
    public java.util.Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(java.util.Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the updatedIp
     */
    public String getUpdatedIp() {
        return updatedIp;
    }

    /**
     * @param updatedIp the updatedIp to set
     */
    public void setUpdatedIp(String updatedIp) {
        this.updatedIp = updatedIp;
    }

    /**
     * @return the updatedDate
     */
    public java.util.Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(java.util.Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the createdDateTs
     */
    public java.sql.Timestamp getCreatedDateTs() {
        return createdDateTs;
    }

    /**
     * @param createdDateTs the createdDateTs to set
     */
    public void setCreatedDateTs(java.sql.Timestamp createdDateTs) {
        this.createdDateTs = createdDateTs;
    }

    /**
     * @return the updatedDateTs
     */
    public java.sql.Timestamp getUpdatedDateTs() {
        return updatedDateTs;
    }

    /**
     * @param updatedDateTs the updatedDateTs to set
     */
    public void setUpdatedDateTs(java.sql.Timestamp updatedDateTs) {
        this.updatedDateTs = updatedDateTs;
    }

    /**
     * @return the createdName
     */
    public String getCreatedName() {
        return createdName;
    }

    /**
     * @param createdName the createdName to set
     */
    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    /**
     * @return the updatedName
     */
    public String getUpdatedName() {
        return updatedName;
    }

    /**
     * @param updatedName the updatedName to set
     */
    public void setUpdatedName(String updatedName) {
        this.updatedName = updatedName;
    }

    /**
     * @return the withWarning
     */
    public boolean isWithWarning() {
        return withWarning;
    }

    /**
     * @param withWarning the withWarning to set
     */
    public void setWithWarning(boolean withWarning) {
        this.withWarning = withWarning;
    }

    /**
     * @return the warningMessage
     */
    public String getWarningMessage() {
        return warningMessage;
    }

    /**
     * @param warningMessage the warningMessage to set
     */
    public void setWarningMessage(String warningMessage) {
        this.warningMessage = warningMessage;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getCreatedDateStr() {
        return createdDateStr;
    }

    public void setCreatedDateStr(String createdDateStr) {
        this.createdDateStr = createdDateStr;
    }

    public String getUpdatedDateStr() {
        return updatedDateStr;
    }

    public void setUpdatedDateStr(String updatedDateStr) {
        this.updatedDateStr = updatedDateStr;
    }

    public String getEndDateStr() {
        return endDateStr;
    }

    public void setEndDateStr(String endDateStr) {
        this.endDateStr = endDateStr;
    }
}
