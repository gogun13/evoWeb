/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

import java.util.ArrayList;

/**
 *
 * @author aon
 */
public class UMUserForRoleByBranchResponse extends UMBaseResponse {
    private ArrayList<UMUserInfobyBranchObj> userInfobyBranchObjList;

    /**
     * @return the userInfobyBranchObjList
     */
    public ArrayList<UMUserInfobyBranchObj> getUserInfobyBranchObjList() {
        return userInfobyBranchObjList;
    }

    /**
     * @param userInfobyBranchObjList the userInfobyBranchObjList to set
     */
    public void setUserInfobyBranchObjList(ArrayList<UMUserInfobyBranchObj> userInfobyBranchObjList) {
        this.userInfobyBranchObjList = userInfobyBranchObjList;
    }


}
