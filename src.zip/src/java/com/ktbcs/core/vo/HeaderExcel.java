/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import static com.ktbcs.core.vo.HeaderExcel.DEFAULT_COL_WIDTH;

/**
 *
 * @author kanate
 */
public class HeaderExcel {

    public static final int DEFAULT_COL_WIDTH = 10;
    private String colName;
    private int chrWidth;

    public HeaderExcel() {
        this.colName = "";
        this.chrWidth = DEFAULT_COL_WIDTH;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }

    public int getChrWidth() {
        return chrWidth;
    }

    public void setChrWidth(int chrWidth) {
        this.chrWidth = chrWidth;
    }
}
