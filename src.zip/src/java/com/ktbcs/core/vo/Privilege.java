package com.ktbcs.core.vo;

import java.util.*;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

/**
 *
 * @author Por
 */
public class Privilege  extends BaseVo {
    /** type of privilege **/
    private String type;
    /** workflow step e.g. add register, approval **/
    private String step;
    /** role of a user e.g. manager, bank operator **/
    private String userClass;
    /** step decision **/
    private boolean stepDecision;
    
    /** logger **/
//    private static Log logger = LogFactory.getLog(Privilege.class);
    
    /** name and action_name pair **/
    private Hashtable action_list;

    /** setters, getters **/
    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUserClass() {
        return userClass;
    }

    public void setUserClass(String userClass) {
        this.userClass = userClass;
    }

    public boolean isStepDecision() {
        return stepDecision;
    }

    public void setStepDecision(boolean stepDecision) {
        this.stepDecision = stepDecision;
    }

    /**
     * constructor with no parameter
     */
    public Privilege() {
        //initialization
        reset();
    }

    /**
     * If userClass is known
     * @param userClass
     */
    public Privilege(String userClass) {
        reset();
        System.out.println("type "+type);
        this.setUserClass(userClass);
    }

    /**
     * for clearing all the variables
     */
    public void reset() {
        action_list = null;
        step = "";
        type = "";
        userClass = "";

    }

    /**
     * This function returns action associated with the parameter name
     * PRE: String name: reference name, menu id
     * POST: this function returns destination action. If it doens't exist return null.
     * @param name
     * @return
     */
    public String getActionFromName(String name) {
        if (name != null || name.equals("")) {
            return (String) (action_list.get(name));
        } else {
            return null;
        }
    }

    /**
     * 
     * @return user + step
     */
    @Override
    public String toString(){
        return "user="+getUserClass()+",step="+getStep();
    }
}
