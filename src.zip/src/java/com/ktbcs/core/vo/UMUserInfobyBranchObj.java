/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class UMUserInfobyBranchObj extends UMBaseResponse {

    private java.lang.String empId;
    private java.lang.String empMail;
    private java.lang.String empNameEng;
    private java.lang.String empNameThai;
    private java.lang.String empSurnameEng;
    private java.lang.String empSurnameThai;
    private java.lang.String jobCode;
    private java.lang.String jobDesc;
    private java.lang.String ktbFieldMapCode;
    private java.lang.String ktbFieldMapDesc;
    private java.lang.String responseUnitCode;
    private java.lang.String responseUnitName;
    private java.lang.String seqId;
    private java.lang.String titleNameEng;
    private java.lang.String titleNameThai;

    /**
     * @return the empId
     */
    public java.lang.String getEmpId() {
        return empId;
    }

    /**
     * @param empId the empId to set
     */
    public void setEmpId(java.lang.String empId) {
        this.empId = empId;
    }

    /**
     * @return the empMail
     */
    public java.lang.String getEmpMail() {
        return empMail;
    }

    /**
     * @param empMail the empMail to set
     */
    public void setEmpMail(java.lang.String empMail) {
        this.empMail = empMail;
    }

    /**
     * @return the empNameEng
     */
    public java.lang.String getEmpNameEng() {
        return empNameEng;
    }

    /**
     * @param empNameEng the empNameEng to set
     */
    public void setEmpNameEng(java.lang.String empNameEng) {
        this.empNameEng = empNameEng;
    }

    /**
     * @return the empNameThai
     */
    public java.lang.String getEmpNameThai() {
        return empNameThai;
    }

    /**
     * @param empNameThai the empNameThai to set
     */
    public void setEmpNameThai(java.lang.String empNameThai) {
        this.empNameThai = empNameThai;
    }

    /**
     * @return the empSurnameEng
     */
    public java.lang.String getEmpSurnameEng() {
        return empSurnameEng;
    }

    /**
     * @param empSurnameEng the empSurnameEng to set
     */
    public void setEmpSurnameEng(java.lang.String empSurnameEng) {
        this.empSurnameEng = empSurnameEng;
    }

    /**
     * @return the empSurnameThai
     */
    public java.lang.String getEmpSurnameThai() {
        return empSurnameThai;
    }

    /**
     * @param empSurnameThai the empSurnameThai to set
     */
    public void setEmpSurnameThai(java.lang.String empSurnameThai) {
        this.empSurnameThai = empSurnameThai;
    }

    /**
     * @return the jobCode
     */
    public java.lang.String getJobCode() {
        return jobCode;
    }

    /**
     * @param jobCode the jobCode to set
     */
    public void setJobCode(java.lang.String jobCode) {
        this.jobCode = jobCode;
    }

    /**
     * @return the jobDesc
     */
    public java.lang.String getJobDesc() {
        return jobDesc;
    }

    /**
     * @param jobDesc the jobDesc to set
     */
    public void setJobDesc(java.lang.String jobDesc) {
        this.jobDesc = jobDesc;
    }

    /**
     * @return the ktbFieldMapCode
     */
    public java.lang.String getKtbFieldMapCode() {
        return ktbFieldMapCode;
    }

    /**
     * @param ktbFieldMapCode the ktbFieldMapCode to set
     */
    public void setKtbFieldMapCode(java.lang.String ktbFieldMapCode) {
        this.ktbFieldMapCode = ktbFieldMapCode;
    }

    /**
     * @return the ktbFieldMapDesc
     */
    public java.lang.String getKtbFieldMapDesc() {
        return ktbFieldMapDesc;
    }

    /**
     * @param ktbFieldMapDesc the ktbFieldMapDesc to set
     */
    public void setKtbFieldMapDesc(java.lang.String ktbFieldMapDesc) {
        this.ktbFieldMapDesc = ktbFieldMapDesc;
    }

    /**
     * @return the responseUnitCode
     */
    public java.lang.String getResponseUnitCode() {
        return responseUnitCode;
    }

    /**
     * @param responseUnitCode the responseUnitCode to set
     */
    public void setResponseUnitCode(java.lang.String responseUnitCode) {
        this.responseUnitCode = responseUnitCode;
    }

    /**
     * @return the responseUnitName
     */
    public java.lang.String getResponseUnitName() {
        return responseUnitName;
    }

    /**
     * @param responseUnitName the responseUnitName to set
     */
    public void setResponseUnitName(java.lang.String responseUnitName) {
        this.responseUnitName = responseUnitName;
    }

    /**
     * @return the seqId
     */
    public java.lang.String getSeqId() {
        return seqId;
    }

    /**
     * @param seqId the seqId to set
     */
    public void setSeqId(java.lang.String seqId) {
        this.seqId = seqId;
    }

    /**
     * @return the titleNameEng
     */
    public java.lang.String getTitleNameEng() {
        return titleNameEng;
    }

    /**
     * @param titleNameEng the titleNameEng to set
     */
    public void setTitleNameEng(java.lang.String titleNameEng) {
        this.titleNameEng = titleNameEng;
    }

    /**
     * @return the titleNameThai
     */
    public java.lang.String getTitleNameThai() {
        return titleNameThai;
    }

    /**
     * @param titleNameThai the titleNameThai to set
     */
    public void setTitleNameThai(java.lang.String titleNameThai) {
        this.titleNameThai = titleNameThai;
    }
}
