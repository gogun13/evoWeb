package com.ktbcs.core.vo;
//import org.apache.commons.logging.LogFactory;

import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import com.ktb.ewsl.vo.MtDepartmentVo;
import com.ktb.ewsl.vo.MtUserTeamRoleVo;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author New
 */
public class UserData extends BaseVo {

    /** logger **/
//    private static Log logger = LogFactory.getLog(UserData.class);
    /** properties **/
    protected String name;
    /** givenName **/
    protected String lastName;
    /** sn **/
    protected String userClass;
    protected String email;
    /** mail **/
    protected String cn;
    protected String company;
    protected String description;
    protected String department;
    protected String countryCode;
    protected String displayName;
    protected String givenName;
    protected String initials;
    protected String sAMAccountName;
    protected String title;
    protected String[] memberOf;
    protected Privilege priv;
    protected String genCbsCc;
    protected String genCbsAo;
    protected String genCbsRespUnit;
    protected String genCbsBoo;
    /* modified by tum */
    protected String empNo;
    protected String titleNameThai;
    protected String empNameThai;
    protected String empSurnameThai;
    protected String empPosition;
    protected String deptCode;
    protected String deptName;
    protected String ktbFieldMap;
    protected String isNana;
    protected int hasMoreUserRule;
    protected String[] userClassArr;
    private ArrayList<Authorize> authorizeList = new ArrayList<Authorize>();
    private int authorizeIndex = 0;
    private String bpmToken;
    private Authorize authorize;
    private String previousMenuId;
    private String currentMenuId;
    private String nextMenuId;
    private String topTabMenuId;
    private ArrayList<MenuLevelVo> menuLevelList;
    private String userPhone;
    private String currentMenuGroup;
    private ArrayList<MenuInfoVo> menuHist;
    private int currentMenuIndex = 0;
    private MenuInfoVo backPage;
    private String checkCode;
    private String passCode;
    private String adminToken;

    private String remoteIp;
    private String roleId;

    private ArrayList<MtDepartmentVo> departmentList;
    private ArrayList<MtUserTeamRoleVo> teamRoleList;

    private boolean authOverride;
    private String overrideUser;
    private String overridePassword;
    private String overrideRemark;

    private String costCenter;
    private String costCenterDesc;
    private String respUnit;
    private String respUnitDesc;
    private boolean roleAdmin;
    private String sessionId;
    
    private String fullName;
    private Integer histId;
    
    //----- EWS SME
    private String roleName;
    private String businessUnitCode;  // สายงาน
    private String groupCode;  // กลุ่มงาน
    private String departmentCode; //หน่วยงาน
    private String currentId;
    private String userIP;


    public void clearOverride(){
        this.authOverride = false;
        this.overrideUser = null;
        this.overridePassword = null;
    }

    public UserData() {
        authorize = new Authorize();
        menuHist = new ArrayList<MenuInfoVo>();
    }

    public UserData(String sysEmpNo,String sysRemoteIp) {
        empNo = sysEmpNo;
        remoteIp = sysRemoteIp;
        authorize = new Authorize();
        menuHist = new ArrayList<MenuInfoVo>();
    }

    public void addMenuHist(MenuInfoVo link) {
        if (getCurrentMenuIndex() >= 10) {
            setCurrentMenuIndex(0);
        }

        if (menuHist.size() < getCurrentMenuIndex() + 1) {
            menuHist.add(link);
        } else {
            menuHist.set(getCurrentMenuIndex(), link);
        }
        setCurrentMenuIndex(getCurrentMenuIndex() + 1);
    }

    public MenuInfoVo getHistMenuInfo() {
        MenuInfoVo histMenu = null;
        if (getCurrentMenuIndex() > 0 && getCurrentMenuIndex() < menuHist.size()) {
            histMenu = menuHist.get(getCurrentMenuIndex() - 1);
        }

        return histMenu;
    }

    public void saveBackPage() {
        try {
            int backIndex = 0;
            if (currentMenuIndex - 2 < 0) {
                backIndex = (currentMenuIndex + 10) - 2;
            } else {
                backIndex = currentMenuIndex - 2;
            }

            backPage = menuHist.get(backIndex).clone();
        } catch (Exception e) {
            backPage = null;
        }
    }

    /**
     * @return the authorizeList
     */
    public ArrayList<Authorize> getAuthorizeList() {
        return authorizeList;
    }

    /**
     * @param authorizeList the authorizeList to set
     */
    public void setAuthorizeList(ArrayList<Authorize> authorizeList) {
        this.authorizeList = authorizeList;
    }

    /**
     * @return the authorizeIndex
     */
    public int getAuthorizeIndex() {
        return authorizeIndex;
    }

    /**
     * @param authorizeIndex the authorizeIndex to set
     */
    public void setAuthorizeIndex(int authorizeIndex) {
        this.authorizeIndex = authorizeIndex;
    }

    /**
     * @return the bpmToken
     */
    public String getBpmToken() {
        return bpmToken;
    }

    /**
     * @param bpmToken the bpmToken to set
     */
    public void setBpmToken(String bpmToken) {
        this.bpmToken = bpmToken;
    }

    /**
     * @return the authorize
     */
    public Authorize getAuthorize() {
        return authorize;
    }

    /**
     * @param authorize the authorize to set
     */
    public void setAuthorize(Authorize authorize) {
        if (authorize != null && authorize.getDeptPhone() != null) {
            if (this.userPhone == null || "".equals(this.userPhone)) {
                this.userPhone = authorize.getDeptPhone();
            }
        }
        this.authorize = authorize;
    }

    /**
     * @return the currentMenuId
     */
    public String getCurrentMenuId() {
        return currentMenuId;
    }

    /**
     * @param currentMenuId the currentMenuId to set
     */
    public void setCurrentMenuId(String currentMenuId) {
        this.currentMenuId = currentMenuId;
    }

    /**
     * @return the menuLevelList
     */
    public ArrayList<MenuLevelVo> getMenuLevelList() {
        return menuLevelList;
    }

    /**
     * @param menuLevelList the menuLevelList to set
     */
    public void setMenuLevelList(ArrayList<MenuLevelVo> menuLevelList) {
        this.menuLevelList = menuLevelList;
    }

    /**
     * @return the previousMenuId
     */
    public String getPreviousMenuId() {
        return previousMenuId;
    }

    /**
     * @param previousMenuId the previousMenuId to set
     */
    public void setPreviousMenuId(String previousMenuId) {
        this.previousMenuId = previousMenuId;
    }

    /**
     * @return the nextMenuId
     */
    public String getNextMenuId() {
        return nextMenuId;
    }

    /**
     * @param nextMenuId the nextMenuId to set
     */
    public void setNextMenuId(String nextMenuId) {
        this.nextMenuId = nextMenuId;
    }

    /**
     * @return the userPhone
     */
    public String getUserPhone() {
        return userPhone;
    }

    /**
     * @param userPhone the userPhone to set
     */
    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    /**
     * @return the currentMenuGroup
     */
    public String getCurrentMenuGroup() {
        return currentMenuGroup;
    }

    /**
     * @param currentMenuGroup the currentMenuGroup to set
     */
    public void setCurrentMenuGroup(String currentMenuGroup) {
        this.currentMenuGroup = currentMenuGroup;
    }

    /**
     * @return the menuHist
     */
    public ArrayList<MenuInfoVo> getMenuHist() {
        return menuHist;
    }

    /**
     * @param menuHist the menuHist to set
     */
    public void setMenuHist(ArrayList<MenuInfoVo> menuHist) {
        this.menuHist = menuHist;
    }

    /**
     * @return the backPage
     */
    public MenuInfoVo getBackPage() {
        return backPage;
    }

    /**
     * @param backPage the backPage to set
     */
    public void setBackPage(MenuInfoVo backPage) {
        this.backPage = backPage;
    }

    /**
     * @return the currentMenuIndex
     */
    public int getCurrentMenuIndex() {
        return currentMenuIndex;
    }

    /**
     * @param currentMenuIndex the currentMenuIndex to set
     */
    public void setCurrentMenuIndex(int currentMenuIndex) {
        this.currentMenuIndex = currentMenuIndex;
    }

    /**
     * @return the checkCode
     */
    public String getCheckCode() {
        return checkCode;
    }

    /**
     * @param checkCode the checkCode to set
     */
    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    /**
     * @return the passCode
     */
    public String getPassCode() {
        return passCode;
    }

    /**
     * @param passCode the passCode to set
     */
    public void setPassCode(String passCode) {
        this.passCode = passCode;
    }

    /**
     * @return the adminToken
     */
    public String getAdminToken() {
        return adminToken;
    }

    /**
     * @param adminToken the adminToken to set
     */
    public void setAdminToken(String adminToken) {
        this.adminToken = adminToken;
    }

    /**
     * @return the topTabMenuId
     */
    public String getTopTabMenuId() {
        return topTabMenuId;
    }

    /**
     * @param topTabMenuId the topTabMenuId to set
     */
    public void setTopTabMenuId(String topTabMenuId) {
        this.topTabMenuId = topTabMenuId;
    }

    /**
     * @return the departmentList
     */
    public ArrayList<MtDepartmentVo> getDepartmentList() {
        return departmentList;
    }

    /**
     * @param departmentList the departmentList to set
     */
    public void setDepartmentList(ArrayList<MtDepartmentVo> departmentList) {
        this.departmentList = departmentList;
    }

    /**
     * @return the remoteIp
     */
    public String getRemoteIp() {
        return remoteIp;
    }

    /**
     * @param remoteIp the remoteIp to set
     */
    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    /**
     * @return the teamRoleList
     */
    public ArrayList<MtUserTeamRoleVo> getTeamRoleList() {
        return teamRoleList;
    }

    /**
     * @param teamRoleList the teamRoleList to set
     */
    public void setTeamRoleList(ArrayList<MtUserTeamRoleVo> teamRoleList) {
        this.teamRoleList = teamRoleList;
    }

    /**
     * @return the authOverride
     */
    public boolean isAuthOverride() {
        return authOverride;
    }

    /**
     * @param authOverride the authOverride to set
     */
    public void setAuthOverride(boolean authOverride) {
        this.authOverride = authOverride;
    }

    /**
     * @return the overrideUser
     */
    public String getOverrideUser() {
        return overrideUser;
    }

    /**
     * @param overrideUser the overrideUser to set
     */
    public void setOverrideUser(String overrideUser) {
        this.overrideUser = overrideUser;
    }

    /**
     * @return the overridePassword
     */
    public String getOverridePassword() {
        return overridePassword;
    }

    /**
     * @param overridePassword the overridePassword to set
     */
    public void setOverridePassword(String overridePassword) {
        this.overridePassword = overridePassword;
    }

    /**
     * @return the costCenter
     */
    public String getCostCenter() {
        return costCenter;
    }

    /**
     * @param costCenter the costCenter to set
     */
    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    /**
     * @return the costCenterDesc
     */
    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    /**
     * @param costCenterDesc the costCenterDesc to set
     */
    public void setCostCenterDesc(String costCenterDesc) {
        this.costCenterDesc = costCenterDesc;
    }

    /**
     * @return the respUnit
     */
    public String getRespUnit() {
        return respUnit;
    }

    /**
     * @param respUnit the respUnit to set
     */
    public void setRespUnit(String respUnit) {
        this.respUnit = respUnit;
    }

    /**
     * @return the respUnitDesc
     */
    public String getRespUnitDesc() {
        return respUnitDesc;
    }

    /**
     * @param respUnitDesc the respUnitDesc to set
     */
    public void setRespUnitDesc(String respUnitDesc) {
        this.respUnitDesc = respUnitDesc;
    }

    /**
     * @return the roleAdmin
     */
    public boolean isRoleAdmin() {
        return roleAdmin;
    }

    /**
     * @param roleAdmin the roleAdmin to set
     */
    public void setRoleAdmin(boolean roleAdmin) {
        this.roleAdmin = roleAdmin;
    }

    /**
     * @return the overrideRemark
     */
    public String getOverrideRemark() {
        return overrideRemark;
    }

    /**
     * @param overrideRemark the overrideRemark to set
     */
    public void setOverrideRemark(String overrideRemark) {
        this.overrideRemark = overrideRemark;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId the sessionId to set
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        StringBuilder full = new StringBuilder();
        full.append(titleNameThai!=null?titleNameThai:"");
        full.append(empNameThai!=null?empNameThai:"");
        full.append(" ");
        full.append(empSurnameThai!=null?empSurnameThai:"");
        fullName = full.toString();
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return the histId
     */
    public Integer getHistId() {
        return histId;
    }

    /**
     * @param histId the histId to set
     */
    public void setHistId(Integer histId) {
        this.histId = histId;
    }

    public static class Authorize implements Serializable {

        private String divisionCode;
        private String divisionName;
        private String jobCode;
        private String jobDesc;
        private String ktbFieldMapCode;
        private String ktbFieldMapDesc;
        private String regionCode;
        private String regionName;
        private String responseUnitCode;
        private String responseUnitName;
        private String responseUnitType;
        private String roleDesc;
        private String roleId;
        private String sectionCode;
        private String sectionName;
        private String seqId;
        private String deptCode;
        private String deptName;
        private String deptPhone;

        private String roleKey;

        /**
         * @return the divisionCode
         */
        public String getDivisionCode() {
            return divisionCode;
        }

        /**
         * @param divisionCode the divisionCode to set
         */
        public void setDivisionCode(String divisionCode) {
            this.divisionCode = divisionCode;
        }

        /**
         * @return the divisionName
         */
        public String getDivisionName() {
            return divisionName;
        }

        /**
         * @param divisionName the divisionName to set
         */
        public void setDivisionName(String divisionName) {
            this.divisionName = divisionName;
        }

        /**
         * @return the jobCode
         */
        public String getJobCode() {
            return jobCode;
        }

        /**
         * @param jobCode the jobCode to set
         */
        public void setJobCode(String jobCode) {
            this.jobCode = jobCode;
        }

        /**
         * @return the jobDesc
         */
        public String getJobDesc() {
            return jobDesc;
        }

        /**
         * @param jobDesc the jobDesc to set
         */
        public void setJobDesc(String jobDesc) {
            this.jobDesc = jobDesc;
        }

        /**
         * @return the ktbFieldMapCode
         */
        public String getKtbFieldMapCode() {
            return ktbFieldMapCode;
        }

        /**
         * @param ktbFieldMapCode the ktbFieldMapCode to set
         */
        public void setKtbFieldMapCode(String ktbFieldMapCode) {
            this.ktbFieldMapCode = ktbFieldMapCode;
        }

        /**
         * @return the ktbFieldMapDesc
         */
        public String getKtbFieldMapDesc() {
            return ktbFieldMapDesc;
        }

        /**
         * @param ktbFieldMapDesc the ktbFieldMapDesc to set
         */
        public void setKtbFieldMapDesc(String ktbFieldMapDesc) {
            this.ktbFieldMapDesc = ktbFieldMapDesc;
        }

        /**
         * @return the regionCode
         */
        public String getRegionCode() {
            return regionCode;
        }

        /**
         * @param regionCode the regionCode to set
         */
        public void setRegionCode(String regionCode) {
            this.regionCode = regionCode;
        }

        /**
         * @return the regionName
         */
        public String getRegionName() {
            return regionName;
        }

        /**
         * @param regionName the regionName to set
         */
        public void setRegionName(String regionName) {
            this.regionName = regionName;
        }

        /**
         * @return the responseUnitCode
         */
        public String getResponseUnitCode() {
            return responseUnitCode;
        }

        /**
         * @param responseUnitCode the responseUnitCode to set
         */
        public void setResponseUnitCode(String responseUnitCode) {
            this.responseUnitCode = responseUnitCode;
        }

        /**
         * @return the responseUnitName
         */
        public String getResponseUnitName() {
            return responseUnitName;
        }

        /**
         * @param responseUnitName the responseUnitName to set
         */
        public void setResponseUnitName(String responseUnitName) {
            this.responseUnitName = responseUnitName;
        }

        /**
         * @return the responseUnitType
         */
        public String getResponseUnitType() {
            return responseUnitType;
        }

        /**
         * @param responseUnitType the responseUnitType to set
         */
        public void setResponseUnitType(String responseUnitType) {
            this.responseUnitType = responseUnitType;
        }

        /**
         * @return the roleDesc
         */
        public String getRoleDesc() {
            return roleDesc;
        }

        /**
         * @param roleDesc the roleDesc to set
         */
        public void setRoleDesc(String roleDesc) {
            this.roleDesc = roleDesc;
        }

        /**
         * @return the roleId
         */
        public String getRoleId() {
            return roleId;
        }

        /**
         * @param roleId the roleId to set
         */
        public void setRoleId(String roleId) {
            this.roleId = roleId;
        }

        /**
         * @return the sectionCode
         */
        public String getSectionCode() {
            return sectionCode;
        }

        /**
         * @param sectionCode the sectionCode to set
         */
        public void setSectionCode(String sectionCode) {
            this.sectionCode = sectionCode;
        }

        /**
         * @return the sectionName
         */
        public String getSectionName() {
            return sectionName;
        }

        /**
         * @param sectionName the sectionName to set
         */
        public void setSectionName(String sectionName) {
            this.sectionName = sectionName;
        }

        /**
         * @return the seqId
         */
        public String getSeqId() {
            return seqId;
        }

        /**
         * @param seqId the seqId to set
         */
        public void setSeqId(String seqId) {
            this.seqId = seqId;
        }

        /**
         * @return the deptCode
         */
        public String getDeptCode() {
            return deptCode;
        }

        /**
         * @param deptCode the deptCode to set
         */
        public void setDeptCode(String deptCode) {
            this.deptCode = deptCode;
        }

        /**
         * @return the deptName
         */
        public String getDeptName() {
            return deptName;
        }

        /**
         * @param deptName the deptName to set
         */
        public void setDeptName(String deptName) {
            this.deptName = deptName;
        }

        /**
         * @return the deptPhone
         */
        public String getDeptPhone() {
            return deptPhone;
        }

        /**
         * @param deptPhone the deptPhone to set
         */
        public void setDeptPhone(String deptPhone) {
            this.deptPhone = deptPhone;
        }

        /**
         * @return the roleKey
         */
        public String getRoleKey() {
            roleKey = responseUnitCode.concat("-").concat(roleId);
            return roleKey;
        }

        /**
         * @param roleKey the roleKey to set
         */
        public void setRoleKey(String roleKey) {
            this.roleKey = roleKey;
        }
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setUserClassArr(String[] userClassArr) {
        this.userClassArr = userClassArr;
    }

    public String[] getUserClassArr() {
        return userClassArr;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public void setHasMoreUserRule(int hasMoreUserRule) {
        this.hasMoreUserRule = hasMoreUserRule;
    }

    public int getHasMoreUserRule() {
        return hasMoreUserRule;
    }

    public String getIsNana() {
        return isNana;
    }

    public void setIsNana(String isNana) {
        this.isNana = isNana;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getEmpNameThai() {
        return empNameThai;
    }

    public void setEmpNameThai(String empNameThai) {
        this.empNameThai = empNameThai;
    }

    public String getEmpPosition() {
        return empPosition;
    }

    public void setEmpPosition(String empPosition) {
        this.empPosition = empPosition;
    }

    public String getEmpSurnameThai() {
        return empSurnameThai;
    }

    public void setEmpSurnameThai(String empSurnameThai) {
        this.empSurnameThai = empSurnameThai;
    }

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public String getKtbFieldMap() {
        return ktbFieldMap;
    }

    public void setKtbFieldMap(String ktbFieldMap) {
        this.ktbFieldMap = ktbFieldMap;
    }

    public String getTitleNameThai() {
        return titleNameThai;
    }

    public void setTitleNameThai(String titleNameThai) {
        this.titleNameThai = titleNameThai;
    }

    public String getGenCbsAo() {
        return genCbsAo;
    }

    public void setGenCbsAo(String genCbsAo) {
        this.genCbsAo = genCbsAo;
    }

    public String getGenCbsBoo() {
        return genCbsBoo;
    }

    public void setGenCbsBoo(String genCbsBoo) {
        this.genCbsBoo = genCbsBoo;
    }

    public String getGenCbsCc() {
        return genCbsCc;
    }

    public void setGenCbsCc(String genCbsCc) {
        this.genCbsCc = genCbsCc;
    }

    public String getGenCbsRespUnit() {
        return genCbsRespUnit;
    }

    public void setGenCbsRespUnit(String genCbsRespUnit) {
        this.genCbsRespUnit = genCbsRespUnit;
    }

    /**
     * Creates a new instance of UserData
     * @param name
     * @param lastName
     * @param userClass
     * @param email
     */
    public void UserData(String name, String lastName, String userClass, String email) {
        this.name = name;
        this.lastName = lastName;
        this.userClass = userClass;
        this.email = email;
        this.priv = null;
    }

    public Privilege getPrivilegeObject() {
        return priv;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserClass() {
        return userClass;
    }

    public void setUserClass(String userClass) {
        this.userClass = userClass;
    }

    public String getCn() {
        return cn;
    }

    public void setCn(String cn) {
        this.cn = cn;
    }

    public String getCompany() {
        return company;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getInitials() {
        return initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String[] getMemberOf() {
        return memberOf;
    }

    public void setMemberOf(String[] memberOf) {
        this.memberOf = memberOf;
    }

    public Privilege getPriv() {
        return priv;
    }

    public void setPriv(Privilege priv) {
        this.priv = priv;
    }

    public String getSAMAccountName() {
        return sAMAccountName;
    }

    public void setSAMAccountName(String sAMAccountName) {
        this.sAMAccountName = sAMAccountName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * reset privilege
     */
    public void cleanUp() {
        /** Clean the Privilege Object **/
        if (priv != null) {
            priv.reset();
        }
    }

    /**
     * 
     * @return name+class
     */
    @Override
    public String toString() {
        return "name=" + getName() + ",class=" + getUserClass();
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getBusinessUnitCode() {
        return businessUnitCode;
    }

    public void setBusinessUnitCode(String businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getCurrentId() {
        return currentId;
    }

    public void setCurrentId(String currentId) {
        this.currentId = currentId;
    }

    public String getUserIP() {
        return userIP;
    }

    public void setUserIP(String userIP) {
        this.userIP = userIP;
    }
    
    
    
}
