/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktbcs.core.vo;

/**
 *
 * @author aon
 */
public class UMRequestHeader {
    private java.lang.String channelId;

    private java.lang.String refId;

    private java.lang.String requestDate;

    private java.lang.String requestTime;

    /**
     * @return the channelId
     */
    public java.lang.String getChannelId() {
        return channelId;
    }

    /**
     * @param channelId the channelId to set
     */
    public void setChannelId(java.lang.String channelId) {
        this.channelId = channelId;
    }

    /**
     * @return the refId
     */
    public java.lang.String getRefId() {
        return refId;
    }

    /**
     * @param refId the refId to set
     */
    public void setRefId(java.lang.String refId) {
        this.refId = refId;
    }

    /**
     * @return the requestDate
     */
    public java.lang.String getRequestDate() {
        return requestDate;
    }

    /**
     * @param requestDate the requestDate to set
     */
    public void setRequestDate(java.lang.String requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * @return the requestTime
     */
    public java.lang.String getRequestTime() {
        return requestTime;
    }

    /**
     * @param requestTime the requestTime to set
     */
    public void setRequestTime(java.lang.String requestTime) {
        this.requestTime = requestTime;
    }
}
