/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.util.Date;

/**
 *
 * @author aon
 */
public class SearchBean extends BaseVo {

    private String byId;
    private String byFirstName;
    private String byLastName;
    private String byName;
    private String byTypeId;
    private String fromDate;
    private String toDate;
    private String isMou;
    private String custBusFlg;
    private UserData user;
    private String byCizId;
    private String bySubTypeId;

    private String byMainTypeId;
    private String taskId;

    private String referenceNo;
    private String customerName;
    private String status;

    private boolean ecFlag;
    private boolean otherFlag;
    private String teamId;
    private String makerId;
    private String productType;
    private String overrideId;
    private String accNo;
    private String transTypeId;
    private String transTypeName;
    private String holderFlag;
    private String holderId;

    private String sortField;
    private String sortType;

    private java.util.Date fromUtilDate;
    private java.util.Date toUtilDate;

    private String teamName;
    private String transTypeDesc;
    private String statusDesc;
    
    /* Added by Watthikorn on 13-Nov-2013 */
    private String logValueNo;
    private String serviceName;
    private String className;
    private String tranTypeId;
    private String refNo;
    private String textSearch;
    
    private String costCenter;

    /* ---------- EWS-SME  ---------- */    
    private String cifNo;
    private String name;
    private String responseUnit;
    private String rmId;
    private String roleId;
    private int warningHeaderId;
    private String urlName;
    private String userDB;
    private String pwdDB;
    private String dbDriver;
    private String empNoCondition;
    private boolean crFillter;
    private boolean taFillter; 
    private String organizationGroup;
    private String aeName;
    private String rmName;
    private String responseUnitName;
    private String workLine; //สายงาน
    private String rmIdOrAeId;
    private String individualReportBreakBy;
    /* Phase 2.3 : Memory Search Criteria*/
    private String searchPageIndex;
     /* Phase 3.1.3 : Close Job Report*/
    private String fromDateCloseJobStr;
    private String toDateCloseJobStr;
    private boolean systemCloseFlagY;
    private boolean systemCloseFlagN;
    private Date fromDateCloseJob;
    private Date toDateCloseJob;
    private boolean adminCloseFlagY;
    private boolean adminCloseFlagN;
    private String adminAllId; //Role RE
    private boolean bcCloseFlagY;
     /* ---------- EWS-SME L  ---------- */  
    private String empNo;
    
    //-------- R19 --------//
    private String dataSeperateBy;
    private String custSize;
    private String dataDateTypeReq;
    private String dpdSplitterReportSearchBy;
    private String displayLevel;
    
    //------ R15 -----------//
    
    private String batchDate;

    public String getRmIdOrAeId() {
        return rmIdOrAeId;
    }

    public void setRmIdOrAeId(String rmIdOrAeId) {
        this.rmIdOrAeId = rmIdOrAeId;
    }
    /**
     * @return the byId
     */
    public String getById() {
        return byId;
    }

    /**
     * @param byId the byId to set
     */
    public void setById(String byId) {
        this.byId = byId;
    }

    /**
     * @return the byFirstName
     */
    public String getByFirstName() {
        return byFirstName;
    }

    /**
     * @param byFirstName the byFirstName to set
     */
    public void setByFirstName(String byFirstName) {
        this.byFirstName = byFirstName;
    }

    /**
     * @return the byLastName
     */
    public String getByLastName() {
        return byLastName;
    }

    /**
     * @param byLastName the byLastName to set
     */
    public void setByLastName(String byLastName) {
        this.byLastName = byLastName;
    }

    /**
     * @return the byName
     */
    public String getByName() {
        return byName;
    }

    /**
     * @param byName the byName to set
     */
    public void setByName(String byName) {
        this.byName = byName;
    }

    /**
     * @return the byTypeId
     */
    public String getByTypeId() {
        return byTypeId;
    }

    /**
     * @param byTypeId the byTypeId to set
     */
    public void setByTypeId(String byTypeId) {
        this.byTypeId = byTypeId;
    }

    /**
     * @return the fromDate
     */
    public String getFromDate() {
        return fromDate;
    }

    /**
     * @param fromDate the fromDate to set
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    /**
     * @return the toDate
     */
    public String getToDate() {
        return toDate;
    }

    /**
     * @param toDate the toDate to set
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    /**
     * @return the isMou
     */
    public String getIsMou() {
        return isMou;
    }

    /**
     * @param isMou the isMou to set
     */
    public void setIsMou(String isMou) {
        this.isMou = isMou;
    }

    /**
     * @return the custBusFlg
     */
    public String getCustBusFlg() {
        return custBusFlg;
    }

    /**
     * @param custBusFlg the custBusFlg to set
     */
    public void setCustBusFlg(String custBusFlg) {
        this.custBusFlg = custBusFlg;
    }

    /**
     * @return the user
     */
    public UserData getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(UserData user) {
        this.user = user;
    }

    /**
     * @return the byCizId
     */
    public String getByCizId() {
        return byCizId;
    }

    /**
     * @param byCizId the byCizId to set
     */
    public void setByCizId(String byCizId) {
        this.byCizId = byCizId;
    }

    /**
     * @return the bySubTypeId
     */
    public String getBySubTypeId() {
        return bySubTypeId;
    }

    /**
     * @param bySubTypeId the bySubTypeId to set
     */
    public void setBySubTypeId(String bySubTypeId) {
        this.bySubTypeId = bySubTypeId;
    }

    /**
     * @return the byMainTypeId
     */
    public String getByMainTypeId() {
        return byMainTypeId;
    }

    /**
     * @param byMainTypeId the byMainTypeId to set
     */
    public void setByMainTypeId(String byMainTypeId) {
        this.byMainTypeId = byMainTypeId;
    }

    /**
     * @return the taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * @param taskId the taskId to set
     */
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    /**
     * @return the referenceNo
     */
    public String getReferenceNo() {
        return referenceNo;
    }

    /**
     * @param referenceNo the referenceNo to set
     */
    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    /**
     * @return the customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * @param customerName the customerName to set
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the ecFlag
     */
    public boolean isEcFlag() {
        return ecFlag;
    }

    /**
     * @param ec the ecFlag to set
     */
    public void setEcFlag(boolean ecFlag) {
        this.ecFlag = ecFlag;
    }

    /**
     * @return the otherFlag
     */
    public boolean isOtherFlag() {
        return otherFlag;
    }

    /**
     * @param other the other to set
     */
    public void setOtherFlag(boolean otherFlag) {
        this.otherFlag = otherFlag;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public String getMakerId() {
        return makerId;
    }

    public void setMakerId(String makerId) {
        this.makerId = makerId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getOverrideId() {
        return overrideId;
    }

    public void setOverrideId(String overrideId) {
        this.overrideId = overrideId;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getTransTypeId() {
        return transTypeId;
    }

    public void setTransTypeId(String transTypeId) {
        this.transTypeId = transTypeId;
    }

    public String getTransTypeName() {
        return transTypeName;
    }

    public void setTransTypeName(String transTypeName) {
        this.transTypeName = transTypeName;
    }

    /**
     * @return the sortField
     */
    public String getSortField() {
        return sortField;
    }

    /**
     * @param sortField the sortField to set
     */
    public void setSortField(String sortField) {
        this.sortField = sortField;
    }

    /**
     * @return the sortType
     */
    public String getSortType() {
        return sortType;
    }

    /**
     * @param sortType the sortType to set
     */
    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    /**
     * @return the holderFlag
     */
    public String getHolderFlag() {
        return holderFlag;
    }

    /**
     * @param holderFlag the holderFlag to set
     */
    public void setHolderFlag(String holderFlag) {
        this.holderFlag = holderFlag;
    }

    /**
     * @return the holderId
     */
    public String getHolderId() {
        return holderId;
    }

    /**
     * @param holderId the holderId to set
     */
    public void setHolderId(String holderId) {
        this.holderId = holderId;
    }

    /**
     * @return the fromUtilDate
     */
    public java.util.Date getFromUtilDate() {
        return fromUtilDate;
    }

    /**
     * @param fromUtilDate the fromUtilDate to set
     */
    public void setFromUtilDate(java.util.Date fromUtilDate) {
        this.fromUtilDate = fromUtilDate;
    }

    /**
     * @return the toUtilDate
     */
    public java.util.Date getToUtilDate() {
        return toUtilDate;
    }

    /**
     * @param toUtilDate the toUtilDate to set
     */
    public void setToUtilDate(java.util.Date toUtilDate) {
        this.toUtilDate = toUtilDate;
    }

    /**
     * @return the teamName
     */
    public String getTeamName() {
        return teamName;
    }

    /**
     * @param teamName the teamName to set
     */
    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    /**
     * @return the transTypeDesc
     */
    public String getTransTypeDesc() {
        return transTypeDesc;
    }

    /**
     * @param transTypeDesc the transTypeDesc to set
     */
    public void setTransTypeDesc(String transTypeDesc) {
        this.transTypeDesc = transTypeDesc;
    }

    /**
     * @return the statusDesc
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * @param statusDesc the statusDesc to set
     */
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public String getLogValueNo() {
        return logValueNo;
    }

    public void setLogValueNo(String logValueNo) {
        this.logValueNo = logValueNo;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getTranTypeId() {
        return tranTypeId;
    }

    public void setTranTypeId(String tranTypeId) {
        this.tranTypeId = tranTypeId;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public String getTextSearch() {
        return textSearch;
    }

    public void setTextSearch(String textSearch) {
        this.textSearch = textSearch;
    }

    /**
     * @return the costCenter
     */
    public String getCostCenter() {
        return costCenter;
    }

    /**
     * @param costCenter the costCenter to set
     */
    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getResponseUnit() {
        return responseUnit;
    }

    public void setResponseUnit(String responseUnit) {
        this.responseUnit = responseUnit;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    public String getUserDB() {
        return userDB;
    }

    public void setUserDB(String userDB) {
        this.userDB = userDB;
    }

    public String getPwdDB() {
        return pwdDB;
    }

    public void setPwdDB(String pwdDB) {
        this.pwdDB = pwdDB;
    }

    public String getDbDriver() {
        return dbDriver;
    }

    public void setDbDriver(String dbDriver) {
        this.dbDriver = dbDriver;
    }

    public String getEmpNoCondition() {
        return empNoCondition;
    }

    public void setEmpNoCondition(String empNoCondition) {
        this.empNoCondition = empNoCondition;
    }

    public boolean isCrFillter() {
        return crFillter;
    }

    public void setCrFillter(boolean crFillter) {
        this.crFillter = crFillter;
    }

    public boolean isTaFillter() {
        return taFillter;
    }

    public void setTaFillter(boolean taFillter) {
        this.taFillter = taFillter;
    }

    public String getOrganizationGroup() {
        return organizationGroup;
    }

    public void setOrganizationGroup(String organizationGroup) {
        this.organizationGroup = organizationGroup;
    }

    public String getAeName() {
        return aeName;
    }

    public void setAeName(String aeName) {
        this.aeName = aeName;
    }

    public String getRmName() {
        return rmName;
    }

    public void setRmName(String rmName) {
        this.rmName = rmName;
    }

    public String getResponseUnitName() {
        return responseUnitName;
    }

    public void setResponseUnitName(String responseUnitName) {
        this.responseUnitName = responseUnitName;
    }

    public String getWorkLine() {
        return workLine;
    }

    public void setWorkLine(String workLine) {
        this.workLine = workLine;
    }

    public String getIndividualReportBreakBy() {
        return individualReportBreakBy;
    }

    public void setIndividualReportBreakBy(String individualReportBreakBy) {
        this.individualReportBreakBy = individualReportBreakBy;
    }

    public String getSearchPageIndex() {
        return searchPageIndex;
    }

    public void setSearchPageIndex(String searchPageIndex) {
        this.searchPageIndex = searchPageIndex;
    }

    public String getFromDateCloseJobStr() {
        return fromDateCloseJobStr;
    }

    public void setFromDateCloseJobStr(String fromDateCloseJobStr) {
        this.fromDateCloseJobStr = fromDateCloseJobStr;
    }

    public String getToDateCloseJobStr() {
        return toDateCloseJobStr;
    }

    public void setToDateCloseJobStr(String toDateCloseJobStr) {
        this.toDateCloseJobStr = toDateCloseJobStr;
    }

    public boolean isSystemCloseFlagY() {
        return systemCloseFlagY;
    }

    public void setSystemCloseFlagY(boolean systemCloseFlagY) {
        this.systemCloseFlagY = systemCloseFlagY;
    }

    public boolean isSystemCloseFlagN() {
        return systemCloseFlagN;
    }

    public void setSystemCloseFlagN(boolean systemCloseFlagN) {
        this.systemCloseFlagN = systemCloseFlagN;
    }

    public Date getFromDateCloseJob() {
        return fromDateCloseJob;
    }

    public void setFromDateCloseJob(Date fromDateCloseJob) {
        this.fromDateCloseJob = fromDateCloseJob;
    }

    public Date getToDateCloseJob() {
        return toDateCloseJob;
    }

    public void setToDateCloseJob(Date toDateCloseJob) {
        this.toDateCloseJob = toDateCloseJob;
    }

    public boolean isAdminCloseFlagY() {
        return adminCloseFlagY;
    }

    public void setAdminCloseFlagY(boolean adminCloseFlagY) {
        this.adminCloseFlagY = adminCloseFlagY;
    }

    public boolean isAdminCloseFlagN() {
        return adminCloseFlagN;
    }

    public void setAdminCloseFlagN(boolean adminCloseFlagN) {
        this.adminCloseFlagN = adminCloseFlagN;
    }

    public String getAdminAllId() {
        return adminAllId;
    }

    public void setAdminAllId(String adminAllId) {
        this.adminAllId = adminAllId;
    }

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public boolean isBcCloseFlagY() {
        return bcCloseFlagY;
    }

    public void setBcCloseFlagY(boolean bcCloseFlagY) {
        this.bcCloseFlagY = bcCloseFlagY;
    }

    public String getDataSeperateBy() {
        return dataSeperateBy;
    }

    public void setDataSeperateBy(String dataSeperateBy) {
        this.dataSeperateBy = dataSeperateBy;
    }

    public String getCustSize() {
        return custSize;
    }

    public void setCustSize(String custSize) {
        this.custSize = custSize;
    }

    public String getDataDateTypeReq() {
        return dataDateTypeReq;
    }

    public void setDataDateTypeReq(String dataDateTypeReq) {
        this.dataDateTypeReq = dataDateTypeReq;
    }

    public String getDpdSplitterReportSearchBy() {
        return dpdSplitterReportSearchBy;
    }

    public void setDpdSplitterReportSearchBy(String dpdSplitterReportSearchBy) {
        this.dpdSplitterReportSearchBy = dpdSplitterReportSearchBy;
    }

    public String getDisplayLevel() {
        return displayLevel;
    }

    public void setDisplayLevel(String displayLevel) {
        this.displayLevel = displayLevel;
    }

    public String getBatchDate() {
        return batchDate;
    }

    public void setBatchDate(String batchDate) {
        this.batchDate = batchDate;
    }
    
}
