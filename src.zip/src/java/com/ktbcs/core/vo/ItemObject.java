/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.vo;

import java.util.HashMap;

/**
 *
 * @author KTBDevLoan
 */
public class ItemObject {
   
    private HashMap<String, Object> dataExcel;

    public HashMap<String, Object> getDataExcel() {
        return dataExcel;
    }

    public void setDataExcel(HashMap<String, Object> dataExcel) {
        this.dataExcel = dataExcel;
    }
}
