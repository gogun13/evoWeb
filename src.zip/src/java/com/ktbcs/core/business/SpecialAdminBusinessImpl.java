/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktbcs.core.services.SpecialAdminService;
import com.ktbcs.core.vo.SpecialAdminVo;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class SpecialAdminBusinessImpl extends AbstractBusiness implements SpecialAdminBusiness {

    private static final Logger log = Logger.getLogger(SpecialAdminBusinessImpl.class);
    
    @Autowired
    private SpecialAdminService specialAdminService;
    
    @Override
    public SpecialAdminVo queryData(String sql, boolean inquiryMode, String dbName) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("queryData");
        }
        if(inquiryMode){
            return specialAdminService.getData(sql, dbName);
        }else{
            return specialAdminService.updateData(sql, dbName);
        }
    }
}

