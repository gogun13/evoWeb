/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktb.ewsl.vo.RoleVo;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public interface UserBusiness {

      public ArrayList<RoleVo> findUserRole(UserData entity)throws Exception;
      
      public ArrayList<RoleVo> findUserRoleAndCheckCondition(UserData entity)throws Exception; //-----R22
 
}
