/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface KTBEmpDirectoryBusiness {
    
     public UserData findById(String empNo)throws Exception;
     
     public String searchForFindEmpNo(String condition)throws Exception;
     
     public List<UserData> findByRankCode(String rankCode) throws Exception ;
     
     public List<UserData> findByRankCodeAndDeptCode(String rankCode , String responseUnit) throws Exception ;
     
     public String searchEmpNameById (String empId) throws Exception ;
    
}
