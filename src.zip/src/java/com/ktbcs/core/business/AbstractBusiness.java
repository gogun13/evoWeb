/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.ErrorLevel;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author Administrator
 */
public abstract class AbstractBusiness implements MessageSourceAware {

    private static Logger logger = Logger.getLogger(AbstractBusiness.class);
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public JdbcTemplate getJdbcTemplate(String dataSourceName) {
        ApplicationContext ac = AppContext.getApplicationContext();
        DataSource dataSource = (DataSource) ac.getBean(dataSourceName);
        JdbcTemplate tmpJdbcTemplate = new JdbcTemplate(dataSource);
        return tmpJdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    private MessageSource messageSource;

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

//    public AbstractJpaService getJpaDaoService(Class claz) {
//        try {
//            AbstractJpaService jpaService = (AbstractJpaService) claz.newInstance();
//            jpaService.setEntityManagerFactory(entityManagerFactory);
//            return jpaService;
//        } catch (Exception ex) {
//            System.out.println("Can't create instace class or it is not JpaService class:" + ex);
//        }
//        return null;
//    }
 /*   public AbstractJdbcService getJdbcDaoService(Class claz) {
        try {
            AbstractJdbcService jdbcService = (AbstractJdbcService) claz.newInstance();
            //jdbcService.setEntityManagerFactory(entityManagerFactory);
            jdbcService.setJdbcTemplate(jdbcTemplate);
            return jdbcService;
        } catch (Exception ex) {
            logger.error("Can't create instace class or it is not JpaService class:", ex);
        }
        return null;
    }

    public AbstractJdbcService getJdbcDaoService(Class claz, String dataSourceName) {
        try {
            AbstractJdbcService jdbcService = (AbstractJdbcService) claz.newInstance();
            if (dataSourceName != null && dataSourceName.length() > 0) {
                ApplicationContext ac = AppContext.getApplicationContext();
                DataSource dataSource = (DataSource) ac.getBean(dataSourceName);
                JdbcTemplate tmpJdbcTemplate = new JdbcTemplate(dataSource);
                jdbcService.setJdbcTemplate(tmpJdbcTemplate);
            } else {
                jdbcService.setJdbcTemplate(jdbcTemplate);
            }
            return jdbcService;
        } catch (Exception ex) {
            logger.error("Can't create instace class or it is not JpaService class:", ex);
        }
        return null;
    }
*/
    /***
     * For SystemError assumed that should have technical error messages attached to
     * @param exception: DataAccessException is thrown by Spring jdbcTemplate
     * @param errorKey : Error message key definded in db-error.properties
     * @param keyParams : Optional parameters from key values
     * @throws com.kcs.core.exceptions.BusinessException
     */
    protected void throwSystemError(DataAccessException exception, String errorKey, Object[]... keyParams) throws BusinessException {
        SQLException sqlException = (SQLException) exception.getCause();
        BusinessException be = new BusinessException(errorKey);
        be.setErrorLevel(ErrorLevel.SYSTEM);
        be.setErrorKey(errorKey);
        be.setErrorKeyParams(keyParams);
        be.setSqlErrorCode(sqlException.getErrorCode());
        be.setSqlErrorState(sqlException.getSQLState());
        be.setStackTrace(exception.getStackTrace());
        logger.error("SystemError:", be);
        throw be;
    }

    protected void throwSystemError(DataAccessException exception) throws BusinessException {
        throwSystemError(exception, exception.getMessage());
    }

    protected void throwSystemError(Exception exception) throws BusinessException {
        logger.error("Unhandle Exception :", exception);

        if (exception instanceof DataAccessException) {

            throw new BusinessException(ErrorLevel.SYSTEM, exception);
        } else {

            if (exception.getMessage() != null) {
                throwBusinessError(exception.getMessage(), true);
            } else if (exception.getCause() != null) {
                throwBusinessError(exception.getCause().toString(), true);
            } else {
                throwBusinessError(String.valueOf(exception), true);
            }
        }
    }

    /***
     * @param errorKey : Error key in Property file
     * @param keyParams : Optional , for key parameters
     */
    protected void throwBusinessError(String errorKey, Object... keyParams) throws BusinessException ,Exception{
        if (logger.isInfoEnabled()) {
            logger.info("BusinessError:");
            logger.info("errorKey:" + errorKey);
            logger.info("keyParams:" + keyParams);
        }
        if (errorKey != null) {
            int index = errorKey.indexOf("Exception");
            if (index != -1) {
                throw new BusinessException(ErrorLevel.SYSTEM, errorKey, keyParams);
            }
        } else {
            throw new Exception();
        }
        throw new BusinessException(ErrorLevel.BUSINESS, errorKey, keyParams);
    }

    /***
     * @param errorMessage : plain error messessage
     */
    protected void throwBusinessError(String errorMessage, boolean isPlainMessage) throws BusinessException {
        if (logger.isInfoEnabled()) {
            logger.info("==========###BusinessError###=============");
            logger.info("errorKey:" + errorMessage);
            logger.info("keyParams:" + isPlainMessage);
            logger.info("==========###BusinessError###=============");
        }
        throw new BusinessException(ErrorLevel.BUSINESS, errorMessage, isPlainMessage);
    }

    /***
     * BUSINESS_UNHANDLE type of BusinessException, when thrown to View(front-end). Old data in view will be cleared.
     * @param errorMessage
     * @param isPlainMessage
     * @throws com.kcs.core.exceptions.BusinessException
     */
    protected void throwUnhandleBusinessError(String errorMessage, boolean isPlainMessage) throws BusinessException {
        if (logger.isInfoEnabled()) {
            logger.info("==========###UnhandleBusinessError###=============");
            logger.info("errorKey:" + errorMessage);
            logger.info("keyParams:" + isPlainMessage);
            logger.info("==========###UnhandleBusinessError###=============");
        }

        BusinessException bex = new BusinessException(ErrorLevel.BUSINESS_UNHANDLE, errorMessage, isPlainMessage);
        //logger.error("throwUnhandleBusinessError :", bex);
        throw bex;
    }
}
