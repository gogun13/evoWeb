/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import org.springframework.context.ApplicationContext;

/**
 *
 * @author aon
 */
public class AppContext {

    private static ApplicationContext ctx;

    public static void setApplicationContext(ApplicationContext applicationContext) {
        ctx = applicationContext;
    }

    public static ApplicationContext getApplicationContext() {
        return ctx;
    }

    /**
     * @return the ctx
     */
    public static ApplicationContext getCtx() {
        return ctx;
    }

    /**
     * @param aCtx the ctx to set
     */
    public static void setCtx(ApplicationContext aCtx) {
        ctx = aCtx;
    }
}
