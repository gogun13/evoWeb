/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktbcs.core.vo.SpecialAdminVo;

/**
 *
 * @author KTBDevLoan
 */
public interface SpecialAdminBusiness {
     public SpecialAdminVo queryData(String sql, boolean inquiryMode, String dbName) throws Exception;
    
}
