/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktb.ewsl.services.RoleGroupMappingService;
import com.ktb.ewsl.services.RolePrivilegeHistoryService;
import com.ktb.ewsl.services.RolePrivilegeService;
import com.ktb.ewsl.vo.RolePrivilegeHistoryVo;
import com.ktb.ewsl.vo.RolePrivilegeVo;
import com.ktb.ewsl.vo.RoleVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Administrator
 */
@Service
public class UserBusinessImpl extends AbstractBusiness implements UserBusiness {

    private static Logger logger = Logger.getLogger(UserBusinessImpl.class);

    @Autowired
    RoleGroupMappingService roleGroupMappingService;
    @Autowired
    private RolePrivilegeService rolePrivilegeService;
    @Autowired
    private RolePrivilegeHistoryService rolePrivilegeHistoryService;

    @Override
    public ArrayList<RoleVo> findUserRole(UserData entity) throws Exception {
         ArrayList<RoleVo> roleVoLsit = null;
         String currentDate = DateUtil.getCurrentDateString();
        try{
            if((entity != null)&&(StringUtil.isNotEmpty(entity.getDeptCode()))&&
                     (StringUtil.isNotEmpty(entity.getKtbFieldMap()))&&(StringUtil.isNotEmpty(entity.getEmpNo()))
                          &&(StringUtil.isNotEmpty(currentDate))){   
                 
                roleVoLsit = roleGroupMappingService.getRoleID(entity, currentDate);
                
            }
        }catch(Exception e){
          logger.error("Error occur in while process UserBusinessImpl.findUserRole: " + e.getMessage() , e);
        }
     return roleVoLsit;
    }
    
    /*
     *
     */
    @Override
    public ArrayList<RoleVo> findUserRoleAndCheckCondition(UserData entity) throws Exception {
//        RoleVo result = null;
        RoleVo resultAfterCon = null;
        String currentDate = DateUtil.getCurrentDateString();
        ArrayList<RoleVo> roleVoTmpLsit = null;
        ArrayList<RoleVo> roleVoLsit = null;
        
        try{
            if((entity != null)&&(StringUtil.isNotEmpty(entity.getDeptCode()))&&
                     (StringUtil.isNotEmpty(entity.getKtbFieldMap()))&&(StringUtil.isNotEmpty(entity.getEmpNo()))){
                
                roleVoTmpLsit = roleGroupMappingService.getRoleID(entity, currentDate);
                //--------Get Only High Role
//                if(!roleVoLsit.isEmpty()){
//                  result = (RoleVo)roleVoLsit.get(0);
//                }
                //------ Check Condition -------//
                if(roleVoTmpLsit != null && !roleVoTmpLsit.isEmpty()){
                    roleVoLsit = new ArrayList<RoleVo>();
                    for(RoleVo resultTemp:roleVoTmpLsit){
                        resultAfterCon = checkCondition(resultTemp, entity);
                        if(resultAfterCon != null){
                             roleVoLsit.add(resultAfterCon);
                         }
                    }
                }
            }
        }catch(Exception e){
          logger.error("Error occur in while process UserBusinessImpl.findUserRoleAndCheckCondition: " + e.getMessage() , e);
        }
     return roleVoLsit;
    }
    
    /*
     * compareTo : 0 ; Date 1 = Date 2
     *             -1 ; Date 1 Before Date 2
     *             1 ; Date 1 After Date 2
     */
    private RoleVo checkCondition(RoleVo result , UserData entity) throws Exception {
        logger.info(" --------------------------- checkCondition --------------------------------");
        try{
                logger.info(" result.getRoleId() >> " + result != null ? result.getRoleId() : "");
                logger.info(" entity.getEmpNo() >> " + entity != null ? entity.getEmpNo() : "");
                if(result != null && !"".equals(result.getRoleId()) && !"".equals(entity.getEmpNo())){
                    RolePrivilegeVo  resultPrivilege = rolePrivilegeService.getEmployeeIDByRoleCodeAndEmpNo(result.getRoleId() ,entity.getEmpNo());
                    if(resultPrivilege != null){
                      if((resultPrivilege.getEndDate() != null && DateUtil.clearTime(DateUtil.getCurrentDateTime()).compareTo(resultPrivilege.getEndDate()) > 0)|| 
                           (resultPrivilege.getDeptCode() != null && entity.getDeptCode() != null && 
                                (resultPrivilege.getDeptCode() != Integer.parseInt(entity.getDeptCode())))){
                             logger.info(" LOOP 1 for checkCondition ");
                               rolePrivilegeService.updateInActiveUserRolePrivilege( result.getRoleId() ,entity.getEmpNo());
                               RolePrivilegeVo  resultPrivilegeForInsert = rolePrivilegeService.getEmployeeIDByRoleCodeAndEmpNo(result.getRoleId() ,entity.getEmpNo());
                               if(resultPrivilegeForInsert != null){
                                  RolePrivilegeHistoryVo hisVo = new RolePrivilegeHistoryVo();
                                  hisVo.setDeptCode(resultPrivilegeForInsert.getDeptCode());
                                  hisVo.setDeptName(resultPrivilegeForInsert.getDeptName());
                                  hisVo.setEmpName(entity.getFullName());
                                  hisVo.setEmployeeId(resultPrivilegeForInsert.getEmployeeId());
                                  hisVo.setDateTime(DateUtil.getCurrentDateTime());
                                  hisVo.setEndDate(resultPrivilegeForInsert.getEndDate());
                                  hisVo.setIsActive(resultPrivilegeForInsert.getIsActive());
                                  hisVo.setRoleCode(resultPrivilegeForInsert.getRoleCode());
                                  hisVo.setCreatedDate(resultPrivilegeForInsert.getCreatedDate());
                                  hisVo.setCreatedBy(resultPrivilegeForInsert.getCreatedBy());
                                  hisVo.setUpdatedDate(resultPrivilegeForInsert.getUpdatedDate());
                                  hisVo.setUpdatedBy(resultPrivilegeForInsert.getUpdatedBy());
                                  int resultInsert = rolePrivilegeHistoryService.insertRolePrivilegeHistory(hisVo);
                                  logger.info(" resultInsert 1 >> " + resultInsert);
                                  result = null;
                               }
                        }//END if, and in case EndDate = null it can login
                    }
                }
                
        }catch(Exception e){
          logger.error("Error occur in while process UserBusinessImpl.checkCondition: " + e.getMessage() , e);
        }
     return result;
    }
    
}
