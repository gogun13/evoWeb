/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.business;

import com.ktbcs.core.services.KTBEmpDirectoryService;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class KTBEmpDirectoryBusinessImpl extends AbstractBusiness implements KTBEmpDirectoryBusiness{

    private static Logger logger = Logger.getLogger(KTBEmpDirectoryBusinessImpl.class);
    
    @Autowired
    private KTBEmpDirectoryService ktbEmpDirectoryService;
    
    @Override
    public UserData findById(String empNo) throws Exception {
     UserData result = new UserData();
        try{
            UserData condition = new UserData();
            condition.setEmpNo(empNo);
            List<UserData> userList = ktbEmpDirectoryService.findByFilter(condition);
            if(!userList.isEmpty()){
                 result = (UserData)userList.get(0);
            }
        }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryBusinessImpl.findById: " + e.getMessage() , e);
        }
     return result;
    }

    @Override
    public String searchForFindEmpNo(String condition) throws Exception {
        String param = new String();
        try{
            List empNoList = ktbEmpDirectoryService.searchByEmpName(condition);
            if(!empNoList.isEmpty()){
                for(int i=0 ; i < empNoList.size(); i++){
			 String data = (String)empNoList.get(i);
                         param = param.concat("'").concat(data).concat("'");
                         if(i < empNoList.size() - 1 ){
                                param  = param.concat(",");
                         } 
		}
            }
          System.out.println("searchForFindEmpNo param = " + param);
        }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryBusinessImpl.searchForFindEmpNo: " + e.getMessage() , e);
        }
     return param;
    }

    @Override
    public List<UserData> findByRankCode(String rankCode) throws Exception {
       List<UserData> userList = null;
        try{
           if(!ValidatorUtil.isNullOrEmpty(rankCode)){
             userList = ktbEmpDirectoryService.findByRankCode(rankCode);
           }
           
        }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryBusinessImpl.findByRankCode: " + e.getMessage() , e);
        }
        return userList;
    }

    @Override
    public List<UserData> findByRankCodeAndDeptCode(String rankCode, String responseUnit) throws Exception {
        List<UserData> userList = null;
        try{
           if(!ValidatorUtil.isNullOrEmpty(rankCode) && !ValidatorUtil.isNullOrEmpty(responseUnit) ){
             userList = ktbEmpDirectoryService.findByRankCodeAndDeptCode(rankCode, responseUnit);
           }
           
        }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryBusinessImpl.findByRankCodeAndDeptCode: " + e.getMessage() , e);
        }
        return userList;
    }

    @Override
    public String searchEmpNameById(String empId) throws Exception {
        return ktbEmpDirectoryService.searchEmpNameById(empId);
    }
    
}
