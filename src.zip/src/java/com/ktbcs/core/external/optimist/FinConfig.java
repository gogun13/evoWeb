package com.ktbcs.core.external.optimist;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FinConfig {
    private static final Log log = LogFactory.getLog(FinConfig.class.getName());
    private static Map configMap = new HashMap();
    private String configFile;
    private Properties props;
    private String defaultProfile;

    private FinConfig(String configFile) {
        this.configFile = configFile;
        props = new Properties();
        try {
            props.load(this.getClass().getResourceAsStream(configFile));
            log.debug("create configuration from file " + configFile);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(FinConfig.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.defaultProfile = get("profile");
        log.debug("default profile = " + defaultProfile);
    }

    public static FinConfig getInstance(String configFile) {
        FinConfig conf = (FinConfig) configMap.get(configFile);
        if (conf == null) {
            conf = new FinConfig(configFile);
            configMap.put(configFile, conf);
        }
        return conf;
    }

    public String getProfile() {
        return defaultProfile;
    }

    public String get(String key) {
        String value = null;
        String _key = key;
        try {
            if (defaultProfile != null) {
                _key = defaultProfile + "." + key;
            }

            value = props.getProperty(_key);
            if (value != null) {
                value = value.trim();
            }

        } catch (java.util.MissingResourceException ex) {
        }
        return value;
    }
}
