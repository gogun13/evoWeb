package com.ktbcs.core.external.optimist;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class FinUtil {

    public static final String SYS_USER_ID = "888888";
    public static final String TYPE_BALANCE = "BALANCE";
    public static final String TYPE_INCOME = "INCOME";
    public static final String TYPE_CASH = "CASH";

    public static final BigDecimal percentVal = new BigDecimal("100.0000");
    public static final DecimalFormat amountFormat = new DecimalFormat("###,##0");
    public static final DecimalFormat amount2DigitFormat = new DecimalFormat("###,##0.00");
    public static final DecimalFormat amount3DigitFormat = new DecimalFormat("###,##0.000");
    public static final DecimalFormat amount4DigitFormat = new DecimalFormat("###,##0.0000");
    public static final DecimalFormat amount5DigitFormat = new DecimalFormat("###,##0.00000");
    public static final SimpleDateFormat usDateKeyFormat = new SimpleDateFormat("yyMMddHHmmssSSS", Locale.US);
    public static final SimpleDateFormat usDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    public static final SimpleDateFormat usTimestampFormat = new SimpleDateFormat("yyyy/MM/dd:HH:mm", Locale.US);
    public static final SimpleDateFormat thaiDateFormat = new SimpleDateFormat("dd/MM/yyyy", new Locale("th", "TH"));
    public static final SimpleDateFormat thaiDateFormatFull = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("th", "TH"));
    public static final SimpleDateFormat thaiDateShortFormat = new SimpleDateFormat("dd/MM/yy", new Locale("th", "TH"));
    public static final SimpleDateFormat thaiDate4FileFormat = new SimpleDateFormat("ddMMyyyy", new Locale("th", "TH"));
    public static final DecimalFormat amountDBFormat = new DecimalFormat("#####0");
    public static final DecimalFormat amountDB2DigitFormat = new DecimalFormat("#####0.00");
    public static final DecimalFormat amountDB3DigitFormat = new DecimalFormat("#####0.000");
    public static final DecimalFormat amountDB4DigitFormat = new DecimalFormat("#####0.0000");
    public static final DecimalFormat amountDB5DigitFormat = new DecimalFormat("#####0.00000");
    public static final DecimalFormat amountDB6DigitFormat = new DecimalFormat("#####0.000000");
    public static final DecimalFormat amountDB8DigitFormat = new DecimalFormat("#####0.00000000");
    public static final DecimalFormat amountDB15DigitFormat = new DecimalFormat("#####0.000000000000000");
    public static final DecimalFormat amountDB20DigitFormat = new DecimalFormat("#####0.00000000000000000000");
    public static final DecimalFormat display8DigitFormat = new DecimalFormat("####.########");
    public static final DecimalFormat display2DigitFormat = new DecimalFormat("###,###,###,###.##");

    public static final SimpleDateFormat usDateTimeOraFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
    public static final SimpleDateFormat usDateOraFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);


    public static String null2Empty(String str) {
        if(str == null || "null".equalsIgnoreCase(str)) return "";
        return str.trim();
    }
    
    public static String genKeyByDT(Date date) {
        try {
            return usDateKeyFormat.format(date);
        } catch (Exception e) {
            return "";
        }
    }

    public static String formatddMMyyTH(Date date) {

        try {
            return thaiDateShortFormat.format(date);
        } catch (Exception e) {
            return "";
        }
    }

    public static String formatddMMyyyyTH(Date date) {

        try {
            return thaiDateFormat.format(date);
        } catch (Exception e) {
            return "";
        }
    }

     public static String formatDateTHFull(Date date) {

        try {
            return thaiDateFormatFull.format(date);
        } catch (Exception e) {
            return "";
        }
    }

    public static String formatddMMyyyyTH4File(Date date) {

        try {
            return thaiDate4FileFormat.format(date);
        } catch (Exception e) {
            return "";
        }
    }

    public static Date toDateTH(String string) {
        try {
            return thaiDateFormat.parse(string);
        } catch (Exception e) {
            return null;
        }
    }

    public static Date toDateTHShort(String string) {
        try {
            return thaiDateShortFormat.parse(string);
        } catch (Exception e) {
            return null;
        }
    }

    public static Date toDate(String string) {
        try {
            return usDateFormat.parse(string);
        } catch (Exception e) {
            return null;
        }
    }

    //===============
    public static int usMMFormat(Date date, String format) {
        try {

            SimpleDateFormat form = new SimpleDateFormat(format);
            return Integer.parseInt(form.format(date));

        } catch (Exception e) {
            return 0;
        }
    }
    //===============

    public static String formatDBdate(Date date) {
        try {
            return "'" + usDateFormat.format(date) + "'";
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBOraDate(Date date) {
        try {

            return " TO_DATE('"+ usDateOraFormat.format(date) + "', 'yyyy/mm/dd') ";
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBOraDateTime(Date date) {
        try {
            return " TO_DATE('"+ usDateTimeOraFormat.format(date) + "', 'yyyy/mm/dd hh24:mi:ss') ";
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatCurrency(BigDecimal aValue) {
        try {
            if (aValue == null) {
                return "0";
            }
            return amountFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatCurrency2Digi(BigDecimal aValue) {
        try {
            return amount2DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0.00";
        }
    }

    public static String formatCurrency2DigiNA(BigDecimal aValue) {
        try {
            if (aValue != null) {
                return amount2DigitFormat.format(aValue);
            } else {
                return "n/a";
            }
        } catch (Exception e) {
            return "n/a";
        }
    }

    public static String formatCurrency2DigiOrDash(BigDecimal aValue) {
        try {
            if (aValue != null) {
                return amount2DigitFormat.format(aValue);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0.00";
        }
    }

    public static String formatCurrency4Digi(BigDecimal aValue) {
        try {
            return amount4DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0.0000";
        }
    }

    public static String formatCurrency4DigiOrDash(BigDecimal aValue) {
        try {
            if (aValue != null) {
                return amount4DigitFormat.format(aValue);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0.00";
        }
    }

    public static String formatCurrency3Digi(BigDecimal aValue) {
        try {
            return amount3DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0.000";
        }
    }

    public static String formatCurrency5Digi(BigDecimal aValue) {
        try {
            return amount5DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0.00000";
        }
    }

    public static BigDecimal string2BigDecimal(String text) {
        try {
            return new BigDecimal(text);
        } catch (Exception e) {
            return new BigDecimal("0");
        }
    }

    public static BigDecimal string2BigDecimalNull(String text) {
        try {
            if(text!=null) {
                return new BigDecimal(text);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static BigDecimal string2Bigdecimal2Null(String aValue) {
        try {
            if (aValue != null && aValue.trim().length() > 0) {
                String tmp = aValue.trim();
                BigDecimal tmpb = new BigDecimal(tmp);
                return string2BigDecimal(amountDB2DigitFormat.format(tmpb));
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static BigDecimal string2Bigdecimal3Null(String aValue) {
        try {
            if (aValue != null && aValue.trim().length() > 0) {
                String tmp = aValue.trim();
                BigDecimal tmpb = new BigDecimal(tmp);
                return string2BigDecimal(amountDB3DigitFormat.format(tmpb));
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static int string2Integer(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    public static String string2String(String text) {
        try {
            if (!isEmpty(text) && "null".equalsIgnoreCase(text.trim())) {
                return "";
            } else {
                return text.trim();
            }

        } catch (Exception e) {
            return "";
        }
    }

    public static int obj2Integer(Object obj) {
        try {
            return Integer.parseInt(String.valueOf(obj));
        } catch (Exception e) {
            return 0;
        }
    }

    public static BigDecimal obj2Bigdecimal(Object obj) {
        try {
            if (obj != null) {
                return (BigDecimal) obj;
            } else {
                return new BigDecimal("0.00");
            }

        } catch (Exception e) {
            return new BigDecimal("0.00");
        }
    }

    public static String formatPercent(BigDecimal val) {
        try {
            val = val.multiply(percentVal);
            return formatCurrency3Digi(val);

        } catch (Exception e) {
            return "0.000";
        }
    }

    public static String formatPercentWithSign(BigDecimal val) {
        return formatPercent(val) + "%";
    }

    public static String formatPercentOrDash(BigDecimal val) {
        try {
            if (val != null) {
                val = val.multiply(percentVal);
                return formatCurrency3Digi(val);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0.000";
        }
    }

    public static String formatPercent2DigiOrDash(BigDecimal val) {
        try {
            if (val != null) {
                val = val.multiply(percentVal);
                val = val.setScale(3, BigDecimal.ROUND_CEILING);
                val = val.setScale(2, BigDecimal.ROUND_HALF_UP);
                return formatCurrency2Digi(val);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0.000";
        }
    }

    public static String formatPercentOrDashWithSign(BigDecimal val) {
        return formatPercentOrDash(val) + "%";
    }

    public static String formatPercentNoPrec(BigDecimal val) {
        try {
            val = val.multiply(percentVal);
            return formatCurrency(val);
        } catch (Exception e) {
            return "0.00";
        }
    }

    public static BigDecimal string2Percent(String text) {
        try {

            if (text.indexOf(".") < 0) {
                text += ".0000";
            }

            BigDecimal val = new BigDecimal(text);
            val = val.setScale(8);
            return val.divide(percentVal, BigDecimal.ROUND_HALF_UP);
        } catch (Exception e) {
            return new BigDecimal("0.00");
        }
    }

    public static BigDecimal string2Percent8Digi(String text) {
        try {

            if (text.indexOf(".") < 0) {
                text += ".00000000";
            }

            BigDecimal val = new BigDecimal(text);
            return val.divide(percentVal, 8, BigDecimal.ROUND_HALF_UP);
        } catch (Exception e) {
            return new BigDecimal("0.00000000");
        }
    }

    public static String formatDBString(String text) {
        if (text != null) {
            return (text.trim().length() == 0) ? null : "'" + text.trim().replaceAll("'", "''") + "'";
        } else {
            return "''";
        }
    }

    public static String formatDBString4Prepare(String text) {
        if (text != null) {
            return (text.trim().length() == 0) ? null : text.trim().replaceAll("'", "''");
        } else {
            return " ";
        }
    }

    public static String formatDBStringDefault(String text) {
        if (text != null) {
            return (text.trim().length() == 0) ? null : "'" + text.trim().replaceAll("'", "''") + "'";
        } else {
            return "NULL";
        }
    }

    public static String obj2String(Object obj) {
        try {
            if (obj == null) {
                return "";
            } else {
                return String.valueOf(obj);
            }
        } catch (Exception e) {
            return "";
        }
    }

    public static String getStrCurrDate() {
        return formatddMMyyyyTH(Calendar.getInstance().getTime());
    }

    public static Date getCurrDate() {
        return Calendar.getInstance().getTime();
    }

    public static String getCurrTimestamp() {
        return usTimestampFormat.format(Calendar.getInstance().getTime());
    }

    public static String getStrCurrDate4File() {
        return formatddMMyyyyTH4File(Calendar.getInstance().getTime());
    }

    public static String formatEmptyDashString(String text) {
        if (isEmpty(text)) {
            return "--";
        } else {
            return text.trim();
        }
    }

    public static String formatEmptyString(String text) {
        if (isEmpty(text)) {
            return "";
        } else {
            return text.trim();
        }
    }

    public static String formatEmptyHtml(String text) {
        if (isEmpty(text)) {
            return "&nbsp;";
        } else {
            return text.trim();
        }
    }

    public static String formatDBCurrency(BigDecimal aValue) {
        try {
            return amountDBFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDBCurrencyDefault(BigDecimal aValue) {
        try {
            return formatDBStringDefault(aValue.toString());
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBCurrency2Digi(String aValue) {
        if (aValue != null && aValue.trim().length()>0) {
            String tmp = aValue.trim();
            BigDecimal tmpb = new BigDecimal(tmp);
            return formatDBCurrency2Digi(tmpb);
        } else {
            return "NULL";
        }
    }

    public static String formatDBCurrency3Digi(BigDecimal aValue) {
        try {
            return amountDB3DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBCurrency20Digi(BigDecimal aValue) {
        try {
            return amountDB20DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

   public static String formatDBCurrency3Digi(String aValue) {
        if (aValue != null && aValue.trim().length()>0) {
            String tmp = aValue.trim();
            BigDecimal tmpb = new BigDecimal(tmp);
            return formatDBCurrency3Digi(tmpb);
        } else {
            return "NULL";
        }
    }

    public static String formatDBCurrency2Digi(BigDecimal aValue) {
        try {
            return amountDB2DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBCurrency4Digi(BigDecimal aValue) {
        try {
            return amountDB8DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDBCurrency5Digi(BigDecimal aValue) {
        try {
            return amountDB5DigitFormat.format(aValue);
        } catch (Exception e) {
            return "-99999999";
        }
    }

    public static String formatDBCurrency6Digi(BigDecimal aValue) {
        try {
            return amountDB6DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDBCurrency8Digi(BigDecimal aValue) {
        try {
            return amountDB8DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBCurrency15Digi(BigDecimal aValue) {
        try {
            return amountDB15DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDBPercent8Digi(BigDecimal aValue) {
        try {
            aValue = aValue.divide(percentVal, BigDecimal.ROUND_HALF_UP);
            return amountDB8DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static BigDecimal null2Zero(BigDecimal b1) {
        if (b1 != null) {
            return b1;
        } else {
            return new BigDecimal("0");
        }
    }

    public static BigDecimal minZero(BigDecimal b1) {
        if (b1 != null && b1.compareTo(defaultValue0()) >= 0) {
            return b1;
        } else {
            return new BigDecimal("0");
        }
    }

    public static BigDecimal defaultValue0() {
        return new BigDecimal("0");
    }

    public static BigDecimal defaultValue1() {
        return new BigDecimal("1");
    }

    public static BigDecimal defaultValue12() {
        return new BigDecimal("12");
    }

    public static BigDecimal valueMultiply100(BigDecimal b1) {
        if (b1 != null) {
            return b1.multiply(new BigDecimal("100.00"));
        } else {
            return new BigDecimal("0.00");
        }
    }

    public static BigDecimal valueDivideBy100(BigDecimal b1) {
        if (b1 != null) {
            return b1.divide(new BigDecimal("100"), 8, BigDecimal.ROUND_HALF_UP);
        } else {
            return new BigDecimal("0");
        }
    }

    public static String formatDisplay8Digit(BigDecimal aValue) {
        try {
            return display8DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDisplayPercent8Digit(BigDecimal aValue) {
        try {
            aValue = aValue.multiply(percentVal);
            return display8DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDisplayYesNo(String flagVal) {
        if (flagVal != null) {
            if (flagVal.equalsIgnoreCase("Y")) {
                return "Yes";
            } else if (flagVal.equalsIgnoreCase("N")) {
                return "No";
            } else {
                return "";
            }
        } else {
            return "";
        }
    }

    public static String trimText(String text) {
        if (text != null) {
            return text.trim();
        } else {
            return "";
        }
    }

    public static BigDecimal trans2Percent(BigDecimal val) {
        try {
            return val.divide(percentVal, 8, BigDecimal.ROUND_HALF_UP);
        } catch (Exception e) {
            return new BigDecimal(" 0.0000");
        }
    }

    public static String formatDBCurrency2DigiDefault(BigDecimal aValue) {
        try {
            if (aValue == null) {
                return "NULL";
            }
            return amountDB2DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBCurrency5DigiDefault(BigDecimal aValue) {
        try {
            if (aValue == null) {
                return "NULL";
            }
            return amountDB5DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDBCurrency8DigiDefault(BigDecimal aValue) {
        try {
            if (aValue == null) {
                return "NULL";
            }
            return amountDB8DigitFormat.format(aValue);
        } catch (Exception e) {
            return "NULL";
        }
    }

    public static String formatDisplay2Digi(BigDecimal aValue) {
        try {
            return display2DigitFormat.format(aValue);
        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDisplay2DigiOrDash(BigDecimal aValue) {
        try {
            if (aValue != null) {
                return display2DigitFormat.format(aValue);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatDisplayOrDash(BigDecimal aValue) {
        try {
            if (aValue != null) {
                return amountFormat.format(aValue);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0";
        }
    }

    public static String formatPercentDisplay2DigiOrDash(BigDecimal aValue) {
        try {
            if (aValue != null) {
                aValue = aValue.multiply(percentVal);
                return display2DigitFormat.format(aValue);
            } else {
                return "--";
            }

        } catch (Exception e) {
            return "0";
        }

    }

    public static boolean isEmpty(Object object) {
        if (object == null) {
            return true;
        } else if (object instanceof String) {
            String str = (String) object;
            if (str.trim().equals("")) {
                return true;
            }
        } else if (object instanceof Collection) {
            Collection collection = (Collection) object;
            if (collection.isEmpty()) {
                return true;
            }
        } else if (object instanceof Map) {
            Map map = (Map) object;
            if (map.size() == 0) {
                return true;
            }
        } else if (object.getClass().isArray()) {
            Object[] array = (Object[]) object;
            if (array.length == 0) {
                return true;
            }
            boolean result = true;
            for (int i = 0; i < array.length; i++) {
                result = result && isEmpty(array[i]);
            }
            return result;
        }
        return false;
    }

    public static String removeZeroPrefix(String values) {
    	String result = "";
        try {
            result = String.valueOf(Long.parseLong(values));
        } catch(Exception e) {
            result = values;
        }
    	return result;
    }

    public static String addZeroPrefix(String values, int maxLength) {
    	String result = "";

        int strLength = values.length();
        result = values;
    	for (int i = strLength; i < maxLength; i++) {
            result = "0" + result;
        }
    	return result;
    }

    public static String mathRandomDB() {
        String result = "";
        result = formatDBCurrency2Digi(String.valueOf(Math.random()));
        return result;
    }

    public static void main(String[] args) {
        System.out.println(string2Bigdecimal3Null("-37.064728108903"));
        System.out.println(addZeroPrefix("1234",12));
        System.out.println(mathRandomDB());
         System.out.println(removeZeroPrefix("023456789012"));

    }
}
