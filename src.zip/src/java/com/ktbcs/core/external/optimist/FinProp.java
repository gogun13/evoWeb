package com.ktbcs.core.external.optimist;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FinProp {

    private static final Log log = LogFactory.getLog(FinProp.class.getName());
    static FinConfig conf;

    static {
        conf = FinConfig.getInstance("/financial.properties");
    }

    private static Map configMap = new HashMap();
    private static String DEFAULT_KEY = "__default__";

    public static FinProp getInstance() {
        return getInstance(null);
    }

    public static FinProp getInstance(String name) {
        FinProp finProp = (FinProp) ((name == null) ? configMap.get(DEFAULT_KEY) : configMap.get(name));
        log.debug("existing FinConfig[" + name + "] = " + finProp);

        if (finProp == null) {
            finProp = new FinProp(name);
            configMap.put((name == null) ? DEFAULT_KEY : name, finProp);
        }

        return finProp;
    }

    private String name;

    protected FinProp(String name) {
        log.debug("load FinConfig [name=" + name + "] ");
        if (name != null && !"".equals(name.trim())) {
            this.name = name + ".";
        } else {
            this.name = "";
        }
    }

    public String getURLOptimist() {
        return conf.get(name + "http");
    }

    public String getURLWSOptimist() {
        return conf.get(name + "webservice");
    }

}
