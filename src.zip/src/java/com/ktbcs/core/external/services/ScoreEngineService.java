/*
 * InquiryScoreEngine.java
 *
 * Created on June 16, 2011, 5:06 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.ktbcs.core.external.services;

import com.ktb.ewsl.vo.WSLogVO;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Siriwat Asamo
 */
public interface ScoreEngineService {    
    JSONArray inquiryScoreEngine(String projectName, JSONObject inputData , WSLogVO log) throws Exception;
}
