/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.external.services;

import com.ktb.ewsl.services.WSLogService;
import com.ktb.ewsl.vo.WSLogVO;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.io.StringWriter;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import scoreengineclient.ScoreEngineProvider;

/**
 *
 * @author Siriwat Asamo
 */
@Service
public class ScoreEngineServiceImpl implements ScoreEngineService {

    private static final Logger logger = Logger.getLogger(ScoreEngineServiceImpl.class);
    @Autowired
    private WSLogService wsLogService;

    @Override
    public JSONArray inquiryScoreEngine(String projectName, JSONObject inputData, WSLogVO logVo) throws Exception {
        JSONArray arrResponse = null;
        String currentDT = DateUtil.getCurrentDateString(DateUtil.WS_LOG_DATETIME_FORMAT1);
        try {
            if (logger.isInfoEnabled()) {
                logger.info("inquiryScoreEngine");
            }
            StringWriter outj = new StringWriter();
            inputData.writeJSONString(outj);
            String inputParams = outj.toString();

            if (logVo != null) {
                if (!ValidatorUtil.isNullOrEmpty(logVo.getCifNo())) {
                    currentDT = currentDT.concat("_").concat(logVo.getCifNo());
                }
                logVo.setRefID(currentDT);
                logVo.setTransType(BusinessConst.WS_TRAN_TYPE.REQUEST);
                if ((inputParams != null) && (inputParams.trim().length() > 2500)) {
                    logVo.setDetail(inputParams.trim().substring(0, 2500));
                } else {
                    logVo.setDetail(inputParams);
                }

                wsLogService.insertLog(logVo);
            }

            String result = new ScoreEngineProvider().inquiryScoreEngine(projectName, inputParams);
            JSONParser parser = new JSONParser();
            Object obj;

            try {
                obj = parser.parse(result);
            } catch (Exception ex) {
                ex.printStackTrace();
                logger.debug("ERROR in First Parsing.  Result:   " + result);
                String revisedResult = result.replaceAll("([^ :])\"\"}]", "$1\"}]");
                logger.debug("Revised  Result:   " + revisedResult);
                obj = parser.parse(revisedResult);
            }

            arrResponse = (JSONArray) obj;
            logger.debug("response : " + arrResponse.size());

            JSONArray errors = (JSONArray) arrResponse.get(0);
            logger.debug("errors : " + errors.toString());

        } catch (Exception ex) {
            throw ex;
        } finally {
                if ((logVo != null) && (arrResponse != null) && arrResponse.size() > 0) {
                    logVo.setTransType(BusinessConst.WS_TRAN_TYPE.RESPONSE);
                    String resultData = "";
                    JSONArray jsonErrors = (JSONArray) arrResponse.get(0);
                    JSONObject jsonResponse = (JSONObject) arrResponse.get(1);

                    if (jsonErrors != null && jsonErrors.size() > 0) {
                        JSONObject error = (JSONObject) jsonErrors.get(0);
                        resultData = error.get("message").toString();
                        logger.debug("message =  " + resultData);
                    }
                    if (jsonResponse != null) {
                        JSONArray responseErrorDescObj = (JSONArray) jsonResponse.get("responseErrorDesc");
                        if (responseErrorDescObj != null && responseErrorDescObj.size() > 0) {
                            JSONObject error = (JSONObject) responseErrorDescObj.get(0);
                            if (resultData.trim().length() > 0) {
                                resultData = resultData + ",";
                            }
                            resultData = resultData + error.get("errorDescription").toString();
                        }
                        if (resultData.trim().length() > 0) {
                            resultData = resultData + ",";
                        }
                        resultData = resultData + jsonResponse.toJSONString();
                    }

                    if ((resultData != null) && (resultData.trim().length() > 2500)) {
                        logVo.setDetail(resultData.trim().substring(0, 2500));
                    } else {
                        logVo.setDetail(resultData);
                    }
                    wsLogService.insertLog(logVo);
                }
        }
        return arrResponse;
    }
}
