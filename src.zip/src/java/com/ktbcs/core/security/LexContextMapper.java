/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.security;

import java.util.Collection;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;


import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.security.core.GrantedAuthority;

/**
 *
 * @author aon
 */
public class LexContextMapper implements UserDetailsContextMapper {

    public UserDetails mapUserFromContext(DirContextOperations ctx, String username, Collection<? extends GrantedAuthority> authority) {
        LexUserDetails user = new LexUserDetails();
        
        user.setUsername(username);
        user.getLdapAttribute().put("mail", ctx.getStringAttribute("mail"));
        user.getLdapAttribute().put("cn", ctx.getStringAttribute("cn"));
        user.getLdapAttribute().put("givenname", ctx.getStringAttribute("givenname"));
        user.getLdapAttribute().put("kcsbranchcode", ctx.getStringAttribute("kcsbranchcode"));

        return user;
    }

    
    public void mapUserToContext(UserDetails arg0, DirContextAdapter arg1) {
        // TODO Auto-generated method stub
    }
}
