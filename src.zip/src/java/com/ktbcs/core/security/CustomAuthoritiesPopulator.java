/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.SortedSet;
import org.apache.log4j.Logger;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;

/**
 *
 * @author aon
 */
public class CustomAuthoritiesPopulator implements LdapAuthoritiesPopulator  {
    
    private static final Logger logger = Logger.getLogger(CustomAuthoritiesPopulator.class);
    private String rolePrefix = "ROLE_";

    public Collection<GrantedAuthority> getGrantedAuthorities(DirContextOperations dco, String string){
        Collection<GrantedAuthority> list = new ArrayList<GrantedAuthority>();
        SortedSet roleName = dco.getAttributeSortedStringSet("cn");
      
       try{
            Iterator it = roleName.iterator();
            while (it.hasNext()) {
                list.add(new SimpleGrantedAuthority("ROLE_USER"));
                it.next();
            }
       }catch(Exception e){
           logger.error("Error occur in while process CustomAuthoritiesPopulator.getGrantedAuthorities : " + e.getMessage());
       }
      return list;
    }
    
}
