/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ktbcs.core.security;

import com.ktb.ewsl.business.InOutLogBusiness;
import com.ktb.ewsl.business.KtbOrganizationBusiness;
import com.ktb.ewsl.business.ParameterBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ConfigVO;
import com.ktb.ewsl.vo.KtbOrganization;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktbcs.core.business.UserBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import com.ktbcs.core.utilities.MessageBundle;
import com.ktb.ewsl.vo.RoleVo;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.security.KeyPair;
import java.util.ArrayList;
import java.util.Map;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Processes an authentication form.
 * <p>Login forms must present two parameters to this filter: a username and
 * password. The default parameter names to use are contained in the static
 * fields {@link #SPRING_SECURITY_FORM_USERNAME_KEY} and
 * {@link #SPRING_SECURITY_FORM_PASSWORD_KEY}. The parameter names can also be
 * changed by setting the <tt>usernameParameter</tt> and
 * <tt>passwordParameter</tt>
 * properties.
 *
 * @author Ben Alex
 * @author Colin Sampaleanu
 * @version $Id: AuthenticationProcessingFilter.java 3033 2008-05-05 18:37:02Z
 * luke_t $
 */
public class CustomAuthenticationProcessingFilter extends UsernamePasswordAuthenticationFilter {
    //~ Static fields/initializers =====================================================================================

    private static final Logger logger = Logger.getLogger(CustomAuthenticationProcessingFilter.class);
    public static final String SPRING_SECURITY_FORM_JCRYPTION_KEY = "jCryption";
    public static final String SESSION_KEY = "jCryptionKeys";
    private String usernameParameter = SPRING_SECURITY_FORM_USERNAME_KEY;
    private String passwordParameter = SPRING_SECURITY_FORM_PASSWORD_KEY;
    private String jkCryptionParameter = SPRING_SECURITY_FORM_JCRYPTION_KEY;
    private static final String DEFAULT_FILTER_PROCESSES_URL = "/jsp/login.jsp";
    @Autowired
    private UserBusiness userBusiness;
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    @Autowired
    private KtbOrganizationBusiness ktbOrganizationBusiness;
    @Autowired
    private InOutLogBusiness inOutLogBusiness;
    @Autowired
    private ParameterBusiness parameterBusiness;
  
    public CustomAuthenticationProcessingFilter() {
        super();
    }

     
    //~ Methods ========================================================================================================
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        String username = obtainUsername(request);
        String password = obtainPassword(request);
        String jCryption = obtainjkCryption(request);
        String pathForm = "normalURL";

//        String image = request.getParameter("image");
//        String email = request.getParameter("email");
          String uid = request.getParameter("uid");

        if (username == null) {
            username = "";
        }

        if (password == null) {
            password = "";
        }

        username = username.trim();

        Jcryption jc = new Jcryption();
        KeyPair keys = (KeyPair) request.getSession().getAttribute(SESSION_KEY); //Get Key จาก session


        // decrypt
        if (jCryption != null && keys != null) {
            try {
                String data = jc.decrypt(jCryption, keys);

                //Fix 2012-08-15 trim first 2 excess strings
                if (data != null && data.length() > 2) {
                    data = data.substring(2, data.length());
                }

                if (request.getSession(false) != null) {
                    request.getSession(false).removeAttribute(BusinessConst.Session.LOGIN_KEY);
                    request.getSession(false).invalidate();
                }

                Map params = Jcryption.parse(data, "utf-8");//ถอดรหัส
                username = (String) params.get(usernameParameter);
                password = (String) params.get(passwordParameter);
            } catch (Throwable e) {
                logger.error("Error occur in while process attemptAuthentication : " + e.getMessage());
            }
        }

        UsernamePasswordAuthenticationToken authRequest = null;
        if ("ewsportaladmin".equals(username)) {
            pathForm = "portalURL";
            username = uid;            
            authRequest = new UsernamePasswordAuthenticationToken("ewsportaladmin", "portaladmin");
        } else {
            authRequest = new UsernamePasswordAuthenticationToken(username, password);
        }

        // Place the last username attempted into HttpSession for views
        HttpSession session = request.getSession(false);

        if (session != null || getAllowSessionCreation()) {
            request.getSession().setAttribute(SPRING_SECURITY_LAST_USERNAME_KEY, username);
            request.getSession().setAttribute(BusinessConst.Session.URL_FROM_SESSION, pathForm); //---ANN 31/08/2558
        }

        // Allow subclasses to set the "details" property
        setDetails(request, authRequest);

        Authentication authen = null;
        try {

            try {
                /**
                 * **** LDAP Authentication *****
                 */
                authen = this.getAuthenticationManager().authenticate(authRequest);
            } catch (AuthenticationException ae) {
                String errorMessage = MessageBundle.getMessage("login.insufficient.authentication.user.ldap");
                UserData userError = new UserData();
                userError.setEmpNo(username);
                insertCanNotAccessSystenCase(userError, request, session, errorMessage);
                throw new BusinessException(errorMessage);
            }

            UserData user = null;
            if ("ewsladmn".equals(username)) {
                user = assingSystemUser();
            } else if (EWSConstantValue.USER_EWS_ENVIROMENT.equals(username)) {
                user = assingForEnvUser();
            } else {
                /**
                 * **** Telephone book *****
                 */
                user = ktbEmpDirectoryBusiness.findById(username);
                if (user == null) {
                    String errorMessage = MessageBundle.getMessage("login.insufficient.authentication.user");
                     UserData userError = new UserData();
                     userError.setEmpNo(username);
                    insertCanNotAccessSystenCase(userError, request, session, errorMessage);
                    throw new BusinessException(errorMessage);
                }
                  /** **** Check User Login per Device ******/
                ParameterVo parameterVo = parameterBusiness.findByParamIdAndParamType("USER_LOGIN", "FLAG_CHECK");
                 if (parameterVo != null && BusinessConst.Flag.Y.equals(parameterVo.getValue3())) {
                     if (!ValidatorUtil.isNullOrEmpty(user.getEmpNo())) {
                        inOutLogBusiness.checkAndKickOfUserInOutLog(user.getEmpNo(), request.getHeader("X-FORWARDED-FOR") , request.getRemoteAddr());
                    }
                 }


                /**
                 * **** Role in System *****
                 */
                ArrayList<RoleVo> roleVOList = userBusiness.findUserRoleAndCheckCondition(user);  // userBusiness.findUserRole(user);
                if (roleVOList == null || roleVOList.isEmpty()) {
                    String errorMessage = MessageBundle.getMessage("login.insufficient.authentication");
                      insertCanNotAccessSystenCase(user, request, session, errorMessage);
                    throw new BusinessException(errorMessage);
                }
                if(roleVOList.size() > 1){
                    ArrayList<UserData.Authorize> authorizeList = new ArrayList<UserData.Authorize>();
                    for (RoleVo roleVO : roleVOList) {
                        UserData.Authorize item = new UserData.Authorize();
                        item.setRoleId(roleVO.getRoleId());
                        item.setRoleDesc(roleVO.getRoleName());
                        authorizeList.add(item);
                    }
                    user.setAuthorizeList(authorizeList);
                    user.setAuthorize(user.getAuthorizeList().get(0));
                }
                RoleVo dataRole = (RoleVo)roleVOList.get(0);
                user.setRoleId(dataRole != null ? dataRole.getRoleId() : "");
                user.setRoleName(dataRole != null ? dataRole.getRoleName() : "");
              
                /**
                 * **** KTB_ORGANIZATION in System for RiskMigrationReport & DPD Split*****
                 */
                if (!ValidatorUtil.isNullOrEmpty(user.getDeptCode()) && !BusinessConst.DATA_DEFAULT.KTB.equals(user.getDeptCode())) {
                    KtbOrganization org = ktbOrganizationBusiness.getOrganizationByCostcenter(user.getDeptCode());
                    if (org != null) {
                        user.setBusinessUnitCode((org.getBusinessUnitCode() != null && org.getBusinessUnitCode() != 0) ? String.valueOf(org.getBusinessUnitCode()) : "");
                        user.setGroupCode((org.getGroupCode() != null && org.getGroupCode() != 0) ? String.valueOf(org.getGroupCode()) : "");
                        user.setDepartmentCode((org.getDepartmentCode() != null && org.getDepartmentCode() != 0) ? String.valueOf(org.getDepartmentCode()) : "");
                    }
                }
            }

             
            user.setUserIP(request.getHeader("X-FORWARDED-FOR"));
            user.setRemoteIp(request.getRemoteAddr());
           /* String ipAddress = request.getHeader("X-FORWARDED-FOR");   // เป็น ip เครื่องที่ F5 forward มา ปกติเครื่อง F5 ของ KTB  จะมีค่านี้มาให้
            user.setUserIP(ipAddress);
            if (ipAddress == null) {
                ipAddress = request.getRemoteAddr();  // กรณีไม่มีค่าจาก F5 ให้เอาจาก Remote Addess เลย มันจะได้ IP ของ F5
                 user.setRemoteIp(ipAddress);
            }*/
            user.setSessionId(session.getId());
            request.getSession().setAttribute(BusinessConst.Session.LOGIN_KEY, user);
            if((user != null)&&(!BusinessConst.UserRole.ADMIN.equals(user.getRoleId()))){
                 inOutLogBusiness.insertInOutLog(user, BusinessConst.ACCESS_SYSTEM.LOGIN_IN , BusinessConst.ACCESS_SYSTEM.LOGIN_SUCCESS);
            }
           

 
        } catch (BusinessException bex) {
            throw new InsufficientAuthenticationException(bex.getMessage());
        } catch (Exception ex) {
            logger.error("Error occur in while process attemptAuthentication : " + ex.getMessage());
            throw new InsufficientAuthenticationException("", ex);
        }

        return authen;
    }

    private UserData assingSystemUser() throws Exception {
        UserData user = null;
        try {
            user = new UserData();
            user.setEmpNo("System");
            user.setEmpNameThai("EWS for SME-L");
            user.setCostCenter(BusinessConst.DATA_DEFAULT.KTB);
            user.setCostCenterDesc("KTB");
            user.setDeptCode("KTB");
            user.setDeptName("KTB");
            user.setRoleAdmin(true);
            user.setRoleId(BusinessConst.UserRole.ADMIN);
            user.setTeamRoleList(null);

        } catch (Exception ex) {
            throw ex;
        }
        return user;
    }

    private UserData assingForEnvUser() throws Exception {
        UserData user = null;
        String empNo = EWSConstantValue.USER_EWS_ENVIROMENT;
        try {
//            ConfigVO configVo = configBusiness.findByConfigGroupAndConfigCode("CALL_FIN", "CIF_NO");
//            if (configVo != null) {
//                empNo = configVo.getConfigValue(); //-- For FIN
//            }
            user = new UserData();
            user.setEmpNo(empNo);
            user.setEmpNameThai(EWSConstantValue.USER_EWS_ENVIROMENT);
            user.setCostCenter(BusinessConst.DATA_DEFAULT.KTB);
            user.setCostCenterDesc("KTB");
            user.setDeptCode("KTB");
            user.setDeptName("KTB");
            user.setRoleAdmin(true);
            user.setRoleId(BusinessConst.UserRole.ADMIN);
            user.setTeamRoleList(null);

        } catch (Exception ex) {
            throw ex;
        }
        return user;
    }

    /**
     * This filter by default responds to
     * <code>/j_spring_security_check</code>.
     *
     * @return the default
     */
    public String getDefaultFilterProcessesUrl() {
        return "/j_spring_security_check";
    }

    protected String obtainjkCryption(HttpServletRequest request) {
        return request.getParameter(getJkCryptionParameter());
    }

    /**
     * @return the jkCryptionParameter
     */
    public String getJkCryptionParameter() {
        return jkCryptionParameter;
    }

    /**
     * @param jkCryptionParameter the jkCryptionParameter to set
     */
    public void setJkCryptionParameter(String jkCryptionParameter) {
        this.jkCryptionParameter = jkCryptionParameter;
    }
    
    private void insertCanNotAccessSystenCase(UserData userData , HttpServletRequest request , HttpSession session , String errorMsg){
        try {
            userData.setUserIP(request.getHeader("X-FORWARDED-FOR"));
            userData.setRemoteIp(request.getRemoteAddr());
            userData.setSessionId(session.getId());
            inOutLogBusiness.insertInOutLog(userData, BusinessConst.ACCESS_SYSTEM.LOGIN_FAIL ,errorMsg);
            
        } catch (Exception ex) {
            logger.error("Error occur in while process insertCanNotAccessSystenCase : " + ex.getMessage());
        }
   }
}
