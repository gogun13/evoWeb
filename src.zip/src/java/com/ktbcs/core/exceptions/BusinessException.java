/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.exceptions;

import com.ktbcs.core.utilities.ErrorLevel;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 *
 * @author Administrator
 */
public class BusinessException extends Exception implements Serializable{

    private ErrorLevel errorLevel;
    private String subCode;
    private int sqlErrorCode;
    private String sqlErrorState;
    private String errorKey;
    private Object[] errorKeyParams = new Object[1];
    private boolean plainMessage;
    // to handle additional info
    private HashMap<String, Object> info = new HashMap<String, Object>();

    /** Creates a new instance of BusinessException */
    public BusinessException() {
    }

    public BusinessException(String message) {
        super(message);
        setPlainMessage(true);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
        setPlainMessage(true);
    }

    public BusinessException(Throwable cause) {
        super(cause);
    }

    public BusinessException(ErrorLevel errorLevel, String message, boolean plainMessage) {
        this(message);
        setErrorLevel(errorLevel);
        setPlainMessage(plainMessage);
    }

    public BusinessException(ErrorLevel errorLevel, Throwable cause) {
        this(cause);
        setErrorLevel(errorLevel);
    }

    public BusinessException(ErrorLevel errorLevel, String errorKey, Object[]... keyParams) {
        this(errorKey);
        setErrorLevel(errorLevel);
        setErrorKey(errorKey);
        setErrorKeyParams(keyParams);
    }

    public BusinessException(ErrorLevel errorLevel, String message, Throwable cause) {
        this(message, cause);
        setErrorLevel(errorLevel);
    }


    public String getErrorKey() {
        return errorKey;
    }

    public void setErrorKey(String errorKey) {
        this.errorKey = errorKey;
    }

    public ErrorLevel getErrorLevel() {
        return errorLevel;
    }

    public void setErrorLevel(ErrorLevel errorLevel) {
        this.errorLevel = errorLevel;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getSubCode() {
        return this.subCode;
    }

    public HashMap<String, Object> getInfo() {
        return info;
    }

    public void setInfo(HashMap<String, Object> info) {
        this.info = info;
    }


    public List<String> getInfoKeys() {
        return new ArrayList(info.keySet());
    }

    public Object[] getErrorKeyParams() {
        return errorKeyParams;
    }

    public void setErrorKeyParams(Object[] errorKeyParams) {
        this.errorKeyParams = errorKeyParams;
    }

    public int getSqlErrorCode() {
        return sqlErrorCode;
    }

    public void setSqlErrorCode(int sqlErrorCode) {
        this.sqlErrorCode = sqlErrorCode;
    }

    public String getSqlErrorState() {
        return sqlErrorState;
    }

    public void setSqlErrorState(String sqlErrorState) {
        this.sqlErrorState = sqlErrorState;
    }

    public boolean isPlainMessage() {
        return plainMessage;
    }

    public void setPlainMessage(boolean plainMessage) {
        this.plainMessage = plainMessage;
    }

    @Override
    public String toString() {
        StringBuilder bf = new StringBuilder();
        bf.append("BusinessException:");
        bf.append("errorKey:").append(getErrorKey()).append(", ");
        bf.append("errorKeyParams:").append(getErrorKeyParams()).append(", ");
        bf.append("errorLevel:").append(getErrorLevel()).append(", ");
        bf.append("sqlErrorCode:").append(getSqlErrorCode()).append(", ");
        bf.append("sqlErrorState:").append(getSqlErrorState()).append(", ");
        return bf.toString();
    }
}
