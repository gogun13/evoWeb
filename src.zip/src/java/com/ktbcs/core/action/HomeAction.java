/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.action;

import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import org.apache.log4j.Logger;

/**
 *
 * @author Administrator
 * 
 */
public class HomeAction extends BaseAction{
    private static final Logger logger = Logger.getLogger(HomeAction.class);
    private final String SELECTED_ROLE = "selectRole";
    private UserData currentUser;
    private final String HOME = "home";
    private final String HOME3 = "home3";
    private final String HOME_NEWS = "homeNews";
    private String selectedIndex;
    private String selectedValue;
    
    @Override
    public String success() throws Exception {

        currentUser = super.getCurrentUser();
        if((currentUser != null) &&(EWSConstantValue.USER_EWS_ENVIROMENT.equals(currentUser.getEmpNameThai()))){
           return "env";
        }
        return SUCCESS;
    }

    public String home() throws Exception {

       currentUser = super.getCurrentUser();
        return HOME;
    }
    
    public String homeNews() throws Exception {
        
       currentUser = super.getCurrentUser();
        return HOME_NEWS;
    }

    public String loginSuccess() throws Exception {

        return HOME;
    }
    
     public String debug() {
        return "debug";
    }

    public String toolbar() {
        return "toolbar";
    }

    public String blank() {
        return "blank";
    }
     /**
     * @return the currentUser
     */
    public UserData getCurrentUser() {
        return currentUser;
    }

    /**
     * @param currentUser the currentUser to set
     */
    public void setCurrentUser(UserData currentUser) {
        this.currentUser = currentUser;
    }
    public String home3() throws Exception {

        currentUser = super.getCurrentUser();
        return HOME3;
    }

    public String getSelectedIndex() {
        return selectedIndex;
    }

    public void setSelectedIndex(String selectedIndex) {
        this.selectedIndex = selectedIndex;
    }

    public String getSelectedValue() {
        return selectedValue;
    }

    public void setSelectedValue(String selectedValue) {
        this.selectedValue = selectedValue;
    }

   
     public String selectRole() throws Exception {
        logger.info("Selected role");

        UserData currUser = (UserData) session.get(BusinessConst.Session.LOGIN_KEY);
        if (currUser != null) {
            int index = Integer.parseInt(selectedIndex != null ? selectedIndex : "0");
             logger.info(" index == " + index);
            currUser.setAuthorizeIndex(index);

            if (currUser.getAuthorizeList() != null && currUser.getAuthorizeList().size() > 0 && index < currUser.getAuthorizeList().size()) {
                UserData.Authorize authorize = currUser.getAuthorizeList().get(index);
                logger.info(" index authorize.getRoleId() == " + authorize.getRoleId());
                currUser.setAuthorize(authorize);                
            }
        }
        session.put(BusinessConst.Session.LOGIN_KEY, currUser);
        selectedValue = currUser.getAuthorize().getRoleId();
        currentUser = super.getCurrentUser();
        currentUser.setRoleId(currUser.getAuthorize().getRoleId());

        return SELECTED_ROLE;
    }
}
