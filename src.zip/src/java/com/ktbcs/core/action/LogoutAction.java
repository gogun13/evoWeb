/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.action;


import com.ktb.ewsl.business.InOutLogBusiness;
import com.ktb.ewsl.vo.InOutLogVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;

/**
 *
 * @author aon
 */
public class LogoutAction extends BaseAction {

    private static final Logger logger = Logger.getLogger(LogoutAction.class);
    private final String ROLE = "role";
    private final String LOGOUT = "logout";
    private final String FAIL = "fail";
//    private UMInquiryService umService;
    private String empNo;

   @Autowired
    private InOutLogBusiness inOutLogBusiness;
      
    public String logout() throws Exception {
        logger.info("Logout sucess");
        return SUCCESS;
    }

    @Override
    public String success() throws Exception {
        String forward = SUCCESS;
        try {
              boolean checkPermission = true;
             if(request.getSession().getAttribute(BusinessConst.Session.PERMISSION_ACCESS) != null){
                    String data = (String)request.getSession().getAttribute(BusinessConst.Session.PERMISSION_ACCESS);
                    if("NO_PERMISSION_ACCESS".equals(data)){
                         checkPermission = false;
                    }
              }
             
            UserData currUser = getCurrentUser();
            if(request.getSession().getAttribute(BusinessConst.Session.LOGIN_KEY) != null && checkPermission){
              UserData user = (UserData)request.getSession().getAttribute(BusinessConst.Session.LOGIN_KEY);
                if((user != null)&&(!BusinessConst.UserRole.ADMIN.equals(user.getRoleId()))){
                     InOutLogVo inOutVo = new InOutLogVo();
                     inOutVo.setLogoutStatus(BusinessConst.ACCESS_SYSTEM.LOGOUT_OUT);
                     inOutVo.setLogoutStatusDesc(BusinessConst.ACCESS_SYSTEM.LOGOUT_SUCCESS);
                     inOutVo.setUserId(user.getEmpNo());
                     inOutVo.setUserIP(user.getUserIP());
                     inOutVo.setUpdatedBy(user.getEmpNo());
                     inOutVo.setSessionId(user.getSessionId());
                     inOutVo.setServerIP(user.getRemoteIp());
                     inOutLogBusiness.updateLogout(inOutVo);
                }
            }    

            Authentication auth = SecurityContextHolder.getContext().getAuthentication();

            SecurityContextLogoutHandler securityContextLogoutHandler = new SecurityContextLogoutHandler();
            PersistentTokenBasedRememberMeServices persToken = new PersistentTokenBasedRememberMeServices();

            securityContextLogoutHandler.logout(request, response, auth);
            persToken.logout(request, response, auth);

            SecurityContextHolder.clearContext();
           
            if (currUser != null) {

                if (request.getSession(false) != null) {
                    request.getSession(false).removeAttribute(BusinessConst.Session.LOGIN_KEY);
                    request.getSession(false).removeAttribute(BusinessConst.Session.TITLE_KEY);
                    request.getSession(false).removeAttribute(BusinessConst.Session.WARNING_TYPE_SESSION_KEY);
                    request.getSession(false).removeAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
                    request.getSession(false).removeAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
                    request.getSession(false).removeAttribute(BusinessConst.Session.RISK_MIGRATION_SEARCH_ALL_CIF);
                    request.getSession(false).removeAttribute("NOSESSION");
                    request.getSession(false).removeAttribute(BusinessConst.Session.URL_FROM_SESSION);
                    request.getSession(false).removeAttribute(BusinessConst.Session.PERMISSION_ACCESS);
                    
                    request.getSession(false).invalidate();
                    logger.info("Login sucess");
                }
            }
            
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        System.out.println(" forward ==>>>" +forward);
        return forward;
    }

    public String logoutManual() throws Exception {
        UserData currUser = getCurrentUser();

        return SUCCESS;
    }
    /**
     * @return the empNo
     */
    public String getEmpNo() {
        return empNo;
    }

    /**
     * @param empNo the empNo to set
     */
    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }
}
