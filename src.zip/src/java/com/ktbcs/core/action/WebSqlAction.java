/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.action;

import com.ktbcs.core.business.SpecialAdminBusiness;
import com.ktb.ewsl.utilities.SpecialAdminService;
import com.ktb.ewsl.utilities.SpecialAdminServiceUtil;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktbcs.core.vo.SpecialAdminVo;
import com.ktbcs.core.utilities.ExportUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.ItemObject;
import com.ktbcs.core.vo.ReportExcelObject;
import com.ktbcs.core.vo.SearchBean;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class WebSqlAction extends BaseAction {

    private static final Logger logger = Logger.getLogger(WebSqlAction.class);

    @Autowired
    private SpecialAdminBusiness specialAdminBusiness;

    private SpecialAdminService spService = new SpecialAdminService();
    private Vector sqlVector;

    private Vector connectionList;
    private String connectionName;
    private String sqlStatement;
    private String executeMode;
    private String message;
    private Vector headerTable;
    private Vector headerTypeList;
    private Vector detailTable;

    private long dataSize;
    private boolean updateFlag;
    private SearchBean searchBean;
    private InputStream fileStream;
    private String exportFileName;

    @Override
    public String success() throws Exception {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("Entry to............. WebSqlAction.success");
            }
            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            clear();
        } catch (Exception ex) {
            throw ex;
        }

        return SUCCESS;
    }

    public String executeSQLCommand() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("Entry to............. WebSqlAction.executeSQLCommand");
        }
        try {
            logger.info("executeMode =" + getExecuteMode());
            if (searchBean != null) {
                String conntName = getSearchBean().getTextSearch() != null ? getSearchBean().getTextSearch() : "";
                boolean inquiryMode = (SpecialAdminServiceUtil.parseString(getExecuteMode()).equals("I"));
                String sqlStatement1 = SpecialAdminServiceUtil.parseString(getSqlStatement());
                //----Validate
                logger.info(" inquiryMode >>" + inquiryMode );
                String statementSelect = "SELECT";
                String statementInsert = "INSERT";
                String statementUpdate = "UPDATE";
                String statementDelete = "DELETE";
                if(getExecuteMode() == null){
                    throw new Exception("กรุณาเลือก Radio Button"); 
                }
                if("U".equals(getExecuteMode())){
                      if(sqlStatement1.toUpperCase().indexOf(statementInsert) < 0 &&
                               sqlStatement1.toUpperCase().indexOf(statementUpdate) < 0 &&
                                  sqlStatement1.toUpperCase().indexOf(statementDelete) < 0 ){
                          throw new Exception("เลือก Radio Button ไม่ถูกต้อง"); 
                      }
                }else{
                     if(sqlStatement1.toUpperCase().indexOf(statementSelect) < 0  ){
                          throw new Exception("เลือก Radio Button ไม่ถูกต้อง"); 
                      }
                }
                StringBuilder totalMessage = new StringBuilder();
                long totalResult = 0;
                if (!"OTHER".equals(conntName)) {
                    StringTokenizer strToken = new StringTokenizer(sqlStatement1, ";");
                    while (strToken.hasMoreElements()) {
                        String sql = SpecialAdminServiceUtil.parseString(strToken.nextToken());
                        if (sql.toUpperCase().equals("COMMIT")){
                            continue;
                        }
                        
                        SpecialAdminVo specialAdminVo = specialAdminBusiness.queryData(sql, inquiryMode, conntName);
                        if (specialAdminVo != null) {
                            Vector headerTable1 = specialAdminVo.getHeaderList();
                            if (headerTable1 == null) {
                                headerTable1 = new Vector();
                            }
                            Vector dataTable1 = specialAdminVo.getDataList();
                            if (dataTable1 == null) {
                                dataTable1 = new Vector();
                            }

                            totalMessage.append(SpecialAdminServiceUtil.parseString(specialAdminVo.getMessage())).append("\n");

                            setHeaderTable(headerTable1);
                            if (inquiryMode) {
                                setDetailTable(dataTable1);
                            } else {
                                addDetailTable(dataTable1);
                            }
                            setMessage(totalMessage.toString());
                            setDataSize(totalResult += dataTable1.size());
                        }
                    }
                } else {
                    String urlDB = getSearchBean().getUrlName() != null ? getSearchBean().getUrlName() : "";
                    String userDB = getSearchBean().getUserDB() != null ? getSearchBean().getUserDB() : "";
                    String passwordDB = getSearchBean().getPwdDB() != null ? getSearchBean().getPwdDB() : "";
                    String dbDriver = getSearchBean().getDbDriver() != null ? getSearchBean().getDbDriver() : "";
                    if (!ValidatorUtil.isNullOrEmpty(conntName)) {
                        getConnection(conntName, urlDB, userDB, passwordDB, dbDriver, inquiryMode);
                        StringTokenizer strToken = new StringTokenizer(sqlStatement1, ";");

                        while (strToken.hasMoreElements()) {
                            String sql = SpecialAdminServiceUtil.parseString(strToken.nextToken());

                            if (sql.toUpperCase().equals("COMMIT")) {
                                System.out.println("=============== Commit ===============");
                                setMessage("");
                                if (spService != null) {
                                    spService.commit();
                                    setUpdateFlag(spService.hasUpdate());
                                    setMessage(spService.getMessage());
                                }
                            } else {

                                spService.execute(sql, inquiryMode);
                                if (spService != null) {
                                    Vector headerTable1 = spService.getHeaderList();
                                    if (headerTable1 == null) {
                                        headerTable1 = new Vector();
                                    }
                                    Vector dataTable1 = spService.getDataList();
                                    if (dataTable1 == null) {
                                        dataTable1 = new Vector();
                                    }

                                    totalMessage.append(SpecialAdminServiceUtil.parseString(spService.getMessage())).append("\n");

                                    setHeaderTable(headerTable1);
                                    if (inquiryMode) {
                                        setDetailTable(dataTable1);
                                    } else {
                                        addDetailTable(dataTable1);
                                    }
                                    setMessage(totalMessage.toString());
                                    setDataSize(totalResult += dataTable1.size());
                                    setUpdateFlag(spService.hasUpdate());
                                }
                            }
                        }
                        setMessage("");
                        if (spService != null) {
                            spService.commit();
                            setUpdateFlag(spService.hasUpdate());
                            setMessage(spService.getMessage());
                        }
                    }
                }
            }

        } catch (Exception ex) {
            logger.error("Error: " + ex.getMessage(), ex);
            setMessage(ex.getClass().getName() + ": " + ex.getMessage());
        }
        return LIST;
    }

    public String executeCommit() throws Exception {
        try {
            if (spService != null) {
                spService.commit();
                setUpdateFlag(spService.hasUpdate());
                setMessage(spService.getMessage());
            }
        } catch (Exception ex) {
            setMessage(ex.getClass().getName() + ": " + ex.getMessage());
        }
        return SUCCESS;
    }

    public String executeRollback() throws Exception {
        try {
            setMessage("");
            if (spService != null) {
                spService.rollBack();
                setUpdateFlag(spService.hasUpdate());
                setMessage(spService.getMessage());
            }
        } catch (Exception ex) {
            setMessage(ex.getClass().getName() + ": " + ex.getMessage());
        }
        return SUCCESS;
    }

    public String clearAllData() throws Exception {
        clear();
        return SUCCESS;
    }

    public String exportData() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("Entry to............. WebSqlAction.exportData");
        }
        String status = SUCCESS;
        try {
            logger.info("exportData =" + getExecuteMode());
            if (searchBean != null) {
                String conntName = getSearchBean().getTextSearch() != null ? getSearchBean().getTextSearch() : "";
                String urlDB = getSearchBean().getUrlName() != null ? getSearchBean().getUrlName() : "";
                String userDB = getSearchBean().getUserDB() != null ? getSearchBean().getUserDB() : "";
                String passwordDB = getSearchBean().getPwdDB() != null ? getSearchBean().getPwdDB() : "";
                String dbDriver = getSearchBean().getDbDriver() != null ? getSearchBean().getDbDriver() : "";
                if (!ValidatorUtil.isNullOrEmpty(conntName)) {
                    boolean inquiryMode = true;
                    getConnection(conntName, urlDB, userDB, passwordDB, dbDriver, inquiryMode);
                    String sqlStatement1 = SpecialAdminServiceUtil.parseString(getSqlStatement());
                    StringTokenizer strToken = new StringTokenizer(sqlStatement1, ";");
                    StringBuilder totalMessage = new StringBuilder();
                    long totalResult = 0;

                    while (strToken.hasMoreElements()) {
                        String sql = SpecialAdminServiceUtil.parseString(strToken.nextToken());

                        if (sql.toUpperCase().equals("COMMIT")) {
                            setMessage("Invalid SQL::");
                        } else {

                            spService.execute(sql, inquiryMode);
                            if (spService != null) {
                                Vector headerTable1 = spService.getHeaderList();
                                if (headerTable1 == null) {
                                    headerTable1 = new Vector();
                                }
                                Vector dataTable1 = spService.getDataList();
                                if (dataTable1 == null) {
                                    dataTable1 = new Vector();
                                }

                                totalMessage.append(SpecialAdminServiceUtil.parseString(spService.getMessage())).append("\n");

                                setHeaderTable(headerTable1);
                                if (inquiryMode) {
                                    setDetailTable(dataTable1);
                                } else {
                                    addDetailTable(dataTable1);
                                }
                                setMessage(totalMessage.toString());
                                setDataSize(totalResult += dataTable1.size());
                                setUpdateFlag(spService.hasUpdate());
                            }
                        }
                    }
                }

            }
            if (getHeaderTable() == null || getHeaderTable().isEmpty()) {
                ArrayList tmpCol = new ArrayList();
                tmpCol.add("No Data");
                Vector tmpRow = new Vector();
                tmpRow.add(tmpCol);
                setHeaderTable(new Vector());
                setDetailTable(tmpRow);
            }

            ArrayList<ReportExcelObject> listSheet = new ArrayList<ReportExcelObject>();
            ReportExcelObject excelObject = new ReportExcelObject();
            excelObject.setExportFileName("ADMIN_EXPORT");
            setExportFileName("ADMIN_EXPORT.xls");
            ArrayList dataList = new ArrayList();
            ItemObject obj;
            ArrayList rowData;
            HashMap map;
            String[] colIndex = null;
            if (!getHeaderTable().isEmpty()) {
                colIndex = new String[getHeaderTable().size()];
            }

            for (int i = 0; i < getHeaderTable().size(); i++) {
                excelObject.setHeaderList(0, i, (String) getHeaderTable().get(i), 0);
                colIndex[i] = ((String) getHeaderTable().get(i)).trim();
                logger.info(getHeaderTable().get(i));
            }

            for (int j = 0; j < getDetailTable().size(); j++) {
                rowData = (ArrayList) getDetailTable().get(j);
                obj = new ItemObject();
                map = new HashMap();
                for (int k = 0; k < rowData.size(); k++) {
                    map.put(colIndex[k], rowData.get(k));
                }
                obj.setDataExcel(map);
                dataList.add(obj);
            }

            excelObject.setSheetName("Admin Export");
            excelObject.getRowValue().add(colIndex);
            excelObject.setListData(dataList);
            listSheet.add(excelObject);

            fileStream = ExportUtil.exportExcel(listSheet);
            status = "export";

        } catch (Exception ex) {
            ex.printStackTrace();
            setMessage(ex.getClass().getName() + ": " + ex.getMessage());
        }
        return status;
    }

    public List<DropdownVo> getExecuteModeList() {
        List<DropdownVo> resultList = new ArrayList<DropdownVo>();
        resultList.add(new DropdownVo("I", "Inquiry"));
        resultList.add(new DropdownVo("U", "Update"));
        return resultList;
    }

    private void getConnection(String connectionName, String url, String user, String password, String dbDriver, boolean inquiryMode) {
        if (logger.isInfoEnabled()) {
            logger.info(String.format("connectionName: %s, url: %s", connectionName, url));
        }
        if (spService == null) {
            spService = new SpecialAdminService();
        }

        String connectionURL = "";
        String connectionUser = "";
        String connectionPass = "";
        boolean connectionMode = true;
        String connectionDriver = "";
        boolean autoCommit = false;

        if (connectionName != null) {
            ResourceBundle rb = ResourceBundle.getBundle("app-config");
            if (connectionName.equals("EWSL")) {
                connectionURL = SpecialAdminServiceUtil.parseString(rb.getString("database.ewsl.jndi"));
                connectionUser = "";
                connectionPass = "";
                connectionMode = true;
                connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.db2"));
            } else if (connectionName.equals("EWSM")) {
                connectionURL = SpecialAdminServiceUtil.parseString(rb.getString("database.ewsm.jndi"));
                connectionUser = "";
                connectionPass = "";
                connectionMode = true;
                connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.oracle"));
            }else if (connectionName.equals("TB")) {               
                connectionURL = SpecialAdminServiceUtil.parseString(rb.getString("database.tbewsl.jndi")); 
                connectionUser = "";
                connectionPass = "";
                connectionMode = true;
                connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.oracle"));
        }else if (connectionName.equals("CR")) {
                connectionURL = SpecialAdminServiceUtil.parseString(rb.getString("database.cr.jndi"));
                connectionUser = "";
                connectionPass = "";
                connectionMode = true;
                connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.db2"));
            }else if (connectionName.equals("TA")) {
                connectionURL = SpecialAdminServiceUtil.parseString(rb.getString("database.ta.jndi"));
                connectionUser = "";
                connectionPass = "";
                connectionMode = true;
                connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.db2"));
            }else if (connectionName.equals("EWSCBC")) {
                connectionURL = SpecialAdminServiceUtil.parseString(rb.getString("database.ewsw.jndi"));
                connectionUser = "";
                connectionPass = "";
                connectionMode = true;
                connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.db2"));
            }else if (connectionName.equals("OTHER")) {
                connectionURL = SpecialAdminServiceUtil.parseString(url);
                connectionUser = SpecialAdminServiceUtil.parseString(user);
                connectionPass = SpecialAdminServiceUtil.parseString(password);
                connectionMode = false;
                if (inquiryMode) {
                    autoCommit = true;
                }
                if ("DB2".equals(dbDriver)) {
                    connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.db2"));
                } else { //--ORACLE
                    connectionDriver = SpecialAdminServiceUtil.parseString(rb.getString("database.driver.oracle"));
                }

            }
        }

        logger.debug("----->" + connectionURL);
        logger.debug("----->" + connectionUser);
        logger.debug("----->" + connectionMode);
        logger.debug("----->" + connectionDriver);

        spService.setupConfig(connectionURL, connectionUser, connectionPass, connectionMode, autoCommit, connectionDriver);
    }

    private void clear() {
        connectionName = "";
        sqlStatement = "";
        executeMode = "I";
        clearData();
    }

    private void clearData() {
        message = "";
        headerTable = new Vector<String>();
        headerTypeList = new Vector();
        detailTable = new Vector();
        dataSize = 0L;
        updateFlag = false;
    }

    // ------------------------
    public Vector getSqlVector() {
        return sqlVector;
    }

    public void setSqlVector(Vector sqlVector) {
        this.sqlVector = sqlVector;
    }

    public Vector getConnectionList() {
        return connectionList;
    }

    public void setConnectionList(Vector connectionList) {
        this.connectionList = connectionList;
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public String getSqlStatement() {
        return sqlStatement;
    }

    public void setSqlStatement(String sqlStatement) {
        this.sqlStatement = sqlStatement;
    }

    public String getExecuteMode() {
        return executeMode;
    }

    public void setExecuteMode(String executeMode) {
        this.executeMode = executeMode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Vector getHeaderTable() {
        return headerTable;
    }

    public void setHeaderTable(Vector headerTable) {
        this.headerTable = headerTable;
    }

    public Vector getHeaderTypeList() {
        return headerTypeList;
    }

    public void setHeaderTypeList(Vector headerTypeList) {
        this.headerTypeList = headerTypeList;
    }

    public Vector getDetailTable() {
        return detailTable;
    }

    public void setDetailTable(Vector detailTable) {
        this.detailTable = detailTable;
    }

    public long getDataSize() {
        return dataSize;
    }

    public void setDataSize(long dataSize) {
        this.dataSize = dataSize;
    }

    public boolean isUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(boolean updateFlag) {
        this.updateFlag = updateFlag;
    }

    public SearchBean getSearchBean() {
        return searchBean;
    }

    public void setSearchBean(SearchBean searchBean) {
        this.searchBean = searchBean;
    }

    public InputStream getFileStream() {
        return fileStream;
    }

    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

    public String getExportFileName() {
        return exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    public void addDetailTable(Vector detail) {
        if (detail != null) {
            if (detailTable == null) {
                detailTable = new Vector();
            }
            for (int i = 0; i < detail.size(); i++) {
                detailTable.add((ArrayList) detail.get(i));
            }
        }
    }
}
