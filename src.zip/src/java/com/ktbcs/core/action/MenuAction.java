/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.action;

import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import java.net.URLEncoder;
import java.util.ArrayList;
import org.apache.log4j.Logger;

/**
 *
 * @author KTBDevLoan
 */
public class MenuAction extends BaseAction {
    
    private static final Logger logger = Logger.getLogger(MenuAction.class);
    private static final String MAIN_MENU = "MainMenu";
    private static final String TAB_MENU = "TabMenu";
    private static final String FORWARD = "forward";
    private static final String TAB_MENU_LEVEL = "tabMenuLevel";
    private String menuId;
    private String menuGroup;
    private String link;
    private String linkParam;
    private String menuLevel;
    private ArrayList<MenuInfoVo> mainMenuList;
    private ArrayList<MenuInfoVo> tabMenuList;
    private String saveBack;
    private ArrayList<MenuLevelVo> menuSepLevelList;
    private int fromMenuLevel;
    private int toMenuLevel;
    private boolean clickFromMain;

    public String forward() throws Exception {
        try {
            UserData user = getCurrentUser();
            user.setCurrentMenuId(menuId);
            user.setCurrentMenuGroup(menuGroup);

            if (link == null || "".equals(link)) {
                logger.info("Find action name of first child.");
                MenuInfoVo menu = menuBusiness.getFirstChild(menuId, user.getAuthorize().getRoleId(), menuGroup);
                if (menu != null && menu.getActionName() != null && !"".equals(menu.getActionName())) {
                    link = menu.getLink();
                    user.setCurrentMenuId(menu.getMenuId());
                    user.setCurrentMenuGroup(menu.getMenuGroup());

                    menuId = menu.getMenuId();
                    menuGroup = menu.getMenuGroup();
                } else {

                    link = "taskList.action?";
                }
            }
            if (link != null && !"".equals(link) && linkParam != null && !"".equals(linkParam)) {
                String tmp = StringUtil.Right(link, 1);

                if ("?".equals(tmp) || "&".equals(tmp)) {
                    link = link.concat(linkParam);
                } else {
                    if (link.indexOf("?") > 0) {
                        link = link.concat("&".concat(linkParam));
                    } else {
                        link = link.concat("?".concat(linkParam));
                    }
                }
            }

            if (menuId != null && !"".equals(menuId) && menuGroup != null && !"".equals(menuGroup)) {
                String tmp = StringUtil.Right(link, 1);
                
                if ("?".equals(tmp) || "&".equals(tmp)) {
                    link = link.concat("menuId=").concat(menuId);
                    link = link.concat("&menuGroup=").concat(menuGroup);
                } else {
                    if (link.indexOf("?") > 0) {
                        link = link.concat("&menuId=").concat(menuId);
                        link = link.concat("&menuGroup=").concat(menuGroup);
                    } else {
                        link = link.concat("?menuId=").concat(menuId);
                        link = link.concat("&menuGroup=").concat(menuGroup);
                    }
                }
            }

            MenuInfoVo backLink = new MenuInfoVo();
            backLink.setLink(link);
            backLink.setMenuId(menuId);
            backLink.setMenuGroup(menuGroup);
            backLink.setLinkParam(linkParam);
            getCurrentUser().addMenuHist(backLink);

            if (saveBack != null && "1".equals(saveBack)) {
                getCurrentUser().saveBackPage();
            }
            if (clickFromMain) {
                getCurrentUser().setBackPage(null);
            }
        } catch (Exception ex) {
            throw ex;
        }

        return FORWARD;
    }

    public String back() throws Exception {
        MenuInfoVo backMenu = getCurrentUser().getBackPage();

        String origLink = URLEncoder.encode(backMenu.getLink(), "UTF-8");
        link = "/menu.action?command=forward&link=" + origLink + "&menuId=" + backMenu.getMenuId() + "&menuGroup=" + backMenu.getMenuGroup();
        getCurrentUser().setBackPage(null);
        return BACK;
    }

    public String tabMenu() throws Exception {
        return TAB_MENU;
    }

    public String loadMainMenu() throws Exception {

        try {
            UserData user = getCurrentUser();

            mainMenuList =  menuBusiness.getMainMenu(user);
        } catch (Exception ex) {
            throw ex;
        }
        return MAIN_MENU;
    }

    public String loadTabMenu() throws Exception {
        try {
            UserData user = getCurrentUser();

        } catch (Exception ex) {
            throw ex;
        }

        return TAB_MENU;
    }

  public String getMenuLevelBetween() throws Exception {
        try {
            UserData user = getCurrentUser();
            if (menuGroup != null && !"".equals(menuGroup)) {
                user.setCurrentMenuGroup(menuGroup);
            }
            ArrayList<MenuLevelVo> menuLvList = super.getMenuLevelList();
            if (fromMenuLevel > 0 && toMenuLevel > 0 && menuLvList != null) {
                ArrayList<MenuLevelVo> newMenuLvList = new ArrayList<MenuLevelVo>();
                MenuLevelVo[] newArrMenuLvList = menuLvList.toArray(new MenuLevelVo[menuLvList.size()]);
                int tmp = 0;
                for (int i = 0; i < newArrMenuLvList.length; i++) {
                    tmp = i + 1;
                    if (tmp >= fromMenuLevel && tmp <= toMenuLevel) {
                        newMenuLvList.add(newArrMenuLvList[i]);
                    }
                }
                setMenuSepLevelList(newMenuLvList);
            } else {
                setMenuSepLevelList(menuLvList);
            }

        } catch (Exception ex) {
            throw ex;
        }
        return TAB_MENU_LEVEL;
    }

    public String success() {

        return SUCCESS;
    }

    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }

    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    /**
     * @return the menuLevel
     */
    public String getMenuLevel() {
        return menuLevel;
    }

    /**
     * @param menuLevel the menuLevel to set
     */
    public void setMenuLevel(String menuLevel) {
        this.menuLevel = menuLevel;
    }

    /**
     * @return the mainMenuList
     */
    public ArrayList<MenuInfoVo> getMainMenuList() {
        return mainMenuList;
    }

    /**
     * @param mainMenuList the mainMenuList to set
     */
    public void setMainMenuList(ArrayList<MenuInfoVo> mainMenuList) {
        this.mainMenuList = mainMenuList;
    }

    /**
     * @return the tabMenuList
     */
    public ArrayList<MenuInfoVo> getTabMenuList() {
        return tabMenuList;
    }

    /**
     * @param tabMenuList the tabMenuList to set
     */
    public void setTabMenuList(ArrayList<MenuInfoVo> tabMenuList) {
        this.tabMenuList = tabMenuList;
    }


    /**
     * @return the link
     */
    public String getLink() {
        return link;
    }

    /**
     * @param link the link to set
     */
    public void setLink(String link) {
        this.link = link;
    }

    /**
     * @return the linkParam
     */
    public String getLinkParam() {
        return linkParam;
    }

    /**
     * @param linkParam the linkParam to set
     */
    public void setLinkParam(String linkParam) {
        this.linkParam = linkParam;
    }

    /**
     * @return the menuGroup
     */
    public String getMenuGroup() {
        return menuGroup;
    }

    /**
     * @param menuGroup the menuGroup to set
     */
    public void setMenuGroup(String menuGroup) {
        this.menuGroup = menuGroup;
    }

    /**
     * @return the saveBack
     */
    public String getSaveBack() {
        return saveBack;
    }

    /**
     * @param saveBack the saveBack to set
     */
    public void setSaveBack(String saveBack) {
        this.saveBack = saveBack;
    }

    /**
     * @return the fromMenuLevel
     */
    public int getFromMenuLevel() {
        return fromMenuLevel;
    }

    /**
     * @param fromMenuLevel the fromMenuLevel to set
     */
    public void setFromMenuLevel(int fromMenuLevel) {
        this.fromMenuLevel = fromMenuLevel;
    }

    /**
     * @return the toMenuLevel
     */
    public int getToMenuLevel() {
        return toMenuLevel;
    }

    /**
     * @param toMenuLevel the toMenuLevel to set
     */
    public void setToMenuLevel(int toMenuLevel) {
        this.toMenuLevel = toMenuLevel;
    }

    /**
     * @return the menuSepLevelList
     */
    public ArrayList<MenuLevelVo> getMenuSepLevelList() {
        return menuSepLevelList;
    }

    /**
     * @param menuSepLevelList the menuSepLevelList to set
     */
    public void setMenuSepLevelList(ArrayList<MenuLevelVo> menuSepLevelList) {
        this.menuSepLevelList = menuSepLevelList;
    }

    /**
     * @return the clickFromMain
     */
    public boolean isClickFromMain() {
        return clickFromMain;
    }

    /**
     * @param clickFromMain the clickFromMain to set
     */
    public void setClickFromMain(boolean clickFromMain) {
        this.clickFromMain = clickFromMain;
    }
    
}
