package com.ktbcs.core.action;

import com.ktb.ewsl.business.InOutLogBusiness;
import com.ktb.ewsl.business.MenuBusiness;
import com.ktb.ewsl.business.ParameterBusiness;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.exceptions.RenowalException;
import com.ktbcs.core.exceptions.ScoreEngineException;
import com.ktbcs.core.exceptions.SessionException;
import com.ktbcs.core.utilities.ErrorLevel;
import com.ktbcs.core.utilities.ValidatorUtil;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 *
 * @author Administrator
 */
public class BaseAction extends ActionSupport implements ServletRequestAware, ServletResponseAware, ServletContextAware, SessionAware {

    private static final Logger logger = Logger.getLogger(BaseAction.class);
    protected static final String ADD = "add";             //Prepare page for Insert
    protected static final String SAVE = "save";           //Commit INSERT
    protected static final String SAVE_DRAFT = "saveDraft";           //SAVE draft
    protected static final String EDIT = "edit";           //Prepare page for Edit
    protected static final String UPDATE = "update";       //Commit Update
    protected static final String DESTROY = "destroy";     //Prepare page for Delete
    protected static final String REMOVE = "remove";       //Commit Delete
    protected static final String VIEW = "view";           //Prepare page for Show or View Mode
    protected static final String LIST = "list";           //Prepare page for display list items
    protected static final String SEARCH = "search";       //Commit Search/Query
    protected static final String PRINT = "print";         //Prepare page for Print
    protected static final String BLANK = "blank";         //Prepare page for Blank page
    protected static final String NEXT = "next";         //Prepare page for Next page
    protected static final String NEXT_MAKER = "nextMaker";         //Prepare page for Next page
    protected static final String NEXT_TASK = "nextTask";         //Prepare page for Next page
    protected static final String BACK = "back";         //Prepare page for Back page
    protected static final String REJECT = "reject";         //Prepare page for Reject page
    protected static final String CANCEL = "cancel";         //Prepare page for Cancel page
    protected static final String ERROR_UNHANDLE = "errorUnhandle";
    protected static final String ERROR_LIST = "errorList";
    protected static final String ERROR_PERMISSION = "errorPermission";
    protected static final String ERROR_BUSINESS = "errorBusiness";
    protected static final String ERROR_WORKFLOW = "errorWorkFlow";
    protected static final String ERROR_SESSION = "errorSession";
    protected static final String ERROR_SCORE_ENGINE = "errorScoreEngine";
    protected static final String ERROR_RENOWAL = "errorRenowal";
    protected static final String INVALID_PARAM = "invalidParam";
    protected static final String FORWARD_MENU = "forwardMenu";
    protected static final String POPUP = "popupResponse";
    private String pageIndex;
    private String pageSize;
    private String command;
    private Method method;
    public HttpServletRequest request;
    public HttpServletResponse response;
    private ServletContext servletContext;
    private boolean chkAll;
    protected List selectedChkBox;
    private UserData currentUser;
    private String currentLoginId;
    private String currentMenuId;
    private String currentLinkParam;
    private String currentLink;
    private String currentMenuGroup;
    protected String mode;
    protected List errorMsgList;
    private HashMap<String, ArrayList<Object>> dropdownList;
    private ArrayList<MenuInfoVo> mainMenuList;
    private ArrayList<MenuLevelVo> menuLevelList;
    private MenuInfoVo firstMenu;
    private boolean isNextTabMenu;
    private boolean isPreviousTabMenu;
    private boolean isForwardTabMenu;
    private ArrayList<String> removeMenuList;
    private String fwMenuId;
    private String currentURLFrom;
    
    @Autowired
    MenuBusiness menuBusiness;
    @Autowired
    private ParameterBusiness parameterBusiness;
    @Autowired
    private InOutLogBusiness inOutLogBusiness;

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getCurrentLoginId() {
        currentLoginId = request.getRemoteUser();
        currentLoginId = (String) session.get(BusinessConst.Session.LOGIN_KEY);
        return currentLoginId;
      //  return "ss";
    }

    public String getCurrentTermId() {
        return request.getRemoteAddr();
    }

    public UserData getCurrentUser() {
        if (currentUser == null) {
            currentUser = (UserData) request.getSession().getAttribute(BusinessConst.Session.LOGIN_KEY);
        }
        return currentUser;
    }

    public void setCurrentUser(UserData currentUser) {
        this.currentUser = currentUser;
    }

    public boolean isChkAll() {
        return chkAll;
    }

    public void setChkAll(boolean chkAll) {
        this.chkAll = chkAll;
    }

    public List getSelectedChkBox() {
        return selectedChkBox;
    }

    public void setSelectedChkBox(List selectedChkBox) {
        this.selectedChkBox = selectedChkBox;
    }

    public BaseAction() {
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    @Override
    public void setServletResponse(HttpServletResponse response) {
        this.response = response;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    protected PaginatedListImpl createPaginate() {
        PaginatedListImpl paginate = new PaginatedListImpl(request.getParameterMap());
        //Zero base index
        //paginate.setIndex(pageIndex == null ? 0 : Integer.parseInt(pageIndex) - 1);
        //One base index
        paginate.setIndex(StringUtils.isEmpty(pageIndex) ? 1 : Integer.parseInt(pageIndex));
        //paginate.setPageSize(pageIndex == null ? paginate.getPageSize() : Integer.parseInt(pageSize));
        return paginate;
    }

    protected PaginatedListImpl createPaginate(int pageSize) {
        PaginatedListImpl paginate = new PaginatedListImpl(request.getParameterMap());
        paginate.setUser(getCurrentUser());
        paginate.setIndex(StringUtils.isEmpty(pageIndex) ? 1 : Integer.parseInt(pageIndex));
        paginate.setPageSize(pageSize);
        return paginate;
    }

    protected PaginatedListImpl genPaginageFromDataList(List dataList) {
        ArrayList pageList = new ArrayList();
        PaginatedListImpl paginage = null;
        paginage = createPaginate();

        //set list to display
        int firstIndex = (paginage.getIndex() - 1) * paginage.getPageSize();
        int lastIndex = (((paginage.getIndex() - 1) * paginage.getPageSize()) + paginage.getPageSize());

        if (lastIndex > dataList.size()) {
            lastIndex = dataList.size();
        }

        if (logger.isDebugEnabled()) {
            logger.debug("firstIndex : " + firstIndex);
            logger.debug("lastIndex : " + lastIndex);
        }

        for (int i = firstIndex; i < lastIndex; i++) {
            pageList.add(dataList.get(i));
        }
        logger.debug("pageList : " + pageList.size());

        paginage.setList(pageList);
        paginage.setFullListSize(dataList.size());

        return paginage;
    }

    @Override
    public String execute() throws Exception {
        String logMessage = "--- call one loop action not include jsp ---";
        UtilTimerStack.push(logMessage);
        String ss = (String)request.getSession().getAttribute("NOSESSION");
        if(ss != null){
            return "session";
        }
         /** **** Check User Login per Device ******/
        if(getCurrentUser() != null && !BusinessConst.UserRole.ADMIN.equals(getCurrentUser().getRoleId())){
            ParameterVo parameterVo = parameterBusiness.findByParamIdAndParamType("USER_LOGIN", "FLAG_CHECK");
            if (parameterVo != null && BusinessConst.Flag.Y.equals(parameterVo.getValue3())) {
             boolean checkPermission = true;
                  if(request.getSession().getAttribute(BusinessConst.Session.PERMISSION_ACCESS) != null){
                  String data = (String)request.getSession().getAttribute(BusinessConst.Session.PERMISSION_ACCESS);
                        if("NO_PERMISSION_ACCESS".equals(data)){
                             checkPermission = false;
                        }
                  }
                  if (getCurrentUser() != null && !ValidatorUtil.isNullOrEmpty(getCurrentUser().getEmpNo()) && checkPermission) {
                        boolean onProcess =  inOutLogBusiness.checkUserLoginBeforeNextProcess(getCurrentUser().getEmpNo(), getCurrentUser().getUserIP() ,  getCurrentUser().getRemoteIp(), getCurrentUser().getSessionId());
                        if(!onProcess){
                              request.getSession().setAttribute(BusinessConst.Session.PERMISSION_ACCESS, "NO_PERMISSION_ACCESS");
                              return "errorPermissionAccess";
                        }

                   }
            }
        }
        /**************************************/
        if (StringUtils.isEmpty(this.getCommand())) {
            if (logger.isDebugEnabled()) {
                logger.debug("Call Default success method");
            }
            command = SUCCESS;
        }
        String[] s = command.split("\\,", -1);
        if(s.length > 1){
            command = s[0];
        }
        
        if((UserData) request.getSession().getAttribute(BusinessConst.Session.LOGIN_KEY) == null){
            logger.debug("No User login");
            return "session";
        }
        if (logger.isInfoEnabled()) {
//            logger.debug("---------------> Requesting URI: " + request.getRequestURI() + "?" + StringUtil.notNull(request.getQueryString()));
            logger.info("---------------> Current command is: " + command);
        }
        String result = null;
        try {
            method = this.getClass().getMethod(command, new Class[0]);
        } catch (Exception ne) {
            logger.error("NoSuchMethodException, invlid calling command value:" + ne);
            result = displayErrorMessage(new Exception("ระบุ command ไม่ถูกต้อง [command=" + command + "]"));
            return result;
        }

        boolean isException = false;
        try {
            result = (String) method.invoke(this, new Object[0]);
        } catch (IllegalAccessException illegalAccessException) {
            logger.error("Error IllegalAccessException :" + illegalAccessException);
            isException = true;
        } catch (IllegalArgumentException illegalArgumentException) {
            logger.error("Error illegalArgumentException :" + illegalArgumentException);
            isException = true;
        } catch (InvocationTargetException invEx) {
            logger.error("Error InvocationTargetException :" + invEx);
            isException = true;
            result = displayErrorMessage(invEx);
        } catch (Exception ne) {
            logger.error("Error Case :", ne);
            isException = true;
            result = displayErrorMessage(ne);
        }

        if (result == null || "".equals(result)) {
            result = SUCCESS;
        }

        if (logger.isInfoEnabled()) {
            logger.info("---------------> Return result is:" + result);
        }
        UtilTimerStack.pop(logMessage);

        if (INVALID_PARAM.equals(result)) {
            isException = true;
        }

        if (!isException) {
            if (isNextTabMenu) {
                getCurrentUser().setCurrentMenuId(getCurrentUser().getNextMenuId());
            } else if (isPreviousTabMenu) {
                getCurrentUser().setCurrentMenuId(getCurrentUser().getPreviousMenuId());
            } else if (currentMenuId != null && !"".equals(currentMenuId)) {
                getCurrentUser().setCurrentMenuId(currentMenuId);
                getCurrentUser().setCurrentMenuGroup(currentMenuGroup);
            }else if (null != request.getParameter("menuId")) { //--EWSL
                getCurrentUser().setCurrentMenuId(request.getParameter("menuId"));
            }

            if (isForwardTabMenu) {
                return FORWARD_MENU;
            }
        }
        return result;
    }

    protected String displayErrorMessage(Exception invEx) {
        String result;
        if (logger.isDebugEnabled()) {
            logger.debug("Error from cause:" + invEx.getCause());
        }
        Exception ex = null;
        if (invEx.getCause() != null) {
            try {
                ex = (Exception) invEx.getCause();
            } catch (Exception eee) {
                ex = invEx;
            }
        } else {
            ex = invEx;
        }

        if (ex instanceof BusinessException) {
            BusinessException bex = (BusinessException) invEx.getCause();
            if (logger.isDebugEnabled()) {
                logger.debug("BusinessException inspection:" + bex.toString());
            }
            if (bex.getSqlErrorCode() == 0) {
                if (StringUtils.isNotEmpty(bex.getErrorKey())) {
                    String errorMessage = getText(bex.getErrorKey());
                    addActionMessage(errorMessage);
                    if (logger.isInfoEnabled()) {
                        logger.info("Business Error by key :" + bex.getErrorKey());
                        logger.info("Business Error message :" + errorMessage);
                    }
                } else {
                    if (logger.isInfoEnabled()) {
                        logger.info("Business Error by plain message :" + ex.getMessage());
                    }
                    addActionMessage(ex.getMessage());
                }
            } else {
                addActionMessage(bex.getSqlErrorCode() + ":" + bex.getMessage());
            }

            if (ErrorLevel.NO_PERMISSION.equals(bex.getErrorLevel())) {
                logger.info("found NO_PERMISSION Exception");
                result = ERROR_PERMISSION;
            } else if (ErrorLevel.BUSINESS_UNHANDLE.equals(bex.getErrorLevel())) {
                logger.info("found BUSINESS_UNHANDLE");
                result = ERROR_UNHANDLE;
            } else if (ErrorLevel.SYSTEM.equals(bex.getErrorLevel())) {
                logger.info("found SYSTEM ERROR");
                result = ERROR_UNHANDLE;
            } else {
                result = ERROR_BUSINESS;
            }
        } else if(ex instanceof SessionException){
            addActionMessage("Session timeout");
            result = ERROR_SESSION;
        } else if(ex instanceof ScoreEngineException){
            addActionMessage(ex.getMessage());
             logger.info("found ScoreEngine SYSTEM ERROR");
            result = ERROR_SCORE_ENGINE;
        }else if(ex instanceof RenowalException){
             logger.info("found Renowal SYSTEM ERROR");
            addActionMessage(ex.getMessage());
            result = ERROR_RENOWAL;
        }else {
            logger.error("Other Exception has occured, the system will not handle this exception:", ex);
            addActionMessage("UnhandleException : " + ex);
            result = ERROR;
        }
        
        return result;
    }

    public String getPageIndex() {
        if (pageIndex == null) {
            pageIndex = "1";
        }
        return pageIndex;
    }

    public void setPageIndex(String pageIndex) {
        this.pageIndex = pageIndex;
    }

    public String getPageSize() {
        return pageSize;
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * *
     * Prepare page for Insert
     *
     * @return
     * @throws java.lang.Exception
     */
    public String add() throws Exception {
        return ADD;
    }

    /**
     * *
     * Commit INSERT
     *
     * @return
     * @throws java.lang.Exception
     */
    public String save() throws Exception {
        return SAVE;
    }

    /**
     * *
     * Prepare page for Edit
     *
     * @return
     * @throws java.lang.Exception
     */
    public String edit() throws Exception {
        return EDIT;
    }

    /**
     * *
     * Commit Update
     *
     * @return
     * @throws java.lang.Exception
     */
    public String update() throws Exception {
        return UPDATE;
    }

    /**
     * *
     * Prepare page for Delete
     *
     * @return
     * @throws java.lang.Exception
     */
    public String destroy() throws Exception {
        return DESTROY;
    }

    /**
     * *
     * Commit Delete
     *
     * @return
     * @throws java.lang.Exception
     */
    public String remove() throws Exception {
        return REMOVE;
    }

    //public abstract String remove() throw Exception;
    // public abstract String success() throws Exception;
    /**
     * *
     * Prepare page for Show or View Mode
     *
     * @return
     * @throws java.lang.Exception
     */
    public String view() throws Exception {
        return VIEW;
    }

    /**
     * *
     * Prepare page for display list items
     *
     * @return
     * @throws java.lang.Exception
     */
    public String list() throws Exception {
        return LIST;
    }

    /**
     * *
     * Commit Search/Query
     *
     * @return
     * @throws java.lang.Exception
     */
    public String search() throws Exception {
        return SEARCH;
    }

    /**
     * *
     * Prepare page for Print
     *
     * @return
     * @throws java.lang.Exception
     */
    public String print() throws Exception {
        return PRINT;
    }

    /**
     * *
     * @ Default action
     *
     * @return
     * @throws java.lang.Exception
     */
    //public abstract String success() throws Exception;
    public String success() throws Exception {
        return SUCCESS;
    }

   protected void loadUserDetails() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String loginId = auth.getName(); //get logged in username

//        try {
//            currentUser = getUserBusiness().getUserDetails(loginId);
//            if (logger.isDebugEnabled()) {
//                logger.debug("loadUserDetails from DB ==> ");
//            }
//        } catch (BusinessException ex) {
//            logger.error("Error when getUserDetails", ex);
//        }
        currentUser = new UserData();
    }

    @Override
    public String getText(String errorKey) {
        if (logger.isDebugEnabled()) {
            logger.debug("Get Bunndle key :" + errorKey);
        }
        return super.getText(errorKey, new String[0]);
    }

    public String getText(String errorKey, String[] params) {
        if (logger.isDebugEnabled()) {
            logger.debug("Get Bunndle key :" + errorKey);
            logger.debug("With Params:" + params);
        }
        return super.getText(errorKey, params);
    }

    /**
     * *
     * @param errorKey : Error key in Property file
     * @param keyParams : Optional , for key parameters
     */
    protected void throwBusinessError(String errorKey, Object... keyParams) throws BusinessException {
        throw new BusinessException(ErrorLevel.BUSINESS, errorKey, keyParams);
    }

    /**
     * *
     * @param errorMessage : plain error messessage
     */
    protected void throwBusinessError(String errorMessage, boolean isPlainMessage) throws BusinessException {
        throw new BusinessException(ErrorLevel.BUSINESS, errorMessage, isPlainMessage);
    }

    /**
     * *
     * BUSINESS_UNHANDLE type of BusinessException, when thrown to
     * View(front-end). Old data in view will be cleared.
     *
     * @param errorMessage
     * @param isPlainMessage
     * @throws com.kcs.core.exceptions.BusinessException
     */
    protected void throwUnhandleBusinessError(String errorMessage, boolean isPlainMessage) throws BusinessException {
        throw new BusinessException(ErrorLevel.BUSINESS_UNHANDLE, errorMessage, isPlainMessage);
    }
    
    public Map<String, Object> session;

    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public List getErrorMsgList() {
        return errorMsgList;
    }

    public void setErrorMsgList(List errorMsgList) {
        this.errorMsgList = errorMsgList;
    }

    /**
     * @return the dropdownList
     */
    public HashMap<String, ArrayList<Object>> getDropdownList() {
        return dropdownList;
    }

    /**
     * @param dropdownList the dropdownList to set
     */
    public void setDropdownList(HashMap<String, ArrayList<Object>> dropdownList) {
        this.dropdownList = dropdownList;
    }


    /**
     * @return the mainMenuList
     */
    public ArrayList<MenuInfoVo> getMainMenuList() throws Exception {
        if (mainMenuList == null) {
            try {
                mainMenuList = menuBusiness.getMainMenu(getCurrentUser());
            } catch (Exception ex) {
                throw ex;
            }
        }

        return mainMenuList;
    }

    /**
     * @param mainMenuList the mainMenuList to set
     */
    public void setMainMenuList(ArrayList<MenuInfoVo> mainMenuList) {
        this.mainMenuList = mainMenuList;
    }

    /**
     * @return the menuLevelList
     */
   public ArrayList<MenuLevelVo> getMenuLevelList() throws Exception {
        if (menuLevelList == null) {
            try {
                if(logger.isDebugEnabled()){
                 logger.debug("getCurrentUser().getCurrentMenuId() = " + getCurrentUser().getCurrentMenuId());
                 logger.debug("getCurrentUser().getRoleId() = " + getCurrentUser().getRoleId());
                 logger.debug("getCurrentUser().getCurrentMenuGroup() = " + getCurrentUser().getCurrentMenuGroup());
                }
                        
                menuLevelList = menuBusiness.getTabMenu(getCurrentUser().getCurrentMenuId(), getCurrentUser().getRoleId(), getCurrentUser().getCurrentMenuGroup());

                if (getRemoveMenuList() != null && !getRemoveMenuList().isEmpty()) {
                    for (MenuLevelVo itemList : menuLevelList) {
                        if (itemList != null && itemList.getMenuInfoList() != null && !itemList.getMenuInfoList().isEmpty()) {
                            ArrayList<MenuInfoVo> tmpRemove = new ArrayList<MenuInfoVo>();
                            for (MenuInfoVo item : itemList.getMenuInfoList()) {
                                for (String remove : getRemoveMenuList()) {
                                    if (item.getMenuId().equals(remove)) {
                                        tmpRemove.add(item);
                                    }
                                }
                            }
                            itemList.getMenuInfoList().removeAll(tmpRemove);
                        }
                    }
                }

                String previousMenuId = null;
                String nextMenuId = null;
                String topTabMenuId = null;
                if (menuLevelList != null) {
                    MenuLevelVo[] tmpMenulLevel = menuLevelList.toArray(new MenuLevelVo[menuLevelList.size()]);
                    for (int i = tmpMenulLevel.length - 1; i > 0; i--) {
                        if (tmpMenulLevel[i] != null && tmpMenulLevel[i].getMenuInfoList() != null) {
                            MenuInfoVo[] tmpMenuList = tmpMenulLevel[i].getMenuInfoList().toArray(new MenuInfoVo[tmpMenulLevel[i].getMenuInfoList().size()]);
                            for (int j = 0; j < tmpMenuList.length; j++) {
                                MenuInfoVo tmpMenu = (MenuInfoVo) tmpMenuList[j];
                                if (tmpMenu != null && BusinessConst.ActiveType.ACTIVE.equals(tmpMenu.getIsCurrent())) {
                                    if (j > 0) {
                                        previousMenuId = tmpMenuList[j - 1].getMenuId();
                                    }
                                    if ((j + 1) < tmpMenuList.length) {
                                        nextMenuId = tmpMenuList[j + 1].getMenuId();

                                        if (tmpMenuList[j + 1].getActionName() == null || "".equals(tmpMenuList[j + 1].getActionName())) {
                                            MenuInfoVo nextMenu = menuBusiness.getFirstChild(nextMenuId, getCurrentUser().getAuthorize().getRoleId(), getCurrentUser().getCurrentMenuGroup());
                                            nextMenuId = nextMenu.getMenuId();
                                        }
                                    }
  getCurrentUser().setCurrentId(tmpMenuList[j].getMenuId());   //EWSL
                                    logger.info("previousMenuId=" + previousMenuId);
                                    logger.info("current=" + tmpMenuList[j].getMenuId());
                                    logger.info("nextMenuId=" + nextMenuId);
                                    break;
                                }
                            }
                        }

                        if (previousMenuId != null || nextMenuId != null) {
                            break;
                        }
                    }

                    if (tmpMenulLevel[0] != null && tmpMenulLevel[0].getMenuInfoList() != null && !tmpMenulLevel[0].getMenuInfoList().isEmpty()) {
                        for (MenuInfoVo tmpMenu : tmpMenulLevel[0].getMenuInfoList()) {
                            if (tmpMenu != null && "1".equals(tmpMenu.getIsCurrent())) {
                                topTabMenuId = tmpMenu.getMenuId();
                                break;
                            }
                        }

                    }
                }

                getCurrentUser().setPreviousMenuId(previousMenuId);
                getCurrentUser().setNextMenuId(nextMenuId);
                getCurrentUser().setTopTabMenuId(topTabMenuId);
                getCurrentUser().setMenuLevelList(menuLevelList);

            } catch (Exception ex) {
                logger.info(ex.getMessage());
                throw ex;
            }
        }
        return menuLevelList;
    }

    /**
     * @param menuLevelList the menuLevelList to set
     */
    public void setMenuLevelList(ArrayList<MenuLevelVo> menuLevelList) {
        this.menuLevelList = menuLevelList;
    }

    /**
     * @return the isNextTabMenu
     */
    public boolean isIsNextTabMenu() {
        return isNextTabMenu;
    }

    /**
     * @param isNextTabMenu the isNextTabMenu to set
     */
    public void setIsNextTabMenu(boolean isNextTabMenu) {
        this.isNextTabMenu = isNextTabMenu;
    }

    /**
     * @return the isPreviousTabMenu
     */
    public boolean isIsPreviousTabMenu() {
        return isPreviousTabMenu;
    }

    /**
     * @param isPreviousTabMenu the isPreviousTabMenu to set
     */
    public void setIsPreviousTabMenu(boolean isPreviousTabMenu) {
        this.isPreviousTabMenu = isPreviousTabMenu;
    }

    /**
     * @return the currentMenuId
     */
    public String getCurrentMenuId() {
        return currentMenuId;
    }

    /**
     * @param currentMenuId the currentMenuId to set
     */
    public void setCurrentMenuId(String currentMenuId) {
       getCurrentUser().setCurrentMenuId(currentMenuId); //------EWSL
        this.currentMenuId = currentMenuId;
    }

    /**
     * @return the isForwardTabMenu
     */
    public boolean isIsForwardTabMenu() {
        return isForwardTabMenu;
    }

    /**
     * @param isForwardTabMenu the isForwardTabMenu to set
     */
    public void setIsForwardTabMenu(boolean isForwardTabMenu) {
        this.isForwardTabMenu = isForwardTabMenu;
    }

    /**
     * @return the currentLinkParam
     */
    public String getCurrentLinkParam() {
        return currentLinkParam;
    }

    /**
     * @param currentLinkParam the currentLinkParam to set
     */
    public void setCurrentLinkParam(String currentLinkParam) {
        this.currentLinkParam = currentLinkParam;
    }

    /**
     * @return the currentLink
     */
    public String getCurrentLink() {
        return currentLink;
    }

    /**
     * @param currentLink the currentLink to set
     */
    public void setCurrentLink(String currentLink) {
        this.currentLink = currentLink;
    }

    /**
     * @return the currentMenuGroup
     */
    public String getCurrentMenuGroup() {
        return currentMenuGroup;
    }

    /**
     * @param currentMenuGroup the currentMenuGroup to set
     */
    public void setCurrentMenuGroup(String currentMenuGroup) {
        getCurrentUser().setCurrentMenuGroup(currentMenuGroup);  //-----EWSL
        this.currentMenuGroup = currentMenuGroup;
    }

    /**
     * @return the removeMenuList
     */
    public ArrayList<String> getRemoveMenuList() {
        return removeMenuList;
    }

    /**
     * @param removeMenuList the removeMenuList to set
     */
    public void setRemoveMenuList(ArrayList<String> removeMenuList) {
        this.removeMenuList = removeMenuList;
    }

    /**
     * @return the backMenu
     */
//    public MenuInfoVo getBackMenu() {
//        return backMenu;
//    }

    /**
     * @param backMenu the backMenu to set
     */
//    public void setBackMenu(MenuInfoVo backMenu) {
//        this.backMenu = backMenu;
//    }

    /**
     * @return the fwMenuId
     */
    public String getFwMenuId() {
        return fwMenuId;
    }

    /**
     * @param fwMenuId the fwMenuId to set
     */
    public void setFwMenuId(String fwMenuId) {
        this.fwMenuId = fwMenuId;
    }

    @Override
    public void setServletContext(ServletContext sc) {
        this.servletContext = sc;
    }

    /**
     * @return the servletContext
     */
    public ServletContext getServletContext() {
        return servletContext;
    }

    /**
     * @return the firstMenu
     */
    public MenuInfoVo getFirstMenu() {
        if (mainMenuList != null && !mainMenuList.isEmpty()) {
            for(MenuInfoVo item:mainMenuList){
                if(item!=null&&item.getActionName()!=null&&!"".equals(item.getActionName())){
                    firstMenu = item;
                    break;
                }
            }
        }
        return firstMenu;
    }

    /**
     * @param firstMenu the firstMenu to set
     */
    public void setFirstMenu(MenuInfoVo firstMenu) {
        this.firstMenu = firstMenu;
    }    

    public String getCurrentURLFrom() {
        if (currentURLFrom == null) {
            currentURLFrom = (String) request.getSession().getAttribute(BusinessConst.Session.URL_FROM_SESSION);
        }
        return currentURLFrom;
    }

    public void setCurrentURLFrom(String currentURLFrom) {
        this.currentURLFrom = currentURLFrom;
    }
    
    
}
