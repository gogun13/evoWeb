/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.action;

import com.ktbcs.core.utilities.BusinessConst;
import static com.opensymphony.xwork2.Action.SUCCESS;
import org.apache.log4j.Logger;

/**
 *
 * @author KTBDevLoan
 */
public class ControlLogViewerAction extends BaseAction {
    
   private static final Logger log = Logger.getLogger(ControlLogViewerAction.class);
   private String serverLogApp;
   private String serverLogWS;
   

    public String getServerLogApp() {
        return serverLogApp;
    }

    public void setServerLogApp(String serverLogApp) {
        this.serverLogApp = serverLogApp;
    }

    public String getServerLogWS() {
        return serverLogWS;
    }

    public void setServerLogWS(String serverLogWS) {
        this.serverLogWS = serverLogWS;
    }
    
   
    
   @Override
    public String success() throws Exception {
        try {
             if(log.isDebugEnabled()){
                log.debug("Entry to............. ControlLogViewerAction.success");
             }
             if(getCurrentUser() == null){
                return "logout";
             }
         
            if( request.getSession().getAttribute(BusinessConst.Session.LOG_PATH) != null){
                 request.getSession().removeAttribute(BusinessConst.Session.LOG_PATH);
            }
            //JBoss log
            String serverLogAppName = System.getProperty("jboss.server.log.dir") + "/server.log";
            String serverLogWSName = System.getProperty("jboss.server.log.dir") + "/application_ewsl.log";
            System.out.println("serverLogAppName = " + serverLogAppName);
            System.out.println("serverLogWSName = " + serverLogWSName);
            setServerLogApp(serverLogAppName);
            setServerLogWS(serverLogWSName);
       
        } catch (Exception ex) {
            throw ex;
        }

        return SUCCESS;
    }
   
    public String openServerLog() throws Exception {
            if( request.getSession().getAttribute(BusinessConst.Session.LOG_PATH) != null){
                 request.getSession().removeAttribute(BusinessConst.Session.LOG_PATH);
            }
          String serverLogAppName = System.getProperty("jboss.server.log.dir") + "/server.log";
         request.getSession().setAttribute(BusinessConst.Session.LOG_PATH, serverLogAppName);
       return "logDisplay";
    }
    
    
    public String openApplicationLog() throws Exception {
         if( request.getSession().getAttribute(BusinessConst.Session.LOG_PATH) != null){
                 request.getSession().removeAttribute(BusinessConst.Session.LOG_PATH);
            }
          String serverLogWSName = System.getProperty("jboss.server.log.dir") + "/application_ewsl.log";
         request.getSession().setAttribute(BusinessConst.Session.LOG_PATH, serverLogWSName);
       return "logDisplay";
    }
}
