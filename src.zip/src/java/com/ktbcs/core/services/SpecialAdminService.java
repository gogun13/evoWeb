/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.services;

import com.ktbcs.core.vo.SpecialAdminVo;

/**
 *
 * @author KTBDevLoan
 */
public interface SpecialAdminService {
    public SpecialAdminVo getData(String sql, String dbName) throws Exception;
    public SpecialAdminVo updateData(String sql, String dbName) throws Exception;
}
