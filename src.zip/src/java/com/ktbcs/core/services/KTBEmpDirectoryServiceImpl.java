/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.services;

import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class KTBEmpDirectoryServiceImpl implements KTBEmpDirectoryService{
    private static Logger logger = Logger.getLogger(KTBEmpDirectoryServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplateTBForEWSL;

    @Override
    public List<UserData> findByFilter(UserData entity) throws Exception {
      logger.debug("Entry to process .....KTBEmpDirectoryServiceImpl.findByFilter");
      List<UserData> result = null;
      try{
        StringBuilder sql = new StringBuilder();
     
         sql.append("  SELECT A.EMP_NO AS EMP_NO , A.EMP_NAME_ENG AS EMP_NAME_ENG , A.EMP_SURNAME_ENG AS EMP_SURNAME_ENG, A.EMP_NAME_THAI  AS EMP_NAME_THAI ,  ");
 	 sql.append("         A.EMP_SURNAME_THAI AS EMP_SURNAME_THAI , A.DEPT_CODE AS DEPT_CODE , A.KTB_FIELD_MAP AS KTB_FIELD_MAP , A.TITLE_NAME_THAI  AS TITLE_NAME_THAI,  ");
         sql.append("         A.EMP_POSITION  AS EMP_POSITION , A.EMPLOYED_STATUS AS EMPLOYED_STATUS, A.JOB_CODE AS JOB_CODE, A.EMP_TO AS EMP_TO , ");
         sql.append("         B.DEPT_CODE AS DEPT_CODE,  B.DEPT_NAME AS DEPT_NAME");
         sql.append("  FROM  tbadm.USER_DETAIL A , tbadm.DEPARTMENT B ");
         sql.append("  WHERE 1=1 ");
         sql.append("  AND A.EMP_NO = '").append(entity.getEmpNo()).append("' ");
         sql.append("  AND A.DEPT_CODE = B.DEPT_CODE ");
         sql.append("  AND A.EMPLOYED_STATUS = 'A' ");
         
         result = (ArrayList)  jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
                    public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
                        UserData user = new UserData();
                        user.setEmpNo(rs.getString("EMP_NO"));
                        user.setEmpNameThai(rs.getString("EMP_NAME_THAI"));
                        user.setEmpSurnameThai(rs.getString("EMP_SURNAME_THAI"));
                        user.setDeptCode(rs.getString("DEPT_CODE"));
                        user.setDeptName(rs.getString("DEPT_NAME"));
                        user.setKtbFieldMap(rs.getString("KTB_FIELD_MAP"));
                        user.setTitleNameThai(rs.getString("TITLE_NAME_THAI"));
                        user.setEmpPosition(rs.getString("EMP_POSITION"));
                        return user;
                    }
                });
      
      }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryServiceImpl.findByFilter: " + e.getMessage() , e);
      }
      return result;
    }

    @Override
    public List searchByEmpName(String nameSearch) throws Exception {
      logger.debug("Entry to process .....KTBEmpDirectoryServiceImpl.searchByEmpName");
      List result = null;
      try{
        StringBuilder sql = new StringBuilder();
        
        sql.append(" SELECT EMP_NO FROM USER_DETAIL ");
        sql.append(" WHERE (TITLE_NAME_THAI || EMP_NAME_THAI || ' ' || EMP_SURNAME_THAI)  LIKE '%").append(nameSearch.trim()).append("%' ");
        sql.append(" AND EMPLOYED_STATUS = 'A'  ");

         result = (ArrayList)  jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
                    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return (String)rs.getString("EMP_NO");
                    }
                });
      }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryServiceImpl.searchByEmpName: " + e.getMessage() , e);
      }
      return result;
    }

    @Override
    public List<UserData> findByRankCode(String rankCode) throws Exception {
       logger.debug("Entry to process .....KTBEmpDirectoryServiceImpl.findByRankCode");
      List<UserData> result = null;
      try{
       StringBuilder sql = new StringBuilder();
       sql.append(" SELECT EMP_NO , TITLE_NAME_THAI , EMP_NAME_THAI ,EMP_SURNAME_THAI  , KTB_FIELD_MAP , DEPT_CODE FROM USER_DETAIL  ");
       sql.append(" WHERE  KTB_FIELD_MAP IN ( ");
       sql.append(rankCode);
       sql.append(" )  AND EMPLOYED_STATUS = 'A'  ORDER BY DEPT_CODE ASC ");

         result = (ArrayList)  jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
                    public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
                        UserData user = new UserData();
                        user.setEmpNo(StringUtil.getValue(rs.getString("EMP_NO")));
                        user.setTitleNameThai(rs.getString("TITLE_NAME_THAI"));
                        user.setEmpNameThai(rs.getString("EMP_NAME_THAI"));
                        user.setEmpSurnameThai(rs.getString("EMP_SURNAME_THAI"));
                        user.setKtbFieldMap(StringUtil.getValue(rs.getString("KTB_FIELD_MAP")));
                        user.setDeptCode(StringUtil.getValue(rs.getString("DEPT_CODE")));
                        return user;
                    }
                });
      
      }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryServiceImpl.findByRankCode: " + e.getMessage() , e);
      }
      return result;
    }

    @Override
    public List<UserData> findByRankCodeAndDeptCode(String rankCode, String responseUnit) throws Exception {
        logger.debug("Entry to process .....KTBEmpDirectoryServiceImpl.findByRankCodeAndDeptCode");
      List<UserData> result = null;
      try{
        StringBuilder sql = new StringBuilder();
     
       sql.append(" SELECT EMP_NO , TITLE_NAME_THAI , EMP_NAME_THAI ,EMP_SURNAME_THAI  , KTB_FIELD_MAP , DEPT_CODE FROM USER_DETAIL  ");
       sql.append(" where  dept_code = '").append(responseUnit.trim()).append("'  and ktb_field_map in ( ");
       sql.append(rankCode);
       sql.append(" )  AND EMPLOYED_STATUS = 'A'  ");

         result = (ArrayList)  jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
                    public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
                        UserData user = new UserData();
                        user.setEmpNo(StringUtil.getValue(rs.getString("EMP_NO")));
                        user.setTitleNameThai(rs.getString("TITLE_NAME_THAI"));
                        user.setEmpNameThai(rs.getString("EMP_NAME_THAI"));
                        user.setEmpSurnameThai(rs.getString("EMP_SURNAME_THAI"));
                        user.setKtbFieldMap(StringUtil.getValue(rs.getString("KTB_FIELD_MAP")));
                        user.setDeptCode(StringUtil.getValue(rs.getString("DEPT_CODE")));
                        return user;
                    }
                });
      
      }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryServiceImpl.findByRankCodeAndDeptCode: " + e.getMessage() , e);
      }
      return result;
    }

    @Override
    public String searchEmpNameById(String empId) throws Exception {
        logger.debug("Entry to process .....KTBEmpDirectoryServiceImpl.searchEmpNameById");
      List result = null;
      try{
        StringBuilder sql = new StringBuilder();
        
        sql.append("SELECT TITLE_NAME_THAI||' '|| EMP_NAME_THAI||' '|| EMP_SURNAME_THAI AS EMP_NAME FROM USER_DETAIL WHERE EMP_NO ='").append(empId).append("' ");

         result = (ArrayList)  jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
                    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return (String)rs.getString("EMP_NAME");
                    }
                });
      }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryServiceImpl.searchEmpNameById: " + e.getMessage() , e);
      }
      if(result !=null &&! result.isEmpty()){
          return (String)result.get(0);
      }else return "";
    }
    
    @Override
    public UserData getUserDetail(String empNo) throws Exception {
      logger.debug("Entry to process .....KTBEmpDirectoryServiceImpl.getUserDetail");
      List<UserData> result         = null;
      UserData       userData       = null;
      
      try{
        StringBuilder sql = new StringBuilder();
     
         sql.append("select CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(t.TITLE_NAME_THAI, '')),''),TRIM(NVL(t.EMP_NAME_THAI, ''))),' '),TRIM(NVL(t.EMP_SURNAME_THAI, ''))) AS FULL_NAME ");
         sql.append(" ,t.* ");
         sql.append(" from tbadm.USER_DETAIL t where t.EMP_NO = '").append(empNo).append("'");
         
         logger.debug("sql :: " + sql.toString());
         
         result = (ArrayList)  jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
                    public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
                        UserData user = new UserData();
                        user.setEmpNo           (rs.getString("EMP_NO"));
                        user.setTitleNameThai   (rs.getString("TITLE_NAME_THAI"));
                        user.setEmpNameThai     (rs.getString("EMP_NAME_THAI"));
                        user.setEmpSurnameThai  (rs.getString("EMP_SURNAME_THAI"));
                        user.setFullName        (StringUtil.getValue(rs.getString("FULL_NAME")));
                        return user;
                    }
                });
         
         if(result!=null && result.size() > 0){
             userData = result.get(0);
         }
      
      }catch(Exception e){
          logger.error("Error occur in while process KTBEmpDirectoryServiceImpl.getUserDetail: " + e.getMessage() , e);
      }
      return userData;
    }

    
    
}
