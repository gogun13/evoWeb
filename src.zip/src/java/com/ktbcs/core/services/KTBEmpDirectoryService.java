/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.services;

import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface KTBEmpDirectoryService {
    
     public List<UserData> findByFilter(UserData entity) throws Exception ;
      
     public List searchByEmpName (String nameSearch) throws Exception ;
     
     public List<UserData> findByRankCode(String rankCode) throws Exception ;
     
     public List<UserData> findByRankCodeAndDeptCode(String rankCode , String responseUnit) throws Exception ;
     
     public String searchEmpNameById (String empId) throws Exception ;
     
     public UserData getUserDetail(String empNo) throws Exception;
}
