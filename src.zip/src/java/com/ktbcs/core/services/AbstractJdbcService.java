/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.services;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * Add Spring JDBCTemplate support
 *
 * @author Administrator
 */
public abstract class AbstractJdbcService {

    private static final Logger logger = Logger.getLogger(AbstractJdbcService.class);
    private static final String _ROWNUM = "rownum";

    @Autowired
    public JdbcTemplate jdbcTemplate;
        
    public String decorateRowNumSQL(String sql, int pageIndex, int pageSize) {
        int startRow = getStartRow(pageIndex, pageSize);
        int endRow = (pageIndex) * pageSize;

//        For Oracle
        StringBuilder bf = new StringBuilder();
        bf.append("select aa.* from (");
        bf.append("select a.*, rownum rr from (");
        bf.append(sql);
        bf.append(")a )aa where rr between ").append(startRow).append(" and ").append(endRow);
        if (logger.isDebugEnabled()) {
            logger.debug("sql:" + sql.toString());
        }
        return bf.toString();
    }
    
     public String decorateRowNumSQLForDB2(String sql, int pageIndex, int pageSize) {
        int startRow = getStartRow(pageIndex, pageSize);
        int endRow = (pageIndex) * pageSize;

//        For DB2
        StringBuilder bf = new StringBuilder();
        bf.append("select abc.* from (");
        bf.append("select ab.*, ROW_NUMBER() OVER() rr from (");
        bf.append(sql);
        bf.append(")ab )abc where rr between ").append(startRow).append(" and ").append(endRow);
        if (logger.isDebugEnabled()) {
            logger.debug("sql:" + sql.toString());
        }
        return bf.toString();
    }

    public int getStartRow(int pageIndex, int pageSize) {
        return ((pageIndex - 1) * pageSize) + 1;
    }
    private static final String PRE_COUNT_SQL = "select count(*) from (";
    private static final String SUF_COUNT_SQL = ") c ";

    public int countTotal(String sql) {
        int count = jdbcTemplate.queryForInt(PRE_COUNT_SQL + sql + SUF_COUNT_SQL);

        if (logger.isDebugEnabled()) {
            logger.debug("count:" + count);
        }
        return count;
    }
    
    public int countTotal(String sql, JdbcTemplate jdbc) {
        int count = jdbc.queryForInt(PRE_COUNT_SQL + sql + SUF_COUNT_SQL);

        if (logger.isDebugEnabled()) {
            logger.debug("count:" + count);
        }
        return count;
    }

    public int countTotal(String sql, Object[] params) {
        int count = 0;
        if (params != null && params.length > 0) {
            count = jdbcTemplate.queryForInt(PRE_COUNT_SQL + sql + SUF_COUNT_SQL, params);
        } else {
            count = countTotal(sql);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("count:" + count);
        }
        return count;
    }

    /**
     * *
     * Get Seq number from dabase's seq
     *
     * @param seqName
     * @return
     */
    public int getNextSeq(String seqName) {
        StringBuilder bf = new StringBuilder();
        bf.append("select ");
        bf.append(seqName);
        bf.append(".nextval from dual");
        if (logger.isDebugEnabled()) {
            logger.debug("NextValSql:" + bf.toString());
        }
        int nextVal = jdbcTemplate.queryForInt(bf.toString());
        if (logger.isDebugEnabled()) {
            logger.debug("NextValResult:" + nextVal);
        }
        return nextVal;
    }

    /**
     * *
     * Get Seq number from PKGEN_TRAN table
     *
     * @param pkKey
     * @return
     */
//    public int getControlNextSeq(String pkKey) {
//        SeqNoGenerator generator = SeqNoGenerator.getInstance();
//        generator.setJdbcTemplate(getJdbcTemplate());
//        int genSeqNo = generator.getSeqNo(pkKey);
//        return genSeqNo;
//    }
    private void printColumnInfo(String table) {

        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(table);

        if (logger.isDebugEnabled()) {
            logger.debug("sql:" + sql.toString());
        }

        List result = jdbcTemplate.query(sql.toString(), new RowMapper() {

            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                Object object = new Object();
                ResultSetMetaData rsm = rs.getMetaData();
                int cnt = rsm.getColumnCount();
                logger.debug("column count:" + cnt);
                for (int i = 1; i <= cnt; i++) {
                    System.out.println(rsm.getColumnName(i) + "= " + rsm.getColumnType(i));
                }
                return object;
            }
        });

        if (logger.isDebugEnabled()) {
            logger.debug("all rows :" + result.size());
        }
    }

    public String getSqlFilterUnit(int ownerUnitId) {
        StringBuilder sql = new StringBuilder();
        if (logger.isDebugEnabled()) {
            logger.debug("sql:" + sql.toString());
        }
        return sql.toString();
    }

//    public void setCustomJdbcTemplate(JdbcTemplate jdbcTemplate) {
//        super.setJdbcTemplate(jdbcTemplate);
//    }
}
