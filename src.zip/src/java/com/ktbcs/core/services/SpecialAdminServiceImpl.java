/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktbcs.core.services;

import com.ktb.ewsl.utilities.SpecialAdminServiceUtil;
import com.ktbcs.core.vo.SpecialAdminVo;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class SpecialAdminServiceImpl  implements SpecialAdminService {

    private static final Logger log = Logger.getLogger(SpecialAdminServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private JdbcTemplate jdbcTemplateTBForEWSL;
    @Autowired
    private JdbcTemplate jdbcTemplateEWSM;
    @Autowired
    private JdbcTemplate jdbcTemplateEWSW;
    @Autowired
    private JdbcTemplate jdbcTemplateCRM;
    @Autowired
    private JdbcTemplate jdbcTemplateTAM;
    
    boolean headerFlag = true;
    Vector headerList = new Vector();
    Vector headerTypeList = new Vector();
    Vector data = new Vector();
    ArrayList detail = new ArrayList();
    String message;

    @Override
    public SpecialAdminVo getData(String sql, String dbName) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("getData Sql >>> " + sql);
        }
        headerFlag = true;
        headerList = new Vector();
        headerTypeList = new Vector();
        data = new Vector();
        detail = new ArrayList();
        message = null;
        
        JdbcTemplate jdbc = jdbcTemplate;
        if("EWSL".equals(dbName)){
            jdbc = jdbcTemplate;
        } else if("EWSM".equals(dbName)){
            jdbc = jdbcTemplateEWSM;
        } else if("EWSCBC".equals(dbName)){
            jdbc = jdbcTemplateEWSW;
        } else if("TB".equals(dbName)){
            jdbc = jdbcTemplateTBForEWSL;
        } else if("CR".equals(dbName)){
            jdbc = jdbcTemplateCRM;
        } else if("TA".equals(dbName)){
            jdbc = jdbcTemplateTAM;
        }
        SpecialAdminVo specialAdminVo = new SpecialAdminVo();
        try {
            jdbc.query(sql, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Object object = new Object();
                    ResultSetMetaData rsm = rs.getMetaData();
                    int resultSize = rsm.getColumnCount();
                    if (headerFlag) {
                        headerFlag = false;
                        for (int i = 1; i <= resultSize; i++) {
                            headerList.add(SpecialAdminServiceUtil.parseString(rsm.getColumnName(i)));
                            headerTypeList.add(SpecialAdminServiceUtil.parseString(rsm.getColumnTypeName(i)));
                        }
                    }
                    
                    for (int i = 1; i <= resultSize; i++) {
                        detail.add(SpecialAdminServiceUtil.parseString(rs.getString(i)));
                    }
                    data.add(detail);
                    detail = new ArrayList();
                    return object;
                }
            });
            
            specialAdminVo.setHeaderList(headerList);
            specialAdminVo.setHeaderTypeList(headerTypeList);
            specialAdminVo.setDataList(data);
        } catch (DataAccessException e) {
            message = " Error!! " + e.getClass().getName() + ":" + e.getMessage();
            specialAdminVo.setMessage(message);
            throw e;
        }
        
        return specialAdminVo;
    }
    
    @Override
    public SpecialAdminVo updateData(String sql, String dbName) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("getData Sql >>> " + sql);
        }
        headerFlag = true;
        headerList = new Vector();
        headerTypeList = new Vector();
        data = new Vector();
        detail = new ArrayList();
        message = null;
        
        JdbcTemplate jdbc = jdbcTemplate;
        if("EWSL".equals(dbName)){
            jdbc = jdbcTemplate;
        } else if("EWSM".equals(dbName)){
            jdbc = jdbcTemplateEWSM;
        } else if("EWSCBC".equals(dbName)){
            jdbc = jdbcTemplateEWSW;
        } else if("TB".equals(dbName)){
            jdbc = jdbcTemplateTBForEWSL;
        } else if("CR".equals(dbName)){
            jdbc = jdbcTemplateCRM;
        } else if("TA".equals(dbName)){
            jdbc = jdbcTemplateTAM;
        }
        SpecialAdminVo specialAdminVo = new SpecialAdminVo();
        try {
            int result = jdbc.update(sql);
            headerList.add("Result");
            headerTypeList.add("VARCHAR");

            detail = new ArrayList();
            detail.add(("" + result));
            data.add(detail);
            
            specialAdminVo.setHeaderList(headerList);
            specialAdminVo.setHeaderTypeList(headerTypeList);
            specialAdminVo.setDataList(data);
        } catch (DataAccessException e) {
            message = " Error!! " + e.getClass().getName() + ":" + e.getMessage();
            specialAdminVo.setMessage(message);
            throw e;
        }
        
        return specialAdminVo;
    }
}
