/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

/**
 *
 * @author KTBDevLoan
 */
public class SpecialAdminServiceUtil {
   public static String parseString(String value)
  {
     String resultValue = value != null && value.trim().length() > 0 ? value.trim() : "";
    return resultValue;
  }

  public static int parseToInt(String numberStr) {
    if (numberStr != null) if ((numberStr = numberStr.trim()).length() > 0)
        try {
          return Integer.parseInt(numberStr);
        } catch (Exception ex) {
        }
    return -1;
  }
}
