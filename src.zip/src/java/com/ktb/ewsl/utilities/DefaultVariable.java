/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
/**
 *
 * @author KTBDevLoan
 */
public class DefaultVariable {
    
    
    /** Creates a new instance of DefaultVariable */
    public DefaultVariable()
    {
        
    }
    
    private static Logger logger = Logger.getLogger(DefaultVariable.class);
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static String encoding(String arg) throws Exception
    {
        if (arg == null)
            return "";
        
        return new String(java.net.URLDecoder.decode(defaultString(arg), "UTF-8").getBytes(), "TIS-620");
    }
    
    /**
     * Check input value is only the number.
     *
     * @author Narin
     * @param arg
     * @return boolean
     */
    public static boolean isNumber(String arg)
    {
        try
        {
            arg = removeComma(arg);
            return arg.matches("[0-9]*");
        }
        catch(Exception e)
        {
            
        }
        return false;
    }
    
    /**
     * Check input value is format the Charecter and Number only.
     *
     * @author Narin
     * @param arg
     * @return boolean
     */
    public static boolean isCharecterNumber(String arg)
    {
        return arg.matches("[a-zA-Z_0-9]*");
    }
    
    /**
     * @author Narin
     * @param arg
     * @return int
     */
    public static int defaultInt(String arg)
    {
        if(!checkFieldIsNotNull(arg)) return 0;
        int val = 0;
        try
        {
            val = Integer.parseInt(arg);
        }
        catch (Exception e)
        {
            
        }
        
        return val;
    }
    
    /**
     * @author Narin
     * @param arg
     * @return int
     */
    public static int defaultInt(Object arg)
    {
        if(arg == null) return 0;
        return defaultInt(String.valueOf(arg));
    }
    
    /**
     * @author Narin
     * @param arg
     * @return int
     */
    public static int defaultInt(double arg)
    {
        return new Double(arg).intValue();
    }
    
    /**
     * @author Narin
     * @param arg
     * @return int
     */
    public static Integer defaultInteger(String arg)
    {
        try
        {
            return new Integer(Integer.parseInt(arg));
        }
        catch (Exception e)
        {
           
        }
        
        return new Integer(0);
    }
    
    /**
     * @author Narin
     * @param arg
     * @return int
     */
    public static Integer defaultIntegerNull(String arg)
    {
        try
        {
            return new Integer(Integer.parseInt(arg));
        }
        catch (Exception e)
        {
            
        }        
        return null;
    }
    
    /**
     * @author Tonkla
     * @param arg
     * @return Double
     */
    public static Double defaultClassDouble(String arg) {
        try {
            return new Double(Double.parseDouble(arg));
        } catch (Exception e) {}
        return new Double(0.00);
    }

    /**
     * @author Tonkla
     * @param arg
     * @return Double
     */
    public static Double defaultClassDoubleNull(String arg) {
        try {
            return new Double(Double.parseDouble(arg));
        } catch (Exception e) {}
        return null;
    }
    
    /**
     * @author Narin
     * @param arg
     * @return Double
     */
    public static double defaultDouble(String arg)
    {
        double val = 0;
        try
        {
            val = Double.parseDouble(arg);
        }
        catch (Exception e)
        {
            
        }
        
        return val;
    }
    
    /**
     * @author Narin
     * @param arg
     * @return Double
     */
    public static long defaultLong(Object arg)
    {
        long val = 0;
        try
        {
            val = Long.parseLong(String.valueOf(arg));
        }
        catch (Exception e)
        {
            
        }
        
        return val;
    }
    
    /**
     * @author Narin
     * @param arg
     * @return Double
     */
    public static long defaultLong(String arg)
    {
        long val = 0;
        try
        {
            val = Long.parseLong(arg);
        }
        catch (Exception e)
        {
            
        }
        
        return val;
    }
    
    /**
     * @author Narin
     * @param arg
     * @return Double
     */
    public static Long defaultLongClass(String arg)
    {
        try
        {
            return new Long(Long.parseLong(arg));
        }
        catch (Exception e)
        {
            
        }
        return new Long(0);
    }
    
    /**
     * @author Narin
     * @param arg
     * @return Double
     */
    public static Long defaultLongClassNull(String arg)
    {
        try
        {
            return new Long(Long.parseLong(arg));
        }
        catch (Exception e)
        {
            
        }        
        return null;
    }
    
    /**
     * @author Narin
     * @param arg
     * @return BigDecimal
     */
    public static BigDecimal defaultBigDecimal(String arg)
    {
        if (!checkFieldIsNotNull(arg))
            return new BigDecimal("0");
        try
        {
            return new BigDecimal(removeComma(arg));
        }
        catch (Exception e)
        {
            logger.error("", e);
            return new BigDecimal("0");
        }
    }
    
    /**
     * @author Narin
     * @param arg
     * @return BigDecimal
     */
    public static BigDecimal defaultBigDecimalNull(String arg)
    {
        if (!checkFieldIsNotNull(arg))
            return null;
        try
        {
            return new BigDecimal(removeComma(arg));
        }
        catch (Exception e)
        {
            logger.error("", e);
            return null;
        }
    }
    
    /**
     * @author Narin
     * @param arg
     * @return BigDecimal
     */
    public static String addFormatMoney(String inArg1, String inArg2) throws Exception
    {
       BigDecimal arg1 = defaultBigDecimal(inArg1);
       BigDecimal arg2 = defaultBigDecimal(inArg2);
       arg1 = arg1.add(arg2);
       return MoneyUtil.formatMoney(arg1);
    }
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static String defaultString(String arg) throws Exception
    {
        if (arg == null)
            return "";
        return defaultNull(arg);
    }
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static String defaultString(Object arg) throws Exception
    {
        if (arg == null)
            return "";
        return defaultNull(String.valueOf(arg));
    }
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static String defaultString(Integer arg) throws Exception
    {
        if (arg == null)
            return "";
        return defaultNull(String.valueOf(arg));
    }
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static String defaultString(int arg) throws Exception
    {
        return defaultNull(Integer.toString(arg));
    }
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static String defaultString(BigDecimal arg) throws Exception
    {
        if (arg == null)
        {
            return "";
        }
        return defaultNull(arg.toString());
    }
    
    /**
     * @author Narin
     * @param arg
     * @return string
     * @throws Exception
     */
    public static String defaultNull(String arg) throws Exception
    {
        if (arg == null)
            return "";
        else if ("null".equals(arg))
            return "";
        else if ("".equals(arg.trim()))
            return "";
        return arg.trim();
    }
    
    /**
     * @author Narin
     * @param Object
     * @return boolean
     */
    public static boolean checkFieldIsNotNull(Object arg)
    {
        if ((arg != null))
            return true;
        return false;
    }
    
    /**
     * rcvStrField != null || 'NULL' || 'null'|| "" || " " return true;
     *
     * @author Narin
     * @param rcvStrField
     * @return boolean
     */
    public static boolean checkFieldIsNotNull(String arg)
    {
        if ((arg != null) && !"".equals(arg.trim()) && !"NULL".equalsIgnoreCase(arg.trim()))
        {
            return true;
        }
        return false;
    }
    
    /**
     * @author Narin
     * @param date
     * @return String
     * @throws Exception
     */
    public static String displayDateFormat(Date date) throws Exception
    {
        return EWSDateUtil.dateFormat(date, EWSDateUtil.FMT_VIEW);
    }
    
    
    
    /**
     * @author Narin
     * @param arg
     * @return boolean
     * @throws Exception
     */
    public static boolean defaultBoolean(String arg) throws Exception
    {
        if (arg != null)
        {
            if (arg.equalsIgnoreCase("true"))
            {
                return true;
            }
            else if (arg.equalsIgnoreCase("false"))
            {
                return false;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    public static boolean defaultBoolean(Boolean arg) throws Exception
    {
        if (arg == null)
            return false;
        return arg.booleanValue();
    }
    
    /**
     * @author Narin
     * @param args
     * @return String
     * @throws Exception
     */
    public static String defaultMoneyAbsolute(String args) throws Exception
    {
        BigDecimal moneyAbsolute = defaultBigDecimal(removeComma(args)).abs();
        return MoneyUtil.formatMoney(moneyAbsolute.toString());
    }
    
    /**
     * @author Narin
     * @param args
     * @return String
     * @throws Exception
     */
    public static String defaultMoneyAbsolute(String args, int fraction) throws Exception
    {
        BigDecimal moneyAbsolute = defaultBigDecimal(removeComma(args)).abs();
        return MoneyUtil.formatMoney(moneyAbsolute.toString(), fraction);
    }
    
    /**
     * @author Narin
     * @param args
     * @return String
     * @throws Exception
     */
    public static String defaultMoney(String args) throws Exception
    {   
        return MoneyUtil.formatMoney(removeComma(args));
    }
    
    /**
     * @author Narin
     * @param args
     * @return String
     * @throws Exception
     */
    public static String removeComma(String args) throws Exception
    {
        return (defaultString(args)).replaceAll(",", "");
    }
    
    /**
     * @author Narin
     * @param arg
     * @return String
     * @throws Exception
     */
    public static Integer StringToInteger(String arg) throws Exception
    {
        if (arg == null)
        {
            return new Integer(0);
        }
        else
        {
            try
            {
                return new Integer(arg);
            }
            catch (Exception e)
            {
                return new Integer(0);
            }
        }
    }
        
    /**
     * @param date :
     * format of time( HH24:MI:SS ) @ return int
     */
    public static int convertSecondOfTime(String date) throws Exception
    {
        if (date == null || "".equals(date) || "-".equals(date) || "0".equals(date) || "null".equalsIgnoreCase(date))
            return 0;
        String[] data = date.split(":");
        return (((Integer.parseInt(data[0]) * 60) * 60) + ((Integer.parseInt(data[1]) * 60) + Integer.parseInt(data[2])));
    }
    
    /**
     * @author narin
     * @param arg
     * @return String GPRS_Bonus, MMS_Bonus, SMS_Bonus, Minute_bundle, Promo_II, ATB
     */
    public static BigDecimal divideFormat(BigDecimal amount, String divisor) throws Exception
    {
        try
        {
            return amount.divide(new BigDecimal(divisor), BigDecimal.ROUND_HALF_UP);
        }
        catch (Exception ex)
        {
            logger.error("", ex);
        }
        return null;
    }
    
    /**
     * @author somnarin
     * @param arg
     * @return BigDecimal
     */
    public static BigDecimal stringToBigDecimal(String arg)
    {
        Number numFormat = null;
        if ((arg == null) || ("".equals(arg)))
        {
            return new BigDecimal(0);
        }
        else
        {
            try
            {
                numFormat = NumberFormat.getInstance().parse(arg);
            }
            catch (ParseException e)
            {
                logger.error("", e);
            }
            return new BigDecimal(numFormat.toString());
        }
    }
    
    /**
     * @author narin
     * @param str
     * @param split
     * @return String[]
     */
    public static String[] splitFile(String str, String split)
    {
        StringTokenizer stoken = new StringTokenizer(str, split);
        String[] temp = new String[stoken.countTokens()];
        int i = 0;
        while (stoken.hasMoreTokens())
        {
            String token = stoken.nextToken();
            temp[i] = token;
            i++;
        }
        return temp;
    }
    
    public static Date StringToDate(String date, String format) throws Exception
    {
        if (format.equalsIgnoreCase("ddmmyyyy"))
        {
            if (date.length() == 8)
            {
                Calendar cal = Calendar.getInstance();
                int dd = StringToInt(date.substring(0, 2));
                int mm = StringToInt(date.substring(2, 4)) - 1;
                int yyyy = StringToInt(date.substring(4, 8));
                cal.set(yyyy, mm, dd);
                return cal.getTime();
            }
            else
            {
                throw new Exception("Date format received is " + date + "---> Date format expected is ddmmyyyy");
            }
        }
        else if (format.equalsIgnoreCase("yyyymmdd"))
        {
            
            if (date.length() == 8)
            {
                Calendar cal = Calendar.getInstance();
                int yyyy = StringToInt(date.substring(0, 4));
                int mm = StringToInt(date.substring(4, 6)) - 1;
                int dd = StringToInt(date.substring(6, 8));
                cal.set(yyyy, mm, dd);
                return cal.getTime();
            }
            else
            {
                throw new Exception("Date format received is " + date + "---> Date format expected is yyyymmdd");
            }
        }
        else if (format.equalsIgnoreCase("dd/mm/yyyy"))
        {
            
            int fromIndex;
            int toIndex;
            String dd;
            String mm;
            String yyyy;
            
            fromIndex = 0;
            toIndex = date.indexOf("/");
            if (toIndex >= 0)
            { // found
                dd = date.substring(fromIndex, toIndex);
                dd = (dd.length() == 1 ? "0" + dd : dd);
                fromIndex = toIndex + 1;
                toIndex = date.indexOf("/", fromIndex);
                if (toIndex >= 0)
                { // found
                    mm = date.substring(fromIndex, toIndex);
                    mm = (mm.length() == 1 ? "0" + mm : mm);
                    fromIndex = toIndex + 1;
                    yyyy = date.substring(fromIndex);
                }
                else
                {
                    throw new Exception("Date format received is " + date + "---> Date format expected is dd/mm/yyyy");
                }
                
            }
            else
            {
                throw new Exception("Date format received is " + date + "---> Date format expected is dd/mm/yyyy");
            }
            
            Calendar cal = Calendar.getInstance();
            int d = StringToInt(dd);
            int m = StringToInt(mm) - 1;
            int y = StringToInt(yyyy);
            
            cal.set(y, m, d);
            return cal.getTime();
        }
        return null;
    }
    
    /**
     * @author narin
     * @param String
     * @return int
     */
    public static int StringToInt(String str)
    {
        try
        {
            return Integer.parseInt(str);
        }
        catch (Exception e)
        {
            logger.error("Error message", e);
            return 0;
        }
    }
       
    /**
     * @author Narin
     * @param String
     *            str
     * @return Boolean
     * @throws Exception
     */    
    public static Boolean stringToBoolean(String str) throws Exception
    {
        if ((str == null) || ("".equals(str)))
        {
            return null;
        }
        else
        {
            return Boolean.valueOf(str.trim());
        }
    }
    
    public static String StrToStrCurrency(String input) throws Exception
    {
        String returnStr = "-";
        try
        {
            double d = Double.parseDouble(input);
            DecimalFormat fmt = new DecimalFormat("#,##0.00");
            returnStr = fmt.format(d);
        }
        catch (Exception e)
        {
            e.getMessage();
        }
        return returnStr;
    }


    public static String bigDecimalToStrCurrency(BigDecimal input) throws Exception
    {
        String returnStr = "-";
        try
        {
            DecimalFormat fmt = new DecimalFormat("#,##0.00");
            returnStr = fmt.format(input);
        }
        catch (Exception e)
        {
            e.getMessage();
        }
        return returnStr;
    }

    
    public static String convertStringToDB(String value) throws Exception
    {
        String result = "";
        if (!checkFieldIsNotNull(value))
        {
            result = "NULL";
        }
        else
        {
            result = "'" + defaultString(value) + "'";
        }
        return result;
    }
    
    public static String convertNumberToDB(String value) throws Exception
    {
        String result = "";
        if (!checkFieldIsNotNull(value))
        {
            result = "NULL";
        }
        else
        {
            result = removeComma(value);
        }
        return result;
    }
    
    
    /*
     * Max date dd/mm/2599
     *
     * @author Narin
     * @param date
     * @param splitter
     * @return boolean - if over 2599, it will return false.
     */
    public static boolean verifyMaxDate(String date, String splitter)
    {
        if(!checkFieldIsNotNull(date) || !checkFieldIsNotNull(splitter)) return false;
        String[] dateArray = date.split(splitter);
        if(defaultInt(dateArray[2]) > 2599 )
        {
            return false;
        }
        return true;
    }
    
    /**
     * Remove token {[0-9]} from Resource.properties [ Application_en.properties or Application_th.properties ]
     * 
     * @author Ness
     * @param arg
     * @return
     */
    public static String convertTokenMessageError(String messageError)
    {
        if(checkFieldIsNotNull(messageError))
        {
            String arg = messageError.replaceAll("\\[\\{[0-9]\\}\\]", "");
            int indexSearch = arg.indexOf(":");
            if(indexSearch != -1 && indexSearch < 3)
            {
                return arg.substring(indexSearch + 1).trim();
            }
            return arg.trim();
        }
        return "";
    }

    public static String getNumberFormat(Object arg) {
        try {
            NumberFormat formatter = NumberFormat.getNumberInstance();
            return formatter.format(arg);
        } catch (Exception ex) { }
        return "";
    }

    public static String getPercentFormat(Object arg) {
        try {
            if (arg != null) {
                NumberFormat formatter = NumberFormat.getNumberInstance();
                return formatter.format(arg) + " %";
            }
        } catch (Exception ex) { }
        return "";
    }

/*    public static List<DropdownBean> monthList(String format, Locale locale) {
        List<DropdownBean> monthList = new ArrayList<DropdownBean>();
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        SimpleDateFormat sdfDB = new SimpleDateFormat("MM", Locale.US);
        try {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.MONTH, 0);
            DropdownBean bean;
            for (int i = 0; i < 12; i++) {
                bean = new DropdownBean();
                bean.setCode(sdfDB.format(cal.getTime()));
                bean.setValue(sdfDB.format(cal.getTime()));
                bean.setName(sdf.format(cal.getTime()));

                monthList.add(bean);
                cal.add(Calendar.MONTH, 1);
            }
            cal.add(Calendar.YEAR, -10);
        } catch (Exception ex) {
            System.out.println(ex.getClass().getName() + ":" + ex.getMessage());
        }
        return monthList;
    }*/

    /*public static List<DropdownBean> yearList(int backYear, String format, Locale locale) {
        List<DropdownBean> yearList = new ArrayList<DropdownBean>();
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        SimpleDateFormat sdfDB = new SimpleDateFormat("yyyy", Locale.US);
        try {
            Calendar cal = Calendar.getInstance();
            DropdownBean bean;
            for (int i = 0; i <= backYear; i++) {
                bean = new DropdownBean();
                bean.setCode(sdfDB.format(cal.getTime()));
                bean.setValue(sdfDB.format(cal.getTime()));
                bean.setName(sdf.format(cal.getTime()));

                yearList.add(bean);
                cal.add(Calendar.YEAR, -1);
            }
        } catch (Exception ex) {
            System.out.println(ex.getClass().getName() + ":" + ex.getMessage());
        }
        return yearList;
    }*/

    /**
     *
     * @param arg1 is String data.
     * @param arg2 is Set of string charecter before convert.
     * @param arg3 is Set of string charecter after convert.
     * @return String that convert from arg2 to arg3.
     *
     * Example arg1 = "April < December and April > January"
     *         arg2 = {"<", ">"}
     *         arg3 = {"&lt;", "&gt;"}
     *       result = "April &lt; December and April &gt; January"
     */
    public static String convertSpecialCharecter(String arg1, String[] arg2, String[] arg3) {
        if (arg1 != null && arg2 != null && arg3 != null && 
            arg1.trim().length() > 0 && arg2.length > 0 && arg2.length == arg3.length) {

            for (int i = 0; i < arg2.length; i++) {
                arg1 = arg1.replaceAll(arg2[i], arg3[i]);
            }
        }
        return arg1;
    }


    /* to convert byte unit to humun readable count
     * By Thanakorn Ch. 20150324
     */
    public static HashMap humanReadableByteCount(long bytes, int digit, boolean si) {
        HashMap hm = new HashMap();
        int unit = si ? 1000 : 1024;
        if (bytes < unit){
            hm.put( "value", String.valueOf( bytes ) );
            hm.put( "byteUnitPrefix", "B" );
            return hm;
        }
        int exp = (int) (Math.log(bytes) / Math.log(unit));
//        String pre = (si ? "kMGTPE" : "KMGTPE").charAt(exp-1) + (si ? "" : "i");
        String pre = (si ? "kMGTPE" : "KMGTPE").charAt(exp-1) + "";
        hm.put( "value", String.format( "%." + digit + "f", bytes / Math.pow(unit, exp)) );
        hm.put( "byteUnitPrefix", String.format( "%sB", pre ) );
        return hm;
    }
}
