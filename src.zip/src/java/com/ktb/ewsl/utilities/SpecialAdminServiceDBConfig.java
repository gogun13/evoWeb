/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

/**
 *
 * @author KTBDevLoan
 */
public class SpecialAdminServiceDBConfig {
    
  private String url;
  private String user;
  private String password;
  private boolean poolMode;
  private boolean autoCommit;
  private String dbDriver;

  public SpecialAdminServiceDBConfig()
  {
    this.url = "";
    this.user = "";
    this.password = "";
    this.poolMode = true;
    this.autoCommit = false;
    this.dbDriver = "";
  }

  public SpecialAdminServiceDBConfig(String url, String user, String password, boolean poolMode, boolean autoCommit , String dbDriver) {
    this.url = url;
    this.user = user;
    this.password = password;
    this.poolMode = poolMode;
    this.autoCommit = autoCommit;
    this.dbDriver = dbDriver;
  }

  public boolean isAutoCommit() {
    return this.autoCommit;
  }

  public void setAutoCommit(boolean autoCommit) {
    this.autoCommit = autoCommit;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public boolean isPoolMode() {
    return this.poolMode;
  }

  public void setPoolMode(boolean poolMode) {
    this.poolMode = poolMode;
  }

  public String getUrl() {
    return this.url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getUser() {
    return this.user;
  }

  public void setUser(String user) {
    this.user = user;
  }

    public String getDbDriver() {
        return dbDriver;
    }

    public void setDbDriver(String dbDriver) {
        this.dbDriver = dbDriver;
    }
  
}
