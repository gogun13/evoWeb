/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
/**
 *
 * @author KTBDevLoan
 */
public class MoneyUtil {
    
    /** Creates a new instance of MoneyUtil */
    public MoneyUtil()
    {
    }
    
    
    public static final int FRACTION = 2;
    public static final String patternDPD = "###,###,###,##0";
    public static final String patternTrigger = "00";
    public static final String pattern_bigDecimal = "###,###,###,##0.00";

    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     */
    public static String formatMoney(float data) throws Exception
    {
        return formatMoney(Float.toString(data), FRACTION);
    }

    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     * @throws Exception
     */
    public static String formatMoney(BigDecimal data) throws Exception
    {
        return formatMoney(DefaultVariable.defaultString(data), FRACTION);
    }
   
    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     */
    public static String formatMoney(double data) throws Exception
    {
        return formatMoney(Double.toString(data), FRACTION);
    }

    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     */
    public static String formatMoney(String data) throws Exception
    {
        return formatMoney(data, FRACTION);
    }

    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     */
    public static String formatMoneyDisplay(String data) throws Exception
    {
        return formatMoneyDisplay(data, FRACTION);
    }
    
    /**
     * @author Net Format Money.
     * @param data
     * @param fraction
     * @return String
     */
    public static String formatMoney(String data, int fraction) throws Exception
    {
        if (data == null || "".equals(data))
            return formatMoney("0", fraction);

        if (data.length() >= 3)
        {
            if (data.substring(0, 2).equals("-."))
            {
                data = data.substring(0, 1) + "0" + data.substring(1, data.length());
            }
        }

        StringBuffer arg = new StringBuffer(data.trim());
        StringBuffer argResult = new StringBuffer();

        int dot = arg.indexOf(".");
        int minus = arg.indexOf("-");

        int dataSize = 0;

        if (dot == -1)
            dataSize = (arg.length());
        else
            dataSize = (dot);

        int index = (dataSize % 3);

        boolean ckMinus = false;
        if (index == 1 & minus != -1)
            ckMinus = true;

        int lastIndex = (index + 3);
        // Add Semicolon in member first.
        if (dataSize == 3)
        {
            argResult.append(data.substring(0, 3));
        }
        else if (index != 0)
        {
            argResult.append(data.substring(0, index));
            if (dataSize > 3)
            {
                argResult.append(",");
            }

        }

        // Add Semicolon in member second.
        if (dataSize > 3)
        {
            do
            {
                argResult.append(data.substring(index, lastIndex));
                if (lastIndex != dataSize)
                    argResult.append(",");
                index += 3;
                lastIndex += 3;
            }
            while (lastIndex <= dataSize);
        }

        // Add decimal notation following fraction.
        dataSize = (arg.length());
        int result = (dot + fraction + 1);

        if (dot == -1)
        {
            argResult.append(".");
            addZero(argResult, fraction);
        }
        else
        {
            if (dataSize >= result)
                argResult.append(arg.substring(dot, result));
            else
            {
                addZero(arg, (result - dataSize));
                argResult.append(arg.substring(dot, result));
            }
        }

        if (ckMinus)
            argResult.deleteCharAt(1);

        dot = arg.indexOf(".");
        if (dot == 0)
        {
            argResult.insert(0, "0");
        }
        arg = null;
              
        if(fraction == 0)
        {
            if(argResult.lastIndexOf(".") == (argResult.length() - 1))
            {
                return argResult.substring(0, (argResult.length() - 1));
            }
        }        
        return argResult.toString();
    }
    
    /**
     * @author Net Format Money.
     * @param data
     * @param fraction
     * @return String
     */
    public static String formatMoneyDisplay(String data, int fraction) throws Exception
    {
        if (data == null || "".equals(data))
            return data = "-";

        if (data.substring(0, 2).equals("-."))
        {
            data = data.substring(0, 1) + "0" + data.substring(1, data.length());
        }

        StringBuffer arg = new StringBuffer(data.trim());
        StringBuffer argResult = new StringBuffer();

        if (arg.substring(0, 2).equals("-."))
        {
            arg.insert(1, "0");
            // System.out.println(" --- : " + arg);
        }

        int dot = arg.indexOf(".");
        int minus = arg.indexOf("-");

        int dataSize = 0;

        if (dot == -1)
            dataSize = (arg.length());
        else
            dataSize = (dot);

        int index = (dataSize % 3);

        boolean ckMinus = false;
        if (index == 1 & minus != -1)
            ckMinus = true;

        int lastIndex = (index + 3);
        // Add Semicolon in member first.
        if (dataSize == 3)
        {
            argResult.append(data.substring(0, 3));
        }
        else if (index != 0)
        {
            argResult.append(data.substring(0, index));
            if (dataSize > 3)
            {
                argResult.append(",");
            }

        }

        // Add Semicolon in member second.
        if (dataSize > 3)
        {
            do
            {
                argResult.append(data.substring(index, lastIndex));
                if (lastIndex != dataSize)
                    argResult.append(",");
                index += 3;
                lastIndex += 3;
            }
            while (lastIndex <= dataSize);
        }

        // Add decimal notation following fraction.
        dataSize = (arg.length());
        int result = (dot + fraction + 1);

        if (dot == -1)
        {
            argResult.append(".");
            addZero(argResult, fraction);
        }
        else
        {
            if (dataSize >= result)
                argResult.append(arg.substring(dot, result));
            else
            {
                addZero(arg, (result - dataSize));
                argResult.append(arg.substring(dot, result));
            }
        }

        if (ckMinus)
            argResult.deleteCharAt(1);

        dot = arg.indexOf(".");
        if (dot == 0)
        {
            argResult.insert(0, "0");
        }
        arg = null;

        return argResult.toString();
    }
    
    /**
     * Add zero from the string following fraction.
     * 
     * @author Net
     * @param arg
     * @param fraction
     */
    private static void addZero(String arg, int fraction) throws Exception
    {
        addZero(new StringBuffer(arg), fraction);
    }

    /**
     * Add zero from the string following fraction.
     * 
     * @author Net
     * @param arg
     * @param fraction
     */
    private static void addZero(StringBuffer arg, int fraction) throws Exception
    {
        for (int i = 0 ; i < fraction ; i++)
        {
            arg.append("0");
        }
    }

    /**
     * @author Narin Format Money. Default Semicolon 2.
     * @param data
     * @return String
     * @throws Exception
     */
    public static String formatMoney(Integer data) throws Exception
    {
        if (data == null)
            data = new Integer(0);
        return formatMoney(DefaultVariable.defaultString(data.toString()), FRACTION);
    }
    
    /**
     * @author Narin Format Money. Default Semicolon 2.
     * @param data
     * @return String
     * @throws Exception
     */
    public static String formatMoney(Integer data, int fraction) throws Exception
    {
        if (data == null)
            data = new Integer(0);
        return formatMoney(DefaultVariable.defaultString(data.toString()), fraction);
    }

    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     * @throws Exception
     */
    public static String formatMoney(Long data) throws Exception
    {
        if (data == null)
            data = new Long(0);
        return formatMoney(Long.toString(data), FRACTION);
    }
    
    /**
     * @author Net Format Money. Default Semicolon 2.
     * @param data
     * @return String
     * @throws Exception
     */
    public static String formatMoney(Long data, int fraction) throws Exception
    {
        if (data == null)
            data = new Long(0);
        return formatMoney(Long.toString(data), fraction);
    }
    
    /**
     * @author Narin
     * Format Money.
     * Default Semicolon 2.
     * 
     * @param data
     * @return String
     */
    public static String formatMoney(Double data) throws Exception
    {
        if (data == null)
            data = new Double(0);
        return formatMoney(Double.toString(data), FRACTION);
    }
    
    public static String convertNumberToStringByFormat(int inputLong, String format) {
            DecimalFormat decimalFormat = new DecimalFormat(format);
            return decimalFormat.format(inputLong);
    }
    
    public static String convertBigDecimalToStringByFormat(BigDecimal inputBig , String format) {
        DecimalFormat decimalFormat = new DecimalFormat(format);
        return decimalFormat.format(inputBig);
    }
    
    public static String convertDbFormat(String input) {
        
        String dataRet = null;
        
        if(input!=null && !input.equals("")){
            dataRet = input.replaceAll(",", "");
        }
        
        return dataRet;
    }
  /*      
  public static void main(String[] arg) throws Exception
    { 
         int data = 1403 ;
          MathContext mc = new MathContext(3); // 3 precision
           System.out.println("data " + convertBigDecimalToStringByFormat(new BigDecimal(0).setScale(2, RoundingMode.HALF_UP),pattern_bigDecimal));
          System.out.println("data " + convertBigDecimalToStringByFormat(new BigDecimal(14555.4546).setScale(2, RoundingMode.HALF_UP),pattern_bigDecimal));
          System.out.println("data " + convertBigDecimalToStringByFormat(new BigDecimal(14555.4556).setScale(3, RoundingMode.HALF_UP),pattern_bigDecimal));
          System.out.println("data " + convertBigDecimalToStringByFormat(new BigDecimal(14555.4566).setScale(4, RoundingMode.HALF_UP),pattern_bigDecimal));
           

//          System.out.println("data " + convertNumberToStringByFormat(data,patternDPD));
//          System.out.println("data " + convertNumberToStringByFormat(0,patternDPD));
//          System.out.println("data " + convertNumberToStringByFormat(-2,patternDPD));
//          System.out.println("data " + convertNumberToStringByFormat(9999999,patternDPD));
          
          System.out.println(new BigDecimal("3.53456").round(new MathContext(4, RoundingMode.HALF_UP)));
// 2.
 System.out.println(new BigDecimal("3.53456").setScale(4, RoundingMode.HALF_UP));
    }*/
}
