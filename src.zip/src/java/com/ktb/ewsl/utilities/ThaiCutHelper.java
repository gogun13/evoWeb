/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import java.math.BigDecimal;
import java.text.BreakIterator;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Tum_Surapong
 */
public class ThaiCutHelper {

    static final Character[] ch = {'\u0E38', '\u0E39', '\u0E36', '\u0E31', '\u0E4D', '\u0E35', '\u0E4A', '\u0E49', '\u0E47', '\u0E48', '\u0E4B', '\u0E34', '\u0E3A', '\u0E37', '\u0E4C'};
    static final Character[] vowel = {'\u0E40', '\u0E44', '\u0E42', '\u0E43', ':', ';', '\'', '\"', '.', '*', '!', '(', ')', '1'};
    static final Set<Character> charset = new TreeSet<Character>();
    static final Set<Character> vowelset = new TreeSet<Character>();
    public static final Locale locale_TH = new Locale("th", "TH");
    public static final java.math.BigDecimal FONT_PER_PIXEL = new BigDecimal(0.4);

    static {
        charset.addAll(java.util.Arrays.asList(ch));
        vowelset.addAll(java.util.Arrays.asList(vowel));
    }

    public static String wordwrap(String target, int uiWidth, int fontSize) {
        BigDecimal font = new BigDecimal(fontSize);
        BigDecimal ui = new BigDecimal(uiWidth);
        BigDecimal fontRate = FONT_PER_PIXEL.multiply(font);
        int fontCanContain = ui.divideToIntegralValue(fontRate).intValue();
        return wordwrap(target, fontCanContain);
    }

    public static String wordwrap(String target, int maxLength) {
        BreakIterator boundary = BreakIterator.getLineInstance(ThaiCutHelper.locale_TH);
        boundary.setText(target);
        int start = boundary.first();
        int end = boundary.next();
        int lineLength = 0;
        StringBuilder txt = new StringBuilder("");
        while (end != BreakIterator.DONE) {
            String word = target.substring(start, end);
            lineLength = lineLength + wordlen(word);

            if (lineLength >= maxLength) {
                txt.append("<br/>");
                lineLength = wordlen(word);
            }
            txt.append(word);
            start = end;
            end = boundary.next();
        }

        return txt.toString();
    }

    public static int wordlen(String str) {
        BigDecimal len = new BigDecimal(str.length());
        char font = ' ';
        for (int j = 0; j < str.length(); j++) {
            font = str.charAt(j);
            if (charset.contains(font)) {
                len = len.subtract(new BigDecimal(1));
            } else if (vowelset.contains(font)) {
                len = len.subtract(new BigDecimal(0.3));
            }
        }
        return len.intValue();
    }
}
