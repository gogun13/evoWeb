/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import com.ktb.ewsl.vo.HolidayVo;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author KTBDevLoan
 */
public class CalculateDueDateUtil {
    
    private static Logger logger = Logger.getLogger(CalculateDueDateUtil.class);
    
    /** Creates a new instance of CalculateDueDateUtil */
    public CalculateDueDateUtil()
    {
    }
    
    /**
     *
     *
     */
    public static Date getDueDate(Date dateNow, Date batchDate, int sla, List mtHolidayDTOList) throws Exception
    {
        if(dateNow == null || batchDate == null)
        {
            return null;
        }
        Date dueDate = null;
        int countSla = 1;
        int count = 0;
        while(countSla <= sla)
        {
            dueDate = EWSDateUtil.displayDateFormatJumpDate(batchDate ,EWSDateUtil.DAY , count);
            Calendar calendar = EWSDateUtil.dateToCalendar(dueDate, EWSDateUtil.FMT_VIEW);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if(dayOfWeek != 1 && dayOfWeek != 7 && verifyHoliday(dueDate, mtHolidayDTOList))
            {
                //logger.debug("getDueDate : " + dueDate);
                countSla++;
            }
            count++;
        }
        return dueDate;
    }
    
    /**
     *
     *
     */
    public static int getDueDay(Date dateNow, Date dueDate, List mtHolidayDTOList) throws Exception
    {
        if(dateNow == null || dueDate == null)
        {
            return 0;
        }
        Date date = null;

        // The value 0 if the DateNow is equal to the DueDate;
        // A value less than 0 if the DueDate is before the DateNow;
        // A value greater than 0 if the DueDate is after the DateNow.
        boolean statusCondition = (dueDate.compareTo(dateNow) >= 0 ? true : false);
        if(statusCondition)
        {
            date = dateNow;
        }
        else
        {
            date = dueDate;
        }
        Date dateToday = null;
        
//        logger.debug("\n\n");
//        logger.debug("dateNow         : " + dateNow);
//        logger.debug("dueDate         : " + dueDate);
//        logger.debug("date            : " + date);
//        logger.debug("statusCondition : " + statusCondition);
        
        int count = 1;
        int countSla = 1;
        boolean status = true;
        while(status)
        {
            //logger.debug("\n");
           // logger.debug("count : " + count);
            dateToday = EWSDateUtil.displayDateFormatJumpDate(date ,EWSDateUtil.DAY , count);
            Calendar calendar = EWSDateUtil.dateToCalendar(dateToday, EWSDateUtil.FMT_VIEW);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if(dayOfWeek != 1 && dayOfWeek != 7 && verifyHoliday(dateToday, mtHolidayDTOList))
            {
               // logger.debug("date working            : " + dateToday);
                countSla++;
            }
            
            if(statusCondition)
            {
               // logger.debug("dateToday.compareTo(dueDate) : " + dateToday.compareTo(dueDate));
                if(dateToday.compareTo(dueDate) >= 0)
                {
                    status = false;
                    if(count == 1)
                    {
                        countSla--;
                    }
                }
            }
            else
            {
                //logger.debug("dateToday.compareTo(dateNow) : " + dateToday.compareTo(dateNow));
                if(dateToday.compareTo(dateNow) == 0)
                {
                    status = false;
                    countSla = DefaultVariable.defaultInt("-"+ countSla);
                }
            }
           // logger.debug("date                    : " + dateToday);
           // logger.debug("dateNow                 : " + dateNow);
            
            count++;
        }
        //logger.debug("countSla : " + countSla);
        if(countSla < 0)
        {
            countSla++;
        }
        else if(countSla == 0)
        {
            countSla++;
        }

        if (countSla <= -31) {
            countSla = -31;
        }
        return countSla;
    }

    /**
     *
     *
     */
    public static int getSurveyDueDay(Date dateNow, Date dueDate) throws Exception
    {
        if(dateNow == null || dueDate == null)
        {
            return 0;
        }

        return EWSDateUtil.dateDifference(dueDate, dateNow);

//        Date date = null;
//
//        // The value 0 if the DateNow is equal to the DueDate;
//        // A value less than 0 if the DueDate is before the DateNow;
//        // A value greater than 0 if the DueDate is after the DateNow.
//        boolean statusCondition = (dueDate.compareTo(dateNow) >= 0 ? true : false);
//        if(statusCondition)
//        {
//            date = dateNow;
//        }
//        else
//        {
//            date = dueDate;
//        }
//        Date dateToday = null;
//
//        logger.debug("\n\n");
//        logger.debug("dateNow         : " + dateNow);
//        logger.debug("dueDate         : " + dueDate);
//        logger.debug("date            : " + date);
//        logger.debug("statusCondition : " + statusCondition);
//
//        int count = 1;
//        int countSla = 1;
//        boolean status = true;
//        while(status)
//        {
//            dateToday = DateUtil.displayDateFormatJumpDate(date ,DateUtil.DAY , count);
//
//            countSla++;
//
//            if(statusCondition)
//            {
//                logger.debug("dateToday.compareTo(dueDate) : " + dateToday.compareTo(dueDate));
//                if(dateToday.compareTo(dueDate) >= 0)
//                {
//                    status = false;
//                    if(count == 1)
//                    {
//                        countSla--;
//                    }
//                }
//            }
//            else
//            {
//                logger.debug("dateToday.compareTo(dateNow) : " + dateToday.compareTo(dateNow));
//                if(dateToday.compareTo(dateNow) == 0)
//                {
//                    status = false;
//                    countSla = DefaultVariable.defaultInt("-"+ countSla);
//                }
//            }
//            logger.debug("date                    : " + dateToday);
//            logger.debug("dateNow                 : " + dateNow);
//
//            count++;
//        }
//        logger.debug("countSla : " + countSla);
//        if(countSla < 0)
//        {
//            countSla++;
//        }
//        else if(countSla == 0)
//        {
//            countSla++;
//        }
//        return countSla;
    }
    
    /**
     *
     *
     */
    public static boolean verifyHoliday(Date date, List mtHolidayDTOList) throws Exception
    {
        if(mtHolidayDTOList == null)
        {
            return true;
        }
        HolidayVo mtHolidayDTO = null;
        int condition = 0;
        for(Iterator iter = mtHolidayDTOList.iterator(); iter.hasNext();)
        {
            mtHolidayDTO = (HolidayVo) iter.next();
            //logger.debug("Compare date : " + date + " with " + "mtHolidayDTO.getHolidayDate() : " + mtHolidayDTO.getHolidayDate());
            condition = date.compareTo(mtHolidayDTO.getHolidayDate());
            if(date.compareTo(mtHolidayDTO.getHolidayDate()) == 0)
            {
                return false;
            }
        }
        return true;
    }
    
    
    public static Date getWorkingDate(Date workingDate) throws Exception
    {
        boolean status = true;
        while(status)
        {
            workingDate = EWSDateUtil.displayDateFormatJumpDate(workingDate ,EWSDateUtil.DAY , 1);            
            Calendar calendar = EWSDateUtil.dateToCalendar(workingDate, EWSDateUtil.FMT_VIEW);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if(dayOfWeek != 1 && dayOfWeek != 7)
            {
                logger.debug("workingDate : " + workingDate);
                status = false;
            }
            
        }
        return workingDate;
    }
    
    public static void main(String[] arg) throws Exception
    {
        Date batchDate = EWSDateUtil.convertDateFormat("14/06/2010", EWSDateUtil.FMT_VIEW);
        Date dateNow = EWSDateUtil.convertDateFormat("23/06/2010", EWSDateUtil.FMT_VIEW);
        int sla = 5;
        
        
        List holidayDTOList = new ArrayList();
        HolidayVo mtHolidayDTO = new HolidayVo();
        mtHolidayDTO.setHolidayDate(EWSDateUtil.convertDateFormat("01/07/2010", EWSDateUtil.FMT_VIEW));
        holidayDTOList.add(mtHolidayDTO);
        
        
        
        Date dueDate = getDueDate(dateNow, batchDate, sla, holidayDTOList);
        int dueDay = getDueDay(dateNow, dueDate, holidayDTOList);
        
        System.out.println("\n\n");
        System.out.println("dueDate : " + EWSDateUtil.dateFormat(dueDate, EWSDateUtil.FMT_VIEW));
        System.out.println("dateNow : " + EWSDateUtil.dateFormat(dateNow, EWSDateUtil.FMT_VIEW));
        System.out.println("dueDay : " + dueDay);
        
       // System.out.println("slaMin : " + slaMin);
//        System.out.println("getWorkingDate : "+ getWorkingDate(DateUtil.convertDateFormat("25/06/2010", DateUtil.FMT_VIEW)));
    }
}
