/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

/**
 *
 * @author KTBDevLoan
 */
public class SpecialAdminService {
    
  private Vector headerList;
  private Vector headerTypeList;
  private Vector dataList;
  private String message;
  private SpecialAdminServiceDBConfig dbConfig;
  private SpecialAdminServiceDB updateDB;

  public SpecialAdminService()
  {
    this.headerList = new Vector();
    this.headerTypeList = new Vector();
    this.dataList = new Vector();
    this.message = "";
    this.dbConfig = new SpecialAdminServiceDBConfig();

    this.updateDB = null; }

  public void setupConfig(String url, String user, String password, boolean connPoolMode, boolean autoCommit , String driver) {
    this.dbConfig = new SpecialAdminServiceDBConfig();
    this.dbConfig.setUrl(SpecialAdminServiceUtil.parseString(url));
    this.dbConfig.setUser(SpecialAdminServiceUtil.parseString(user));
    this.dbConfig.setPassword(SpecialAdminServiceUtil.parseString(password));
    this.dbConfig.setPoolMode(connPoolMode);
    this.dbConfig.setAutoCommit(autoCommit);
     this.dbConfig.setDbDriver(driver);
  }

  public void execute(String sql, boolean executeMode)throws Exception{
    try{  
    this.headerList.clear();
    this.dataList.clear();
    this.message = "";

    if (executeMode){
      SpecialAdminServiceDB db = null;
      ResultSet rs = null;
      try {
        db = new SpecialAdminServiceDB(this.dbConfig);
        rs = db.executeQuery(sql);
        ResultSetMetaData rsm = rs.getMetaData();
        boolean headerFlag = true;

        while (rs.next()) {
          int i;
          int resultSize = rsm.getColumnCount();
          if (headerFlag) {
            headerFlag = false;
            for (i = 1; i <= resultSize; ++i){
              this.headerList.add(SpecialAdminServiceUtil.parseString(rsm.getColumnName(i)));
            }
            for (i = 1; i <= resultSize; ++i){
              this.headerTypeList.add(SpecialAdminServiceUtil.parseString(rsm.getColumnTypeName(i)));
            }
          }

          ArrayList data = new ArrayList();
          for (int j = 1; j <= resultSize; ++j){
            data.add(SpecialAdminServiceUtil.parseString(rs.getString(j)));
          }
          
          this.dataList.add(data);
          data = null;
        }
      }catch(Exception e){
            throw e;
      }
      finally {
          if (rs != null) rs.close();
          if (db != null) db.close();
      }
    } else {
        if (this.updateDB == null){
          this.updateDB = new SpecialAdminServiceDB(this.dbConfig);
        }
        int resultCount = this.updateDB.executeUpdate(sql);
        this.headerList.add(new String("Result"));
        this.headerTypeList.add(new String("VARCHAR"));

        ArrayList data = new ArrayList();
        data.add(new String("" + resultCount));
        this.dataList.add(data);
    }
    }catch(Exception e){
       this.message = " Error!! " + e.getClass().getName() + ":" + e.getMessage();
       e.printStackTrace();
       throw e;
    }
  }

  public void commit() {
    try {
      if (this.updateDB != null) {
        this.updateDB.commit();
        this.message = "Commit Success!!";
      }
    } catch (Exception ex) {
      this.message = "Commit Error!! " + ex.getClass().getName() + ":" + ex.getMessage();
    }
    finally {
        if (this.updateDB != null)
        try {
          this.updateDB.close();
          this.updateDB = null;
        } catch (SQLException ex) {
        }
    }
  }

  public void rollBack() {
    try {
      if (this.updateDB != null) {
        this.updateDB.rollback();
        this.message = "Rollback Success!!";
      }
    } catch (Exception ex) {
      this.message = "Rollback Error!! " + ex.getClass().getName() + ":" + ex.getMessage();
    }
    finally {
      if (this.updateDB != null)
        try {
          this.updateDB.close();
          this.updateDB = null;
        } catch (SQLException ex) {
        }
    }
  }

  public boolean hasUpdate() {
    return (this.updateDB != null);
  }

  public Vector getDataList() {
    return this.dataList;
  }

  public Vector getHeaderList() {
    return this.headerList;
  }

  public Vector getHeaderTypeList() {
    return this.headerTypeList;
  }

  public String getMessage() {
    return this.message;
  }
}
