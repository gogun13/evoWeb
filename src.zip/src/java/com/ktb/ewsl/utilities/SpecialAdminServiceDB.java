/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 *
 * @author KTBDevLoan
 */
public class SpecialAdminServiceDB {
    
  private SpecialAdminServiceDBConfig dbConfig = null;
  private Connection conn = null;
  private Statement smt = null;

  public SpecialAdminServiceDB(SpecialAdminServiceDBConfig dbConfig)
    throws Exception
  {
    if (dbConfig != null){
      try {
        this.dbConfig = dbConfig;
        if (dbConfig.isPoolMode())
        {
          DataSource serviceSource = null;
          Context initCtx = new InitialContext();
          serviceSource = (DataSource)initCtx.lookup(dbConfig.getUrl());
          this.conn = serviceSource.getConnection();
          this.conn.setAutoCommit(dbConfig.isAutoCommit());
        }
        else
        {
           Class.forName(dbConfig.getDbDriver());
          this.conn = DriverManager.getConnection(dbConfig.getUrl(), dbConfig.getUser(), dbConfig.getPassword());

          this.conn.setAutoCommit(dbConfig.isAutoCommit());
        }
      } catch (Exception ex) {
//          if(conn != null){ conn.close(); }
          throw new Exception("SpecialAdminServiceDB cannot connect to database. [" + ex.getClass().getName() + ":" + ex.getMessage() + "]");
      }
    }
  }

  public ResultSet executeQuery(String sql) throws SQLException
  {
    this.smt = this.conn.createStatement();
    return this.smt.executeQuery(sql);
  }

  public int executeUpdate(String sql) throws SQLException {
    this.smt = this.conn.createStatement();
    return this.smt.executeUpdate(sql);
  }

  public boolean exeute(String sql) throws SQLException {
    this.smt = this.conn.createStatement();
    return this.smt.execute(sql);
  }

  public ResultSet getResultSet() throws SQLException {
    if (this.smt != null){
      return this.smt.getResultSet();
    }
    return null;
  }

  public int getUpdateCount() throws SQLException {
    if (this.smt != null){
      return this.smt.getUpdateCount();
    }
    return -1;
  }

  public void commit() throws SQLException {
    if (this.conn != null){
      this.conn.commit();
    }
  }

  public void rollback() throws SQLException
  {
    if (this.conn != null){
      this.conn.rollback();
    }
  }

  public void close() throws SQLException
  {
    if (this.conn != null){
      this.conn.close();
    }
  }
}
