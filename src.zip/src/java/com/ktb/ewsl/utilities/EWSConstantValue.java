/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import com.ktbcs.core.utilities.BusinessConst;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public class EWSConstantValue {
    
    public static String USER_EWS_ENVIROMENT = "envadmin";
    
    public static List ROLE_TRACKING = new ArrayList();
    static
    {
          ROLE_TRACKING.add(BusinessConst.UserRole.CREDIT_CONTROLER);
          ROLE_TRACKING.add(BusinessConst.UserRole.TURNAROUND);
    }
    
    public static List CAN_TRACKING = new ArrayList();
    static
    {
          CAN_TRACKING.add("N");
          //CAN_TRACKING.add("D");
          CAN_TRACKING.add("RMP");
          CAN_TRACKING.add("BRMP");
          CAN_TRACKING.add("RMF");
    }
    
    public static List TRIGGER_GROUP = new ArrayList();
    static
    {
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG01);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG02);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG03);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG04);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG05);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG06);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG07);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG08);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG09);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG10);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG11);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG12);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG13);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG14);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG15);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG16);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG17);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG18);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG19);
          TRIGGER_GROUP.add(BusinessConst.WarningTypeCode.TRIG20);
    }
    
    public static List ROLE_APPROVE = new ArrayList();
    static
    {
        ROLE_APPROVE.add(BusinessConst.UserRole.BCM);
        //  ROLE_APPROVE.add(BusinessConst.UserRole.RISK_EDITOR);
          
        /*Begin R3.1*/
        ROLE_APPROVE.add(BusinessConst.UserRole.CO_BCM);
        /*End R3.1*/
    }
    public static List ROLE_APPROVE_CLOSE_JOB = new ArrayList();
    static
    {
          ROLE_APPROVE_CLOSE_JOB.add(BusinessConst.UserRole.BCM);
          ROLE_APPROVE_CLOSE_JOB.add(BusinessConst.UserRole.RISK_EDITOR);
          
          /*Begin R3.1*/
          ROLE_APPROVE_CLOSE_JOB.add(BusinessConst.UserRole.CO_BCM);
          /*End R3.1*/
    }
    
    public static List ROLE_APPROVE_QCA_FINAL_LEVEL1 = new ArrayList();
    static
    {
          ROLE_APPROVE_QCA_FINAL_LEVEL1.add(BusinessConst.UserRole.SCM);
//          ROLE_APPROVE_QCA_FINAL_LEVEL1.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    
    public static List ROLE_APPROVE_QCA_FINAL_LEVEL2 = new ArrayList();
    static
    {
          ROLE_APPROVE_QCA_FINAL_LEVEL2.add(BusinessConst.UserRole.SCM);
//          ROLE_APPROVE_QCA_FINAL_LEVEL2.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    
    public static List ROLE_EDITOR = new ArrayList();
    static
    {
          ROLE_EDITOR.add(BusinessConst.UserRole.RM);
          ROLE_EDITOR.add(BusinessConst.UserRole.BCM);
          ROLE_EDITOR.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    
    public static List ROLE_EDITOR_FIN = new ArrayList();
    static
    {
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.AE);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.AO);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.RM);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.BCM);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.RISK_EDITOR);
          
          /*Begin R3.1*/
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.CO_AE);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.CO_AO);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.CO_RM);
          ROLE_EDITOR_FIN.add(BusinessConst.UserRole.CO_BCM);
          /*End R3.1*/
    }
    
    public static List ROLE_EDITOR_QULI = new ArrayList();
    static
    {
          ROLE_EDITOR_QULI.add(BusinessConst.UserRole.AE);
          ROLE_EDITOR_QULI.add(BusinessConst.UserRole.AO);
          ROLE_EDITOR_QULI.add(BusinessConst.UserRole.RM);
          ROLE_EDITOR_QULI.add(BusinessConst.UserRole.BCM);
          ROLE_EDITOR_QULI.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    public static List ROLE_EDITOR_QULI_CO_OP = new ArrayList();
    static
    {
          ROLE_EDITOR_QULI_CO_OP.add(BusinessConst.UserRole.CO_AE);
          ROLE_EDITOR_QULI_CO_OP.add(BusinessConst.UserRole.CO_AO);
          ROLE_EDITOR_QULI_CO_OP.add(BusinessConst.UserRole.CO_RM);
          ROLE_EDITOR_QULI_CO_OP.add(BusinessConst.UserRole.CO_BCM);
    }
     public static List ROLE_EDITOR_CO_OP = new ArrayList();
    static
    {
          ROLE_EDITOR_CO_OP.add(BusinessConst.UserRole.CO_AE);
          ROLE_EDITOR_CO_OP.add(BusinessConst.UserRole.CO_AO);
          ROLE_EDITOR_CO_OP.add(BusinessConst.UserRole.CO_RM);
          ROLE_EDITOR_CO_OP.add(BusinessConst.UserRole.CO_BCM);
    }
    public static List ROLE_EDITOR_EWSL = new ArrayList();
    static
    {
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.AE);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.AO);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.RM);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.BCM);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.RISK_EDITOR);
          
          /*Begin R3.1*/
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.CO_AE);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.CO_AO);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.CO_RM);
          ROLE_EDITOR_EWSL.add(BusinessConst.UserRole.CO_BCM);
          /*End R3.1*/
    }
    
    public static List ROLE_EDITOR_OLD = new ArrayList();
    static
    {
          ROLE_EDITOR_OLD.add(BusinessConst.UserRole.AE);
          ROLE_EDITOR_OLD.add(BusinessConst.UserRole.AO);
          ROLE_EDITOR_OLD.add(BusinessConst.UserRole.RM);
          ROLE_EDITOR_OLD.add(BusinessConst.UserRole.BCM);
    }
    
    public static List ROLE_EWS = new ArrayList();
    static
    {
          ROLE_EWS.add(BusinessConst.UserRole.AE);
          ROLE_EWS.add(BusinessConst.UserRole.RM);
          ROLE_EWS.add(BusinessConst.UserRole.BCM);
          ROLE_EWS.add(BusinessConst.UserRole.SCM);
          ROLE_EWS.add(BusinessConst.UserRole.CREDIT_CONTROLER);
          ROLE_EWS.add(BusinessConst.UserRole.TURNAROUND);
          ROLE_EWS.add(BusinessConst.UserRole.RISK_EDITOR);
          ROLE_EWS.add(BusinessConst.UserRole.ADMIN);
          ROLE_EWS.add(BusinessConst.UserRole.VIEWER);
          ROLE_EWS.add(BusinessConst.UserRole.RISK_VIEWER);
    }
    
    public static List STATUS_DEFAULT_ANSWER = new ArrayList();
    static
    {
          STATUS_DEFAULT_ANSWER.add(BusinessConst.Flag.N);
          STATUS_DEFAULT_ANSWER.add(BusinessConst.Flag.RMP);
    }
    public static List ROLE_GOTO_OPTIMIST = new ArrayList();
    static
    {
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.AO);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.AE);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.RM);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.BCM);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.ADMIN);
          
          /*Begin R3.1*/
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.CO_AO);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.CO_AE);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.CO_RM);
          ROLE_GOTO_OPTIMIST.add(BusinessConst.UserRole.CO_BCM);
          /*End R3.1*/
          
    }
    public static List STATUS_GOTO_OPTIMIST = new ArrayList();
    static
    {
          STATUS_GOTO_OPTIMIST.add(BusinessConst.Flag.N);
          STATUS_GOTO_OPTIMIST.add(BusinessConst.Flag.RMP);
          STATUS_GOTO_OPTIMIST.add(BusinessConst.Flag.BRMP);
          STATUS_GOTO_OPTIMIST.add(BusinessConst.Flag.PRMP);
    }
    public static List STATUS_INPROCESS_GROUP = new ArrayList();
    static
    {
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.RMP);
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.RMF);
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.BRMP);
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.BCA);
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.CMP);
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.CMF);
          STATUS_INPROCESS_GROUP.add(BusinessConst.Flag.SCMP);
    }
    public static List ROLE_APPROVE_REJECT_STEP_1 = new ArrayList();
    static
    {
          ROLE_APPROVE_REJECT_STEP_1.add(BusinessConst.UserRole.BCM);
          //ROLE_APPROVE_REJECT_STEP_1.add(BusinessConst.UserRole.RISK_EDITOR);
          
          /*Begin R3.1*/
          ROLE_APPROVE_REJECT_STEP_1.add(BusinessConst.UserRole.CO_BCM);
          /*End R3.1*/
    }
    public static List STATUS_APPROVE_REJECT_STEP_1 = new ArrayList();
    static
    {
          STATUS_APPROVE_REJECT_STEP_1.add(BusinessConst.Flag.RMF);
          STATUS_APPROVE_REJECT_STEP_1.add(BusinessConst.Flag.BRMF);
    }
    public static List ROLE_APPROVE_REJECT_STEP_2 = new ArrayList();
    static
    {
          ROLE_APPROVE_REJECT_STEP_2.add(BusinessConst.UserRole.CM);
          ROLE_APPROVE_REJECT_STEP_2.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    public static List STATUS_APPROVE_REJECT_STEP_2 = new ArrayList();
    static
    {
          STATUS_APPROVE_REJECT_STEP_2.add(BusinessConst.Flag.BCA);
          STATUS_APPROVE_REJECT_STEP_2.add(BusinessConst.Flag.BBCA);
    }
    public static List ROLE_APPROVE_REJECT_STEP_3 = new ArrayList();
    static
    {
          ROLE_APPROVE_REJECT_STEP_3.add(BusinessConst.UserRole.SCM);
          ROLE_APPROVE_REJECT_STEP_3.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    public static List STATUS_APPROVE_REJECT_STEP_3 = new ArrayList();
    static
    {
          STATUS_APPROVE_REJECT_STEP_3.add(BusinessConst.Flag.CMF);
    }
    public static List STATUS_HEADER_NOT_SEND_BCM = new ArrayList();
    static
    {
          STATUS_HEADER_NOT_SEND_BCM.add(BusinessConst.Flag.N);
          STATUS_HEADER_NOT_SEND_BCM.add(BusinessConst.Flag.RMP);
          STATUS_HEADER_NOT_SEND_BCM.add(BusinessConst.Flag.BRMP);
    }
    
    public static List ROLE_FOR_CHECKBOX_CONDITION = new ArrayList();
    static
    {
          ROLE_FOR_CHECKBOX_CONDITION.add(BusinessConst.UserRole.VIEWER);
          ROLE_FOR_CHECKBOX_CONDITION.add(BusinessConst.UserRole.RISK_VIEWER);
          ROLE_FOR_CHECKBOX_CONDITION.add(BusinessConst.UserRole.RISK_EDITOR);
          ROLE_FOR_CHECKBOX_CONDITION.add(BusinessConst.UserRole.ADMIN);
    }
    
    public static List ROLE_SEARCH_MORE = new ArrayList();
    static
    {
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.VIWER_1);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.VIWER_2);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.VIWER_3);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.VIWER_4);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.ADMIN);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.VIEWER);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.RISK_VIEWER);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.RISK_EDITOR);
          ROLE_SEARCH_MORE.add(BusinessConst.UserRole.AMD);
    }
    
    public static List ROLE_SEARCH_BUSINESS_SIZE = new ArrayList();
    static
    {
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.RISK_EDITOR);
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.VIEWER);
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.VIWER_1);
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.VIWER_2);
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.VIWER_3);
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.VIWER_4);
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.VIWER_5);
          
          ROLE_SEARCH_BUSINESS_SIZE.add(BusinessConst.UserRole.RISK_VIEWER);//[EWS-L : R11] 
    }
    
    public static List DATA_FOR_TURNAROUND = new ArrayList();
    static
    {
          DATA_FOR_TURNAROUND.add(BusinessConst.WarningTypeCode.TRIG);
          DATA_FOR_TURNAROUND.add(BusinessConst.WarningTypeCode.PAY);
    }
    public static List DATA_FOR_CREDIT_CONTROLER = new ArrayList();
    static
    {
          DATA_FOR_CREDIT_CONTROLER.add(BusinessConst.WarningTypeCode.FIN);
          DATA_FOR_CREDIT_CONTROLER.add(BusinessConst.WarningTypeCode.EWSQ);
    }
    public static List ROLE_CAN_DO_QUESTION = new ArrayList();
    static
    {
          ROLE_CAN_DO_QUESTION.add(BusinessConst.UserRole.AE);
          ROLE_CAN_DO_QUESTION.add(BusinessConst.UserRole.RM);
          ROLE_CAN_DO_QUESTION.add(BusinessConst.UserRole.BCM);
          ROLE_CAN_DO_QUESTION.add(BusinessConst.UserRole.SCM);
          ROLE_CAN_DO_QUESTION.add(BusinessConst.UserRole.ADMIN);
    }
    
    
    public static List NO_CRITERIA_INDIVIDUAL_RM_AE_AO = new ArrayList();
    static
    {
          NO_CRITERIA_INDIVIDUAL_RM_AE_AO.add(BusinessConst.UserRole.AE);
          NO_CRITERIA_INDIVIDUAL_RM_AE_AO.add(BusinessConst.UserRole.RM);
          NO_CRITERIA_INDIVIDUAL_RM_AE_AO.add(BusinessConst.UserRole.AO);
          NO_CRITERIA_INDIVIDUAL_RM_AE_AO.add(BusinessConst.UserRole.BCM);
    }
    
    public static List CRITERIA_INDIVIDUAL_ORGANIZATION = new ArrayList();
    static
    {
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.SCM);
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.CREDIT_CONTROLER);
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.TURNAROUND);
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.VIEWER);
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.RISK_VIEWER);
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.RISK_EDITOR);
          CRITERIA_INDIVIDUAL_ORGANIZATION.add(BusinessConst.UserRole.ADMIN);
    }
    public static List ROLE_CAN_PROTEST = new ArrayList();
    static
    {
          ROLE_CAN_PROTEST.add(BusinessConst.UserRole.TURNAROUND);
          ROLE_CAN_PROTEST.add(BusinessConst.UserRole.CREDIT_CONTROLER);
    }
    
    public static List STATUS_NO_FIND_HOLDER_ID_ROLE = new ArrayList();
    static
    {
          STATUS_NO_FIND_HOLDER_ID_ROLE.add(BusinessConst.Flag.COMPLETE);
          STATUS_NO_FIND_HOLDER_ID_ROLE.add(BusinessConst.Flag.OVER_LIMIT_SLA);
          STATUS_NO_FIND_HOLDER_ID_ROLE.add(BusinessConst.Flag.CANCEL);
    }
    public static List STATUS_FIND_HOLDER_ID_AE_RM_BCM_SCM = new ArrayList();
    static
    {
          STATUS_FIND_HOLDER_ID_AE_RM_BCM_SCM.add(BusinessConst.Flag.RMP);
          STATUS_FIND_HOLDER_ID_AE_RM_BCM_SCM.add(BusinessConst.Flag.CMP);
          STATUS_FIND_HOLDER_ID_AE_RM_BCM_SCM.add(BusinessConst.Flag.CMF);
          STATUS_FIND_HOLDER_ID_AE_RM_BCM_SCM.add(BusinessConst.Flag.SCMP);
    }
    public static List STATUS_FIND_NEXT_HOLDER_ID = new ArrayList();
    static
    {
          STATUS_FIND_NEXT_HOLDER_ID.add(BusinessConst.Flag.RMF);
          STATUS_FIND_NEXT_HOLDER_ID.add(BusinessConst.Flag.BCA);
    }
    
    public enum LoanCategory {

        TERM_LOAN {
            public String toString() {
                return "'COM', 'LN'";
            }
        }, 
        REVOLVING_LOAN {
            public String toString() {
                return "revolving loan type";
            }
        };
    }
    
    public enum LoanType {
        TERMLOAN, REVOLVING, ADVANCEMENT
    }
    public static List AUTHEN_DATA_ALL_PORT = new ArrayList(); //สายงาน
    static
    {
          AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.RISK_EDITOR);
          AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.TURNAROUND);
          AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.CREDIT_CONTROLER);
          AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.RISK_VIEWER); //--- ตามองค์กร
          //AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.VIEWER);
          AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.SCM); 
          AUTHEN_DATA_ALL_PORT.add(BusinessConst.UserRole.ADMIN); 
    }
    
    public static List AUTHEN_DATA_ONLY_BC = new ArrayList(); //กลุ่มงาน
    static
    {
          AUTHEN_DATA_ONLY_BC.add(BusinessConst.UserRole.AE);
          AUTHEN_DATA_ONLY_BC.add(BusinessConst.UserRole.RM);
          AUTHEN_DATA_ONLY_BC.add(BusinessConst.UserRole.BCM);
          AUTHEN_DATA_ONLY_BC.add(BusinessConst.UserRole.VIEWER); //--- ทุกกลุ่มเฉพาะ response Unit ของตัวเอง
    }
    //----------------------------------------------------EWSL ----------------------------------------------------//
    public static List USER_ROLE_WITH_ORGANIZATION = new ArrayList();
    static
    {
          USER_ROLE_WITH_ORGANIZATION.add(BusinessConst.UserRole.VIWER_1);
          USER_ROLE_WITH_ORGANIZATION.add(BusinessConst.UserRole.VIWER_2);
          USER_ROLE_WITH_ORGANIZATION.add(BusinessConst.UserRole.VIWER_3);
          USER_ROLE_WITH_ORGANIZATION.add(BusinessConst.UserRole.VIWER_4);
          
          USER_ROLE_WITH_ORGANIZATION.add(BusinessConst.UserRole.RISK_VIEWER);//[EWS-L : R11]
    }
    
    public static List USER_ROLE_WITH_ORGANIZATION_CTRL = new ArrayList(); 
    static
    {
          USER_ROLE_WITH_ORGANIZATION_CTRL.add(BusinessConst.UserRole.RISK_EDITOR);
    }
    
    /*Begin Add By Pound*/
    public static List ROLE_ACTION_FORM = new ArrayList();
    static
    {
        ROLE_ACTION_FORM.add(BusinessConst.UserRole.RM);
        ROLE_ACTION_FORM.add(BusinessConst.UserRole.AE);
        ROLE_ACTION_FORM.add(BusinessConst.UserRole.AO);
        
        /*Begin R3.1*/
        ROLE_ACTION_FORM.add(BusinessConst.UserRole.CO_RM);
        ROLE_ACTION_FORM.add(BusinessConst.UserRole.CO_AE);
        ROLE_ACTION_FORM.add(BusinessConst.UserRole.CO_AO);
        /*End R3.1*/
          
    }
    
    public static List ROLE_CO_ACTION_FORM = new ArrayList();
    static
    {
        ROLE_CO_ACTION_FORM.add(BusinessConst.UserRole.CO_RM);
        ROLE_CO_ACTION_FORM.add(BusinessConst.UserRole.CO_AE);
        ROLE_CO_ACTION_FORM.add(BusinessConst.UserRole.CO_AO);
          
    }
    /*End Add By Pound*/
    
    public static List ROLE_CLOSE_JOB = new ArrayList();
    static
    {
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.RISK_EDITOR);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.BCM);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.RM);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.AE);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.AO);
          
          /*Begin R3.1*/
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.CO_BCM);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.CO_RM);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.CO_AE);
          ROLE_CLOSE_JOB.add(BusinessConst.UserRole.CO_AO);
          /*End R3.1*/
    }
    
    public static List ROLE_CLOSE_JOB_APPROVE = new ArrayList();
    static
    {
          ROLE_CLOSE_JOB_APPROVE.add(BusinessConst.UserRole.RISK_EDITOR);
          ROLE_CLOSE_JOB_APPROVE.add(BusinessConst.UserRole.BCM); 
          
          /*Begin R3.1*/
          ROLE_CLOSE_JOB_APPROVE.add(BusinessConst.UserRole.CO_BCM);
          /*End R3.1*/
    }
    
    public static List ROLE_BO_CHECK_DPD = new ArrayList();
    static
    {
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.RM);
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.AE);
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.AO);  
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.BCM);
        
        /*Begin R3.1*/
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.CO_RM);
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.CO_AE);
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.CO_AO);  
        ROLE_BO_CHECK_DPD.add(BusinessConst.UserRole.CO_BCM);
        /*End R3.1*/
    }
    
    public static List ROLE_DRAFT_DO_REPRESENT = new ArrayList();
    static
    {
          ROLE_DRAFT_DO_REPRESENT.add(BusinessConst.UserRole.AE);
          ROLE_DRAFT_DO_REPRESENT.add(BusinessConst.UserRole.AO);
          ROLE_DRAFT_DO_REPRESENT.add(BusinessConst.UserRole.RM);
          
          /*Begin R3.1*/
          ROLE_DRAFT_DO_REPRESENT.add(BusinessConst.UserRole.CO_AE);
          ROLE_DRAFT_DO_REPRESENT.add(BusinessConst.UserRole.CO_AO);
          ROLE_DRAFT_DO_REPRESENT.add(BusinessConst.UserRole.CO_RM);
          /*End R3.1*/
    }
    
}
