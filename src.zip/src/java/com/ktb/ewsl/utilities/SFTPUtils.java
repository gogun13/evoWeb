package com.ktb.ewsl.utilities;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Vector;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author Thanakorn.C
 */
public class SFTPUtils {

    public static void putFileByUserAndPassword(String host, String port, String user, String pass, InputStream is, String absFileName) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            sftpChannel.put( is, absFileName );

            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        } catch (SftpException e) {
        	throw e;
        } finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
	}

    public static void putFileByKnownHosts(String host, String port, String user, String knownHost, String pubKeyFile, InputStream is, String absFileName) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            jsch.setKnownHosts( knownHost );
            jsch.addIdentity( pubKeyFile );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            sftpChannel.put( is, absFileName );

            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        } catch (SftpException e) {
        	throw e;
        } finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
	}

    public static void makeDirectoryIfNotExists(String host, String port, String user, String pass, String path, int decPerm) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;

            sftpChannel.cd( "/" );
            String[] folders = path.split( "/" );
            for ( String folder : folders ) {
                if ( folder.length() > 0 ) {
                    try {
                        sftpChannel.cd( folder );
                    }
                    catch ( SftpException e ) {
                        sftpChannel.mkdir( folder );
                        sftpChannel.chmod( decPerm , path);
                        sftpChannel.cd( folder );
                    }
                }
            }

            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        } catch (SftpException e) {
        	throw e;
        } finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
	}

    public static boolean removeFile(String host, String port, String user, String pass, String path) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        boolean ret = false;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            try {
                sftpChannel.rm( path );
                ret = true;
            } catch ( SftpException e ) {
                ret = false;
            }
            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        }  finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
        return ret;
	}

    public static boolean getFileInputSteam(String host, String port, String user, String pass, String path, InputStream is ) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        boolean ret = false;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            try {
                byte[] bytes = IOUtils.toByteArray( sftpChannel.get( path ) );
                is = new ByteArrayInputStream( bytes );
                ret = true;
            } catch (SftpException e) {
                ret = false;
            }
            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        }  finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
        return ret;
	}

    public static InputStream getFileInputSteam(String host, String port, String user, String pass, String path ) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        byte[] bytes = null;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            try {
                bytes = IOUtils.toByteArray( sftpChannel.get( path ) );
            } catch (SftpException e) {
            }
            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        }  finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
        return bytes == null? null : new ByteArrayInputStream( bytes );
	}

    public static SftpATTRS getFileAttribute(String host, String port, String user, String pass, String path ) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        SftpATTRS attrs = null;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;

//            attrs = sftpChannel.lstat( path );
            attrs = sftpChannel.stat( path );
            
            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        }  finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
        return attrs;
	}

    public static Vector<ChannelSftp.LsEntry> getFileList(String host, String port, String user, String pass, String path ) throws Exception{
		JSch jsch = new JSch();
        Session session = null;
        Channel channel = null;
        ChannelSftp sftpChannel = null;
        Vector<ChannelSftp.LsEntry> list = null;
        try {
            session = jsch.getSession(user, host, new Integer( port ).intValue());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword( pass );
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();
            sftpChannel = (ChannelSftp) channel;
            sftpChannel.cd(path);
            list = sftpChannel.ls( "*.*" );

            sftpChannel.exit();
            session.disconnect();
        } catch (JSchException e) {
            throw e;
        }  finally {
            if (sftpChannel != null) session.disconnect();
            if (session != null) session.disconnect();
        }
        return list;
	}
}
