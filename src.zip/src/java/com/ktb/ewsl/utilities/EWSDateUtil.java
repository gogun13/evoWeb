/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.PropertyResourceBundle;

import org.apache.log4j.Logger;
/**
 *
 * @author KTBDevLoan
 */
public class EWSDateUtil {
    
    private static Logger logger = Logger.getLogger(EWSDateUtil.class);
    
    public static Locale localeThai = new Locale("TH","th");
     
    public static Locale locale = Locale.US;
        
    /**
     * String - dd/MM/yyyy
     */
    public static String FMT_VIEW = "dd/MM/yyyy";
        
    /**
     * String - dd/MM/yyyy HH:mm:ss
     */
    public static String FMT_TIMESTAMP = "dd/MM/yyyy HH:mm:ss";
    
    /**
     * String - HH:mm:ss
     */
    public static String FMT_TIMESTAMP_HHMM = "dd/MM/yyyy HH:mm";
    
    /**
     * String - HH:mm:ss
     */
    public static String FMT_VIEW_TIMESTAMP = "HH:mm:ss";
    
    public static String FMT_VIEW_EXPORT = "dd-MM-yyyy";
    
    /**
     * String - yyyy-MM-dd HH:mm:ss
     */
    public static String FMT_DB_TIMESTAMP = "yyyy-MM-dd HH:mm:ss";
    
    public static SimpleDateFormat sdf = new SimpleDateFormat(FMT_VIEW, locale);
    
    public static SimpleDateFormat sdfThai = new SimpleDateFormat(FMT_VIEW, localeThai);
    
    /**
     * String - DAY
     */
    public static String DAY = "DAY";
    
    /**
     * String - MONTH
     */
    public static String MONTH = "MONTH";
    
    /**
     * String - YEAR
     */
    public static String YEAR = "YEAR";
       
    /**
     * String - 00.00.0000
     */
    public static String DEFAULT_DATE = "00.00.0000";


    public static PropertyResourceBundle appSouce = (PropertyResourceBundle)PropertyResourceBundle.getBundle("applications",Locale.US);

    
    /** Creates a new instance of DateUtil */
    public EWSDateUtil()
    {
    }
    
    /**
     * @author Narin
     * @param date
     * @param patternOutput
     * @return String
     * @throws Exception
     */
    public static String displayDateFormat(Date date, String patternOutput)
    {
        String result = "";
        try
        {
            if (date == null || "".equals(date) || "-".equals(date))
                return "-";
            sdf.applyPattern(patternOutput);
            result = sdf.format(date);
        }
        catch (Exception e)
        {
            logger.error("", e);
        }
        return result;
    }
    
    /**
     * @author Narin
     * @param date
     * @param patternOutput
     * @return String
     * @throws Exception
     */
    public static String displayDateFormat(String date, String patternOutput)
    {
        if (date == null || "".equals(date))
            return "-";
        try
        {
            sdf.applyPattern(patternOutput);
            date = sdf.format(date);
        }
        catch (Exception e)
        {
            return date;
        }
        return date;
    }
    
    /**
     * @author Narin
     * @param date
     * @return String
     * @throws Exception
     */
    public static String dateFormat(Date date) throws Exception
    {
        return dateFormat(date, FMT_VIEW);
    }
    
    /**
     * @author Narin
     * @param date
     * @param patternOutput
     * @return String
     * @throws Exception
     */
    public static String dateFormat(Date date, String patternOutput) throws Exception
    {
        if (date == null)
            return "";
        sdf.applyPattern(patternOutput);
        return sdf.format(date);
    }
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date dateFormat(String strDate) throws Exception
    {
        if ("".equals(DefaultVariable.defaultString(strDate)))
            strDate = now();
        return dateFormat(strDate, FMT_VIEW, locale);
    }
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date dateFormatDB(String strDate) throws Exception
    {
        return dateFormat(strDate, FMT_DB_TIMESTAMP, false);
    }   
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date dateFormat(String strDate, String patternInput) throws Exception
    {
        if (strDate == null || "-".equals(strDate) || "".equals(DefaultVariable.defaultNull(strDate)))
            strDate = now();
        return dateFormat(strDate, patternInput, locale);
    }
        
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param satusNewDate
     * @return Date
     * @throws Exception
     */
    public static Date dateFormat(String strDate, String patternInput, boolean satusNewDate) throws Exception
    {
        if (strDate == null || "-".equals(strDate) || "".equals(DefaultVariable.defaultNull(strDate)))
        {
            if (satusNewDate)
                strDate = now();
            else
                return null;
        }
        return dateFormat(strDate, patternInput, locale);
    }
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date dateFormat(String strDate, String patternInput, Locale locale) throws Exception
    {
        if ("".equals(DefaultVariable.defaultString(strDate)))
            strDate = now();
        SimpleDateFormat fmt = new SimpleDateFormat(patternInput, locale);
        Date date = fmt.parse(strDate);
        return date;
    }
    
    /**
     * Date now.
     *
     * @author Narin
     * @return String
     * @throws Exception
     */
    public static String now() throws Exception
    {
        sdf.applyPattern(FMT_VIEW);
        return sdf.format(new Date());
    }
    
    /**
     * Date now format Thai.
     *
     * @author Narin
     * @return String
     * @throws Exception
     */
    public static String nowThai() throws Exception
    {
        sdfThai.applyPattern(FMT_VIEW);
        return sdfThai.format(new Date());
    }
    
    
    /**
     * Date now.
     *
     * @author Narin
     * @param pattern
     * @return String
     * @throws Exception
     */
    public static String now(String pattern) throws Exception
    {
        sdf.applyPattern(pattern);
        return sdf.format(new Date());
    }
    
    /**
     * Date now format DD/MM/YYYY.
     *
     * @author Narin
     * @return Date
     * @throws ParseException
     * @throws Exception
     */
    public static Date getDateNow() throws ParseException, Exception
    {
        return getDateNow(FMT_VIEW);
    }
    
    /**
     * Date now.
     *
     * @author Narin
     * @param pattern
     * @return Date
     * @throws ParseException
     * @throws Exception
     */
    public static Date getDateNow(String pattern) throws ParseException, Exception
    {
        SimpleDateFormat fmt = new SimpleDateFormat(pattern, locale);
        Date date = fmt.parse(now(pattern));
        return date;
    }
    
    
    /**
     * @author Narin
     * @param date
     * @return String
     * @throws Exception
     */
    public static Date displayDateFormatJumpDate(Date date, String filed, int hop) throws Exception
    {
        if (date == null)
            return null;
        if (filed == null)
            return date;
        
        Calendar calendar = dateToCalendar(date, FMT_VIEW);
//        Calendar calendar = new GregorianCalendar(locale);
//        calendar.setTime(date);
        
        if (YEAR.equals(filed))
        {
            calendar.add(Calendar.YEAR, hop);
        }
        else if (MONTH.equals(filed))
        {
            calendar.add(Calendar.MONTH, hop);
        }
        else if (DAY.equals(filed))
        {
            calendar.add(Calendar.DATE, hop);
        }
        return calendar.getTime();
    }
    
         
    /**
     * @author narin
     * @param String
     * @return String
     */
    public static String convertDateDB(String date, String datePattern) throws Exception
    {
        return dateToString(convertDateFormat(date, datePattern), datePattern, "");
    }
    
    public static Date convertDateEnToThai(Date inDate) throws Exception
    {   
        SimpleDateFormat fmt = new SimpleDateFormat(FMT_TIMESTAMP, locale);
        sdfThai.applyPattern(FMT_TIMESTAMP);
        Date date = fmt.parse(sdfThai.format(inDate));
        
        return date;
    }
    
    public static Date convertDateThaiToEn(Date inDate) throws Exception
    {
        SimpleDateFormat fmt = new SimpleDateFormat(FMT_TIMESTAMP, localeThai);
        sdf.applyPattern(FMT_TIMESTAMP);
        Date date = fmt.parse(sdf.format(inDate));
        
        return date;
        
    }
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date convertDateFormatThaiToEn(String strDate, String patternInput) throws Exception
    {
        if (strDate == null || "-".equals(strDate) || "".equals(DefaultVariable.defaultNull(strDate)))
        {
            return null;
        }
        else
        {
            return dateFormat(strDate, patternInput, localeThai);
        }
    }
    
    
    /**
     * @author narin
     * @param String
     * @return String - DEFAULT_DATE 00.00.0000
     */
    public static String convertDateDBThai(String date, String datePattern) throws Exception
    {
        return dateToStringThai(convertDateFormat(date, datePattern), datePattern, "");
    }
    
    /**
     * @author narin
     * @param date
     * @param datePattern
     * @param datePatternOutput
     * @return String
     */
    public static String convertDateDBThaiToEn(String date, String datePattern) throws Exception
    {
        return dateToString(convertDateFormatThai(date, datePattern), datePattern, "");
    }
    
    /**
     * @author narin
     * @param date
     * @param datePattern
     * @param datePatternOutput
     * @return String
     */
    public static String convertDateDBThaiToEn(String date, String datePattern, String datePatternOutput) throws Exception
    {
        return dateToString(convertDateFormatThai(date, datePattern), datePatternOutput, "");
    }
    
    /**
     * @author narin
     * @param Date
     * @param datePattern
     * @param defaultForNull
     * @return String
     */
    public static String dateToString(Date date, String datePattern, String defaultForNull) throws Exception
    {
        return dateToString(date, datePattern, defaultForNull, locale);
    }
    
    /**
     * @author narin
     * @param Date
     * @param datePattern
     * @param defaultForNull
     * @return String
     */
    public static String dateToStringThai(Date date, String datePattern, String defaultForNull) throws Exception
    {
        return dateToString(date, datePattern, defaultForNull, localeThai);
    }
    
    /**
     * @author narin
     * @param Date
     * @param datePattern
     * @param defaultForNull
     * @param Locale
     * @return String
     */
    private static String dateToString(Date date, String datePattern, String defaultForNull, Locale locale) throws Exception
    {
        if (date == null)
            return null;
        
        SimpleDateFormat sdf = new SimpleDateFormat(datePattern, locale);
        Calendar calendar = new GregorianCalendar(locale);
        calendar.setTime(sdf.parse(sdf.format(date)));
        
        return calendarToString(calendar, datePattern, defaultForNull, locale);
    }
    
    public static String calendarToString(Calendar dateValue, String datePattern, String defaultForNull, Locale locale) throws Exception
    {
        String output = defaultForNull;
        if (dateValue != null)
        {
            Date dateInput = dateValue.getTime();
            try
            {
                if (dateInput != null && datePattern != null)
                {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(datePattern, locale);
                    return dateFormat.format(dateInput);
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return output;
    }
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date convertDateFormatThai(String strDate, String patternInput) throws Exception
    {
        if (strDate == null || "-".equals(strDate) || "".equals(DefaultVariable.defaultNull(strDate)))
        {
            return null;
        }
        else
        {
            return dateFormat(strDate, patternInput, localeThai);
        }
    }
    
    /**
     * @author Narin
     * @param strDate
     * @param patternInput
     * @param locale
     * @return Date
     * @throws Exception
     */
    public static Date convertDateFormat(String strDate, String patternInput) throws Exception
    {
        if (strDate == null || "-".equals(strDate) || "".equals(DefaultVariable.defaultNull(strDate)))
        {
            return null;
        }
        else
        {
            return dateFormat(strDate, patternInput, locale);
        }
    }
    
    public static Calendar dateToCalendar(Date date, String format) throws Exception
    {
        if (date == null)
            return null;
        
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Calendar calendar = new GregorianCalendar(locale);
        calendar.setTime(sdf.parse(sdf.format(date)));
        
        return calendar;
    }
    
    public static Date calendarToDate(Calendar calendar, String format) throws Exception
    {        
        if (calendar == null)
            return null;
        
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Date date = sdf.parse(sdf.format(calendar.getTime()));
        
        return date;
    }
    
    
    /**
     * @author Narin
     * @param startDate
     * @param endDate
     * @param periodMonth
     * @param datePattern
     * @return boolean
     * @throws Exception
     */
    public static boolean periodDateBetween(String startDate, String endDate, int periodMonth, String datePattern) throws Exception
    {
        return periodDateBetween(dateFormat(startDate, datePattern), dateFormat(endDate, datePattern), periodMonth);
    }
    
    /**
     * @author Narin
     * @param startDate - Default format date DD/MM/YYYY
     * @param endDate - Default format date DD/MM/YYYY
     * @param periodMonth
     * @return boolean
     * @throws Exception
     */
    public static boolean periodDateBetween(String startDate, String endDate, int periodMonth) throws Exception
    {
        return periodDateBetween(dateFormat(startDate), dateFormat(endDate), periodMonth);
    }
    
    /**
     * @author Narin
     * @param startDate
     * @param endDate
     * @param periodMonth
     * @return boolean
     * @throws Exception
     */
    public static boolean periodDateBetween(Date startDate, Date endDate, int periodMonth) throws Exception
    {
        Calendar startCalendar = new GregorianCalendar(locale);
        startCalendar.setTime(startDate);
        
        Calendar endCalendar = new GregorianCalendar(locale);
        endCalendar.setTime(endDate);
        
        Date periodDate = displayDateFormatJumpDate(startDate, MONTH, periodMonth);
        Calendar periodMonthCalendar = new GregorianCalendar(locale);
        periodMonthCalendar.setTime(periodDate);
        
        int result = endCalendar.compareTo(periodMonthCalendar);
        if(result == 0 || result == 1)
        {
            return false;
        }
        return true;
    }
    
    public static String getDateName(String date)
    {
        try
        {
            if(!DefaultVariable.checkFieldIsNotNull(date)) return "";
            return convertDateName(dateFormat(date, FMT_VIEW), null);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "";
    }

      public static String getMonthYearName(String date)
    {
        try
        {
            if(!DefaultVariable.checkFieldIsNotNull(date)) return "";
            return convertMonthYearDateName(dateFormat(date, FMT_VIEW), null);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "";
    }

      public static String getMonthName(String date)
    {
        try
        {
            if(!DefaultVariable.checkFieldIsNotNull(date)) return "";
            return convertMonthDateName(dateFormat(date, FMT_VIEW), null);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "";
    }

    
    
    public static String getDateNameNowThai()
    {
        try
        {
            return getDateName(nowThai());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "";
    }
    
    public static String getDateNameNowEng()
    {
        try
        {
            return getDateName(now());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "";
    }
    
    /**
     * 
     * Default Locale Thai.
     *
     * @author Narin
     * @param Date
     * @return String
     * @throw Exception
     */
    public static String convertDateName(Date date) throws Exception
    {
        return convertDateName(date, null);
    }
    
    /**
     *
     * @author Narin
     * @param Date
     * @param Locale
     * @return String
     * @throw Exception
     */
    public static String convertDateName(Date date, Locale locale) throws Exception
    {   
        if(date == null)
        {
            return "";
        }
        if(locale == null)
        {
            locale = new Locale("TH","th");
        }
        Calendar calendar = dateToCalendar(date, FMT_VIEW);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK_IN_MONTH);
        int day = calendar.get(Calendar.DATE);
        int month = (calendar.get(Calendar.MONTH) + 1);
        int year = (calendar.get(Calendar.YEAR));        
        String dayOfWeekName = "";
        String monthName = "";
        String typeYear = "";
        if("TH".equalsIgnoreCase(locale.getLanguage()))
        {
            //dayOfWeekName = getDayOfWeekNameThai(dayOfWeek);
            monthName = getMonthThai(month);
            typeYear = appSouce.getString("L01024").toString();
        }
        else
        {
            dayOfWeekName = getDayOfWeekNameEng(dayOfWeek);
            monthName = getMonthEng(month);
        }
        return concatDateName(dayOfWeekName , day, monthName, year);
    }

    public static String concatDateName(String dayOfWeekName, int day, String monthName, int year)
    {
        return dayOfWeekName +" "+ day +" "+ monthName +" " + year;
    }
    
    public static  String getDayOfWeekNameThai(int inDayOfWeek)
    {
        if (inDayOfWeek == 1)
        {
            return appSouce.getString("L01026").toString();
        }
        else if (inDayOfWeek == 2)
        {
             return appSouce.getString("L01027").toString();
        }
        else if (inDayOfWeek == 3)
        {
             return appSouce.getString("L01028").toString();
        }
        else if (inDayOfWeek == 4)
        {
             return appSouce.getString("L01029").toString();
        }
        else if (inDayOfWeek == 5)
        {
             return appSouce.getString("L01030").toString();
        }
        else if (inDayOfWeek == 6)
        {
             return appSouce.getString("L01031").toString();
        }
        else if (inDayOfWeek == 7)
        {
             return appSouce.getString("L01032").toString();
        }
        return "";
    }
    
    public static String getDayOfWeekNameEng(int inDayOfWeek)
    {
        if (inDayOfWeek == 1)
        {
            return "Monday";
        }
        else if (inDayOfWeek == 2)
        {
            return "Tuesday";
        }
        else if (inDayOfWeek == 3)
        {
            return "Wednesday";
        }
        else if (inDayOfWeek == 4)
        {
            return "Thursday";
        }
        else if (inDayOfWeek == 5)
        {
            return "Friday";
        }
        else if (inDayOfWeek == 6)
        {
            return "Saturday";
        }
        else if (inDayOfWeek == 7)
        {
            return "Sunday";
        }
        return "";
    }
    
    public static String getMonthThai(int inMonth)
    {
        if (inMonth == 1)
        {
            return appSouce.getString("L01001").toString();
        }
        else if (inMonth == 2)
        {
           return appSouce.getString("L01002").toString();
        }
        else if (inMonth == 3)
        {
            return appSouce.getString("L01003").toString();
        }
        else if (inMonth == 4)
        {
            return appSouce.getString("L01004").toString();
        }
        else if (inMonth == 5)
        {
            return appSouce.getString("L01005").toString();
        }
        else if (inMonth == 6)
        {
            return appSouce.getString("L01006").toString();
        }
        else if (inMonth == 7)
        {
            return appSouce.getString("L01007").toString();
        }
        else if (inMonth == 8)
        {
            return appSouce.getString("L01008").toString();
        }
        else if (inMonth == 9)
        {
            return appSouce.getString("L01009").toString();
        }
        else if (inMonth == 10)
        {
            return appSouce.getString("L01010").toString();
        }
        else if (inMonth == 11)
        {
            return appSouce.getString("L01011").toString();
        }
        else if (inMonth == 12)
        {
            return appSouce.getString("L01012").toString();
        }
        return "";
    }


    
    public static String getMonthEng(int inMonth)
    {
        if (inMonth == 1)
        {
            return "January";
        }
        if (inMonth == 2)
        {
            return "February";
        }
        if (inMonth == 3)
        {
            return "March";
        }
        if (inMonth == 4)
        {
            return "April";
        }
        if (inMonth == 5)
        {
            return "May";
        }
        if (inMonth == 6)
        {
            return "June";
        }
        if (inMonth == 7)
        {
            return "July";
        }
        if (inMonth == 8)
        {
            return "August";
        }
        if (inMonth == 9)
        {
            return "September";
        }
        if (inMonth == 10)
        {
            return "October";
        }
        if (inMonth == 11)
        {
            return "November";
        }
        if (inMonth == 12)
        {
            return "December";
        }
        return "";
    }
    
    /**
     * @author Ness
     * @param valueDate :
     *            format date [ mm/dd/yyyy ]
     * @return boolean true = format valid
     */
    public static boolean validateFormatDate(String valueDate)
    {
        if(DefaultVariable.checkFieldIsNotNull(valueDate))
        {
            if(valueDate.length() >= 10)
            {
                if(valueDate.substring(2, 3).equals("/") && valueDate.substring(5, 6).equals("/"))
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Begin date must less than End date <br>
     * 
     * @author Ness
     * @param startDate
     * @param endDate
     * @param statusEqual
     * @return boolean false = More than
     */
    public static boolean beginDateLessThanEndDate(String startDate, String endDate, boolean statusEqual)
    {
        if(DefaultVariable.checkFieldIsNotNull(startDate) && DefaultVariable.checkFieldIsNotNull(endDate))
        {
            if(validateFormatDate(startDate) && validateFormatDate(endDate))
            {
                int subStartDate = DefaultVariable.defaultInt(startDate.substring(0, 2));
                int subStartMonth = DefaultVariable.defaultInt(startDate.substring(3, 5));
                int subStartYear = DefaultVariable.defaultInt(startDate.substring(6, startDate.length()));

                int subEndDate = DefaultVariable.defaultInt(endDate.substring(0, 2));
                int subEndMonth = DefaultVariable.defaultInt(endDate.substring(3, 5));
                int subEndYear = DefaultVariable.defaultInt(endDate.substring(6, endDate.length()));

                if(subStartYear > subEndYear)
                {
                    return false;
                }
                else if(subStartYear == subEndYear)
                {
                    if(subStartMonth > subEndMonth)
                    {
                        return false;
                    }
                    else if(subStartMonth == subEndMonth)
                    {
                        if(subStartDate > subEndDate)
                        {
                            return false;
                        }
                        else if(!statusEqual && subStartDate == subEndDate)
                        {
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }


    public static String getMonthShortThai(int inMonth)
    {
        if (inMonth == 1)
        {
            return appSouce.getString("L01013").toString();
        }
        else if (inMonth == 2)
        {
            return appSouce.getString("L01014").toString();
        }
        else if (inMonth == 3)
        {
            return appSouce.getString("L01015").toString();
        }
        else if (inMonth == 4)
        {
            return appSouce.getString("L01016").toString();
        }
        else if (inMonth == 5)
        {
            return appSouce.getString("L01017").toString();
        }
        else if (inMonth == 6)
        {
            return appSouce.getString("L01018").toString();
        }
        else if (inMonth == 7)
        {
            return appSouce.getString("L01019").toString();
        }
        else if (inMonth == 8)
        {
            return appSouce.getString("L01020").toString();
        }
        else if (inMonth == 9)
        {
           return appSouce.getString("L01021").toString();
        }
        else if (inMonth == 10)
        {
            return appSouce.getString("L01022").toString();
        }
        else if (inMonth == 11)
        {
            return appSouce.getString("L01023").toString();
        }
        else if (inMonth == 12)
        {
           return appSouce.getString("L01024").toString();
        }
        return "";
    }

      public static String convertMonthYearDateName(Date date, Locale locale) throws Exception
    {
        if(date == null)
        {
            return "";
        }
        if(locale == null)
        {
            locale = new Locale("TH","th");
        }
        Calendar calendar = dateToCalendar(date, FMT_VIEW);
        //int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK_IN_MONTH);
        //int day = calendar.get(Calendar.DATE);
        int month = (calendar.get(Calendar.MONTH) + 1);
        int year = (calendar.get(Calendar.YEAR));
        //String dayOfWeekName = "";
        String monthName = "";
        //String typeYear = "";
        if("TH".equalsIgnoreCase(locale.getLanguage()))
        {
            //dayOfWeekName = getDayOfWeekNameThai(dayOfWeek);
            monthName = getMonthShortThai(month);
            //typeYear = "?.?.";
        }
        else
        {
            //dayOfWeekName = getDayOfWeekNameEng(dayOfWeek);
            monthName = getMonthEng(month);
        }
        return concatMonthYearDateName( monthName, year-2500);
    }

      public static String convertMonthDateName(Date date, Locale locale) throws Exception
    {
        if(date == null)
        {
            return "";
        }
        if(locale == null)
        {
            locale = new Locale("TH","th");
        }
        Calendar calendar = dateToCalendar(date, FMT_VIEW);

        int month = (calendar.get(Calendar.MONTH) + 1);
        int year = (calendar.get(Calendar.YEAR));

        String monthName = "";

        if("TH".equalsIgnoreCase(locale.getLanguage()))
        {

            monthName = getMonthThai(month)+" "+year;

        }
        else
        {

            monthName = getMonthEng(month)+" "+(year-543);
        }
        return monthName;
    }

     public static String concatMonthYearDateName(String monthName, int year)
    {
        return monthName +" " + year;
    }

    public static int dateDifference(Date date1, Date date2) {
        try {
            long diffTime = date1.getTime() - date2.getTime();
            long diffDay = diffTime / (24 * 60 * 60 * 1000);
            return Integer.parseInt("" + diffDay);
        } catch (Exception ex) {}
        return 0;
    }

  
    /**
     *
     * @param startDate format 'MMYYYY'.
     * @param diffDate number of difference date (diffDate >= 0).
     * @return list of month format 'MMYYYY'.
     */
    public static List<String> getListMonthDate(String startDate, int diffDate) {
        List<String> monthList = new ArrayList<String>();
        monthList.add(startDate);
        if (diffDate > 0) {
            Calendar date = Calendar.getInstance();
            date.set(Calendar.DATE, 1);
            date.set(Calendar.MONTH, Integer.parseInt(startDate.substring(0, 2)) - 1);
            date.set(Calendar.YEAR, Integer.parseInt(startDate.substring(2)));
            for (int i = 0; i < diffDate; i++) {
                date.add(Calendar.MONTH, 1);
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMyyyy");
                monthList.add(dateFormat.format(date.getTime()));
            }
        } else if (diffDate < 0) {
            Calendar date = Calendar.getInstance();
            date.set(Calendar.DATE, 1);
            date.set(Calendar.MONTH, Integer.parseInt(startDate.substring(0, 2)) - 1);
            date.set(Calendar.YEAR, Integer.parseInt(startDate.substring(2)));
            for (int i = 0; i > diffDate; i--) {
                date.add(Calendar.MONTH, -1);
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMyyyy");
                monthList.add(dateFormat.format(date.getTime()));
            }
        }
        return monthList;
    }

    public static String getFirstDayOfMonth(String date) throws ParseException {
        return getFirstDayOfMonth(date, FMT_VIEW, Locale.US);

    }

    public static String getFirstDayOfMonth(String date, String datePattern) throws ParseException {
        return getFirstDayOfMonth(date, datePattern, Locale.US);
    }

    public static String getFirstDayOfMonth(String date, String datePattern, Locale dateLocale) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat(datePattern, dateLocale);
        df.setLenient(false);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(df.parse(date));
        calendar.set(Calendar.DAY_OF_MONTH, 1);     // Set day is 1.
        return df.format(new Date(calendar.getTimeInMillis()));
    }


    public static String getEndDayOfMonth(String date) throws ParseException {
        return getEndDayOfMonth(date, FMT_VIEW, Locale.US);

    }

    public static String getEndDayOfMonth(String date, String datePattern) throws ParseException {
        return getEndDayOfMonth(date, datePattern, Locale.US);
    }

    public static String getEndDayOfMonth(String date, String datePattern, Locale dateLocale) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat(datePattern, dateLocale);
        df.setLenient(false);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(df.parse(date));
        calendar.set(Calendar.DAY_OF_MONTH, 1);     // Set day is 1.
        calendar.add(Calendar.MONTH, 1);            // Go to next month.
        calendar.add(Calendar.DAY_OF_MONTH, -1);    // Minus 1 day.
        return df.format(new Date(calendar.getTimeInMillis()));
    }
}
