/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.utilities;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FontUnderline;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author PoUnDZaa
 */
public class ExcelUtils {
    private XSSFFont        defaultFont         = null;
    private XSSFFont        fontBold            = null;
    private XSSFWorkbook    workbook            = null;
    private XSSFCellStyle   cellStyleCenter 	= null;

    public ExcelUtils(){
        workbook 	= new XSSFWorkbook();
        defaultFont	= workbook.createFont();

        defaultFont.setFontHeightInPoints((short)11);
        defaultFont.setFontName("Tahoma");
        defaultFont.setColor(IndexedColors.BLACK.getIndex());
        defaultFont.setBold(false);
        defaultFont.setItalic(false);

        fontBold	= workbook.createFont();
        fontBold.setFontHeightInPoints((short)11);
        fontBold.setFontName("Tahoma");
        fontBold.setColor(IndexedColors.BLACK.getIndex());
        fontBold.setBold(true);
        fontBold.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
        fontBold.setItalic(false);
        
        cellStyleCenter = workbook.createCellStyle();
        cellStyleCenter.setAlignment		(CellStyle.ALIGN_CENTER);
        cellStyleCenter.setVerticalAlignment	(CellStyle.VERTICAL_BOTTOM);
        cellStyleCenter.setFont(defaultFont);
    }

    public XSSFWorkbook getWorkbook() {
        return workbook;
    }
	
    public XSSFCell setCell(String msg, int rows, int cols, short align, short valign, boolean bold, boolean border, XSSFSheet worksheet, boolean autoSize) throws Exception{
        XSSFRow 		row 		= null;
        XSSFCell 		cell 		= null;
        XSSFCellStyle 	cellStyle 	= null;

        try{
            row 	= worksheet.getRow(rows);
            row 	= row==null?worksheet.createRow((short) rows):row;
            cell 	= row.createCell((short) cols);
            cellStyle 	= workbook.createCellStyle();

            cell.setCellValue			(msg);
            cellStyle.setAlignment		(align);
            cellStyle.setVerticalAlignment	(valign);

            if(border==true){
                setBorder(cellStyle);
            }

            if(bold==true){
                cellStyle.setFont(fontBold);
            }else{
                cellStyle.setFont(defaultFont);
            }
            
            cell.setCellStyle(cellStyle);
            
            if(autoSize){
                workbook.getSheetAt(0).autoSizeColumn(cols,true);
            }

        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }

        return cell;
    }
    
    public XSSFCell setCellTableData(String msg, int rows, int cols, XSSFSheet worksheet) throws Exception{
        XSSFRow 		row 		= null;
        XSSFCell 		cell 		= null;

        try{
            row 	= worksheet.getRow(rows);
            row 	= row==null?worksheet.createRow((short) rows):row;
            cell 	= row.createCell((short) cols);

            cell.setCellValue			(msg);
            
            cell.setCellStyle(cellStyleCenter);

        }catch(Exception e){
            throw e;
        }

        return cell;
    }
	
    private void setBorder(CellStyle cellStyle) throws Exception{
        try{
            if(cellStyle!=null){
                cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
                cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
                cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
                cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
                cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
                cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
                cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
            }
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }
    }
	
    public void setBackGroundColor(XSSFCell cell, int r, int g, int b) throws Exception{
        XSSFCellStyle  	cellStyle 	= null;

        try{
            cellStyle = cell.getCellStyle();

            if(cellStyle!=null){
                cellStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(r, g, b)));
                cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
            }
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }
    }
    
    public void setFontColor(XSSFCell cell, int r, int g, int b ,boolean bold ,boolean underLine) throws Exception{
        XSSFCellStyle  	cellStyle 	= null;

        try{
            cellStyle = cell.getCellStyle();

            if(cellStyle!=null){
                XSSFFont font = workbook.createFont();
                
                font.setFontHeightInPoints((short)11);
                font.setFontName("Tahoma");
                font.setColor(new XSSFColor(new java.awt.Color(r, g, b)));
                if(bold==true){
                    font.setBold(true);
                    font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
                }
                font.setItalic(false);
                
                if(underLine==true){
                    font.setUnderline(FontUnderline.SINGLE);
                }
                
                
                cellStyle.setFont(font);
            }
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }
    }
    
    public void mergedCell(int rowIndex, int cellFrom, int cellTo, boolean border, XSSFSheet worksheet ,boolean autoSize) throws Exception{
        try{
            for(int i=cellFrom;i<cellTo;i++){
                setCell("", rowIndex, (i+1), CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, border, worksheet,autoSize);
            }
            
            worksheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, cellFrom, cellTo));
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }
    }
    
    public void mergedRow(int cellIndex, int rowFrom, int rowTo, boolean border, XSSFSheet worksheet,boolean autoSize) throws Exception{
        try{
            for(int i=rowFrom;i<rowTo;i++){
                setCell("", (i+1), cellIndex, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, border, worksheet,autoSize);
            }
            
            worksheet.addMergedRegion(new CellRangeAddress(rowFrom, rowTo, cellIndex, cellIndex));
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }
    }
    
}
