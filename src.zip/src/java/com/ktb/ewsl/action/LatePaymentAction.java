/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.services.AsstAnswerService;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class LatePaymentAction extends BaseAction {
    private static final Logger logger = Logger.getLogger(LatePaymentAction.class);
    private String cifNo;
    private int warningHeaderId;
    private int warningInfoId;
    private String warningType;
    private String infoStatus;
    private List<QuestionHistoryVo>  questionHistoryList;
    private List<ActionHistoryVo> actionHistoryVoList;
    private List<AsstTopicVo> asstTopicVoList;
    private List<AsstTopicVo> asstTopicVoListForOldAnswer;//---RM/AE/AO
    private List<AsstTopicVo> asstTopicVoListHistory;
    private ArrayList<AsstSubtopicVo> asstSubtopicVoListRM;
    private String approveFlag = BusinessConst.Flag.N;
    private String rejectFlag = BusinessConst.Flag.N;
    private String saveFlag = BusinessConst.Flag.N;
    private String finalLevel;
    private String showSaveFinal = BusinessConst.Flag.N;
    private String showMode;
    private List<String> requireList;
    private List<String> questionList;
    private String actionMode;
    private List<String> answers;
    private List<String> answersTemp;
    private List<String> remarks;
    private String questionId;
    private String version;
    private String showResult;
    private String latePayLevel;
    private String latePayAdvice;
    private String latePayAdvice1 = BusinessConst.Flag.N;
    private String wordlatePayAdvice1;
    private String latePayAdvice2 = BusinessConst.Flag.N;
    private String wordlatePayAdvice2;
    private String latePayAdvice3 = BusinessConst.Flag.N;
    private String wordlatePayAdvice3;
    private String SUGGESTION = "SUGGESTION";
    private String ADDITIONAL = "ADDITIONAL";
    private List<String> answersResult;
    private String currentUserRole;
    private String forBackPage;
    private String warningInfoDateStr;
    private String editFlag = BusinessConst.Flag.N;
    private String editRadioFlag = BusinessConst.Flag.N;
    private String buttonSetOfEditFlag = BusinessConst.Flag.N;
    private String warningIdHistory;
    private String warningHeaderIdHistory;
    private String actionDateHistory;
    private String versionHistory;
    private String questionIdHistory;
    private String warningTypeHistory;
    
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private AsstAnswerService asstAnswerService;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness;
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    
     @Override
    public String success() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("success");
            logger.debug(" getCifNo : " + getCifNo());
            logger.debug(" getWarningHeaderId : " + getWarningHeaderId());
            logger.debug(" getWarningInfoId : " + getWarningInfoId());
            logger.debug(" getWarningType : " + getWarningType());
            logger.debug(" getInfoStatus : " + getInfoStatus());
        }
        
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if(titleVo != null){
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        }
        setCurrentUserRole(getCurrentUser() != null ?  getCurrentUser().getRoleId() : "");

        if (asstTopicVoList == null && titleVo != null) {
            //-------- Find 
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            filter.setWarningHeaderId(getWarningHeaderId());
            filter.setWarningId(getWarningInfoId());
            filter.setWarningType(getWarningType());
            filter.setInfoStatus(getInfoStatus());
            findData(filter);
        }

        //find form history
        findQuestionHistory(this.cifNo);
         
        /*begin Release 3.1*/
        if (EWSConstantValue.ROLE_EDITOR_OLD.contains(getCurrentUser().getRoleId())) {
            WarningHeaderVo wh = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
            if(wh!=null){
                if(!ValidatorUtil.isNullOrEmpty(wh.getCoRespUnitStr()) && !"0".equals(wh.getCoRespUnitStr())){
                    showMode = "true";
                    approveFlag = BusinessConst.Flag.N;
                    rejectFlag = BusinessConst.Flag.N;
                    saveFlag = BusinessConst.Flag.N;
                    editFlag = BusinessConst.Flag.N;
                }
            }
        }
        /*end Release 3.1*/
         
        if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
            if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                showMode = "true";
                approveFlag = BusinessConst.Flag.N;
                rejectFlag = BusinessConst.Flag.N;
                saveFlag = BusinessConst.Flag.N;
                editFlag = BusinessConst.Flag.N;
            }
            
            request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
        }
         
        return SUCCESS;
    }
     
     private void findData(AsstTopicVo filter) throws Exception {
//        filter
//        1. warningId
//        2. questionId
//        3. version

        UserData userData = getCurrentUser();
        filter.setWarningHeaderId(warningHeaderId);
        filter.setInfoStatus(infoStatus);
        filter.setWarningId(warningInfoId);
        filter.setWarningType(warningType);
        this.asstTopicVoList = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);

        if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.RMP.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
                approveFlag = BusinessConst.Flag.N;
                rejectFlag = BusinessConst.Flag.N;
                editFlag = BusinessConst.Flag.N;
              if (EWSConstantValue.ROLE_EDITOR_EWSL.contains(userData.getRoleId())) {
                    if(!BusinessConst.UserRole.RISK_EDITOR.equals(userData.getRoleId())){
                         saveFlag = BusinessConst.Flag.Y;
                    }
               }
            //--------- Validate Buttom ----------------//
            if(BusinessConst.Flag.RMP.equals(infoStatus)|| BusinessConst.Flag.BRMP.equals(infoStatus)){
                WarningInfoVo infoVo =  warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                if(infoVo != null){
                    if(EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(infoVo.getHolderRole()) &&
                             EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(getCurrentUser().getRoleId())){
                        saveFlag = BusinessConst.Flag.Y;
                    }else if((BusinessConst.UserRole.BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()))
                                || (BusinessConst.UserRole.CO_BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId()))){
                         saveFlag = BusinessConst.Flag.Y;
                    }else{
                        saveFlag = BusinessConst.Flag.N;
                    }
                }
            }
           
           
        } else if (EWSConstantValue.ROLE_APPROVE.contains(userData.getRoleId()) && BusinessConst.Flag.RMF.equals(infoStatus)) {
            approveFlag = BusinessConst.Flag.Y;
            rejectFlag = BusinessConst.Flag.Y;
            saveFlag = BusinessConst.Flag.N;
            editFlag = BusinessConst.Flag.Y;
        }
        
       this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(warningInfoId);
 
       if (BusinessConst.Flag.Y.equals(saveFlag)) { 
            showMode = "false";
       } else {
           showMode = "true"; 
       }
       
       WarningInfoVo  infoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, BusinessConst.WarningTypeCode.LATE_PAY);
       if(infoVo != null){
            setWarningInfoDateStr(infoVo.getWarningDateStr() != null ? infoVo.getWarningDateStr() : "");
            String lpAdvice = !ValidatorUtil.isNullOrEmpty(infoVo.getBcmLatePayAdvice()) ? infoVo.getBcmLatePayAdvice() : infoVo.getLatePayAdvice();
            String lpLevel  = !ValidatorUtil.isNullOrEmpty(infoVo.getBcmLatePayLevel()) ? infoVo.getBcmLatePayLevel() : infoVo.getLatePayLevel();
            if(!ValidatorUtil.isNullOrEmpty(lpAdvice) && !ValidatorUtil.isNullOrEmpty(lpLevel)){
                latePayLevel = lpLevel; 
                latePayAdvice = lpAdvice;
                 String[] lpaArray = latePayAdvice.split("&",-1);
                 for(String data : lpaArray){
                     if("1".equals(data)){
                           latePayAdvice1 = BusinessConst.Flag.Y;
                     }else if("2".equals(data)){
                           latePayAdvice2 = BusinessConst.Flag.Y;
                     }else if("3".equals(data)){
                           latePayAdvice3 = BusinessConst.Flag.Y;
                     }
                 }
                 if(lpaArray.length > 1){
                     if("1&2".equals(latePayAdvice)){
                         wordlatePayAdvice1 = SUGGESTION;
                         wordlatePayAdvice2 = ADDITIONAL;
                         wordlatePayAdvice3 = null;
                     }else if("1&3".equals(latePayAdvice)){
                         wordlatePayAdvice1 = SUGGESTION;
                         wordlatePayAdvice2 = null;
                         wordlatePayAdvice3 = ADDITIONAL;
                     }else if("2&3".equals(latePayAdvice)){
                         wordlatePayAdvice1 = null;
                         wordlatePayAdvice2 = SUGGESTION;
                         wordlatePayAdvice3 = ADDITIONAL;
                     }
                 }else{
                     wordlatePayAdvice1 = SUGGESTION;
                     wordlatePayAdvice2 = SUGGESTION;
                     wordlatePayAdvice3 = SUGGESTION;
                 }
                 //----------------------- ANSWER --------------//

                 if(!asstTopicVoList.isEmpty()){ 
                   //-Start------- NOT Display LAST TOPIC "Other" 
                     Integer lastSubtopic = null;
                     if(!ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionId()) && !ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionVersion())){
                          lastSubtopic = asstQuestionBusiness.getLastSubTopic(infoVo.getAnswerQuestionId(), infoVo.getAnswerQuestionVersion());
                     }
                  //-END--------------------------------------------------------
                     answersResult = new ArrayList<String>();
                       for(AsstTopicVo topicAns : asstTopicVoList){
                           for( AsstSubtopicVo subTopicAns : topicAns.getAsstSubtopicVoList() ){
                                    if("1".equals(subTopicAns.getAnswer())){
                                        if(lastSubtopic != null && lastSubtopic > 0 && lastSubtopic == subTopicAns.getSubTopicId()){
                                            break;
                                        }
                                        answersResult.add(subTopicAns.getSubTopicId()+"."+subTopicAns.getSubTopicDesc());
                                    }
                           }
                       }
                 }
                 showResult = "true";
            }else{
                 showResult = "false";
            } 
        }else{
            showResult = "false";
        } 
    }
     public void findQuestionHistory(String cif) throws Exception{
        List<QuestionHistoryVo> historyList ;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cif, warningType); //warningHeaderBusiness.findWarningIdForQuestion(cif, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                    vo.setActionDetail(warningType);
                    vo.setWarningType(warningType);
                    vo.setCif(cif);
                    historyList = actionHistoryBusiness.findQuestionHistory(vo);
                    if (historyList != null && !historyList.isEmpty()) {
                        tmpVo = (QuestionHistoryVo) historyList.get(0);
                        vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                        vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                        vo.setActionUserId(tmpVo.getActionUserId());
                        vo.setActionDate(tmpVo.getActionDate());
                        vo.setApproveUserId(tmpVo.getApproveUserId());
                        vo.setApproveDate(tmpVo.getApproveDate());
                        vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                        vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                        vo.setCif(cif);
                        resultList.add(vo);
                    }  
                }
                if(resultList.size() > 0){
                    setQuestionHistoryList(resultList);
                }
            }
    }
     
      public String saveData() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("saveData");
            logger.debug(" warningInfoId >>" + warningInfoId);
            logger.debug(" answers.size >>" + answers == null ? 0 : answers.size());
            logger.debug(" remarks.size >>" + remarks == null ? 0 : remarks.size());
            logger.debug(" questionList.size() >>" + questionList != null ?  questionList.size() : 0);
            logger.debug(" getwarningHeaderId >>" + warningHeaderId);
        }
        String questionIdSave = "";
        String versionSave = "";
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if (questionList != null) {
            List<AsstAnswerVo> asstAnswerVoList = new ArrayList<AsstAnswerVo>();
            AsstAnswerVo asstAnswerVo;
            int tmp = 0;
            for (String question : questionList) {
                if ("Save".equals(actionMode)) {
                    if ("1".equals(requireList.get(tmp))) {
                        if (answers == null || answers.size() < questionList.size() || answers.get(tmp) == null || answers.get(tmp).trim().length() <= 0) {
                            throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                        }
                        int yes = 0;
                        for(int i=0 ; i < answers.size() ; i++ ){ /** Check Last SubTop "Other" Fix "ใช่" *****/
                              String ans = (String)answers.get(i);
                               if("1".equals(ans)){
                                   if(i != (answers.size() - 1)){
                                       yes  = yes + 1;
                                   }
                              }
                        }
                        /*for(String ans : answers){
                              if("1".equals(ans)){
                                   yes  = yes + 1;
                              }
                        }*/
                        //logger.debug(" yes >>" + yes);
                        if(yes == 0){
                            if(remarks != null && remarks.size() > 0 && questionList != null && questionList.size() > 0 ){
                                 int indexTextAreaOther = questionList.size()-1;
                                 if(indexTextAreaOther <= remarks.size()){
                                    String remarkOther = remarks.get(indexTextAreaOther);
                                    if(ValidatorUtil.isNullOrEmpty(remarkOther)){
                                        throw new BusinessException("กรุณาระบุเหตุผลในช่องอื่นๆด้วย");
                                    }
                                 }
                            }else{
                                 throw new BusinessException("กรุณาระบุเหตุผลในช่องอื่นๆด้วย");
                            }     
                        }else{
                            if(yes > 3){
                                throw new BusinessException("สามารถเลือกตอบ ใช่ ได้สูงสุดไม่เกิน 3 ข้อ");
                            }
                        }
                    }      
                }

                asstAnswerVo = new AsstAnswerVo();
                String[] s = question.split("\\,", -1);
                if (s != null && s.length > 0) {
                    questionIdSave = s[0];
                    versionSave = s[1];
                    asstAnswerVo.setQuestionId(questionIdSave);
                    asstAnswerVo.setVersion(versionSave);
                    asstAnswerVo.setTopicId(Integer.parseInt(s[2]));
                    asstAnswerVo.setSubTopicId(Integer.parseInt(s[3]));
                    if (s[4] != null && s[4].trim().length() > 0) {
                        asstAnswerVo.setWarningId(Integer.parseInt(s[4]));
                    }
                    if (s[5] != null && s[5].trim().length() > 0) {
                        asstAnswerVo.setWarningType(s[5]);
                    }
                }
                if (answers != null) {
                    if (answers.size() > tmp) {
                        if (answers.get(tmp) != null) {
                            asstAnswerVo.setChoiceId(Integer.parseInt(answers.get(tmp)));
                            if (remarks != null) {
                                if (remarks.get(tmp) != null) {
                                    asstAnswerVo.setChoiceReason(remarks.get(tmp));
                                }
                            }
                            if (asstAnswerVo.getWarningId() <= 0) {
                                asstAnswerVo.setWarningId(warningInfoId);
                            }
                            if (asstAnswerVo.getWarningType() == null || asstAnswerVo.getWarningType().trim().length() <= 0) {
                                asstAnswerVo.setWarningType(warningType);
                            }
                            asstAnswerVo.setWarningHeaderId(titleVo.getWarningHeaderId());
                            asstAnswerVo.setCifNo(titleVo.getCifNo());
                            asstAnswerVoList.add(asstAnswerVo);
                        }
                    }
                }
                tmp++;
            }
            if (asstAnswerVoList.size() > 0) {
                infoStatus = asstQuestionBusiness.saveAsstAnswer(asstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType);
            }
        }

        if ("Draft".equals(actionMode)) {
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            findData(filter);
            showSaveFinal = BusinessConst.Flag.N;
        }
        if("Save".equals(actionMode) && getCurrentUser() != null){
           logger.debug("warningHeaderId >>" + warningHeaderId);
           logger.debug("warningInfoId >>" + warningInfoId);
           logger.debug("warningType >>" + warningType);
              if(BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())){
                    WarningInfoVo infoAfterApprove = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                    if(infoAfterApprove != null){ //--- For hide buttom after approve
                         setInfoStatus(infoAfterApprove.getStatus());
                         setActionMode("Approve");
                    }
                 doApprove();
              }else{
                  if(!ValidatorUtil.isNullOrEmpty(questionIdSave) && !ValidatorUtil.isNullOrEmpty(versionSave)){
                    //----------------------------------------//    
                      AsstTopicVo asstTopicVo = new AsstTopicVo();
                        asstTopicVo.setWarningHeaderId(warningHeaderId);
                        asstTopicVo.setWarningType(warningType);
                        asstTopicVo.setWarningId(warningInfoId);
                        asstTopicVo.setQuestionId(questionIdSave);
                        asstTopicVo.setVersion(versionSave);
                        asstTopicVo.setCifNo(titleVo.getCifNo());
                        asstTopicVo.setCustName(titleVo.getCustName());
                        asstTopicVo.setActionForm(BusinessConst.ACTION_CODE.SEND_JOB);
                        asstQuestionBusiness.sendScroe(asstTopicVo, getCurrentUser());
                        
                        //-------- Find 
                        WarningInfoVo infoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                        if(infoVo != null){
                            AsstTopicVo filter = new AsstTopicVo();
                            filter.setCifNo(titleVo.getCifNo());
                            filter.setWarningHeaderId(getWarningHeaderId());
                            filter.setWarningId(getWarningInfoId());
                            filter.setWarningType(getWarningType());
                            filter.setInfoStatus(getInfoStatus());
                            findData(filter);
                            return "showPopupSuggestion";
                        }
                 } 
              }    
        }

        return SUCCESS;
    }
      
      
    public String doEdit() throws Exception {
     
        if (logger.isDebugEnabled()) {
            logger.debug("success");
            logger.debug(" getCifNo : " + getCifNo());
            logger.debug(" getWarningHeaderId : " + getWarningHeaderId());
            logger.debug(" getWarningInfoId : " + getWarningInfoId());
            logger.debug(" getWarningType : " + getWarningType());
            logger.debug(" getInfoStatus : " + getInfoStatus());
        }
        
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if(titleVo != null){
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        }
        setCurrentUserRole(getCurrentUser() != null ?  getCurrentUser().getRoleId() : "");

         //find form history
         findQuestionHistory(this.cifNo);
         
        if (asstTopicVoList == null && titleVo != null) {
            //-------- Find 
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            filter.setWarningHeaderId(getWarningHeaderId());
            filter.setWarningId(getWarningInfoId());
            filter.setWarningType(getWarningType());
            filter.setInfoStatus(getInfoStatus());
            this.asstTopicVoList = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
            if(asstTopicVoList != null){
               for(AsstTopicVo topicTemp : asstTopicVoList){
                   asstSubtopicVoListRM  = topicTemp.getAsstSubtopicVoList();
               }
               
               filter.setRequireOldAnswer(BusinessConst.Flag.Y);
               this.asstTopicVoListForOldAnswer = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
               if(asstTopicVoListForOldAnswer != null && asstTopicVoListForOldAnswer.size() == 1){ //----- HAVE ONLY TOPIC
                AsstTopicVo oldAnswer = (AsstTopicVo)asstTopicVoListForOldAnswer.get(0);
                if(oldAnswer != null && oldAnswer.getAsstSubtopicVoList() != null){
                  for(AsstTopicVo asstTopicVoResult :  asstTopicVoList){
                         for(AsstSubtopicVo subTopicVo :  asstTopicVoResult.getAsstSubtopicVoList()){
                             for(AsstSubtopicVo subTopicVoOLD : oldAnswer.getAsstSubtopicVoList()){
                                if((subTopicVo.getTopicId() == subTopicVoOLD.getTopicId())&&(subTopicVo.getSubTopicId() == subTopicVoOLD.getSubTopicId())
                                        &&(subTopicVo.getQuestionId().equals(subTopicVoOLD.getQuestionId()))&&(subTopicVo.getVersion().equals(subTopicVoOLD.getVersion()))){
                                   subTopicVo.setAnswerRM(subTopicVoOLD.getAnswer());
                                   break;
                                }
                             }
                         }
                  }
                }
            }
            }
        }

     //------------------------------
        approveFlag = BusinessConst.Flag.N;
        rejectFlag = BusinessConst.Flag.N;
        saveFlag = BusinessConst.Flag.N;
        editFlag = BusinessConst.Flag.N;
        editRadioFlag = BusinessConst.Flag.Y;
        buttonSetOfEditFlag = BusinessConst.Flag.Y;
        
       this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(warningInfoId);
       showMode = "false";
      
       
       WarningInfoVo  infoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, BusinessConst.WarningTypeCode.LATE_PAY);
       if(infoVo != null){
            setWarningInfoDateStr(infoVo.getWarningDateStr() != null ? infoVo.getWarningDateStr() : "");
            String lpAdvice = !ValidatorUtil.isNullOrEmpty(infoVo.getBcmLatePayAdvice()) ? infoVo.getBcmLatePayAdvice() : infoVo.getLatePayAdvice();
            String lpLevel = !ValidatorUtil.isNullOrEmpty(infoVo.getBcmLatePayLevel()) ? infoVo.getBcmLatePayLevel() : infoVo.getLatePayLevel();
            if(!ValidatorUtil.isNullOrEmpty(lpAdvice) && !ValidatorUtil.isNullOrEmpty(lpLevel)){
                latePayLevel = lpLevel; 
                latePayAdvice = lpAdvice;
                 String[] lpaArray = latePayAdvice.split("&",-1);
                 for(String data : lpaArray){
                     if("1".equals(data)){
                           latePayAdvice1 = BusinessConst.Flag.Y;
                     }else if("2".equals(data)){
                           latePayAdvice2 = BusinessConst.Flag.Y;
                     }else if("3".equals(data)){
                           latePayAdvice3 = BusinessConst.Flag.Y;
                     }
                 }
                 if(lpaArray.length > 1){
                     if("1&2".equals(latePayAdvice)){
                         wordlatePayAdvice1 = SUGGESTION;
                         wordlatePayAdvice2 = ADDITIONAL;
                         wordlatePayAdvice3 = null;
                     }else if("1&3".equals(latePayAdvice)){
                         wordlatePayAdvice1 = SUGGESTION;
                         wordlatePayAdvice2 = null;
                         wordlatePayAdvice3 = ADDITIONAL;
                     }else if("2&3".equals(latePayAdvice)){
                         wordlatePayAdvice1 = null;
                         wordlatePayAdvice2 = SUGGESTION;
                         wordlatePayAdvice3 = ADDITIONAL;
                     }
                 }else{
                     wordlatePayAdvice1 = SUGGESTION;
                     wordlatePayAdvice2 = SUGGESTION;
                     wordlatePayAdvice3 = SUGGESTION;
                 }
                 //----------------------- ANSWER --------------//
                 if(!asstTopicVoList.isEmpty()){ 
                   //-Start------- NOT Display LAST TOPIC "Other" 
                     Integer lastSubtopic = null;
                     if(!ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionId()) && !ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionVersion())){
                          lastSubtopic = asstQuestionBusiness.getLastSubTopic(infoVo.getAnswerQuestionId(), infoVo.getAnswerQuestionVersion());
                     }
                  //-END--------------------------------------------------------
                     answersResult = new ArrayList<String>();
                       for(AsstTopicVo topicAns : asstTopicVoList){
                           for( AsstSubtopicVo subTopicAns : topicAns.getAsstSubtopicVoList() ){
                                    if("1".equals(subTopicAns.getAnswer())){
                                        if(lastSubtopic != null && lastSubtopic > 0 && lastSubtopic == subTopicAns.getSubTopicId()){
                                            break;
                                        }
                                        answersResult.add(subTopicAns.getSubTopicId()+"."+subTopicAns.getSubTopicDesc());
                                    }
                           }
                       }
                 }
                 showResult = "true";
            }else{
                 showResult = "false";
            }
       }else{
            showResult = "false";
       } 
     //-------------------------------   
        return SUCCESS;
    }
    public String backTaskList() throws Exception {
        logger.debug("[backTaskList][Begin]");
        
        String backToPage   = "backTaskList";
        String forBackPage  = null;
        
        try{
            forBackPage = (String) request.getSession(false).getAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL);
            
            logger.debug("[backTaskList] forBackPage :: " + forBackPage);
            
            if(forBackPage!=null && !forBackPage.equals("")){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    backToPage = "backCloseJobTaskList";
                }else if(forBackPage.equals(BusinessConst.PAGE.PIPELINE)){
                    backToPage = "backTaskList";
                }
            }
            
            logger.debug("[backTaskList][End]");
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[backTaskList][End]");
        }
        
        return backToPage;
    }
    
     public String showPopupAddRemark() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("showPopupAddRemark");
        }
        return "showPopupAddRemark";
    }
      public String doApprove() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doApprove");
        }
        //---------Can send OLD Answer :09/06/2015---//
        String versionAnswerOld = "";
        if(warningInfoId > 0 && !ValidatorUtil.isNullOrEmpty(questionId)){
             versionAnswerOld = asstAnswerService.findAnswerVersionByWarningIdAndQuestionId(warningInfoId, questionId);
        }
        if(ValidatorUtil.isNullOrEmpty(versionAnswerOld)){ //--- Is null or blank
             versionAnswerOld = version;
        } 
        //----------------------------------------//    
        if(!ValidatorUtil.isNullOrEmpty(questionId) && !ValidatorUtil.isNullOrEmpty(versionAnswerOld)){  
            TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
            AsstTopicVo asstTopicVo = new AsstTopicVo();
            asstTopicVo.setWarningHeaderId(warningHeaderId);
            asstTopicVo.setWarningType(warningType);
            asstTopicVo.setWarningId(warningInfoId);
            asstTopicVo.setQuestionId(questionId);
            asstTopicVo.setVersion(versionAnswerOld);
            asstTopicVo.setCifNo(titleVo.getCifNo());
            asstTopicVo.setCustName(titleVo.getCustName());
            asstTopicVo.setActionForm(BusinessConst.ACTION_CODE.APPROVE);
            asstQuestionBusiness.approveQuestion(asstTopicVo, getCurrentUser(), infoStatus, actionMode , true);
        }
        WarningInfoVo infoAfterApprove = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
        if(infoAfterApprove != null){ //--- For hide buttom after approve
             setInfoStatus(infoAfterApprove.getStatus());
        }
        
        WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
        UserData        user            = getCurrentUser();
        
        warningHeaderVo.setWarningHeaderId(warningHeaderId);
        warningHeaderVo.setUpdatedBy(user.getEmpNo());
        //การ update TBL_WARNING_HEADER เพื่อให้งานหายจาก Pipeline
        //comment by Onn : เนื่องจากใน method approveQuestion มีการ insert อยู่แล้ว
//        warningHeaderBusiness.updateForApprove(warningHeaderVo, "E");
        
        success();
        return SUCCESS;
    }
      
    public String saveDataEdit() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("saveDataEdit");
        }
        String questionIdSave = "";
        String versionSave = "";
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if (questionList != null) {
            List<AsstAnswerVo> asstAnswerVoList = new ArrayList<AsstAnswerVo>();
            AsstAnswerVo asstAnswerVo;
            int tmp = 0;
            for (String question : questionList) {
                if ("Save".equals(actionMode)) {
                    if ("1".equals(requireList.get(tmp))) {
                        if (answers == null || answers.size() < questionList.size() || answers.get(tmp) == null || answers.get(tmp).trim().length() <= 0) {
                            throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                        }
                        int yes = 0;
                        for(int i=0 ; i < answers.size() ; i++ ){ /** Check Last SubTop "Other" Fix "ใช่" *****/
                              String ans = (String)answers.get(i);
                               if("1".equals(ans)){
                                   if(i != (answers.size() - 1)){
                                       yes  = yes + 1;
                                   }
                              }
                        }
                        if(yes == 0){
                            if(remarks != null && remarks.size() > 0 && questionList != null && questionList.size() > 0 ){
                                 int indexTextAreaOther = questionList.size()-1;
                                 if(indexTextAreaOther <= remarks.size()){
                                    String remarkOther = remarks.get(indexTextAreaOther);
                                    if(ValidatorUtil.isNullOrEmpty(remarkOther)){
                                        throw new BusinessException("กรุณาระบุเหตุผลในช่องอื่นๆด้วย");
                                    }
                                 }
                            }else{
                                 throw new BusinessException("กรุณาระบุเหตุผลในช่องอื่นๆด้วย");
                            }     
                        }else{
                            if(yes > 3){
                                throw new BusinessException("สามารถเลือกตอบ ใช่ ได้สูงสุดไม่เกิน 3 ข้อ");
                            }
                        }
                    }
                }else{
                      if ("1".equals(requireList.get(tmp))) {
                        int yes = 0;
                         for(int i=0 ; i < answers.size() ; i++ ){ /** Check Last SubTop "Other" Fix "ใช่" *****/
                              String ans = (String)answers.get(i);
                               if("1".equals(ans)){
                                   if(i != (answers.size() - 1)){
                                       yes  = yes + 1;
                                   }
                              }
                        }
                         if(yes == 0){
                            if(remarks != null && remarks.size() > 0 && questionList != null && questionList.size() > 0 ){
                                 int indexTextAreaOther = questionList.size()-1;
                                 if(indexTextAreaOther <= remarks.size()){
                                    String remarkOther = remarks.get(indexTextAreaOther);
                                    if(ValidatorUtil.isNullOrEmpty(remarkOther)){
                                        throw new BusinessException("กรุณาระบุเหตุผลในช่องอื่นๆด้วย");
                                    }
                                 }
                            }else{
                                 throw new BusinessException("กรุณาระบุเหตุผลในช่องอื่นๆด้วย");
                            }     
                        }else{
                            if(yes > 3){
                                throw new BusinessException("สามารถเลือกตอบ ใช่ ได้สูงสุดไม่เกิน 3 ข้อ");
                            }
                        }
                    }
                }
                asstAnswerVo = new AsstAnswerVo();
                String[] s = question.split("\\,", -1);
                if (s != null && s.length > 0) {
                    questionIdSave = s[0];
                    versionSave = s[1];
                    asstAnswerVo.setQuestionId(questionIdSave);
                    asstAnswerVo.setVersion(versionSave);
                    asstAnswerVo.setTopicId(Integer.parseInt(s[2]));
                    asstAnswerVo.setSubTopicId(Integer.parseInt(s[3]));
                    if (s[4] != null && s[4].trim().length() > 0) {
                        asstAnswerVo.setWarningId(Integer.parseInt(s[4]));
                    }
                    if (s[5] != null && s[5].trim().length() > 0) {
                        asstAnswerVo.setWarningType(s[5]);
                    }
                }
                if (answers != null) {
                    if (answers.size() > tmp) {
                        if (answers.get(tmp) != null) {
                            asstAnswerVo.setChoiceId(Integer.parseInt(answers.get(tmp)));
                            if (remarks != null) {
                                if (remarks.get(tmp) != null) {
                                    asstAnswerVo.setChoiceReason(remarks.get(tmp));
                                }
                            }
                            if (asstAnswerVo.getWarningId() <= 0) {
                                asstAnswerVo.setWarningId(warningInfoId);
                            }
                            if (asstAnswerVo.getWarningType() == null || asstAnswerVo.getWarningType().trim().length() <= 0) {
                                asstAnswerVo.setWarningType(warningType);
                            }
                            asstAnswerVo.setWarningHeaderId(titleVo.getWarningHeaderId());
                            asstAnswerVo.setCifNo(titleVo.getCifNo());
                            asstAnswerVoList.add(asstAnswerVo);
                        }
                    }
                }
                tmp++;
            }
            if (asstAnswerVoList.size() > 0) {
                infoStatus = asstQuestionBusiness.saveAsstAnswer(asstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType);
            }
        }

        AsstTopicVo filter = new AsstTopicVo();
        filter.setCifNo(titleVo.getCifNo());
        findData(filter);
        showSaveFinal = BusinessConst.Flag.N;
        if("Draft".equals(actionMode)){
            doEdit();
        }else if("Save".equals(actionMode) && getCurrentUser() != null){
           logger.debug("warningHeaderId >>" + warningHeaderId);
           logger.debug("warningInfoId >>" + warningInfoId);
           logger.debug("warningType >>" + warningType);
              if(BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())){
                    WarningInfoVo infoAfterApprove = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                    if(infoAfterApprove != null){ //--- For hide buttom after approve
                         setInfoStatus(infoAfterApprove.getStatus());
                         setActionMode("Approve");
                    }
                 doApprove();
                 editFlag = BusinessConst.Flag.N;
                 rejectFlag = BusinessConst.Flag.N;
                 approveFlag = BusinessConst.Flag.N;
                 saveFlag = BusinessConst.Flag.N;
              }
        }
       
 
      return SUCCESS;
    }
    
    public String doCancleNoEdit() throws Exception {
           success();
      return SUCCESS;
    }
    
     public String goLatePaymentHistory() throws Exception {
       if (logger.isDebugEnabled()) {
            logger.debug("goLatePaymentHistory");
        }
       try{
        if(!ValidatorUtil.isNullOrEmpty(warningHeaderIdHistory) && !ValidatorUtil.isNullOrEmpty(warningIdHistory)){
        UserData userData = getCurrentUser();
        AsstTopicVo filter = new AsstTopicVo();
        int historyWarningHeaderId = Integer.parseInt(warningHeaderIdHistory);
        int historyWarningId = Integer.parseInt(warningIdHistory);
        filter.setWarningHeaderId(historyWarningHeaderId);
        filter.setWarningId(historyWarningId);
        filter.setWarningType(warningTypeHistory);
        filter.setInfoStatus(BusinessConst.Flag.COMPLETE);
        this.asstTopicVoListHistory = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
 
        showMode = "true"; 

        WarningInfoVo  infoVo = warningInfoBusiness.findWarningInfoObj(historyWarningHeaderId, historyWarningId, BusinessConst.WarningTypeCode.LATE_PAY);
            if(infoVo != null){
            setWarningInfoDateStr(infoVo.getWarningDateStr() != null ? infoVo.getWarningDateStr() : "");
            String lpAdvice = !ValidatorUtil.isNullOrEmpty(infoVo.getBcmLatePayAdvice()) ? infoVo.getBcmLatePayAdvice() : infoVo.getLatePayAdvice();
            String lpLevel  = !ValidatorUtil.isNullOrEmpty(infoVo.getBcmLatePayLevel()) ? infoVo.getBcmLatePayLevel() : infoVo.getLatePayLevel();
            if(!ValidatorUtil.isNullOrEmpty(lpAdvice) && !ValidatorUtil.isNullOrEmpty(lpLevel)){
                latePayLevel = lpLevel; 
                latePayAdvice = lpAdvice;
                 String[] lpaArray = latePayAdvice.split("&",-1);
                 for(String data : lpaArray){
                     if("1".equals(data)){
                           latePayAdvice1 = BusinessConst.Flag.Y;
                     }else if("2".equals(data)){
                           latePayAdvice2 = BusinessConst.Flag.Y;
                     }else if("3".equals(data)){
                           latePayAdvice3 = BusinessConst.Flag.Y;
                     }
                 }
                 if(lpaArray.length > 1){
                     if("1&2".equals(latePayAdvice)){
                         wordlatePayAdvice1 = SUGGESTION;
                         wordlatePayAdvice2 = ADDITIONAL;
                         wordlatePayAdvice3 = null;
                     }else if("1&3".equals(latePayAdvice)){
                         wordlatePayAdvice1 = SUGGESTION;
                         wordlatePayAdvice2 = null;
                         wordlatePayAdvice3 = ADDITIONAL;
                     }else if("2&3".equals(latePayAdvice)){
                         wordlatePayAdvice1 = null;
                         wordlatePayAdvice2 = SUGGESTION;
                         wordlatePayAdvice3 = ADDITIONAL;
                     }
                 }else{
                     wordlatePayAdvice1 = SUGGESTION;
                     wordlatePayAdvice2 = SUGGESTION;
                     wordlatePayAdvice3 = SUGGESTION;
                 }
                 //----------------------- ANSWER --------------//

                 if(!asstTopicVoListHistory.isEmpty()){ 
                   //-Start------- NOT Display LAST TOPIC "Other" 
                     Integer lastSubtopic = null;
                     if(!ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionId()) && !ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionVersion())){
                          lastSubtopic = asstQuestionBusiness.getLastSubTopic(infoVo.getAnswerQuestionId(), infoVo.getAnswerQuestionVersion());
                     }
                  //-END--------------------------------------------------------
                     answersResult = new ArrayList<String>();
                       for(AsstTopicVo topicAns : asstTopicVoListHistory){
                           for( AsstSubtopicVo subTopicAns : topicAns.getAsstSubtopicVoList() ){
                                    if("1".equals(subTopicAns.getAnswer())){
                                        if(lastSubtopic != null && lastSubtopic > 0 && lastSubtopic == subTopicAns.getSubTopicId()){
                                            break;
                                        }
                                        answersResult.add(subTopicAns.getSubTopicId()+"."+subTopicAns.getSubTopicDesc());
                                    }
                           }
                       }
                 }
                 showResult = "true";
            }else{
                 showResult = "false";
            }
            }else{
             showResult = "false";
        }
        }else{
               throw new BusinessException("ไม่สามารถดำเนินการได้");
        }
       }catch(Exception e){
           throw e;
       }
        return "latePaymentHistoryScreen";
    }
    //------------------------------------------------ GET/SET ------------------------------------------------//
    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public int getWarningInfoId() {
        return warningInfoId;
    }

    public void setWarningInfoId(int warningInfoId) {
        this.warningInfoId = warningInfoId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public List<QuestionHistoryVo> getQuestionHistoryList() {
        return questionHistoryList;
    }

    public void setQuestionHistoryList(List<QuestionHistoryVo> questionHistoryList) {
        this.questionHistoryList = questionHistoryList;
    }

    public List<AsstTopicVo> getAsstTopicVoList() {
        return asstTopicVoList;
    }

    public void setAsstTopicVoList(List<AsstTopicVo> asstTopicVoList) {
        this.asstTopicVoList = asstTopicVoList;
    }

    public String getApproveFlag() {
        return approveFlag;
    }

    public void setApproveFlag(String approveFlag) {
        this.approveFlag = approveFlag;
    }

    public String getRejectFlag() {
        return rejectFlag;
    }

    public void setRejectFlag(String rejectFlag) {
        this.rejectFlag = rejectFlag;
    }

    public String getSaveFlag() {
        return saveFlag;
    }

    public void setSaveFlag(String saveFlag) {
        this.saveFlag = saveFlag;
    }

    public String getFinalLevel() {
        return finalLevel;
    }

    public void setFinalLevel(String finalLevel) {
        this.finalLevel = finalLevel;
    }

    public String getShowSaveFinal() {
        return showSaveFinal;
    }

    public void setShowSaveFinal(String showSaveFinal) {
        this.showSaveFinal = showSaveFinal;
    }

    public String getShowMode() {
        return showMode;
    }

    public void setShowMode(String showMode) {
        this.showMode = showMode;
    }

    public List<String> getRequireList() {
        return requireList;
    }

    public void setRequireList(List<String> requireList) {
        this.requireList = requireList;
    }

    public List<String> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<String> questionList) {
        this.questionList = questionList;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }

    public List<String> getAnswers() {
        return answers;
    }

    public void setAnswers(List<String> answers) {
        this.answers = answers;
    }

    public List<String> getRemarks() {
        return remarks;
    }

    public void setRemarks(List<String> remarks) {
        this.remarks = remarks;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public List<ActionHistoryVo> getActionHistoryVoList() {
        return actionHistoryVoList;
    }

    public void setActionHistoryVoList(List<ActionHistoryVo> actionHistoryVoList) {
        this.actionHistoryVoList = actionHistoryVoList;
    }

    public String getShowResult() {
        return showResult;
    }

    public void setShowResult(String showResult) {
        this.showResult = showResult;
    }

    public String getLatePayLevel() {
        return latePayLevel;
    }

    public void setLatePayLevel(String latePayLevel) {
        this.latePayLevel = latePayLevel;
    }

    public String getLatePayAdvice() {
        return latePayAdvice;
    }

    public void setLatePayAdvice(String latePayAdvice) {
        this.latePayAdvice = latePayAdvice;
    }

    public String getLatePayAdvice1() {
        return latePayAdvice1;
    }

    public void setLatePayAdvice1(String latePayAdvice1) {
        this.latePayAdvice1 = latePayAdvice1;
    }

    public String getWordlatePayAdvice1() {
        return wordlatePayAdvice1;
    }

    public void setWordlatePayAdvice1(String wordlatePayAdvice1) {
        this.wordlatePayAdvice1 = wordlatePayAdvice1;
    }

    public String getLatePayAdvice2() {
        return latePayAdvice2;
    }

    public void setLatePayAdvice2(String latePayAdvice2) {
        this.latePayAdvice2 = latePayAdvice2;
    }

    public String getWordlatePayAdvice2() {
        return wordlatePayAdvice2;
    }

    public void setWordlatePayAdvice2(String wordlatePayAdvice2) {
        this.wordlatePayAdvice2 = wordlatePayAdvice2;
    }

    public String getLatePayAdvice3() {
        return latePayAdvice3;
    }

    public void setLatePayAdvice3(String latePayAdvice3) {
        this.latePayAdvice3 = latePayAdvice3;
    }

    public String getWordlatePayAdvice3() {
        return wordlatePayAdvice3;
    }

    public void setWordlatePayAdvice3(String wordlatePayAdvice3) {
        this.wordlatePayAdvice3 = wordlatePayAdvice3;
    }

    public List<String> getAnswersResult() {
        return answersResult;
    }

    public void setAnswersResult(List<String> answersResult) {
        this.answersResult = answersResult;
    }

    public String getCurrentUserRole() {
        return currentUserRole;
    }

    public void setCurrentUserRole(String currentUserRole) {
        this.currentUserRole = currentUserRole;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    public String getWarningInfoDateStr() {
        return warningInfoDateStr;
    }

    public void setWarningInfoDateStr(String warningInfoDateStr) {
        this.warningInfoDateStr = warningInfoDateStr;
    }

    public String getEditFlag() {
        return editFlag;
    }

    public void setEditFlag(String editFlag) {
        this.editFlag = editFlag;
    }

    public ArrayList<AsstSubtopicVo> getAsstSubtopicVoListRM() {
        return asstSubtopicVoListRM;
    }

    public void setAsstSubtopicVoListRM(ArrayList<AsstSubtopicVo> asstSubtopicVoListRM) {
        this.asstSubtopicVoListRM = asstSubtopicVoListRM;
    }

    public List<String> getAnswersTemp() {
        return answersTemp;
    }

    public void setAnswersTemp(List<String> answersTemp) {
        this.answersTemp = answersTemp;
    }

    public String getEditRadioFlag() {
        return editRadioFlag;
    }

    public void setEditRadioFlag(String editRadioFlag) {
        this.editRadioFlag = editRadioFlag;
    }

    public String getButtonSetOfEditFlag() {
        return buttonSetOfEditFlag;
    }

    public void setButtonSetOfEditFlag(String buttonSetOfEditFlag) {
        this.buttonSetOfEditFlag = buttonSetOfEditFlag;
    }

    public List<AsstTopicVo> getAsstTopicVoListForOldAnswer() {
        return asstTopicVoListForOldAnswer;
    }

    public void setAsstTopicVoListForOldAnswer(List<AsstTopicVo> asstTopicVoListForOldAnswer) {
        this.asstTopicVoListForOldAnswer = asstTopicVoListForOldAnswer;
    }

    public String getWarningIdHistory() {
        return warningIdHistory;
    }

    public void setWarningIdHistory(String warningIdHistory) {
        this.warningIdHistory = warningIdHistory;
    }

    public String getWarningHeaderIdHistory() {
        return warningHeaderIdHistory;
    }

    public void setWarningHeaderIdHistory(String warningHeaderIdHistory) {
        this.warningHeaderIdHistory = warningHeaderIdHistory;
    }

    public String getActionDateHistory() {
        return actionDateHistory;
    }

    public void setActionDateHistory(String actionDateHistory) {
        this.actionDateHistory = actionDateHistory;
    }

    public String getVersionHistory() {
        return versionHistory;
    }

    public void setVersionHistory(String versionHistory) {
        this.versionHistory = versionHistory;
    }

    public String getQuestionIdHistory() {
        return questionIdHistory;
    }

    public void setQuestionIdHistory(String questionIdHistory) {
        this.questionIdHistory = questionIdHistory;
    }

    public String getWarningTypeHistory() {
        return warningTypeHistory;
    }

    public void setWarningTypeHistory(String warningTypeHistory) {
        this.warningTypeHistory = warningTypeHistory;
    }

    public List<AsstTopicVo> getAsstTopicVoListHistory() {
        return asstTopicVoListHistory;
    }

    public void setAsstTopicVoListHistory(List<AsstTopicVo> asstTopicVoListHistory) {
        this.asstTopicVoListHistory = asstTopicVoListHistory;
    }

   

     
}
