/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.ScoreEngineBusiness;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.exceptions.BusinessException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Tum_Surapong
 */
public class AssessmentAction extends BaseAction {

    private static final Logger log = Logger.getLogger(AssessmentAction.class);
    private List<WarningTypeVo> warningTypeList;
    private String selectQuestId;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private ScoreEngineBusiness scoreEngineBusiness;

    public String getSelectQuestId() {
        return selectQuestId;
    }

    public void setSelectQuestId(String selectQuestId) {
        this.selectQuestId = selectQuestId;
    }

    public List<WarningTypeVo> getWarningTypeList() {
        return warningTypeList;
    }

    public void setWarningTypeList(List<WarningTypeVo> warningTypeList) {
        this.warningTypeList = warningTypeList;
    }

    @Override
    public String success() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("AssessmentAction.success");
        }
        try {           
            if (selectQuestId != null) {
                WarningTypeVo filter = new WarningTypeVo();
                filter.setQuestionId(selectQuestId);
                updateScoreEngine(filter);
            }
            warningTypeList = new ArrayList<WarningTypeVo>();
            warningTypeList = asstQuestionBusiness.findWarningType();
           
        } catch (Exception ex) {
            throw ex;
        }
        return SUCCESS;
    }

    public void updateScoreEngine(WarningTypeVo filter ) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("AssessmentAction.updateScoreEngine QuestionId : " + filter.getQuestionId());
        }
        try {
             scoreEngineBusiness.updateAsstQuestion(filter,getCurrentUser());
        } catch (BusinessException e){
            throwBusinessError(e.getMessage());
        } catch (Exception ex) {
            throw ex;
        }
    }
}