/**
 * 
 */
package com.ktb.ewsl.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.ktb.ewsl.business.AnnouncementBusiness;
import com.ktb.ewsl.vo.AnnouncementVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author somphop.h
 *
 */
public class PostAnnoucementAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	private AnnouncementBusiness announcementBusiness;

	private Integer seq;
	private Object json_response;

	private static final Logger log = Logger.getLogger(PostAnnoucementAction.class);

	public String execute() {
		return SUCCESS;
	}

	public String reqActiveAnnouncementJson() throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("AnnouncementAction.reqActiveAnnouncementJson");
		}
		List<AnnouncementVo> list = new ArrayList<AnnouncementVo>();
		PaginatedListImpl<AnnouncementVo> paginate = new PaginatedListImpl<AnnouncementVo>();
		paginate.setPageSize(-1);
		try {

			paginate = announcementBusiness.getListPostAnnouncement(paginate);
		} catch (Exception e) {
			throw e;
		}
		list = paginate.getList();
		if (list != null && !list.isEmpty()) {
			List<Map<String,Object>> responseList = new ArrayList<Map<String,Object>>();
			SimpleDateFormat df = new SimpleDateFormat("dd MMMM yyyy", new Locale("th", "TH"));
			for(AnnouncementVo ann : list) {
				Map<String, Object> response = new HashMap<String, Object>();
				response.put("seq", ann.getSeq());
				response.put("title", ann.getAnnounceTitle());
				response.put("dateStr", df.format(ann.getAnnounceDate()));
				response.put("newFlag", ann.getNewFlag());
				response.put("updateFlag", ann.getUpdateFlag());
				responseList.add(response);
			}
			json_response = responseList;

		}else {
			json_response = list;
		}
		
		return "json_item";
	}
	
	public String reqAnnouncementContentJson() throws Exception{
		if (log.isDebugEnabled()) {
			log.debug("AnnouncementAction.reqAnnouncementContent seq:"+seq);
		}
		AnnouncementVo announcementVo = new AnnouncementVo();
		announcementVo.setSeq(seq);
		announcementVo = announcementBusiness.getAnnouncementVo(announcementVo);
		Map<String,Object> resp = new HashMap<String,Object>();
		if(announcementVo!=null) {
			resp.put("seq", announcementVo.getSeq());
			resp.put("content", announcementVo.getAnnounceDetail());
		}else {
			resp.put("seq",seq);
			resp.put("content","");
		}
		json_response = resp;
		return "json_content";
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public Object getJson_response() {
		return json_response;
	}

}
