/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AccountDetailBusiness;
import com.ktb.ewsl.vo.CrWarningAcctVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.List;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Pound
 */
public class AccountDetailAction extends BaseAction{
    private static final Logger logger = Logger.getLogger(AccountDetailAction.class);
    
    private String cif;
    private String custName;
    private String cifHid;
    private String forBackPage;
    private List<CrWarningAcctVo> crWarningAcctList;
    private String pageMode;

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    public List<CrWarningAcctVo> getCrWarningAcctList() {
        return crWarningAcctList;
    }

    public void setCrWarningAcctList(List<CrWarningAcctVo> crWarningAcctList) {
        this.crWarningAcctList = crWarningAcctList;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCifHid() {
        return cifHid;
    }

    public void setCifHid(String cifHid) {
        this.cifHid = cifHid;
    }

    public String getPageMode() {
        return pageMode;
    }

    public void setPageMode(String pageMode) {
        this.pageMode = pageMode;
    }
    
    @Autowired
    private AccountDetailBusiness accountDetailBusiness;

    @Override
    public String execute() throws Exception {
        log("[execute][Begin]");
        String forward  = null;
        String command  = null;
        try{
            command = request.getParameter("command");
            
            log("[execute] command :: " + command);
            
            if(command==null || command.equals(SUCCESS)){
                forward = success();
            }else if(command.equals("getDetail")){
                forward = getDetail();
            }else if(command.equals("backTaskDetail")){
                forward = backTaskDetail();
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[execute][End]");
        }
        return forward;
    }
    
     
    private String backTaskDetail(){
        return "backTaskDetail";
    }
    
    private String getDetail(){
        log("[getDetail][Begin]");
        
        try{
            this.cif           = URLDecoder.decode(StringUtil.nullToStr(this.cif), "UTF-8");
            this.custName      = URLDecoder.decode(StringUtil.nullToStr(this.custName), "UTF-8");
            
            log("[getDetail] this.cif :: " + this.cif);
            log("[getDetail] this.custName :: " + this.custName);
            log("[getDetail] this.cifHid :: " + this.cifHid);
            
            if(!StringUtil.nullToStr(this.cifHid).equals("")){
                this.crWarningAcctList = this.accountDetailBusiness.getCrWarningAcctListByCif(this.cifHid);
            }
        }catch(Exception e){
            logger.error(e);
        }finally{
            log("[getDetail][End]");
        }
        return SUCCESS;
    }
    
    
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }
    
    private void writeMSG(String msg) {
        PrintWriter print = null;
        try {
            this.response.setContentType("text/html; charset=UTF-8");
            print = this.response.getWriter();
            print.write(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
