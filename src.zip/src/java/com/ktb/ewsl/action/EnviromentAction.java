/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.kcs.cash.env.ENVBeanResponse;
import com.kcs.cash.env.ENVMonitoring;
import com.ktb.ewsl.business.ScoreEngineBusiness;
import com.ktbcs.core.action.BaseAction;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import netscape.ldap.LDAPConnection;
import netscape.ldap.LDAPException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class EnviromentAction  extends BaseAction {
    
    
    private static final Logger log = Logger.getLogger(EnviromentAction.class);
    private String maxMemory;
    private String totalMemory;
    private String usageTotal;
    private String freeTotal;
    private String freeMemory;
    private String avaliable;
    private Timestamp currentDate;
    private String PASS = "P";
    private String NO_PASS = "N";
    private String ERROR_CONNECT = "E";
    private String scoreMessage;
    private String scoreCallStatus;
    private String scoreDetail;
    private String ldapMessage;
    private String ldapCallStatus;
    private String ldapDetail;
    private String cbsMessage;
    private String cbsCallStatus;
    private String cbsDetail;
    
    private String dbTBMessage;
    private String dbTBCallStatus;
    private String dbTBDetail;
    private String dbCRMessage;
    private String dbCRCallStatus;
    private String dbCRDetail;
    private String dbEWSMessage;
    private String dbEWSCallStatus;
    private String dbEWSDetail;
    private String dbTACallStatus;
    private String dbTADetail;
    private String dbTAMessage;
    
    @Autowired
    private ScoreEngineBusiness scoreEngineBusiness;
            
    @Override
    public String success() throws Exception {
      DecimalFormat format = (DecimalFormat) DecimalFormat.getInstance();
      format.applyPattern("#,###");
       try {
           long total = Runtime.getRuntime().totalMemory();
            long free = Runtime.getRuntime().freeMemory();
            long max = Runtime.getRuntime().maxMemory();
            long proc = Runtime.getRuntime().availableProcessors();
            long usage = max - free;
            long usage2 = total - free;
            long free2 = free + (max - total);
             if(log.isInfoEnabled()){
                log.info("Entry to............. EnviromentAction.success");
             }
             
                currentDate = new java.sql.Timestamp(java.util.Calendar.getInstance().getTimeInMillis());
                setMaxMemory(format.format(max/1024));
                setTotalMemory(format.format(total/1024)) ;
                setUsageTotal(format.format(usage2/1024)) ;
                setFreeTotal(format.format(free/1024)) ;
                setFreeMemory(format.format(free2/1024));
                setAvaliable(String.valueOf(proc));
                
                PropertyResourceBundle appConfig = (PropertyResourceBundle)PropertyResourceBundle.getBundle("app-config",Locale.US);
                // DB Telbook
                String dbTB = appConfig.getString("database.tbewsl.jndi");
                ENVBeanResponse rsTB = ENVMonitoring.prepareDBConnection(dbTB);
                       if(rsTB != null){
                           setDbTBCallStatus(rsTB.getStatus());
                           setDbTBDetail(" Oracle : " + dbTB);
                           setDbTBMessage(rsTB.getMessage());
                       }
                // DB Credit Review
              /*  String dbCR = appConfig.getString("database.cr.jndi");
                ENVBeanResponse rsCR = ENVMonitoring.prepareDBConnection(dbCR);
                       if(rsCR != null){
                           setDbCRCallStatus(rsCR.getStatus());
                           setDbCRDetail(" DB2 : " + dbCR);
                           setDbCRMessage(rsCR.getMessage());
                       }
                       
                // DB Turnaround
                String dbTA = appConfig.getString("database.ta.jndi");
                ENVBeanResponse rsTA = ENVMonitoring.prepareDBConnection(dbTA);
                       if(rsTA != null){
                           setDbTACallStatus(rsTA.getStatus());
                           setDbTADetail(" DB2 : " + dbTA);
                           setDbTAMessage(rsTA.getMessage());
                 }*/
                       
                 // DB EWS
                String dbEWS = appConfig.getString("database.ewsl.jndi");
                ENVBeanResponse rsEWS = ENVMonitoring.prepareDBConnection(dbEWS);
                       if(rsEWS != null){
                           setDbEWSCallStatus(rsEWS.getStatus());
                           setDbEWSDetail(" DB2 : " + dbEWS);
                           setDbEWSMessage(rsEWS.getMessage());
                       }
                       
                //Score Engine
                 String resultSC =  scoreEngineBusiness.checkConnection();
                 if((resultSC != null)&&(!resultSC.equals(""))){
                    setScoreDetail("");
                    setScoreCallStatus(resultSC);
                    if("P".equals(resultSC)){
                        setScoreMessage("CONNECT SUCCESSFULLY");
                    }else{
                        setScoreMessage("CONNECT NOT SUCCESSFULLY");
                    }
                 }
                   // CBS
//                  ConfigVO configVoCBS = configBusiness.findByConfigGroupAndConfigCode("CALL_CBS", "CIF_NO");
//                  if((configVoCBS != null)&& (!ValidatorUtil.isNullOrEmpty(configVoCBS.getConfigValue()))){
//                      String resultCbs =  cbsBusiness.checkConnection(configVoCBS.getConfigValue());
//                        if((resultCbs != null)&&(!resultCbs.equals(""))){
//                           setCbsDetail("");
//                           setCbsCallStatus(resultSC);
//                           if("P".equals(resultSC)){
//                               setCbsMessage("CONNECT SUCCESSFULLY");
//                           }else{
//                               setCbsMessage("CONNECT NOT SUCCESSFULLY");
//                           }
//                        }
//                  }
//                 
//                  //FIN --- For test
//                  ConfigVO configVo = configBusiness.findByConfigGroupAndConfigCode("CALL_FIN", "CIF_NO");
//                  if(configVo != null){
//                      String cifNoOpt = configVo.getConfigValue();
//                      //------- Title bar -----------//
//                        TitleVo titleVo = new TitleVo();
//                        titleVo.setCifNo(cifNoOpt);
//                        titleVo.setCustName("TEST");
//                        titleVo.setWarningHeaderId(0);
//                        request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
//                  }

                //EWS WebService
                  
                  
                  
                //Internal LDAP
                 boolean canAuthen = checkLDAP(appConfig);
                 log.info("Internal LDAP canAuthen " + canAuthen);
                 if(canAuthen){
                      setLdapCallStatus(PASS);
                      setLdapDetail(" LDAP : " + appConfig.getString("ldap.ktb.providerurl"));
                      setLdapMessage("CONNECT SUCCESSFULLY");
                 }else{
                      setLdapCallStatus(NO_PASS);
                      setLdapDetail(" LDAP : " + appConfig.getString("ldap.ktb.providerurl"));
                      setLdapMessage("LDAP problem. Cannot get Connection.");
                 }
                  
               
            
        } catch (Exception ex) {
            throw ex;
        }
        return SUCCESS;
   }
            
   public boolean checkLDAP(PropertyResourceBundle appConfig) {
        LDAPConnection ld = null;
        boolean result = false;
        try {
            String providerUrlHost = appConfig.getString("ldap.ktb.host");
            String portStr = appConfig.getString("ldap.ktb.port");
            int port = 0;
            if((portStr != null)&&(!portStr.equals(""))){
                 port = Integer.parseInt(portStr); 
            }
            String dn = appConfig.getString("ldap.ktb.manager.userid");
            String pwd = appConfig.getString("ldap.ktb.manager.password");
           
            //Connect to the LDAP Server
            ld = new LDAPConnection();
            ld.connect(providerUrlHost,port ,dn, pwd);
            result = true;
        
        }catch (LDAPException e) {
            System.err.println(e.toString());
            result = false;
        }

        // Finally, disconnect from the LDAP server
        if ( (ld != null) && ld.isConnected()) {
            try {
                ld.disconnect();
                result = true;
            }
            catch (LDAPException e) {
                System.err.println(e.toString());
                result = false;
            }
        }
        return result;
    }
   
   
    public String getMaxMemory() {
        return maxMemory;
    }

    public void setMaxMemory(String maxMemory) {
        this.maxMemory = maxMemory;
    }

    public String getTotalMemory() {
        return totalMemory;
    }

    public void setTotalMemory(String totalMemory) {
        this.totalMemory = totalMemory;
    }

    public String getUsageTotal() {
        return usageTotal;
    }

    public void setUsageTotal(String usageTotal) {
        this.usageTotal = usageTotal;
    }

    public String getFreeTotal() {
        return freeTotal;
    }

    public void setFreeTotal(String freeTotal) {
        this.freeTotal = freeTotal;
    }

    public String getFreeMemory() {
        return freeMemory;
    }

    public void setFreeMemory(String freeMemory) {
        this.freeMemory = freeMemory;
    }

    public String getAvaliable() {
        return avaliable;
    }

    public void setAvaliable(String avaliable) {
        this.avaliable = avaliable;
    }

    public Timestamp getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(Timestamp currentDate) {
        this.currentDate = currentDate;
    }

    public String getPASS() {
        return PASS;
    }

    public void setPASS(String PASS) {
        this.PASS = PASS;
    }

    public String getNO_PASS() {
        return NO_PASS;
    }

    public void setNO_PASS(String NO_PASS) {
        this.NO_PASS = NO_PASS;
    }

    public String getERROR_CONNECT() {
        return ERROR_CONNECT;
    }

    public void setERROR_CONNECT(String ERROR_CONNECT) {
        this.ERROR_CONNECT = ERROR_CONNECT;
    }

    public String getScoreMessage() {
        return scoreMessage;
    }

    public void setScoreMessage(String scoreMessage) {
        this.scoreMessage = scoreMessage;
    }

    public String getScoreCallStatus() {
        return scoreCallStatus;
    }

    public void setScoreCallStatus(String scoreCallStatus) {
        this.scoreCallStatus = scoreCallStatus;
    }

    public String getScoreDetail() {
        return scoreDetail;
    }

    public void setScoreDetail(String scoreDetail) {
        this.scoreDetail = scoreDetail;
    }

    public String getLdapMessage() {
        return ldapMessage;
    }

    public void setLdapMessage(String ldapMessage) {
        this.ldapMessage = ldapMessage;
    }

    public String getLdapCallStatus() {
        return ldapCallStatus;
    }

    public void setLdapCallStatus(String ldapCallStatus) {
        this.ldapCallStatus = ldapCallStatus;
    }

    public String getLdapDetail() {
        return ldapDetail;
    }

    public void setLdapDetail(String ldapDetail) {
        this.ldapDetail = ldapDetail;
    }

    public String getDbTBMessage() {
        return dbTBMessage;
    }

    public void setDbTBMessage(String dbTBMessage) {
        this.dbTBMessage = dbTBMessage;
    }

    public String getDbTBCallStatus() {
        return dbTBCallStatus;
    }

    public void setDbTBCallStatus(String dbTBCallStatus) {
        this.dbTBCallStatus = dbTBCallStatus;
    }

    public String getDbTBDetail() {
        return dbTBDetail;
    }

    public void setDbTBDetail(String dbTBDetail) {
        this.dbTBDetail = dbTBDetail;
    }

    public String getDbCRMessage() {
        return dbCRMessage;
    }

    public void setDbCRMessage(String dbCRMessage) {
        this.dbCRMessage = dbCRMessage;
    }

    public String getDbCRCallStatus() {
        return dbCRCallStatus;
    }

    public void setDbCRCallStatus(String dbCRCallStatus) {
        this.dbCRCallStatus = dbCRCallStatus;
    }

    public String getDbCRDetail() {
        return dbCRDetail;
    }

    public void setDbCRDetail(String dbCRDetail) {
        this.dbCRDetail = dbCRDetail;
    }

    public String getDbEWSMessage() {
        return dbEWSMessage;
    }

    public void setDbEWSMessage(String dbEWSMessage) {
        this.dbEWSMessage = dbEWSMessage;
    }

    public String getDbEWSCallStatus() {
        return dbEWSCallStatus;
    }

    public void setDbEWSCallStatus(String dbEWSCallStatus) {
        this.dbEWSCallStatus = dbEWSCallStatus;
    }

    public String getDbEWSDetail() {
        return dbEWSDetail;
    }

    public void setDbEWSDetail(String dbEWSDetail) {
        this.dbEWSDetail = dbEWSDetail;
    }

    public String getDbTACallStatus() {
        return dbTACallStatus;
    }

    public void setDbTACallStatus(String dbTACallStatus) {
        this.dbTACallStatus = dbTACallStatus;
    }

    public String getDbTADetail() {
        return dbTADetail;
    }

    public void setDbTADetail(String dbTADetail) {
        this.dbTADetail = dbTADetail;
    }

    public String getDbTAMessage() {
        return dbTAMessage;
    }

    public void setDbTAMessage(String dbTAMessage) {
        this.dbTAMessage = dbTAMessage;
    }

    public String getCbsMessage() {
        return cbsMessage;
    }

    public void setCbsMessage(String cbsMessage) {
        this.cbsMessage = cbsMessage;
    }

    public String getCbsCallStatus() {
        return cbsCallStatus;
    }

    public void setCbsCallStatus(String cbsCallStatus) {
        this.cbsCallStatus = cbsCallStatus;
    }

    public String getCbsDetail() {
        return cbsDetail;
    }

    public void setCbsDetail(String cbsDetail) {
        this.cbsDetail = cbsDetail;
    }

}
