/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ParameterBusiness;
import com.ktb.ewsl.business.WarningCloseBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktb.ewsl.vo.WarningCloseVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author pumin
 */
public class PopupCloseJobAction extends BaseAction {

    private static final Logger log = Logger.getLogger(PopupCloseJobAction.class);
    private String reasonIdSave;
    private String remarkDescSave;
    private String cifNo;
    private String warningHeaderId;
    private ArrayList<DropdownVo> reasonList;
    @Autowired
    WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    WarningCloseBusiness warningCloseBusiness;
    @Autowired
    ParameterBusiness parameterBusiness;

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(String warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getReasonIdSave() {
        return reasonIdSave;
    }

    public void setReasonIdSave(String reasonIdSave) {
        this.reasonIdSave = reasonIdSave;
    }

    public String getRemarkDescSave() {
        return remarkDescSave;
    }

    public void setRemarkDescSave(String remarkDescSave) {
        this.remarkDescSave = remarkDescSave;
    }

    public ArrayList<DropdownVo> getReasonList() throws Exception {
        return this.reasonList;
    }

    public ArrayList<DropdownVo> setReasonList(ArrayList<DropdownVo> reasonList) throws Exception {
        return this.reasonList = reasonList;
    }

    public String success() throws Exception {
        log.info("PopupCloseJobAction : success");
        setReasonList(getReasonListForDropdown());
        return "success";
    }

    public String doSave() throws Exception {
        log.info("PopupCloseJobAction : success");
        //insert  TBL_WARNING_CLOSE โดยให้ STATUS = I
        //update TBL_WARNING_HEADER.STATUS = I and update UPDATED_DT , UPDATED_BY 
        UserData user = getCurrentUser();
        String closeJobWarningHeaderId = (String) request.getSession(false).getAttribute("closeJobWarningHeaderId" + user.getCurrentId());
        String cif = (String) request.getSession(false).getAttribute("closeJobCifNo" + user.getCurrentId());
        setWarningHeaderId(closeJobWarningHeaderId);
        setCifNo(cif);

        WarningCloseVo warningCloseVo = new WarningCloseVo();
        warningCloseVo.setStatus("R");
        warningCloseVo.setWarningHeadId(closeJobWarningHeaderId);
        warningCloseVo.setReasonFlg(getReasonIdSave());
        warningCloseVo.setRemark(getRemarkDescSave());
        warningCloseVo.setCreatedBy(user.getEmpNo());
        warningCloseVo.setCreatedDt(DateUtil.getCurrentDateTime());
        warningCloseVo.setRoleCode(user.getRoleId());
        warningCloseBusiness.insertWarningClose(warningCloseVo);

        WarningHeaderVo headVo = new WarningHeaderVo();
        headVo.setWarningHeaderId(Integer.parseInt(closeJobWarningHeaderId));
        headVo.setUpdatedBy(user.getCurrentId());
        headVo.setUpdatedDate(DateUtil.getCurrentDateTime());
        headVo.setStatus("R");
        warningHeaderBusiness.updateStatusWarningHeader(headVo);

        return "gotoCloseJob";
    }

    public String doSaveRemark() throws Exception {
        log.info("PopupCloseJobAction : success");
        // insert  TBL_WARNING_CLOSE with STATUS = R
        // update TBL_WARNING_HEADER.STATUS = R  , UPDATED_DT , UPDATED_BY  


        UserData user = getCurrentUser();
        String closeJobWarningHeaderId = (String) request.getSession(false).getAttribute("closeJobWarningHeaderId" + user.getCurrentId());
        String cif = (String) request.getSession(false).getAttribute("closeJobCifNo" + user.getCurrentId());
        setWarningHeaderId(closeJobWarningHeaderId);
        setCifNo(cif);

        WarningCloseVo warningCloseVo = new WarningCloseVo();
        warningCloseVo.setStatus("I");
        warningCloseVo.setWarningHeadId(closeJobWarningHeaderId);
        warningCloseVo.setReasonFlg(getReasonIdSave());
        warningCloseVo.setRemark(getRemarkDescSave());
        warningCloseVo.setCreatedBy(user.getEmpNo());
        warningCloseVo.setCreatedDt(DateUtil.getCurrentDateTime());
        warningCloseVo.setRoleCode(user.getRoleId());
        warningCloseBusiness.insertWarningClose(warningCloseVo);
        
        WarningHeaderVo headVo = new WarningHeaderVo();
        headVo.setWarningHeaderId(Integer.parseInt(closeJobWarningHeaderId));
        headVo.setUpdatedBy(user.getCurrentId());
        headVo.setUpdatedDate(DateUtil.getCurrentDateTime());
        
        int     cnt = warningHeaderBusiness.countForCloseByCif(Integer.parseInt(closeJobWarningHeaderId));
        String  status = cnt>0?"N":"I";
        
        headVo.setStatus(status);
        warningHeaderBusiness.updateStatusWarningHeader(headVo);

        return "gotoCloseJob";
    }

    ArrayList<DropdownVo> getReasonListForDropdown() throws Exception {
        ArrayList<ParameterVo> paramList = parameterBusiness.getParameterByTypeId(BusinessConst.PARAMETER_TYPE_ID.CLOSE_BY_CIF_REASON, "PARAMETER_ID");
        ArrayList<DropdownVo> ddList = new ArrayList();
        for (ParameterVo vo : paramList) {
            ddList.add(setDataToDropDrown(vo.getParameterId(), vo.getParameterName()));
        }
        return ddList;
    }

    private DropdownVo setDataToDropDrown(String key, String value) {
        DropdownVo ddVo = new DropdownVo();
        ddVo.setId(key);
        ddVo.setDesc(value);
        return ddVo;
    }
}
