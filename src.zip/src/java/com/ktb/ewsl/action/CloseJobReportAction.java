/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

import com.ktb.ewsl.business.ActionCloseBusiness;
import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.DropdownBusiness;
import com.ktb.ewsl.business.KtbOrganizationBusiness;
import com.ktb.ewsl.business.MtConfigBusiness;
import com.ktb.ewsl.business.RolePrivilegeBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.export.CloseJobDataExporter;
import com.ktb.ewsl.utilities.EWSDateUtil;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.MtFormStatusVo;
import com.ktb.ewsl.vo.ReportCloseJobVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;

import net.sf.jxls.transformer.XLSTransformer;

/**
 *
 * @author KTBDevLoan
 */
public class CloseJobReportAction extends BaseAction {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(CloseJobReportAction.class);
	private final String FW_LATE_PAYMENT_FORM = "latePaymentForm";
	// private final String FW_WAY_OUT_FORM = "wayOutForm";
	private final String FW_ACTION_FROM = "actionForm";// Edit By Pound
	private final String FW_QUALI = "nextQuali";
	private final String FW_CREDIT_RATING = "creditRating";
	private final String FW_FIN = "nextFinance";
	private final String FW_CREDIT_REVIEW = "creditReview";
	private final String FW_TODAY_MOVEMENT = "todayMovement";
	private String SEARCH = "search";
	private SearchBean searchBean;
	private List<DropdownVo> departmentList; // --หน่วยงาน
	private List<DropdownVo> organizationGroupList; // กลุ่มงาน
	private List<DropdownVo> businessUnitList; // สายงาน
	private PaginatedListImpl<ReportCloseJobVo> paginate;
	private InputStream fileStream;
	private String exportFileName;
	private String fromPageName;
	private String nextCifNo;
	private int nextWarningHeaderId;
	private String nextCurrentHeaderStatus;
	private String nextDisplayFinalComplete;
	private String nextCurrentWarningTypeCode;
	private String nextCustName;
	private String forBackPage;
	private int nextWarningInfoId;
	private String nextCurrentFormFlg;
	// private String nextCurrentWayOutFlg;
	private String showDataGrid;

	private HashMap MT_FORM_STATUS_MAP;
	@Autowired
	private DropdownBusiness dropdownBusiness;
	@Autowired
	private ActionCloseBusiness actionCloseBusiness;
	@Autowired
	private RolePrivilegeBusiness rolePrivilegeBusiness;
	@Autowired
	KtbOrganizationBusiness ktbOrganizationBusiness;
	@Autowired
	private MtConfigBusiness mtConfigBusiness;
	@Autowired
	private WarningInfoBusiness warningInfoBusiness;
	@Autowired
	private CustomerBusiness customerBusiness;

	public InputStream getFileStream() {
		return fileStream;
	}

	public void setFileStream(InputStream fileStream) {
		this.fileStream = fileStream;
	}

	public String getExportFileName() {
		return exportFileName;
	}

	public void setExportFileName(String exportFileName) {
		this.exportFileName = exportFileName;
	}

	public String getFromPageName() {
		return fromPageName;
	}

	public void setFromPageName(String fromPageName) {
		this.fromPageName = fromPageName;
	}

	@Override
	public String success() throws Exception {
		log.info("Init CloseJobReportAction");
		if (request.getSession(false).getAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT) != null) {
			request.getSession(false).removeAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT);
		}

		departmentList = new ArrayList<DropdownVo>();
		organizationGroupList = new ArrayList<DropdownVo>();

		businessUnitList = new ArrayList<DropdownVo>();
		businessUnitList = dropdownBusiness.getWorkLine();
		// search();
		setShowDataGrid(BusinessConst.Flag.N);
		return SUCCESS;
	}

	public String search() throws Exception {
		int rowAmt = 10;// Default
		int pageAmt = 10;// Default
		try {
			if (log.isDebugEnabled()) {
				log.debug("Entry to............. CloseJobReportAction.search");
				log.debug(" getPageIndex : " + getPageIndex());
			}

			if (paginate == null) {

				paginate = createPaginate(rowAmt);
			}
			if (searchBean != null) {
				if (paginate != null) {
					String pageIndexSearch = String.valueOf(paginate.getIndex());
					setPageIndex(pageIndexSearch);
					searchBean.setSearchPageIndex(pageIndexSearch);
				}
				if ((searchBean.isAdminCloseFlagY()) || (searchBean.isAdminCloseFlagY())
						|| (searchBean.isBcCloseFlagY())) {
					String empaIdAdmin = rolePrivilegeBusiness.getEmployeeID(BusinessConst.UserRole.RISK_EDITOR); // ---
																													// ADMIN
																													// is
																													// RE
					searchBean.setAdminAllId(empaIdAdmin);
				}

				searchBean.setFromDateCloseJobStr(DateUtil.convertThEnYearStr(searchBean.getFromDateCloseJobStr(), true));
				searchBean.setToDateCloseJobStr(DateUtil.convertThEnYearStr(searchBean.getToDateCloseJobStr(), true));
				request.getSession(false).setAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT,
						searchBean);
			}
			paginate = actionCloseBusiness.getCloseListEwsl(paginate, searchBean, getCurrentUser(), pageAmt);
			if (businessUnitList == null) {
				businessUnitList = new ArrayList<DropdownVo>();
				businessUnitList = dropdownBusiness.getWorkLine();
			}
			if (departmentList == null) {
				departmentList = new ArrayList<DropdownVo>();
			}
			if (organizationGroupList == null) {
				organizationGroupList = new ArrayList<DropdownVo>();
			}
			setShowDataGrid(BusinessConst.Flag.Y);
		} catch (Exception ex) {
			throw ex;
		}
		return SEARCH;
	}

	public String searchConditionMemory() throws Exception {
		int rowAmt = 10;// Default
		int pageAmt = 10;// Default
		try {
			if (log.isDebugEnabled()) {
				log.debug("Entry to............. CloseJobReportAction.searchConditionMemory");
			}
			if (paginate == null) {
				paginate = createPaginate(rowAmt);
			}
			if (searchBean == null) {
				searchBean = new SearchBean();
			}
			setShowDataGrid(BusinessConst.Flag.Y);
			log.debug("CLOSE_JOB_CRITERIA_SEARCH_SORT :: "
					+ request.getSession(false).getAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT));

			if (request.getSession(false).getAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT) != null) {
				searchBean = (SearchBean) request.getSession(false)
						.getAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT);
				if (searchBean != null) {
					setPageIndex(searchBean.getSearchPageIndex());
					paginate.setIndex(Integer.parseInt(searchBean.getSearchPageIndex()));
				}
			}
			if (searchBean != null) {
				log.debug("searchBean.getSortField() = " + searchBean.getSortField());
				log.debug("searchBean.getSortType() = " + searchBean.getSortType());
				log.debug("searchBean.getByName() = " + searchBean.getByName());
				log.debug("searchBean.getTextSearch() = " + searchBean.getTextSearch());
				log.debug("searchBean.getSearchPageIndex() = " + searchBean.getSearchPageIndex());
			}

			paginate = actionCloseBusiness.getCloseListEwsl(paginate, searchBean, getCurrentUser(), pageAmt);

			if (businessUnitList == null) {
				businessUnitList = new ArrayList<DropdownVo>();
				businessUnitList = dropdownBusiness.getWorkLine();
			}
			if (departmentList == null) {
				departmentList = new ArrayList<DropdownVo>();
			}
			if (organizationGroupList == null) {
				organizationGroupList = new ArrayList<DropdownVo>();
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error occur in while process CloseJobReportAction.searchConditionMemory : " + e.getMessage(), e);
		}
		return SUCCESS;
	}

	public String gotoFormDetail() throws Exception {
		String forward = SUCCESS;
		try {
			this.nextCustName = URLDecoder.decode(nullToStr(this.nextCustName), "UTF-8");

			if (log.isDebugEnabled()) {
				log.debug("gotoFormDetail Start");
				log.debug("nextWarningHeaderId          >> " + this.nextWarningHeaderId);
				log.debug("nextCifNo                    >> " + this.nextCifNo);
				log.debug("nextCurrentWarningTypeCode   >> " + this.nextCurrentWarningTypeCode);
				log.debug("nextCustName                 >> " + this.nextCustName);
			}

			// ------- Title bar -----------//
			TitleVo titleVo = new TitleVo();
			titleVo.setCifNo(this.nextCifNo);
			titleVo.setCustName(this.nextCustName);
			titleVo.setWarningHeaderId(this.nextWarningHeaderId);
			request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);

			setForBackPage(BusinessConst.PAGE.CLOSE_JOB_REPORT);
			forward = "closeJobReportDetail";

		} catch (Exception ex) {
			throw ex;
		}
		return forward;
	}

	public String gotoCloseJobDetail() throws Exception {
		String forward = SUCCESS;
		try {
			this.nextCustName = URLDecoder.decode(nullToStr(this.nextCustName), "UTF-8");

			if (log.isDebugEnabled()) {
				log.debug("gotoFormDetail Start");
				log.debug("nextWarningHeaderId          >> " + this.nextWarningHeaderId);
				log.debug("nextCifNo                    >> " + this.nextCifNo);
				log.debug("nextCurrentWarningTypeCode   >> " + this.nextCurrentWarningTypeCode);
				log.debug("nextCustName                 >> " + this.nextCustName);
			}

			// ------- Title bar -----------//
			TitleVo titleVo = new TitleVo();
			titleVo.setCifNo(this.nextCifNo);
			titleVo.setCustName(this.nextCustName);
			titleVo.setWarningHeaderId(this.nextWarningHeaderId);
			request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);

			setForBackPage(BusinessConst.PAGE.CLOSE_JOB_REPORT);
			forward = "closeJobReportDetailByWarningHead";

		} catch (Exception ex) {
			throw ex;
		}
		return forward;
	}

	public SearchBean getSearchBean() {
		return searchBean;
	}

	public void setSearchBean(SearchBean searchBean) {
		this.searchBean = searchBean;
	}

	public List<DropdownVo> getDepartmentList() {
		return departmentList;
	}

	public void setDepartmentList(List<DropdownVo> departmentList) {
		this.departmentList = departmentList;
	}

	public List<DropdownVo> getOrganizationGroupList() {
		return organizationGroupList;
	}

	public void setOrganizationGroupList(List<DropdownVo> organizationGroupList) {
		this.organizationGroupList = organizationGroupList;
	}

	public List<DropdownVo> getBusinessUnitList() {
		return businessUnitList;
	}

	public void setBusinessUnitList(List<DropdownVo> businessUnitList) {
		this.businessUnitList = businessUnitList;
	}

	public PaginatedListImpl getPaginate() {
		return paginate;
	}

	public void setPaginate(PaginatedListImpl paginate) {
		this.paginate = paginate;
	}

	public String exportExcel() throws Exception {
		String closeBy = "";
		String fromDateCloseJobStr = "";
		String toDateCloseJobStr = "";

		Calendar cal = Calendar.getInstance();
		Locale localeThai = new Locale("TH", "th");
		SimpleDateFormat format = new SimpleDateFormat(EWSDateUtil.FMT_TIMESTAMP, localeThai);
		String reportDate = format.format(cal.getTime()).toString();

		try {
			
			searchBean = (SearchBean) request.getSession(false)
					.getAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT);
			if (searchBean == null) {
				searchBean = new SearchBean();
			}
			
			paginate = createPaginate(0);
			paginate.setIndex(-99);
			paginate = actionCloseBusiness.getCloseListForExportEwsl(searchBean);
			List<ReportCloseJobVo> dataList = paginate.getList();

			Map<String, Object> beans = new HashMap<String, Object>();
			WarningHeaderVo wVo;

			int idx = 1;
			if (dataList != null && !dataList.isEmpty()) {
				for (ReportCloseJobVo rpVo : dataList) {
					rpVo.setIndex(idx);
					wVo = rpVo.getWarningHeaderVo();
					wVo.setLatePayFlg(convertFlgShowExcel(wVo.getLatePayFlg(),wVo.getStatus()));
					wVo.setAction1Flg(convertFlgShowExcel(wVo.getAction1Flg(),wVo.getStatus()));
					wVo.setAction2Flg(convertFlgShowExcel(wVo.getAction2Flg(),wVo.getStatus()));
					wVo.setQualiFlg(convertFlgShowExcel(wVo.getQualiFlg(),wVo.getStatus()));
					//wVo.setCreditRatingFlg(convertFlgShowExcel(wVo.getCreditRatingFlg(),wVo.getStatus()));
					wVo.setFinFlg(convertFlgShowExcel(wVo.getFinFlg(),wVo.getStatus()));
					//wVo.setCrFlg(convertFlgShowExcel(wVo.getCrFlg(),wVo.getStatus()));
                                         //-------CreditRating
                                        String creditRatingFlg = convertFlgShowExcel(wVo.getCreditRatingFlg(), wVo.getStatus());
					wVo.setCreditRatingFlg(creditRatingFlg);
                                        String ratingDateFinalStr = "1".equals(creditRatingFlg)?"":wVo.getRatingDateFinalStr();
                                        wVo.setRatingDateFinalStr(ratingDateFinalStr);
					//-------CR
                                        String crFlg = convertFlgShowExcel(wVo.getCrFlg(), wVo.getStatus());
                                        wVo.setCrFlg(crFlg);
                                        String reviewDateFinalStr = "1".equals(crFlg)?"":wVo.getReviewDateFinalStr();
                                        wVo.setReviewDateFinalStr(reviewDateFinalStr);
					idx++;
				}

				beans.put("totalRecs", dataList.size());
			} else {
				beans.put("totalRecs", 0);
			}

			if (searchBean.isSystemCloseFlagY()) {
				closeBy = "System";
			}

			if (searchBean.isAdminCloseFlagY()) {
				if (!"".equals(closeBy))
					closeBy += ", Admin";
				else
					closeBy = "Admin";
			}

			if (searchBean.isBcCloseFlagY()) {
				if (!"".equals(closeBy))
					closeBy += ", BC";
				else
					closeBy = "BC";
			}

			if (searchBean.getWorkLine() != null && !"".equals(searchBean.getWorkLine())) {
				searchBean.setWorkLine(searchBean.getWorkLine() + " "
						+ ktbOrganizationBusiness.findCostCenterName(searchBean.getWorkLine()));
			}
			if (searchBean.getOrganizationGroup() != null && !"".equals(searchBean.getOrganizationGroup())) {
				searchBean.setOrganizationGroup(searchBean.getOrganizationGroup() + " "
						+ ktbOrganizationBusiness.findCostCenterName(searchBean.getOrganizationGroup()));
			}
			if (searchBean.getCostCenter() != null && !"".equals(searchBean.getCostCenter())) {
				searchBean.setCostCenter(searchBean.getCostCenter() + " "
						+ ktbOrganizationBusiness.findCostCenterName(searchBean.getCostCenter()));
			}


			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy",new Locale("en","US"));
			SimpleDateFormat ddf = new SimpleDateFormat("dd/MM/yyyy",new Locale("th","TH"));
			if (!ValidatorUtil.isNullOrEmpty(searchBean.getFromDateCloseJobStr())) {
				
				fromDateCloseJobStr = ddf.format(sdf.parse(searchBean.getFromDateCloseJobStr()));	
			}
			
			if(!ValidatorUtil.isNullOrEmpty(searchBean.getToDateCloseJobStr())) {
				toDateCloseJobStr = ddf.format(sdf.parse(searchBean.getToDateCloseJobStr()));	
			}

			beans.put("roleId", getCurrentUser().getRoleId());
			beans.put("closeBy", closeBy);
			beans.put("dataList", dataList);
			beans.put("searchBean", searchBean);
			beans.put("fromDateCloseJobStr", fromDateCloseJobStr);
			beans.put("toDateCloseJobStr", toDateCloseJobStr);
			beans.put("reportDate", reportDate.substring(0, 10));
			beans.put("reportTime", reportDate.substring(11, reportDate.length()));
			beans.put("countObjData", paginate.getCountObjData());
			//beans.put("remark", mtConfigBusiness.getStatusNameAndSeq());
                        
                        ArrayList<MtFormStatusVo> dataStatus = mtConfigBusiness.getStatusNameAndSeq();
                        //--- TYPES FLG 
                        //ArrayList<MtFormStatusVo> dataTypeFlgRemarkList = new ArrayList<MtFormStatusVo>();
                        MtFormStatusVo dataTypeFlgRemark = new MtFormStatusVo();
                        dataTypeFlgRemark.setSeq("A");
                        dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวนสินเชื่อ");
                        dataStatus.add(dataTypeFlgRemark);

                        dataTypeFlgRemark = new MtFormStatusVo();
                        dataTypeFlgRemark.setSeq("B");
                        dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ต่ออายุวงเงิน");
                        dataStatus.add(dataTypeFlgRemark);

                        dataTypeFlgRemark = new MtFormStatusVo();
                        dataTypeFlgRemark.setSeq("C");
                        dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวนการจัดชั้นหนี้ C-Class");
                        dataStatus.add(dataTypeFlgRemark);

                        dataTypeFlgRemark = new MtFormStatusVo();
                        dataTypeFlgRemark.setSeq("D");
                        dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวน Rating");
                        dataStatus.add(dataTypeFlgRemark);
                        beans.put("remark", dataStatus);
                        
			CloseJobDataExporter exporter = new CloseJobDataExporter();
			HSSFWorkbook workbook = exporter.setParams(beans).export();

			StringBuilder fileName = new StringBuilder("taskListReport");
			Calendar fcal = Calendar.getInstance();

			fileName.append(format.format(fcal.getTime()).toString()).append(".xls");

			response.setHeader("Set-Cookie", "fileDownload=true; path=/");

			ByteArrayOutputStream bos = new ByteArrayOutputStream();

			try {
				workbook.write(bos);

				byte[] bytes = bos.toByteArray();
				setExportFileName(fileName.toString());
				fileStream = new ByteArrayInputStream(bytes);
			} catch (Exception e) {
				throw e;
			} finally {
				bos.close();
			}

		} catch (Exception ex) {
			response.setHeader("Set-Cookie", "fileDownload=false; path=/");
			ex.printStackTrace();
			throw ex;
		} finally {

			log.debug("[exportExcel][End]");
		}
		return "export";
	}

	public String exportExcelwTemplate() throws Exception {
		System.out.println("Entry to............. CloseJobReportAction.exportExcel");
		try {
			Map<String, Object> beans = new HashMap<String, Object>();
			WarningHeaderVo wVo;
			int idx = 1;
			String closeBy = "";
			String fromDateCloseJobStr = "";
			String toDateCloseJobStr = "";
			String[] date = null;
			int year = 0;

			Calendar cal = Calendar.getInstance();
			Locale localeThai = new Locale("TH", "th");
			SimpleDateFormat format = new SimpleDateFormat(EWSDateUtil.FMT_TIMESTAMP, localeThai);
			String reportDate = format.format(cal.getTime()).toString();

			searchBean = (SearchBean) request.getSession(false)
					.getAttribute(BusinessConst.Session.CLOSE_JOB_CRITERIA_SEARCH_SORT);
			if (searchBean == null) {
				searchBean = new SearchBean();
			}

			paginate = actionCloseBusiness.getCloseListForExportEwsl(searchBean);
			List<ReportCloseJobVo> dataList = paginate.getList();

			if (dataList != null && !dataList.isEmpty()) {
				for (ReportCloseJobVo rpVo : dataList) {
					rpVo.setIndex(idx);
					wVo = rpVo.getWarningHeaderVo();
					wVo.setLatePayFlg(convertFlg(wVo.getLatePayFlg()));
					wVo.setAction1Flg(convertFlg(wVo.getAction1Flg()));
					wVo.setAction2Flg(convertFlg(wVo.getAction2Flg()));
					wVo.setQualiFlg(convertFlg(wVo.getQualiFlg()));
					wVo.setCreditRatingFlg(convertFlg(wVo.getCreditRatingFlg()));
					wVo.setFinFlg(convertFlg(wVo.getFinFlg()));
					wVo.setCrFlg(convertFlg(wVo.getCrFlg()));
					idx++;
				}

				beans.put("totalRecs", dataList.size());
			} else {
				beans.put("totalRecs", 0);
			}

			if (searchBean.isSystemCloseFlagY()) {
				closeBy = "System";
			}

			if (searchBean.isAdminCloseFlagY()) {
				if (!"".equals(closeBy))
					closeBy += ", Admin";
				else
					closeBy = "Admin";
			}

			if (searchBean.isBcCloseFlagY()) {
				if (!"".equals(closeBy))
					closeBy += ", BC";
				else
					closeBy = "BC";
			}

			if (searchBean.getWorkLine() != null && !"".equals(searchBean.getWorkLine())) {
				searchBean.setWorkLine(searchBean.getWorkLine() + " "
						+ ktbOrganizationBusiness.findCostCenterName(searchBean.getWorkLine()));
			}
			if (searchBean.getOrganizationGroup() != null && !"".equals(searchBean.getOrganizationGroup())) {
				searchBean.setOrganizationGroup(searchBean.getOrganizationGroup() + " "
						+ ktbOrganizationBusiness.findCostCenterName(searchBean.getOrganizationGroup()));
			}
			if (searchBean.getCostCenter() != null && !"".equals(searchBean.getCostCenter())) {
				searchBean.setCostCenter(searchBean.getCostCenter() + " "
						+ ktbOrganizationBusiness.findCostCenterName(searchBean.getCostCenter()));
			}

			if (!ValidatorUtil.isNullOrEmpty(searchBean.getFromDateCloseJobStr())
					&& !ValidatorUtil.isNullOrEmpty(searchBean.getToDateCloseJobStr())) {
				date = searchBean.getFromDateCloseJobStr().split("/");
				year = Integer.parseInt(date[2]) + 543;
				fromDateCloseJobStr = date[0] + "/" + date[1] + "/" + year;

				date = searchBean.getToDateCloseJobStr().split("/");
				year = Integer.parseInt(date[2]) + 543;
				toDateCloseJobStr = date[0] + "/" + date[1] + "/" + year;
			}

			beans.put("closeBy", closeBy);
			beans.put("dataList", dataList);
			beans.put("searchBean", searchBean);
			beans.put("fromDateCloseJobStr", fromDateCloseJobStr);
			beans.put("toDateCloseJobStr", toDateCloseJobStr);
			beans.put("reportDate", reportDate.substring(0, 10));
			beans.put("reportTime", reportDate.substring(11, reportDate.length()));
			beans.put("countObjData", paginate.getCountObjData());
			beans.put("remark", mtConfigBusiness.getStatusNameAndSeq());

			XLSTransformer transformer = new XLSTransformer();

			String path = getServletContext().getRealPath("/");
			File file = new File(path + "report/closejobReportTemplete.xls");
			InputStream inputStream = new FileInputStream(file);
			HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);

			response.setHeader("Set-Cookie", "fileDownload=true; path=/");

			bos.close();
			byte[] bytes = bos.toByteArray();
			setExportFileName("closejobReport.xls");
			fileStream = new ByteArrayInputStream(bytes);
		} catch (Exception e) {
			response.setHeader("Set-Cookie", "fileDownload=false; path=/");
			log.error(e);
			throw e;
		}

		return "export";
	}

	private String convertFlg(String flgInput) throws Exception {
		String flg;
		if (flgInput != null && !"".equals(flgInput)) {
			flg = flgInput.trim();
		} else {
			flg = flgInput;
		}

		if ("N".equals(flg)) {
			return "1";
		} else if ("P".equals(flg)) {
			return "1.1";
		} else if ("I".equals(flg)) {
			return "2";
		} else if ("C".equals(flg)) {
			return "3";
		} else if ("A".equals(flg)) {
			return "2.1";
		} else {
			return "0";
		}
	}
	
	private String convertFlgShowExcel(String inp, String status) throws Exception {
        String flag = "";
        HashMap mtData = getMtFormStatusData();
        if (mtData != null) {
            if (inp != null && !"".equals(inp)) {
                
                //กรณีที่ TBL_WARNING_HEADER.STATUS = W ให้ แสดงตัวเลขของ form เป็นเหมือน status E ซึ่งมี SEQ = 2
                if("W".equals(status) && !inp.equals("D")){
                    inp = "E";
                }
                //กรณีที่ TBL_WARNING_HEADER.STATUS = R ให้ แสดงตัวเลขของ form เป็นเหมือน status RN หรือ RI ค่ะ ซึ่งมี SEQ = 3
                else if("R".equals(status) && !inp.equals("D")){
                    inp = "RN";
                }
                
                
                if (mtData.containsKey(inp)) {
                    flag = ((MtFormStatusVo) mtData.get(inp)).getSeq();
                }

            }
        }

        return flag;
    }
	
	protected HashMap getMtFormStatusData() throws Exception {
        HashMap hashData;
        if (MT_FORM_STATUS_MAP == null) {
            ArrayList<MtFormStatusVo> list = mtConfigBusiness.getMtFormDetail();
            if (list != null && !list.isEmpty()) {
                hashData = new HashMap();
                for (MtFormStatusVo vo : list) {
                    hashData.put(vo.getFormStatusFlg().trim(), vo);
                }
                MT_FORM_STATUS_MAP = hashData;
            }

        }
        return MT_FORM_STATUS_MAP;
    }

	public String goTaskDetail() throws Exception {
		log.debug(" nextCifNo : " + nextCifNo);
		log.debug(" nextCurrentHeaderStatus : " + nextCurrentHeaderStatus);
		log.debug(" nextWarningHeaderId : " + nextWarningHeaderId);
		log.debug(" nextDisplayFinalComplete : " + nextDisplayFinalComplete);
		setFromPageName(BusinessConst.PAGE.CLOSE_JOB_REPORT);
		return "nextTaskDetail";
	}

	public String gotoFormQuestion() throws Exception {
		String forward = SUCCESS;
		try {
			if (log.isDebugEnabled()) {
				log.debug("Entry to............. TaskListAction.gotoFormQuestion");
				log.debug(" getNextCifNo >>" + getNextCifNo());
				log.debug(" getNextCurrentHeaderStatus >>" + getNextCurrentHeaderStatus());
				log.debug(" getNextCurrentWarningTypeCode >>" + getNextCurrentWarningTypeCode());
				log.debug(" getNextWarningHeaderId >>" + getNextWarningHeaderId());
				log.debug(" getNextCurrentFormFlg >> " + getNextCurrentFormFlg()); // --HEADER FLAG
			}
			if (!ValidatorUtil.isNullOrEmpty(getNextCifNo())) {
				int cifInt = Integer.parseInt(getNextCifNo());
				CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
				if (custVo != null) {
					// ------- Title bar -----------//
					TitleVo titleVo = new TitleVo();
					titleVo.setCifNo(getNextCifNo());
					titleVo.setCustName(custVo.getCustName());
					titleVo.setWarningHeaderId(getNextWarningHeaderId());
					titleVo.setStatus(getNextCurrentHeaderStatus());
					request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
				}
			}
			if (getNextWarningHeaderId() > 0 && !ValidatorUtil.isNullOrEmpty(getNextCurrentWarningTypeCode())) {
				WarningInfoVo warningInfoVo = warningInfoBusiness.findWarningInfoObject(getNextWarningHeaderId(),
						getNextCurrentWarningTypeCode());
				if (warningInfoVo != null) {
					setNextWarningInfoId(warningInfoVo.getWarningId());
					setNextCurrentFormFlg(warningInfoVo.getStatus()); // --INFO FLAG
					log.debug(" getWarningId >> " + warningInfoVo.getWarningId());
					log.debug(" getStatus >> " + warningInfoVo.getStatus());
				}
			}

			setForBackPage(BusinessConst.PAGE.CLOSE_JOB_REPORT);

			if (BusinessConst.WarningTypeCode.LATE_PAY.equals(getNextCurrentWarningTypeCode())) {
				forward = FW_LATE_PAYMENT_FORM;
			}
			// else if
			// (BusinessConst.WarningTypeCode.WAY_OUT.equals(getNextCurrentWarningTypeCode()))
			// {
			// forward = FW_WAY_OUT_FORM;
			// }
			else if (BusinessConst.WarningTypeCode.ACTION1.equals(getNextCurrentWarningTypeCode())) {
				forward = FW_ACTION_FROM;
			} else if (BusinessConst.WarningTypeCode.EWSQ.equals(getNextCurrentWarningTypeCode())) {
				forward = FW_QUALI;
			} else if (BusinessConst.WarningTypeCode.CREDIT_RATING.equals(getNextCurrentWarningTypeCode())) {
				forward = FW_CREDIT_RATING;
			} else if (BusinessConst.WarningTypeCode.FIN.equals(getNextCurrentWarningTypeCode())) {
				forward = FW_FIN;
			} else if (BusinessConst.WarningTypeCode.CR.equals(getNextCurrentWarningTypeCode())) {
				forward = FW_CREDIT_REVIEW;
			}

		} catch (Exception ex) {
			throw ex;
		}
		return forward;
	}

	public String getNextCifNo() {
		return nextCifNo;
	}

	public void setNextCifNo(String nextCifNo) {
		this.nextCifNo = nextCifNo;
	}

	public int getNextWarningHeaderId() {
		return nextWarningHeaderId;
	}

	public void setNextWarningHeaderId(int nextWarningHeaderId) {
		this.nextWarningHeaderId = nextWarningHeaderId;
	}

	public String getNextCurrentHeaderStatus() {
		return nextCurrentHeaderStatus;
	}

	public void setNextCurrentHeaderStatus(String nextCurrentHeaderStatus) {
		this.nextCurrentHeaderStatus = nextCurrentHeaderStatus;
	}

	public String getNextDisplayFinalComplete() {
		return nextDisplayFinalComplete;
	}

	public void setNextDisplayFinalComplete(String nextDisplayFinalComplete) {
		this.nextDisplayFinalComplete = nextDisplayFinalComplete;
	}

	public String getNextCurrentWarningTypeCode() {
		return nextCurrentWarningTypeCode;
	}

	public void setNextCurrentWarningTypeCode(String nextCurrentWarningTypeCode) {
		this.nextCurrentWarningTypeCode = nextCurrentWarningTypeCode;
	}

	public String getNextCustName() {
		return nextCustName;
	}

	public void setNextCustName(String nextCustName) {
		this.nextCustName = nextCustName;
	}

	private String nullToStr(Object obj) {

		return obj == null ? "" : obj.toString().trim();

	}

	public String getForBackPage() {
		return forBackPage;
	}

	public void setForBackPage(String forBackPage) {
		this.forBackPage = forBackPage;
	}

	public int getNextWarningInfoId() {
		return nextWarningInfoId;
	}

	public void setNextWarningInfoId(int nextWarningInfoId) {
		this.nextWarningInfoId = nextWarningInfoId;
	}

	public String getNextCurrentFormFlg() {
		return nextCurrentFormFlg;
	}

	public void setNextCurrentFormFlg(String nextCurrentFormFlg) {
		this.nextCurrentFormFlg = nextCurrentFormFlg;
	}

	// public String getNextCurrentWayOutFlg() {
	// return nextCurrentWayOutFlg;
	// }
	//
	// public void setNextCurrentWayOutFlg(String nextCurrentWayOutFlg) {
	// this.nextCurrentWayOutFlg = nextCurrentWayOutFlg;
	// }
	public String getShowDataGrid() {
		return showDataGrid;
	}

	public void setShowDataGrid(String showDataGrid) {
		this.showDataGrid = showDataGrid;
	}

}
