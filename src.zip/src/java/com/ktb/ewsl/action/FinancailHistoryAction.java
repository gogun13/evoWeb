package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.QcaFinancialBusiness;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.FinancialCustomerVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class FinancailHistoryAction extends BaseAction {

    private static final Logger logger = Logger.getLogger(FinancialAction.class);
    private String cifNo;
    private int warningHeaderId;
    private String custCatCd;
    private String custName;
    private String custTypeName;
    private FinancialVo financialVo;
    private String reasonChoice;
    private List<FinancialCustomerVo> customerList;
    private int warningInfoId;
    private int warningId;
    private String warningType;
    private String hvFin;
    private List<ActionHistoryVo> actionHistoryVoList;
    private ArrayList reasonSelectList;
    private String reasonSelect;
    private String reasonDetail;
    private ArrayList reasonSelectListYes;
    private String reasonSelectY;
    private String reasonSelectN;
    private String reasonChoiceNo;
    private String reasonChoiceYes;
    private String canProtest;
    private FinancialVo lastFinancialVo;
    private List<QuestionHistoryVo> questionHistoryList;
    private String actionDate;
    private String title;
    @Autowired
    private QcaFinancialBusiness qcaFinancialBusiness;
    @Autowired
    private CustomerBusiness customerBusiness;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;

    public List<QuestionHistoryVo> getQuestionHistoryList() {
        return questionHistoryList;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getActionDate() {
        return actionDate;
    }

    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }

    public void setQuestionHistoryList(List<QuestionHistoryVo> questionHistoryList) {
        this.questionHistoryList = questionHistoryList;
    }

    public FinancialVo getLastFinancialVo() {
        return lastFinancialVo;
    }

    public void setLastFinancialVo(FinancialVo lastFinancialVo) {
        this.lastFinancialVo = lastFinancialVo;
    }

    public String getReasonChoiceNo() {
        return reasonChoiceNo;
    }

    public void setReasonChoiceNo(String reasonChoiceNo) {
        this.reasonChoiceNo = reasonChoiceNo;
    }

    public String getReasonChoiceYes() {
        return reasonChoiceYes;
    }

    public void setReasonChoiceYes(String reasonChoiceYes) {
        this.reasonChoiceYes = reasonChoiceYes;
    }

    public String getReasonSelectY() {
        return reasonSelectY;
    }

    public void setReasonSelectY(String reasonSelectY) {
        this.reasonSelectY = reasonSelectY;
    }

    public String getReasonSelectN() {
        return reasonSelectN;
    }

    public void setReasonSelectN(String reasonSelectN) {
        this.reasonSelectN = reasonSelectN;
    }

    public ArrayList getReasonSelectListYes() {
        return reasonSelectListYes;
    }

    public void setReasonSelectListYes(ArrayList reasonSelectListYes) {
        this.reasonSelectListYes = reasonSelectListYes;
    }

    public String getReasonSelect() {
        return this.reasonSelect;
    }

    public void setReasonSelect(String resaonSelect) {
        this.reasonSelect = resaonSelect;
    }

    public String getReasonDetail() {
        return this.reasonDetail;
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public ArrayList getReasonSelectList() {
        return reasonSelectList;
    }

    public void setReasonSelectList(ArrayList reasonSelectList) {
        this.reasonSelectList = reasonSelectList;
    }

    public FinancialVo getFinancialVo() {
        return financialVo;
    }

    public void setFinancialVo(FinancialVo financialVo) {
        this.financialVo = financialVo;
    }

    public String getCustTypeName() {
        return custTypeName;
    }

    public void setCustTypeName(String custTypeName) {
        this.custTypeName = custTypeName;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustCatCd() {
        return custCatCd;
    }

    public void setCustCatCd(String custCatCd) {
        this.custCatCd = custCatCd;
    }

    public List<FinancialCustomerVo> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<FinancialCustomerVo> customerList) {
        this.customerList = customerList;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getReasonChoice() {
        return reasonChoice;
    }

    public void setReasonChoice(String reasonChoice) {
        this.reasonChoice = reasonChoice;
    }

    public int getWarningInfoId() {
        return warningInfoId;
    }

    public void setWarningInfoId(int warningInfoId) {
        this.warningInfoId = warningInfoId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getHvFin() {
        return hvFin;
    }

    public void setHvFin(String hvFin) {
        this.hvFin = hvFin;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public List<ActionHistoryVo> getActionHistoryVoList() {
        return actionHistoryVoList;
    }

    public void setActionHistoryVoList(List<ActionHistoryVo> actionHistoryVoList) {
        this.actionHistoryVoList = actionHistoryVoList;
    }

    public String getCanProtest() {
        return canProtest;
    }

    public void setCanProtest(String canProtest) {
        this.canProtest = canProtest;
    }

    @Override
    public String success() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("success");
        }
        setHeaderDetail();

        QuestionHistoryVo keyVo = (QuestionHistoryVo) request.getSession().getAttribute(BusinessConst.Session.FINANCE_HISTORY_KEY);
        if (logger.isDebugEnabled()) {
            logger.debug("cif>>>>" + keyVo.getCif());
            logger.debug("warningId>>>" + keyVo.getWarningId());
        }

        CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(keyVo.getCif()));
        if (custVo == null) {
            logger.info(" CustomerList is null ");
            request.setAttribute("FINANCIAL_BO", new FinancialVo());
        } else {
            FinancialCustomerVo finCustVo = new FinancialCustomerVo();
            finCustVo.setCifNo(keyVo.getCif());
            finCustVo.setFirstNameTh(custVo.getCustName());
            finCustVo.setCustCatCd("1");
            List<FinancialCustomerVo> tmpCustlist = new ArrayList<FinancialCustomerVo>();
            tmpCustlist.add(finCustVo);

            setCustomerList(tmpCustlist);
            setFinancialVo(qcaFinancialBusiness.getFinancialVOByWarningId(keyVo.getWarningId()));
            setReasonSelectList(getReasonSelectListDataNo());
            setReasonSelectListYes(getReasonSelectListDataYes());
            setReasonSelectN(getFinancialVo().getReasonSelectN());
            setReasonSelectY(getFinancialVo().getReasonSelectY());
            setHvFin(getFinancialVo().getHvFin());
            setTitle("ข้อมูลประวัติการตอบงบการเงิน วันที่ทำรายการ " + keyVo.getActionDate());
            if (getFinancialVo().getHvFin() != null && "N".equalsIgnoreCase(getFinancialVo().getHvFin())) {
                setReasonChoiceNo(getFinancialVo().getHvFin());
                request.setAttribute("FINANCIAL_BO", new FinancialVo());
            } else if (getFinancialVo().getHvFin() != null && "Y".equalsIgnoreCase(getFinancialVo().getHvFin())) {
                setReasonChoiceYes(getFinancialVo().getHvFin());
                getFinancialVo().setRatioList(qcaFinancialBusiness.getRatioList(getFinancialVo(), qcaFinancialBusiness.getRatioList(getFinancialVo().getTrnId())));
                logger.info("RatioList().size() : " + getFinancialVo().getRatioList().size());

                request.setAttribute("FINANCIAL_BO", getFinancialVo());
            }

        }
        if (reasonSelectList == null || reasonSelectList.isEmpty()) {
            reasonSelectList = getReasonSelectListDataNo();
        }
        if (reasonSelectListYes == null || reasonSelectListYes.isEmpty()) {
            reasonSelectListYes = getReasonSelectListDataYes();
        }

        System.out.println("FinancailHistoryAction >> END");

        /**
         * *END***********************************************************************
         */
        return SUCCESS;
    }

    public void setHeaderDetail() throws Exception {
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        setCifNo(titleVo.getCifNo());
        setWarningHeaderId(titleVo.getWarningHeaderId());
        setCustName(titleVo.getCustName());

        this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(warningInfoId);
    }

    public ArrayList<DropdownVo> getReasonSelectListDataNo() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("1", "ก่อตั้งกิจการใหม่ (ยังไม่เริ่มดำเนินการ)"));
        result.add(setDataToDropDrown("2", "อยู่ระหว่างจัดทำบัญชี"));
        result.add(setDataToDropDrown("3", "เลิกกิจการ (ยังชำระบัญชีไม่เสร็จสิ้น)"));
        result.add(setDataToDropDrown("4", "เลิกกิจการ (ชำระบัญชีเสร็จสิ้น)"));
        result.add(setDataToDropDrown("5", "มีคำสั่งศาล/ดำเนินการทางกฎหมาย"));
        result.add(setDataToDropDrown("6", "อื่นๆ ระบุ"));
        return result;
    }

    public ArrayList<DropdownVo> getReasonSelectListDataYes() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("1", "งบนำส่งสรรพากร"));
        result.add(setDataToDropDrown("2", "งบ Recast"));
        return result;
    }

    private DropdownVo setDataToDropDrown(String key, String value) {
        DropdownVo ddVo = new DropdownVo();
        ddVo.setId(key);
        ddVo.setDesc(value);
        return ddVo;
    }

    private String getReasonDetial(String key, ArrayList<DropdownVo> list) throws Exception {
        for (DropdownVo vo : list) {
            if (vo.getId().trim().equals(key.trim())) {
                return vo.getDesc();
            }
        }
        return "";
    }

  
}
