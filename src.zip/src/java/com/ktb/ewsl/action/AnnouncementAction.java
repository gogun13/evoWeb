/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AnnouncementBusiness;
import com.ktb.ewsl.business.DropdownBusiness;
import com.ktb.ewsl.vo.AnnouncementVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Pook
 */
public class AnnouncementAction extends BaseAction {

    private static final Logger log = Logger.getLogger(AnnouncementAction.class);
    private String PATH_FILE;
    //private static final String PATH_FILE = "/NAS_EWS/EWSCBC/ANNOUCEMENT";
    private ArrayList<DropdownVo> statusList;
    private static int rowAmt = 20;// Default
    private static int pageAmt = 20;// Default
    private Integer seq;
    private String newFlag;
    @Autowired
    private DropdownBusiness dropdownBusiness;
    @Autowired
    private AnnouncementBusiness announcementBusiness;
    private AnnouncementVo announcementVo;
    private ArrayList announcementVoList;
    private PaginatedListImpl paginate;
    private String showDataGrid;
    private String searchByPageNum;
    private String initFlag;

    @Override
    public String success() throws Exception {
       if (log.isDebugEnabled()) {
            log.debug("AnnouncementAction.success");
        }
        statusList = new ArrayList<DropdownVo>();
        statusList = dropdownBusiness.getStatusDropdown();
        if (announcementVo == null) {
            announcementVo = new AnnouncementVo();
        }

        if (paginate == null) {
            paginate = createPaginate(rowAmt);
        }
        if (paginate != null) {
            String pageIndexSearch = String.valueOf(paginate.getIndex());
            setPageIndex(pageIndexSearch);
            announcementVo.setSearchPageIndex(pageIndexSearch);
        }
        setInitFlag("Y");
        if (getInitFlag() != null && ("Y".equals(getInitFlag()))) {
            announcementVo.setIsActive(1);
        }
        paginate = announcementBusiness.getListAnnouncement(announcementVo, paginate, pageAmt);
        setShowDataGrid(BusinessConst.Flag.Y);
        return SUCCESS;
    }

    @Override
    public String search() throws Exception {
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. AnnouncementAction.search");
            }
            if (announcementVo == null) {
                announcementVo = new AnnouncementVo();
            }
            statusList = new ArrayList<DropdownVo>();
            statusList = (ArrayList<DropdownVo>) dropdownBusiness.getStatusDropdown();
            if (paginate == null) {
                paginate = createPaginate(rowAmt);
            }
            if (paginate != null) {
                String pageIndexSearch = String.valueOf(paginate.getIndex());
                setPageIndex(pageIndexSearch);
                announcementVo.setSearchPageIndex(pageIndexSearch);
            }
            paginate = announcementBusiness.getListAnnouncement(announcementVo, paginate, pageAmt);

            setShowDataGrid(BusinessConst.Flag.Y);
        } catch (Exception ex) {
            throw ex;
        }
        return SEARCH;
    }

    @Override
    public String add() throws Exception {
        if (log.isDebugEnabled()) {
            log.debug("AnnouncementAction.add");
        }
        statusList = new ArrayList<DropdownVo>();
        announcementVo = new AnnouncementVo();
        announcementVo.setIsActive(1);
        statusList = (ArrayList<DropdownVo>) dropdownBusiness.getStatusDropdown();
        mode = "add";
        return ADD;
    }

    @Override
    public String save() throws Exception {
        if (log.isDebugEnabled()) {
            log.debug("AnnouncementAction.save");
        }
        statusList = new ArrayList<DropdownVo>();
        statusList = (ArrayList<DropdownVo>) dropdownBusiness.getStatusDropdown();
        try {
            if ("false".equals(announcementVo.getNewFlag())) {
                announcementVo.setNewFlag("N");
            } else {
                announcementVo.setNewFlag("Y");
            }
            if ("false".equals(announcementVo.getUpdateFlag())) {
                announcementVo.setUpdateFlag("N");
            } else {
                announcementVo.setUpdateFlag("Y");
            }


            if ("add".equalsIgnoreCase(mode)) {
                announcementVo.setCreatedBy(getCurrentUser().getEmpNo());
                announcementVo.setCreatedDate(new Date());
                announcementVo.setUpdatedBy(getCurrentUser().getEmpNo());
                announcementVo.setUpdatedDate(new Date());
                seq = announcementBusiness.getMaxSeq();
                if (seq == null || seq == 0) {
                    seq = 1;
                } else {
                    seq = seq + 1;
                }
                announcementVo.setSeq(seq);
                announcementBusiness.saveAnnouncement(announcementVo);
                announcementVo.setSeq(seq);
                if (announcementVo.getIsActive() == 1) {
                    announcementBusiness.saveFileOutputStream(getPATH_FILE(), announcementVo);
                }
                //writeFile(FILE_NAME);
            } else {
                announcementVo.setUpdatedBy(getCurrentUser().getEmpNo());
                announcementVo.setUpdatedDate(new Date());
                announcementBusiness.updateAnnouncement(announcementVo);
                announcementBusiness.saveFileOutputStream(getPATH_FILE(), announcementVo);

            }
            
//            if (paginate == null) {
//                paginate = createPaginate(rowAmt);
//            }
//            if (paginate != null) {
//                String pageIndexSearch = String.valueOf(paginate.getIndex());
//                setPageIndex(pageIndexSearch);
//                announcementVo.setSearchPageIndex(pageIndexSearch);
//            }
//            announcementVo.setAnnounceTitle("");
//            announcementVo.setIsActive(null);
//            paginate = announcementBusiness.getListAnnouncement(announcementVo, paginate, pageAmt);
//            setShowDataGrid(BusinessConst.Flag.Y);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return "reload";
    }

    @Override
    public String remove() throws Exception {

        if (log.isDebugEnabled()) {
            log.debug("AnnouncementAction.remove seq:" + seq);
        }
        try {
            statusList = new ArrayList<DropdownVo>();
            statusList = (ArrayList<DropdownVo>) dropdownBusiness.getStatusDropdown();
            announcementBusiness.deleteAnnouncement(seq, getCurrentUser().getEmpNo());
            if (announcementVo == null) {
                announcementVo = new AnnouncementVo();

            }
            announcementVo.setSeq(seq);
            announcementVo.setUpdatedBy(getCurrentUser().getEmpNo());
            announcementVo.setUpdatedDate(new Date());
            announcementVo = announcementBusiness.getAnnouncementVo(announcementVo);
            announcementVo.setIsActive(0);
            announcementBusiness.saveFileOutputStream(getPATH_FILE(), announcementVo);
            if (paginate == null) {
                paginate = createPaginate(rowAmt);
            }
            if (paginate != null) {
                String pageIndexSearch = String.valueOf(paginate.getIndex());
                setPageIndex(pageIndexSearch);
                announcementVo.setSearchPageIndex(pageIndexSearch);
            }
            announcementVo.setAnnounceTitle("");
            announcementVo.setIsActive(1);
            paginate = announcementBusiness.getListAnnouncement(announcementVo, paginate, pageAmt);
            setShowDataGrid(BusinessConst.Flag.Y);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return SUCCESS;
    }

    @Override
    public String edit() throws Exception {

        if (log.isDebugEnabled()) {
            log.debug("AnnouncementAction.edit seq:" + seq);
        }
        mode = "edit";
        announcementVo.setSeq(seq);
        statusList = new ArrayList<DropdownVo>();
        statusList = (ArrayList<DropdownVo>) dropdownBusiness.getStatusDropdown();
        announcementVo = announcementBusiness.getAnnouncementVo(announcementVo);

        return ADD;
    }

    public String readMultipleFile() throws IOException, Exception {
        StringBuilder contentData = new StringBuilder();
        try {
            File dir = new File(getPATH_FILE());
            BufferedReader br = null;
            InputStream is = null;
            String[] fileNames = null;
            List files = null;

            if (dir.listFiles() != null) {
                files = Arrays.asList(dir.listFiles());
            }
            if (files != null) {
                Collections.sort(files, Collections.reverseOrder());

                for (int a = 0; a < files.size(); a++) {
                    File file = (File) files.get(a);
                    String fileName = file.getName();
                    boolean readFlag = false;
                    if (file.isFile()) {
                        try {
                            /* Format file is 25600929_9_ANNOUCEMENT_27092560_30092560.TXT     --annnounceDate_seq_ANNOUCEMENT_startDate_endDate.TXT
                             * [0] = AnnounceDate
                             * [1] = seq, 
                             * [2] = ANNOUCEMENT, 
                             * [3] = startDate
                             * [4] = endDate
                             */
                            String startDateStr = "";
                            String endDateStr = "";
                            fileNames = fileName.split("_");
                            for (int i = 0; i < fileNames.length; i++) {
                                if (i == 3) {
                                    startDateStr = fileNames[i];
                                } else if (i == 4) {
                                    endDateStr = fileNames[i].substring(0, 8);
                                }
                            }
                            if (!"99999999".equals(startDateStr) && (!"99999999".equals(endDateStr))) {
                                Date curDate = DateUtil.convertStringToDateByFormat(DateUtil.getCurrentDateString("ddMMyyyy"), "ddMMyyyy");
                                Date startDate = DateUtil.parseThai(startDateStr, "ddMMyyyy");
                                Date endDate = DateUtil.parseThai(endDateStr, "ddMMyyyy");
                                if (curDate.compareTo(startDate) >= 0 && curDate.compareTo(endDate) <= 0) {
                                    readFlag = true;
                                }
                            } else {
                                readFlag = true;
                            }
                            if (readFlag) {
                                is = new FileInputStream(file);
                                if (is != null) {
                                    int record_length = 4096;
                                    char[] buff = new char[record_length];
                                    br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                                    int record;
                                    while ((record = br.read(buff, 0, record_length)) != -1) {
                                        if (record == record_length) {
                                            contentData.append(new String(buff));
                                        } else {
                                            contentData.append(new String(buff).substring(0, record));
                                        }
                                    }
                                    contentData.append("<br><b>===============================================================================================================</b><br>");
                                    if (br != null) {
                                        br.close();
                                    }

                                } else {
                                    log.info("getAnnouncementTXT : File not found");
                                    contentData.append("");
                                }
                                if (is != null) {
                                    is.close();
                                }
                            }
                            //} 
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            log.error("getAnnouncementTXT :" + ex.getMessage());
                            contentData.append("");
                        } finally {
                            if (is != null) {
                                is = null;
                            }
                            if (br != null) {
                                br = null;
                            }
                        }
                    } else {
                        log.info("getAnnouncementTXT : File not found");
                        contentData.append("");
                    }
                    if (is != null) {
                        is.close();
                    }
                }
            }
            if (announcementVo == null) {
                announcementVo = new AnnouncementVo();
            }
            announcementVo.setAnnounceDetail(contentData.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("getAnnouncementTXT :" + ex.getMessage());
            contentData.append("");
        }
        String content = contentData.toString();
        content = content.replaceAll("\\r", "\\\\r");
        content = content.replaceAll("\\n", "\\\\n");
        return content;
    }

    public ArrayList<DropdownVo> getStatusList() {
        return statusList;
    }

    public void setStatusList(ArrayList<DropdownVo> statusList) {
        this.statusList = statusList;
    }

    public AnnouncementVo getAnnouncementVo() {
        return announcementVo;
    }

    public void setAnnouncementVo(AnnouncementVo announcementVo) {
        this.announcementVo = announcementVo;
    }

    public ArrayList getAnnouncementVoList() {
        return announcementVoList;
    }

    public void setAnnouncementVoList(ArrayList announcementVoList) {
        this.announcementVoList = announcementVoList;
    }

    public PaginatedListImpl getPaginate() {
        return paginate;
    }

    public void setPaginate(PaginatedListImpl paginate) {
        this.paginate = paginate;
    }

    public String getShowDataGrid() {
        return showDataGrid;
    }

    public void setShowDataGrid(String showDataGrid) {
        this.showDataGrid = showDataGrid;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public String getSearchByPageNum() {
        return searchByPageNum;
    }

    public void setSearchByPageNum(String searchByPageNum) {
        this.searchByPageNum = searchByPageNum;
    }

    public String getNewFlag() {
        return newFlag;
    }

    public void setNewFlag(String newFlag) {
        this.newFlag = newFlag;
    }

    public String getInitFlag() {
        return initFlag;
    }

    public void setInitFlag(String initFlag) {
        this.initFlag = initFlag;
    }

     
    public String getPATH_FILE() {
        PropertyResourceBundle appConfig = (PropertyResourceBundle) PropertyResourceBundle.getBundle("app-config", Locale.US);
        //Get Path for write file
        String path = appConfig.getString("announcement_path");
        if (!path.endsWith("/")) {
            path = path + "/";
        }
        PATH_FILE = path;
        log.info(" filePath : " + path);
        return PATH_FILE;
    }

    public void setPATH_FILE(String PATH_FILE) {
        this.PATH_FILE = PATH_FILE;
    }

    public String resetData() throws Exception {
        if (log.isDebugEnabled()) {
            log.debug("AnnouncementAction.resetData");
        }
       
        setInitFlag("Y");
        if (announcementVo == null) {
            announcementVo = new AnnouncementVo();
        }
        announcementVo.setAnnounceTitle("");
        announcementVo.setAnnounceDateStrFrom("");
        announcementVo.setAnnounceDateStrTo("");
        announcementVo.setIsActive(1);
        statusList = new ArrayList<DropdownVo>();
        statusList = (ArrayList<DropdownVo>) dropdownBusiness.getStatusDropdown();
        if (paginate == null) {
            paginate = createPaginate(rowAmt);
        }
        if (paginate != null) {
            String pageIndexSearch = String.valueOf(paginate.getIndex());
            setPageIndex(pageIndexSearch);
            announcementVo.setSearchPageIndex(pageIndexSearch);
        }
        paginate = announcementBusiness.getListAnnouncement(announcementVo, paginate, pageAmt);

        setShowDataGrid(BusinessConst.Flag.Y);
        return SEARCH;
    }
}
