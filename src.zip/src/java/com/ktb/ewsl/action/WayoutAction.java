/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.FormStatusControlBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.business.WayOutBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.FormStatusControlVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.QuestionVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningWayOutVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTB_User
 */
public class WayoutAction extends BaseAction{
    private static final Logger logger = Logger.getLogger(WayoutAction.class);
    private List<QuestionVo> wayOutquestion;
    private List<QuestionHistoryVo> questionHistoryList;
    private String cifNo;
    private int warningHeaderId;
    private int warningId;    
    private String currentHeaderStatus;       
    private String currentWarningTypeCode;          
    private String currentFormFlg;
    private String showMode = "true";//Mode View
    private String showButton = "";//ไม่แสดงปุ่ม
    private String infoStatus;
    private String actionMode;
    private String warningIdHistory;
    private String warningHeaderIdHistory;
    private String questionIdHistory;
    private String versionHistory;
    private String warningTypeHistory;
    private String actionDateHistory;
    private String forBackPage;
    private String warningDateStr;
                                 
    @Autowired
    private CustomerBusiness customerBusiness;
    
    @Autowired 
    private WayOutBusiness wayOutBusiness;
    
    @Autowired
    ActionHistoryBusiness actionHistoryBusiness;
    
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    
    @Autowired
    private FormStatusControlBusiness formStatusControlBusiness;
    
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
                        
    @Override
    public String success() throws Exception{
        log("[success][Begin]");    
        
        String          holderRole          = null;
        UserData        userData            = getCurrentUser();
        
        try{
            findData();
            
            if (EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId())){

                if(BusinessConst.Flag.N.equals(this.infoStatus)){
                    this.showMode   = "false";//Mode Edit
                    this.showButton = "1";//บันทึก, ส่งงาน
                }else if(BusinessConst.Flag.RMP.equals(this.infoStatus)){
                    if(BusinessConst.UserRole.BCM.equals(holderRole)){
                        this.showMode = "true";//Mode View
                        this.showButton = "";//ไม่แสดงปุ่ม
                    }else{
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "1";//บันทึก, ส่งงาน
                    }
                }else if(BusinessConst.Flag.RMF.equals(this.infoStatus) || BusinessConst.Flag.COMPLETE.equals(this.infoStatus)){
                    this.showMode = "true";//Mode View
                    this.showButton = "";//ไม่แสดงปุ่ม
                }else if(BusinessConst.Flag.BRMP.equals(this.infoStatus)){
                    this.showMode   = "false";//Mode Edit
                    this.showButton = "1";//บันทึก, ส่งงาน
                }
            }else if(BusinessConst.UserRole.BCM.equals(userData.getRoleId())){
                if(BusinessConst.Flag.N.equals(this.infoStatus)){
                    this.showMode   = "false";//Mode Edit
                    this.showButton = "3";//บันทึก, ตรวจสอบ/อนุมัติ
                }else if(BusinessConst.Flag.RMP.equals(this.infoStatus)){
                    if(BusinessConst.UserRole.BCM.equals(holderRole)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "3";//บันทึก, ตรวจสอบ/อนุมัติ
                    }else{
                       this.showMode = "true";//Mode View
                       this.showButton = "";//ไม่แสดงปุ่ม
                    }
                }else if(BusinessConst.Flag.RMF.equals(this.infoStatus)){
                    this.showMode = "true";//Mode View
                    this.showButton = "2";//แก้ไข, ส่งกลับ, ตรวจสอบ/อนุมัติ
                }else if(BusinessConst.Flag.COMPLETE.equals(this.infoStatus) || BusinessConst.Flag.BRMP.equals(this.infoStatus)){
                    this.showMode = "true";//Mode View
                    this.showButton = "";//ไม่แสดงปุ่ม
                }
            }
            
            if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    this.showMode = "true";//Mode View
                    this.showButton = "";//ไม่แสดงปุ่ม
                }
                
                request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
            }
            
//        this.showMode   = "false";//For Test
//        this.showButton = "1";//For Test
            
        } catch (Exception ex) {
            throw ex;
        }                        
        logger.debug("WayoutAction success Finish");                                
        return SUCCESS;
    }
     
    public String goQuestionHistory() throws Exception {
        logger.debug("WayoutAction success Start");    
        
        WarningInfoVo   warningInfoVo       = null;
        WarningInfoVo   warningInfoVoDb     = null;
        
        try{
            if (logger.isDebugEnabled()) {
                logger.debug("Entry to............. WayoutAction.goQuestionHistory");
                logger.debug(" CifNo >>" + getCifNo());    
                logger.debug(" warningHeaderIdHistory >>" + this.warningHeaderIdHistory);
            }
            
            UserData userData = getCurrentUser();
            
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(Integer.parseInt(this.warningHeaderIdHistory));
//            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
            
            this.infoStatus         = warningInfoVoDb.getStatus();
            this.warningId          = warningInfoVoDb.getWarningId();
            
            log("[success] infoStatus        :: " + this.infoStatus);
            log("[success] RoleId            :: " + userData.getRoleId());
            
            QuestionVo filter = new QuestionVo();
            filter.setWarningId(this.warningId);
            wayOutquestion = wayOutBusiness.findQuestionWayOut(filter);

            findQuestionHistory(this.cifNo);
            
            this.showMode   = "true";
            this.showButton = "";
            
        } catch (Exception ex) {
            throw ex;
        }                        
        logger.debug("WayoutAction goQuestionHistory Finish");                                
        return SUCCESS;
    }
   
//    public String saveData() throws Exception {
//        log("[saveData][Begin]");
//        
//        FormStatusControlVo         formStatusControlVo     = null;
//        String                      nextStatus              = "";
//        UserData                    userData                = getCurrentUser();
//        List<WarningWayOutVo>       warningWayOutList       = null;
//        ActionHistoryVo             actionHistoryVo         = null;
//        WarningInfoVo               warningInfoVo           = null;
//        String                      holderRole              = "";
//        WarningHeaderVo             warningHeaderVo         = null;
//        String                      holderId                = null;
//        String                      actionCode              = "";
//        
//        try{
//            
//            
//            log("[saveData] actionMode  :: " + actionMode);
//            
//            actionCode = "SaveAndApprove".equals(actionMode)?"Approve":actionMode;
//            
//            /*Begin หา status*/
//            formStatusControlVo = new FormStatusControlVo();
//            formStatusControlVo.setCurrStatus(infoStatus);
//            formStatusControlVo.setActionCode(actionCode);
//            formStatusControlVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
//            nextStatus = this.nullToStr(formStatusControlBusiness.getNextStatus(formStatusControlVo));
//            nextStatus = nextStatus.equals("")?infoStatus:nextStatus;
//            /*End หา status*/
//            
//            log("[saveData] nextStatus :: " + nextStatus);
//            
//            if ("Draft".equals(actionMode)) {
//                holderRole              = userData.getRoleId();
//                holderId                = userData.getEmpNo();
//                warningWayOutList       = assignValue(this.warningId, userData.getEmpNo(), getWayOutquestion(), userData.getRoleId());
//                wayOutBusiness.saveWayOut(warningWayOutList);
//            }else if ("Save".equals(actionMode)) {
//                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "");
//                
//                warningWayOutList       = assignValue(this.warningId, userData.getEmpNo(), getWayOutquestion(), userData.getRoleId());
//                wayOutBusiness.saveWayOut(warningWayOutList);
//                
//                /*Begin Update TBL_WARNING_HEADER*/
//                warningHeaderVo = new WarningHeaderVo();
//                warningHeaderVo.setWayOutFlg("I");
//                warningHeaderVo.setWarningHeaderId(warningHeaderId);
//                warningHeaderVo.setUpdatedBy(userData.getEmpNo());
//                
//                warningHeaderBusiness.updateWayOutFlg(warningHeaderVo);
//                /*End Update TBL_WARNING_HEADER*/
//                
//            }else if ("Approve".equals(actionMode)) {
//                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "");
//                
//                warningWayOutList       = assignValueForApprove();
//                wayOutBusiness.saveWayOut(warningWayOutList);
//                
//                /*Begin Update TBL_WARNING_HEADER*/
//                warningHeaderVo = new WarningHeaderVo();
//                warningHeaderVo.setWayOutFlg("C");
//                warningHeaderVo.setWarningHeaderId(warningHeaderId);
//                warningHeaderVo.setUpdatedBy(userData.getEmpNo());
//                
//                warningHeaderBusiness.updateWayOutFlg(warningHeaderVo);
//                /*End Update TBL_WARNING_HEADER*/
//                
//                //การ update TBL_WARNING_HEADER เพื่อให้งานหายจาก Pipeline
//                warningHeaderBusiness.updateForApprove(warningHeaderVo, "F");
//                
//            }else if ("Reject".equals(actionMode)) {
//                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "");
//                
//                /*Begin Update TBL_WARNING_HEADER*/
//                warningHeaderVo = new WarningHeaderVo();
//                warningHeaderVo.setWayOutFlg("N");
//                warningHeaderVo.setWarningHeaderId(warningHeaderId);
//                warningHeaderVo.setUpdatedBy(userData.getEmpNo());
//                
//                warningHeaderBusiness.updateWayOutFlg(warningHeaderVo);
//                /*End Update TBL_WARNING_HEADER*/
//                
//                int cnt = warningHeaderBusiness.findWarningInfoALLNewOrBlank(warningHeaderId);
//                if (cnt == 1) {
//                    warningHeaderVo.setStatus("N");
//                    warningHeaderBusiness.updateStatusWarningHeader(warningHeaderVo);
//                }
//                
//                wayOutBusiness.deleteTblWarningWayOutForm(this.warningId, BusinessConst.UserRole.BCM);
//
//                
//            }
////            else if ("SaveAndApprove".equals(actionMode)) {
////                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "");
////                
////                warningWayOutList       = assignValue(this.warningId, userData.getEmpNo(), getWayOutquestion(), userData.getRoleId());
////                wayOutBusiness.saveWayOut(warningWayOutList);
////                
////                /*Begin Update TBL_WARNING_HEADER*/
////                warningHeaderVo = new WarningHeaderVo();
////                warningHeaderVo.setWayOutFlg("C");
////                warningHeaderVo.setWarningHeaderId(warningHeaderId);
////                warningHeaderVo.setUpdatedBy(userData.getEmpNo());
////                
////                warningHeaderBusiness.updateWayOutFlg(warningHeaderVo);
////                /*End Update TBL_WARNING_HEADER*/
////                
////                //การ update TBL_WARNING_HEADER เพื่อให้งานหายจาก Pipeline
////                warningHeaderBusiness.updateForApprove(warningHeaderVo, "F");
////            }
//            
//            /*Begin Update TBL_WARNING_INFO*/
//            warningInfoVo = new WarningInfoVo();
//            warningInfoVo.setStatus(nextStatus);
//            warningInfoVo.setUpdatedBy(userData.getEmpNo());
//            warningInfoVo.setWarningId(this.warningId);
//            warningInfoVo.setHolderId(holderId);
//            warningInfoVo.setHolderRole(holderRole);
//
//            warningInfoBusiness.updateStatusForWayOut(warningInfoVo);
//            /*End Update TBL_WARNING_INFO*/
//            
//            /*Begin Insert TBL_ACTION_HISTORY*/
//            actionHistoryVo = new ActionHistoryVo();
//            actionHistoryVo.setWarningId(this.warningId);
//            actionHistoryVo.setActionBy(userData.getEmpNo());
//            actionHistoryVo.setActionCode(actionMode);
//            actionHistoryVo.setActionDetail(BusinessConst.WarningTypeCode.WAY_OUT);
//            actionHistoryVo.setStatus(nextStatus);
//            
//            actionHistoryBusiness.saveData(actionHistoryVo);
//            /*End Insert TBL_ACTION_HISTORY*/
//            
//        }catch(Exception e){
//            logger.error(e);
//            throw e;
//        }finally{
//            log("[saveData][End]");
//        }
//        
//        return "saveData";
//    }
    
    private List<WarningWayOutVo> assignValue(int warningId, String createBy, List<QuestionVo> wayOutquestionList, String roleCode){
        log("[assignValue][Begin]");
        
        List<WarningWayOutVo>   result  = new ArrayList<WarningWayOutVo>();        
        int                     i       = 1;
        
        try{
            log("wayOutquestionList :: " + wayOutquestionList);
            if(wayOutquestionList!=null || !wayOutquestionList.isEmpty()){
                for(QuestionVo vo : wayOutquestionList){
                    log("i="+i);
                    if(null!=vo){
                        WarningWayOutVo warningWayOutVo = new WarningWayOutVo();                
                        logger.debug("Answer="+vo.getAnswer());                
                        warningWayOutVo.setWarningId(warningId);
                        warningWayOutVo.setWayoutId(i);                
                        if("TRUE".equals(vo.getAnswer().toUpperCase())){
                            warningWayOutVo.setWayoutFlg(BusinessConst.Flag.Y);
                        }else{
                            warningWayOutVo.setWayoutFlg(BusinessConst.Flag.N);
                        }                                                
                        warningWayOutVo.setWayoutRemark(vo.getRemark());
                        warningWayOutVo.setCreatedBy(createBy);
                        warningWayOutVo.setUpdatedBy(createBy);
                        warningWayOutVo.setRoleCode(roleCode);
                        result.add(warningWayOutVo);
                    }            
                    i++;
                }
            }
        }catch(Exception e){
            logger.error(e);
        }finally{
            log("[assignValue][End]");
        }
            
        return result;
    }
    
    private List<WarningWayOutVo> assignValueForApprove(){
        log("[assignValueForApprove][Begin]");
        
        List<WarningWayOutVo>   result          = new ArrayList<WarningWayOutVo>();
        UserData                userData        = getCurrentUser();
        String[]                hidAnswerArray  = null;
        String[]                hidRemarkArray  = null;
        WarningWayOutVo         warningWayOutVo = null;
        
        try{
            hidAnswerArray  = request.getParameterValues("hidAnswer");
            hidRemarkArray  = request.getParameterValues("hidRemark");
                    
                    
            for(int i=0;i<hidAnswerArray.length;i++){
                warningWayOutVo = new WarningWayOutVo();
                
                warningWayOutVo.setWarningId(this.warningId);
                warningWayOutVo.setWayoutId(i+1);                
                if("TRUE".equalsIgnoreCase(hidAnswerArray[i])){
                    warningWayOutVo.setWayoutFlg(BusinessConst.Flag.Y);
                }else{
                    warningWayOutVo.setWayoutFlg(BusinessConst.Flag.N);
                }                                                
                warningWayOutVo.setWayoutRemark(hidRemarkArray[i]);
                warningWayOutVo.setCreatedBy(userData.getEmpNo());
                warningWayOutVo.setUpdatedBy(userData.getEmpNo());
                warningWayOutVo.setRoleCode(userData.getRoleId());
                result.add(warningWayOutVo);
            }
        }catch(Exception e){
            logger.error(e);
        }finally{
            log("[assignValueForApprove][End]");
        }
            
        return result;
    }
     
    public String goTaskDetail() throws Exception {
        logger.debug("[goTaskDetail][Begin]");
        
        String backToPage   = "backTaskDetail";
        String forBackPage  = null;
        
        try{
            forBackPage = (String) request.getSession(false).getAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL);
            
            logger.debug("[goTaskDetail] forBackPage :: " + forBackPage);
            
            if(forBackPage!=null && !forBackPage.equals("")){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    backToPage = "backCloseJobTaskList";
                }else if(forBackPage.equals(BusinessConst.PAGE.PIPELINE)){
                    backToPage = "backTaskDetail";
                }
            }
            
            logger.debug("[goTaskDetail][End]");
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[goTaskDetail][End]");
        }
        
        return backToPage;
    }
     
    public void findQuestionHistory(String cif) throws Exception{
        List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForQuestion(cif, BusinessConst.WarningTypeCode.WAY_OUT);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
//                    vo.setActionDetail(BusinessConst.WarningTypeCode.WAY_OUT);
//                    vo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
                    vo.setCif(cif);
                    historyList = actionHistoryBusiness.findQuestionHistory(vo);
                    if (historyList != null && !historyList.isEmpty()) {
                        tmpVo = (QuestionHistoryVo) historyList.get(0);
                        vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                        vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                        vo.setActionUserId(tmpVo.getActionUserId());
                        vo.setActionDate(tmpVo.getActionDate());
                        vo.setApproveUserId(tmpVo.getApproveUserId());
                        vo.setApproveDate(tmpVo.getApproveDate());
                        vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                        vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                        vo.setCif(cif);
                        if (BusinessConst.WarningTypeCode.EWSQ.equals(BusinessConst.WarningTypeCode.WAY_OUT)) {
                            QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                            vo.setVersion(tmpQuestionVo.getVersion());
                            vo.setQuestionId(tmpQuestionVo.getQuestionId());
                        }
                        resultList.add(vo);
                    }  
                }
                if(resultList.size() > 0){
                    setQuestionHistoryList(resultList);
                }
            }
    }
    
    public String editByBCM() throws Exception{
        log("[editByBCM][Begin]");
        
        try{
            findDataByBCM();
            
            this.showMode   = "false";//Mode Edit
            this.showButton = "4";//บันทึก, ยกเลิก
            
            
        } catch (Exception ex) {
            logger.error(ex);
            throw ex;
        } finally{
            log("[editByBCM][End]");
        }                       
                                  
        return SUCCESS;
    }
    
    public String cancel() throws Exception{
        log("[cancel][Begin]");

        try{
            findData();

            this.showMode = "true";//Mode View
            this.showButton = "2";//แก้ไข, ส่งกลับ, ตรวจสอบ/อนุมัติ


        } catch (Exception ex) {
            logger.error(ex);
            throw ex;
        } finally{
            log("[cancel][End]");
        }                       

        return SUCCESS;
    }
    
    public String saveForBCM() throws Exception {
        log("[saveForBCM][Begin]");
        
        UserData                    userData                = null;
        List<WarningWayOutVo>       warningWayOutList       = null;
        
        try{
            userData                = getCurrentUser();
            
            warningWayOutList       = assignValue(this.warningId, userData.getEmpNo(), getWayOutquestion(), userData.getRoleId());
            wayOutBusiness.saveWayOut(warningWayOutList);
            
            findData();

            this.showMode = "true";//Mode View
            this.showButton = "2";//แก้ไข, ส่งกลับ, ตรวจสอบ/อนุมัติ
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[saveForBCM][End]");
        }
        
        return SUCCESS;
    }
      
    private void findData() throws Exception{
        log("[findData][Begin]");
        
        WarningInfoVo   warningInfoVo       = null;
        WarningInfoVo   warningInfoVoDb     = null;
        String          holderRole          = null;
        
        try{
            log("[findData] CifNo                   :: " + getCifNo());    
            log("[findData] CurrentHeaderStatus     :: " + getCurrentHeaderStatus());
            log("[findData] CurrentWarningTypeCode  :: " + getCurrentWarningTypeCode());
            log("[findData] WarningHeaderId         :: " + getWarningHeaderId());
            log("[findData] WarningId               :: " + getWarningId());
            log("[findData] CurrentFormFlg          :: " + getCurrentFormFlg());
            
            UserData userData = getCurrentUser();
            
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(getWarningHeaderId());
            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
            
            this.infoStatus         = warningInfoVoDb.getStatus();
            this.warningId          = warningInfoVoDb.getWarningId();
            this.warningDateStr     = warningInfoVoDb.getWarningDateStr();
            holderRole              = warningInfoVoDb.getHolderRole();
            
            log("[findData] infoStatus        :: " + this.infoStatus);
            log("[findData] RoleId            :: " + userData.getRoleId());
            log("[findData] holderRole        :: " + holderRole);
            
            /*การดึงข้อมูลจาก  TBL_WARNING_WAYOUT_FORM ให้ดึงข้อมูลของ ROLE_CODE = “BCM” มาแสดงก่อน ถ้าไม่มี ค่อยดึงข้อมูลของ ROLE_CODE IN (‘RM,’AE’,’AO’) มาแสดง*/
            QuestionVo          filter          = new QuestionVo();
            ArrayList<String>   roleCodeList    = new ArrayList<String>();
            filter.setWarningId(this.warningId);
            roleCodeList.add(BusinessConst.UserRole.BCM);
            filter.setRoleCodeList(roleCodeList);
            wayOutquestion = wayOutBusiness.findQuestionWayOut(filter);
            
            log("[findData] wayOutquestion        :: " + wayOutquestion);
            if(wayOutquestion==null || wayOutquestion.isEmpty()){
                roleCodeList    = new ArrayList<String>();
                
                roleCodeList.add(BusinessConst.UserRole.RM);
                roleCodeList.add(BusinessConst.UserRole.AE);
                roleCodeList.add(BusinessConst.UserRole.AO);
                
                filter.setRoleCodeList(roleCodeList);
                wayOutquestion = wayOutBusiness.findQuestionWayOut(filter);
            }

            findQuestionHistory(this.cifNo);
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        } finally{
            log("[findData][End]");
        }        
    }
       
    private void findDataByBCM() throws Exception{
        log("[findDataByBCM][Begin]");
        
        WarningInfoVo   warningInfoVo       = null;
        WarningInfoVo   warningInfoVoDb     = null;
        String          holderRole          = null;
        
        try{
            log("[findDataByBCM] CifNo                   :: " + getCifNo());    
            log("[findDataByBCM] CurrentHeaderStatus     :: " + getCurrentHeaderStatus());
            log("[findDataByBCM] CurrentWarningTypeCode  :: " + getCurrentWarningTypeCode());
            log("[findDataByBCM] WarningHeaderId         :: " + getWarningHeaderId());
            log("[findDataByBCM] WarningId               :: " + getWarningId());
            log("[findDataByBCM] CurrentFormFlg          :: " + getCurrentFormFlg());
            
            UserData userData = getCurrentUser();
            
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(getWarningHeaderId());
            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
            
            this.infoStatus         = warningInfoVoDb.getStatus();
            this.warningId          = warningInfoVoDb.getWarningId();
            this.warningDateStr     = warningInfoVoDb.getWarningDateStr();
            holderRole              = warningInfoVoDb.getHolderRole();
            
            log("[findDataByBCM] infoStatus        :: " + this.infoStatus);
            log("[findDataByBCM] RoleId            :: " + userData.getRoleId());
            log("[findDataByBCM] holderRole        :: " + holderRole);
            
            QuestionVo          filter          = new QuestionVo();
            filter.setWarningId(this.warningId);
            wayOutquestion = wayOutBusiness.findQuestionWayOutForBCM(filter);

            findQuestionHistory(this.cifNo);
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        } finally{
            log("[findDataByBCM][End]");
        }        
    }
   
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }
    
    private String nullToStr(Object obj){
        
        return obj==null?"":obj.toString().trim();
        
    }

    /**
     * @return the cifNo
     */
    public String getCifNo() {
        return cifNo;
    }

    /**
     * @param cifNo the cifNo to set
     */
    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    /**
     * @return the warningHeaderId
     */
    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    /**
     * @param warningHeaderId the warningHeaderId to set
     */
    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    /**
     * @return the warningId
     */
    public int getWarningId() {
        return warningId;
    }

    /**
     * @param warningId the warningId to set
     */
    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    /**
     * @return the currentHeaderStatus
     */
    public String getCurrentHeaderStatus() {
        return currentHeaderStatus;
    }

    /**
     * @param currentHeaderStatus the currentHeaderStatus to set
     */
    public void setCurrentHeaderStatus(String currentHeaderStatus) {
        this.currentHeaderStatus = currentHeaderStatus;
    }

    /**
     * @return the currentWarningTypeCode
     */
    public String getCurrentWarningTypeCode() {
        return currentWarningTypeCode;
    }

    /**
     * @param currentWarningTypeCode the currentWarningTypeCode to set
     */
    public void setCurrentWarningTypeCode(String currentWarningTypeCode) {
        this.currentWarningTypeCode = currentWarningTypeCode;
    }

    /**
     * @return the currentFormFlg
     */
    public String getCurrentFormFlg() {
        return currentFormFlg;
    }

    /**
     * @param currentFormFlg the currentFormFlg to set
     */
    public void setCurrentFormFlg(String currentFormFlg) {
        this.currentFormFlg = currentFormFlg;
    }

    /**
     * @return the wayOutquestion
     */
    public List<QuestionVo> getWayOutquestion() {
        return wayOutquestion;
    }

    /**
     * @param wayOutquestion the wayOutquestion to set
     */
    public void setWayOutquestion(List<QuestionVo> wayOutquestion) {
        this.wayOutquestion = wayOutquestion;
    }

    /**
     * @return the questionHistoryList
     */
    public List<QuestionHistoryVo> getQuestionHistoryList() {
        return questionHistoryList;
    }

    /**
     * @param questionHistoryList the questionHistoryList to set
     */
    public void setQuestionHistoryList(List<QuestionHistoryVo> questionHistoryList) {
        this.questionHistoryList = questionHistoryList;
    }

    public String getShowMode() {
        return showMode;
    }

    public void setShowMode(String showMode) {
        this.showMode = showMode;
    }

    public String getShowButton() {
        return showButton;
    }

    public void setShowButton(String showButton) {
        this.showButton = showButton;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }

    public String getWarningIdHistory() {
        return warningIdHistory;
    }

    public void setWarningIdHistory(String warningIdHistory) {
        this.warningIdHistory = warningIdHistory;
    }

    public String getWarningHeaderIdHistory() {
        return warningHeaderIdHistory;
    }

    public void setWarningHeaderIdHistory(String warningHeaderIdHistory) {
        this.warningHeaderIdHistory = warningHeaderIdHistory;
    }

    public String getQuestionIdHistory() {
        return questionIdHistory;
    }

    public void setQuestionIdHistory(String questionIdHistory) {
        this.questionIdHistory = questionIdHistory;
    }

    public String getVersionHistory() {
        return versionHistory;
    }

    public void setVersionHistory(String versionHistory) {
        this.versionHistory = versionHistory;
    }

    public String getWarningTypeHistory() {
        return warningTypeHistory;
    }

    public void setWarningTypeHistory(String warningTypeHistory) {
        this.warningTypeHistory = warningTypeHistory;
    }

    public String getActionDateHistory() {
        return actionDateHistory;
    }

    public void setActionDateHistory(String actionDateHistory) {
        this.actionDateHistory = actionDateHistory;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    public String getWarningDateStr() {
        return warningDateStr;
    }

    public void setWarningDateStr(String warningDateStr) {
        this.warningDateStr = warningDateStr;
    }
}
