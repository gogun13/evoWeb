/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ConfigBusiness;
import com.ktb.ewsl.business.IndividualODAccountBusiness;
import com.ktb.ewsl.business.TodayMovementBusiness;
import com.ktb.ewsl.vo.ConfigVO;
import com.ktb.ewsl.vo.CrWarningAcctVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.IndividualODAccountVo;
import com.ktb.ewsl.vo.RptIndividualAccountVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Pratya
 */
public class TodayMovementAction extends BaseAction {
    private static final Logger logger = Logger.getLogger(TodayMovementAction.class);
    
    private CustomerVo customerVo;
    private List<RptIndividualAccountVo> rptIndividualAcctList;
    private String cif;
    private String custName;
    private String pageMode;
    private String forBackPage;
//    private String forBackAcctDetail;
    private String firstTime;
    private List<CrWarningAcctVo>   crWarningAcctExpList;
    private List<CrWarningAcctVo>   crWarningAcctNoExpList;
    private String cifHid;
//    private List<IndividualODAccountVo> odAccountVoList;
//    private List<IndividualODAccountVo> beforeODAccountVoList;
    private InputStream fileStream;
    private String exportFileName;
    
    @Autowired
    private TodayMovementBusiness todayMovementBusiness;
    @Autowired
    private IndividualODAccountBusiness individualODAccountBusiness;
    @Autowired
    private ConfigBusiness configBusiness;

    @Override
    public String execute() throws Exception {
        log("[execute][Begin]");
        String forward  = null;
        String command  = null;
        try{
            command = request.getParameter("command");
            
            log("[execute] command :: " + command);
            
            if(command==null || command.equals(SUCCESS)){
                forward = success();
            }else if(command.equals("goTaskDetail")){
                forward = goTaskDetail();
            }else if(command.equals("search")){
                forward = search();
            }else if(command.equals("tabTodayMovment2")){
                forward = tabTodayMovment2();
            }else if(command.equals("tabTodayMovment1")){
                forward = tabTodayMovment1();
            }else if(command.equals("gotoAcctDetail")){
                forward = gotoAcctDetail();
            }else if(command.equals("searchConditionMemory")){
                forward = searchConditionMemory();
            }else if(command.equals("exportExcelTab1")){
                forward = exportExcelTab1();
            }else if(command.equals("exportExcelTab2")){
                forward = exportExcelTab2();
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[execute][End]");
        }
        return forward;
    }
    
    @Override
    public String success() throws Exception {
        log("[success][Begin]");
        
        try{
            this.customerVo = new CustomerVo();
            this.search();
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[success][End]");
        }
        
        return SUCCESS;
    }
    
    public String search() throws Exception {
        log("[search][Begin]");
        String                  cif                     = null;
        String                  custName                = null;
        CustomerVo              criteriaVo              = null;
        
        try{
            
            log("[search] forBackPage :: " + this.forBackPage);
            
            if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
                request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
            }
            
            cif           = URLDecoder.decode(nullToStr(this.cif), "UTF-8");
            custName      = URLDecoder.decode(nullToStr(this.custName), "UTF-8");
            this.custName = custName;
            this.cif      = cif;
            
            log("[search] cif       :: " + cif);
            log("[search] custName  :: " + custName);
            
            if(!cif.equals("") || !custName.equals("")){
                criteriaVo = new CustomerVo();
                
                if(!cif.equals(""))criteriaVo.setCif(paresInt(cif));
                if(!custName.equals(""))criteriaVo.setCustName(custName);
                
                this.customerVo     = this.todayMovementBusiness.customerInfo(criteriaVo);
                
                if(this.customerVo!=null){
                    this.cifHid = nullToStr(this.customerVo.getCif());
                    tabTodayMovment1();
                }
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[search][End]");
        }
        
        return "search";
    }
    
    private String searchConditionMemory() throws Exception{
        log("[searchConditionMemory][Begin]");
        
        try{
            
            if("review".equals(this.pageMode)){
                this.cif = this.cifHid;
            }
            
            
            search();
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[searchConditionMemory][End]");
        }
        
        return SUCCESS;
    }
 
    private String goTaskDetail(){
        log("[goTaskDetail][Begin]");
        String forward = "backTaskDetail";
        
        try{
//            if(!nullToStr(this.condition).equals("")){
//                forward = "backTaskDetailCond";
//            }
            
        }catch(Exception e){
            logger.error(e);
        }finally{
            log("[goTaskDetail][End]");
        }
        return forward;
        
        
    }
  
    private String gotoAcctDetail(){
        log("[gotoAcctDetail][Begin]");
        
        String forward = "gotoAcctDetail";
        
        try{
            
//            setForBackAcctDetail(BusinessConst.PAGE.TODAY_MOVEMENT);
            
        }catch(Exception e){
            logger.error(e);
        }finally{
            log("[gotoAcctDetail][End]");
        }
        return forward;
        
        
    }   
    
    public String tabTodayMovment1() throws Exception {
        log("[tabTodayMovment1][Begin]");
        String                          cif                     = null;
        RptIndividualAccountVo          rptIndividualAcctVo     = null;
        
        try{
            
            cif           = nullToStr(this.cifHid);
            
            log("[tabTodayMovment1] cif       :: " + cif);
            
            if(!cif.equals("")){
                rptIndividualAcctVo = new RptIndividualAccountVo();
                rptIndividualAcctVo.setCif(cif);
                rptIndividualAcctList = this.todayMovementBusiness.getRptIndividualAccountList(rptIndividualAcctVo);
            /*   -------[BUG Copy Code comment 26/06/2560]   
                odAccountVoList =  individualODAccountBusiness.getWarningODOverLimit(cif);
                List<ConfigVO> configList = configBusiness.findByConfigGroup(BusinessConst.CONFIG_GROUP.TODAY_MOVEMENT_OD);
                int dateInt = DateUtil.getDayOfMonth(DateUtil.getCurrentDateTime());
                log("dateInt = " + dateInt);
                if(configList != null && !configList.isEmpty()&&(dateInt > 0)){
                    for(ConfigVO vo : configList){
                       int valueDate =  vo.getConfigValue() != null ? Integer.parseInt(vo.getConfigValue()) : 0 ;
                       if(dateInt == valueDate){
                        beforeODAccountVoList = individualODAccountBusiness.getWarningBeforeODOverLimit(cif);
                        break;
                       }
                    }
                }
                */
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[tabTodayMovment1][End]");
        }
        
        return "tabTodayMovment1";
    }
    
    public String exportExcelTab1() throws Exception{
        log("[exportExcelTab1][Begin]");
        
        String                          cif                     = null;
        RptIndividualAccountVo          rptIndividualAcctVo     = null;
        List<RptIndividualAccountVo>    rptIndividualAcctList   = new ArrayList<RptIndividualAccountVo>();
//        List<IndividualODAccountVo>     odAccountVoList         = new ArrayList<IndividualODAccountVo>();
//        List<IndividualODAccountVo>     beforeODAccountVoList   = new ArrayList<IndividualODAccountVo>();
        CustomerVo                      customerVo              = null;
        CustomerVo                      criteriaVo              = null;
        HashMap                         beans                   = new HashMap();
        String                          rmEmpNo                 = "";
        String                          aeEmpNo                 = "";
        
        try{
            cif           = nullToStr(this.request.getParameter("cif"));
            
            log("[exportExcelTab1] cif       :: " + cif);
            
            if(!cif.equals("")){
                criteriaVo = new CustomerVo();
                
                criteriaVo.setCif(paresInt(cif));
                customerVo     = this.todayMovementBusiness.customerInfo(criteriaVo);
                
                rptIndividualAcctVo = new RptIndividualAccountVo();
                rptIndividualAcctVo.setCif(cif);
                rptIndividualAcctList = this.todayMovementBusiness.getRptIndividualAccountList(rptIndividualAcctVo);
              /*  -------[BUG Copy Code comment 26/06/2560]
                odAccountVoList =  individualODAccountBusiness.getWarningODOverLimit(cif);
                List<ConfigVO> configList = configBusiness.findByConfigGroup(BusinessConst.CONFIG_GROUP.TODAY_MOVEMENT_OD);
                int dateInt = DateUtil.getDayOfMonth(DateUtil.getCurrentDateTime());
                log("dateInt = " + dateInt);
                if(configList != null && !configList.isEmpty()&&(dateInt > 0)){
                    for(ConfigVO vo : configList){
                       int valueDate =  vo.getConfigValue() != null ? Integer.parseInt(vo.getConfigValue()) : 0 ;
                       if(dateInt == valueDate){
                        beforeODAccountVoList = individualODAccountBusiness.getWarningBeforeODOverLimit(cif);
                        break;
                       }
                    }
                }*/
            }
            
            if(customerVo!=null){
                beans.put("cif"         , customerVo.getCif());
                beans.put("custName"    , customerVo.getCustName());
                
                rmEmpNo = customerVo.getRmEmpNo() + " - " + customerVo.getRmTitleName() + " " + customerVo.getRmEmpName() + " " + customerVo.getRmEmpSurName();
                beans.put("rmEmpNo"     , rmEmpNo);
                beans.put("responseUnit", customerVo.getResponseUnit() + " - " + customerVo.getResponseUnitName());
                
                aeEmpNo = customerVo.getAeEmpNo() + " - " + customerVo.getAeTitleName() + " " + customerVo.getAeEmpName() + " " + customerVo.getAeEmpSurName();
                beans.put("aeEmpNo", aeEmpNo);
            }else{
                beans.put("cif"         , "");
                beans.put("custName"    , "");
                beans.put("rmEmpNo"     , "");
                beans.put("responseUnit", "");
                beans.put("aeEmpNo"     , "");
            }
            
            if(rptIndividualAcctList!=null && rptIndividualAcctList.size() > 0){
                for(RptIndividualAccountVo vo:rptIndividualAcctList){
                    if(vo.getProductType()!=null && !vo.getProductType().equals("")){
                        vo.setProductType(vo.getProductType() + " : " + vo.getLoanGrpProd());
                    }
                }
            }
            
            beans.put("rptIndividualAcctList"     , rptIndividualAcctList);
//            beans.put("odAccountVoList"           , odAccountVoList);
//            beans.put("beforeODAccountVoList"     , beforeODAccountVoList);
            
            XLSTransformer transformer = new XLSTransformer();
            String path = getServletContext().getRealPath("/");
            File file = new File(path + "report/todayMovementDPDReportTemplete.xls");
            InputStream inputStream = new FileInputStream(file);
            HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
            Calendar cal = Calendar.getInstance();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            
            response.setHeader("Set-Cookie", "fileDownload=true; path=/");

            bos.close();
            byte[] bytes = bos.toByteArray();
            setExportFileName("TodayMovementDPD_CIF" + cif + "_" + format.format(cal.getTime()).toString() + ".xls");
            fileStream = new ByteArrayInputStream(bytes);
            
            
        }catch(Exception e){
            logger.error(e);
            response.setHeader("Set-Cookie", "fileDownload=false; path=/");
            throw e;
        }finally{
            log("[exportExcelTab1][End]");
        }
        
        return "export";
    }
     
    public String tabTodayMovment2() throws Exception {
        log("[tabTodayMovment2][Begin]");
        String                  cif                     = null;
        
        try{
            
            cif           = nullToStr(this.cifHid);
            
            log("[tabTodayMovment2] cif       :: " + cif);
            
            if(!cif.equals("")){
                this.crWarningAcctExpList    = this.todayMovementBusiness.getCrWarningAcctList(cif, "M");
                this.crWarningAcctNoExpList  = this.todayMovementBusiness.getCrWarningAcctList(cif, "L");
                
            }else{
                this.crWarningAcctExpList    = null;
                this.crWarningAcctNoExpList  = null;
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[tabTodayMovment2][End]");
        }
        
        return "tabTodayMovment2";
    }
    
    public String exportExcelTab2() throws Exception{
        log("[exportExcelTab2][Begin]");
        
        String                          cif                     = null;
        List<CrWarningAcctVo>           crWarningAcctExpList    = null;;
        List<CrWarningAcctVo>           crWarningAcctNoExpList  = null;
        CustomerVo                      customerVo              = null;
        CustomerVo                      criteriaVo              = null;
        HashMap                         beans                   = new HashMap();
        String                          rmEmpNo                 = "";
        String                          aeEmpNo                 = "";
        
        try{
            cif           = nullToStr(this.request.getParameter("cif"));
            
            log("[exportExcelTab2] cif       :: " + cif);
            
            if(!cif.equals("")){
                criteriaVo = new CustomerVo();
                
                criteriaVo.setCif(paresInt(cif));
                customerVo     = this.todayMovementBusiness.customerInfo(criteriaVo);
                
                crWarningAcctExpList    = this.todayMovementBusiness.getCrWarningAcctList(cif, "M");
                crWarningAcctNoExpList  = this.todayMovementBusiness.getCrWarningAcctList(cif, "L");
            }
            
            if(customerVo!=null){
                beans.put("cif"         , customerVo.getCif());
                beans.put("custName"    , customerVo.getCustName());
                
                rmEmpNo = customerVo.getRmEmpNo() + " - " + customerVo.getRmTitleName() + " " + customerVo.getRmEmpName() + " " + customerVo.getRmEmpSurName();
                beans.put("rmEmpNo"     , rmEmpNo);
                beans.put("responseUnit", customerVo.getResponseUnit() + " - " + customerVo.getResponseUnitName());
                
                aeEmpNo = customerVo.getAeEmpNo() + " - " + customerVo.getAeTitleName() + " " + customerVo.getAeEmpName() + " " + customerVo.getAeEmpSurName();
                beans.put("aeEmpNo", aeEmpNo);
            }else{
                beans.put("cif"         , "");
                beans.put("custName"    , "");
                beans.put("rmEmpNo"     , "");
                beans.put("responseUnit", "");
                beans.put("aeEmpNo"     , "");
            }
            
            if(crWarningAcctExpList!=null && crWarningAcctExpList.size() > 0){
                for(CrWarningAcctVo vo:crWarningAcctExpList){
                    if(vo.getProductType()!=null && !vo.getProductType().equals("")){
                        vo.setProductType(vo.getProductType() + " : " + vo.getLoanGrpProd());
                    }
                }
            }
            
            if(crWarningAcctNoExpList!=null && crWarningAcctNoExpList.size() > 0){
                for(CrWarningAcctVo vo:crWarningAcctNoExpList){
                    if(vo.getProductType()!=null && !vo.getProductType().equals("")){
                        vo.setProductType(vo.getProductType() + " : " + vo.getLoanGrpProd());
                    }
                }
            }
            
            beans.put("crWarningAcctExpList"     , crWarningAcctExpList);
            beans.put("crWarningAcctNoExpList"   , crWarningAcctNoExpList);
            
            XLSTransformer transformer = new XLSTransformer();
            String path = getServletContext().getRealPath("/");
            File file = new File(path + "report/todayMovementCreditReviewReportTemplete.xls");
            InputStream inputStream = new FileInputStream(file);
            HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
            Calendar cal = Calendar.getInstance();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            
            response.setHeader("Set-Cookie", "fileDownload=true; path=/");

            bos.close();
            byte[] bytes = bos.toByteArray();
            setExportFileName("TodayMovementCreditReview_CIF" + cif + "_" + format.format(cal.getTime()).toString() + ".xls");
            fileStream = new ByteArrayInputStream(bytes);
            
            
        }catch(Exception e){
            logger.error(e);
            response.setHeader("Set-Cookie", "fileDownload=false; path=/");
            throw e;
        }finally{
            log("[exportExcelTab2][End]");
        }
        
        return "export";
    }
 
    private void writeMSG(String msg) {
        PrintWriter print = null;
        try {
            this.response.setContentType("text/html; charset=UTF-8");
            print = this.response.getWriter();
            print.write(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }
    
    private String nullToStr(Object obj){
        
        return obj==null?"":obj.toString().trim();
        
    }
    
    private int paresInt(Object obj){
        
        int ret = 0;
        
        try{
            return obj==null?0:Integer.parseInt(obj.toString());
        }catch(Exception e){
            ret = 0;
            logger.error(e);
        }
        return ret;
    }
    
    public CustomerVo getCustomerVo() {
        return customerVo;
    }

    public void setCustomerVo(CustomerVo customerVo) {
        this.customerVo = customerVo;
    }

    public List<RptIndividualAccountVo> getRptIndividualAcctList() {
        return rptIndividualAcctList;
    }

    public void setRptIndividualAcctList(List<RptIndividualAccountVo> rptIndividualAcctList) {
        this.rptIndividualAcctList = rptIndividualAcctList;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getPageMode() {
        return pageMode;
    }

    public void setPageMode(String pageMode) {
        this.pageMode = pageMode;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    public String getFirstTime() {
        return firstTime;
    }

    public void setFirstTime(String firstTime) {
        this.firstTime = firstTime;
    }

    public List<CrWarningAcctVo> getCrWarningAcctExpList() {
        return crWarningAcctExpList;
    }

    public void setCrWarningAcctExpList(List<CrWarningAcctVo> crWarningAcctExpList) {
        this.crWarningAcctExpList = crWarningAcctExpList;
    }

    public List<CrWarningAcctVo> getCrWarningAcctNoExpList() {
        return crWarningAcctNoExpList;
    }

    public void setCrWarningAcctNoExpList(List<CrWarningAcctVo> crWarningAcctNoExpList) {
        this.crWarningAcctNoExpList = crWarningAcctNoExpList;
    }

    public String getCifHid() {
        return cifHid;
    }

    public void setCifHid(String cifHid) {
        this.cifHid = cifHid;
    }

//    public List<IndividualODAccountVo> getOdAccountVoList() {
//        return odAccountVoList;
//    }
//
//    public void setOdAccountVoList(List<IndividualODAccountVo> odAccountVoList) {
//        this.odAccountVoList = odAccountVoList;
//    }
//
//    public List<IndividualODAccountVo> getBeforeODAccountVoList() {
//        return beforeODAccountVoList;
//    }
//
//    public void setBeforeODAccountVoList(List<IndividualODAccountVo> beforeODAccountVoList) {
//        this.beforeODAccountVoList = beforeODAccountVoList;
//    }  

    public InputStream getFileStream() {
        return fileStream;
    }

    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

    public String getExportFileName() {
        return exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }
    
}
