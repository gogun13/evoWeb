/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.RoleAssignmentBusiness;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.UserVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.utilities.ExportUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.ReportExcelObject;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTB_User
 */
public class RoleAssignmentAction extends BaseAction {
    private static final Logger log = Logger.getLogger(RoleAssignmentAction.class);
    private SearchBean searchBean;
    private PaginatedListImpl paginate;
    private final String IS_CONFIG = "Y";
    private List<DropdownVo> roleList;
    private String saveFlag;
    private String show;//none, block
    private String oldRoleId;
    private String oldDeptCode;
    private String rowSizPopUp;
       
    //For Excel
    private String exportFileName;
    private InputStream fileStream;
    
    @Autowired
    private RoleAssignmentBusiness roleAssignmentBusiness;
    
    @Override
    public String success() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("success");
        }        
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }
        roleList = new ArrayList<DropdownVo>();
        roleList = roleAssignmentBusiness.getRoleList(IS_CONFIG);
        //paginate = roleAssignmentBusiness.getUserMtRolePrivilegeList(paginate, searchBean, pageAmt); //Defect ตอนเข้ามาหน้าหา ยังไม่ต้อง search ข้อมูลมาแสดง ให้ผลการค้นหาเป็นว่างๆ 13.30 21/03/2559
                        
        return SUCCESS;        
    }
    
    @Override
    public String search() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("search");
        }        
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }
        roleAssignmentBusiness.updateUserMtRolePrivilegeBySearch();
        paginate = roleAssignmentBusiness.getUserMtRolePrivilegeList(paginate, searchBean, pageAmt);
        setPaginate(paginate);
        return SEARCH;        
    }
    
    public String searchByGet() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("searchByGet");
        }        
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }
        roleAssignmentBusiness.updateUserMtRolePrivilegeBySearch();        
        UserData user = searchBean.getUser();
                        
        if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNo()))){            
            log.info("RoleAssignmentAction searchByGet EmpNo="+searchBean.getUser().getEmpNo()+", cast1="+MS874ToUnicode(searchBean.getUser().getEmpNo())+", cast2="+UnicodeToMS874(searchBean.getUser().getEmpNo()));
            
            log.info("RoleAssignmentAction searchByGet EmpNo="+(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8")));            
            user.setEmpNo(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8"));           
        }
        if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNameThai()))){
            log.info("RoleAssignmentAction searchByGet EmpNameThai="+searchBean.getUser().getEmpNameThai()+", cast1="+MS874ToUnicode(searchBean.getUser().getEmpNameThai())+", cast2="+UnicodeToMS874(searchBean.getUser().getEmpNameThai()));
                        
            log.info("RoleAssignmentAction searchByGet EmpNameThai="+(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8")));
            user.setEmpNameThai(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8"));           
        }
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode()))){
            log.info("RoleAssignmentAction searchByGet DeptCode="+searchBean.getUser().getDeptCode()+", cast1="+MS874ToUnicode(searchBean.getUser().getDeptCode())+", cast2="+UnicodeToMS874(searchBean.getUser().getDeptCode()));
            
            log.info("RoleAssignmentAction searchByGet DeptCode="+(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8")));
            user.setDeptCode(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8"));                
        }
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName()))){
            log.info("RoleAssignmentAction searchByGet DeptName="+searchBean.getUser().getDeptName()+", cast1="+MS874ToUnicode(searchBean.getUser().getDeptName())+", cast2="+UnicodeToMS874(searchBean.getUser().getDeptName()));
                        
            log.info("RoleAssignmentAction searchByGet DeptName="+(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8")));            
            user.setDeptName(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8"));
        }
        searchBean.setUser(user);
        paginate = roleAssignmentBusiness.getUserMtRolePrivilegeList(paginate, searchBean, pageAmt);        
        setPaginate(paginate);
        return SEARCH;        
    }
    
    @Override
    public String save() throws Exception {
        int result = roleAssignmentBusiness.save(searchBean, getCurrentUser());
        log.info("RoleAssignmentAction save result="+result);
        if(result==-2){
            String errorMsg = "พนักงานท่านนี้ "+StringUtil.notNull(searchBean.getById())+" ไม่มีอยู่ในระบบ Telephone Book ไม่สามารถบันทึกข้อมูลได้";
            throw new BusinessException(errorMsg);
        }else if(result==-1){
//            String errorMsg = "พนักงานท่านนี้ "+StringUtil.notNull(searchBean.getById());        
//            errorMsg += "รหัสผู้ใช้งาน:"+searchBean.getUser().getEmpNo();            
//            //errorMsg += "<br>ฝ่ายงาน/หน่วยงาน:"+StringUtil.notNull(searchBean.getUser().getDeptName());
//            //errorMsg += "<br>สิทธิ์การใช้งาน:"+roleAssignmentBusiness.getRoleCodeDesc(IS_CONFIG, searchBean.getRoleId());
//            errorMsg += "<br>มีในระบบแล้ว ไม่สามารถบันทึกข้อมูลได้";
            throw new BusinessException("ผู้ใช้งานมีสิทธิ์การใช้งานนี้อยู่ในระบบแล้ว ไม่สามารถบันทึกข้อมูลได้");
        }
        
        /* หลังจากบันทึกแล้ว ไม่ต้องแสดงรายการใน List ครับบบบ, เปลี่ยนเป็น Disabled ใน txtField แทน         
        setPaginate(null);
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }
        //searchBean.setByFirstName("");
        paginate.setPageSize(rowAmt);
        paginate = roleAssignmentBusiness.getUserMtRolePrivilegeList(paginate, searchBean, pageAmt);
        setSearchBean(null);*/
        setSaveFlag("1");
        return add();
    }
    
    @Override
    public String update() throws Exception {        
        log.info("New RoleId="+StringUtil.notNull(searchBean.getRoleId())+", OldRoleId="+StringUtil.notNull(getOldRoleId()));        
        log.info("New DeptCode="+StringUtil.notNull(searchBean.getUser().getDeptCode())+", OldDeptCode="+StringUtil.notNull(getOldDeptCode()));                                        
        //if(!StringUtil.notNull(searchBean.getRoleId()).equals(StringUtil.notNull(getOldRoleId())) || !StringUtil.notNull(searchBean.getUser().getDeptCode()).equals(StringUtil.notNull(getOldDeptCode()))){
        if(!StringUtil.notNull(searchBean.getRoleId()).equals(StringUtil.notNull(getOldRoleId()))){        
            int row = roleAssignmentBusiness.validateUpdate(StringUtil.notNull(searchBean.getUser().getEmpNo()), StringUtil.notNull(searchBean.getRoleId()), StringUtil.notNull(searchBean.getUser().getDeptCode()));                                
            if(row==1){
                String errorMsg = "พนักงานท่านนี้";
                errorMsg += " รหัสผู้ใช้งาน:"+searchBean.getUser().getEmpNo();                
                //errorMsg += "<br>ฝ่ายงาน/หน่วยงาน:"+StringUtil.notNull(searchBean.getUser().getDeptName());
                //errorMsg += "<br>สิทธิ์การใช้งาน:"+roleAssignmentBusiness.getRoleCodeDesc(IS_CONFIG, searchBean.getRoleId());
                errorMsg += "<br>มีอยู่ในระบบอยู่แล้ว ไม่สามารถบันทึกข้อมูลได้";
                throw new BusinessException(errorMsg);
            }
        }
                                        
        int result = roleAssignmentBusiness.updateUserMtRolePrivilege(searchBean, getCurrentUser(), StringUtil.notNull(getOldRoleId()), StringUtil.notNull(getOldDeptCode()));
        log.info("RoleAssignmentAction save result="+result);        
        //setSearchBean(null);
        //setPaginate(null);
        setSaveFlag("1");
        return edit();
    }
        
    @Override
    public String add() throws Exception{
        roleList = new ArrayList<DropdownVo>();
        roleList = roleAssignmentBusiness.getRoleList(IS_CONFIG);        
        return ADD;
    }
    
    @Override
    public String edit() throws Exception { 
        if (log.isInfoEnabled()) {
            log.info("edit");
        } 
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }
        roleList = new ArrayList<DropdownVo>();
        roleList = roleAssignmentBusiness.getRoleList(IS_CONFIG);
        UserVo userVo = roleAssignmentBusiness.getUserMtRolePrivilegeByFilter(searchBean);
        setValue(userVo);
        setOldRoleId(userVo.getRoleId());
        setOldDeptCode(userVo.getDeptCd());
        return EDIT;
    }
    
    @Override
    public String remove() throws Exception { 
        if (log.isInfoEnabled()) {
            log.info("remove");
        } 
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }        
        int result = roleAssignmentBusiness.deleteUserMtRolePrivilege(searchBean);
        log.info("RoleAssignmentAction remove result="+result);                                
        setSearchBean(null);
        setPaginate(null);
        return success();
    }
    
    public String updateUser() throws Exception{
        UserData userData = getCurrentUser();
        UserVo userVo = new UserVo();
        userVo.setUpdatedBy(userData.getEmpNo());        
        roleAssignmentBusiness.updateUser(userVo);
        return success();
    }        
    
    public String history(){
        if (log.isInfoEnabled()) {
            log.info("history");
        }
        searchBean = new SearchBean();
        searchBean.setUser(new UserData());
        return "history";
    }
    
    public String historyList() throws Exception{
        if (log.isInfoEnabled()) {
            log.info("historylist");
        }                
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }                                
        paginate = roleAssignmentBusiness.getUserMtRolePrivilegeHistoryList(paginate, searchBean, pageAmt);
        return "historylist";
    }
    
    public String historyListByGet() throws Exception{
        if (log.isInfoEnabled()) {
            log.info("historyListByGet");
        }                
        if(searchBean==null){
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }        
        UserData user = searchBean.getUser();
        if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNo()))){
            log.info("RoleAssignmentAction historyListByGet EmpNo="+searchBean.getUser().getEmpNo()+", cast1="+MS874ToUnicode(searchBean.getUser().getEmpNo())+", cast2="+UnicodeToMS874(searchBean.getUser().getEmpNo()));
            
            log.info("RoleAssignmentAction historyListByGet EmpNo="+(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8")));
            user.setEmpNo(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8"));           
        }
        if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNameThai()))){            
            log.info("RoleAssignmentAction historyListByGet EmpNameThai="+searchBean.getUser().getEmpNameThai()+", cast1="+MS874ToUnicode(searchBean.getUser().getEmpNameThai())+", cast2="+UnicodeToMS874(searchBean.getUser().getEmpNameThai()));
            
            log.info("RoleAssignmentAction historyListByGet EmpNameThai="+(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8")));
            user.setEmpNameThai(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8"));           
        }
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode()))){
            log.info("RoleAssignmentAction historyListByGet DeptCode="+searchBean.getUser().getDeptCode()+", cast1="+MS874ToUnicode(searchBean.getUser().getDeptCode())+", cast2="+UnicodeToMS874(searchBean.getUser().getDeptCode()));
            
            log.info("RoleAssignmentAction historyListByGet DeptCode="+(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8")));
            user.setDeptCode(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8"));                
        }
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName()))){
            log.info("RoleAssignmentAction historyListByGet DeptName="+searchBean.getUser().getDeptName()+", cast1="+MS874ToUnicode(searchBean.getUser().getDeptName())+", cast2="+UnicodeToMS874(searchBean.getUser().getDeptName()));
            
            log.info("RoleAssignmentAction historyListByGet DeptName="+(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8")));            
            user.setDeptName(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8"));
        }
        searchBean.setUser(user);        
        paginate = roleAssignmentBusiness.getUserMtRolePrivilegeHistoryList(paginate, searchBean, pageAmt);
        return "historylist";
    }
    
    public String findUser() throws Exception {
        log.info("RoleAssignmentAction findUser");                        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }
        if (searchBean == null) {                
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }
        log.info("ById="+StringUtil.notNull(searchBean.getById()));        
                
        //ตรวจสอบเมื่อมีการกดที่ปุ่ม "ค้นหา" ที่ Modal Dialog, ต้อง set ค่าตามด้านล่างครับ
        UserData user = new UserData();
        String checked = StringUtil.notNull(searchBean.getById());
        if("1".equals(StringUtil.notNull(searchBean.getById()))){               //Radio รหัส                  
            user.setDeptCode("");            
            if(!"".equals(StringUtil.notNull(searchBean.getTextSearch()))){
                user.setEmpNo(searchBean.getTextSearch());                
            }else
                user.setEmpNo("");       
            
            searchBean.setUser(user);
        }else if("2".equals(StringUtil.notNull(searchBean.getById()))){         //Radio คำอธิบาย             
            user.setDeptName("");            
            if(!"".equals(StringUtil.notNull(searchBean.getTextSearch()))){
                user.setEmpNameThai(searchBean.getTextSearch());                
            }else
                user.setEmpNameThai("");
            
            searchBean.setUser(user);
        }else if("0".equals(StringUtil.notNull(searchBean.getById()))){         //Set value To TextBox เมื่อคลิ๊กมาจากหน้าหลัก เพื่อส่งค่าไปที่ Modal Dialog
            log.info("RoleAssignmentAction findUser Main-->Modal");
            if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNo()))){
                log.info("RoleAssignmentAction findUser EmpNo="+(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8")));
                user.setEmpNo(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8"));
                checked = "1";
                searchBean.setTextSearch(new String(searchBean.getUser().getEmpNo().getBytes("ISO-8859-1"), "UTF-8"));
            }else if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNameThai()))){
                log.info("RoleAssignmentAction findUser EmpNameThai="+(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8")));
                user.setEmpNameThai(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8"));
                checked = "2";            
                searchBean.setTextSearch(new String(searchBean.getUser().getEmpNameThai().getBytes("ISO-8859-1"), "UTF-8"));
            }
            searchBean.setById("");//Set For Service
            searchBean.setUser(user);
        }                        
        paginate = roleAssignmentBusiness.getUserTBList(paginate, searchBean, pageAmt);                                       
        searchBean.setById(checked);
        setRowSizPopUp(paginate.getTotalRecordStr());
        return "userPopup";
    }
    
    public String findDept() throws Exception {
        log.info("RoleAssignmentAction findDept");                        
        int rowAmt = 20; // Default
        int pageAmt = 10;// Default
        if (paginate == null) {                
            paginate = createPaginate(rowAmt);
        }
        if (searchBean == null) {                
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }
        log.info("ById="+StringUtil.notNull(searchBean.getById()));        
                
        //ตรวจสอบเมื่อมีการกดที่ปุ่ม "ค้นหา" ที่ Modal Dialog, ต้อง set ค่าตามด้านล่างครับ
        UserData user = new UserData();
        String checked = StringUtil.notNull(searchBean.getById());
        if("1".equals(StringUtil.notNull(searchBean.getById()))){               //Radio รหัส
            user.setEmpNo("");            
            if(!"".equals(StringUtil.notNull(searchBean.getTextSearch()))){
                user.setDeptCode(searchBean.getTextSearch());                
            }else
                user.setDeptCode("");
            
            searchBean.setUser(user);
        }else if("2".equals(StringUtil.notNull(searchBean.getById()))){         //Radio คำอธิบาย
            user.setEmpNameThai("");               
            if(!"".equals(StringUtil.notNull(searchBean.getTextSearch()))){
                user.setDeptName(searchBean.getTextSearch());                
            }else
                user.setDeptName("");
            
            searchBean.setUser(user);
        }else if("0".equals(StringUtil.notNull(searchBean.getById()))){         //Set value To TextBox เมื่อคลิ๊กมาจากหน้าหลัก เพื่อส่งค่าไปที่ Modal Dialog
            log.info("RoleAssignmentAction findDept Main-->Modal");            
            if(!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode()))){
                log.info("RoleAssignmentAction findDept DeptCode="+(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8")));
                user.setDeptCode(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8"));
                checked = "1";
                searchBean.setTextSearch(new String(searchBean.getUser().getDeptCode().getBytes("ISO-8859-1"), "UTF-8"));                                
            }else if(!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName()))){
                log.info("RoleAssignmentAction findDept getDeptName="+(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8")));            
                user.setDeptName(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8"));
                checked = "2";
                searchBean.setTextSearch(new String(searchBean.getUser().getDeptName().getBytes("ISO-8859-1"), "UTF-8"));
            }
            searchBean.setById("");//Set For Service
            searchBean.setUser(user);
        }                                        
        paginate = roleAssignmentBusiness.getDepartmentList(paginate, searchBean, pageAmt);                        
        searchBean.setById(checked);
        setRowSizPopUp(paginate.getTotalRecordStr());
        return "deptPopup";
    }
    
    public void createExcel()throws Exception{
        if (log.isInfoEnabled()) {
            log.info("createExcel Start");
        }
        
        if (searchBean == null) {                
            searchBean = new SearchBean();
            searchBean.setUser(new UserData());
        }
        
        //int rowAmt = 
        //paginate = createPaginate(rowAmt);
                        
        PaginatedListImpl paginateReport = paginate;
        paginateReport.setIndex(1);
        paginateReport.setPageSize(paginate.getTotalRecord());
        paginateReport = roleAssignmentBusiness.getUserMtRolePrivilegeList(paginateReport, searchBean, 0);
        
        List<UserVo> list = null;
            if(paginateReport !=null) 
                list = paginateReport.getList();
            
            if(list ==null) 
                list = new ArrayList();                        
        
        ReportExcelObject excelObject = new ReportExcelObject();
        excelObject.setExportFileName("EWSM_ROLE_PRIVILEGE_REPORT");
        excelObject.setSheetName("ROLE-PRIVILEGE");
        
        //<editor-fold desc="## HEADER ##">                   							
        excelObject.setHeaderList(0, 0, "ลำดับ", 5);
        excelObject.setHeaderList(0, 1, "รหัสผู้ใช้งาน", 15);
        excelObject.setHeaderList(0, 2, "ชื่อผู้ใช้งาน", 30);
        excelObject.setHeaderList(0, 3, "ฝ่ายงาน/หน่วยงาน", 50);            
        excelObject.setHeaderList(0, 4, "สิทธิ์การใช้งาน", 25);
        excelObject.setHeaderList(0, 5, "สถานะ", 15);                        
        excelObject.setHeaderList(0, 6, "วันที่สิ้นสุดการใช้งาน", 20);
        excelObject.setHeaderList(0, 7, "ผู้ทำรายการ", 15);
        excelObject.setHeaderList(0, 8, "วันที่ทำรายการ", 20);
        //</editor-fold>   
                                 
        ArrayList<ReportExcelObject> listSheet = new ArrayList<ReportExcelObject>();
        ArrayList <ReportExcelObject.ItemObject> dataList = new ArrayList();
        ReportExcelObject.ItemObject obj;
        int idx = 1;
        //<editor-fold desc="## DETAIL ##">
        for(UserVo vo:list){
            HashMap map = new HashMap();
            map.put("idx", Integer.toString(idx));
            map.put("EmpNo", vo.getEmpNo());
            map.put("EmpFullName", vo.getEmpFullName());            
            map.put("Dept", ValidatorUtil.isNullOrEmpty(vo.getDeptCd()) ? "" :(vo.getDeptCd()+":"+vo.getDeptName()));             
//            map.put("Dept", ValidatorUtil.isNullOrEmpty(vo.getDeptCd()) ? "" :(vo.getDeptName()));
            //map.put("RoleId", vo.getRoleId());
            map.put("RoleId", vo.getRoleDesc());
            //map.put("IsActive", vo.getIsActive());
            map.put("IsActive", vo.getIsActiveDesc());
            map.put("EndDate", vo.getEndDateStr()); 
            map.put("CreatedBy", vo.getCreatedBy());                            
            map.put("CreatedDate", vo.getCreatedDateStr());            
            obj = new ReportExcelObject.ItemObject();
            obj.setDataExcel(map);
            dataList.add(obj);
            idx++;            
        }        
        //</editor-fold>                
        
        excelObject.setListData(dataList);
        excelObject.getRowValue().add(new String[]{"idx", "EmpNo","EmpFullName","Dept","RoleId","IsActive","EndDate","CreatedBy","CreatedDate"});
           
        listSheet.add(excelObject);
        fileStream = ExportUtil.exportExcel(listSheet);
        exportFileName = "EWSL_ROLE_PRIVILEGE_REPORT.xls";    
        if (log.isInfoEnabled()) {
            log.info("createExcel Finish");
        }        
    }
    
    public String exportExcel()throws Exception{
        if (log.isInfoEnabled()) {
            log.info("exportExcel");
        }                   
        createExcel();
        return "exportExcel";
    } 
    
    private void setValue(UserVo userVo){
        log.info("RoleAssignmentAction setValue Start");           
        UserData userData = new UserData();
        userData.setEmpNo(userVo.getEmpNo());
        userData.setEmpNameThai(userVo.getEmpFullName());
        userData.setDeptCode(userVo.getDeptCd());
        userData.setDeptName(userVo.getDeptName());                    
        this.searchBean.setUser(userData);
        this.searchBean.setStatus(userVo.getIsActive());
        this.searchBean.setRoleId(userVo.getRoleId());
        this.searchBean.setToDate(userVo.getEndDateStr());        
        log.info("RoleAssignmentAction setValue Finish");           
    }    
       
    public static String MS874ToUnicode(String s) {
        if (s == null)
            return "";
        
	StringBuffer stringbuffer = new StringBuffer(s);
	for (int i = 0; i < s.length(); i++) {
            char c = stringbuffer.charAt(i);
            if ('\241' <= c && c <= '\373')
                stringbuffer.setCharAt(i, (char) (c + 3424));
	}
	return stringbuffer.toString();
    }
    
    public static String UnicodeToMS874(String s) {
	if (s == null)
	    return "";

	StringBuffer stringbuffer = new StringBuffer(s);
	    for (int i = 0; i < s.length(); i++) {
		char c = stringbuffer.charAt(i);
		if ('\u0E01' <= c && c <= '\u0E5B')
		 stringbuffer.setCharAt(i, (char) (c - 3424));
	}
	return stringbuffer.toString();
    }
    
    /**
     * @return the searchBean
     */
    public SearchBean getSearchBean() {
        return searchBean;
    }

    /**
     * @param searchBean the searchBean to set
     */
    public void setSearchBean(SearchBean searchBean) {
        this.searchBean = searchBean;
    }
    
    public PaginatedListImpl getPaginate() {
        return paginate;
    }

    public void setPaginate(PaginatedListImpl paginate) {
        this.paginate = paginate;
    }

    /**
     * @return the exportFileName
     */
    public String getExportFileName() {
        return exportFileName;
    }

    /**
     * @param exportFileName the exportFileName to set
     */
    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    /**
     * @return the fileStream
     */
    public InputStream getFileStream() {
        return fileStream;
    }

    /**
     * @param fileStream the fileStream to set
     */
    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

    /**
     * @return the roleList
     */
    public List<DropdownVo> getRoleList() {
        return roleList;
    }

    /**
     * @param roleList the roleList to set
     */
    public void setRoleList(List<DropdownVo> roleList) {
        this.roleList = roleList;
    }

    /**
     * @return the saveFlag
     */
    public String getSaveFlag() {
        return saveFlag;
    }

    /**
     * @param saveFlag the saveFlag to set
     */
    public void setSaveFlag(String saveFlag) {
        this.saveFlag = saveFlag;
    }    

    /**
     * @return the oldRoleId
     */
    public String getOldRoleId() {
        return oldRoleId;
    }

    /**
     * @param oldRoleId the oldRoleId to set
     */
    public void setOldRoleId(String oldRoleId) {
        this.oldRoleId = oldRoleId;
    }

    /**
     * @return the oldDeptCode
     */
    public String getOldDeptCode() {
        return oldDeptCode;
    }

    /**
     * @param oldDeptCode the oldDeptCode to set
     */
    public void setOldDeptCode(String oldDeptCode) {
        this.oldDeptCode = oldDeptCode;
    }

    /**
     * @return the rowSizPopUp
     */
    public String getRowSizPopUp() {
        return rowSizPopUp;
    }

    /**
     * @param rowSizPopUp the rowSizPopUp to set
     */
    public void setRowSizPopUp(String rowSizPopUp) {
        this.rowSizPopUp = rowSizPopUp;
    }

    /**
     * @return the show
     */
    public String getShow() {
        return show;
    }

    /**
     * @param show the show to set
     */
    public void setShow(String show) {
        this.show = show;
    }
  
}
