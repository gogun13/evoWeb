/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AssignSlaBusiness;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Pound
 */
public class AssignSlaAction extends BaseAction {
    private static final Logger logger = Logger.getLogger(AssignSlaAction.class);
    
    private List<DropdownVo> formComboList;
    private WarningTypeVo warningTypeVoCriteria;
    private List<WarningTypeVo> warningTypeList;
    private WarningTypeVo warningTypeVo;
    private String warningTypeCode;
    
    @Autowired
    private AssignSlaBusiness assignSlaBusiness;
    
    @Override
    public String success() throws Exception {
        logger.info("[success][Begin]");
        
        List<WarningTypeVo> voList;
        
        try{
            warningTypeVoCriteria   = new WarningTypeVo();
            voList                  = assignSlaBusiness.findWarningTypeUnderWarningTypeIsNull(new WarningTypeVo());
            formComboList           = new ArrayList<DropdownVo>();
            
            for(WarningTypeVo vo:voList){
                formComboList.add(new DropdownVo(vo.getWarningTypeCode(),vo.getWarningTypeDesc()));
            }
            
            search();
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[success][End]");
        }
                        
        return SUCCESS;        
    }
    
    @Override
    public String search() throws Exception {
        logger.info("[search][Begin]");
        
        try{
            if(warningTypeVoCriteria==null){
                warningTypeVoCriteria = new WarningTypeVo();
            }
            
            warningTypeList = assignSlaBusiness.findWarningTypeUnderWarningTypeIsNull(warningTypeVoCriteria);
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[search][End]");
        }
        
        return SEARCH;        
    }
    
    public String popupDetail() throws Exception {
        logger.info("[popupDetail][Begin]");
        
        try{
            logger.info("[popupDetail] warningTypeCode :: " + warningTypeCode);
            
            warningTypeVo = assignSlaBusiness.getWarningTypeDetail(warningTypeCode);
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[popupDetail][End]");
        }
        
        return "popupDetail";        
    }
    
    public String saveSla() throws Exception {
        logger.info("[saveSla][Begin]");
        
        try{
            logger.info("[saveSla] sla              :: " + warningTypeVo.getSla());
            logger.info("[saveSla] warningTypeCode  :: " + warningTypeVo.getWarningTypeCode());
            
            UserData        userData            = getCurrentUser();
            
            warningTypeVo.setUpdatedBy(userData.getEmpNo());
            warningTypeVo.setCreatedBy(userData.getEmpNo());
            
            assignSlaBusiness.updateSla(warningTypeVo);
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[saveSla][End]");
        }
        
        return SEARCH;        
    }  

    public List<DropdownVo> getFormComboList() {
        return formComboList;
    }

    public void setFormComboList(List<DropdownVo> formComboList) {
        this.formComboList = formComboList;
    }

    public WarningTypeVo getWarningTypeVoCriteria() {
        return warningTypeVoCriteria;
    }

    public void setWarningTypeVoCriteria(WarningTypeVo warningTypeVoCriteria) {
        this.warningTypeVoCriteria = warningTypeVoCriteria;
    }

    public List<WarningTypeVo> getWarningTypeList() {
        return warningTypeList;
    }

    public void setWarningTypeList(List<WarningTypeVo> warningTypeList) {
        this.warningTypeList = warningTypeList;
    }

    public WarningTypeVo getWarningTypeVo() {
        return warningTypeVo;
    }

    public void setWarningTypeVo(WarningTypeVo warningTypeVo) {
        this.warningTypeVo = warningTypeVo;
    }

    public String getWarningTypeCode() {
        return warningTypeCode;
    }

    public void setWarningTypeCode(String warningTypeCode) {
        this.warningTypeCode = warningTypeCode;
    }
  
}
