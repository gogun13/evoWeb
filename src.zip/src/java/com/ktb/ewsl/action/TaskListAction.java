/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.DropdownBusiness;
import com.ktb.ewsl.business.MtConfigBusiness;
import com.ktb.ewsl.business.ParameterBusiness;
import com.ktbcs.core.action.BaseAction;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.business.WarningTypeBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.utilities.ExcelUtils;
import com.ktb.ewsl.vo.CountDataVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.MtFormStatusVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Luksamee
 */
public class TaskListAction extends BaseAction {

    private static final Logger log = Logger.getLogger(TaskListAction.class);
    private final String FW_LATE_PAYMENT_FORM = "latePaymentForm";
    private final String FW_WAY_OUT_FORM = "wayOutForm";
    private final String FW_ACTION1_FROM = "actionForm";//Edit By Pound
    private final String FW_ACTION2_FROM = "action2Form";//Edit By Pound
    private final String FW_QUALI = "nextQuali";
    private final String FW_CREDIT_RATING = "creditRating";
    private final String FW_FIN = "nextFinance";
    private final String FW_CREDIT_REVIEW = "creditReview";
    private final String FW_TODAY_MOVEMENT = "todayMovement";
    private SearchBean searchBean;
    private PaginatedListImpl paginate;
    private String nextCifNo;
    private int nextWarningHeaderId;
    private String nextCurrentHeaderStatus;
    private List<DropdownVo> conditionSearchList;
    private List<DropdownVo> organizationTypeList;
    private boolean crflagFillter;
    private boolean taflagFillter;
    /*----- IR = Individual Report ----*/
    private int nextIRWarningHeaderId; //
    private String nextIRCifNo;
    private String exportFileName;
    private InputStream fileStream;
    private String actionStatus;
    private String pageName;
    private String forBackPage;
    /*----- Size L ----*/
    private ArrayList<WarningTypeVo> monitoringFormList;
    private ArrayList<WarningTypeVo> assessmentList;
    private ArrayList<WarningTypeVo> reviewList;
    private String roleId;
    private String nextCurrentFormFlg;
    private String nextCurrentWarningTypeCode;
//    private String nextCurrentWayOutFlg;//Add By Pound
    private int nextWarningInfoId;

    private String cif;
    private String warningHeaderId;
    
    private String displayColumnCoOp = BusinessConst.Flag.Y;


    private HashMap MT_FORM_STATUS_MAP;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private ParameterBusiness parameterBusiness;
    @Autowired
    private DropdownBusiness dropdownBusiness;
    @Autowired
    private WarningTypeBusiness warningTypeBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private CustomerBusiness customerBusiness;
    @Autowired
    private MtConfigBusiness mtConfigBusiness;

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(String warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }
	

    public String getActionStatus() {
        return actionStatus;
    }

    public void setActionStatus(String actionStatus) {
        this.actionStatus = actionStatus;
    }

    public SearchBean getSearchBean() {
        return searchBean;
    }

    public void setSearchBean(SearchBean searchBean) {
        this.searchBean = searchBean;
    }

    public PaginatedListImpl getPaginate() {
        return paginate;
    }

    public void setPaginate(PaginatedListImpl paginate) {
        this.paginate = paginate;
    }

    public String getNextCifNo() {
        return nextCifNo;
    }

    public void setNextCifNo(String nextCifNo) {
        this.nextCifNo = nextCifNo;
    }

    public int getNextWarningHeaderId() {
        return nextWarningHeaderId;
    }

    public void setNextWarningHeaderId(int nextWarningHeaderId) {
        this.nextWarningHeaderId = nextWarningHeaderId;
    }

    public List<DropdownVo> getConditionSearchList() {
        return conditionSearchList;
    }

    public void setConditionSearchList(List<DropdownVo> conditionSearchList) {
        this.conditionSearchList = conditionSearchList;
    }

    public boolean isCrflagFillter() {
        return crflagFillter;
    }

    public void setCrflagFillter(boolean crflagFillter) {
        this.crflagFillter = crflagFillter;
    }

    public boolean isTaflagFillter() {
        return taflagFillter;
    }

    public void setTaflagFillter(boolean taflagFillter) {
        this.taflagFillter = taflagFillter;
    }

    public List<DropdownVo> getOrganizationTypeList() {
        return organizationTypeList;
    }

    public void setOrganizationTypeList(ArrayList<DropdownVo> organizationTypeList) {
        this.organizationTypeList = organizationTypeList;
    }

    public String getExportFileName() {
        return exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    public InputStream getFileStream() {
        return fileStream;
    }

    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

    public int getNextIRWarningHeaderId() {
        return nextIRWarningHeaderId;
    }

    public void setNextIRWarningHeaderId(int nextIRWarningHeaderId) {
        this.nextIRWarningHeaderId = nextIRWarningHeaderId;
    }

    public String getNextIRCifNo() {
        return nextIRCifNo;
    }

    public void setNextIRCifNo(String nextIRCifNo) {
        this.nextIRCifNo = nextIRCifNo;
    }

    public String getNextCurrentHeaderStatus() {
        return nextCurrentHeaderStatus;
    }

    public void setNextCurrentHeaderStatus(String nextCurrentHeaderStatus) {
        this.nextCurrentHeaderStatus = nextCurrentHeaderStatus;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    public String getNextCurrentWarningTypeCode() {
        return nextCurrentWarningTypeCode;
    }

    public void setNextCurrentWarningTypeCode(String nextCurrentWarningTypeCode) {
        this.nextCurrentWarningTypeCode = nextCurrentWarningTypeCode;
    }

    public String getNextCurrentFormFlg() {
        return nextCurrentFormFlg;
    }

    public void setNextCurrentFormFlg(String nextCurrentFormFlg) {
        this.nextCurrentFormFlg = nextCurrentFormFlg;
    }

    //------------------------- Biz ------------------------------//
    @Override
    public String success() throws Exception {
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. TaskListAction.success");
            }

            if (searchBean == null) {
                searchBean = new SearchBean();
            }

            if (request.getSession(false) != null) {
                request.getSession(false).removeAttribute(BusinessConst.Session.TITLE_KEY);
                request.getSession(false).removeAttribute(BusinessConst.Session.WARNING_TYPE_SESSION_KEY);
                request.getSession(false).removeAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
            }
            if (conditionSearchList == null || conditionSearchList.isEmpty()) {
                conditionSearchList = getDropdownSearchList(getCurrentUser().getRoleId());
            }
            if (organizationTypeList == null || organizationTypeList.isEmpty()) {
                organizationTypeList = getDropdownOrganizeType();
            }

            search();
            
        } catch (Exception ex) {
            throw ex;
        }
        setActionStatus("success");
        return SUCCESS;
    }

    public String search() throws Exception {
        int rowAmt = 10;// Default
        int pageAmt = 10;// Default
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. TaskListAction.search");
                log.debug(" getPageIndex : " + getPageIndex());
            }
            if (getCurrentUser() != null && (!ValidatorUtil.isNullOrEmpty(getCurrentUser().getRoleId()))) {
                setMonitoringFormList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.MONITOR));
                setAssessmentList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.ASSES));
                setReviewList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.REVIEW));
            }
            
            setRoleId(getCurrentUser().getRoleId());

            if (request.getSession(false).getAttribute(BusinessConst.Session.WARNING_TYPE_SESSION_KEY) != null) {
                request.getSession(false).removeAttribute(BusinessConst.Session.WARNING_TYPE_SESSION_KEY);
            }
            if (paginate == null) {
                rowAmt = parameterBusiness.numRowDataGrid();
                pageAmt = parameterBusiness.numPageDisplayOnDataGrid();
                paginate = createPaginate(rowAmt);
            }
            if (searchBean != null) {
                if (paginate != null) {
                    log.debug("paginate.getIndex() = " + paginate.getIndex());
                    String pageIndexSearch = String.valueOf(paginate.getIndex());
                    setPageIndex(pageIndexSearch);
                    searchBean.setSearchPageIndex(pageIndexSearch);
                }
                request.getSession(false).setAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT, searchBean);
            }
            paginate = warningHeaderBusiness.getPipeline(paginate, searchBean, getCurrentUser(), pageAmt);

            //--DISPLAY Column CO_OP
            Integer amtCoOp = warningHeaderBusiness.countPipelineHaveCoOp(searchBean, getCurrentUser());
            if(amtCoOp == null || amtCoOp == 0){
               setDisplayColumnCoOp(BusinessConst.Flag.N);
            }else{
               setDisplayColumnCoOp(BusinessConst.Flag.Y);
            }
        } catch (Exception ex) {
            throw ex;
        }
        setActionStatus("search");
        return SEARCH;
    }

    public String goCustomerGroupView() throws Exception {
        setForBackPage(BusinessConst.PAGE.PIPELINE);
        return "nextCustomerGroupView";
    }

    public String gotoFormQuestion() throws Exception {
        String forward = SUCCESS;
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. TaskListAction.gotoFormQuestion");
            }
            if (!ValidatorUtil.isNullOrEmpty(getNextCifNo())) {
                int cifInt = Integer.parseInt(getNextCifNo());
                CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
                if (custVo != null) {
                    //------- Title bar -----------//
                    TitleVo titleVo = new TitleVo();
                    titleVo.setCifNo(getNextCifNo());
                    titleVo.setCustName(custVo.getCustName());
                    titleVo.setWarningHeaderId(getNextWarningHeaderId());
                    titleVo.setStatus(getNextCurrentHeaderStatus());
                    request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
                }
            }
            if (getNextWarningHeaderId() > 0 && !ValidatorUtil.isNullOrEmpty(getNextCurrentWarningTypeCode())) {
                WarningInfoVo warningInfoVo =  warningInfoBusiness.findWarningInfoObjectByMaxWarningInfo(getNextWarningHeaderId(), getNextCurrentWarningTypeCode());//warningInfoBusiness.findWarningInfoObject(getNextWarningHeaderId(), getNextCurrentWarningTypeCode());
                if (warningInfoVo != null) {
                    setNextWarningInfoId(warningInfoVo.getWarningId());
                    setNextCurrentFormFlg(warningInfoVo.getStatus()); //--INFO FLAG
                }
            }

            if (BusinessConst.WarningTypeCode.LATE_PAY.equals(getNextCurrentWarningTypeCode())) {
                setForBackPage(BusinessConst.PAGE.PIPELINE);
                forward = FW_LATE_PAYMENT_FORM;
            } 
            else if (BusinessConst.WarningTypeCode.ACTION1.equals(getNextCurrentWarningTypeCode())) {
                setForBackPage(BusinessConst.PAGE.PIPELINE);
                forward = FW_ACTION1_FROM;
            }else if (BusinessConst.WarningTypeCode.ACTION2.equals(getNextCurrentWarningTypeCode())) {
                setForBackPage(BusinessConst.PAGE.PIPELINE);
                forward = FW_ACTION2_FROM;
            } else if (BusinessConst.WarningTypeCode.EWSQ.equals(getNextCurrentWarningTypeCode())) {
                setForBackPage(BusinessConst.PAGE.PIPELINE);
                forward = FW_QUALI;
            } else if (BusinessConst.WarningTypeCode.CREDIT_RATING.equals(getNextCurrentWarningTypeCode())) {
                forward = FW_CREDIT_RATING;
                setForBackPage(BusinessConst.PAGE.PIPELINE);
            } else if (BusinessConst.WarningTypeCode.FIN.equals(getNextCurrentWarningTypeCode())) {
                setForBackPage(BusinessConst.PAGE.PIPELINE);
                forward = FW_FIN;
            } else if (BusinessConst.WarningTypeCode.CR.equals(getNextCurrentWarningTypeCode())) {
                setForBackPage(BusinessConst.PAGE.PIPELINE);
                forward = FW_CREDIT_REVIEW;
            }

        } catch (Exception ex) {
            throw ex;
        }
        return forward;
    }
    
    public String gotoTodayMovement() throws Exception {
        
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. TaskListAction.gotoTodayMovement");
                log.debug(" getNextCifNo >>" + getNextCifNo());
            }

        } catch (Exception ex) {
            throw ex;
        }
        return FW_TODAY_MOVEMENT;
    }

    public ArrayList getDropdownSearchList(String role) throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("CIF", "CIF No."));
        result.add(setDataToDropDrown("NAME", "ชื่อลูกค้า"));
        if (BusinessConst.UserRole.BCM.equals(role)) {
            result.add(setDataToDropDrown("RM_ID", "รหัสพนักงาน"));
            result.add(setDataToDropDrown("RM_NAME", "ชื่อพนักงาน"));
        } else if (EWSConstantValue.ROLE_SEARCH_MORE.contains(role)) {
            result.add(setDataToDropDrown("RM_ID", "รหัสพนักงาน"));
            result.add(setDataToDropDrown("RM_NAME", "ชื่อพนักงาน"));
            result.add(setDataToDropDrown("COSTCENTER", "รหัสหน่วยงาน"));
            result.add(setDataToDropDrown("COSTCENTER_NAME", "ชื่อหน่วยงาน"));
            
            if (BusinessConst.UserRole.RISK_EDITOR.equals(role) || BusinessConst.UserRole.VIEWER.equals(role) 
                    || BusinessConst.UserRole.VIWER_1.equals(role) || BusinessConst.UserRole.ADMIN.equals(role) 
                    || BusinessConst.UserRole.RISK_VIEWER.equals(role) || BusinessConst.UserRole.AMD.equals(role)) {
                result.add(setDataToDropDrown("CO_RM_ID", "รหัสพนักงาน CO RM"));
                result.add(setDataToDropDrown("CO_OP_ID", "รหัสหน่วยงาน CO OP"));
            }
            
            if (BusinessConst.UserRole.VIWER_1.equals(role) || BusinessConst.UserRole.RISK_EDITOR.equals(role) 
                    || BusinessConst.UserRole.ADMIN.equals(role) || BusinessConst.UserRole.RISK_VIEWER.equals(role)
                    || BusinessConst.UserRole.AMD.equals(role)) {
                result.add(setDataToDropDrown("L", "สายงาน BC-L"));
//                result.add(setDataToDropDrown("CBC1", "สายงาน CBC 1"));
//                result.add(setDataToDropDrown("CBC2", "สายงาน CBC 2"));
//                result.add(setDataToDropDrown("CBC1_CBC2", "สายงาน CBC 1 & CBC 2"));
//                result.add(setDataToDropDrown("L_CBC1_CBC2", "ทั้งหมด (BC-L & CBC 1 & CBC 2)"));
            }
            
            
        }
        //[EWS-L : R10 Develop] ระบบ EWS-L ปรับปรุงสิทธิ์การใช้งานให้ยกเลิก Role “VW3”, “VW4”, “VW5” ออกจากระบบ
//        else if (BusinessConst.UserRole.VIWER_5.equals(role)) {
//            result.add(setDataToDropDrown("RM_ID", "รหัสพนักงาน"));
//            result.add(setDataToDropDrown("RM_NAME", "ชื่อพนักงาน"));
//            result.add(setDataToDropDrown("COSTCENTER", "รหัสหน่วยงาน"));
//            result.add(setDataToDropDrown("COSTCENTER_NAME", "ชื่อหน่วยงาน"));
//            result.add(setDataToDropDrown("CBC1", "สายงาน CBC 1"));
//            result.add(setDataToDropDrown("CBC2", "สายงาน CBC 2"));
//            result.add(setDataToDropDrown("CBC1_CBC2", "สายงาน CBC 1 & CBC 2"));
//            
//        }
        return result;
    }

    public List getDropdownOrganizeType() throws Exception {
    	List<DropdownVo> organizationList = dropdownBusiness.getOrganizationGroupAndEwsUse("108018");
        return organizationList;
    }

    private DropdownVo setDataToDropDrown(String key, String value) {
        DropdownVo ddVo = new DropdownVo();
        ddVo.setId(key);
        ddVo.setDesc(value);
        return ddVo;
    }

//    public String exportExcel() throws Exception {
//        log.debug("[exportExcel][Begin]");
//        
//        String ROLE_RM = "RM";
//        String ROLE_AE = "AE";
//        String ROLE_AO = "AO";
//        String ROLE_AD = "AD";
//        String ROLE_BCM = "BCM";
//        String ROLE_VW1 = "VW1";
//        String ROLE_RE = "RE";
//        String ROLE_CO_RM = "CO_RM";
//        String ROLE_CO_AE = "CO_AE";
//        String ROLE_CO_BCM = "CO_BCM";
//        boolean hvRM = false;
//        boolean hvAe = false;
//        boolean hvAo = false;
//        boolean hvRepUnit = false;
//        boolean hvCoRM = false;
//        boolean hvCoAe = false;
//        boolean hvCoRepUnit = false;
//        ArrayList custInfoList;
//        ArrayList coCustInfoList;
//        ArrayList monitoryList;
//        ArrayList assesList;
//        ArrayList reviewRowList;
//        ArrayList rowList;
//        ArrayList colList;
//        ArrayList dpdMonitorList;
//        ArrayList odMonitorList;
//        ArrayList spListHeader;
//        ArrayList sumRowList = new ArrayList();
//        ArrayList sumRowREList = new ArrayList();
//        ParameterVo parameterVo     = null;
//        String      templateName    = null;
//
//        try {
//            if (getCurrentUser() != null && (!ValidatorUtil.isNullOrEmpty(getCurrentUser().getRoleId()))) {
//                setMonitoringFormList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.MONITOR));
//                setAssessmentList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.ASSES));
//                setReviewList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.REVIEW));
//            }
//
//            setRoleId(getCurrentUser().getRoleId());
//            searchBean = (SearchBean) request.getSession(false).getAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
//            paginate = createPaginate(0);
//            paginate.setIndex(-99);
//            paginate = warningHeaderBusiness.getPipeline(paginate, searchBean, getCurrentUser(), 0);
//
//             //--DISPLAY Column CO_OP
//            boolean fullFile = true;
//            Integer amtCoOp = warningHeaderBusiness.countPipelineHaveCoOp(searchBean, getCurrentUser());
//            if(amtCoOp == null || amtCoOp == 0){
//               fullFile = false;
//            }
//
//            custInfoList = new ArrayList();
//            coCustInfoList = new ArrayList();
//            monitoryList = new ArrayList();
//            assesList = new ArrayList();
//            reviewRowList = new ArrayList();
//            dpdMonitorList = new ArrayList();
//            odMonitorList = new ArrayList();
//
//            
//            // column head for show in excel
//            if (!ROLE_RM.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("RM ID");
//                hvRM = true;
//            }
//            if (!ROLE_AE.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("AE ID");
//                hvAe = true;
//            }
//            if (!ROLE_AO.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("AO ID");
//                hvAo = true;
//            }
//            if (!ROLE_RM.equals(getCurrentUser().getRoleId()) && !ROLE_AE.equals(getCurrentUser().getRoleId()) && !ROLE_AO.equals(getCurrentUser().getRoleId()) && !ROLE_BCM.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("Response Unit ");
//                hvRepUnit = true;
//            }
//          if(fullFile){  
//            //[Start] co response owner
//            if (!ROLE_CO_RM.equals(getCurrentUser().getRoleId())) {
//                coCustInfoList.add("CO RM ID");
//                hvCoRM = true;
//            }
//            if (!ROLE_CO_AE.equals(getCurrentUser().getRoleId())) {
//                coCustInfoList.add("CO AE ID");
//                hvCoAe = true;
//            }
//            if (!ROLE_CO_RM.equals(getCurrentUser().getRoleId()) && !ROLE_CO_AE.equals(getCurrentUser().getRoleId()) && !ROLE_CO_BCM.equals(getCurrentUser().getRoleId())) {
//                coCustInfoList.add("CO Response Unit ");
//                hvCoRepUnit = true;
//            }
//            //[End] co response owner
//          }   
//            dpdMonitorList.add("DPDs");
//            dpdMonitorList.add("#A/Cs");
//            dpdMonitorList.add("Unpaid Amount(บาท)");
//            odMonitorList.add("OD Over-Limit");
//            odMonitorList.add("#A/Cs");
//            odMonitorList.add("ยอดหนี้ที่เกินวงเงิน(บาท)");
//
//            ArrayList spAcctHeaderList = new ArrayList();
//            spAcctHeaderList.add("#A/Cs");
//
//            // column head for show in excel
//            if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
//                for (WarningTypeVo vo : getMonitoringFormList()) {
//                    monitoryList.add(vo.getShortName());
//                }
//            }
//
//            // column head for show in excel
//            if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
//                for (WarningTypeVo vo : getAssessmentList()) {
//                    assesList.add(vo.getShortName());
//                }
//            }
//            // column head for show in excel
//            if (getReviewList() != null && !getReviewList().isEmpty()) {
//                for (WarningTypeVo vo : getReviewList()) {
//                    reviewRowList.add(vo.getShortName());
//                }
//            }
//            reviewRowList.add("Maturity Date");
//            reviewRowList.add("#A/Cs");
//            reviewRowList.add("Warnings");
//
//            rowList = new ArrayList();
//            WarningHeaderVo headVo;
//            TaskListExportVo expVo;
//            int cntCol = 4;
//            for (int i = 0; i < paginate.getList().size(); i++) { // create row and column data for show excel
//                colList = new ArrayList();
//                expVo = new TaskListExportVo();
//
//                headVo = (WarningHeaderVo) paginate.getList().get(i);
//                expVo.setWarningDate(headVo.getWarningDateStr());
//                expVo.setCif(headVo.getCif());
//                expVo.setCustName(headVo.getCustomerVo().getCustName());
//                
//                if (ROLE_VW1.equals(getCurrentUser().getRoleId()) || ROLE_RE.equals(getCurrentUser().getRoleId()) || ROLE_AD.equals(getCurrentUser().getRoleId())) {
//                    expVo.setBusinessSize(headVo.getCustomerVo().getBusinessSize());
//                    cntCol++;
//                }
//
//                if (hvRM) {
//                    expVo.setRmId(headVo.getCustomerVo().getRmId());
//                    expVo.setHasRmId(1);
//                    cntCol++;
//                }
//                if (hvAe) {
//                    expVo.setAeId(headVo.getCustomerVo().getAeId());
//                    expVo.setHasAeId(1);
//                    cntCol++;
//                }
//                if (hvAo) {
//                    expVo.setAoId(headVo.getCustomerVo().getAoId());
//                    expVo.setHasAoId(1);
//                    cntCol++;
//                }
//                if (hvRepUnit) {
//                    expVo.setRespUnit(headVo.getCustomerVo().getResponseUnit());
//                    expVo.setHasRespUnit(1);
//                    cntCol++;
//                }
//              if(fullFile){  
//                if (hvCoRM) {
//                    expVo.setCoRmId(headVo.getCustomerVo().getCoRmId());
//                    expVo.setHasCoRmId(1);
//                    cntCol++;
//                }
//                if (hvCoAe) {
//                    expVo.setCoAeId(headVo.getCustomerVo().getCoAeId());
//                    expVo.setHasCoAeId(1);
//                    cntCol++;
//                }
//                if (hvCoRepUnit) {
//                    expVo.setCoRespUnit(headVo.getCustomerVo().getCoResponseUnit());
//                    expVo.setHasCoRespUnit(1);
//                    cntCol++;
//                }
//               }
//                expVo.setEwsRisk(headVo.getEwsRiskLevel());
//                expVo.setcFinal(headVo.getcFinal());
//                expVo.setMoniDpd(headVo.getDpdStrFormat());
//                expVo.setHasMoniDpd(1);
//                expVo.setMoniAcct(headVo.getDpdAcctCntStr());
//                expVo.setHasMoniAcct(1);
//
//                if (headVo.getUnpaidAmt() != null) {
//                    expVo.setMoniUnpaidAmt(headVo.getUnpaidAmt() + "");
//                } else {
//                    expVo.setMoniUnpaidAmt("");
//                }
//                expVo.setHasMoniUnpaidAmt(1);
//                expVo.setSpAcct(headVo.getSpAccount());
////                expVo.setOdOverLimit(headVo.getOdOverLimitStr());
////                expVo.setHasOdOverLimit(1);
////                expVo.setOdAcct("");
////                expVo.setHasOdAcct(1);
////                if (headVo.getOdOverAmt() != null) {
////                    expVo.setOdOverBalance(headVo.getOdOverAmt().toString());
////                } else {
////                    expVo.setOdOverBalance("");
////                }
////                expVo.setHasOdBalance(1);
////                cntCol = cntCol + 9;
//                cntCol = cntCol + 6;
//
//                if (i == 0) {
//                    for (int idx = 0; idx < cntCol; idx++) { // create empty cell for total row
//                        if (idx == cntCol - 1) {
//                            sumRowList.add("รวม");
//                        } else {
//                            sumRowList.add("");
//                        }
//                    }
//                }
//
//                if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
//                    for (WarningTypeVo vo : getMonitoringFormList()) {
//                        if ("LATE_PAY".equals(vo.getWarningTypeCode())) {
//                            expVo.setLatePayForm(convertFlgShowExcel(headVo.getLatePayFlg(), headVo.getStatus()));
//                            expVo.setHasLatePayForm(1);
//                            if (i == 0) {
//                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getLatePayFlgCountStr());
//                            }
//                        }
//                        if ("ACTION1".equals(vo.getWarningTypeCode())) {
//                            expVo.setAction1Form(convertFlgShowExcel(headVo.getAction1Flg(), headVo.getStatus()));
//                            expVo.setHasAction1Form(1);
//                            if (i == 0) {
//                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getAction1FlgCountStr());
//                            }
//                        }
//                        if ("ACTION2".equals(vo.getWarningTypeCode())) {
//                            expVo.setAction2Form(convertFlgShowExcel(headVo.getAction2Flg(), headVo.getStatus()));
//                            expVo.setHasAction2Form(1);
//                            if (i == 0) {
//                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getAction2FlgCountStr());
//                            }
//                        }
//                    }
//                }
//
//                if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
//                    for (WarningTypeVo vo : getAssessmentList()) {
//                        if ("EWSQ".equals(vo.getWarningTypeCode())) {
//                            expVo.setQuali(convertFlgShowExcel(headVo.getQualiFlg(), headVo.getStatus()));
//                            expVo.setHasQuali(1);
//                            if (i == 0) {
//                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getQualiFlgCountStr());
//                            }
//                        }
//                        if ("CREDIT_RATING".equals(vo.getWarningTypeCode())) {
//                            expVo.setCreditRating(convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus()));
//                            expVo.setHasCreditRating(1);
//                            if (i == 0) {
//                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr());
//                            }
//                        }
//                        if ("FIN".equals(vo.getWarningTypeCode())) {
//                            expVo.setFin(convertFlgShowExcel(headVo.getFinFlg(), headVo.getStatus()));
//                            expVo.setHasFin(1);
//                            if (i == 0) {
//                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getFinFlgCountStr());
//                            }
//                        }
//                    }
//                }
//               expVo.setTypesFlg(headVo.getTypesFlg());
//               expVo.setCr(convertFlgShowExcel(headVo.getCrFlg(), headVo.getStatus()));
//               //expVo.setCrAmount(cntCol);
//               sumRowList.add("");
//               sumRowList.add(((CountDataVo) paginate.getCountObjData()).getCrFlgCountStr());
//               expVo.setCrrm(convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus()));
//               //expVo.setCrrmAmount(cntCol);
//               sumRowList.add("");
//               sumRowList.add(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr());
////                if (getReviewList() != null && !getReviewList().isEmpty()) {
////                    for (WarningTypeVo vo : getReviewList()) {
////                        if ("CR".equals(vo.getWarningTypeCode())) {
////                            expVo.setCreditReview(convertFlgShowExcel(headVo.getCrFlg(), headVo.getStatus()));
////                            expVo.setHasCreditReview(1);
////                            if (i == 0) {
////                                sumRowList.add(((CountDataVo) paginate.getCountObjData()).getCrFlgCountStr());
////                            }
////                        }
////                    }
////                }
//
////                expVo.setMaturityDate(headVo.getMaturityDateStr());
////                expVo.setHasMaturityDate(1);
////                expVo.setTaAcct("");
////                expVo.setHasTaAcct(1);
////                expVo.setTaWaringDate("");
////                expVo.setHasTaWarningDate(1);
//                //colList.add("");
//                // colList.add("");
//                rowList.add(expVo);
//
//
//            }
//            //rowList.add(sumRowList);
//
//            Map beans = new HashMap();
//
//            beans.put("custInfoList", custInfoList);
//            beans.put("coCustInfoList", coCustInfoList);
//            beans.put("coCustInfoListSize", coCustInfoList.size());
//            beans.put("monitorList", monitoryList);
//            beans.put("assesLit", assesList);
//            
////            beans.put("reviewList", reviewRowList);
//            beans.put("reviewList", new ArrayList());
//            
//            beans.put("custHeader", putExcelHeader(custInfoList, "Account Owner"));
//            beans.put("custCnt", custInfoList.size() - 1);
//
//            beans.put("coCustHeader", putExcelHeader(coCustInfoList, "CO Response Owner"));
//            beans.put("coCustCnt", coCustInfoList.size() - 1);
//            
//            beans.put("montorHeader", putExcelHeader(monitoryList, "Turnaround"));
//            beans.put("monitorCnt", monitoryList.size() - 1);
//
//            beans.put("assesHeader", putExcelHeader(assesList, "Assessment Updated"));
//            beans.put("assesCnt", assesList.size() - 1);
//
//            beans.put("dpdMonitorList", dpdMonitorList);
//            beans.put("dpdMonitorHeader", putExcelHeader(dpdMonitorList, "Daily DPD Monitoring"));
//            beans.put("dpdMcnt", dpdMonitorList.size() - 1);
//
////            beans.put("odMonitorList", odMonitorList);
////            beans.put("odMonitorHeader", putExcelHeader(odMonitorList, "Daily OD Monitoring"));
////            beans.put("odMcnt", odMonitorList.size() - 1);
//            beans.put("odMonitorList", new ArrayList());
//            beans.put("odMonitorHeader", putExcelHeader(new ArrayList(), ""));
//            beans.put("odMcnt", 0);
//
////            beans.put("reviewHeader", putExcelHeader(reviewRowList, "การต่ออายุ/ทบทวนสินเชื่อ"));
////            beans.put("reviewCnt", reviewRowList.size() - 1);
//            beans.put("reviewHeader", putExcelHeader(new ArrayList(), ""));
//            beans.put("reviewCnt", 0);
//
//            beans.put("spAcctHeaderList", spAcctHeaderList);
//            ArrayList spAcctHeader = new ArrayList();
//            spAcctHeader.add("SP");
//            beans.put("spAcctHeader", spAcctHeader);
//
//            if (getCurrentUser().getDeptCode() != null && !"".equals(getCurrentUser().getDeptCode())) {
//                beans.put("respDesc", getCurrentUser().getDeptCode() + " - " + getCurrentUser().getDeptName());
//            } else {
//                beans.put("respDesc", getCurrentUser().getDeptCode());
//            }
//            beans.put("userName", getCurrentUser().getEmpNo() + " - " + getCurrentUser().getFullName());
//            beans.put("roleDesc", getCurrentUser().getRoleId());
//
//            beans.put("sumRowList", sumRowList);
//            beans.put("rowList", rowList);
//            beans.put("listSize", rowList.size() - 1);
//            
//            int hasBusinessSize;
//            if (ROLE_VW1.equals(getCurrentUser().getRoleId()) || ROLE_RE.equals(getCurrentUser().getRoleId()) || ROLE_AD.equals(getCurrentUser().getRoleId())) {
//                hasBusinessSize = 1;
//            }else{
//                hasBusinessSize = 0;
//            }
//            
//            beans.put("hasBusinessSize", hasBusinessSize);
//
////            beans.put("remark", mtConfigBusiness.getMtFormDetail());
//            beans.put("remark", mtConfigBusiness.getStatusNameAndSeq());
//            
//            /*Begin หา template ที่ต้องใช้*/
//            parameterVo = parameterBusiness.findByParamIdAndParamType(getCurrentUser().getRoleId(), "PIPELINE_FILE_TEMPLATE");
//            if(parameterVo!=null){
//                beans.put("latePayFlgCountStr", ((CountDataVo) paginate.getCountObjData()).getLatePayFlgCountStr());
//                beans.put("action1FlgCountStr", ((CountDataVo) paginate.getCountObjData()).getAction1FlgCountStr());
//                beans.put("action2FlgCountStr", ((CountDataVo) paginate.getCountObjData()).getAction2FlgCountStr());
//                beans.put("qualiFlgCountStr", ((CountDataVo) paginate.getCountObjData()).getQualiFlgCountStr());
//                beans.put("creditRatingFlgCountStr", ((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr());
//                beans.put("finFlgCountStr", ((CountDataVo) paginate.getCountObjData()).getFinFlgCountStr());
//                beans.put("crFlgCountStr", ((CountDataVo) paginate.getCountObjData()).getCrFlgCountStr());
//                templateName = parameterVo.getValue3();
//                
//                if(ROLE_RE.equals(getCurrentUser().getRoleId())){
//                    int totalCouRe = hasBusinessSize==1?15:14;
//                    for(int i=1;i<=totalCouRe;i++){
//                        if(i==totalCouRe){
//                            sumRowREList.add("รวม");
//                        }else{
//                            sumRowREList.add("");
//                        }
//                    }
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getLatePayFlgCountStr());
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getAction1FlgCountStr());
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getAction2FlgCountStr());
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getQualiFlgCountStr());
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getFinFlgCountStr());
//                    sumRowREList.add("");
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getCrFlgCountStr());
//                    sumRowREList.add("");
//                    sumRowREList.add(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr());
//                    
//                    beans.put("sumRowREList", sumRowREList);
//                }
//                
//            }else{
//                templateName = "taskListReportTemplete";
//            }
//            /*End หา template ที่ต้องใช้*/
//            
//
//            StringBuilder fileName = new StringBuilder("taskListReport");
//            SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm", Locale.US);
//            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
//            Calendar cal = Calendar.getInstance();
//
//            beans.put("reportDate", convertDateThai(format1.format(cal.getTime()).toString()));
//
//            fileName.append(format.format(cal.getTime()).toString()).append(".xls");
//
//            XLSTransformer transformer = new XLSTransformer();
//            String path = getServletContext().getRealPath("/");
//           // System.out.println("path>>" + path);
//            File file = new File(path + "report/" + templateName + ".xls");
//            InputStream inputStream = new FileInputStream(file);
//            HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);
//            
//            response.setHeader("Set-Cookie", "fileDownload=true; path=/");
//
//            ByteArrayOutputStream bos = new ByteArrayOutputStream();
//            workbook.write(bos);
//
//            bos.close();
//            byte[] bytes = bos.toByteArray();
//            setExportFileName(fileName.toString());
//            fileStream = new ByteArrayInputStream(bytes);
//
//
//        } catch (Exception ex) {
//            response.setHeader("Set-Cookie", "fileDownload=false; path=/");
//            ex.printStackTrace();
//            throw ex;
//        }finally{
//            log.debug("[exportExcel][End]");
//        }
//        return "exportExcel";
//    }
    
//    public String exportExcel() throws Exception {
//        log.debug("[exportExcel][Begin]");
//        
//        ExcelUtils          excelUtils		= new ExcelUtils();
//        XSSFWorkbook        workbook 		= excelUtils.getWorkbook();
//        XSSFSheet           worksheet 		= workbook.createSheet("Pipe Line");
//        XSSFCell            cell 		= null;
//        int                 rows        	= 0;
//        int                 cols        	= 0;
//        StringBuilder       fileName            = new StringBuilder("taskListReport");
//        SimpleDateFormat    format              = new SimpleDateFormat("yyyyMMddHHmm", Locale.US);
//        Calendar            cal                 = Calendar.getInstance();
//        SimpleDateFormat    format1             = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
//        String              respDesc            = "";
//        ArrayList<String>   custInfoList        = new ArrayList<String>();
//        ArrayList<String>   coCustInfoList      = new ArrayList<String>();
//        ArrayList<String>   dpdMonitorList      = new ArrayList<String>();
//        int                 c                   = 0;
//        int                 sumCols        	= 0;
//
//        try {
//            
//            if (getCurrentUser() != null && (!ValidatorUtil.isNullOrEmpty(getCurrentUser().getRoleId()))) {
//                setMonitoringFormList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.MONITOR));
//                setAssessmentList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.ASSES));
//            }
//
//            setRoleId(getCurrentUser().getRoleId());
//            searchBean = (SearchBean) request.getSession(false).getAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
//            paginate = createPaginate(0);
//            paginate.setIndex(-99);
//            paginate = warningHeaderBusiness.getPipeline(paginate, searchBean, getCurrentUser(), 0);
//            
//            log.info("[exportExcel] totalRecord :: " + paginate.getTotalRecord());
//            log.info("[exportExcel] totalPage :: " + paginate.getTotalPage());
//            
//            /*Begin Header*/
//            excelUtils.setCell("Export by:", 1, 0, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,true);
//            excelUtils.setCell(getCurrentUser().getEmpNo() + " - " + getCurrentUser().getFullName(), 1, 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
//            excelUtils.mergedCell(1, 1, 2, false, worksheet,true);
//            
//            if (getCurrentUser().getDeptCode() != null && !"".equals(getCurrentUser().getDeptCode())) {
//                respDesc = getCurrentUser().getDeptCode() + " - " + getCurrentUser().getDeptName();
//            } else {
//                respDesc = getCurrentUser().getDeptCode();
//            }
//            excelUtils.setCell("Response Unit:", 1, 3, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,true);
//            excelUtils.setCell(respDesc, 1, 4, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
//            excelUtils.mergedCell(1, 4, 5, false, worksheet,true);
//
//            excelUtils.setCell("Role:", 1, 7, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,true);
//            excelUtils.setCell(getCurrentUser().getRoleId(), 1, 8, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
//
//            excelUtils.setCell("ข้อมูลวันที่ " + convertDateThai(format1.format(cal.getTime()).toString()), 2, 0, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
//            /*End Header*/
//            
//            /*Begin Table header*/
//            rows    = 4;
//            cols    = 0;
//            
//            cell = excelUtils.setCell("No.", rows, cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//
//            cell = excelUtils.setCell("Warning Date", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//
//            cell = excelUtils.setCell("CIF No.", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//
//            cell = excelUtils.setCell("ชื่อลูกค้า", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//            
//            if (BusinessConst.UserRole.VIWER_1.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.RISK_EDITOR.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.ADMIN.equals(getCurrentUser().getRoleId())) {
//                cell = excelUtils.setCell("Size", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                excelUtils.setBackGroundColor(cell, 130, 239, 242);
//                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//            }
//            
//            /*Begin Account Owner*/
//            if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("RM ID");
//            }
//            if (!BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("AE ID");
//            }
//            if (!BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("AO ID");
//            }
//            if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())) {
//                custInfoList.add("Response Unit ");
//            }
//
//            cell = excelUtils.setCell("Account Owner", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.mergedCell(rows, cols, ((cols-1)+custInfoList.size()), true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 222, 233, 201);
//            c = cols;
//            for(String s:custInfoList){
//                cell = excelUtils.setCell(s, (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                excelUtils.setBackGroundColor(cell, 222, 233, 201);
//            }
//            cols = cols + custInfoList.size() - 1;
//            /*End Account Owner*/
//            
//            /*Begin CO Response Owner*/
//            //--DISPLAY Column CO_OP
//            boolean fullFile = true;
//            Integer amtCoOp = warningHeaderBusiness.countPipelineHaveCoOp(searchBean, getCurrentUser());
//            if(amtCoOp == null || amtCoOp == 0)fullFile = false;
//            if(fullFile){
//                if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId())) {
//                    coCustInfoList.add("CO RM ID");
//                }
//                if (!BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId())) {
//                    coCustInfoList.add("CO AE ID");
//                }
//                if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())) {
//                    coCustInfoList.add("CO Response Unit ");
//                }
//                
//                cell = excelUtils.setCell("CO Response Owner", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                excelUtils.mergedCell(rows, cols, ((cols-1)+coCustInfoList.size()), true, worksheet,true);
//                excelUtils.setBackGroundColor(cell, 222, 233, 201);
//                c = cols;
//                for(String s:coCustInfoList){
//                    cell = excelUtils.setCell(s, (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                    excelUtils.setBackGroundColor(cell, 222, 233, 201);
//                }
//                cols = cols + coCustInfoList.size() - 1;
//            }   
//            /*End CO Response Owner*/
//            
//            cell = excelUtils.setCell("EWS Risk", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 21, 204, 204);
//
//            cell = excelUtils.setCell("C final", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 21, 204, 204);
//            
//            /*Begin Daily OD Monitoring*/
//            dpdMonitorList.add("DPDs");
//            dpdMonitorList.add("#A/Cs");
//            dpdMonitorList.add("Unpaid Amount(บาท)");
//            
//            cell = excelUtils.setCell("Daily OD Monitoring", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.mergedCell(rows, cols, ((cols-1)+dpdMonitorList.size()), true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 21, 204, 204);
//            c = cols;
//            for(String s:dpdMonitorList){
//                cell = excelUtils.setCell(s, (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                excelUtils.setBackGroundColor(cell, 21, 204, 204);
//            }
//            cols = cols + dpdMonitorList.size() - 1;
//            /*End Daily OD Monitoring*/
//
//            cell = excelUtils.setCell("SP", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 21, 204, 204);
//            cell = excelUtils.setCell("#A/Cs", (rows+1), cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 21, 204, 204);
//            
//            sumCols = cols;
//            
//            /*Begin Turnaround*/
//            if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
//                cell = excelUtils.setCell("Turnaround", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                excelUtils.mergedCell(rows, cols, ((cols-1)+getMonitoringFormList().size()), true, worksheet,true);
//                excelUtils.setBackGroundColor(cell, 0, 0, 255);
//                c = cols;
//                for (WarningTypeVo vo : getMonitoringFormList()) {
//                    cell = excelUtils.setCell(vo.getShortName(), (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                    excelUtils.setBackGroundColor(cell, 130, 239, 242);
//                }
//                cols = cols + getMonitoringFormList().size() - 1;
//            }
//            /*End Turnaround*/
//            
//            /*Begin Assessment Updated*/
//            if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
//                cell = excelUtils.setCell("Assessment Updated", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                excelUtils.mergedCell(rows, cols, ((cols-1)+getAssessmentList().size()), true, worksheet,true);
//                excelUtils.setBackGroundColor(cell, 0, 0, 255);
//                c = cols;
//                for (WarningTypeVo vo : getAssessmentList()) {
//                    cell = excelUtils.setCell(vo.getShortName(), (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//                    excelUtils.setBackGroundColor(cell, 130, 239, 242);
//                }
//                cols = cols + getAssessmentList().size() - 1;
//            }
//            /*End Assessment Updated*/
//            
//            /*Begin การทบทวนต่ออายุ*/
//            cell = excelUtils.setCell("การทบทวน/ต่ออายุวงเงิน และ Credit Rating", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.mergedCell(rows, cols, ((cols-1)+5), true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 0, 0, 255);
//            
//            cell = excelUtils.setCell("Types", (rows+1), cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            
//            cell = excelUtils.setCell("Credit Review", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            
//            cell = excelUtils.setCell("Review Date", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            
//            cell = excelUtils.setCell("Credit Rating", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            
//            cell = excelUtils.setCell("Rating Date", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
//            excelUtils.setBackGroundColor(cell, 130, 239, 242);
//            /*End การทบทวนต่ออายุ*/
//            
//            /*End Table header*/
//            
//            /*Begin Table Body*/
//            rows    = 6;
//            int i = 0;
//            
//            ArrayList<WarningHeaderVo> taskList = paginate.getList();
//            
//            for(WarningHeaderVo headVo:taskList){
//                cols    = 0;
//                int nums = ++i;
//                
//                //No.
//                excelUtils.setCellTableData(String.valueOf(nums), rows, cols++,  worksheet );
//                
//                //Warning Date
//                excelUtils.setCellTableData(headVo.getWarningDateStr(), rows, cols++,  worksheet );
//                
//                //CIF No.
//                excelUtils.setCellTableData(headVo.getCif(), rows, cols++,  worksheet );
//                
//                //ชื่อลูกค้า
//                excelUtils.setCellTableData(headVo.getCustomerVo().getCustName(), rows, cols++,  worksheet );
//                
//                //Size
//                if (BusinessConst.UserRole.VIWER_1.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.RISK_EDITOR.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.ADMIN.equals(getCurrentUser().getRoleId())) {
//                    excelUtils.setCellTableData(headVo.getCustomerVo().getBusinessSize(), rows, cols++,  worksheet );
//                }
//                
//                /*Begin Account Owner*/
//                if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId())) {
//                    excelUtils.setCellTableData(headVo.getCustomerVo().getRmId(), rows, cols++,  worksheet );
//                }
//                if (!BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId())) {
//                    excelUtils.setCellTableData(headVo.getCustomerVo().getAeId(), rows, cols++,  worksheet );
//                }
//                if (!BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId())) {
//                    excelUtils.setCellTableData(headVo.getCustomerVo().getAoId(), rows, cols++,  worksheet );
//                }
//                if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())) {
//                    excelUtils.setCellTableData(headVo.getCustomerVo().getResponseUnit(), rows, cols++,  worksheet );
//                }
//                /*End Account Owner*/
//                
//                /*Begin CO Response Owner*/
//                if(fullFile){
//                    if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId())) {
//                        excelUtils.setCellTableData(headVo.getCustomerVo().getCoRmId(), rows, cols++,  worksheet );
//                    }
//                    if (!BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId())) {
//                        excelUtils.setCellTableData(headVo.getCustomerVo().getCoAeId(), rows, cols++,  worksheet );
//                    }
//                    if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())) {
//                        excelUtils.setCellTableData(headVo.getCustomerVo().getCoResponseUnit(), rows, cols++,  worksheet );
//                    }
//                }
//                /*End CO Response Owner*/
//                
//                //EWS Risk
//                excelUtils.setCellTableData(headVo.getEwsRiskLevel(), rows, cols++,  worksheet );
//                //C final
//                excelUtils.setCellTableData(headVo.getcFinal(), rows, cols++,  worksheet );
//                
//                /*Begin Daily DPD Monitoring */
//                excelUtils.setCellTableData(headVo.getDpdStrFormat(), rows, cols++,  worksheet );
//                excelUtils.setCellTableData(headVo.getDpdAcctCntStr(), rows, cols++,  worksheet );
//                excelUtils.setCellTableData(StringUtil.nullToStr(headVo.getUnpaidAmt()), rows, cols++,  worksheet );
//                /*End Daily DPD Monitoring */
//                
//                //SP #A/Cs
//                excelUtils.setCellTableData(headVo.getSpAccount(), rows, cols++,  worksheet );
//                
//                /*Begin Turnaround*/
//                if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
//                    for (WarningTypeVo vo : getMonitoringFormList()) {
//                        if ("LATE_PAY".equals(vo.getWarningTypeCode())) {
//                            excelUtils.setCellTableData(convertFlgShowExcel(headVo.getLatePayFlg(), headVo.getStatus()), rows, cols++,  worksheet );
//                        }
//                        if ("ACTION1".equals(vo.getWarningTypeCode())) {
//                            excelUtils.setCellTableData(convertFlgShowExcel(headVo.getAction1Flg(), headVo.getStatus()), rows, cols++,  worksheet );
//                        }
//                        if ("ACTION2".equals(vo.getWarningTypeCode())) {
//                            excelUtils.setCellTableData(convertFlgShowExcel(headVo.getAction2Flg(), headVo.getStatus()), rows, cols++,  worksheet );
//                        }
//                    }
//                }
//                /*End Turnaround*/
//                
//                /*Begin Assessment Updated*/
//                if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
//                    for (WarningTypeVo vo : getAssessmentList()) {
//                        if ("EWSQ".equals(vo.getWarningTypeCode())) {
//                            excelUtils.setCellTableData(convertFlgShowExcel(headVo.getQualiFlg(), headVo.getStatus()), rows, cols++,  worksheet );
//                        }
//                        if ("CREDIT_RATING".equals(vo.getWarningTypeCode())) {
//                            excelUtils.setCellTableData(convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus()), rows, cols++,  worksheet );
//                        }
//                        if ("FIN".equals(vo.getWarningTypeCode())) {
//                            excelUtils.setCellTableData(convertFlgShowExcel(headVo.getFinFlg(), headVo.getStatus()), rows, cols++,  worksheet );
//                        }
//                    }
//                }
//                /*End Assessment Updated*/
//                
//                /*Begin การทบทวนต่ออายุ*/
//                //Types
//                excelUtils.setCellTableData(headVo.getTypesFlg(), rows, cols++,  worksheet );
//                
//                //Credit Review
//                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getCrFlg(), headVo.getStatus()), rows, cols++,  worksheet );
//                
//                //Review Date
//                excelUtils.setCellTableData(headVo.getReviewDateFinalStr(), rows, cols++,  worksheet );
//                
//                //Credit Rating
//                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus()), rows, cols++,  worksheet );
//                
//                //Rating Date
//                excelUtils.setCellTableData(headVo.getRatingDateFinalStr(), rows, cols++,  worksheet );
//                /*End การทบทวนต่ออายุ*/
//                
//                rows++;
//            }
//            /*End Table Body*/
//            
//            /*Begin รวม*/
//            excelUtils.setCell("รวม", rows, sumCols++, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet ,false);
//            
//            /*Begin Turnaround*/
//            if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
//                for (WarningTypeVo vo : getMonitoringFormList()) {
//                    if ("LATE_PAY".equals(vo.getWarningTypeCode())) {
//                        excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getLatePayFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//                    }
//                    if ("ACTION1".equals(vo.getWarningTypeCode())) {
//                        excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getAction1FlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//                    }
//                    if ("ACTION2".equals(vo.getWarningTypeCode())) {
//                        excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getAction2FlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//                    }
//                }
//            }
//            /*End Turnaround*/
//            
//            /*Begin Assessment Updated*/
//            if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
//                for (WarningTypeVo vo : getAssessmentList()) {
//                    if ("EWSQ".equals(vo.getWarningTypeCode())) {
//                        excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getQualiFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//                    }
//                    if ("CREDIT_RATING".equals(vo.getWarningTypeCode())) {
//                        excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//                    }
//                    if ("FIN".equals(vo.getWarningTypeCode())) {
//                        excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getFinFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//                    }
//                }
//            }
//            /*End Assessment Updated*/
//            
//            excelUtils.setCell("", rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getCrFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//            excelUtils.setCell("", rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
//            
//            /*End รวม*/
//            
//            ArrayList<MtFormStatusVo> formStatusList = mtConfigBusiness.getStatusNameAndSeq();
//           
//            //--- TYPES FLG 
//            ArrayList<MtFormStatusVo> dataTypeFlgRemarkList = new ArrayList<MtFormStatusVo>();
//            MtFormStatusVo dataTypeFlgRemark = new MtFormStatusVo();
//            dataTypeFlgRemark.setSeq("A");
//            dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวนสินเชื่อ");
//            dataTypeFlgRemarkList.add(dataTypeFlgRemark);
//            
//            dataTypeFlgRemark = new MtFormStatusVo();
//            dataTypeFlgRemark.setSeq("B");
//            dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ต่ออายุวงเงิน");
//            dataTypeFlgRemarkList.add(dataTypeFlgRemark);
//            
//            dataTypeFlgRemark = new MtFormStatusVo();
//            dataTypeFlgRemark.setSeq("C");
//            dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวนการจัดชั้นหนี้ C-Class");
//            dataTypeFlgRemarkList.add(dataTypeFlgRemark);
//            
//            dataTypeFlgRemark = new MtFormStatusVo();
//            dataTypeFlgRemark.setSeq("D");
//            dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวน Rating");
//            dataTypeFlgRemarkList.add(dataTypeFlgRemark);
//           
//            
//            cell = excelUtils.setCell("หมายเหตุ สถานะการแจ้งเตือน", (++rows), 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,false);
//            excelUtils.setFontColor(cell, 255, 0, 0,true,true);
//            for(MtFormStatusVo vo:formStatusList){
//                cell = excelUtils.setCell(vo.getSeq() + " หมายถึง " + vo.getFormStatusName(), (++rows), 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,false);
//                excelUtils.setFontColor(cell, 255, 0, 0,false,false);
//            }
//            for(MtFormStatusVo voType:dataTypeFlgRemarkList){
//                cell = excelUtils.setCell(voType.getSeq() + " หมายถึง " + voType.getFormStatusName(), (++rows), 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,false);
//                excelUtils.setFontColor(cell, 255, 0, 0,false,false);
//            }
////            excelUtils.setCell("", (++rows), 3, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
//            
//            
//            response.setHeader("Set-Cookie", "fileDownload=true; path=/");
//
//            ByteArrayOutputStream bos = new ByteArrayOutputStream();
//            workbook.write(bos);
//            bos.close();
//            byte[] bytes = bos.toByteArray();
//            fileName.append(format.format(cal.getTime()).toString()).append(".xlsx");
//            setExportFileName(fileName.toString());
//            fileStream = new ByteArrayInputStream(bytes);
//
//        } catch (Exception ex) {
//            response.setHeader("Set-Cookie", "fileDownload=false; path=/");
//            throw ex;
//        }finally{
//            log.debug("[exportExcel][End]");
//        }
//        return "exportExcel";
//    }
    
    public String exportExcel() throws Exception {
        log.debug("[exportExcel][Begin]");
        
        ExcelUtils          excelUtils		= new ExcelUtils();
        XSSFWorkbook        workbook 		= excelUtils.getWorkbook();
        XSSFSheet           worksheet 		= null;
        XSSFCell            cell 		= null;
        int                 rows        	= 0;
        int                 cols        	= 0;
        StringBuilder       fileName            = new StringBuilder("taskListReport");
        SimpleDateFormat    format              = new SimpleDateFormat("yyyyMMddHHmm", Locale.US);
        Calendar            cal                 = Calendar.getInstance();
        SimpleDateFormat    format1             = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String              respDesc            = "";
        ArrayList<String>   custInfoList        = new ArrayList<String>();
        ArrayList<String>   coCustInfoList      = new ArrayList<String>();
        ArrayList<String>   dpdMonitorList      = new ArrayList<String>();
        int                 c                   = 0;
        int                 sumCols        	= 0;
        int                 totalSheet          = 0;
        boolean             fullFile            = true;
        Integer             amtCoOp             = 0;
        int                 nums                = 0;

        try {
            
            if (getCurrentUser() != null && (!ValidatorUtil.isNullOrEmpty(getCurrentUser().getRoleId()))) {
                setMonitoringFormList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.MONITOR));
                setAssessmentList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.ASSES));
            }

            setRoleId(getCurrentUser().getRoleId());
            searchBean = (SearchBean) request.getSession(false).getAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
            paginate = createPaginate(6000);
            paginate.setIndex(1);
            paginate = warningHeaderBusiness.getPipeline(paginate, searchBean, getCurrentUser(), 0);
            
            amtCoOp = warningHeaderBusiness.countPipelineHaveCoOp(searchBean, getCurrentUser());
            
            totalSheet = paginate.getTotalPage();
            
            log.info("[exportExcel] totalRecord :: " + paginate.getTotalRecord());
            log.info("[exportExcel] totalSheet :: " + totalSheet);
            
            for(int sheet=1;sheet<=totalSheet;sheet++){
                worksheet = workbook.createSheet("Pipe Line" + sheet);
                
                if(sheet > 1){
                    paginate.setIndex(sheet);
                    paginate = warningHeaderBusiness.getPipeline(paginate, searchBean, getCurrentUser(), 0);
                    
                    custInfoList        = new ArrayList<String>();
                    coCustInfoList      = new ArrayList<String>();
                    dpdMonitorList      = new ArrayList<String>();
                }
                
                /*Begin Header*/
                excelUtils.setCell("Export by:", 1, 0, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,true);
                excelUtils.setCell(getCurrentUser().getEmpNo() + " - " + getCurrentUser().getFullName(), 1, 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
                excelUtils.mergedCell(1, 1, 2, false, worksheet,true);

                if (getCurrentUser().getDeptCode() != null && !"".equals(getCurrentUser().getDeptCode())) {
                    respDesc = getCurrentUser().getDeptCode() + " - " + getCurrentUser().getDeptName();
                } else {
                    respDesc = getCurrentUser().getDeptCode();
                }
                excelUtils.setCell("Response Unit:", 1, 3, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,true);
                excelUtils.setCell(respDesc, 1, 4, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
                excelUtils.mergedCell(1, 4, 5, false, worksheet,true);

                excelUtils.setCell("Role:", 1, 7, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,true);
                excelUtils.setCell(getCurrentUser().getRoleId(), 1, 8, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);

                excelUtils.setCell("ข้อมูลวันที่ " + convertDateThai(format1.format(cal.getTime()).toString()), 2, 0, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
                /*End Header*/

                /*Begin Table header*/
                rows    = 4;
                cols    = 0;

                cell = excelUtils.setCell("No.", rows, cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);
                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);

                cell = excelUtils.setCell("Warning Date", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);
                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);

                cell = excelUtils.setCell("CIF No.", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);
                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);

                cell = excelUtils.setCell("ชื่อลูกค้า", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);
                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);

                if (BusinessConst.UserRole.VIWER_1.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.RISK_EDITOR.equals(getCurrentUser().getRoleId()) 
                        || BusinessConst.UserRole.ADMIN.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.RISK_VIEWER.equals(getCurrentUser().getRoleId())) {
                    cell = excelUtils.setCell("Size", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                    excelUtils.setBackGroundColor(cell, 130, 239, 242);
                    excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
                }

                /*Begin Account Owner*/
                if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId())) {
                    custInfoList.add("RM ID");
                }
                if (!BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId())) {
                    custInfoList.add("AE ID");
                }
                if (!BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId())) {
                    custInfoList.add("AO ID");
                }
                if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())) {
                    custInfoList.add("Response Unit ");
                }

                cell = excelUtils.setCell("Account Owner", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.mergedCell(rows, cols, ((cols-1)+custInfoList.size()), true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 222, 233, 201);
                c = cols;
                for(String s:custInfoList){
                    cell = excelUtils.setCell(s, (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                    excelUtils.setBackGroundColor(cell, 222, 233, 201);
                }
                cols = cols + custInfoList.size() - 1;
                /*End Account Owner*/

                /*Begin CO Response Owner*/
                //--DISPLAY Column CO_OP
                if(amtCoOp == null || amtCoOp == 0)fullFile = false;
                if(fullFile){
                    if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId())) {
                        coCustInfoList.add("CO RM ID");
                    }
                    if (!BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId())) {
                        coCustInfoList.add("CO AE ID");
                    }
                    if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())) {
                        coCustInfoList.add("CO Response Unit ");
                    }

                    cell = excelUtils.setCell("CO Response Owner", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                    excelUtils.mergedCell(rows, cols, ((cols-1)+coCustInfoList.size()), true, worksheet,true);
                    excelUtils.setBackGroundColor(cell, 222, 233, 201);
                    c = cols;
                    for(String s:coCustInfoList){
                        cell = excelUtils.setCell(s, (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                        excelUtils.setBackGroundColor(cell, 222, 233, 201);
                    }
                    cols = cols + coCustInfoList.size() - 1;
                }   
                /*End CO Response Owner*/

                cell = excelUtils.setCell("EWS Risk", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 21, 204, 204);

                cell = excelUtils.setCell("C final", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.mergedRow(cols, rows, (rows+1), true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 21, 204, 204);

                /*Begin Daily OD Monitoring*/
                dpdMonitorList.add("DPDs");
                dpdMonitorList.add("#A/Cs");
                dpdMonitorList.add("Unpaid Amount(บาท)");

                cell = excelUtils.setCell("Daily OD Monitoring", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.mergedCell(rows, cols, ((cols-1)+dpdMonitorList.size()), true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 21, 204, 204);
                c = cols;
                for(String s:dpdMonitorList){
                    cell = excelUtils.setCell(s, (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                    excelUtils.setBackGroundColor(cell, 21, 204, 204);
                }
                cols = cols + dpdMonitorList.size() - 1;
                /*End Daily OD Monitoring*/

                cell = excelUtils.setCell("SP", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 21, 204, 204);
                cell = excelUtils.setCell("#A/Cs", (rows+1), cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 21, 204, 204);

                sumCols = cols;

                /*Begin Turnaround*/
                if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
                    cell = excelUtils.setCell("Turnaround", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                    excelUtils.mergedCell(rows, cols, ((cols-1)+getMonitoringFormList().size()), true, worksheet,true);
                    excelUtils.setBackGroundColor(cell, 0, 0, 255);
                    c = cols;
                    for (WarningTypeVo vo : getMonitoringFormList()) {
                        cell = excelUtils.setCell(vo.getShortName(), (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                        excelUtils.setBackGroundColor(cell, 130, 239, 242);
                    }
                    cols = cols + getMonitoringFormList().size() - 1;
                }
                /*End Turnaround*/

                /*Begin Assessment Updated*/
                if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
                    cell = excelUtils.setCell("Assessment Updated", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                    excelUtils.mergedCell(rows, cols, ((cols-1)+getAssessmentList().size()), true, worksheet,true);
                    excelUtils.setBackGroundColor(cell, 0, 0, 255);
                    c = cols;
                    for (WarningTypeVo vo : getAssessmentList()) {
                        cell = excelUtils.setCell(vo.getShortName(), (rows+1), c++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                        excelUtils.setBackGroundColor(cell, 130, 239, 242);
                    }
                    cols = cols + getAssessmentList().size() - 1;
                }
                /*End Assessment Updated*/

                /*Begin การทบทวนต่ออายุ*/
                cell = excelUtils.setCell("การทบทวน/ต่ออายุวงเงิน และ Credit Rating", rows, ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.mergedCell(rows, cols, ((cols-1)+5), true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 0, 0, 255);

                cell = excelUtils.setCell("Types", (rows+1), cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);

                cell = excelUtils.setCell("Credit Review", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);

                cell = excelUtils.setCell("Review Date", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);

                cell = excelUtils.setCell("Credit Rating", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);

                cell = excelUtils.setCell("Rating Date", (rows+1), ++cols, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, true, true, worksheet,true);
                excelUtils.setBackGroundColor(cell, 130, 239, 242);
                /*End การทบทวนต่ออายุ*/

                /*End Table header*/

                /*Begin Table Body*/
                rows    = 6;

                ArrayList<WarningHeaderVo> taskList = paginate.getList();

                for(WarningHeaderVo headVo:taskList){
                    cols    = 0;

                    //No.
                    excelUtils.setCellTableData(String.valueOf(++nums), rows, cols++,  worksheet );

                    //Warning Date
                    excelUtils.setCellTableData(headVo.getWarningDateStr(), rows, cols++,  worksheet );

                    //CIF No.
                    excelUtils.setCellTableData(headVo.getCif(), rows, cols++,  worksheet );

                    //ชื่อลูกค้า
                    excelUtils.setCellTableData(headVo.getCustomerVo().getCustName(), rows, cols++,  worksheet );

                    //Size
                    if (BusinessConst.UserRole.VIWER_1.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.RISK_EDITOR.equals(getCurrentUser().getRoleId()) 
                            || BusinessConst.UserRole.ADMIN.equals(getCurrentUser().getRoleId()) || BusinessConst.UserRole.RISK_VIEWER.equals(getCurrentUser().getRoleId())) {
                        excelUtils.setCellTableData(headVo.getCustomerVo().getBusinessSize(), rows, cols++,  worksheet );
                    }

                    /*Begin Account Owner*/
                    if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId())) {
                        excelUtils.setCellTableData(headVo.getCustomerVo().getRmId(), rows, cols++,  worksheet );
                    }
                    if (!BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId())) {
                        excelUtils.setCellTableData(headVo.getCustomerVo().getAeId(), rows, cols++,  worksheet );
                    }
                    if (!BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId())) {
                        excelUtils.setCellTableData(headVo.getCustomerVo().getAoId(), rows, cols++,  worksheet );
                    }
                    if (!BusinessConst.UserRole.RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.AO.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())) {
                        excelUtils.setCellTableData(headVo.getCustomerVo().getResponseUnit(), rows, cols++,  worksheet );
                    }
                    /*End Account Owner*/

                    /*Begin CO Response Owner*/
                    if(fullFile){
                        if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId())) {
                            excelUtils.setCellTableData(headVo.getCustomerVo().getCoRmId(), rows, cols++,  worksheet );
                        }
                        if (!BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId())) {
                            excelUtils.setCellTableData(headVo.getCustomerVo().getCoAeId(), rows, cols++,  worksheet );
                        }
                        if (!BusinessConst.UserRole.CO_RM.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_AE.equals(getCurrentUser().getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())) {
                            excelUtils.setCellTableData(headVo.getCustomerVo().getCoResponseUnit(), rows, cols++,  worksheet );
                        }
                    }
                    /*End CO Response Owner*/

                    //EWS Risk
                    excelUtils.setCellTableData(headVo.getEwsRiskLevel(), rows, cols++,  worksheet );
                    //C final
                    excelUtils.setCellTableData(headVo.getcFinal(), rows, cols++,  worksheet );

                    /*Begin Daily DPD Monitoring */
                    excelUtils.setCellTableData(headVo.getDpdStrFormat(), rows, cols++,  worksheet );
                    excelUtils.setCellTableData(headVo.getDpdAcctCntStr(), rows, cols++,  worksheet );
                    excelUtils.setCellTableData(StringUtil.nullToStr(headVo.getUnpaidAmt()), rows, cols++,  worksheet );
                    /*End Daily DPD Monitoring */

                    //SP #A/Cs
                    excelUtils.setCellTableData(headVo.getSpAccount(), rows, cols++,  worksheet );

                    /*Begin Turnaround*/
                    if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
                        for (WarningTypeVo vo : getMonitoringFormList()) {
                            if ("LATE_PAY".equals(vo.getWarningTypeCode())) {
                                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getLatePayFlg(), headVo.getStatus()), rows, cols++,  worksheet );
                            }
                            if ("ACTION1".equals(vo.getWarningTypeCode())) {
                                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getAction1Flg(), headVo.getStatus()), rows, cols++,  worksheet );
                            }
                            if ("ACTION2".equals(vo.getWarningTypeCode())) {
                                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getAction2Flg(), headVo.getStatus()), rows, cols++,  worksheet );
                            }
                        }
                    }
                    /*End Turnaround*/

                    /*Begin Assessment Updated*/
                    if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
                        for (WarningTypeVo vo : getAssessmentList()) {
                            if ("EWSQ".equals(vo.getWarningTypeCode())) {
                                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getQualiFlg(), headVo.getStatus()), rows, cols++,  worksheet );
                            }
                            if ("CREDIT_RATING".equals(vo.getWarningTypeCode())) {
                                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus()), rows, cols++,  worksheet );
                            }
                            if ("FIN".equals(vo.getWarningTypeCode())) {
                                excelUtils.setCellTableData(convertFlgShowExcel(headVo.getFinFlg(), headVo.getStatus()), rows, cols++,  worksheet );
                            }
                        }
                    }
                    /*End Assessment Updated*/

                    /*Begin การทบทวนต่ออายุ*/
                    //Types
                    excelUtils.setCellTableData(headVo.getTypesFlg(), rows, cols++,  worksheet );

                    //Credit Review
                    String crFlg = convertFlgShowExcel(headVo.getCrFlg(), headVo.getStatus());
                    excelUtils.setCellTableData(crFlg, rows, cols++,  worksheet );

                    //Review Date
                    String reviewDateFinalStr = "1".equals(crFlg)?"":headVo.getReviewDateFinalStr();
                    excelUtils.setCellTableData(reviewDateFinalStr, rows, cols++,  worksheet );

                    //Credit Rating
                    String creditRatingFlg = convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus());
                    excelUtils.setCellTableData(convertFlgShowExcel(headVo.getCreditRatingFlg(), headVo.getStatus()), rows, cols++,  worksheet );

                    //Rating Date
                    String ratingDateFinalStr = "1".equals(creditRatingFlg)?"":headVo.getRatingDateFinalStr();
                    excelUtils.setCellTableData(ratingDateFinalStr, rows, cols++,  worksheet );
                    /*End การทบทวนต่ออายุ*/

                    rows++;
                }
                /*End Table Body*/

                /*Begin รวม*/
                excelUtils.setCell("รวม", rows, sumCols++, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet ,false);

                /*Begin Turnaround*/
                if (getMonitoringFormList() != null && !getMonitoringFormList().isEmpty()) {
                    for (WarningTypeVo vo : getMonitoringFormList()) {
                        if ("LATE_PAY".equals(vo.getWarningTypeCode())) {
                            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getLatePayFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                        }
                        if ("ACTION1".equals(vo.getWarningTypeCode())) {
                            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getAction1FlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                        }
                        if ("ACTION2".equals(vo.getWarningTypeCode())) {
                            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getAction2FlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                        }
                    }
                }
                /*End Turnaround*/

                /*Begin Assessment Updated*/
                if (getAssessmentList() != null && !getAssessmentList().isEmpty()) {
                    for (WarningTypeVo vo : getAssessmentList()) {
                        if ("EWSQ".equals(vo.getWarningTypeCode())) {
                            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getQualiFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                        }
                        if ("CREDIT_RATING".equals(vo.getWarningTypeCode())) {
                            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                        }
                        if ("FIN".equals(vo.getWarningTypeCode())) {
                            excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getFinFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                        }
                    }
                }
                /*End Assessment Updated*/

                excelUtils.setCell("", rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getCrFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                excelUtils.setCell("", rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);
                excelUtils.setCell(((CountDataVo) paginate.getCountObjData()).getCreditRatingFlgCountStr(), rows, sumCols++, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, false, false, worksheet ,false);

                /*End รวม*/

                ArrayList<MtFormStatusVo> formStatusList = mtConfigBusiness.getStatusNameAndSeq();

                //--- TYPES FLG 
                ArrayList<MtFormStatusVo> dataTypeFlgRemarkList = new ArrayList<MtFormStatusVo>();
                MtFormStatusVo dataTypeFlgRemark = new MtFormStatusVo();
                dataTypeFlgRemark.setSeq("A");
                dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวนสินเชื่อ");
                dataTypeFlgRemarkList.add(dataTypeFlgRemark);

                dataTypeFlgRemark = new MtFormStatusVo();
                dataTypeFlgRemark.setSeq("B");
                dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ต่ออายุวงเงิน");
                dataTypeFlgRemarkList.add(dataTypeFlgRemark);

                dataTypeFlgRemark = new MtFormStatusVo();
                dataTypeFlgRemark.setSeq("C");
                dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวนการจัดชั้นหนี้ C-Class");
                dataTypeFlgRemarkList.add(dataTypeFlgRemark);

                dataTypeFlgRemark = new MtFormStatusVo();
                dataTypeFlgRemark.setSeq("D");
                dataTypeFlgRemark.setFormStatusName("แจ้งเตือนให้ทบทวน Rating");
                dataTypeFlgRemarkList.add(dataTypeFlgRemark);


                cell = excelUtils.setCell("หมายเหตุ สถานะการแจ้งเตือน", (++rows), 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, true, false, worksheet,false);
                excelUtils.setFontColor(cell, 255, 0, 0,true,true);
                for(MtFormStatusVo vo:formStatusList){
                    cell = excelUtils.setCell(vo.getSeq() + " หมายถึง " + vo.getFormStatusName(), (++rows), 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,false);
                    excelUtils.setFontColor(cell, 255, 0, 0,false,false);
                }
                for(MtFormStatusVo voType:dataTypeFlgRemarkList){
                    cell = excelUtils.setCell(voType.getSeq() + " หมายถึง " + voType.getFormStatusName(), (++rows), 1, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,false);
                    excelUtils.setFontColor(cell, 255, 0, 0,false,false);
                }
    //            excelUtils.setCell("", (++rows), 3, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, false, false, worksheet,true);
            }
            
            response.setHeader("Set-Cookie", "fileDownload=true; path=/");

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            bos.close();
            byte[] bytes = bos.toByteArray();
            fileName.append(format.format(cal.getTime()).toString()).append(".xlsx");
            setExportFileName(fileName.toString());
            fileStream = new ByteArrayInputStream(bytes);

        } catch (Exception ex) {
            response.setHeader("Set-Cookie", "fileDownload=false; path=/");
            throw ex;
        }finally{
            log.debug("[exportExcel][End]");
        }
        return "exportExcel";
    }

    public String goIndividualReport() throws Exception {
        setPageName(BusinessConst.PAGE.PIPELINE);
        return "nextIndividualReport";
    }

    public String searchConditionMemory() throws Exception {
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. TaskListAction.searchConditionMemory");
            }
            
            if (getCurrentUser() != null && (!ValidatorUtil.isNullOrEmpty(getCurrentUser().getRoleId()))) {
                setMonitoringFormList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.MONITOR));
                setAssessmentList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.ASSES));
                setReviewList(warningTypeBusiness.getColumnByPrivilege(getCurrentUser().getRoleId(), BusinessConst.WARNING_TYPE_GROUP.REVIEW));
            }
            setRoleId(getCurrentUser().getRoleId());
            
            /**
             * * Render Screen ***
             */
            if (conditionSearchList == null || conditionSearchList.isEmpty()) {
                conditionSearchList = getDropdownSearchList(getCurrentUser().getRoleId());
            }
            if (organizationTypeList == null || organizationTypeList.isEmpty()) {
                organizationTypeList = getDropdownOrganizeType();
            }
            /**
             * * --------------- ***
             */
            int rowAmt = 10;// Default
            int pageAmt = 10;// Default
            if (paginate == null) {
                rowAmt = parameterBusiness.numRowDataGrid();
                pageAmt = parameterBusiness.numPageDisplayOnDataGrid();
                paginate = createPaginate(rowAmt);
            }
            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            if (request.getSession(false).getAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT) != null) {
                searchBean = (SearchBean) request.getSession(false).getAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
                if (searchBean != null) {
                    setCrflagFillter(searchBean.isCrFillter());
                    setTaflagFillter(searchBean.isTaFillter());
                    setPageIndex(searchBean.getSearchPageIndex());
                    paginate.setIndex(Integer.parseInt(searchBean.getSearchPageIndex()));
                }
            }
            if (searchBean != null) {
                log.debug("searchBean.getSortField() = " + searchBean.getSortField());
                log.debug("searchBean.getSortType() = " + searchBean.getSortType());
                log.debug("searchBean.getByName() = " + searchBean.getByName());
                log.debug("searchBean.getTextSearch() = " + searchBean.getTextSearch());
                log.debug("searchBean.getSearchPageIndex() = " + searchBean.getSearchPageIndex());

            }
            paginate = warningHeaderBusiness.getPipeline(paginate, searchBean, getCurrentUser(), pageAmt);

        } catch (Exception e) {
            log.error("Error occur in while process searchConditionMemory : " + e.getMessage(), e);
        }
        return SUCCESS;
    }

    public ArrayList<WarningTypeVo> getMonitoringFormList() {
        return monitoringFormList;
    }

    public void setMonitoringFormList(ArrayList<WarningTypeVo> monitoringFormList) {
        this.monitoringFormList = monitoringFormList;
    }

    public ArrayList<WarningTypeVo> getAssessmentList() {
        return assessmentList;
    }

    public void setAssessmentList(ArrayList<WarningTypeVo> assessmentList) {
        this.assessmentList = assessmentList;
    }

    public ArrayList<WarningTypeVo> getReviewList() {
        return reviewList;
    }

    public void setReviewList(ArrayList<WarningTypeVo> reviewList) {
        this.reviewList = reviewList;
    }

    public WarningHeaderBusiness getWarningHeaderBusiness() {
        return warningHeaderBusiness;
    }

    public void setWarningHeaderBusiness(WarningHeaderBusiness warningHeaderBusiness) {
        this.warningHeaderBusiness = warningHeaderBusiness;
    }

    public ParameterBusiness getParameterBusiness() {
        return parameterBusiness;
    }

    public void setParameterBusiness(ParameterBusiness parameterBusiness) {
        this.parameterBusiness = parameterBusiness;
    }

    public DropdownBusiness getDropdownBusiness() {
        return dropdownBusiness;
    }

    public void setDropdownBusiness(DropdownBusiness dropdownBusiness) {
        this.dropdownBusiness = dropdownBusiness;
    }

    public WarningTypeBusiness getWarningTypeBusiness() {
        return warningTypeBusiness;
    }

    public void setWarningTypeBusiness(WarningTypeBusiness warningTypeBusiness) {
        this.warningTypeBusiness = warningTypeBusiness;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public int getNextWarningInfoId() {
        return nextWarningInfoId;
    }

    public void setNextWarningInfoId(int nextWarningInfoId) {
        this.nextWarningInfoId = nextWarningInfoId;
    }

    private ArrayList putExcelHeader(ArrayList list, String headerName) throws Exception {
        ArrayList result = new ArrayList();
        if (list != null && !list.isEmpty()) {
            int size = list.size();
            if (size == 1) {
                size = 1;
            } else if (size % 2 == 0) {
                size = size / 2;
            } else {
                size = (size - 1) / 2;
            }


            for (int i = 0; i < list.size(); i++) {
                if (i == size) {
                    result.add(headerName);
                } else {
                    result.add("");
                }

            }
        }
        return result;


    }

    /*  private TaskListExcelVO setToExcel(String inp, int isFlg, int color) throws Exception {
     TaskListExcelVO vo = new TaskListExcelVO();
     vo.setValue(inp);
     vo.setIsFlg(isFlg);
     vo.setColor(color);
     return vo;
     }*/
    private String convertFlgShowExcel(String inp, String status) throws Exception {
        String flag = "";
        HashMap mtData = getMtFormStatusData();
        if (mtData != null) {
            if (inp != null && !"".equals(inp)) {
                
                //กรณีที่ TBL_WARNING_HEADER.STATUS = W ให้ แสดงตัวเลขของ form เป็นเหมือน status E ซึ่งมี SEQ = 2
                if("W".equals(status) && !inp.equals("D")){
                    inp = "E";
                }
                //กรณีที่ TBL_WARNING_HEADER.STATUS = R ให้ แสดงตัวเลขของ form เป็นเหมือน status RN หรือ RI ค่ะ ซึ่งมี SEQ = 3
                else if("R".equals(status) && !inp.equals("D")){
                    inp = "RN";
                }
                
                
                if (mtData.containsKey(inp)) {
                    flag = ((MtFormStatusVo) mtData.get(inp)).getSeq();
                }

            }
        }

        return flag;
    }

    protected HashMap getMtFormStatusData() throws Exception {
        HashMap hashData;
        if (MT_FORM_STATUS_MAP == null) {
            ArrayList<MtFormStatusVo> list = mtConfigBusiness.getMtFormDetail();
            if (list != null && !list.isEmpty()) {
                hashData = new HashMap();
                for (MtFormStatusVo vo : list) {
                    hashData.put(vo.getFormStatusFlg().trim(), vo);
                }
                MT_FORM_STATUS_MAP = hashData;
            }

        }
        return MT_FORM_STATUS_MAP;
    }

    private String convertDateThai(String dateStr) throws Exception {

        String dd = "";
        String mm = "";
        String yyyy = "";

        if (dateStr != null && !"".equals(dateStr) && dateStr.length() == 10) {
            dd = dateStr.substring(8, 10);
            mm = dateStr.substring(5, 7);
            yyyy = dateStr.substring(0, 4);
            return dd + "/" + mm + "/" + (Integer.parseInt(yyyy) + 543);
        } else {
            return "";
        }

    }

   public String gotoCloseJob() throws Exception {
        return "gotoCloseJobScreen";
    }

    public String getDisplayColumnCoOp() {
        return displayColumnCoOp;
    }

    public void setDisplayColumnCoOp(String displayColumnCoOp) {
        this.displayColumnCoOp = displayColumnCoOp;
    }
   
   
}
