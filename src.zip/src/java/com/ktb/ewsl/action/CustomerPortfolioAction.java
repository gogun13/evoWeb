/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ConfigBusiness;
import com.ktb.ewsl.business.CustomerPortfolioBusiness;
import com.ktb.ewsl.business.DropdownBusiness;
import com.ktb.ewsl.business.KtbOrganizationBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ConfigVO;
import com.ktb.ewsl.vo.CustomerPortfolioVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.DisplayUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class CustomerPortfolioAction extends BaseAction{
    
    private static final Logger log = Logger.getLogger(CustomerPortfolioAction.class);
    private String SEARCH = "search";
    private SearchBean searchBean;
    private List<DropdownVo> departmentList;
    private List<DropdownVo> organizationList;
    private List<DropdownVo> lineOrgList;
    private String showDataGrid;
    private Map<String, List> mapList = new TreeMap<String, List>();
    private String displayBreakType;
    private int nextIRWarningHeaderId; 
    private String nextIRCifNo;
    private String displayCriteriaRmAe;
    private String displayOrganiztion;
    private String pageName;
    private String comeformPageIRDetail;
    private String detailCifNo;
    private String detailCustomerName;
    private String detailRmIdOrAeId;
    private String detailWorkLine;
    private String detailOrganizationGroup;
    private String detailCostCenter;
    private PaginatedListImpl paginate;
    private InputStream fileStream;
    private String exportFileName;
    private String searchByPageNum;
    private String maxBatchDate;
    private String backFromHistoricalPage;
    private String displayColumnGroupResp = BusinessConst.Flag.Y;
    
    
    @Autowired
    private DropdownBusiness dropdownBusiness;
    @Autowired
    private ConfigBusiness configBusiness;
    @Autowired
    private CustomerPortfolioBusiness customerPortfolioBusiness;
    @Autowired
    private KtbOrganizationBusiness ktbOrganizationBusiness;
    @Override
    public String success() throws Exception {
        if (log.isDebugEnabled()) {
            log.debug("CustomerPortfolioAction.success");
        }
        
        departmentList = new ArrayList<DropdownVo>();
        organizationList = new ArrayList<DropdownVo>();

        lineOrgList = new ArrayList<DropdownVo>();
        lineOrgList = dropdownBusiness.getWorkLine();
        
        if (request.getSession(false) != null) {
            request.getSession(false).removeAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
        }
        setShowDataGrid(BusinessConst.Flag.N);
        
        if (EWSConstantValue.NO_CRITERIA_INDIVIDUAL_RM_AE_AO.contains(getCurrentUser().getRoleId())) {
            setDisplayOrganiztion(BusinessConst.Flag.N);
        } else {
            setDisplayOrganiztion(BusinessConst.Flag.Y);
        }
        return SUCCESS;
    }

    public String search() throws Exception {
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. CustomerPortfolioAction.search");
            }
            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            searchBean.setRmId(getCurrentUser().getEmpNo());
            searchBean.setRoleId(getCurrentUser().getRoleId());
            searchBean.setResponseUnit(getCurrentUser().getDeptCode());
            setShowDataGrid(BusinessConst.Flag.Y);

//            if (!ValidatorUtil.isNullOrEmpty(comeformPageIRDetail) && BusinessConst.PAGE.CUSTOMER_PORTFOLIO.equals(comeformPageIRDetail)) {
//                searchBean.setCifNo(getDetailCifNo() != null ? getDetailCifNo().trim() : "");
//                searchBean.setCustomerName(getDetailCustomerName() != null ? getDetailCustomerName().trim() : "");
//                if (request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH) != null) {
//                SearchBean sb = (SearchBean) request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
//                if (sb != null) {
//                    searchBean.setCustomerName(sb.getCustomerName() != null ? sb.getCustomerName().trim() : "");
//                }
//              }
//            }
            if (!ValidatorUtil.isNullOrEmpty(comeformPageIRDetail) && BusinessConst.PAGE.CUSTOMER_PORTFOLIO.equals(comeformPageIRDetail)) {
                searchBean.setCifNo(getDetailCifNo() != null ? getDetailCifNo().trim() : "");
                searchBean.setCustomerName(getDetailCustomerName() != null ? getDetailCustomerName().trim() : "");
                searchBean.setRmIdOrAeId(getDetailRmIdOrAeId() != null ? getDetailRmIdOrAeId().trim() : "");
                searchBean.setWorkLine(getDetailWorkLine() != null ? getDetailWorkLine().trim() : "");
                searchBean.setOrganizationGroup(getDetailOrganizationGroup() != null ? getDetailOrganizationGroup().trim() : "");
                searchBean.setCostCenter(getDetailCostCenter() != null ? getDetailCostCenter().trim() : "");
                if (request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH) != null) {
                SearchBean sb = (SearchBean) request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
                if (sb != null) {
                    searchBean.setCustomerName(sb.getCustomerName() != null ? sb.getCustomerName().trim() : "");
                }
              }
            }
            
            String breakBy = "";
            boolean displayResponseUnit = true;
            //-------------
             if(!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())){
                    displayResponseUnit = false;
             }else if(!ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())){
                     displayResponseUnit = false;
             }
            //-------------
            if(!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo())
                ||!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())
                ||!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())){
                
                breakBy = BusinessConst.BREAK_BY.SEARCH_BY_CUSTINFO;
            }else if(!ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())
                    && !ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup())
                    && !ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {

                breakBy = BusinessConst.BREAK_BY.DATA_NO_WORKLINE;
               
            } else if (!ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup()) && !ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {

                breakBy = BusinessConst.BREAK_BY.HAVE_DEPARTMENT;

            } else if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {
                breakBy = BusinessConst.BREAK_BY.HAVE_GROUP_CODE;
            } else {
                breakBy = BusinessConst.BREAK_BY.DATA_NO_WORKLINE;
            }
            searchBean.setIndividualReportBreakBy(breakBy);

            if (BusinessConst.BREAK_BY.DATA_NO_WORKLINE.equals(breakBy) || BusinessConst.BREAK_BY.SEARCH_BY_CUSTINFO.equals(breakBy)) {
            int rowAmt = 10;// Default
            int pageAmt = 10;// Default
            if (paginate == null) {
//                    ConfigVO configVoRow = configBusiness.findByConfigGroupAndConfigCode(BusinessConst.CONFIG_PAGE.CONFIG_GROUP_CODE, BusinessConst.CONFIG_PAGE.ROW);
//                    if ((configVoRow != null) && (!ValidatorUtil.isNullOrEmpty(configVoRow.getConfigValue()))) {
//                        rowAmt = Integer.parseInt(configVoRow.getConfigValue());
//                    }
//                    ConfigVO configVoPage = configBusiness.findByConfigGroupAndConfigCode(BusinessConst.CONFIG_PAGE.CONFIG_GROUP_CODE, BusinessConst.CONFIG_PAGE.PAGE);
//                    if ((configVoPage != null) && (!ValidatorUtil.isNullOrEmpty(configVoPage.getConfigValue()))) {
//                        pageAmt = Integer.parseInt(configVoPage.getConfigValue());
//                    }
                paginate = createPaginate(rowAmt);
            }
            if (paginate != null) {
                String pageIndexSearch = String.valueOf(paginate.getIndex());
                setPageIndex(pageIndexSearch);
                searchBean.setSearchPageIndex(pageIndexSearch);
            }

                //ค้นหาโดยไม่มีการเลือกสายงาน
             paginate = customerPortfolioBusiness.getCustomerPortfolioList(paginate, searchBean, getCurrentUser(), pageAmt);
            }else{
                //ค้นหาโดยมีการเลือกสายงาน
                mapList = customerPortfolioBusiness.getCustomerPortfolioList(searchBean);
            }
            
            //ข้อมูล ณ วันที่
            maxBatchDate = customerPortfolioBusiness.getMaxBatchDate(searchBean);
            maxBatchDate = DisplayUtil.getFullDateThai(DateUtil.parsePattern(maxBatchDate, "dd/MM/yyyy"));

            //***** Set Session *****//
            if (searchBean != null) {
                request.getSession(false).setAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH, searchBean);
            }

            setDisplayBreakType(breakBy);
            if(!displayResponseUnit){
               setDisplayColumnGroupResp(BusinessConst.Flag.N);
            }else{
               setDisplayColumnGroupResp(BusinessConst.Flag.Y);
            }
        } catch (Exception ex) {
            throw ex;
        }
        if (!ValidatorUtil.isNullOrEmpty(comeformPageIRDetail) && BusinessConst.PAGE.CUSTOMER_PORTFOLIO.equals(comeformPageIRDetail)) {
                        
            if (EWSConstantValue.NO_CRITERIA_INDIVIDUAL_RM_AE_AO.contains(getCurrentUser().getRoleId())) {
                setDisplayOrganiztion(BusinessConst.Flag.N);
            } else {
                setDisplayOrganiztion(BusinessConst.Flag.Y);
            }

            if (BusinessConst.Flag.Y.equals(getDisplayOrganiztion())) {
                lineOrgList = new ArrayList<DropdownVo>();
                lineOrgList = dropdownBusiness.getWorkLine();
                departmentList = new ArrayList<DropdownVo>();
                organizationList = new ArrayList<DropdownVo>();
                if (searchBean != null) {
                    if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {
                        organizationList = dropdownBusiness.getOrganizationGroupAndEwsUse(searchBean.getWorkLine());

                    }
                    if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup()))) {
                        departmentList = dropdownBusiness.getDepartment(searchBean.getWorkLine(), searchBean.getOrganizationGroup());
                    }
                }
            }
            if(!ValidatorUtil.isNullOrEmpty(getSearchByPageNum()) && "YES".equals(getSearchByPageNum())){
                return SEARCH;
            }else{
               return SUCCESS;
            }
        } else {
        return SEARCH;
    }
    }
     public String gotoViewCustomerPortfolioDetail() throws Exception {
        setPageName(BusinessConst.PAGE.CUSTOMER_PORTFOLIO_SEARCH);
        return "nextCustomerPortfolioDetailDetail";
    }
    
     public String searchWithCondition() throws Exception {
        try {
            if (log.isDebugEnabled()) {
                log.debug("Entry to............. CustomerPortfolioAction.searchWithCondition");
                log.debug(" getDetailCifNo >> " + getDetailCifNo());
                log.debug(" getDetailCustomerName >>" + getDetailCustomerName());
                log.debug(" getDetailRmIdOrAeId >>" + getDetailRmIdOrAeId());
                log.debug(" getDetailWorkLine >>" + getDetailWorkLine());
                log.debug(" getDetailOrganizationGroup >>" + getDetailOrganizationGroup());
                log.debug(" getDetailCostCenter >>" + getDetailCostCenter());
            }
            
            if (request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH) != null) {
                searchBean = (SearchBean) request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
            }
            
//            if (searchBean == null) {
//                searchBean = new SearchBean();
//            }
//            searchBean.setCifNo(getDetailCifNo() != null ? getDetailCifNo().trim() : "");
//            searchBean.setCustomerName(getDetailCustomerName() != null ? getDetailCustomerName().trim() : "");
//            searchBean.setRmIdOrAeId(getDetailRmIdOrAeId() != null ? getDetailRmIdOrAeId().trim() : "");
//            searchBean.setWorkLine(getDetailWorkLine() != null ? getDetailWorkLine().trim() : "");
//            searchBean.setOrganizationGroup(getDetailOrganizationGroup() != null ? getDetailOrganizationGroup().trim() : "");
//            searchBean.setCostCenter(getDetailCostCenter() != null ? getDetailCostCenter().trim() : "");
//            searchBean.setRmId(getCurrentUser().getEmpNo());
//            searchBean.setRoleId(getCurrentUser().getRoleId());
//            searchBean.setResponseUnit(getCurrentUser().getDeptCode());
            setShowDataGrid(BusinessConst.Flag.Y);

            String breakBy = "";
            boolean displayResponseUnit = true;
             //-------------
             if(!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())){
                    displayResponseUnit = false;
             }else if(!ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())){
                     displayResponseUnit = false;
            }
            //-------------
            if(!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo())
                ||!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())
                ||!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())){
                
                breakBy = BusinessConst.BREAK_BY.SEARCH_BY_CUSTINFO;
            }else if(!ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())
                    && !ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup())
                    && !ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {

                breakBy = BusinessConst.BREAK_BY.DATA_NO_WORKLINE;
            } else if (!ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup()) && !ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {

                breakBy = BusinessConst.BREAK_BY.HAVE_DEPARTMENT;

            } else if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {
                breakBy = BusinessConst.BREAK_BY.HAVE_GROUP_CODE;
            } else {
                breakBy = BusinessConst.BREAK_BY.DATA_NO_WORKLINE;
            }
            searchBean.setIndividualReportBreakBy(breakBy);
            log.debug(" breakBy >>" + breakBy);

            if (BusinessConst.BREAK_BY.DATA_NO_WORKLINE.equals(breakBy) || BusinessConst.BREAK_BY.SEARCH_BY_CUSTINFO.equals(breakBy)) {
            int rowAmt = 10;// Default
            int pageAmt = 10;// Default
            if (paginate == null) {
//                    ConfigVO configVoRow = configBusiness.findByConfigGroupAndConfigCode(BusinessConst.CONFIG_PAGE.CONFIG_GROUP_CODE, BusinessConst.CONFIG_PAGE.ROW);
//                    if ((configVoRow != null) && (!ValidatorUtil.isNullOrEmpty(configVoRow.getConfigValue()))) {
//                        rowAmt = Integer.parseInt(configVoRow.getConfigValue());
//                    }
//                    ConfigVO configVoPage = configBusiness.findByConfigGroupAndConfigCode(BusinessConst.CONFIG_PAGE.CONFIG_GROUP_CODE, BusinessConst.CONFIG_PAGE.PAGE);
//                    if ((configVoPage != null) && (!ValidatorUtil.isNullOrEmpty(configVoPage.getConfigValue()))) {
//                        pageAmt = Integer.parseInt(configVoPage.getConfigValue());
//                    }
                paginate = createPaginate(rowAmt);
            }
            if (paginate != null) {
                String pageIndexSearch = String.valueOf(paginate.getIndex());
                setPageIndex(pageIndexSearch);
                searchBean.setSearchPageIndex(pageIndexSearch);
            }

                //ค้นหาโดยไม่มีการเลือกสายงาน
             paginate = customerPortfolioBusiness.getCustomerPortfolioList(paginate, searchBean, getCurrentUser(), pageAmt);
            }else{
                //ค้นหาโดยมีการเลือกสายงาน
                mapList = customerPortfolioBusiness.getCustomerPortfolioList(searchBean);
            }
            
            //ข้อมูล ณ วันที่
            maxBatchDate = customerPortfolioBusiness.getMaxBatchDate(searchBean);

            //***** Set Session *****//
            if (searchBean != null) {
                request.getSession(false).setAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH, searchBean);
            }

            setDisplayBreakType(breakBy);
            if(!displayResponseUnit){
               setDisplayColumnGroupResp(BusinessConst.Flag.N);
            }else{
               setDisplayColumnGroupResp(BusinessConst.Flag.Y);
            }
            
            
        } catch (Exception ex) {
            throw ex;
        }
        
        if (!ValidatorUtil.isNullOrEmpty(comeformPageIRDetail) && BusinessConst.PAGE.CUSTOMER_PORTFOLIO.equals(comeformPageIRDetail)) {
            
            if (EWSConstantValue.NO_CRITERIA_INDIVIDUAL_RM_AE_AO.contains(getCurrentUser().getRoleId())) {
                setDisplayOrganiztion(BusinessConst.Flag.N);
            } else {
                setDisplayOrganiztion(BusinessConst.Flag.Y);
            }

            if (BusinessConst.Flag.Y.equals(getDisplayOrganiztion())) {
                lineOrgList = new ArrayList<DropdownVo>();
                lineOrgList = dropdownBusiness.getWorkLine();
                departmentList = new ArrayList<DropdownVo>();
                organizationList = new ArrayList<DropdownVo>();
                if (searchBean != null) {
                    if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())){
                        organizationList = dropdownBusiness.getOrganizationGroupAndEwsUse(searchBean.getWorkLine());

                    }
                    if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup()))) {
                        departmentList = dropdownBusiness.getDepartment(searchBean.getWorkLine(), searchBean.getOrganizationGroup());
                    }
                }
            }
            if(!ValidatorUtil.isNullOrEmpty(getSearchByPageNum()) && "YES".equals(getSearchByPageNum())){
                return SEARCH;
            }else{
        return SUCCESS;
    }
        } else {
            return SEARCH;
        }
    }
     
    public String exportExcel() throws Exception {
        Map<String,Object> beans = new HashMap<String,Object>();
        int idx = 1;
        int total = 0;
        if (log.isDebugEnabled()) {
            log.debug("Entry to............. CustomerPortfolioAction.exportExcel");
        }
        if (searchBean == null) {
            searchBean = new SearchBean();
        }
        if(request.getSession(false).getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH) != null){
               searchBean = (SearchBean)request.getSession(false).getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
              // searchBean.setCifNo(getDetailCifNo() != null ? getDetailCifNo().trim() : "");
             //  searchBean.setCustomerName(getDetailCustomerName() != null ? getDetailCustomerName().trim() : "");
        } 
        searchBean.setRmId(getCurrentUser() != null ? getCurrentUser().getEmpNo() : "");
        searchBean.setRoleId(getCurrentUser() != null ? getCurrentUser().getRoleId() : "");
        searchBean.setResponseUnit(getCurrentUser() != null ? getCurrentUser().getDeptCode() : "");
        setShowDataGrid(BusinessConst.Flag.Y);
        //------- Hide Group
        boolean displayResponseUnit = true;
        if(!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())){
            displayResponseUnit = false;
        }else if(!ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())) {
            displayResponseUnit = false;
        }       
        //--------------
        ArrayList<CustomerPortfolioVo> dataList = customerPortfolioBusiness.getCustomerPortfolioListExport(searchBean);
      
        if (dataList != null && !dataList.isEmpty()) {
            for (CustomerPortfolioVo vo : dataList) {
            vo.setIndex(idx);
            idx++;
            }
            total = dataList.size();
        }
        beans.put("dataList", dataList);
        beans.put("total", total);
        beans.put("searchBean", searchBean);

        //สายงาน
        beans.put("workLineInfo", ktbOrganizationBusiness.getCostCenterDescByCode(searchBean.getWorkLine()));
        //กลุ่มงาน
        beans.put("groupInfo", ktbOrganizationBusiness.getCostCenterDescByCode(searchBean.getOrganizationGroup()));
        //หน่วยงาน
        beans.put("costCenterInfo", ktbOrganizationBusiness.getCostCenterDescByCode(searchBean.getCostCenter()));
        
        XLSTransformer transformer = new XLSTransformer();

        String path = getServletContext().getRealPath("/");
        File file = null;
        if(!displayResponseUnit){ 
          file = new File(path + "report/customerPortfolioReportTempleteHideResponse.xls");
        }else{
          //file = new File(path + "report/customerPortfolioReportTemplete.xls");
            file = new File(path + "report/customerPortfolioReportTemplete_1.xls"); //R4
        }
        InputStream inputStream = new FileInputStream(file);
        HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
        Calendar cal = Calendar.getInstance();
            
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        workbook.write(bos);

        bos.close();
        byte[] bytes = bos.toByteArray();
        //setExportFileName("customerPortfolioReport.xls");
        setExportFileName("CustomerPortfolioReport"+"_"+format.format(cal.getTime()).toString()+ ".xls");
        fileStream = new ByteArrayInputStream(bytes);

        return "export";
    }
    
    
    public SearchBean getSearchBean() {
        return searchBean;
    }

    public void setSearchBean(SearchBean searchBean) {
        this.searchBean = searchBean;
    }

    public List<DropdownVo> getDepartmentList() {
        return departmentList;
    }

    public void setDepartmentList(List<DropdownVo> departmentList) {
        this.departmentList = departmentList;
    }

    public List<DropdownVo> getOrganizationList() {
        return organizationList;
    }

    public void setOrganizationList(List<DropdownVo> organizationList) {
        this.organizationList = organizationList;
    }

    public List<DropdownVo> getLineOrgList() {
        return lineOrgList;
    }

    public void setLineOrgList(List<DropdownVo> lineOrgList) {
        this.lineOrgList = lineOrgList;
    }

    public DropdownBusiness getDropdownBusiness() {
        return dropdownBusiness;
    }

    public void setDropdownBusiness(DropdownBusiness dropdownBusiness) {
        this.dropdownBusiness = dropdownBusiness;
    }

    public String getShowDataGrid() {
        return showDataGrid;
    }

    public void setShowDataGrid(String showDataGrid) {
        this.showDataGrid = showDataGrid;
    }

    public Map<String, List> getMapList() {
        return mapList;
    }

    public void setMapList(Map<String, List> mapList) {
        this.mapList = mapList;
    }

    public String getDisplayBreakType() {
        return displayBreakType;
    }

    public void setDisplayBreakType(String displayBreakType) {
        this.displayBreakType = displayBreakType;
    }

    public String getDisplayCriteriaRmAe() {
        return displayCriteriaRmAe;
    }

    public void setDisplayCriteriaRmAe(String displayCriteriaRmAe) {
        this.displayCriteriaRmAe = displayCriteriaRmAe;
    }

    public String getDisplayOrganiztion() {
        return displayOrganiztion;
    }

    public void setDisplayOrganiztion(String displayOrganiztion) {
        this.displayOrganiztion = displayOrganiztion;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public String getComeformPageIRDetail() {
        return comeformPageIRDetail;
    }

    public void setComeformPageIRDetail(String comeformPageIRDetail) {
        this.comeformPageIRDetail = comeformPageIRDetail;
    }

    public String getDetailCifNo() {
        return detailCifNo;
    }

    public void setDetailCifNo(String detailCifNo) {
        this.detailCifNo = detailCifNo;
    }

    public String getDetailCustomerName() {
        return detailCustomerName;
    }

    public void setDetailCustomerName(String detailCustomerName) {
        this.detailCustomerName = detailCustomerName;
    }

    public String getDetailRmIdOrAeId() {
        return detailRmIdOrAeId;
    }

    public void setDetailRmIdOrAeId(String detailRmIdOrAeId) {
        this.detailRmIdOrAeId = detailRmIdOrAeId;
    }

    public String getDetailWorkLine() {
        return detailWorkLine;
    }

    public void setDetailWorkLine(String detailWorkLine) {
        this.detailWorkLine = detailWorkLine;
    }

    public String getDetailOrganizationGroup() {
        return detailOrganizationGroup;
    }

    public void setDetailOrganizationGroup(String detailOrganizationGroup) {
        this.detailOrganizationGroup = detailOrganizationGroup;
    }

    public String getDetailCostCenter() {
        return detailCostCenter;
    }

    public void setDetailCostCenter(String detailCostCenter) {
        this.detailCostCenter = detailCostCenter;
    }

    public PaginatedListImpl getPaginate() {
        return paginate;
    }

    public void setPaginate(PaginatedListImpl paginate) {
        this.paginate = paginate;
    }

    public InputStream getFileStream() {
        return fileStream;
    }

    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

    public String getExportFileName() {
        return exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    public String getSearchByPageNum() {
        return searchByPageNum;
    }

    public void setSearchByPageNum(String searchByPageNum) {
        this.searchByPageNum = searchByPageNum;
    }

    public int getNextIRWarningHeaderId() {
        return nextIRWarningHeaderId;
    }

    public void setNextIRWarningHeaderId(int nextIRWarningHeaderId) {
        this.nextIRWarningHeaderId = nextIRWarningHeaderId;
    }

    public String getNextIRCifNo() {
        return nextIRCifNo;
    }

    public void setNextIRCifNo(String nextIRCifNo) {
        this.nextIRCifNo = nextIRCifNo;
    }

    public String getMaxBatchDate() {
        return maxBatchDate;
    }

    public void setMaxBatchDate(String maxBatchDate) {
        this.maxBatchDate = maxBatchDate;
    }

    public String getBackFromHistoricalPage() {
        return backFromHistoricalPage;
    }

    public void setBackFromHistoricalPage(String backFromHistoricalPage) {
        this.backFromHistoricalPage = backFromHistoricalPage;
    }

    public String getDisplayColumnGroupResp() {
        return displayColumnGroupResp;
    }

    public void setDisplayColumnGroupResp(String displayColumnGroupResp) {
        this.displayColumnGroupResp = displayColumnGroupResp;
    }
    
    
    
}
