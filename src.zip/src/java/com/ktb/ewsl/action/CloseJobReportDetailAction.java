/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ActionCloseBusiness;
import com.ktb.ewsl.business.QcaFinancialBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.external.optimist.FinUtil;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class CloseJobReportDetailAction extends BaseAction{
    
    private static final Logger logger = Logger.getLogger(CloseJobReportDetailAction.class);
    
    private String forBackPage;
    private String cif;
    private String custName;
    private String warningHeaderId;
    private String warningType;
    private String warningId;
    private List<ActionCloseVo> closeJobDetailList;
    
    private String reasonChoiceYes;
    private String reasonChoiceNo;
    private String reasonSelectY;
    private String reasonSelectN;
    private String reasonDetail;
    private ArrayList reasonSelectListYes;
    private ArrayList reasonSelectList;
    private FinancialVo financialVo;
    private String message;
    private String pageTitle;

    @Autowired
    private ActionCloseBusiness actionCloseBusiness; 
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private QcaFinancialBusiness qcaFinancialBusiness;

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(String warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getWarningId() {
        return warningId;
    }

    public void setWarningId(String warningId) {
        this.warningId = warningId;
    }

    public List<ActionCloseVo> getCloseJobDetailList() {
        return closeJobDetailList;
    }

    public void setCloseJobDetailList(List<ActionCloseVo> closeJobDetailList) {
        this.closeJobDetailList = closeJobDetailList;
    }

    public String getReasonChoiceYes() {
        return reasonChoiceYes;
    }

    public void setReasonChoiceYes(String reasonChoiceYes) {
        this.reasonChoiceYes = reasonChoiceYes;
    }

    public String getReasonSelectY() {
        return reasonSelectY;
    }

    public void setReasonSelectY(String reasonSelectY) {
        this.reasonSelectY = reasonSelectY;
    }

    public String getReasonSelectN() {
        return reasonSelectN;
    }

    public void setReasonSelectN(String reasonSelectN) {
        this.reasonSelectN = reasonSelectN;
    }

    public String getReasonDetail() {
        return reasonDetail;
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public ArrayList getReasonSelectListYes() {
        return reasonSelectListYes;
    }

    public void setReasonSelectListYes(ArrayList reasonSelectListYes) {
        this.reasonSelectListYes = reasonSelectListYes;
    }

    public ArrayList getReasonSelectList() {
        return reasonSelectList;
    }

    public void setReasonSelectList(ArrayList reasonSelectList) {
        this.reasonSelectList = reasonSelectList;
    }

    public FinancialVo getFinancialVo() {
        return financialVo;
    }

    public void setFinancialVo(FinancialVo financialVo) {
        this.financialVo = financialVo;
    }

    public String getReasonChoiceNo() {
        return reasonChoiceNo;
    }

    public void setReasonChoiceNo(String reasonChoiceNo) {
        this.reasonChoiceNo = reasonChoiceNo;
    }   

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPageTitle() {
        return pageTitle;
    }

    public void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }
       
    @Override
    public String success() throws Exception {
        log("[success][Begin]");
        
//        WarningInfoVo   warningInfoVo           = null;
//        WarningInfoVo   warningInfoVoDb         = null;
//        ActionCloseVo   actionCloseVo           = null;
        
        try{
            setHeaderDetail();
            
            setReasonChoiceYes("N");
            setReasonChoiceNo("N");
            setReasonSelectY("N");
            setReasonSelectN("N");
            
            log("[success] forBackPage      :: " + this.forBackPage);
            log("[success] warningType      :: " + this.warningType);
            log("[success] warningHeaderId  :: " + this.warningHeaderId);
            
            if(BusinessConst.WarningTypeCode.LATE_PAY.equals(warningType)){
                pageTitle = "Late Payment Form";
            }else if(BusinessConst.WarningTypeCode.ACTION1.equals(warningType)){
                pageTitle = "Action Form 1";
            }else if(BusinessConst.WarningTypeCode.ACTION2.equals(warningType)){
                pageTitle = "Action Form 2";
            }else if(BusinessConst.WarningTypeCode.EWSQ.equals(warningType)){
                pageTitle = "Qualitative Assessment";
            }else if(BusinessConst.WarningTypeCode.CREDIT_RATING.equals(warningType)){
                pageTitle = "Credit Rating";
            }else if(BusinessConst.WarningTypeCode.FIN.equals(warningType)){
                pageTitle = "Financial";
            }else if(BusinessConst.WarningTypeCode.CREDIT_REVIEW.equals(warningType)){
                pageTitle = "Credit Review";
            }else{
                pageTitle = "รายละเอียดการปิดงาน";
            }
            
            if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
                request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
            }
            
//            warningInfoVo = new WarningInfoVo();
//            warningInfoVo.setWarningHeaderId(this.paresInt(this.warningHeaderId));
//            warningInfoVo.setWarningType(this.warningType);
//            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
            
//            this.cif        = URLDecoder.decode(nullToStr(this.cif), "UTF-8");
//            this.custName   = URLDecoder.decode(nullToStr(this.custName), "UTF-8");
//            this.warningId  = this.nullToStr(warningInfoVoDb.getWarningId());
            
            log("[success] custName     :: " + this.custName);
            log("[success] cif          :: " + this.cif);
//            log("[success] warningId    :: " + this.warningId);
            
//            actionCloseVo = new ActionCloseVo();
//            actionCloseVo.setWarningHeadId(this.paresInt(this.warningHeaderId));
//            actionCloseVo.setWarningId(this.paresInt(this.warningId));
            
            this.closeJobDetailList = this.actionCloseBusiness.getcloseJobDetailList(warningHeaderId, warningType);
            
            if(reasonSelectListYes == null || reasonSelectListYes.isEmpty()){
                reasonSelectListYes = getReasonSelectListDataYes();
            }
            
            if(reasonSelectList == null || reasonSelectList.isEmpty() ){
                reasonSelectList = getReasonSelectListDataNo();
            }
            
            String tmpHvFin = FinUtil.null2Empty(qcaFinancialBusiness.checkHVFin(this.cif).getHvFin());
            if ("Y".equals(tmpHvFin.trim())) {
                setReasonChoiceYes("Y");
            } else {
                setReasonChoiceNo("N");
            }
            
            this.getFinancialDetail(this.custName);
            
        }catch(Exception e){
            logger.error(e);
        }finally{
            log("[success][End]");
        }
        
        return SUCCESS;
    }
    public String backTaskDetail() throws Exception {
        return "backTaskDetail";
    }

    public void setHeaderDetail() throws Exception{
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if(titleVo != null){
            this.cif                = titleVo.getCifNo();
            this.custName           = titleVo.getCustName();
            this.warningHeaderId    = this.nullToStr(titleVo.getWarningHeaderId());
        }
    }
    
    private void getFinancialDetail(String custName) {
        try {
            setFinancialVo(qcaFinancialBusiness.getFinancialVO(null, this.cif));

            if (getFinancialVo() == null) {
                log("FinancialVo is null");
                FinancialVo financialVO = new FinancialVo();
                financialVO.setHvFin("");
                financialVO.setReasonCode("");
                financialVO.setReasonSelectN("");
                financialVO.setReasonSelectY("");
                financialVO.setReasonDetail("");
                setFinancialVo(financialVO);
                setMessage("");
            } else {
                getFinancialVo().setRatioList(qcaFinancialBusiness.getRatioList(getFinancialVo(), qcaFinancialBusiness.getRatioList(getFinancialVo().getTrnId())));
                getFinancialVo().setCifNo(this.cif);
                getFinancialVo().setCustName(custName);
            }
        } catch (Exception e) {
        }
    }       
    public ArrayList<DropdownVo> getReasonSelectListDataYes() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("1", "งบนำส่งสรรพากร"));
        result.add(setDataToDropDrown("2", "งบ Recast"));  
        return result;
    }
    
    public ArrayList<DropdownVo> getReasonSelectListDataNo() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("1", "ก่อตั้งกิจการใหม่ (ยังไม่เริ่มดำเนินการ)"));
        result.add(setDataToDropDrown("2", "อยู่ระหว่างจัดทำบัญชี"));  
        result.add(setDataToDropDrown("3", "เลิกกิจการ (ยังชำระบัญชีไม่เสร็จสิ้น)"));  
        result.add(setDataToDropDrown("4", "เลิกกิจการ (ชำระบัญชีเสร็จสิ้น)"));  
        result.add(setDataToDropDrown("5", "มีคำสั่งศาล/ดำเนินการทางกฎหมาย"));  
        result.add(setDataToDropDrown("6", "อื่นๆ ระบุ"));  
        return result;
    }
    
    private DropdownVo setDataToDropDrown(String key,String value){
        DropdownVo ddVo = new DropdownVo();
        ddVo.setId(key);
        ddVo.setDesc(value);
        return ddVo;
    }
    
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }
    
    private String nullToStr(Object obj){
        
        return obj==null?"":obj.toString().trim();
        
    }
    
    private int paresInt(Object obj){
        
        int ret = 0;
        
        try{
            return obj==null?0:Integer.parseInt(obj.toString());
        }catch(Exception e){
            ret = 0;
            logger.error(e);
        }
        return ret;
    }
  
    
}
