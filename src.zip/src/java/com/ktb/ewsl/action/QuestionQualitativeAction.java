/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.CacheBusiness;
import com.ktb.ewsl.business.WarningCompletionBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.services.AsstAnswerService;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class QuestionQualitativeAction extends BaseAction {
    private static final Logger logger = Logger.getLogger(QuestionQualitativeAction.class);
    
    private String cifNo;
    private int warningHeaderId;
    private String warningType;
    private String infoStatus;
    private List<AsstTopicVo> asstTopicVoList;
    private List<AsstTopicVo> asstTopicVoListForOldAnswer;//---RM/AE/AO
    private List<AsstTopicVo> asstTopicVoListHistory;
    private List<String> answers;
    private List<QuestionHistoryVo>  questionHistoryList;
    private String approveFlag = BusinessConst.Flag.N;
    private String rejectFlag = BusinessConst.Flag.N;
    private String saveFlag = BusinessConst.Flag.N;
    private String finalLevel;
    private String showSaveFinal = BusinessConst.Flag.N;
    private String showMode;
    private List<ActionHistoryVo> actionHistoryVoList;
    private String showButtonForClose;
    private List<String> answersTrig;
    private List<String> requireList;
    private List<String> questionList;
    private String actionMode;
    private List<String> remarks;      // --For Quali
    private List<String> remarksTrig;  // --For Trig
    //private List<String> questionTrigList;
    private String questionId;
    private String version;
    private int ewsqWarningId;
    //private List questionTrigList;
    private String[][] questionTrigList = new String[20][10];
    private String currentUserRole;
    private String forBackPage;
    private String warningInfoDateStr;
    private String editRadioQualiFlag = BusinessConst.Flag.N;
    private String editFlag = BusinessConst.Flag.N;
    private String buttonSetOfEditFlag = BusinessConst.Flag.N;
    private List<String> answersQualiTemp;
    private List<String> answersTrigTemp;
    private String warningIdHistory;
    private String warningHeaderIdHistory;
    private String actionDateHistory;
    private String versionHistory;
    private String questionIdHistory;
    private String warningTypeHistory;

    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private CacheBusiness cacheBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private AsstAnswerService asstAnswerService;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness; 
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness; 
    @Autowired
    private WarningCompletionBusiness warningCompletionBusiness;
    
    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public List<AsstTopicVo> getAsstTopicVoList() {
        return asstTopicVoList;
    }

    public void setAsstTopicVoList(List<AsstTopicVo> asstTopicVoList) {
        this.asstTopicVoList = asstTopicVoList;
    }

    public List<String> getAnswers() {
        return answers;
    }

    public void setAnswers(List<String> answers) {
        this.answers = answers;
    }

    public List<QuestionHistoryVo> getQuestionHistoryList() {
        return questionHistoryList;
    }

    public void setQuestionHistoryList(List<QuestionHistoryVo> questionHistoryList) {
        this.questionHistoryList = questionHistoryList;
    }

    public String getApproveFlag() {
        return approveFlag;
    }

    public void setApproveFlag(String approveFlag) {
        this.approveFlag = approveFlag;
    }

    public String getRejectFlag() {
        return rejectFlag;
    }

    public void setRejectFlag(String rejectFlag) {
        this.rejectFlag = rejectFlag;
    }

    public String getSaveFlag() {
        return saveFlag;
    }

    public void setSaveFlag(String saveFlag) {
        this.saveFlag = saveFlag;
    }

    public String getFinalLevel() {
        return finalLevel;
    }

    public void setFinalLevel(String finalLevel) {
        this.finalLevel = finalLevel;
    }

    public String getShowSaveFinal() {
        return showSaveFinal;
    }

    public void setShowSaveFinal(String showSaveFinal) {
        this.showSaveFinal = showSaveFinal;
    }

    public String getShowMode() {
        return showMode;
    }

    public void setShowMode(String showMode) {
        this.showMode = showMode;
    }

    public List<ActionHistoryVo> getActionHistoryVoList() {
        return actionHistoryVoList;
    }

    public void setActionHistoryVoList(List<ActionHistoryVo> actionHistoryVoList) {
        this.actionHistoryVoList = actionHistoryVoList;
    }

    public String getShowButtonForClose() {
        return showButtonForClose;
    }

    public void setShowButtonForClose(String showButtonForClose) {
        this.showButtonForClose = showButtonForClose;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }
    
    
    @Override
    public String success() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("success");
            logger.debug(" getCifNo : " + getCifNo());
            logger.debug(" getWarningHeaderId : " + getWarningHeaderId());
            logger.debug(" getEwsqWarningId : " + getEwsqWarningId());
            logger.debug(" getWarningType : " + getWarningType());
            logger.debug(" getInfoStatus : " + getInfoStatus());
        }
        
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if(titleVo != null){
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        }
        setCurrentUserRole(getCurrentUser() != null ?  getCurrentUser().getRoleId() : "");

        if (asstTopicVoList == null && titleVo != null) {
            //-------- Find 
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            filter.setWarningHeaderId(getWarningHeaderId());
            filter.setWarningId(getEwsqWarningId());
            filter.setWarningType(getWarningType());
            filter.setInfoStatus(getInfoStatus());
            findData(filter,false);
        }

        //find form history
         findQuestionHistory(this.cifNo);
         
        if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
            if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                showButtonForClose  = "";
                approveFlag         = BusinessConst.Flag.N;
                rejectFlag          = BusinessConst.Flag.N;
                saveFlag            = BusinessConst.Flag.N;
                showMode            = "true"; 
            }
            request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
        }
         
        return SUCCESS;
    }
    public void findQuestionHistory(String cif) throws Exception{
        List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cif, warningType);//warningHeaderBusiness.findWarningIdForQuestion(cif, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                    vo.setActionDetail(warningType);
                    vo.setWarningType(warningType);
                    vo.setCif(cif);
                    historyList = actionHistoryBusiness.findQuestionHistory(vo);
                    if (historyList != null && !historyList.isEmpty()) {
                        tmpVo = (QuestionHistoryVo) historyList.get(0);
                        vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                        vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                        vo.setActionUserId(tmpVo.getActionUserId());
                        vo.setActionDate(tmpVo.getActionDate());
                        vo.setApproveUserId(tmpVo.getApproveUserId());
                        vo.setApproveDate(tmpVo.getApproveDate());
                        vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                        vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                        vo.setCif(cif);
                        if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                            QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                            vo.setVersion(tmpQuestionVo.getVersion());
                            vo.setQuestionId(tmpQuestionVo.getQuestionId());
                        }
                        resultList.add(vo);
                    }  
                }
                if(resultList.size() > 0){
                    setQuestionHistoryList(resultList);
                }
            }
    }
    
     private void findData(AsstTopicVo filter , boolean requireOldData) throws Exception {
//        filter
//        1. warningId
//        2. questionId
//        3. version

        UserData userData = getCurrentUser();
        filter.setWarningHeaderId(warningHeaderId);
        filter.setInfoStatus(infoStatus);
        filter.setWarningId(ewsqWarningId);
        filter.setWarningType(warningType);
        filter.setInfoStatus(infoStatus);
        this.asstTopicVoList = asstQuestionBusiness.findQuestionQualitative(filter);
        if(asstTopicVoList != null && asstTopicVoList.size() > 0){
            for(AsstTopicVo asstTopicVoResult :  asstTopicVoList){
               if(asstTopicVoResult != null && !ValidatorUtil.isNullOrEmpty(asstTopicVoResult.getWarningDateStr())){
                    setWarningInfoDateStr(asstTopicVoResult.getWarningDateStr());
                    break;
               }
            }
            if(requireOldData){//--- Case Edit Only
            filter.setRequireOldAnswer(BusinessConst.Flag.Y);
            this.asstTopicVoListForOldAnswer = asstQuestionBusiness.findQuestionQualitative(filter);
            if(asstTopicVoListForOldAnswer != null && asstTopicVoListForOldAnswer.size() == 1){ //----- HAVE ONLY QUALI TOPIC
                AsstTopicVo oldAnswer = (AsstTopicVo)asstTopicVoListForOldAnswer.get(0);
                if(oldAnswer != null && oldAnswer.getAsstSubtopicVoList() != null){
                  for(AsstTopicVo asstTopicVoResult :  asstTopicVoList){
                         for(AsstSubtopicVo subTopicVo :  asstTopicVoResult.getAsstSubtopicVoList()){
                             for(AsstSubtopicVo subTopicVoOLD : oldAnswer.getAsstSubtopicVoList()){
                                if((subTopicVo.getTopicId() == subTopicVoOLD.getTopicId())&&(subTopicVo.getSubTopicId() == subTopicVoOLD.getSubTopicId())
                                        &&(subTopicVo.getQuestionId().equals(subTopicVoOLD.getQuestionId()))&&(subTopicVo.getVersion().equals(subTopicVoOLD.getVersion()))){
                                   subTopicVo.setOldAnswerQuali(subTopicVoOLD.getAnswer());
                                   subTopicVo.setOldAnswerSubtopicChoice(subTopicVoOLD.getAnswerSubtopicChoice());
                                   break;
                                }
                             }
                         }
                  }
                }
            }
            }
        }
        logger.debug(" findData infoStatus =" + infoStatus);
        if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.RMP.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
            approveFlag = BusinessConst.Flag.N;
            rejectFlag = BusinessConst.Flag.N;
            saveFlag = BusinessConst.Flag.N; //---3.1
            if (EWSConstantValue.ROLE_EDITOR_QULI.contains(userData.getRoleId()) || EWSConstantValue.ROLE_EDITOR_QULI_CO_OP.contains(userData.getRoleId())) {
                 if(!BusinessConst.UserRole.RISK_EDITOR.equals(userData.getRoleId())){
                     if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(userData, warningHeaderId))){
                        saveFlag = BusinessConst.Flag.Y;
                     }
                 }
            }
            //--------- Validate Buttom ----------------//
            if(BusinessConst.Flag.RMP.equals(infoStatus)|| BusinessConst.Flag.BRMP.equals(infoStatus)){
                WarningInfoVo infoVo =  warningInfoBusiness.findWarningInfoObj( filter.getWarningHeaderId(),  filter.getWarningId(),  filter.getWarningType());
                if(infoVo != null){
                    if(EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(infoVo.getHolderRole()) &&
                             EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(getCurrentUser().getRoleId())){
                        
                         if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(userData, warningHeaderId))){
                              saveFlag = BusinessConst.Flag.Y;
                         }
                    }else if((BusinessConst.UserRole.BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()))||
                            (BusinessConst.UserRole.CO_BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId()))){
                         if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(userData, warningHeaderId))){
                             saveFlag = BusinessConst.Flag.Y;
                         }
                    }else{
                         saveFlag = BusinessConst.Flag.N;
                    }
                }
            }
        } else if(EWSConstantValue.ROLE_APPROVE.contains(userData.getRoleId()) && BusinessConst.Flag.RMF.equals(infoStatus)){
              if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(userData, warningHeaderId))){
               approveFlag = BusinessConst.Flag.Y;
               rejectFlag = BusinessConst.Flag.Y;
               saveFlag = BusinessConst.Flag.N;
               editFlag = BusinessConst.Flag.Y;
              }else{
               approveFlag = BusinessConst.Flag.N;
               rejectFlag = BusinessConst.Flag.N;
               saveFlag = BusinessConst.Flag.N;
               editFlag = BusinessConst.Flag.N;
              }
        }

        this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(ewsqWarningId);

        if(!BusinessConst.Flag.COMPLETE.equals(infoStatus)){
            WarningInfoVo warningInfoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, ewsqWarningId, warningType);
            if (BusinessConst.Flag.Y.equals(warningInfoVo.getCloseFlag())) {
                if (EWSConstantValue.ROLE_APPROVE_CLOSE_JOB.contains(userData.getRoleId())) {
                     if(BusinessConst.UserRole.RISK_EDITOR.equals(userData.getRoleId())){
                          showButtonForClose = "C2";
                     }else if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(userData, warningHeaderId))){
                          showButtonForClose = "C2";
                     }else{
                          showButtonForClose = "";
                     }
                }
                approveFlag = BusinessConst.Flag.N;
                rejectFlag = BusinessConst.Flag.N;
                saveFlag = BusinessConst.Flag.N;
            } else {
                if (EWSConstantValue.ROLE_EDITOR_QULI.contains(userData.getRoleId())) {
                    //ตรวจสอบ CO คู่ว่ามีหรือไหม RM = ไม่มี CO_RM , AE = ไม่มี  CO_AE , BCM = ไม่มี CO_RESPONSEUNIT
                     if(BusinessConst.UserRole.RISK_EDITOR.equals(userData.getRoleId())){
                       showButtonForClose = "C1";
                     }else if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(userData, warningHeaderId))){
                       showButtonForClose = "C1";
                     }else{
                       showButtonForClose = "";
                     }
                }else if(EWSConstantValue.ROLE_EDITOR_QULI_CO_OP.contains(userData.getRoleId())){
                    showButtonForClose = "C1";
                }
            }
        }

        if (BusinessConst.Flag.Y.equals(saveFlag)) {
                showMode = "false";
            } else {
                showMode = "true"; 
            }
         }

   
    public String saveData() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("saveData");
            logger.debug("warningHeaderId =" + warningHeaderId);
            logger.debug("cifNo =" + cifNo);
            logger.debug("ewsqWarningId =" + ewsqWarningId);
            logger.debug("questionList =" + questionList != null ? questionList.size() : 0);
            logger.debug("requireList =" + requireList != null ? requireList.size() : 0);
            logger.debug("remarksTrig = " + ((remarksTrig == null || remarksTrig.isEmpty()) ? 0 : remarksTrig.size()));
            logger.debug("answers = " +  ((answers == null || answers.isEmpty()) ? 0 : answers.size()));
            logger.debug("answersTrig = " + ((answersTrig == null || answersTrig.isEmpty()) ? 0 : answersTrig.size()));
        }

        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if (questionList != null) {
            List<AsstAnswerVo> qualiAsstAnswerVoList = new ArrayList<AsstAnswerVo>();
            List<AsstAnswerVo> trigAsstAnswerVoList = new ArrayList<AsstAnswerVo>();
            List<WarningInfoVo> warningInfoVoList = new ArrayList<WarningInfoVo>();
            AsstAnswerVo asstAnswerVo;
            AsstAnswerVo asstAnswerTrigVo = new AsstAnswerVo();
            WarningInfoVo warningInfoVo;
            int tmp = 0 , tmpValidate = 0 , tmValidateReq = 0;
                /*** START Validate ****/
                if ("Save".equals(actionMode)) {
                    if(answers == null || answers.size() < questionList.size()){
                        throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                    }
                   for (String questionTempReq : questionList) {//---Check จำนวนคำตอบตามคำถาม
                    if ("1".equals(requireList.get(tmValidateReq))) {
                        if (answers.get(tmValidateReq) == null || answers.get(tmValidateReq).trim().length() <= 0) {
                             throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                        }
                     tmValidateReq++;
                   }
                   }
                    /**** Validate sub answer of qualitative (trigger answer)****/
                    if(answers != null){
                        int countSelYes = 0;
                        int countAnswerTrigYes = 0;
                        int indexTrig = 0;
                        for(String dataTemp : answers){
                            if(dataTemp != null && Integer.parseInt(dataTemp) == 1 ){
                                if(answersTrig != null ){
                                    if((answersTrig.size() > indexTrig ) && (answersTrig.get(indexTrig) != null)){
                                       countAnswerTrigYes++;
                                    }
                                }
                                countSelYes++;
                            }
                            indexTrig++;
                        }
                        // System.out.println(" countSelYes =   " + countSelYes);
                        // System.out.println(" countAnswerTrigYes =   " + countAnswerTrigYes);
                       if(answersTrig != null && countSelYes != countAnswerTrigYes){
                            throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                       }else if ((answersTrig == null || answersTrig.size() == 0) && countSelYes > 0){
                           throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                       }
                    }
                    /**** Validate Remark of trigger ****/
                 for (String questionTemp : questionList) { 
                      //System.out.println(" questionTemp = " + questionTemp);
                      //System.out.println(" tmpValidateTemp = " + tmpValidate);
                     if (answers != null && answers.size() > tmpValidate) {
                        if (answers.get(tmpValidate) != null) {
                            int choiceQualiIdTemp = Integer.parseInt(answers.get(tmpValidate));
                             //System.out.println(" choiceQualiIdTemp = " + choiceQualiIdTemp);
                            //-----------------------
                            if(choiceQualiIdTemp == 1 && answersTrig != null){
                                if(answersTrig.size() > tmpValidate){
                                if (answersTrig.get(tmpValidate) != null) {
                                    int choiceTrigIdTemp = Integer.parseInt(answersTrig.get(tmpValidate));
                                     //System.out.println(" choiceTrigIdTemp = " + choiceTrigIdTemp);
                                    if(questionTrigList != null && questionTrigList.length >= tmpValidate){
                                        String questionTrigTemp = (String)questionTrigList[tmpValidate][choiceTrigIdTemp-1];
                                        if(!ValidatorUtil.isNullOrEmpty(questionTrigTemp)){
                                             String[] sTrigTemp= questionTrigTemp.split("\\,", -1);
                                            if (sTrigTemp != null && sTrigTemp.length == 5) {
                                                    String remarkTrigTemp =  sTrigTemp[4] != null ? sTrigTemp[4] : "";
                                                    //System.out.println(" remarkTrigTemp = " + remarkTrigTemp);
                                                    if("1".equals(remarkTrigTemp)){
                                                         if (remarksTrig == null || remarksTrig.get(tmpValidate) == null || "".equals(remarksTrig.get(tmpValidate))) {
                                                              throw new BusinessException("กรุณากรอกหมายเหตุของคำตอบที่เลือกอื่นๆ ให้ครบทุกข้อ");
                                                         }
                                                        
                                                    }
                                            } 
                                        }
                                    }
                                }
                                }
                            }
                        }   
                  }
                 tmpValidate++;
                }
             }
            /**** END : Validate  ****/
            for (String question : questionList) {
                asstAnswerVo = new AsstAnswerVo();
                //System.out.println(" question = " + question);
                String questionIdSel = "";
                String versionSel ="";
                String topicIdSel = "";
                String subTopicIdSel = "";
                String warningIdSel = "";
                String warningTypeSel = "";
                String[] s = question.split("\\,", -1);
                if (s != null && s.length > 0) {
                     questionIdSel = s[0] ;
                     versionSel = s[1] ;
                     topicIdSel = s[2] ;
                     subTopicIdSel = s[3] ;
                     warningIdSel = s[4] ;
                     warningTypeSel = s[5] ;
                    asstAnswerVo.setQuestionId(questionIdSel);
                    asstAnswerVo.setVersion(versionSel);
                    asstAnswerVo.setTopicId(Integer.parseInt(topicIdSel));
                    asstAnswerVo.setSubTopicId(Integer.parseInt(subTopicIdSel));
                    if (s[4] != null && s[4].trim().length() > 0) {
                        asstAnswerVo.setWarningId(Integer.parseInt(s[4]));
                    }
                    if (s[5] != null && s[5].trim().length() > 0) {
                        asstAnswerVo.setWarningType(s[5]);
                    }
                }
                if (answers != null) {
                    if (answers.size() > tmp) {
                        if (answers.get(tmp) != null) {
                            int choiceQualiId = Integer.parseInt(answers.get(tmp));
                            asstAnswerVo.setChoiceId(choiceQualiId);
                            //-----------------------
                            if(choiceQualiId == 1 && answersTrig != null){
                                warningInfoVo = new WarningInfoVo();
                                if(answersTrig.size() > tmp){
                                if (answersTrig.get(tmp) != null) {
                                    int choiceTrigId = Integer.parseInt(answersTrig.get(tmp));
//                                    System.out.println("  answersTrig.get("+tmp+")  = " + choiceTrigId);
//                                    System.out.println("  choiceTrigId  = " + choiceTrigId);
                                    if(questionTrigList != null && questionTrigList.length >= tmp){
                                        String questionTrig = (String)questionTrigList[tmp][choiceTrigId-1];
                                        //System.out.println("  questionTrig  = " + questionTrig);
                                        if(!ValidatorUtil.isNullOrEmpty(questionTrig)){
                                             String[] sTrig = questionTrig.split("\\,", -1);
                                            if (sTrig != null && sTrig.length > 0) {
                                                    String questionIdTrigSel =  sTrig[0] != null ? sTrig[0] : "";
                                                    String versionTrigSel = sTrig[1] != null ? sTrig[1] : "";
                                                    String topicIdTrigSel = sTrig[2]  != null ? sTrig[2] : "";
                                                    String subTopicIdTrigSel = sTrig[3] != null ? sTrig[3] : "";
                                                    String remarkTrig =  sTrig[4] != null ? sTrig[4] : "";
                                                    String triggerItem = MoneyUtil.convertNumberToStringByFormat(Integer.parseInt(subTopicIdSel), MoneyUtil.patternTrigger);
                                                    String triggerCode = BusinessConst.WarningTypeCode.TRIG.concat(triggerItem);
                                                    asstAnswerTrigVo = new AsstAnswerVo();
                                                    asstAnswerTrigVo.setQuestionId(questionIdTrigSel);
                                                    asstAnswerTrigVo.setVersion(versionTrigSel);
                                                    asstAnswerTrigVo.setTopicId(Integer.parseInt(topicIdTrigSel));
                                                    asstAnswerTrigVo.setSubTopicId(Integer.parseInt(subTopicIdTrigSel));
                                                    asstAnswerTrigVo.setWarningType(triggerCode);
                                                    asstAnswerTrigVo.setChoiceId(choiceTrigId);
                                                    if (remarksTrig != null) {
                                                        if (remarksTrig.get(tmp) != null) {
                                                            asstAnswerTrigVo.setRemark(remarksTrig.get(tmp));
                                                            asstAnswerTrigVo.setChoiceReason(remarksTrig.get(tmp));
                                                        }
                                                    }
                                                    
                                                    //--------------- TRIG IN WARNING_INFO --------------------
                                                    warningInfoVo.setWarningHeaderId(warningHeaderId);
                                                    warningInfoVo.setCifNo(cifNo);
                                                    warningInfoVo.setCloseFlag(BusinessConst.Flag.N);
                                                    warningInfoVo.setSlaFlag(BusinessConst.Flag.Y);
                                                    warningInfoVo.setWarningDate(DateUtil.getCurrentDateTime());
                                                    warningInfoVo.setWarningType(triggerCode);
                                                    warningInfoVo.setStatus(BusinessConst.Flag.N);
                                                    warningInfoVo.setQuestionId(questionIdTrigSel);
                                                    warningInfoVo.setVersion(versionTrigSel);
                                                    warningInfoVo.setQualiWarningId(ewsqWarningId);
                                                    warningInfoVo.setRoleCode(getCurrentUser().getRoleId());
                                                    warningInfoVoList.add(warningInfoVo);
                                            }
                                            
                                        }
                                   
                                    }
                                  trigAsstAnswerVoList.add(asstAnswerTrigVo);
                                }
                               }
                            }
                            
                            if (asstAnswerVo.getWarningId() <= 0) {
                                asstAnswerVo.setWarningId(ewsqWarningId);
                            }
                            if (asstAnswerVo.getWarningType() == null || asstAnswerVo.getWarningType().trim().length() <= 0) {
                                asstAnswerVo.setWarningType(warningType);
                            }
                            asstAnswerVo.setWarningHeaderId(titleVo.getWarningHeaderId());
                            asstAnswerVo.setCifNo(titleVo.getCifNo());
                            qualiAsstAnswerVoList.add(asstAnswerVo);
                        }
                    }
                }
              tmp++;
            }
           if(trigAsstAnswerVoList.size() > 0){
                  logger.debug("------------------Call Service INSERT -----------");
                  logger.debug("actionMode = " + actionMode);
                  logger.debug("infoStatus = " + infoStatus);
                  logger.debug("warningType = " + warningType);
                int cifNoInt = 0;
                if(!ValidatorUtil.isNullOrEmpty(cifNo)){
                    cifNoInt  = Integer.parseInt(cifNo);
                }
                 asstQuestionBusiness.saveAsstAnswerTrigAndKeepAnswer(warningInfoVoList,trigAsstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType , cifNoInt , warningHeaderId,ewsqWarningId,BusinessConst.TEXT_STATIC.EVENT_SAVE);
            }
            if (qualiAsstAnswerVoList.size() > 0) {
                  logger.debug("actionMode = " + actionMode);
                  logger.debug("infoStatus = " + infoStatus);
                  logger.debug("warningType = " + warningType);
                 infoStatus = asstQuestionBusiness.saveAsstAnswerQuali(qualiAsstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType);
            } 
    }
      if ("Draft".equals(actionMode)) {
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            filter.setWarningHeaderId(titleVo.getWarningHeaderId());
            findData(filter, false);
            showSaveFinal = BusinessConst.Flag.N;  
        }
      if ("Save".equals(actionMode) && (getCurrentUser() != null && (BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())||
              BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())))) {
                logger.debug("----Before approve ewsqWarningId >>" + ewsqWarningId);
                logger.debug("questionId >>" + questionId);
                logger.debug("warningHeaderId >>" + warningHeaderId);
                logger.debug("warningType >>" + warningType);
                WarningInfoVo infoAfterApprove = warningInfoBusiness.findWarningInfoObj(warningHeaderId, ewsqWarningId, warningType);
                if(infoAfterApprove != null){ //--- For hide buttom after approve
                     setInfoStatus(infoAfterApprove.getStatus());
                     setActionMode("Approve");
                }
               doApprove();
      }
      return SUCCESS;
    }
    
    public String gotoBackPipeline() throws Exception {
        logger.debug("[gotoBackPipeline][Begin]");
        
        String backToPage   = "backTaskList";
        String forBackPage  = null;
        
        try{
            forBackPage = (String) request.getSession(false).getAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL);
            
            logger.debug("[gotoBackPipeline] forBackPage :: " + forBackPage);
            
            if(forBackPage!=null && !forBackPage.equals("")){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    backToPage = "backCloseJobTaskList";
                }else if(forBackPage.equals(BusinessConst.PAGE.PIPELINE)){
                    backToPage = "backTaskList";
                }
            }
            
            logger.debug("[gotoBackPipeline][End]");
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[gotoBackPipeline][End]");
        }
        
        return backToPage;
    }
    
    public String goCloseForm() throws Exception {
        return "closeJobScreen";
    }
      
    public String doApprove() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doApprove");
            logger.debug(" ewsqWarningId >> " +  ewsqWarningId);
            logger.debug(" questionId >> " +  questionId);
            logger.debug(" warningHeaderId >> " +  warningHeaderId);
        }
        //---------Can send OLD Answer :09/06/2015---//
        String versionAnswerOld = "";
        if(ewsqWarningId > 0 && !ValidatorUtil.isNullOrEmpty(questionId)){
             versionAnswerOld = asstAnswerService.findAnswerVersionByWarningIdAndQuestionId(ewsqWarningId, questionId);
        }
        if(ValidatorUtil.isNullOrEmpty(versionAnswerOld)){ //--- Is null or blank
             versionAnswerOld = version;
        } 
        //----------------------------------------//    
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        AsstTopicVo asstTopicVo = new AsstTopicVo();
        asstTopicVo.setWarningHeaderId(warningHeaderId);
        asstTopicVo.setWarningType(warningType);
        asstTopicVo.setWarningId(ewsqWarningId);
        asstTopicVo.setQuestionId(questionId);
        asstTopicVo.setVersion(versionAnswerOld);
        asstTopicVo.setCifNo(titleVo.getCifNo());
        asstTopicVo.setCustName(titleVo.getCustName());
        asstQuestionBusiness.approveQuestion(asstTopicVo, getCurrentUser(), infoStatus, actionMode , true);

        return SUCCESS;
    }
    
    public String showPopupAddRemark() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("showPopupAddRemark");
        }
        return "showPopupAddRemark";
    }
     
    public String goApproveClose() throws Exception {
        WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
        warningHeaderVo.setWarningHeaderId(warningHeaderId);
        warningHeaderVo.setCif(cifNo);
        warningHeaderVo.setStatus(BusinessConst.Flag.COMPLETE);

        warningHeaderBusiness.closeJob(warningHeaderVo, getCurrentUser(), "", "อนุมัติปิดงาน", "Approve", ewsqWarningId, warningType);
        
        success();
        return SUCCESS;
    }
    
      public String doEdit() throws Exception {
       if (logger.isDebugEnabled()) {
            logger.debug("doEdit");
            logger.debug(" getCifNo : " + getCifNo());
            logger.debug(" getWarningHeaderId : " + getWarningHeaderId());
            logger.debug(" getEwsqWarningId : " + getEwsqWarningId());
            logger.debug(" getWarningType : " + getWarningType());
            logger.debug(" getInfoStatus : " + getInfoStatus());
        }
        
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if(titleVo != null){
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        }
        setCurrentUserRole(getCurrentUser() != null ?  getCurrentUser().getRoleId() : "");

        if (asstTopicVoList == null && titleVo != null) {
            //-------- Find 
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            filter.setWarningHeaderId(getWarningHeaderId());
            filter.setWarningId(getEwsqWarningId());
            filter.setWarningType(getWarningType());
            filter.setInfoStatus(getInfoStatus());
            findData(filter,true);
        }

        //find form history
         findQuestionHistory(this.cifNo);
         
        if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
            if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                showButtonForClose  = "";
                approveFlag         = BusinessConst.Flag.N;
                rejectFlag          = BusinessConst.Flag.N;
                saveFlag            = BusinessConst.Flag.N;
                showMode            = "true"; 
            }
            request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
        }
        if(BusinessConst.Flag.EDIT.equals(checkCOOPWithCurrentLogin(getCurrentUser(), warningHeaderId))){
            approveFlag = BusinessConst.Flag.N;
            editFlag = BusinessConst.Flag.N;
            editRadioQualiFlag = BusinessConst.Flag.Y;
            buttonSetOfEditFlag = BusinessConst.Flag.Y;
            rejectFlag = BusinessConst.Flag.N;
            showButtonForClose = BusinessConst.Flag.N;
            showMode = "false";
        }else{
            approveFlag = BusinessConst.Flag.N;
            editFlag = BusinessConst.Flag.N;
            editRadioQualiFlag = BusinessConst.Flag.N;
            buttonSetOfEditFlag = BusinessConst.Flag.N;
            rejectFlag = BusinessConst.Flag.N;
            showButtonForClose = BusinessConst.Flag.N;
            showMode = "false";
        }
       
         
        return SUCCESS;
      }
      
       public String saveDataEdit() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("saveDataEdit");
            logger.debug("warningHeaderId =" + warningHeaderId);
            logger.debug("cifNo =" + cifNo);
            logger.debug("ewsqWarningId =" + ewsqWarningId);
            logger.debug("questionList =" + questionList != null ? questionList.size() : 0);
            logger.debug("requireList =" + requireList != null ? requireList.size() : 0);
            logger.debug("remarksTrig = " + ((remarksTrig == null || remarksTrig.isEmpty()) ? 0 : remarksTrig.size()));
            logger.debug("answers = " +  ((answers == null || answers.isEmpty()) ? 0 : answers.size()));
            logger.debug("answersTrig = " + ((answersTrig == null || answersTrig.isEmpty()) ? 0 : answersTrig.size()));
        }

        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if (questionList != null) {
            List<AsstAnswerVo> qualiAsstAnswerVoList = new ArrayList<AsstAnswerVo>();
            List<AsstAnswerVo> trigAsstAnswerVoList = new ArrayList<AsstAnswerVo>();
            List<WarningInfoVo> warningInfoVoList = new ArrayList<WarningInfoVo>();
            AsstAnswerVo asstAnswerVo;
            AsstAnswerVo asstAnswerTrigVo = new AsstAnswerVo();
            WarningInfoVo warningInfoVo;
            int tmp = 0 , tmpValidate = 0 , tmValidateReq = 0;
                if ("Save".equals(actionMode)) {
                    if(answers == null || answers.size() < questionList.size()){
                        throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                    }
                   for (String questionTempReq : questionList) {//---Check จำนวนคำตอบตามคำถาม
                    if ("1".equals(requireList.get(tmValidateReq))) {
                        if (answers.get(tmValidateReq) == null || answers.get(tmValidateReq).trim().length() <= 0) {
                             throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                        }
                     tmValidateReq++;
                   }
                   }
                    /**** Validate sub answer of qualitative (trigger answer)****/
                    if(answers != null){
                        int countSelYes = 0;
                        int countAnswerTrigYes = 0;
                        int indexTrig = 0;
                        for(String dataTemp : answers){
                            if(dataTemp != null && Integer.parseInt(dataTemp) == 1 ){
                                if(answersTrig != null ){
                                    if((answersTrig.size() > indexTrig ) && (answersTrig.get(indexTrig) != null)){
                                       countAnswerTrigYes++;
                                    }
                                }
                                countSelYes++;
                            }
                            indexTrig++;
                        }
                         //System.out.println(" countSelYes =   " + countSelYes);
                         //System.out.println(" countAnswerTrigYes =   " + countAnswerTrigYes);
                       if(answersTrig != null && countSelYes != countAnswerTrigYes){
                            throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                       }else if ((answersTrig == null || answersTrig.size() == 0) && countSelYes > 0){
                           throw new BusinessException("กรุณาตอบคำถามในข้อที่มีเครื่องหมาย <span class='rqField'>*</span> ให้ครบทุกข้อ");
                       }
                    }
                    /**** Validate Remark of trigger ****/
                 for (String questionTemp : questionList) { 
                      //System.out.println(" questionTemp = " + questionTemp);
                     // System.out.println(" tmpValidateTemp = " + tmpValidate);
                     if (answers != null && answers.size() > tmpValidate) {
                        if (answers.get(tmpValidate) != null) {
                            int choiceQualiIdTemp = Integer.parseInt(answers.get(tmpValidate));
                             //System.out.println(" choiceQualiIdTemp = " + choiceQualiIdTemp);
                            //-----------------------
                            if(choiceQualiIdTemp == 1 && answersTrig != null){
                                if(answersTrig.size() > tmpValidate){
                                if (answersTrig.get(tmpValidate) != null) {
                                    int choiceTrigIdTemp = Integer.parseInt(answersTrig.get(tmpValidate));
                                    // System.out.println(" choiceTrigIdTemp = " + choiceTrigIdTemp);
                                    if(questionTrigList != null && questionTrigList.length >= tmpValidate){
                                        String questionTrigTemp = (String)questionTrigList[tmpValidate][choiceTrigIdTemp-1];
                                        if(!ValidatorUtil.isNullOrEmpty(questionTrigTemp)){
                                             String[] sTrigTemp= questionTrigTemp.split("\\,", -1);
                                            if (sTrigTemp != null && sTrigTemp.length == 5) {
                                                    String remarkTrigTemp =  sTrigTemp[4] != null ? sTrigTemp[4] : "";
                                                    //System.out.println(" remarkTrigTemp = " + remarkTrigTemp);
                                                    if("1".equals(remarkTrigTemp)){
                                                         if (remarksTrig == null || remarksTrig.get(tmpValidate) == null || "".equals(remarksTrig.get(tmpValidate))) {
                                                              throw new BusinessException("กรุณากรอกหมายเหตุของคำตอบที่เลือกอื่นๆ ให้ครบทุกข้อ");
                                                         }
                                                        
                                                    }
                                            } 
                                        }
                                    }
                                }
                                }
                            }
                        }   
                  }
                 tmpValidate++;
                }
             }
                  /**** END : Validate  ****/
            for (String question : questionList) {
                asstAnswerVo = new AsstAnswerVo();
                //System.out.println(" question = " + question);
                String questionIdSel = "";
                String versionSel ="";
                String topicIdSel = "";
                String subTopicIdSel = "";
                String warningIdSel = "";
                String warningTypeSel = "";
                String[] s = question.split("\\,", -1);
                if (s != null && s.length > 0) {
                    questionIdSel = s[0] ;
                    versionSel = s[1] ;
                    topicIdSel = s[2] ;
                    subTopicIdSel = s[3] ;
                    warningIdSel = s[4] ;
                    warningTypeSel = s[5] ;
                    asstAnswerVo.setQuestionId(questionIdSel);
                    asstAnswerVo.setVersion(versionSel);
                    asstAnswerVo.setTopicId(Integer.parseInt(topicIdSel));
                    asstAnswerVo.setSubTopicId(Integer.parseInt(subTopicIdSel));
                    if (s[4] != null && s[4].trim().length() > 0) {
                        asstAnswerVo.setWarningId(Integer.parseInt(s[4]));
                    }
                    if (s[5] != null && s[5].trim().length() > 0) {
                        asstAnswerVo.setWarningType(s[5]);
                    }
                }
                if (answers != null) {
                    if (answers.size() > tmp) {
                        if (answers.get(tmp) != null) {
                            int choiceQualiId = Integer.parseInt(answers.get(tmp));
                            asstAnswerVo.setChoiceId(choiceQualiId);
                            //-----------------------
                            if(choiceQualiId == 1 && answersTrig != null){
                                warningInfoVo = new WarningInfoVo();
                                if(answersTrig.size() > tmp){
                                if (answersTrig.get(tmp) != null) {
                                    int choiceTrigId = Integer.parseInt(answersTrig.get(tmp));
                                    //System.out.println("  answersTrig.get("+tmp+")  = " + choiceTrigId);
                                    //System.out.println("  choiceTrigId  = " + choiceTrigId);
                                    if(questionTrigList != null && questionTrigList.length >= tmp){
                                        String questionTrig = (String)questionTrigList[tmp][choiceTrigId-1];
                                        //System.out.println("  questionTrig  = " + questionTrig);
                                        if(!ValidatorUtil.isNullOrEmpty(questionTrig)){
                                             String[] sTrig = questionTrig.split("\\,", -1);
                                            if (sTrig != null && sTrig.length > 0) {
                                                    String questionIdTrigSel =  sTrig[0] != null ? sTrig[0] : "";
                                                    String versionTrigSel = sTrig[1] != null ? sTrig[1] : "";
                                                    String topicIdTrigSel = sTrig[2]  != null ? sTrig[2] : "";
                                                    String subTopicIdTrigSel = sTrig[3] != null ? sTrig[3] : "";
                                                    String remarkTrig =  sTrig[4] != null ? sTrig[4] : "";
                                                    //System.out.println("  questionIdTrigSel  = " + questionIdTrigSel);
                                                    //System.out.println("  versionTrigSel  = " + versionTrigSel);
                                                    String triggerItem = MoneyUtil.convertNumberToStringByFormat(Integer.parseInt(subTopicIdSel), MoneyUtil.patternTrigger);
                                                    String triggerCode = BusinessConst.WarningTypeCode.TRIG.concat(triggerItem);
                                                    //System.out.println("  triggerCode  = " + triggerCode);
                                                    asstAnswerTrigVo = new AsstAnswerVo();
                                                    asstAnswerTrigVo.setQuestionId(questionIdTrigSel);
                                                    asstAnswerTrigVo.setVersion(versionTrigSel);
                                                    asstAnswerTrigVo.setTopicId(Integer.parseInt(topicIdTrigSel));
                                                    asstAnswerTrigVo.setSubTopicId(Integer.parseInt(subTopicIdTrigSel));
                                                    asstAnswerTrigVo.setWarningType(triggerCode);
                                                    asstAnswerTrigVo.setChoiceId(choiceTrigId);
                                                    //System.out.println("  tmp  ===> " + tmp);
                                                    if (remarksTrig != null) {
                                                        if (remarksTrig.get(tmp) != null) {
                                                             //System.out.println("  remarksTrig.get(tmp)  = " + remarksTrig.get(tmp));
                                                            asstAnswerTrigVo.setRemark(remarksTrig.get(tmp));
                                                            asstAnswerTrigVo.setChoiceReason(remarksTrig.get(tmp));
                                                        }
                                                    }
                                                    
                                                    //--------------- TRIG IN WARNING_INFO --------------------
                                                    warningInfoVo.setWarningHeaderId(warningHeaderId);
                                                    warningInfoVo.setCifNo(cifNo);
                                                    warningInfoVo.setCloseFlag(BusinessConst.Flag.N);
                                                    warningInfoVo.setSlaFlag(BusinessConst.Flag.Y);
                                                    warningInfoVo.setWarningDate(DateUtil.getCurrentDateTime());
                                                    warningInfoVo.setWarningType(triggerCode);
                                                    warningInfoVo.setStatus(BusinessConst.Flag.N);
                                                    warningInfoVo.setQuestionId(questionIdTrigSel);
                                                    warningInfoVo.setVersion(versionTrigSel);
                                                    warningInfoVo.setQualiWarningId(ewsqWarningId);
                                                    warningInfoVoList.add(warningInfoVo);
                                            }
                                            
                                        }
                                   
                                    }
                                  trigAsstAnswerVoList.add(asstAnswerTrigVo);
                                }
                               }
                            }
                            
                            if (asstAnswerVo.getWarningId() <= 0) {
                                asstAnswerVo.setWarningId(ewsqWarningId);
                            }
                            if (asstAnswerVo.getWarningType() == null || asstAnswerVo.getWarningType().trim().length() <= 0) {
                                asstAnswerVo.setWarningType(warningType);
                            }
                            asstAnswerVo.setWarningHeaderId(titleVo.getWarningHeaderId());
                            asstAnswerVo.setCifNo(titleVo.getCifNo());
                            qualiAsstAnswerVoList.add(asstAnswerVo);
                        }
                    }
                }
              tmp++;
            }
           if(trigAsstAnswerVoList.size() > 0){
                  logger.debug("------------------Call Service INSERT -----------");
                  logger.debug("actionMode = " + actionMode);
                  logger.debug("infoStatus = " + infoStatus);
                  logger.debug("warningType = " + warningType);
                int cifNoInt = 0;
                if(!ValidatorUtil.isNullOrEmpty(cifNo)){
                    cifNoInt  = Integer.parseInt(cifNo);
                }
                //asstQuestionBusiness.saveAsstAnswerTrig(warningInfoVoList,trigAsstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType , cifNoInt , warningHeaderId);
                asstQuestionBusiness.saveAsstAnswerTrigAndKeepAnswer(warningInfoVoList,trigAsstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType , cifNoInt , warningHeaderId,getEwsqWarningId(),BusinessConst.TEXT_STATIC.EVENT_EDIT);
            }
            if (qualiAsstAnswerVoList.size() > 0) {
                 System.out.println(" asstAnswerVoList.size() >>>> " + qualiAsstAnswerVoList.size());
                  logger.debug("actionMode = " + actionMode);
                  logger.debug("infoStatus = " + infoStatus);
                  logger.debug("warningType = " + warningType);
                 infoStatus = asstQuestionBusiness.saveAsstAnswerQuali(qualiAsstAnswerVoList, getCurrentUser(), actionMode, infoStatus, warningType);
            } 
    }
     
     AsstTopicVo filter = new AsstTopicVo();
     filter.setCifNo(titleVo.getCifNo());
     filter.setWarningHeaderId(titleVo.getWarningHeaderId());
     findData(filter,false);
     showSaveFinal = BusinessConst.Flag.N;  
        if("Draft".equals(actionMode)){
            doEdit();
        }else if ("Save".equals(actionMode) && (getCurrentUser() != null && ((BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()))||
                (BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId()))))){
                   logger.debug("----Before approve ewsqWarningId >>" + ewsqWarningId);
                   logger.debug("questionId >>" + questionId);
                   logger.debug("warningHeaderId >>" + warningHeaderId);
                   logger.debug("warningType >>" + warningType);
                   WarningInfoVo infoAfterApprove = warningInfoBusiness.findWarningInfoObj(warningHeaderId, ewsqWarningId, warningType);
                   if(infoAfterApprove != null){ //--- For hide buttom after approve
                        setInfoStatus(infoAfterApprove.getStatus());
                        setActionMode("Approve");
                   }
          doApprove();
          editFlag = BusinessConst.Flag.N;
          rejectFlag = BusinessConst.Flag.N;
          approveFlag = BusinessConst.Flag.N;
          saveFlag = BusinessConst.Flag.N;
       }
      return SUCCESS;
    }
    
       
     public String doCancleNoEdit() throws Exception {
           success();
           return SUCCESS;
    }
       
     public String goQualiHistory() throws Exception {
           if (logger.isDebugEnabled()) {
            logger.debug("goQualiHistory");
            logger.debug(" warningHeaderIdHistory >>" + warningHeaderIdHistory);
            logger.debug(" warningIdHistory >>" + warningIdHistory);
            logger.debug(" questionIdHistory >>" + questionIdHistory);
            logger.debug(" versionHistory >>" + versionHistory);
            logger.debug(" warningTypeHistory >>" + warningTypeHistory);
            logger.debug(" actionDateHistory " +actionDateHistory);
        }
       try{
           TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
           
          if(!ValidatorUtil.isNullOrEmpty(warningHeaderIdHistory) && !ValidatorUtil.isNullOrEmpty(warningIdHistory) && titleVo != null && !ValidatorUtil.isNullOrEmpty(titleVo.getCifNo())){
            int historyWarningHeaderId = Integer.parseInt(warningHeaderIdHistory);
            int historyWarningId = Integer.parseInt(warningIdHistory);
            AsstTopicVo filter = new AsstTopicVo();
            filter.setCifNo(titleVo.getCifNo());
            filter.setWarningHeaderId(historyWarningHeaderId);
            filter.setWarningId(historyWarningId);
            filter.setWarningType(warningTypeHistory);
            filter.setInfoStatus(BusinessConst.Flag.COMPLETE);
            this.asstTopicVoListHistory = asstQuestionBusiness.findQuestionQualitative(filter);
            if(asstTopicVoListHistory != null && asstTopicVoListHistory.size() > 0){
                for(AsstTopicVo asstTopicVoResult :  asstTopicVoListHistory){
                   if(asstTopicVoResult != null && !ValidatorUtil.isNullOrEmpty(asstTopicVoResult.getWarningDateStr())){
                        setWarningInfoDateStr(asstTopicVoResult.getWarningDateStr());
                        break;
                   }
                }
              }
          }
          showMode = "true"; 
       }catch(Exception e){
       }
        return "qualiHistoryScreen";
     }
     
     private String checkCOOPWithCurrentLogin(UserData userData , int warningHeaderId) throws Exception{
       String result = BusinessConst.Flag.VIEW;    
       logger.debug("--------- checkCOOPWithCurrentLogin ---------");
       logger.debug(" warningHeaderId >>" +  warningHeaderId);
       logger.debug(" userData.getRoleId() >>" +  userData != null ? userData.getRoleId() : "");
         if(warningHeaderId > 0){
            WarningHeaderVo headerVo = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
            if(headerVo != null){
            logger.debug(" getCoAoId >>" +  headerVo.getCoAoId());
            logger.debug(" getCoAeId >>" +  headerVo.getCoAeId());
            logger.debug(" getCoRmId >>" +  headerVo.getCoRmId());
            logger.debug(" getCoRespUnitStr >>" +  headerVo.getCoRespUnitStr());
            //ไม่มี CO ถึงทำงานได้
            if(BusinessConst.UserRole.AO.equals(userData.getRoleId()) || BusinessConst.UserRole.AE.equals(userData.getRoleId()) ||
                    BusinessConst.UserRole.RM.equals(userData.getRoleId()) || BusinessConst.UserRole.BCM.equals(userData.getRoleId())){
               
                if(StringUtil.isEmpty(headerVo.getCoRespUnitStr()) || "0".equals(headerVo.getCoRespUnitStr())){
                     result = BusinessConst.Flag.EDIT;    
                }
            }else if(EWSConstantValue.ROLE_EDITOR_QULI_CO_OP.contains(userData.getRoleId())){
                   result = BusinessConst.Flag.EDIT;    
            }
            }
         }
        logger.debug(" result >>" +  result);
        return result; 
     }
    //-------------------------------------------- GET & SET -------------------------------------------------//
     public List<String> getAnswersTrig() {
        return answersTrig;
    }

    public void setAnswersTrig(List<String> answersTrig) {
        this.answersTrig = answersTrig;
    }

    public List<String> getRequireList() {
        return requireList;
    }

    public void setRequireList(List<String> requireList) {
        this.requireList = requireList;
    }

    public List<String> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<String> questionList) {
        this.questionList = questionList;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }

    public List<String> getRemarksTrig() {
        return remarksTrig;
    }

    public void setRemarksTrig(List<String> remarksTrig) {
        this.remarksTrig = remarksTrig;
    }

    public List<String> getRemarks() {
        return remarks;
    }

    public void setRemarks(List<String> remarks) {
        this.remarks = remarks;
    }

    public String[][] getQuestionTrigList() {
        return questionTrigList;
    }

    public void setQuestionTrigList(String[][] questionTrigList) {
        this.questionTrigList = questionTrigList;
    }

  
    public int getEwsqWarningId() {
        return ewsqWarningId;
    }

    public void setEwsqWarningId(int ewsqWarningId) {
        this.ewsqWarningId = ewsqWarningId;
    }

    public String getCurrentUserRole() {
        return currentUserRole;
    }

    public void setCurrentUserRole(String currentUserRole) {
        this.currentUserRole = currentUserRole;
    }

    public String getWarningInfoDateStr() {
        return warningInfoDateStr;
    }

    public void setWarningInfoDateStr(String warningInfoDateStr) {
        this.warningInfoDateStr = warningInfoDateStr;
    }

    public String getEditRadioQualiFlag() {
        return editRadioQualiFlag;
    }

    public void setEditRadioQualiFlag(String editRadioQualiFlag) {
        this.editRadioQualiFlag = editRadioQualiFlag;
    }

    public String getEditFlag() {
        return editFlag;
    }

    public void setEditFlag(String editFlag) {
        this.editFlag = editFlag;
    }

    public String getButtonSetOfEditFlag() {
        return buttonSetOfEditFlag;
    }

    public void setButtonSetOfEditFlag(String buttonSetOfEditFlag) {
        this.buttonSetOfEditFlag = buttonSetOfEditFlag;
    }

    public List<String> getAnswersQualiTemp() {
        return answersQualiTemp;
    }

    public void setAnswersQualiTemp(List<String> answersQualiTemp) {
        this.answersQualiTemp = answersQualiTemp;
    }

    public List<String> getAnswersTrigTemp() {
        return answersTrigTemp;
    }

    public void setAnswersTrigTemp(List<String> answersTrigTemp) {
        this.answersTrigTemp = answersTrigTemp;
    }

    public List<AsstTopicVo> getAsstTopicVoListForOldAnswer() {
        return asstTopicVoListForOldAnswer;
    }

    public void setAsstTopicVoListForOldAnswer(List<AsstTopicVo> asstTopicVoListForOldAnswer) {
        this.asstTopicVoListForOldAnswer = asstTopicVoListForOldAnswer;
    }

    public String getWarningIdHistory() {
        return warningIdHistory;
    }

    public void setWarningIdHistory(String warningIdHistory) {
        this.warningIdHistory = warningIdHistory;
    }

    public String getWarningHeaderIdHistory() {
        return warningHeaderIdHistory;
    }

    public void setWarningHeaderIdHistory(String warningHeaderIdHistory) {
        this.warningHeaderIdHistory = warningHeaderIdHistory;
    }

    public String getActionDateHistory() {
        return actionDateHistory;
    }

    public void setActionDateHistory(String actionDateHistory) {
        this.actionDateHistory = actionDateHistory;
    }

    public String getVersionHistory() {
        return versionHistory;
    }

    public void setVersionHistory(String versionHistory) {
        this.versionHistory = versionHistory;
    }

    public String getQuestionIdHistory() {
        return questionIdHistory;
    }

    public void setQuestionIdHistory(String questionIdHistory) {
        this.questionIdHistory = questionIdHistory;
    }

    public String getWarningTypeHistory() {
        return warningTypeHistory;
    }

    public void setWarningTypeHistory(String warningTypeHistory) {
        this.warningTypeHistory = warningTypeHistory;
    }

    public List<AsstTopicVo> getAsstTopicVoListHistory() {
        return asstTopicVoListHistory;
    }

    public void setAsstTopicVoListHistory(List<AsstTopicVo> asstTopicVoListHistory) {
        this.asstTopicVoListHistory = asstTopicVoListHistory;
    }
    
    
}
