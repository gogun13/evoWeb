/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AccountDetailHistoryBusiness;
import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.ConfigBusiness;
import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.CustomerPortfolioBusiness;
import com.ktb.ewsl.business.IndividualODAccountBusiness;
import com.ktb.ewsl.business.KtbOrganizationBusiness;
import com.ktb.ewsl.business.TodayMovementBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.vo.AccountDetailVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.IndividualForBreakVo;
import com.ktb.ewsl.vo.IndividualODAccountVo;
import com.ktb.ewsl.vo.KtbOrganization;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.ReportVO;
import com.ktb.ewsl.vo.RptIndividualAccountVo;
import com.ktb.ewsl.vo.RptIndividualRiskLevelVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class CustomerPortfolioDetailAction  extends BaseAction{
    
     private static final Logger log = Logger.getLogger(CustomerPortfolioDetailAction.class);
     private SearchBean searchBean;
     private String cifNo;
     private int warningHeaderId;
     private String custfullName;
     private String responseUnit;
     private String responseUnitName;
     private String rmId;
     private String aeId;
     private String rmName;
     private String aeName;
     private List<RptIndividualRiskLevelVo> ewsRiskList;
     private List<RptIndividualRiskLevelVo> quantiList;
     private List<RptIndividualRiskLevelVo> qualiList;
     private String lastUpdateRiskLevel;
     private String lastRiskLevel;
     private int tabIndex = 0;
     private List<RptIndividualAccountVo> rptIndividualAcctList;
     private List<IndividualODAccountVo> odAccountVoList;
     private List<IndividualODAccountVo> beforeODAccountVoList;
     private List<AccountDetailVo> accountDetailVoList;
     //-------------
    private String pageEntryFrom;
    private String backCifNo;
    private String backCustomerName;
    private String backPage;
    private InputStream fileStream;
    private String exportFileName;
     
    private List<IndividualForBreakVo> individualForBreakVoList;
    private String historicalWarningId;
    private String historicalWarningHeaderId;
    private String historicalActionDate;
    private String historicalVersion;
    private String historicalQuestionId;
    private String historicalWarningType;
    private String backFromHistoricalPage;
    
    private List<QuestionHistoryVo>  qualiQuestionHistoryList;
    private List<QuestionHistoryVo>  finQuestionHistoryList;
    private List<QuestionHistoryVo>  latePayQuestionHistoryList;
    private List<QuestionHistoryVo>  action1QuestionHistoryList;
    private List<QuestionHistoryVo>  action2QuestionHistoryList;

    //R4
    private String workLineNo;
    private String workLineDesc;
    private String organizationGroupNo;
    private String organizationGroupDesc;
    private String backRmIdOrAeId;
    private String backWorkLine;
    private String backOrganizationGroup;
    private String backCostCenter;
    
    @Autowired
    private CustomerPortfolioBusiness customerPortfolioBusiness;
    @Autowired
    private CustomerBusiness customerBusiness;
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    @Autowired
    private TodayMovementBusiness todayMovementBusiness;
    @Autowired
    private IndividualODAccountBusiness individualODAccountBusiness;
    @Autowired
    private ConfigBusiness configBusiness;
    @Autowired
    private AccountDetailHistoryBusiness accountDetailHistoryBusiness;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness; 
    @Autowired
    private KtbOrganizationBusiness ktbOrganizationBusiness;
    @Override
    public String success() throws Exception {
        if (log.isDebugEnabled()) {
            log.debug("IndividualTrackRecordAction.success");
            log.debug(" warningHeaderId = " + warningHeaderId);
            log.debug(" cifNo =" + cifNo);
            log.debug(" custfullName =" + custfullName);
            log.debug(" responseUnit =" + responseUnit);
            log.debug(" responseUnitName =" + responseUnitName);
            log.debug(" rmId =" + rmId);
            log.debug(" aeId =" + aeId);
            log.debug(" backFromHistoricalPage =" + backFromHistoricalPage);
            //log.debug(" headerStatus =" + headerStatus);
            
        }

        if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
            int cifInt = Integer.parseInt(cifNo);
            CustomerVo custVo = customerBusiness.selectCustomerByCifWithCostCenterName(Integer.valueOf(cifInt));
            if (custVo != null) {
                setCustfullName(custVo.getCustName());
                setResponseUnit(custVo.getResponseUnit());
                setResponseUnitName(custVo.getResponseUnitName());
                setRmId(custVo.getRmId());
                setAeId(custVo.getAeId());
                
                KtbOrganization ktbOrganization = ktbOrganizationBusiness.getOrganizationByCostcenter(custVo.getResponseUnit());
                if(ktbOrganization != null){
                    //สายงาน
                    if(!ValidatorUtil.isNullOrEmpty(ktbOrganization.getBusinessUnitCode())){
                        KtbOrganization department = ktbOrganizationBusiness.getOrganizationByCostcenter(ktbOrganization.getBusinessUnitCode().toString());
                        if(department != null && department.getCostCenterName()!=null){
                            setWorkLineNo(department.getCostCenterCode().toString());
                            setWorkLineDesc(department.getCostCenterName());
                        }
                    }
                    //กลุ่มงาน
                    if(!ValidatorUtil.isNullOrEmpty(ktbOrganization.getGroupCode())){
                        KtbOrganization group = ktbOrganizationBusiness.getOrganizationByCostcenter(ktbOrganization.getGroupCode().toString());
                        if(group != null && group.getCostCenterName()!=null){
                            setOrganizationGroupNo(group.getCostCenterCode().toString());
                            setOrganizationGroupDesc(group.getCostCenterName());
                        }
                    }
                }
                
                if (!ValidatorUtil.isNullOrEmpty(custVo.getRmId())) {
                    UserData rmUser = ktbEmpDirectoryBusiness.findById(custVo.getRmId());
                    if ((rmUser != null) && (!ValidatorUtil.isNullOrEmpty(rmUser.getEmpNameThai())) && (!ValidatorUtil.isNullOrEmpty(rmUser.getEmpSurnameThai()))) {
                        setRmName(rmUser.getTitleNameThai() + " " + rmUser.getEmpNameThai() + " " + rmUser.getEmpSurnameThai());
                    }
                }
                if (!ValidatorUtil.isNullOrEmpty(custVo.getAeId())) {
                    UserData aeUser = ktbEmpDirectoryBusiness.findById(custVo.getAeId());
                    if ((aeUser != null) && (!ValidatorUtil.isNullOrEmpty(aeUser.getEmpNameThai())) && (!ValidatorUtil.isNullOrEmpty(aeUser.getEmpSurnameThai()))) {
                        setAeName(aeUser.getTitleNameThai() + " " + aeUser.getEmpNameThai() + " " + aeUser.getEmpSurnameThai());
                    }
                }
            }
            
            if(!ValidatorUtil.isNullOrEmpty(backFromHistoricalPage)){
                clickHistorical();
            }else{
            clickEWSRiskLevel();
        }
            
            
        }
        return SUCCESS;
    }
    
     public String clickEWSRiskLevel() throws Exception {
        try {
            if (log.isDebugEnabled()) {
                log.debug(" warningHeaderId = " + warningHeaderId);
                log.debug(" cifNo =" + cifNo);
            }
            ewsRiskList = new ArrayList<RptIndividualRiskLevelVo>();
            quantiList = new ArrayList<RptIndividualRiskLevelVo>();
            qualiList = new ArrayList<RptIndividualRiskLevelVo>();
            if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
                Integer cif = Integer.parseInt(cifNo);
                ewsRiskList = customerPortfolioBusiness.getIndividualRiskLevel(cif, BusinessConst.EWS_TYPE.EWS_RISK_LEVEL);
                quantiList = customerPortfolioBusiness.getIndividualRiskLevel(cif, BusinessConst.EWS_TYPE.EWS_QUANTITATIVE_BEHAVIOR_MODEL);
                qualiList = customerPortfolioBusiness.getIndividualRiskLevel(cif, BusinessConst.EWS_TYPE.EWS_QUALITATIVE_ASSESSMENT);
            }
            if (!ewsRiskList.isEmpty()) {
                RptIndividualRiskLevelVo vo = ewsRiskList.get(0);
                setLastRiskLevel(vo.getRiskLevel());
                setLastUpdateRiskLevel(vo.getRiskDateStr());
            }
            
            this.tabIndex = 1;
            
        } catch (Exception e) {
            log.error("Error occur in while process clickEWSRiskLevel : " + e.getMessage());

        }
        return "tabEWSRiskLevel";
    }
     
      public String clickTodayMovement() throws Exception {
        if (log.isInfoEnabled()) {
              log.info("[search][Begin]");
              log.debug(" warningHeaderId = " + warningHeaderId);
              log.debug(" cifNo =" + cifNo);
        }
        RptIndividualAccountVo          rptIndividualAcctVo     = null;
        try{
            if(!cifNo.equals("")){
                if(!cifNo.equals("")){
                rptIndividualAcctVo = new RptIndividualAccountVo();
                rptIndividualAcctVo.setCif(cifNo);
                rptIndividualAcctList = this.todayMovementBusiness.getRptIndividualAccountList(rptIndividualAcctVo);
               /* odAccountVoList =  individualODAccountBusiness.getWarningODOverLimit(cifNo);
                List<ConfigVO> configList = configBusiness.findByConfigGroup(BusinessConst.CONFIG_GROUP.TODAY_MOVEMENT_OD);
                int dateInt = DateUtil.getDayOfMonth(DateUtil.getCurrentDateTime());
                log.info("dateInt = " + dateInt);
                if(configList != null && !configList.isEmpty()&&(dateInt > 0)){
                    for(ConfigVO vo : configList){
                       int valueDate =  vo.getConfigValue() != null ? Integer.parseInt(vo.getConfigValue()) : 0 ;
                       if(dateInt == valueDate){
                        beforeODAccountVoList = individualODAccountBusiness.getWarningBeforeODOverLimit(cifNo);
                        break;
                       }
                    }
                }*/
                }
            }
        this.tabIndex = 2;
        }catch(Exception e){
            log.error("Error occur in while process clickTodayMovement : " + e.getMessage());
            throw e;
        }
      return "tabTodayMovement";
    }

      public String clickTrackRecord() throws Exception {
          if (log.isInfoEnabled()) {
              log.info("clickTrackRecord");
          }
          individualForBreakVoList = accountDetailHistoryBusiness.findDataByCifForTrack(new Integer(cifNo));
          
//          individualODForBreakVoList = accountDetailHistoryBusiness.findDataByCifForTrackODOverLimit(cifNo);
          this.tabIndex = 3;

          return "tabTrackRecord";
      }
    
    public String clickHistorical() throws Exception {
      
        if(!ValidatorUtil.isNullOrEmpty(backFromHistoricalPage)){
            if("action1".equals(backFromHistoricalPage)){
                tabHistoricalAction1();
            }else if("action2".equals(backFromHistoricalPage)){
                tabHistoricalAction2();
            }else{
                tabHistoricalQuali();
            }
        }else{
            tabHistoricalQuali();
        }
      
        return "tabHistorical";
    }
    
    public String tabHistoricalQuali() throws Exception{
        List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        String                       warningType = "EWSQ";
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cifNo, warningType);//warningHeaderBusiness.findWarningIdForQuestion(cif, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                vo.setActionDetail(warningType);
                vo.setWarningType(warningType);
                vo.setCif(cifNo);
                historyList = actionHistoryBusiness.findQuestionHistory(vo);
                if (historyList != null && !historyList.isEmpty()) {
                    tmpVo = (QuestionHistoryVo) historyList.get(0);
                    vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                    vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                    vo.setActionUserId(tmpVo.getActionUserId());
                    vo.setActionDate(tmpVo.getActionDate());
                    vo.setApproveUserId(tmpVo.getApproveUserId());
                    vo.setApproveDate(tmpVo.getApproveDate());
                    vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                    vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                    vo.setCif(cifNo);
                    if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                        QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                        vo.setVersion(tmpQuestionVo.getVersion());
                        vo.setQuestionId(tmpQuestionVo.getQuestionId());
                    }
                    resultList.add(vo);
                }  
            }
            if(resultList.size() > 0){
                setQualiQuestionHistoryList(resultList);
            }
        }
        
        return "tabHistoricalQuali";
    }
    
    public String goQualiHistory() throws Exception {
        log.debug("goQualiHistory");
        
        log.debug(" historicalWarningId >>" + historicalWarningId);
        log.debug(" historicalWarningHeaderId >>" + historicalWarningHeaderId);
        log.debug(" historicalActionDate >>" + historicalActionDate);
        log.debug(" historicalVersion >>" + historicalVersion);
        log.debug(" historicalQuestionId >>" + historicalQuestionId); 
        log.debug(" historicalWarningType " +historicalWarningType);
        log.debug(" cifNo " +cifNo);
        
        if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
            int cifInt = Integer.parseInt(cifNo);
            CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
            if (custVo != null) {
                //------- Title bar -----------//
                TitleVo titleVo = new TitleVo();
                titleVo.setCifNo(cifNo);
                titleVo.setCustName(custVo.getCustName());
                request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
            }
        }
        
        return "goQualiHistory";
     }
    
    public String tabHistoricalFin() throws Exception{
       List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        String                       warningType = "FIN";

        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cifNo, warningType);//warningHeaderBusiness.findWarningIdForQuestion(cif, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
            for (QuestionHistoryVo vo : warningIdList) {
                vo.setActionDetail(warningType);
                vo.setWarningType(warningType);
                vo.setCif(cifNo);
                historyList = actionHistoryBusiness.findQuestionHistory(vo);
                if (historyList != null && !historyList.isEmpty()) {
                    tmpVo = (QuestionHistoryVo) historyList.get(0);
                    vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                    vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                    vo.setActionUserId(tmpVo.getActionUserId());
                    vo.setActionDate(tmpVo.getActionDate());
                    vo.setApproveUserId(tmpVo.getApproveUserId());
                    vo.setApproveDate(tmpVo.getApproveDate());
                    vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                    vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                    vo.setCif(cifNo);
                    resultList.add(vo);
                }
            }
              if(resultList.size() > 0){
                    setFinQuestionHistoryList(resultList);
              }
        }
        
        return "tabHistoricalFin";
    }
    
    public String goFinancialHistory() throws Exception {
        log.debug("goFinancialHistory");
        
        log.debug(" historicalWarningId >>" + historicalWarningId);
        log.debug(" historicalWarningHeaderId >>" + historicalWarningHeaderId);
        log.debug(" historicalActionDate >>" + historicalActionDate);
        log.debug(" historicalVersion >>" + historicalVersion);
        log.debug(" historicalQuestionId >>" + historicalQuestionId);
        log.debug(" historicalWarningType " +historicalWarningType);
        log.debug(" cifNo " +cifNo);
        
        if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
            int cifInt = Integer.parseInt(cifNo);
            CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
            if (custVo != null) {
                //------- Title bar -----------//
                TitleVo titleVo = new TitleVo();
                titleVo.setCifNo(cifNo);
                titleVo.setCustName(custVo.getCustName());
                request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
            }
        }
        
        return "goFinancialHistory";
     }
    
    public String tabHistoricalLatePay() throws Exception{
        List<QuestionHistoryVo> historyList ;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        String                       warningType = "LATE_PAY";
//        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForQuestion(cifNo, warningType);
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cifNo, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                vo.setActionDetail(warningType);
                vo.setWarningType(warningType);
                vo.setCif(cifNo);
                historyList = actionHistoryBusiness.findQuestionHistory(vo);
                if (historyList != null && !historyList.isEmpty()) {
                    tmpVo = (QuestionHistoryVo) historyList.get(0);
                    vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                    vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                    vo.setActionUserId(tmpVo.getActionUserId());
                    vo.setActionDate(tmpVo.getActionDate());
                    vo.setApproveUserId(tmpVo.getApproveUserId());
                    vo.setApproveDate(tmpVo.getApproveDate());
                    vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                    vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                    vo.setCif(cifNo);
                     if (BusinessConst.WarningTypeCode.LATE_PAY.equals(warningType)) {
                        QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                        vo.setVersion(tmpQuestionVo.getVersion());
                        vo.setQuestionId(tmpQuestionVo.getQuestionId());
                    }
                    resultList.add(vo);
                }  
            }
            if(resultList.size() > 0){
                setLatePayQuestionHistoryList(resultList);
            }
        }
        
        return "tabHistoricalLatePay";
    }
    
    public String goLatePaymentHistory() throws Exception {
        log.debug("goLatePaymentHistory");
        
        log.debug(" historicalWarningId >>" + historicalWarningId);
        log.debug(" historicalWarningHeaderId >>" + historicalWarningHeaderId);
        log.debug(" historicalActionDate >>" + historicalActionDate);
        log.debug(" historicalVersion >>" + historicalVersion);
        log.debug(" historicalQuestionId >>" + historicalQuestionId);
        log.debug(" historicalWarningType " +historicalWarningType);
        log.debug(" cifNo " +cifNo);
        
        if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
            int cifInt = Integer.parseInt(cifNo);
            CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
            if (custVo != null) {
                //------- Title bar -----------//
                TitleVo titleVo = new TitleVo();
                titleVo.setCifNo(cifNo);
                titleVo.setCustName(custVo.getCustName());
                request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
            }
        }
        
        return "goLatePaymentHistory";
     }
    
    public String tabHistoricalAction1() throws Exception{
        List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        String                       warningType = "ACTION1";
//        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForQuestion(cifNo, warningType);
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cifNo, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                vo.setActionDetail(warningType);
                vo.setWarningType(warningType);
                vo.setCif(cifNo);
                historyList = actionHistoryBusiness.findQuestionHistory(vo);
                if (historyList != null && !historyList.isEmpty()) {
                    tmpVo = (QuestionHistoryVo) historyList.get(0);
                    vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                    vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                    vo.setActionUserId(tmpVo.getActionUserId());
                    vo.setActionDate(tmpVo.getActionDate());
                    vo.setApproveUserId(tmpVo.getApproveUserId());
                    vo.setApproveDate(tmpVo.getApproveDate());
                    vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                    vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                    vo.setCif(cifNo);
                    if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                        QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                        vo.setVersion(tmpQuestionVo.getVersion());
                        vo.setQuestionId(tmpQuestionVo.getQuestionId());
                    }
                    resultList.add(vo);
                }  
            }
            if(resultList.size() > 0){
                setAction1QuestionHistoryList(resultList);
            }
        }
        
        return "tabHistoricalAction1";
    }
    
    public String goAction1History() throws Exception {
        log.debug("goAction1History");
        
        log.debug(" historicalWarningId >>" + historicalWarningId);
        log.debug(" historicalWarningHeaderId >>" + historicalWarningHeaderId);
        log.debug(" historicalActionDate >>" + historicalActionDate);
        log.debug(" historicalVersion >>" + historicalVersion);
        log.debug(" historicalQuestionId >>" + historicalQuestionId);
        log.debug(" historicalWarningType " +historicalWarningType);
        log.debug(" cifNo " +cifNo);
        
        if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
            int cifInt = Integer.parseInt(cifNo);
            CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
            if (custVo != null) {
                //------- Title bar -----------//
                TitleVo titleVo = new TitleVo();
                titleVo.setCifNo(cifNo);
                titleVo.setCustName(custVo.getCustName());
                request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
            }
        }
        
        return "goAction1History";
     }
    
    public String tabHistoricalAction2() throws Exception{
        List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        String                       warningType = "ACTION2";
//        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForQuestion(cifNo, warningType);
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cifNo, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                vo.setActionDetail(warningType);
                vo.setWarningType(warningType);
                vo.setCif(cifNo);
                historyList = actionHistoryBusiness.findQuestionHistory(vo);
                if (historyList != null && !historyList.isEmpty()) {
                    tmpVo = (QuestionHistoryVo) historyList.get(0);
                    vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                    vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                    vo.setActionUserId(tmpVo.getActionUserId());
                    vo.setActionDate(tmpVo.getActionDate());
                    vo.setApproveUserId(tmpVo.getApproveUserId());
                    vo.setApproveDate(tmpVo.getApproveDate());
                    vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                    vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                    vo.setCif(cifNo);
                    if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                        QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                        vo.setVersion(tmpQuestionVo.getVersion());
                        vo.setQuestionId(tmpQuestionVo.getQuestionId());
                    }
                    resultList.add(vo);
                }  
            }
            if(resultList.size() > 0){
                setAction2QuestionHistoryList(resultList);
            }
        }
        
        return "tabHistoricalAction2";
    }
    
    public String goAction2History() throws Exception {
        log.debug("goAction2History");
        
        log.debug(" historicalWarningId >>" + historicalWarningId);
        log.debug(" historicalWarningHeaderId >>" + historicalWarningHeaderId);
        log.debug(" historicalActionDate >>" + historicalActionDate);
        log.debug(" historicalVersion >>" + historicalVersion);
        log.debug(" historicalQuestionId >>" + historicalQuestionId);
        log.debug(" historicalWarningType " +historicalWarningType);
        log.debug(" cifNo " +cifNo);
        
        if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
            int cifInt = Integer.parseInt(cifNo);
            CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifInt));
            if (custVo != null) {
                //------- Title bar -----------//
                TitleVo titleVo = new TitleVo();
                titleVo.setCifNo(cifNo);
                titleVo.setCustName(custVo.getCustName());
                request.getSession(false).setAttribute(BusinessConst.Session.TITLE_KEY, titleVo);
            }
        }
        
        return "goAction2History";
     }

    public String exportExcel() throws Exception {
        log.debug(">>>>>>>>>>>>exportEWSRiskLevel");
        int max = 0;
        String riskLevelShow    = "";
        String lastUpdate       = "";
        CustomerVo criteriaVo   = null;
        CustomerVo customerVo   = null;
        String    rmEmpNo       = "";
        String     aeEmpNo      = "";
        List<RptIndividualAccountVo>   rptIndividualAcctListExport   = new ArrayList<RptIndividualAccountVo>();
        try {
            if (log.isDebugEnabled()) {
                log.debug(" warningHeaderId = " + warningHeaderId);
                log.debug(" cifNo =" + cifNo);
            }
            ewsRiskList = new ArrayList<RptIndividualRiskLevelVo>();
            quantiList = new ArrayList<RptIndividualRiskLevelVo>();
            qualiList = new ArrayList<RptIndividualRiskLevelVo>();
            List<ReportVO> allList = new ArrayList<ReportVO>();
            ReportVO rpVo;
            List<ReportVO> acctList = new ArrayList<ReportVO>();
            List<ReportVO> acctDetailList = new ArrayList<ReportVO>();
            
            if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
                Integer cif = Integer.parseInt(cifNo);
                ewsRiskList = customerPortfolioBusiness.getIndividualRiskLevel(cif, BusinessConst.EWS_TYPE.EWS_RISK_LEVEL);
                quantiList = customerPortfolioBusiness.getIndividualRiskLevel(cif, BusinessConst.EWS_TYPE.EWS_QUANTITATIVE_BEHAVIOR_MODEL);
                qualiList = customerPortfolioBusiness.getIndividualRiskLevel(cif, BusinessConst.EWS_TYPE.EWS_QUALITATIVE_ASSESSMENT);
                
                acctDetailList = accountDetailHistoryBusiness.findDataByCifForTrackForReport(new Integer(cifNo)); //info for show in Track Record sheet (TR)
                criteriaVo = new CustomerVo();
                
                criteriaVo.setCif(Integer.parseInt(cifNo));
                customerVo     = this.todayMovementBusiness.customerInfo(criteriaVo);
                
            }

            if (!ewsRiskList.isEmpty()) {
                RptIndividualRiskLevelVo vo = ewsRiskList.get(0);
                if ("L".equals(vo.getRiskLevel())) {
                    riskLevelShow = "Low";
                } else if ("M".equals(vo.getRiskLevel())) {
                    riskLevelShow = "Medium";
                } else if ("H".equals(vo.getRiskLevel())) {
                    riskLevelShow = "High";
                }
                lastUpdate = vo.getRiskDateStr();//vo.getCreatedDtStr();
            }

            if (ewsRiskList != null && ewsRiskList.size() > max) {
                max = ewsRiskList.size();
            }
            if (quantiList != null && quantiList.size() > max) {
                max = quantiList.size();
            }
            if (qualiList != null && qualiList.size() > max) {
                max = qualiList.size();
            }

            for (int i = 0; i < max; i++) {//info for show in EWS List Level sheet
                rpVo = new ReportVO();
                if (ewsRiskList != null && i < ewsRiskList.size()) {
                    rpVo.setEwsCrateDate(((RptIndividualRiskLevelVo) ewsRiskList.get(i)).getRiskDateStr());
                    rpVo.setEwsRiskLevel(((RptIndividualRiskLevelVo) ewsRiskList.get(i)).getRiskLevel());
                } else if ((ewsRiskList == null || ewsRiskList.isEmpty()) && i == 0) {
                    rpVo.setEwsRiskLevel("ไม่พบข้อมูล");
                }
                if (quantiList != null && i < quantiList.size()) {
                    rpVo.setPd1CreateDate(((RptIndividualRiskLevelVo) quantiList.get(i)).getRiskDateStr());
                    rpVo.setPd1RiskLevel(((RptIndividualRiskLevelVo) quantiList.get(i)).getRiskLevel());
                } else if ((quantiList == null || quantiList.isEmpty()) && i == 0) {
                    rpVo.setPd1RiskLevel("ไม่พบข้อมูล");
                }
                if (qualiList != null && i < qualiList.size()) {
                    rpVo.setPd2CreateDate(((RptIndividualRiskLevelVo) qualiList.get(i)).getRiskDateStr());
                    rpVo.setPd2RiskLevel(((RptIndividualRiskLevelVo) qualiList.get(i)).getRiskLevel());
                } else if ((qualiList == null || qualiList.isEmpty()) && i == 0) {
                    rpVo.setPd2RiskLevel("ไม่พบข้อมูล");
                }
                allList.add(rpVo);
            }
            AccountDetailVo tmpVo;
            List<IndividualODAccountVo> beforeODAccountList = new ArrayList<IndividualODAccountVo>();
            List<IndividualODAccountVo> odAccountList = new ArrayList<IndividualODAccountVo>();
            ReportVO odBreakStatus = new ReportVO();
            odBreakStatus.setBreakStatus(0);
            ReportVO beforOdBreakStatus = new ReportVO();
            beforOdBreakStatus.setBreakStatus(0);


//            if (warningHeaderId != 0) { //info for show in Today Movement sheet
                RptIndividualAccountVo rptIndividualAcctVo = new RptIndividualAccountVo();
                rptIndividualAcctVo.setCif(cifNo);
                rptIndividualAcctListExport = this.todayMovementBusiness.getRptIndividualAccountList(rptIndividualAcctVo);
                
//ANN                accountDetailVoList = accountDetailHistoryBusiness.findDataByCifForTodayMovement(new Integer(cifNo));
                if (accountDetailVoList != null && !accountDetailVoList.isEmpty()) {
                    for (int i = 0; i < accountDetailVoList.size(); i++) {
                        tmpVo = (AccountDetailVo) accountDetailVoList.get(i);
                        rpVo = new ReportVO();
                        rpVo.setBreakStatus(1);
                        if (tmpVo.getProdType() != null && !"".equals(tmpVo.getProdType())) {
                            tmpVo.setLoanGrpProd(tmpVo.getProdType() + " : " + tmpVo.getLoanGrpProd());
                        }
                        rpVo.setAccountDetailVo(tmpVo);
                        rpVo.setIndex(i + 1);
                        acctList.add(rpVo);
                    }
                } else {
                    if (warningHeaderId != 0) {
                    rpVo = new ReportVO();
                    rpVo.setBreakStatus(0);
                    acctList.add(rpVo);
                    }
                }
            //}

            Map<String,Object> beans = new HashMap<String,Object>();
            beans.put("acctDetailList", acctDetailList);

            beans.put("acountList", acctList);//to day movment
//ANN            beans.put("asAtDate", getAsAtDate());
            beans.put("riskLevelList", allList);
            beans.put("riskLevelShow", riskLevelShow);
            beans.put("riskLevellastUpdate", lastUpdate);
            beans.put("cif", cifNo);

            // OD account
            beans.put("odBreakStatus", odBreakStatus);
            beans.put("beforOdBreakStatus", beforOdBreakStatus);
            beans.put("odAccountList", odAccountList);
            beans.put("beforeODAccountList", beforeODAccountList);
//ANN            beans.put("odAcctTrkRecList", odAccountTrackRecordList);

             if(customerVo!=null){
                beans.put("cif"         , customerVo.getCif());
                beans.put("custName"    , customerVo.getCustName());
                beans.put("responseUnit", customerVo.getResponseUnit() + " - " + customerVo.getResponseUnitName());
                
                aeEmpNo = customerVo.getAeEmpNo() + " - " + customerVo.getAeTitleName() + " " + customerVo.getAeEmpName() + " " + customerVo.getAeEmpSurName();
                beans.put("aeEmpNo", aeEmpNo);
                
                //R4
                rmEmpNo = (ValidatorUtil.isNullOrEmpty(customerVo.getRmId())?"":customerVo.getRmId()) 
                        + " - " + (ValidatorUtil.isNullOrEmpty(customerVo.getRmTitleName())?"":customerVo.getRmTitleName()) 
                        + " " + (ValidatorUtil.isNullOrEmpty(customerVo.getRmEmpName())?"":customerVo.getRmEmpName()) 
                        + " " + (ValidatorUtil.isNullOrEmpty(customerVo.getRmEmpSurName())?"":customerVo.getRmEmpSurName());
                beans.put("rmEmpNo"     , rmEmpNo);
                
                if(!ValidatorUtil.isNullOrEmpty(customerVo.getResponseUnit())){
                    KtbOrganization ktbOrganization = ktbOrganizationBusiness.getOrganizationByCostcenter(customerVo.getResponseUnit());
                    if(ktbOrganization != null){
                        //สายงาน
                        if(!ValidatorUtil.isNullOrEmpty(ktbOrganization.getBusinessUnitCode())){
                            KtbOrganization department = ktbOrganizationBusiness.getOrganizationByCostcenter(ktbOrganization.getBusinessUnitCode().toString());
                            if(department != null && department.getCostCenterName()!=null){
                                setWorkLineNo(department.getCostCenterCode().toString());
                                setWorkLineDesc(department.getCostCenterName());
                            }
                        }
                        //กลุ่มงาน
                        if(!ValidatorUtil.isNullOrEmpty(ktbOrganization.getGroupCode())){
                            KtbOrganization group = ktbOrganizationBusiness.getOrganizationByCostcenter(ktbOrganization.getGroupCode().toString());
                            if(group != null && group.getCostCenterName()!=null){
                                setOrganizationGroupNo(group.getCostCenterCode().toString());
                                setOrganizationGroupDesc(group.getCostCenterName());
                            }
                        }
                    }
                    beans.put("workLineInfo", getWorkLineNo() +" - " + getWorkLineDesc());
                    beans.put("groupInfo", getOrganizationGroupNo() +" - " + getOrganizationGroupDesc());
                }
            }else{
                 
                beans.put("cif"         , "");
                beans.put("custName"    , "");
                beans.put("rmEmpNo"     , "");
                beans.put("responseUnit", "");
                beans.put("aeEmpNo"     , "");
                beans.put("workLineInfo", "");
                beans.put("groupInfo"   , "");
                
            }
             if(rptIndividualAcctListExport!=null && rptIndividualAcctListExport.size() > 0){
                for(RptIndividualAccountVo vo:rptIndividualAcctListExport){
                    if(vo.getProductType()!=null && !vo.getProductType().equals("")){
                        vo.setProductType(vo.getProductType() + " : " + vo.getLoanGrpProd());
                    }
                }
            }
             
            beans.put("rptIndividualAcctList"     , rptIndividualAcctListExport);
            //beans.put("odAccountVoList"           , odAccountVoList);
           // beans.put("beforeODAccountVoList"     , beforeODAccountVoList);
            
            XLSTransformer transformer = new XLSTransformer();

            String path = getServletContext().getRealPath("/");
            File file = new File(path + "report/inividual_report.xls");
            InputStream inputStream = new FileInputStream(file);
            HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
            Calendar cal = Calendar.getInstance();

            
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            
            response.setHeader("Set-Cookie", "fileDownload=true; path=/");

            bos.close();
            byte[] bytes = bos.toByteArray();
            setExportFileName("CustomerPortfolio_CIF" + cifNo + "_" + format.format(cal.getTime()).toString() + ".xls");
            fileStream = new ByteArrayInputStream(bytes);
            
            

        } catch (Exception e) {
            log.error("Error occur in while process exportEWSRiskLevel : " + e.getMessage());

        }

        return "exportExcel";
    }
         
    public String exportHistoricalExcel() throws Exception {
        log.info("[exportHistoricalExcel][begin]");
        
        CustomerVo  criteriaVo   = null;
        CustomerVo  customerVo   = null;
        String      rmEmpNo      = "";
        String      aeEmpNo      = "";
        
        try {
            if (log.isDebugEnabled()) {
                log.debug(" warningHeaderId = " + warningHeaderId);
                log.debug(" cifNo =" + cifNo);
            }
            
            if (!ValidatorUtil.isNullOrEmpty(cifNo)) {
                Integer cif = Integer.parseInt(cifNo);
                
                criteriaVo = new CustomerVo();
                criteriaVo.setCif(cif);
                customerVo     = this.todayMovementBusiness.customerInfo(criteriaVo);
                
            }
            
            qualiQuestionHistoryList    = new ArrayList<QuestionHistoryVo>();
            finQuestionHistoryList      = new ArrayList<QuestionHistoryVo>();
            latePayQuestionHistoryList  = new ArrayList<QuestionHistoryVo>();
            action1QuestionHistoryList  = new ArrayList<QuestionHistoryVo>();
            action2QuestionHistoryList  = new ArrayList<QuestionHistoryVo>();
            
            tabHistoricalQuali();
            tabHistoricalFin();
            tabHistoricalLatePay();
            tabHistoricalAction1();
            tabHistoricalAction2();
            

            Map beans = new HashMap();
            beans.put("qualiQuestionHistoryList", qualiQuestionHistoryList);
            beans.put("finQuestionHistoryList", finQuestionHistoryList);
            beans.put("latePayQuestionHistoryList", latePayQuestionHistoryList);
            beans.put("action1QuestionHistoryList", action1QuestionHistoryList);
            beans.put("action2QuestionHistoryList", action2QuestionHistoryList);

            if(customerVo!=null){
                beans.put("cif"         , customerVo.getCif());
                beans.put("custName"    , customerVo.getCustName());
                            
                beans.put("responseUnit", customerVo.getResponseUnit() + " - " + customerVo.getResponseUnitName());
                
                aeEmpNo = customerVo.getAeEmpNo() + " - " + customerVo.getAeTitleName() + " " + customerVo.getAeEmpName() + " " + customerVo.getAeEmpSurName();
                beans.put("aeEmpNo", aeEmpNo);
                
                //R4
                rmEmpNo = (ValidatorUtil.isNullOrEmpty(customerVo.getRmId())?"":customerVo.getRmId()) 
                        + " - " + (ValidatorUtil.isNullOrEmpty(customerVo.getRmTitleName())?"":customerVo.getRmTitleName()) 
                        + " " + (ValidatorUtil.isNullOrEmpty(customerVo.getRmEmpName())?"":customerVo.getRmEmpName()) 
                        + " " + (ValidatorUtil.isNullOrEmpty(customerVo.getRmEmpSurName())?"":customerVo.getRmEmpSurName());
                beans.put("rmEmpNo"     , rmEmpNo);
                
                if(!ValidatorUtil.isNullOrEmpty(customerVo.getResponseUnit())){
                    KtbOrganization ktbOrganization = ktbOrganizationBusiness.getOrganizationByCostcenter(customerVo.getResponseUnit());
                    if(ktbOrganization != null){
                        //สายงาน
                        if(!ValidatorUtil.isNullOrEmpty(ktbOrganization.getBusinessUnitCode())){
                            KtbOrganization department = ktbOrganizationBusiness.getOrganizationByCostcenter(ktbOrganization.getBusinessUnitCode().toString());
                            if(department != null && department.getCostCenterName()!=null){
                                setWorkLineNo(department.getCostCenterCode().toString());
                                setWorkLineDesc(department.getCostCenterName());
                            }
                        }
                        //กลุ่มงาน
                        if(!ValidatorUtil.isNullOrEmpty(ktbOrganization.getGroupCode())){
                            KtbOrganization group = ktbOrganizationBusiness.getOrganizationByCostcenter(ktbOrganization.getGroupCode().toString());
                            if(group != null && group.getCostCenterName()!=null){
                                setOrganizationGroupNo(group.getCostCenterCode().toString());
                                setOrganizationGroupDesc(group.getCostCenterName());
                            }
                        }
                    }
                    beans.put("workLineInfo", getWorkLineNo() +" - " + getWorkLineDesc());
                    beans.put("groupInfo", getOrganizationGroupNo() +" - " + getOrganizationGroupDesc());
                }
            }else{
                beans.put("cif"         , "");
                beans.put("custName"    , "");
                beans.put("rmEmpNo"     , "");
                beans.put("responseUnit", "");
                beans.put("aeEmpNo"     , "");
                beans.put("workLineInfo", "");
                beans.put("groupInfo"   , "");
            }
            
            XLSTransformer transformer = new XLSTransformer();

            String path = getServletContext().getRealPath("/");
            File file = new File(path + "report/historical_assessment.xls");
            InputStream inputStream = new FileInputStream(file);
            HSSFWorkbook workbook = (HSSFWorkbook) transformer.transformXLS(inputStream, beans);
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
            Calendar cal = Calendar.getInstance();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            
            response.setHeader("Set-Cookie", "fileDownload=true; path=/");

            bos.close();
            byte[] bytes = bos.toByteArray();
            setExportFileName("HistoricalAssessment_CIF" + cifNo + "_" + format.format(cal.getTime()).toString() + ".xls");
            fileStream = new ByteArrayInputStream(bytes);

        } catch (Exception e) {
            log.error("exportHistoricalExcel : " + e.getMessage());
            throw e;
        }finally{
            log.info("[exportHistoricalExcel][End]");
        }

        return "exportHistoricalExcel";
    }
         
     public String goBack() throws Exception {
        String forward = "";
        if (log.isInfoEnabled()) {
            log.info("goBack");
            log.info("pageEntryFrom = " + pageEntryFrom);
        }
//        if (!ValidatorUtil.isNullOrEmpty(pageEntryFrom) && pageEntryFrom.equals(BusinessConst.PAGE.PIPELINE)) {
//            forward = "backTaskList";
//        }
//        if (!ValidatorUtil.isNullOrEmpty(pageEntryFrom) && pageEntryFrom.equals(BusinessConst.PAGE.TASK_DETAIL)) {
//            setBackCifNo(cifNo != null ? cifNo.trim() : "");
//            setBackWarningHeaderId(warningHeaderId);
//            setBackHeaderStatus(headerStatus != null ? headerStatus.trim() : "");
//            forward = "backTaskDetail";
//        } else {
            forward = "backCustomerPortfolio";
//            if (request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH) != null) {
//                SearchBean sb = (SearchBean) request.getSession().getAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
//                if (sb != null) {
//                    
//                    log.info("CustomerName = " + sb.getCustomerName());
//                    
//                    setBackCifNo(sb.getCifNo() != null ? sb.getCifNo().trim() : "");
//                    setBackCustomerName(sb.getCustomerName() != null ? sb.getCustomerName().trim() : "");
//                    setBackRmIdOrAeId(sb.getRmIdOrAeId() != null ? sb.getRmIdOrAeId().trim() : "");
//                    setBackWorkLine(sb.getWorkLine() != null ? sb.getWorkLine().trim() : "");
//                    setBackOrganizationGroup(sb.getOrganizationGroup() != null ? sb.getOrganizationGroup().trim() : "");
//                    setBackCostCenter(sb.getCostCenter() != null ? sb.getCostCenter().trim() : "");
//                }
//            }
            setBackPage(BusinessConst.PAGE.CUSTOMER_PORTFOLIO);
       // }
        return forward;
    }
     
    public SearchBean getSearchBean() {
        return searchBean;
    }

    public void setSearchBean(SearchBean searchBean) {
        this.searchBean = searchBean;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public List<RptIndividualRiskLevelVo> getEwsRiskList() {
        return ewsRiskList;
    }

    public void setEwsRiskList(List<RptIndividualRiskLevelVo> ewsRiskList) {
        this.ewsRiskList = ewsRiskList;
    }

    public List<RptIndividualRiskLevelVo> getQuantiList() {
        return quantiList;
    }

    public void setQuantiList(List<RptIndividualRiskLevelVo> quantiList) {
        this.quantiList = quantiList;
    }

    public List<RptIndividualRiskLevelVo> getQualiList() {
        return qualiList;
    }

    public void setQualiList(List<RptIndividualRiskLevelVo> qualiList) {
        this.qualiList = qualiList;
    }

    public String getCustfullName() {
        return custfullName;
    }

    public void setCustfullName(String custfullName) {
        this.custfullName = custfullName;
    }

    public String getResponseUnit() {
        return responseUnit;
    }

    public void setResponseUnit(String responseUnit) {
        this.responseUnit = responseUnit;
    }

    public String getResponseUnitName() {
        return responseUnitName;
    }

    public void setResponseUnitName(String responseUnitName) {
        this.responseUnitName = responseUnitName;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public String getAeId() {
        return aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public String getRmName() {
        return rmName;
    }

    public void setRmName(String rmName) {
        this.rmName = rmName;
    }

    public String getAeName() {
        return aeName;
    }

    public void setAeName(String aeName) {
        this.aeName = aeName;
    }

    public String getLastUpdateRiskLevel() {
        return lastUpdateRiskLevel;
    }

    public void setLastUpdateRiskLevel(String lastUpdateRiskLevel) {
        this.lastUpdateRiskLevel = lastUpdateRiskLevel;
    }

    public String getLastRiskLevel() {
        return lastRiskLevel;
    }

    public void setLastRiskLevel(String lastRiskLevel) {
        this.lastRiskLevel = lastRiskLevel;
    }

    public int getTabIndex() {
        return tabIndex;
    }

    public void setTabIndex(int tabIndex) {
        this.tabIndex = tabIndex;
    }

    public String getPageEntryFrom() {
        return pageEntryFrom;
    }

    public void setPageEntryFrom(String pageEntryFrom) {
        this.pageEntryFrom = pageEntryFrom;
    }

    public String getBackCifNo() {
        return backCifNo;
    }

    public void setBackCifNo(String backCifNo) {
        this.backCifNo = backCifNo;
    }

    public String getBackCustomerName() {
        return backCustomerName;
    }

    public void setBackCustomerName(String backCustomerName) {
        this.backCustomerName = backCustomerName;
    }

    public String getBackPage() {
        return backPage;
    }

    public void setBackPage(String backPage) {
        this.backPage = backPage;
    }

    public List<RptIndividualAccountVo> getRptIndividualAcctList() {
        return rptIndividualAcctList;
    }

    public void setRptIndividualAcctList(List<RptIndividualAccountVo> rptIndividualAcctList) {
        this.rptIndividualAcctList = rptIndividualAcctList;
    }

    public List<IndividualODAccountVo> getOdAccountVoList() {
        return odAccountVoList;
    }

    public void setOdAccountVoList(List<IndividualODAccountVo> odAccountVoList) {
        this.odAccountVoList = odAccountVoList;
    }

    public List<IndividualODAccountVo> getBeforeODAccountVoList() {
        return beforeODAccountVoList;
    }

    public void setBeforeODAccountVoList(List<IndividualODAccountVo> beforeODAccountVoList) {
        this.beforeODAccountVoList = beforeODAccountVoList;
    }

    public List<AccountDetailVo> getAccountDetailVoList() {
        return accountDetailVoList;
    }

    public void setAccountDetailVoList(List<AccountDetailVo> accountDetailVoList) {
        this.accountDetailVoList = accountDetailVoList;
    }

    public InputStream getFileStream() {
        return fileStream;
    }

    public void setFileStream(InputStream fileStream) {
        this.fileStream = fileStream;
    }

    public String getExportFileName() {
        return exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    public String getHistoricalWarningId() {
        return historicalWarningId;
    }

    public void setHistoricalWarningId(String historicalWarningId) {
        this.historicalWarningId = historicalWarningId;
    }

    public String getHistoricalWarningHeaderId() {
        return historicalWarningHeaderId;
    }

    public void setHistoricalWarningHeaderId(String historicalWarningHeaderId) {
        this.historicalWarningHeaderId = historicalWarningHeaderId;
    }

    public String getHistoricalActionDate() {
        return historicalActionDate;
    }

    public void setHistoricalActionDate(String historicalActionDate) {
        this.historicalActionDate = historicalActionDate;
    }

    public String getHistoricalVersion() {
        return historicalVersion;
    }

    public void setHistoricalVersion(String historicalVersion) {
        this.historicalVersion = historicalVersion;
    }

    public String getHistoricalQuestionId() {
        return historicalQuestionId;
    }

    public void setHistoricalQuestionId(String historicalQuestionId) {
        this.historicalQuestionId = historicalQuestionId;
    }

    public String getHistoricalWarningType() {
        return historicalWarningType;
    }

    public void setHistoricalWarningType(String historicalWarningType) {
        this.historicalWarningType = historicalWarningType;
    }
    
    public List<QuestionHistoryVo> getQualiQuestionHistoryList() {
        return qualiQuestionHistoryList;
    }

    public void setQualiQuestionHistoryList(List<QuestionHistoryVo> qualiQuestionHistoryList) {
        this.qualiQuestionHistoryList = qualiQuestionHistoryList;
    }

    public List<QuestionHistoryVo> getFinQuestionHistoryList() {
        return finQuestionHistoryList;
    }

    public void setFinQuestionHistoryList(List<QuestionHistoryVo> finQuestionHistoryList) {
        this.finQuestionHistoryList = finQuestionHistoryList;
    }

    public List<QuestionHistoryVo> getLatePayQuestionHistoryList() {
        return latePayQuestionHistoryList;
    }
    public void setLatePayQuestionHistoryList(List<QuestionHistoryVo> latePayQuestionHistoryList) {
        this.latePayQuestionHistoryList = latePayQuestionHistoryList;
    }

    public List<QuestionHistoryVo> getAction1QuestionHistoryList() {
        return action1QuestionHistoryList;
    }

    public void setAction1QuestionHistoryList(List<QuestionHistoryVo> action1QuestionHistoryList) {
        this.action1QuestionHistoryList = action1QuestionHistoryList;
    }

    public List<QuestionHistoryVo> getAction2QuestionHistoryList() {
        return action2QuestionHistoryList;
    }

    public void setAction2QuestionHistoryList(List<QuestionHistoryVo> action2QuestionHistoryList) {
        this.action2QuestionHistoryList = action2QuestionHistoryList;
    }

    public String getBackFromHistoricalPage() {
        return backFromHistoricalPage;
    }

    public void setBackFromHistoricalPage(String backFromHistoricalPage) {
        this.backFromHistoricalPage = backFromHistoricalPage;
    }

    public String getWorkLineNo() {
        return workLineNo;
    }

    public void setWorkLineNo(String workLineNo) {
        this.workLineNo = workLineNo;
    }

    public String getWorkLineDesc() {
        return workLineDesc;
    }

    public void setWorkLineDesc(String workLineDesc) {
        this.workLineDesc = workLineDesc;
    }

    public String getOrganizationGroupNo() {
        return organizationGroupNo;
    }

    public void setOrganizationGroupNo(String organizationGroupNo) {
        this.organizationGroupNo = organizationGroupNo;
    }

    public String getOrganizationGroupDesc() {
        return organizationGroupDesc;
    }

    public void setOrganizationGroupDesc(String organizationGroupDesc) {
        this.organizationGroupDesc = organizationGroupDesc;
    }

    public String getBackRmIdOrAeId() {
        return backRmIdOrAeId;
    }

    public void setBackRmIdOrAeId(String backRmIdOrAeId) {
        this.backRmIdOrAeId = backRmIdOrAeId;
    }

    public String getBackWorkLine() {
        return backWorkLine;
    }

    public void setBackWorkLine(String backWorkLine) {
        this.backWorkLine = backWorkLine;
    }

    public String getBackOrganizationGroup() {
        return backOrganizationGroup;
    }

    public void setBackOrganizationGroup(String backOrganizationGroup) {
        this.backOrganizationGroup = backOrganizationGroup;
    }

    public String getBackCostCenter() {
        return backCostCenter;
    }

    public void setBackCostCenter(String backCostCenter) {
        this.backCostCenter = backCostCenter;
    }

    public List<IndividualForBreakVo> getIndividualForBreakVoList() {
        return individualForBreakVoList;
    }

    public void setIndividualForBreakVoList(List<IndividualForBreakVo> individualForBreakVoList) {
        this.individualForBreakVoList = individualForBreakVoList;
    }
     
}
