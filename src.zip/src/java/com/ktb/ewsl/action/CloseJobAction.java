/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ParameterBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Tum_Surapong
 */
public class CloseJobAction extends BaseAction {

    private static final Logger log = Logger.getLogger(CloseJobAction.class);
    private ArrayList<DropdownVo> reasonForCloseList;
    private String reason;
    private int warningHeaderId;
    private int warningId;
    private String warningType;
    private String cifNo;
    private String rejectRemark;
    private String actionMode;
    private String title;
    private String returnCurrentHeaderStatus;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private ParameterBusiness parameterBusiness;

    public ArrayList<DropdownVo> getReasonForCloseList() {
        return reasonForCloseList;
    }

    public void setReasonForCloseList(ArrayList<DropdownVo> reasonForCloseList) {
        this.reasonForCloseList = reasonForCloseList;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getRejectRemark() {
        return rejectRemark;
    }

    public void setRejectRemark(String rejectRemark) {
        this.rejectRemark = rejectRemark;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReturnCurrentHeaderStatus() {
        return returnCurrentHeaderStatus;
    }

    public void setReturnCurrentHeaderStatus(String returnCurrentHeaderStatus) {
        this.returnCurrentHeaderStatus = returnCurrentHeaderStatus;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    @Override
    public String success() throws Exception {
        log.info("Init CloseJobAction");
        log.info(" warningHeaderId = " + warningHeaderId);
        log.info(" cifNo = " + cifNo);
        log.info(" warningId = " + warningId);
        log.info(" warningType = " + warningType);


        actionMode = "Request";
        title = "ปิดงาน";
        if (warningId <= 0) { // close cif
            WarningHeaderVo warningHeaderVo = warningHeaderBusiness.findWarningHeaderObjectOriginal(warningHeaderId, cifNo);
            if (BusinessConst.Flag.CLOSE_JOB.equals(warningHeaderVo.getStatus())) {
                actionMode = "Reject";
                title = "ยกเลิกปิดงาน";
            } else {
                if (reasonForCloseList == null || reasonForCloseList.isEmpty()) {
                    List<ParameterVo> ParameterVoList =  parameterBusiness.getParameterByTypeId(BusinessConst.PARAMETER_TYPE_ID.CLOSEJOB, "PARAMETER_ID");
                    reasonForCloseList = new ArrayList<DropdownVo>();
                    if (ParameterVoList != null) {
                        for (ParameterVo parameterVo : ParameterVoList) {
                            reasonForCloseList.add(setDataToDropDrown(parameterVo.getParameterId(), parameterVo.getParameterName()));
                        }
                    }
                }
            }
        } else { // close warningId
            WarningInfoVo warningInfoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningId, warningType);
            if (BusinessConst.Flag.Y.equals(warningInfoVo.getCloseFlag())) {
                actionMode = "Reject";
                title = "ยกเลิกปิดงาน";
            } else {
                if (reasonForCloseList == null || reasonForCloseList.isEmpty()) {
                    List<ParameterVo> ParameterVoList =  parameterBusiness.getParameterByTypeId(BusinessConst.PARAMETER_TYPE_ID.CLOSEJOBBYTYPE, "PARAMETER_ID");
                    reasonForCloseList = new ArrayList<DropdownVo>();
                    if (ParameterVoList != null) {
                        for (ParameterVo parameterVo : ParameterVoList) {
                            reasonForCloseList.add(setDataToDropDrown(parameterVo.getParameterId(), parameterVo.getParameterName()));
                        }
                    }
                }
            }
        }
        return SUCCESS;
    }

    public String doSave() throws Exception {
        log.info("doSave");
        log.info(" warningHeaderId = " + warningHeaderId);
        log.info(" warningId = " + warningId);
        log.info(" warningType = " + warningType);
        log.info(" cifNo = " + cifNo);
        log.info(" reason = " + reason);
        log.info(" actionMode = " + actionMode);
        log.info(" rejectRemark = " + rejectRemark);
        log.info(" rejectRemark = " + getCurrentUser().getRoleId());

        WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
        warningHeaderVo.setWarningHeaderId(warningHeaderId);
        warningHeaderVo.setCif(cifNo);
       // warningHeaderVo.setStatus(BusinessConst.Flag.CLOSE_JOB);
        if ("Reject".equals(actionMode)) {
            warningHeaderVo.setStatus(BusinessConst.Flag.INPROCESS);
        } else {
       /* Defect 002 --26/01/2016
            if (rejectRemark == null || rejectRemark.trim().length() <= 0) {
                rejectRemark = "อนุมัติปิดงาน";
            }    
       */
        }
        warningHeaderBusiness.closeJob(warningHeaderVo, getCurrentUser(), reason, rejectRemark, actionMode, warningId, warningType );
        //---- ForRender screen --//
        setReturnCurrentHeaderStatus(warningHeaderVo.getStatus());
        
        if((BusinessConst.WarningTypeCode.FIN.equals(warningType) ||(BusinessConst.WarningTypeCode.EWSQ.equals(warningType)))
                && (getCurrentUser() != null && (EWSConstantValue.ROLE_APPROVE_CLOSE_JOB.contains(getCurrentUser().getRoleId())))
                &&  !"Reject".equals(actionMode)){
            log.info(" CloseJobAction.doSave Entry to loop approve auto ");
                WarningHeaderVo warningHeaderVoApprove = new WarningHeaderVo();
                warningHeaderVoApprove.setWarningHeaderId(warningHeaderId);
                warningHeaderVoApprove.setCif(cifNo);
                warningHeaderVoApprove.setStatus(BusinessConst.Flag.COMPLETE);
                warningHeaderBusiness.closeJob(warningHeaderVoApprove, getCurrentUser(), "", "อนุมัติปิดงาน", "Approve", warningId, warningType);
        }
        return "pipeline";//"taskDetail";
    }

    private DropdownVo setDataToDropDrown(String key, String value) {
        DropdownVo ddVo = new DropdownVo();
        ddVo.setId(key);
        ddVo.setDesc(value);
        return ddVo;
    }
}
