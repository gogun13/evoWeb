/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.CacheBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.List;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Tum_Surapong
 */
public class QuestionHistoryAction extends BaseAction {


    private static final Logger log = Logger.getLogger(QuestionHistoryAction.class);
    private List<AsstTopicVo> asstTopicVoList;
    private int warningId;
    private String warningType;
    private String warningTypeDesc;
    private String questionId;
    private String version;
    private String cifNo;
    private int warningHeaderId;
    private String approveFlag = BusinessConst.Flag.N;
    private String rejectFlag = BusinessConst.Flag.N;
    private String saveFlag = BusinessConst.Flag.N;
    private String infoStatus;
    private String finalLevel;
    private String showSaveFinal = BusinessConst.Flag.N;
    private String showMode;
    private List<ActionHistoryVo> actionHistoryVoList;
    private String showButtonForClose;
    private int dpd;
    private String title;
    
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private CacheBusiness cacheBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    
    public List<AsstTopicVo> getAsstTopicVoList() {
        return asstTopicVoList;
    }

    public void setAsstTopicVoList(List<AsstTopicVo> asstTopicVoList) {
        this.asstTopicVoList = asstTopicVoList;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getWarningTypeDesc() {
        return warningTypeDesc;
    }

    public void setWarningTypeDesc(String warningTypeDesc) {
        this.warningTypeDesc = warningTypeDesc;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getApproveFlag() {
        return approveFlag;
    }

    public void setApproveFlag(String approveFlag) {
        this.approveFlag = approveFlag;
    }

    public String getSaveFlag() {
        return saveFlag;
    }

    public void setSaveFlag(String saveFlag) {
        this.saveFlag = saveFlag;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public String getFinalLevel() {
        return finalLevel;
    }

    public void setFinalLevel(String finalLevel) {
        this.finalLevel = finalLevel;
    }

    public String getShowSaveFinal() {
        return showSaveFinal;
    }

    public void setShowSaveFinal(String showSaveFinal) {
        this.showSaveFinal = showSaveFinal;
    }

    public String getShowMode() {
        return showMode;
    }

    public void setShowMode(String showMode) {
        this.showMode = showMode;
    }

    public List<ActionHistoryVo> getActionHistoryVoList() {
        return actionHistoryVoList;
    }

    public void setActionHistoryVoList(List<ActionHistoryVo> actionHistoryVoList) {
        this.actionHistoryVoList = actionHistoryVoList;
    }

    public String getShowButtonForClose() {
        return showButtonForClose;
    }

    public void setShowButtonForClose(String showButtonForClose) {
        this.showButtonForClose = showButtonForClose;
    }

    public int getDpd() {
        return dpd;
    }

    public void setDpd(int dpd) {
        this.dpd = dpd;
    }
    @Override
    public String success() throws Exception {
       
        if (log.isInfoEnabled()) {
            log.info("success");
        }
       
        QuestionHistoryVo keyVo = (QuestionHistoryVo)request.getSession().getAttribute(BusinessConst.Session.QUESTION_HISTORY_KEY);
        this.cifNo = keyVo.getCif();
        this.warningHeaderId = Integer.parseInt(keyVo.getHeaderId());

        if (asstTopicVoList == null) {
            findData(keyVo);
        }

        WarningTypeVo warningTypeVo = cacheBusiness.findWarningTypeDetail(warningType);
        if (warningTypeVo != null) {
            this.warningTypeDesc = warningTypeVo.getWarningTypeDesc();
            setTitle("ข้อมูลประวัติการตอบฟอร์ม "+warningTypeVo.getWarningTypeDesc() +" วันที่ทำรายการ "+keyVo.getActionDate());
        }

        showSaveFinal = BusinessConst.Flag.N;
        UserData userData = getCurrentUser();
//        if (BusinessConst.WarningTypeCode.QCA.equals(warningType) && EWSConstantValue.STATUS_QCA_FINAL.contains(infoStatus)) {
//            showMode = "true";
//            if (EWSConstantValue.STATUS_QCA_FINAL_LEVEL1.contains(infoStatus)) {
//                finalLevel = "1";
//                if (EWSConstantValue.ROLE_APPROVE_QCA_FINAL_LEVEL1.contains(userData.getRoleId())) {
//                    showSaveFinal = BusinessConst.Flag.Y;
//                }
//            } else if (EWSConstantValue.QCA_FINAL_LEVEL2_EDIT.contains(infoStatus)) {
//                finalLevel = "2";
//                if (EWSConstantValue.ROLE_APPROVE_QCA_FINAL_LEVEL2.contains(userData.getRoleId())) {
//                    if (asstQuestionBusiness.chkUser(warningId, userData.getEmpNo())) {
//                        showSaveFinal = BusinessConst.Flag.Y;
//                    }
//                }
//            }
//
//            if (BusinessConst.Flag.Y.equals(showSaveFinal)) {
//                showMode = "false";
//            }
//
//            return "final_qca";
//        }
        Integer intObjDpd = warningHeaderBusiness.findWarningHeaderByPK( warningHeaderId ).getDpd();
        this.dpd = NumberUtils.toInt( intObjDpd != null ? intObjDpd.toString() : "", 0 );
        
       request.getSession().removeAttribute(BusinessConst.Session.QUESTION_HISTORY_KEY);
        
        return SUCCESS;
    }

   private void findData(QuestionHistoryVo keyVo) throws Exception {
//        filter
//        1. warningId
//        2. questionId
//        3. version

        UserData userData = getCurrentUser();
        AsstTopicVo filter = new AsstTopicVo();
        filter.setWarningHeaderId(Integer.parseInt(keyVo.getHeaderId()));
        //filter.setInfoStatus(infoStatus);
        filter.setVersion(keyVo.getVersion());
        filter.setWarningId(Integer.parseInt(keyVo.getWarningId()));
        filter.setQuestionId(keyVo.getQuestionId());
        filter.setWarningType(keyVo.getWarningType());
        
        System.out.println("warningHeaderId >>>"+keyVo.getHeaderId());
        System.out.println("infoStatus >>>"+infoStatus);
        System.out.println("version >>>>"+keyVo.getVersion());
        System.out.println("warningId >>>"+keyVo.getWarningId());
        System.out.println("questionId >>>"+keyVo.getQuestionId());
        System.out.println("warningType >>>"+keyVo.getWarningType());
        
        
        this.asstTopicVoList = asstQuestionBusiness.findQuestionByFilter(filter);

        if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.RMP.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
            approveFlag = BusinessConst.Flag.N;
            rejectFlag = BusinessConst.Flag.N;
            if (EWSConstantValue.ROLE_EDITOR.contains(userData.getRoleId()) || (BusinessConst.WarningTypeCode.EWSQ.equals(warningType) && BusinessConst.UserRole.AE.equals(userData.getRoleId()))) {
                 if(!BusinessConst.UserRole.RISK_EDITOR.equals(userData.getRoleId())){
                      saveFlag = BusinessConst.Flag.Y;
                 }
            }
        } else if (EWSConstantValue.ROLE_APPROVE.contains(userData.getRoleId()) && BusinessConst.Flag.RMF.equals(infoStatus)) {
            approveFlag = BusinessConst.Flag.Y;
            rejectFlag = BusinessConst.Flag.Y;
            saveFlag = BusinessConst.Flag.N;
        }

        this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(warningId);

        if(!BusinessConst.Flag.COMPLETE.equals(infoStatus)){
            WarningInfoVo warningInfoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningId, warningType);
            if (warningInfoVo !=null && BusinessConst.Flag.Y.equals(warningInfoVo.getCloseFlag())) {
                if (EWSConstantValue.ROLE_APPROVE_CLOSE_JOB.contains(userData.getRoleId())) {
                    showButtonForClose = "C2";
                }
                approveFlag = BusinessConst.Flag.N;
                rejectFlag = BusinessConst.Flag.N;
                saveFlag = BusinessConst.Flag.N;
            } else {
                if (EWSConstantValue.ROLE_EDITOR.contains(userData.getRoleId())) {
                    showButtonForClose = "C1";
                }
            }
        }

        if (BusinessConst.Flag.Y.equals(saveFlag)) {
            showMode = "false";
        } else {
            showMode = "true";
        }
    }
}
