/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.action.LogoutAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;

/**
 *
 * @author KTBDevLoan
 */
public class LogoutPortalAction extends BaseAction {

    private static final Logger logger = Logger.getLogger(LogoutPortalAction.class);
    private String empNo;

    public String logout() throws Exception {
        logger.info("Logout sucess");
        return SUCCESS;
    }

    @Override
    public String success() throws Exception {
        try {
            UserData currUser = getCurrentUser();

            Authentication auth = SecurityContextHolder.getContext().getAuthentication();

            SecurityContextLogoutHandler securityContextLogoutHandler = new SecurityContextLogoutHandler();
            PersistentTokenBasedRememberMeServices persToken = new PersistentTokenBasedRememberMeServices();

            securityContextLogoutHandler.logout(request, response, auth);
            persToken.logout(request, response, auth);

            SecurityContextHolder.clearContext();
           
            if (currUser != null) {

                if (request.getSession(false) != null) {
                    request.getSession(false).removeAttribute(BusinessConst.Session.LOGIN_KEY);
                    request.getSession(false).removeAttribute(BusinessConst.Session.TITLE_KEY);
                    request.getSession(false).removeAttribute(BusinessConst.Session.WARNING_TYPE_SESSION_KEY);
                    request.getSession(false).removeAttribute(BusinessConst.Session.PIPELINE_CRITERIA_SEARCH_SORT);
                    request.getSession(false).removeAttribute(BusinessConst.Session.CUSTOMER_PORTFOLIO_CRITERIA_SEARCH);
                    request.getSession(false).removeAttribute(BusinessConst.Session.RISK_MIGRATION_SEARCH_ALL_CIF);
                    request.getSession(false).removeAttribute("NOSESSION");
                    request.getSession(false).removeAttribute(BusinessConst.Session.URL_FROM_SESSION);
                    
                    request.getSession(false).invalidate();
                    logger.info("Login sucess");
                }
            }
            
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return "TEST";
    }

    public String logoutManual() throws Exception {
        UserData currUser = getCurrentUser();

        return SUCCESS;
    }
    /**
     * @return the empNo
     */
    public String getEmpNo() {
        return empNo;
    }

    /**
     * @param empNo the empNo to set
     */
    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }
}
