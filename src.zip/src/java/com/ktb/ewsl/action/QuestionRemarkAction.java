/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.PrintWriter;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Tum_Surapong
 */
public class QuestionRemarkAction extends BaseAction {

    private static final Logger logger = Logger.getLogger(QuestionRemarkAction.class);
    private int warningId;
    private String rejectRemark;
    private int warningHeaderId;
    private String cifNo;
    private String warningType;
    private String questionId;
    private String version;
    private String infoStatus;
    private String actionMode;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness;

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public String getRejectRemark() {
        return rejectRemark;
    }

    public void setRejectRemark(String rejectRemark) {
        this.rejectRemark = rejectRemark;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }
    
    @Override
    public String success() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("success");
        }
         TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        logger.debug("warningHeaderId >>> " + warningHeaderId);
        logger.debug("warningId >>> " + warningId);
        logger.debug("warningType >>> " + warningType);
        logger.debug("questionId >>> " + questionId);
        logger.debug("version >>> " + version);
        logger.debug("infoStatus >>> " + infoStatus);
        logger.debug("actionMode >>> " + actionMode);
        if(warningId != 0){
            ActionHistoryVo data = actionHistoryBusiness.findActionHistory(warningId, "Reject", "RX");
            if((data != null)&&(!ValidatorUtil.isNullOrEmpty(data.getActionDetail()))){
               setRejectRemark(data.getRemark());
            }else{
               setRejectRemark("");
            }
        }
        return SUCCESS;
    }

    public String doSave() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doSave");
        }

        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        logger.debug("warningHeaderId >>> " + warningHeaderId);
        logger.debug("warningId >>> " + warningId);
        logger.debug("warningType >>> " + warningType);
        logger.debug("questionId >>> " + questionId);
        logger.debug("version >>> " + version);
        logger.debug("infoStatus >>> " + infoStatus);
        logger.debug("actionMode >>> " + actionMode);

        AsstTopicVo asstTopicVo = new AsstTopicVo();
        asstTopicVo.setWarningHeaderId(warningHeaderId);
        asstTopicVo.setWarningType(warningType);
        asstTopicVo.setWarningId(warningId);
        asstTopicVo.setQuestionId(questionId);
        asstTopicVo.setVersion(version);
        asstTopicVo.setCifNo(titleVo.getCifNo());
        asstTopicVo.setCustName(titleVo.getCustName());
        asstTopicVo.setRemark(rejectRemark);
        if (BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
            asstQuestionBusiness.sendbackQuestion(asstTopicVo, getCurrentUser(), getFinStatus(infoStatus, BusinessConst.GO_ACTION.PREVIOUS), actionMode);
        } else {
            asstQuestionBusiness.sendbackQuestion(asstTopicVo, getCurrentUser(), infoStatus, actionMode);
        }

       return "taskList";//approveDone";
    }
    
     public String doSaveDraft() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("------doSaveDraft");
        }
        try{
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        logger.info("warningHeaderId >>> " + warningHeaderId);
        logger.info("warningId >>> " + warningId);
        logger.info("warningType >>> " + warningType);
        logger.info("questionId >>> " + questionId);
        logger.info("version >>> " + version);
        logger.info("infoStatus >>> " + infoStatus);
        logger.info("actionMode >>> " + actionMode);

        AsstTopicVo asstTopicVo = new AsstTopicVo();
        asstTopicVo.setWarningHeaderId(warningHeaderId);
        asstTopicVo.setWarningType(warningType);
        asstTopicVo.setWarningId(warningId);
        asstTopicVo.setQuestionId(questionId);
        asstTopicVo.setVersion(version);
        asstTopicVo.setCifNo(titleVo.getCifNo());
        asstTopicVo.setCustName(titleVo.getCustName());
        asstTopicVo.setRemark(rejectRemark);
        if (BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
            asstQuestionBusiness.sendbackQuestionDraft(asstTopicVo, getCurrentUser(), getFinStatus(infoStatus, BusinessConst.GO_ACTION.PREVIOUS), actionMode);
        } else {
            asstQuestionBusiness.sendbackQuestionDraft(asstTopicVo, getCurrentUser(), infoStatus, actionMode);
        }
        }catch(Exception e){
            logger.error(e);
            throw e;
        }
        return null;// "showProtestRemark";//"taskList";//approveDone";
    }

    private String getFinStatus(String currentStatus, String needToGo) throws Exception {
        logger.info("getFinStatus currentStatus= " + currentStatus);
        logger.info("getFinStatus needToGo= " + needToGo);
        String result = "";
        if (BusinessConst.GO_ACTION.PREVIOUS.equals(needToGo)) {
            if (BusinessConst.Flag.RMF.equals(currentStatus) || BusinessConst.Flag.BRMF.equals(currentStatus)) {
                result = BusinessConst.Flag.BRMP;
            }
        } else {
            if (BusinessConst.Flag.N.equals(currentStatus)) {
                result = BusinessConst.Flag.RMP;
            } else if (BusinessConst.Flag.RMP.equals(currentStatus) || BusinessConst.Flag.BRMP.equals(currentStatus)) {
                result = BusinessConst.Flag.RMF;
            } else if (BusinessConst.Flag.RMF.equals(currentStatus) || BusinessConst.Flag.BRMF.equals(currentStatus)) {
                result = BusinessConst.Flag.COMPLETE;
            }
        }
        logger.info("getFinStatus result= " + result);
        return result;
    }
    
    public String protestRemark() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("protestRemark");
        }
        return "showProtestRemark";
    }
    
    public String doSaveProtest() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doSaveProtest");
        }

        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        this.cifNo = titleVo.getCifNo();
        this.warningHeaderId = titleVo.getWarningHeaderId();
        logger.info("warningHeaderId >>> " + warningHeaderId);
        logger.info("warningId >>> " + warningId);
        logger.info("warningType >>> " + warningType);
        logger.info("questionId >>> " + questionId);
        logger.info("version >>> " + version);
        logger.info("infoStatus >>> " + infoStatus);
        logger.info("actionMode >>> " + actionMode);

        AsstTopicVo asstTopicVo = new AsstTopicVo();
        asstTopicVo.setWarningHeaderId(warningHeaderId);
        asstTopicVo.setWarningType(warningType);
        asstTopicVo.setWarningId(warningId);
        asstTopicVo.setQuestionId(questionId);
        asstTopicVo.setVersion(version);
        asstTopicVo.setCifNo(titleVo.getCifNo());
        asstTopicVo.setCustName(titleVo.getCustName());
        asstTopicVo.setRemark(rejectRemark);
        asstTopicVo.setActionCode(BusinessConst.ACTION_CODE.PROSTEST);
        
        asstQuestionBusiness.sendbackQuestion(asstTopicVo, getCurrentUser(), BusinessConst.Flag.PRMP, actionMode);

        return "taskList";//approveDone";
    }
     private void writeMSG(String msg) {
        PrintWriter print = null;
        try {
            this.response.setContentType("text/html; charset=UTF-8");
            print = this.response.getWriter();
            print.write(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }
}
