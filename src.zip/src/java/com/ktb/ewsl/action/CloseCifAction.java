/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.ParameterBusiness;
import com.ktb.ewsl.business.WarningCloseBusiness;
import com.ktb.ewsl.business.WarningCompletionBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktb.ewsl.vo.WarningCloseVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author pumin
 */
public class CloseCifAction extends BaseAction {

    private static final Logger log = Logger.getLogger(CloseCifAction.class);
    private String warningHeaderId;
    private String cifNo;
    private String customerName;
    private ArrayList<WarningCloseVo> closeList;
    private boolean canCloseJob;
    private boolean canCloseCif;
    private boolean canApprove;
    private String headerStatus;
    private WarningHeaderVo warningHeaderVo;
    private int warningId;
    private ArrayList<DropdownVo> reasonForCloseList;
    private String reason;
    private String warningType;
    private String rejectRemark;
    private String actionMode;
    private String title;
    private String returnCurrentHeaderStatus;
    private String lastestStatus;
    private String buttonDisplay = BusinessConst.Flag.N;
    
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private WarningCloseBusiness warningCloseBusiness;
    @Autowired
    private CustomerBusiness customerBusiness;
    @Autowired
    private WarningCompletionBusiness warningCompletionBusiness;
    @Autowired
    private ParameterBusiness parameterBusiness;

    public WarningHeaderVo getWarningHeaderVo() {
        return warningHeaderVo;
    }

    public void setWarningHeaderVo(WarningHeaderVo warningHeaderVo) {
        this.warningHeaderVo = warningHeaderVo;
    }

    public boolean isCanApprove() {
        return canApprove;
    }

    public void setCanApprove(boolean canApprove) {
        this.canApprove = canApprove;
    }

    public String getHeaderStatus() {
        return headerStatus;
    }

    public void setHeaderStatus(String headerStatus) {
        this.headerStatus = headerStatus;
    }

    public boolean isCanCloseJob() {
        return canCloseJob;
    }

    public void setCanCloseJob(boolean canCloseJob) {
        this.canCloseJob = canCloseJob;
    }

    public boolean isCanCloseCif() {
        return canCloseCif;
    }

    public void setCanCloseCif(boolean canCloseCif) {
        this.canCloseCif = canCloseCif;
    }

    public String getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(String warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public ArrayList<WarningCloseVo> getCloseList() {
        return closeList;
    }

    public void setCloseList(ArrayList<WarningCloseVo> closeList) {
        this.closeList = closeList;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public ArrayList<DropdownVo> getReasonForCloseList() {
        return reasonForCloseList;
    }

    public void setReasonForCloseList(ArrayList<DropdownVo> reasonForCloseList) {
        this.reasonForCloseList = reasonForCloseList;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getRejectRemark() {
        return rejectRemark;
    }

    public void setRejectRemark(String rejectRemark) {
        this.rejectRemark = rejectRemark;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReturnCurrentHeaderStatus() {
        return returnCurrentHeaderStatus;
    }

    public void setReturnCurrentHeaderStatus(String returnCurrentHeaderStatus) {
        this.returnCurrentHeaderStatus = returnCurrentHeaderStatus;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getLastestStatus() {
        return lastestStatus;
    }

    public void setLastestStatus(String lastestStatus) {
        this.lastestStatus = lastestStatus;
    }

    @Override
    public String success() throws Exception {
        log.info("CloseJobAction :success");
        log.info(" warningHeaderId = " + warningHeaderId);
        log.info(" cifNo = " + cifNo);
        if(StringUtil.isNotEmpty(warningHeaderId)){
        int headerID = Integer.parseInt(warningHeaderId);
            setButtonDisplay(checkCOOPWithCurrentLogin(getCurrentUser(), headerID));
        }
        findData();

        return SUCCESS;
    }

    private String checkCOOPWithCurrentLogin(UserData userData , int warningHeaderId) throws Exception{
       String result = BusinessConst.Flag.N;    
       log.debug("--------- CloseCifAction checkCOOPWithCurrentLogin ---------");
       log.debug(" warningHeaderId >>" +  warningHeaderId);
       log.debug(" userData.getRoleId() >>" +  userData != null ? userData.getRoleId() : "");
         if(warningHeaderId > 0){
            WarningHeaderVo headerVo = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
            if(headerVo != null){
            //ไม่มี CO ถึงทำงานได้
            if(BusinessConst.UserRole.AO.equals(userData.getRoleId()) || BusinessConst.UserRole.AE.equals(userData.getRoleId()) ||
                    BusinessConst.UserRole.RM.equals(userData.getRoleId()) || BusinessConst.UserRole.BCM.equals(userData.getRoleId())){
               
                if(StringUtil.isEmpty(headerVo.getCoRespUnitStr()) || "0".equals(headerVo.getCoRespUnitStr())){
                   result = BusinessConst.Flag.Y;    
                }
            }else if(BusinessConst.UserRole.RISK_EDITOR.equals(userData.getRoleId())){
                   result = BusinessConst.Flag.Y; 
            }else if(EWSConstantValue.ROLE_EDITOR_QULI_CO_OP.contains(userData.getRoleId())){
                   result = BusinessConst.Flag.Y;    
            }
           }
         }
        log.debug(" result >>" +  result);
        return result; 
     }
    
    public String closeCif() throws Exception {
        log.info("CloseJobAction : closeCif");
        WarningHeaderVo warningHeadVo   = warningHeaderBusiness.findWarningHeaderByPK(getWarningId());
        UserData        user            = getCurrentUser();
//        if ((warningHeadVo.getDpd() == null || warningHeadVo.getDpd() == 0) && (warningHeadVo.getOdOverAmt() == null || warningHeadVo.getOdOverAmt().intValue() == 0)) {
        //ให้เช็คที่ฟิลด์ DPD และ DPD_OD  (ไม่ต้องเช็คฟิลด์ OD_OVER_LIMIT) พี่ออนบอก ปอนด์แก้ 20160307
        if (EWSConstantValue.ROLE_BO_CHECK_DPD.contains(user.getRoleId())) {
            if ((warningHeadVo.getDpd() == null || warningHeadVo.getDpd() == 0) 
                    && (warningHeadVo.getDpdOd() == null || warningHeadVo.getDpdOd().intValue() == 0)) {
                setCanCloseCif(true);
            }else{
                setCanCloseCif(false);
            }
        }else{
            setCanCloseCif(true);
        }
        
        
        request.getSession(false).setAttribute("closeJobCifNo" + user.getCurrentId(), getCifNo());
        request.getSession(false).setAttribute("closeJobWarningHeaderId" + user.getCurrentId(), getWarningHeaderId());

        return "closeCif";
    }

    public String rejectRemark() throws Exception {
        log.info("CloseJobAction : rejectRemark");
        UserData user = getCurrentUser();
        request.getSession(false).setAttribute("closeJobCifNo" + user.getCurrentId(), getCifNo());
        request.getSession(false).setAttribute("closeJobWarningHeaderId" + user.getCurrentId(), getWarningHeaderId());

        return "rejectRemark";
    }

    public String confirmClose() throws Exception {
        log.info("CloseJobAction : confirmClose");
        /* <<< condition >>> 
         * insert  TBL_WARNING_CLOSE  STATUS = C  
         if (TBL_WARNING_HEADER.CR_FLG IN ('N','I'))  then :  update TBL_WARNING_HEADER.STATUS = W  , UPDATED_DT , UPDATED_BY 
         else {
         update TBL_WARNING_HEADER.STATUS = C  , UPDATED_DT , UPDATED_BY 
         insert TBL_WARNING_COMPLETION COMPLETE_FLG = A
         }
         * */

        UserData user = getCurrentUser();
        WarningHeaderVo warningHeadVo = warningHeaderBusiness.findWarningHeaderByPK(Integer.parseInt(getWarningHeaderId()));

        WarningCloseVo warningCloseVo = new WarningCloseVo();
        warningCloseVo.setStatus("C");
        warningCloseVo.setReasonFlg(warningCloseBusiness.getReasonFlg(getWarningHeaderId()));
        warningCloseVo.setWarningHeadId(getWarningHeaderId());
        warningCloseVo.setRemark("อนุมัติปิดงาน");
        warningCloseVo.setCreatedBy(user.getEmpNo());
        warningCloseVo.setCreatedDt(DateUtil.getCurrentDateTime());
        warningCloseVo.setRoleCode(user.getRoleId());
        warningCloseBusiness.insertWarningClose(warningCloseVo);

        WarningHeaderVo headVo = new WarningHeaderVo();
        headVo.setWarningHeaderId(Integer.parseInt(getWarningHeaderId()));
        headVo.setUpdatedBy(user.getEmpNo());
        headVo.setUpdatedDate(DateUtil.getCurrentDateTime());
        if (warningHeadVo.getCrFlg() != null && ("N".equals(warningHeadVo.getCrFlg()) || "I".equals(warningHeadVo.getCrFlg()))) {
            headVo.setStatus("W");
            warningHeaderBusiness.updateStatusWarningHeader(headVo);
        } else {
//            headVo.setStatus("C");
//            warningHeaderBusiness.updateStatusWarningHeader(headVo);
//
//            WarningCompletionVo compVo = new WarningCompletionVo();
//            compVo.setWarningHeadId(getWarningHeaderId());
//            compVo.setCreatedBy(user.getEmpNo());
//            compVo.setCreatedDt(DateUtil.getCurrentDateTime());
//            compVo.setCompleteFlg("A");
//            compVo.setRemark("อนุมัติปิดงาน");
//            warningCompletionBusiness.InsertWarningCompletion(compVo);
            warningHeaderBusiness.updateForApproveForCloaseByCif(headVo, "A");
        }

        findData();
        return SUCCESS;
    }

    public String backToList() throws Exception {
        log.info("CloseJobAction : backToList");
        return "backToList";
    }

    protected void findData() throws Exception {
        setCanCloseJob(false);
        setCanApprove(false);
        UserData user = getCurrentUser();
        setCustomerName(customerBusiness.selectCustomerByCif(Integer.parseInt(getCifNo())).getCustName());

        ArrayList<WarningCloseVo> closeListTmp = warningCloseBusiness.getWarningClose(getWarningHeaderId());
        HashMap hasData = getParamCloseJob();
        if (closeListTmp != null && !closeListTmp.isEmpty()) {
            for (WarningCloseVo wcVo : closeListTmp) {
                if (wcVo.getReasonFlg() != null && !"".equals(wcVo.getReasonFlg().trim())) {
                    wcVo.setReasonDetail((String) hasData.get(wcVo.getReasonFlg().trim()));
                }
            }
        }
        setCloseList(closeListTmp);
        
        this.lastestStatus = warningCloseBusiness.getStatusByMaxCreatedDt(getWarningHeaderId());
        
        log.info("lastestStatus :: " + this.lastestStatus);
        
        WarningHeaderVo wVo = warningHeaderBusiness.findWarningHeaderByPK(Integer.parseInt(getWarningHeaderId()));
        
//        if (EWSConstantValue.ROLE_CLOSE_JOB.contains(user.getRoleId())) {
//            setCanCloseJob(true);
//        }
//        if (isCanCloseJob() && (EWSConstantValue.ROLE_CLOSE_JOB_APPROVE.contains(user.getRoleId()))) {
//            setCanApprove(true);
//        }
//        
//        if (EWSConstantValue.ROLE_BO_CHECK_DPD.contains(user.getRoleId())) {
//            if ((wVo.getDpd() == null || wVo.getDpd() == 0) 
//                    && (wVo.getDpdOd() == null || wVo.getDpdOd().intValue() == 0)) {
//                setCanCloseCif(true);
//            }else{
//                setCanCloseCif(false);
//            }
//        }else{
//            setCanCloseCif(true);
//        }
        
        if (EWSConstantValue.ROLE_CLOSE_JOB.contains(user.getRoleId())) {
            setCanCloseJob(true);
        }

        if (isCanCloseJob() && (EWSConstantValue.ROLE_CLOSE_JOB_APPROVE.contains(user.getRoleId()))) {
            setCanApprove(true);
        }

        if (EWSConstantValue.ROLE_BO_CHECK_DPD.contains(user.getRoleId())) {
            if ((wVo.getDpd() == null || wVo.getDpd() == 0) 
                    && (wVo.getDpdOd() == null || wVo.getDpdOd().intValue() == 0)) {
                setCanCloseCif(true);
            }else{
                setCanCloseCif(false);
            }
        }else{
            setCanCloseCif(true);
        }
        
        
        setWarningHeaderVo(wVo);
        setHeaderStatus(wVo.getStatus());

    }

    private HashMap getParamCloseJob() throws Exception {
        ArrayList<ParameterVo> list = parameterBusiness.getParameterByTypeId(BusinessConst.PARAMETER_TYPE_ID.CLOSE_BY_CIF_REASON, "PARAMETER_ID");
        HashMap hash = new HashMap();
        if (list != null && !list.isEmpty()) {
            for (ParameterVo vo : list) {
                hash.put(vo.getParameterId().trim(), vo.getParameterName());
            }
        }
        return hash;
    }

    public String getButtonDisplay() {
        return buttonDisplay;
    }

    public void setButtonDisplay(String buttonDisplay) {
        this.buttonDisplay = buttonDisplay;
    }
    
}
