/* To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.CustomerBusiness;
import com.ktb.ewsl.business.QcaFinancialBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.FinancialCustomerVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.external.optimist.FinUtil;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Kat
 */
public class FinancialAction extends BaseAction {

    private static final Logger logger = Logger.getLogger(FinancialAction.class);
    private static String OPTIMIST = "gotoOptimist";
    private String cifNo;
    private int warningHeaderId;
    private String custCatCd;
    private String custName;
    private String custTypeName;
    private FinancialVo financialVo;
    private String message;
    private String cifNoOpt;
    private String reasonChoice;
    private List<FinancialCustomerVo> customerList;
    private int warningInfoId;
    private int warningId;
    private String warningType;
    private String canApprove;
    private String infoStatus;
    private String roleCanGotoOptimist;
    private int backWarningHeaderId;
    private String backCifNo;
    private String hvFin;
    private List<ActionHistoryVo> actionHistoryVoList;
    private ArrayList reasonSelectList;
    private String reasonSelect;
    private String reasonDetail;
    private ArrayList reasonSelectListYes;
    private String reasonSelectY;
    private String reasonSelectN;
    private String reasonChoiceNo;
    private String reasonChoiceYes;
    private String canProtest;
    private String showButtonForClose;
    private FinancialVo lastFinancialVo;
    private List<QuestionHistoryVo>  questionHistoryList;
    private String actionDate;
    private String displayFinalCompleteFromCloseReport;
    private String backdisplayFinalCompleteFromCloseReport;
     private String warningHeaderIdHistory;
     private String warningIdHistory;
     private String warningTypeHistory;
     private String  actionDateHistory;
     private String forBackPage;
     private String delayReason;
     private String showButtonForSaveFINAfterWS;
     private String enableTextAreaSaveFINAfterWS;
     private String currentUserRole;
     private String showTextAreaDelayReason;
            
    @Autowired
    private QcaFinancialBusiness qcaFinancialBusiness;
    @Autowired
    private CustomerBusiness customerBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness; 
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness; 

    public String getWarningHeaderIdHistory() {
        return warningHeaderIdHistory;
    }

    public void setWarningHeaderIdHistory(String warningHeaderIdHistory) {
        this.warningHeaderIdHistory = warningHeaderIdHistory;
    }

    public String getWarningIdHistory() {
        return warningIdHistory;
    }

    public void setWarningIdHistory(String warningIdHistory) {
        this.warningIdHistory = warningIdHistory;
    }

    public String getWarningTypeHistory() {
        return warningTypeHistory;
    }

    public void setWarningTypeHistory(String warningTypeHistory) {
        this.warningTypeHistory = warningTypeHistory;
    }

    public String getActionDateHistory() {
        return actionDateHistory;
    }

    public void setActionDateHistory(String actionDateHistory) {
        this.actionDateHistory = actionDateHistory;
    }

    
    public List<QuestionHistoryVo> getQuestionHistoryList() {
        return questionHistoryList;
    }

    public String getActionDate() {
        return actionDate;
    }

    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }

    public void setQuestionHistoryList(List<QuestionHistoryVo> questionHistoryList) {
        this.questionHistoryList = questionHistoryList;
    }

    
    public FinancialVo getLastFinancialVo() {
        return lastFinancialVo;
    }

    public void setLastFinancialVo(FinancialVo lastFinancialVo) {
        this.lastFinancialVo = lastFinancialVo;
    }

    
    public String getReasonChoiceNo() {
        return reasonChoiceNo;
    }

    public void setReasonChoiceNo(String reasonChoiceNo) {
        this.reasonChoiceNo = reasonChoiceNo;
    }

    public String getReasonChoiceYes() {
        return reasonChoiceYes;
    }

    public void setReasonChoiceYes(String reasonChoiceYes) {
        this.reasonChoiceYes = reasonChoiceYes;
    }

    
    
    public String getReasonSelectY() {
        return reasonSelectY;
    }

    public void setReasonSelectY(String reasonSelectY) {
        this.reasonSelectY = reasonSelectY;
    }

    public String getReasonSelectN() {
        return reasonSelectN;
    }

    public void setReasonSelectN(String reasonSelectN) {
        this.reasonSelectN = reasonSelectN;
    }

    
    public ArrayList getReasonSelectListYes() {
        return reasonSelectListYes;
    }

    public void setReasonSelectListYes(ArrayList reasonSelectListYes) {
        this.reasonSelectListYes = reasonSelectListYes;
    }

    public String getReasonSelect(){
        return this.reasonSelect;
    }
    public void setReasonSelect(String resaonSelect){
        this.reasonSelect = resaonSelect;
    }
    public String getReasonDetail(){
        return this.reasonDetail;
    }
    public void setReasonDetail(String reasonDetail){
        this.reasonDetail = reasonDetail;
    }
    public ArrayList getReasonSelectList(){
        return reasonSelectList;
    }
    public void setReasonSelectList(ArrayList reasonSelectList){
         this.reasonSelectList = reasonSelectList;
    }
    public String getCifNoOpt() {
        return cifNoOpt;
    }

    public void setCifNoOpt(String cifNoOpt) {
        this.cifNoOpt = cifNoOpt;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public FinancialVo getFinancialVo() {
        return financialVo;
    }

    public void setFinancialVo(FinancialVo financialVo) {
        this.financialVo = financialVo;
    }

    public String getCustTypeName() {
        return custTypeName;
    }

    public void setCustTypeName(String custTypeName) {
        this.custTypeName = custTypeName;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustCatCd() {
        return custCatCd;
    }

    public void setCustCatCd(String custCatCd) {
        this.custCatCd = custCatCd;
    }

    public List<FinancialCustomerVo> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<FinancialCustomerVo> customerList) {
        this.customerList = customerList;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getReasonChoice() {
        return reasonChoice;
    }

    public void setReasonChoice(String reasonChoice) {
        this.reasonChoice = reasonChoice;
    }

    public int getWarningInfoId() {
        return warningInfoId;
    }

    public void setWarningInfoId(int warningInfoId) {
        this.warningInfoId = warningInfoId;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getCanApprove() {
        return canApprove;
    }

    public void setCanApprove(String canApprove) {
        this.canApprove = canApprove;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public String getRoleCanGotoOptimist() {
        return roleCanGotoOptimist;
    }

    public void setRoleCanGotoOptimist(String roleCanGotoOptimist) {
        this.roleCanGotoOptimist = roleCanGotoOptimist;
    }

    public int getBackWarningHeaderId() {
        return backWarningHeaderId;
    }

    public void setBackWarningHeaderId(int backWarningHeaderId) {
        this.backWarningHeaderId = backWarningHeaderId;
    }

    public String getBackCifNo() {
        return backCifNo;
    }

    public void setBackCifNo(String backCifNo) {
        this.backCifNo = backCifNo;
    }

    public String getHvFin() {
        return hvFin;
    }

    public void setHvFin(String hvFin) {
        this.hvFin = hvFin;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public List<ActionHistoryVo> getActionHistoryVoList() {
        return actionHistoryVoList;
    }

    public void setActionHistoryVoList(List<ActionHistoryVo> actionHistoryVoList) {
        this.actionHistoryVoList = actionHistoryVoList;
    }

    public String getCanProtest() {
        return canProtest;
    }

    public void setCanProtest(String canProtest) {
        this.canProtest = canProtest;
    }

    public String getShowButtonForClose() {
        return showButtonForClose;
    }

    public void setShowButtonForClose(String showButtonForClose) {
        this.showButtonForClose = showButtonForClose;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }

    @Override
    public String success() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("success");
            logger.debug(" getCifNo : " + getCifNo());
            logger.debug(" getWarningHeaderId : " + getWarningHeaderId());
            logger.debug(" getWarningInfoId : " + getWarningInfoId());
            logger.debug(" getWarningType : " + getWarningType());
            logger.debug(" getInfoStatus : " + getInfoStatus());
        }
        setHeaderDetail();
        setCurrentUserRole(getCurrentUser() != null ?  getCurrentUser().getRoleId() : "");
        //init
        initPage(getCifNo());
        FinancialVo fVO = qcaFinancialBusiness.checkHVFin(getCifNo());
        if (warningInfoId == fVO.getWarningInfoId()) {
            getFinancialDetail(getCustName(), getCustTypeName());
            request.setAttribute("FINANCIAL_BO", this.getFinancialVo());
        } else{
      /*    Comment For not Default
      *     setReasonChoiceYes("N");
            setReasonChoiceNo("N");
            setReasonSelectY("N");
            setReasonSelectN("N"); */
            if (getFinancialVo() != null) {
                getFinancialVo().setReasonCode("");
                getFinancialVo().setReasonSelectY("");
                getFinancialVo().setReasonCode("");
                getFinancialVo().setReasonDetail("");
            }
            getLastFinancialDetail(getCustName(), getCustTypeName());
            if(getLastFinancialVo() !=null && "Y".equals(FinUtil.null2Empty(this.getLastFinancialVo().getHvFin()))){
                getLastFinancialVo().setReasonCode("");
                getLastFinancialVo().setReasonDetail("");
                getLastFinancialVo().setReasonSelectN("");
                getLastFinancialVo().setReasonSelectY("");
                request.setAttribute("FINANCIAL_BO", this.getLastFinancialVo());
            }
        }
        if(reasonSelectList == null || reasonSelectList.isEmpty() ){
            reasonSelectList = getReasonSelectListDataNo();
        }
        if(reasonSelectListYes == null || reasonSelectListYes.isEmpty()){
            reasonSelectListYes = getReasonSelectListDataYes();
        }
       
        UserData userData = getCurrentUser();
        logger.debug(" warningHeaderId = " + warningHeaderId);
        logger.debug(" warningInfoId = " + warningInfoId);
        logger.debug(" warningType = " + warningType);
        logger.debug(" reasonChoice = " + reasonChoice);
        logger.debug(" infoStatus = " + infoStatus);
         
        if (EWSConstantValue.ROLE_APPROVE_REJECT_STEP_1.contains(userData.getRoleId()) && EWSConstantValue.STATUS_APPROVE_REJECT_STEP_1.contains(infoStatus)) {
            setCanApprove(BusinessConst.Flag.Y);
        } else {
            setCanApprove(BusinessConst.Flag.N);
        }

        if ((EWSConstantValue.ROLE_GOTO_OPTIMIST.contains(userData.getRoleId())) && (EWSConstantValue.STATUS_GOTO_OPTIMIST.contains(infoStatus))) {
            setRoleCanGotoOptimist(BusinessConst.Flag.Y);
        } else {
            setRoleCanGotoOptimist(BusinessConst.Flag.N);
        }
        setCanProtest(BusinessConst.Flag.N);
        
         logger.debug(" warningInfoId = " + warningInfoId);
         logger.debug(" fVO.getWarningInfoId() = " + fVO.getWarningInfoId());
         logger.debug(" fVO.getHvFin() = " + fVO.getHvFin());
         logger.debug(" getWarningInfoId() = " + getWarningInfoId());
         logger.debug(" getWarningType() = " + getWarningType());
        //-------START-------------Validate Over 18 month : After Send FIN------------------------//
         setShowTextAreaDelayReason(BusinessConst.Flag.N);
         setEnableTextAreaSaveFINAfterWS("false");
        if (warningInfoId == fVO.getWarningInfoId() && "Y".equals(fVO.getHvFin()) && !ValidatorUtil.isNullOrEmpty(fVO.getFinTrnId())) {
             setShowTextAreaDelayReason(BusinessConst.Flag.Y);
             if(BusinessConst.Flag.RMF.equals(infoStatus) || BusinessConst.Flag.COMPLETE.equals(infoStatus)){
                 setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
                 setEnableTextAreaSaveFINAfterWS("true");
             }//else if(BusinessConst.Flag.RMP.equals(infoStatus)|| BusinessConst.Flag.BRMP.equals(infoStatus)){
             else if(BusinessConst.Flag.BRMP.equals(infoStatus)|| BusinessConst.Flag.PRMP.equals(infoStatus)){ //----- Require Send Optimis again
                setRoleCanGotoOptimist(BusinessConst.Flag.Y);
                setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
             }else if(BusinessConst.Flag.RMP.equals(infoStatus)){
                WarningInfoVo infoVo =  warningInfoBusiness.findWarningInfoObj(getWarningHeaderId(), getWarningInfoId(), getWarningType());
                if(infoVo != null){
                    if(EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(infoVo.getHolderRole()) &&
                             EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(getCurrentUser().getRoleId())){
                        setRoleCanGotoOptimist(BusinessConst.Flag.N);
                        setShowButtonForSaveFINAfterWS(BusinessConst.Flag.Y);
                    }else if(BusinessConst.UserRole.BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())){
                          setRoleCanGotoOptimist(BusinessConst.Flag.N);
                          setShowButtonForSaveFINAfterWS(BusinessConst.Flag.Y);
                    }else{
                        setRoleCanGotoOptimist(BusinessConst.Flag.N);
                        setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
                    }
                }
            }else{
                setRoleCanGotoOptimist(BusinessConst.Flag.N);
                setShowButtonForSaveFINAfterWS(BusinessConst.Flag.Y);
             }
        }else{
             setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
        }    
        //------END-------------- Validate Over 18 month : After Send FIN------------------------//
        
        if(!BusinessConst.Flag.COMPLETE.equals(infoStatus)){
            WarningInfoVo warningInfoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
            if (warningInfoVo != null && BusinessConst.Flag.Y.equals(warningInfoVo.getCloseFlag())) {
                setRoleCanGotoOptimist(BusinessConst.Flag.N);
                setCanApprove(BusinessConst.Flag.N);
                setCanProtest(BusinessConst.Flag.N);
                if (EWSConstantValue.ROLE_APPROVE_CLOSE_JOB.contains(userData.getRoleId())) {
                    showButtonForClose = "C2";
                }
            } else {
                if (EWSConstantValue.ROLE_EDITOR_FIN.contains(userData.getRoleId())) {
                    showButtonForClose = "C1";
                }
            }
        }
        
        /*begin Release 3.1*/
            if (EWSConstantValue.ROLE_EDITOR_OLD.contains(getCurrentUser().getRoleId())) {
                WarningHeaderVo wh = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
                if(wh!=null){
                    if(!ValidatorUtil.isNullOrEmpty(wh.getCoRespUnitStr()) && !"0".equals(wh.getCoRespUnitStr())){
                        showButtonForClose  = "";
                        roleCanGotoOptimist = BusinessConst.Flag.N;
                        canApprove          = BusinessConst.Flag.N;
                        canProtest          = BusinessConst.Flag.N;
                    }
                }
            }
            /*end Release 3.1*/
        
        if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
            if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                showButtonForClose  = "";
                roleCanGotoOptimist = BusinessConst.Flag.N;
                canApprove          = BusinessConst.Flag.N;
                canProtest          = BusinessConst.Flag.N;
                
          /*    Comment For not Default
           *    setReasonChoiceYes("N");
                setReasonChoiceNo("N");
                setReasonSelectY("N");
                setReasonSelectN("N"); */
            }
            request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
        }
        
        return SUCCESS;
    }
    @Override
    public String save() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("FinancialAction.save");
            logger.info("hvFin = " + hvFin);
            logger.info("getHvFin = " + getHvFin());
        }
        if(getCurrentUser() != null && BusinessConst.UserRole.ADMIN.equals(getCurrentUser().getRoleId())){
          return OPTIMIST;
        }
        String tmpFin = getHvFin();
        setReasonChoice(tmpFin);
        if(getReasonChoice() != null || !"".equals(getReasonDetail()))
        {
            if(getReasonChoiceYes() !=null && !"".equals(getReasonChoiceYes())){
                setReasonSelect(getReasonSelectY());
                setReasonDetail(getReasonDetial(getReasonSelectY(),getReasonSelectListDataYes())); 
            }else if(getReasonChoiceNo() !=null && !"".equals(getReasonChoiceNo())){
                setReasonSelect(getReasonSelectN());
               if(getReasonSelectN()!=null && "6".equals(getReasonSelectN())){
                setReasonDetail(getReasonDetail()); 
               }else setReasonDetail(getReasonDetial(getReasonSelectN(),getReasonSelectListDataNo())); 
            }
        }
        
        setHeaderDetail();
        keepDetailFormToBean();
        getFinancialVo().setReasonCode(getReasonSelect());
        getFinancialVo().setReasonDetail(getReasonDetail());
        getFinancialVo().setDelayReason(getDelayReason() != null ? getDelayReason() : "");
        
        boolean isSuccess = false;
        try {
           isSuccess = qcaFinancialBusiness.saveFinancial(getFinancialVo(), getCurrentUser());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getCause() != null) {
                this.setMessage(" : " + e.getCause());
            } else {
                this.setMessage(" : " + e.getMessage());
            }
        }

        System.out.println("isSuccess : " + isSuccess);
        if (isSuccess) {
            logger.debug("-----FinancialAction : FOR   update WarningHeader , WarningInfo -----------");
            logger.debug(" warningHeaderId = " + warningHeaderId);
            logger.debug(" warningInfoId = " + warningInfoId);
            logger.debug(" warningType = " + warningType);
            logger.debug(" reasonChoice = " + reasonChoice);
            logger.debug(" infoStatus = " + infoStatus);
            logger.debug(" cifNo = " + cifNo);
            String currentStatus;
            String actionCode;
            String finFlagInHeader;
            if (reasonChoice != null && "Y".equals(reasonChoice)) {
                currentStatus = BusinessConst.Flag.RMP;
                actionCode = "Draft";
                finFlagInHeader = BusinessConst.Flag.N;
            } else {
                currentStatus = BusinessConst.Flag.RMF;
                actionCode = "Save";
                finFlagInHeader = BusinessConst.Flag.INPROCESS;
            }
            if (!ValidatorUtil.isNullOrEmpty(warningHeaderId) && !ValidatorUtil.isNullOrEmpty(warningInfoId)
                    && !ValidatorUtil.isNullOrEmpty(currentStatus) && !ValidatorUtil.isNullOrEmpty(infoStatus)) {
                 warningInfoBusiness.updateStatusByWarningIdAndType(warningInfoId, warningType, getCurrentUser(), currentStatus, actionCode, currentStatus);
                 asstQuestionBusiness.checkAllXxFlagForUpdateHeaderStatus(warningHeaderId, getCurrentUser().getEmpNo(), BusinessConst.GO_ACTION.NAXT);
                 warningHeaderBusiness.updateFlagInWarningHeaderForFin(warningHeaderId, getCurrentUser(), finFlagInHeader);
              
                WarningInfoVo warningInfo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                infoStatus = warningInfo.getStatus();
            }

            if ("Y".equalsIgnoreCase(getReasonChoice())) {
                return OPTIMIST;
            } else {
                //------------------- BCM - DO IT----------------------//
                logger.debug(" getCurrentUser().getRoleId() = " + getCurrentUser().getRoleId());
//                if(getCurrentUser() != null && BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())){
                //R3.1
                if(getCurrentUser() != null 
                        && (BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()) 
                            || BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId()))){
                       approveFin();
                }
                //------------------------------------------------------//
                getFinancialDetail(getCustName(), getCustTypeName());
                request.setAttribute("FINANCIAL_BO", this.getFinancialVo());

                String tmpHvFin = FinUtil.null2Empty(qcaFinancialBusiness.checkHVFin(getCifNo()).getHvFin());
                if ("Y".equals(tmpHvFin.trim())) {
                    setReasonChoice("Y");
                    setReasonChoiceYes("Y");
                } else {
                    setReasonChoice("N");
                    setReasonChoiceNo("N");
                    request.setAttribute("FINANCIAL_BO", new FinancialVo());
                }

                //------------Render --------//
                UserData userData = getCurrentUser();
                if (EWSConstantValue.ROLE_APPROVE_REJECT_STEP_1.contains(userData.getRoleId()) && EWSConstantValue.STATUS_APPROVE_REJECT_STEP_1.contains(infoStatus)) {
                    setCanApprove(BusinessConst.Flag.Y);
                } else {
                    setCanApprove(BusinessConst.Flag.N);
                }
                if (EWSConstantValue.ROLE_GOTO_OPTIMIST.contains(userData.getRoleId()) && (EWSConstantValue.STATUS_GOTO_OPTIMIST.contains(infoStatus))) {
                    setRoleCanGotoOptimist(BusinessConst.Flag.Y);
                } else {
                    setRoleCanGotoOptimist(BusinessConst.Flag.N);
                }
   
                setCanProtest(BusinessConst.Flag.N);

                setBackCifNo(getCifNo());
                setBackWarningHeaderId(warningHeaderId);
                return "backTaskList";
            }
        }
        return SUCCESS;
    }

    public String gotoDetail() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("gotoDetail");
            logger.info("warningHeaderId = " + warningHeaderId);
            logger.info("cifNo = " + cifNo);
            logger.info("warningInfoId = " + warningInfoId);
            logger.info("warningType = " + warningType);
            logger.info("infoStatus = " + infoStatus);
        }

        //kat add
        logger.info(" CIF No = " + cifNo);
        setHeaderDetail();
        initPage(getCifNo());
        String cif = "";
        String custName = "";
        String custTypeName = "";
        FinancialCustomerVo tmpCustomer = null;
        for (int i = 0; i < getCustomerList().size(); i++) {
            tmpCustomer = getCustomerList().get(i);

            if (getCifNo().equals(tmpCustomer.getCifNo())) {
                cif = tmpCustomer.getCifNo();
                custName = tmpCustomer.getFirstNameTh(); 
                if ("1".equals(getCustCatCd())) {
                    custTypeName += "\u0E19\u0E34\u0E15\u0E34\u0E1A\u0E38\u0E04\u0E04\u0E25";
                }
                break;
            }
        }

        logger.info(custName);
        setCustName(custName);
        logger.info(custTypeName);
        setCustTypeName(custTypeName);

        getFinancialDetail(custName, custTypeName);

        String tmpHvFin = FinUtil.null2Empty(qcaFinancialBusiness.checkHVFin(getCifNo()).getHvFin());
        if ("Y".equals(tmpHvFin.trim())) {
            setReasonChoice("Y");
            setReasonChoiceYes("Y");
            System.out.println("FINANCIAL_BO : " + getFinancialVo().getRatioList().size());
            request.setAttribute("FINANCIAL_BO", getFinancialVo());
        } else {
            setReasonChoice("N");
            setReasonChoiceNo("N");
            request.setAttribute("FINANCIAL_BO", new FinancialVo());
        }
       
        UserData userData = getCurrentUser();
        String currentStatus = infoStatus;
        if (!ValidatorUtil.isNullOrEmpty(warningHeaderId) && !ValidatorUtil.isNullOrEmpty(warningInfoId) && !ValidatorUtil.isNullOrEmpty(warningType)) {
            WarningInfoVo info = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
            currentStatus = info.getStatus();
            setInfoStatus(currentStatus);
        }
        logger.info("currentStatus = " + currentStatus);
        if (EWSConstantValue.ROLE_APPROVE_REJECT_STEP_1.contains(userData.getRoleId()) && EWSConstantValue.STATUS_APPROVE_REJECT_STEP_1.contains(currentStatus)) {
            setCanApprove(BusinessConst.Flag.Y);
        } else {
            setCanApprove(BusinessConst.Flag.N);
        }
        if (EWSConstantValue.ROLE_GOTO_OPTIMIST.contains(userData.getRoleId()) && (EWSConstantValue.STATUS_GOTO_OPTIMIST.contains(currentStatus))) {
            setRoleCanGotoOptimist(BusinessConst.Flag.Y);
        } else {
            setRoleCanGotoOptimist(BusinessConst.Flag.N);
        }
        setCanProtest(BusinessConst.Flag.N);
         //-------START------------- Validate Over 18 month : After Send FIN------------------------//
         FinancialVo fVOValidate = qcaFinancialBusiness.checkHVFin(getCifNo());
         setEnableTextAreaSaveFINAfterWS("false");
         setShowTextAreaDelayReason(BusinessConst.Flag.N);
        if (warningInfoId == fVOValidate.getWarningInfoId() && "Y".equals(fVOValidate.getHvFin()) && !ValidatorUtil.isNullOrEmpty(fVOValidate.getFinTrnId())) {
             setShowTextAreaDelayReason(BusinessConst.Flag.Y);
             if(BusinessConst.Flag.RMF.equals(infoStatus) || BusinessConst.Flag.COMPLETE.equals(infoStatus)){
                 setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
                 setEnableTextAreaSaveFINAfterWS("true");
             }else if(BusinessConst.Flag.BRMP.equals(infoStatus)|| BusinessConst.Flag.PRMP.equals(infoStatus)){ //----- Require Send Optimis again
                setRoleCanGotoOptimist(BusinessConst.Flag.Y);
                setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
             }//else if(BusinessConst.Flag.RMP.equals(infoStatus)|| BusinessConst.Flag.BRMP.equals(infoStatus)){
             else if(BusinessConst.Flag.RMP.equals(infoStatus)){
                WarningInfoVo infoVo =  warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                if(infoVo != null){
                    if(EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(infoVo.getHolderRole()) &&
                             EWSConstantValue.ROLE_DRAFT_DO_REPRESENT.contains(getCurrentUser().getRoleId())){
                        setRoleCanGotoOptimist(BusinessConst.Flag.N);
                        setShowButtonForSaveFINAfterWS(BusinessConst.Flag.Y);
//                    }else if(BusinessConst.UserRole.BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())){
                    }else if((BusinessConst.UserRole.BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId()))
                                || (BusinessConst.UserRole.CO_BCM.equals(infoVo.getHolderRole()) && BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId()))){
                          setRoleCanGotoOptimist(BusinessConst.Flag.N);
                          setShowButtonForSaveFINAfterWS(BusinessConst.Flag.Y);
                    }else{
                        setRoleCanGotoOptimist(BusinessConst.Flag.N);
                        setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
                    }
                }
            }else{
                setRoleCanGotoOptimist(BusinessConst.Flag.N);
                setShowButtonForSaveFINAfterWS(BusinessConst.Flag.Y);
             }
        }else{
             setShowButtonForSaveFINAfterWS(BusinessConst.Flag.N);
        }    
        //------END-------------- Validate Over 18 month : After Send FIN------------------------//
  
        if(getReasonSelectList() ==null || getReasonSelectList().isEmpty() ){
            setReasonSelectList(getReasonSelectListDataNo());
        }
        if(getReasonSelectListDataYes() == null ||getReasonSelectListDataYes().isEmpty() ){
            setReasonSelectListYes(getReasonSelectListDataYes());
        }
        return SUCCESS;
    }

    private void getFinancialDetail(String custName, String custTypeName) {
        try {
            setFinancialVo(qcaFinancialBusiness.getFinancialVO(null, getCifNo()));

            if (getFinancialVo() == null) {
                logger.info("FinancialVo is null");
                FinancialVo financialVO = new FinancialVo();
                financialVO.setHvFin("");
                financialVO.setReasonCode("");
                financialVO.setReasonSelectN("");
                financialVO.setReasonSelectY("");
                financialVO.setReasonDetail("");
                setFinancialVo(financialVO);
                setMessage("");
            } else {
                getFinancialVo().setRatioList(qcaFinancialBusiness.getRatioList(getFinancialVo(), qcaFinancialBusiness.getRatioList(getFinancialVo().getTrnId())));
                getFinancialVo().setCifNo(getCifNo());
                getFinancialVo().setCustName(custName);
                getFinancialVo().setCustTypeName(custTypeName);
            }
        } catch (Exception e) {
        }
    }

    private void keepDetailFormToBean() {
        logger.info("[keepDetailFormToBean]");
        try {
            setFinancialVo(new FinancialVo());//kat fix
            System.out.println("getReasonChoice : " + getReasonChoice());
            if (getReasonChoice() != null && getReasonChoice().equals("Y")) {
                getFinancialVo().setHvFin("Y");
            } else {
                getFinancialVo().setHvFin("N");
            }
            
            getFinancialVo().setReasonCode(getReasonSelect()); // pumin: add reason code
            getFinancialVo().setReasonDetail(getReasonDetail());// pumin: add reason detail
            getFinancialVo().setCif(cifNo);
            getFinancialVo().setWarningInfoId(warningInfoId);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initPage(String cifId) {
        try {
            CustomerVo custVo = customerBusiness.selectCustomerByCif(Integer.valueOf(cifId));
            if (custVo == null) {
                logger.info(" CustomerList is null ");
            } else {
                FinancialCustomerVo finCustVo = new FinancialCustomerVo();
                finCustVo.setCifNo(cifId);
                finCustVo.setFirstNameTh(custVo.getCustName());
                finCustVo.setCustCatCd("1");
                List<FinancialCustomerVo> tmpCustlist = new ArrayList<FinancialCustomerVo>();
                tmpCustlist.add(finCustVo);

                setCustomerList(tmpCustlist);
                setFinancialVo(qcaFinancialBusiness.getCurrentQcaFin(cifId));
                setReasonSelectList(getReasonSelectListDataNo());
                setReasonSelectListYes(getReasonSelectListDataYes());
                setReasonSelectN(getFinancialVo().getReasonSelectN());
                setReasonSelectY(getFinancialVo().getReasonSelectY());
                setHvFin(getFinancialVo().getHvFin());
                if(getFinancialVo().getHvFin()!=null && "N".equalsIgnoreCase(getFinancialVo().getHvFin()))
                {
                    setReasonChoiceNo(getFinancialVo().getHvFin());
                }else if(getFinancialVo().getHvFin() !=null && "Y".equalsIgnoreCase(getFinancialVo().getHvFin()))
                {
                    setReasonChoiceYes(getFinancialVo().getHvFin());
                }
         
                findQuestionHistory(cifId) ;
                 setDelayReason(getFinancialVo().getDelayReason() != null ? getFinancialVo().getDelayReason() : "");
                logger.info(" Customer name = " + custVo.getCustName());
                
            }
        } catch (Exception e) {
            logger.error(e.toString());
        }
    }

    public void setHeaderDetail() throws Exception{
        TitleVo titleVo = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        if(titleVo != null){
        setCifNo(titleVo.getCifNo());
        setWarningHeaderId(titleVo.getWarningHeaderId());
        setCustName(titleVo.getCustName());
        }
        
        this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(warningInfoId);
    }

    public String approveFin() throws Exception {
        try {
            
            if (!ValidatorUtil.isNullOrEmpty(warningHeaderId) && !ValidatorUtil.isNullOrEmpty(warningInfoId)
                    && !ValidatorUtil.isNullOrEmpty(warningType) && !ValidatorUtil.isNullOrEmpty(infoStatus)
                    && !ValidatorUtil.isNullOrEmpty(cifNo)) {

                AsstTopicVo asstTopicVo = new AsstTopicVo();
                asstTopicVo.setWarningHeaderId(warningHeaderId);
                asstTopicVo.setWarningId(warningInfoId);
                asstTopicVo.setWarningType(warningType);
                asstTopicVo.setCifNo(cifNo);
                String nextFinStatus = getFinStatus(infoStatus, BusinessConst.GO_ACTION.NAXT);
                asstQuestionBusiness.approveQuestion(asstTopicVo, getCurrentUser(), nextFinStatus, "Approve" , true);
            }
            if(reasonSelectList == null || reasonSelectList.isEmpty() ){
                reasonSelectList = getReasonSelectListDataNo();
            }
            if(reasonSelectListYes == null || reasonSelectListYes.isEmpty())
            {
                reasonSelectListYes = getReasonSelectListDataYes();
            }
        } catch (Exception ex) {
            throw ex;
        }
        return "taskList";
    }

    public String rejectFin() throws Exception {
        try {
            if (!ValidatorUtil.isNullOrEmpty(warningHeaderId) && !ValidatorUtil.isNullOrEmpty(warningInfoId)
                    && !ValidatorUtil.isNullOrEmpty(warningType) && !ValidatorUtil.isNullOrEmpty(infoStatus)) {

                AsstTopicVo asstTopicVo = new AsstTopicVo();
                asstTopicVo.setWarningHeaderId(warningHeaderId);
                asstTopicVo.setWarningId(warningInfoId);
                asstTopicVo.setWarningType(warningType);
                String nextFinStatus = getFinStatus(infoStatus, BusinessConst.GO_ACTION.PREVIOUS);
                asstQuestionBusiness.sendbackQuestion(asstTopicVo, getCurrentUser(), nextFinStatus, "Back");
            }
            if(reasonSelectList == null || reasonSelectList.isEmpty() ){
                reasonSelectList = getReasonSelectListDataNo();
            }
            if(reasonSelectListYes == null || reasonSelectListYes.isEmpty() ){
                reasonSelectListYes = getReasonSelectListDataYes();
            }
        } catch (Exception ex) {
            throw ex;
        }
        return SUCCESS;
    }

    public String gotoBackPipeline() throws Exception {
        logger.debug("[gotoBackPipeline][Begin]");
        
        String backToPage   = "backTaskList";
        String forBackPage  = null;
        
        try{
            forBackPage = (String) request.getSession(false).getAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL);
            
            logger.debug("[gotoBackPipeline] forBackPage :: " + forBackPage);
            
            if(forBackPage!=null && !forBackPage.equals("")){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    backToPage = "backCloseJobTaskList";
                }else if(forBackPage.equals(BusinessConst.PAGE.PIPELINE)){
                    backToPage = "backTaskList";
                }else{
                    backToPage = "backTaskList";
                }
            }else{
                backToPage = "backTaskList";
            }
            
            logger.debug("[gotoBackPipeline][End]");
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[gotoBackPipeline][End]");
        }
        
        return backToPage;
    }
    
    public String showPopupAddRemark() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("showPopupAddRemark");
        }
        return "showPopupAddRemark";
    }

    private String getFinStatus(String currentStatus, String needToGo) throws Exception {
        logger.info("getFinStatus currentStatus= " + currentStatus);
        logger.info("getFinStatus needToGo= " + needToGo);
        String result = "";
        if (BusinessConst.GO_ACTION.PREVIOUS.equals(needToGo)) {
            if (BusinessConst.Flag.RMF.equals(currentStatus) || BusinessConst.Flag.BRMF.equals(currentStatus)) {
                result = BusinessConst.Flag.BRMP;
            }
        } else {
            if (BusinessConst.Flag.N.equals(currentStatus) || BusinessConst.Flag.PRMP.equals(currentStatus)) {
                result = BusinessConst.Flag.RMP;
            } else if (BusinessConst.Flag.RMP.equals(currentStatus) || BusinessConst.Flag.BRMP.equals(currentStatus)) {
                result = BusinessConst.Flag.RMF;
            } else if (BusinessConst.Flag.RMF.equals(currentStatus) || BusinessConst.Flag.BRMF.equals(currentStatus)) {
                result = BusinessConst.Flag.COMPLETE;
               
            }
        }
        logger.info("getFinStatus result= " + result);
        return result;
    }
     public ArrayList<DropdownVo> getReasonSelectListDataNo() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("1", "ก่อตั้งกิจการใหม่ (ยังไม่เริ่มดำเนินการ)"));
        result.add(setDataToDropDrown("2", "อยู่ระหว่างจัดทำบัญชี"));  
        result.add(setDataToDropDrown("3", "เลิกกิจการ (ยังชำระบัญชีไม่เสร็จสิ้น)"));  
        result.add(setDataToDropDrown("4", "เลิกกิจการ (ชำระบัญชีเสร็จสิ้น)"));  
        result.add(setDataToDropDrown("5", "มีคำสั่งศาล/ดำเนินการทางกฎหมาย"));  
        result.add(setDataToDropDrown("6", "อื่นๆ ระบุ"));  
        return result;
   }
    public ArrayList<DropdownVo> getReasonSelectListDataYes() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        result.add(setDataToDropDrown("1", "งบนำส่งสรรพากร"));
        result.add(setDataToDropDrown("2", "งบ Recast"));  
        return result;
   }
          
   private DropdownVo setDataToDropDrown(String key,String value){
        DropdownVo ddVo = new DropdownVo();
        ddVo.setId(key);
        ddVo.setDesc(value);
        return ddVo;
   }
   
   private String getReasonDetial(String key,ArrayList<DropdownVo> list)throws Exception{
      
       for(DropdownVo vo: list){
           if(vo.getId().trim().equals(key.trim())){
               return vo.getDesc();
           }
       }
       return "";
   }
    public String goToPopupAddProtestRemark() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("goToPopupAddProtestRemark");
        }
        return "showPopupAddProtestRemark";
    }
    
    public String goCloseForm() throws Exception {
        return "closeJobScreen";
    }
    
    public String goApproveClose() throws Exception {
        WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
        warningHeaderVo.setWarningHeaderId(warningHeaderId);
        warningHeaderVo.setCif(cifNo);
        warningHeaderVo.setStatus(BusinessConst.Flag.COMPLETE);

        warningHeaderBusiness.closeJob(warningHeaderVo, getCurrentUser(), "", "อนุมัติปิดงาน", "Approve", warningInfoId, warningType);
        success();
        showButtonForClose = "";
        return SUCCESS;
    }
    private void getLastFinancialDetail(String custName, String custTypeName) throws Exception{
        try {
            
            setLastFinancialVo(qcaFinancialBusiness.getLastFinancialVO(getCifNo()));
            if (getLastFinancialVo() == null) {
                logger.info("FinancialVo is null");
                FinancialVo financialVO = new FinancialVo();
                financialVO.setHvFin("");
                financialVO.setReasonCode("");
                financialVO.setReasonSelectN("");
                financialVO.setReasonSelectY("");
                financialVO.setReasonDetail("");
                setLastFinancialVo(financialVO);
                setMessage("");
            } else {

                getLastFinancialVo().setRatioList(qcaFinancialBusiness.getRatioList(getLastFinancialVo(), qcaFinancialBusiness.getRatioList(getLastFinancialVo().getTrnId())));
         
                logger.info("RatioList().size() : " + getLastFinancialVo() != null && getLastFinancialVo().getRatioList() != null ? getLastFinancialVo().getRatioList().size() : "0" );

                if (getLastFinancialVo().getRatioList() != null) {
                    logger.info("FinancialVO: " + getLastFinancialVo() != null && getLastFinancialVo().getRatioList() != null ? getLastFinancialVo().getRatioList().size() : "0");
                } else {
                    logger.info("FinancialVO.getRatioList(): " + getLastFinancialVo()!= null && getLastFinancialVo().getRatioList() != null ? getLastFinancialVo().getRatioList() : "0");
                }

                getLastFinancialVo().setCifNo(getCifNo());
                getLastFinancialVo().setCustName(custName);
                getLastFinancialVo().setCustTypeName(custTypeName);
            }
        } catch (Exception e) {
            throw e;
        }
    }
    public void findQuestionHistory(String cif) throws Exception{
       List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();

        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cif, warningType);//warningHeaderBusiness.findWarningIdForQuestion(cif, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
            for (QuestionHistoryVo vo : warningIdList) {
                vo.setActionDetail(warningType);
                vo.setWarningType(warningType);
                vo.setCif(cif);
                historyList = actionHistoryBusiness.findQuestionHistory(vo);
                if (historyList != null && !historyList.isEmpty()) {
                    tmpVo = (QuestionHistoryVo) historyList.get(0);
                    vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                    vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                    vo.setActionUserId(tmpVo.getActionUserId());
                    vo.setActionDate(tmpVo.getActionDate());
                    vo.setApproveUserId(tmpVo.getApproveUserId());
                    vo.setApproveDate(tmpVo.getApproveDate());
                    vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                    vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                    vo.setCif(cif);
                    resultList.add(vo);
                }
            }
              if(resultList.size() > 0){
                    setQuestionHistoryList(resultList);
              }
        }
    }
     public String goFinancialHistory() throws Exception {
        
       QuestionHistoryVo sessionVo = new QuestionHistoryVo();
       sessionVo.setHeaderId(getWarningHeaderIdHistory()+"");
       sessionVo.setWarningId(getWarningIdHistory()+"");
       sessionVo.setWarningType(getWarningTypeHistory());
       sessionVo.setCif(getCifNo());
       sessionVo.setActionDate(getActionDateHistory());
       
       request.getSession().setAttribute(BusinessConst.Session.FINANCE_HISTORY_KEY,sessionVo);
       
        return "financialHistoryScreen";
    }

      public String saveFINAfterWS() throws Exception {
         if (logger.isInfoEnabled()) {
              logger.info("saveFINAfterWS");
              logger.info(" cifNo = " + cifNo);
              logger.info("warningInfoId = " + warningInfoId);
          }
        try {  
            //------------------------------
            if (!ValidatorUtil.isNullOrEmpty(warningHeaderId) && !ValidatorUtil.isNullOrEmpty(warningInfoId)
                    && !ValidatorUtil.isNullOrEmpty(warningType) && !ValidatorUtil.isNullOrEmpty(infoStatus)
                    && !ValidatorUtil.isNullOrEmpty(cifNo)) {

                //--- Validate ----------------------  
                FinancialVo finVo = qcaFinancialBusiness.getFinancialForCalDate(cifNo, String.valueOf(warningInfoId));
                if(finVo != null){
                    Date finForCal =  null;
                    if(BusinessConst.FIN_STATE_TYPE.A_AUDIT.equals(finVo.getStateType())){
                        finForCal = ValidatorUtil.isNullOrEmpty(finVo.getFinStatementAuditDate1())  ? null :  DateUtil.parse(finVo.getFinStatementAuditDate1(), DateUtil.DEFAULT_DATE_FORMAT_1);
                    }else if(BusinessConst.FIN_STATE_TYPE.R_ADJUST.equals(finVo.getStateType())){
                        finForCal = ValidatorUtil.isNullOrEmpty(finVo.getFinStatementAdjustDate1())  ? null :  DateUtil.parse(finVo.getFinStatementAdjustDate1(), DateUtil.DEFAULT_DATE_FORMAT_1);
                    }
                    
                     logger.info("finVo.getStateType() = " + finVo.getStateType());
                     logger.info("getFinStatementAuditDate1= " + finVo.getFinStatementAuditDate1());
                     logger.info("getFinStatementAdjustDate1= " + finVo.getFinStatementAdjustDate1());
                     logger.info("finForCal= " + finForCal);
                   
                     if(finForCal != null){
                          long diffMonthCalculateIgnoreTime =  DateUtil.diffMonthCalculateIgnoreTime(finForCal,DateUtil.getCurrentDateTime()) ; 
                          logger.info("diffMonthCalculateIgnoreTime= " + diffMonthCalculateIgnoreTime);
                          if(diffMonthCalculateIgnoreTime > 18){
                              if(ValidatorUtil.isNullOrEmpty(delayReason)){
                                  throw new BusinessException("กรุณาระบุ เหตุผลการผ่อนผัน เนื่องจากงบการเงินเก่าเกิน 18 เดือน");
                              }
                          }
                     }
                     logger.info("delayReason= " + delayReason);
                }//if(finVo != null)

                if(!ValidatorUtil.isNullOrEmpty(delayReason)){
                    FinancialVo finVoDelay = new FinancialVo();
                    finVoDelay.setCif(cifNo);
                    finVoDelay.setWarningInfoId(warningInfoId);
                    finVoDelay.setDelayReason(delayReason);
                    finVoDelay.setUpdatedBy(getCurrentUser().getEmpNo());
                    finVoDelay.setUpdatedDate(DateUtil.getCurrentDateTime());
                    qcaFinancialBusiness.updateQcaFinInDelayReason(finVoDelay);
                }
                 warningInfoBusiness.updateStatusByWarningIdAndType(warningInfoId, warningType, getCurrentUser(), BusinessConst.Flag.RMF, "Save", BusinessConst.Flag.RMF);
                 asstQuestionBusiness.checkAllXxFlagForUpdateHeaderStatus(warningHeaderId, getCurrentUser().getEmpNo(), BusinessConst.GO_ACTION.NAXT);
                 warningHeaderBusiness.updateFlagInWarningHeaderForFin(warningHeaderId, getCurrentUser(), BusinessConst.Flag.INPROCESS);
               
                 
                WarningInfoVo warningInfo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);
                infoStatus = warningInfo.getStatus();

            }
            if(reasonSelectList == null || reasonSelectList.isEmpty() ){
                reasonSelectList = getReasonSelectListDataNo();
            }
            if(reasonSelectListYes == null || reasonSelectListYes.isEmpty())
            {
                reasonSelectListYes = getReasonSelectListDataYes();
            }
            if(BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())){
                   approveFin();
            }
        } catch (Exception ex) {
            throw ex;
        }
        return SUCCESS;
    }
      
    public String getDisplayFinalCompleteFromCloseReport() {
        return displayFinalCompleteFromCloseReport;
    }

    public void setDisplayFinalCompleteFromCloseReport(String displayFinalCompleteFromCloseReport) {
        this.displayFinalCompleteFromCloseReport = displayFinalCompleteFromCloseReport;
    }

    public String getBackdisplayFinalCompleteFromCloseReport() {
        return backdisplayFinalCompleteFromCloseReport;
    }

    public void setBackdisplayFinalCompleteFromCloseReport(String backdisplayFinalCompleteFromCloseReport) {
        this.backdisplayFinalCompleteFromCloseReport = backdisplayFinalCompleteFromCloseReport;
    }

    public String getDelayReason() {
        return delayReason;
    }

    public void setDelayReason(String delayReason) {
        this.delayReason = delayReason;
    }

    public String getShowButtonForSaveFINAfterWS() {
        return showButtonForSaveFINAfterWS;
    }

    public void setShowButtonForSaveFINAfterWS(String showButtonForSaveFINAfterWS) {
        this.showButtonForSaveFINAfterWS = showButtonForSaveFINAfterWS;
    }

    public String getEnableTextAreaSaveFINAfterWS() {
        return enableTextAreaSaveFINAfterWS;
    }

    public void setEnableTextAreaSaveFINAfterWS(String enableTextAreaSaveFINAfterWS) {
        this.enableTextAreaSaveFINAfterWS = enableTextAreaSaveFINAfterWS;
    }

    public String getCurrentUserRole() {
        return currentUserRole;
    }

    public void setCurrentUserRole(String currentUserRole) {
        this.currentUserRole = currentUserRole;
    }

    public String getShowTextAreaDelayReason() {
        return showTextAreaDelayReason;
    }

    public void setShowTextAreaDelayReason(String showTextAreaDelayReason) {
        this.showTextAreaDelayReason = showTextAreaDelayReason;
    }

   
    
}
