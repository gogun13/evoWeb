/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.DropdownBusiness;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author KTBDevLoan
 */
public class JsonDropdownAction extends BaseAction{
    private static final Logger logger = Logger.getLogger(JsonDropdownAction.class);
    private final String OBJECT_LIST = "objectList";
    private String param1;
    private String param2;
    private String param3;
    private String param4;
    private String param5;
    private List objectList = new ArrayList();
    private HashMap<String, List> mappingList = new HashMap<String, List>();

    @Autowired
    private DropdownBusiness dropdownBusiness;   
    
    public String loadOrganizationGroup() throws Exception {
       if(!ValidatorUtil.isNullOrEmpty(param1)){
            //objectList = dropdownBusiness.getOrganizationGroup(param1);
           objectList = dropdownBusiness.getOrganizationGroupAndEwsUse(param1);
        }
    return OBJECT_LIST;
    }

   public String loadDepartment() throws Exception {
       if(!ValidatorUtil.isNullOrEmpty(param1) && !ValidatorUtil.isNullOrEmpty(param2)){
            objectList = dropdownBusiness.getDepartment(param1, param2);
        }
    return OBJECT_LIST;
    }
      
    public String getParam1() {
        return param1;
    }

    public void setParam1(String param1) {
        this.param1 = param1;
    }

    public String getParam2() {
        return param2;
    }

    public void setParam2(String param2) {
        this.param2 = param2;
    }

    public String getParam3() {
        return param3;
    }

    public void setParam3(String param3) {
        this.param3 = param3;
    }

    public String getParam4() {
        return param4;
    }

    public void setParam4(String param4) {
        this.param4 = param4;
    }

    public String getParam5() {
        return param5;
    }

    public void setParam5(String param5) {
        this.param5 = param5;
    }

    public List getObjectList() {
        return objectList;
    }

    public void setObjectList(List objectList) {
        this.objectList = objectList;
    }

}
