/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktbcs.core.action.BaseAction;
import static com.opensymphony.xwork2.Action.SUCCESS;
import org.apache.log4j.Logger;

/**
 *
 * @author KTBDevLoan
 */
public class CustomerGroupViewAction extends BaseAction{
    private static final Logger log = Logger.getLogger(CustomerGroupViewAction.class);
    
    
    @Override
    public String success() throws Exception{
        if(log.isDebugEnabled()){
            log.debug("CustomerGroupViewAction.success");
        }
        return SUCCESS;
    }
}
