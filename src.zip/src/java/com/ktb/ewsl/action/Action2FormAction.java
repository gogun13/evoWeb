/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.action;

import com.ktb.ewsl.business.Action2FormBusiness;
import com.ktb.ewsl.business.ActionHistoryBusiness;
import com.ktb.ewsl.business.AsstQuestionBusiness;
import com.ktb.ewsl.business.FormStatusControlBusiness;
import com.ktb.ewsl.business.ParameterBusiness;
import com.ktb.ewsl.business.WarningHeaderBusiness;
import com.ktb.ewsl.business.WarningInfoBusiness;
import com.ktb.ewsl.business.WarningWayOutFormBusiness;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ActionAccountVo;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.FormStatusControlVo;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.TitleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningWayOutFormVo;
import com.ktbcs.core.action.BaseAction;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Pratya
 */
public class Action2FormAction extends BaseAction {
    private static final Logger logger = Logger.getLogger(Action2FormAction.class);
    
    private String cifNo;
    private int warningHeaderId;
    private String warningId;
//    private String actionWarningId;
//    private String wayOutWarningId;
    private String warningType;
    private String infoStatus;
    private List<String> answers;
    private List<QuestionHistoryVo>  questionHistoryList;
    private String showMode = "true";//Mode View
    private List<ActionHistoryVo> actionHistoryVoList;
    private List<WarningWayOutFormVo> warningWayOutFormVoList;
    private List<ParameterVo> parameterList;
    private String showButton = "";//ไม่แสดงปุ่ม
    private String actionMode;
    private String amdFlg;
//    private String modeView;
    private String warningIdHistory;
    private String warningHeaderIdHistory;
    private String questionIdHistory;
    private String versionHistory;
    private String warningTypeHistory;
    private String actionDateHistory;
    private String forBackPage;
    private List<ActionAccountVo> actionAccountList;
    private String warningDateStr;
    private String holderRole;
    private List<AsstTopicVo> asstTopicVoList;
    private List<AsstTopicVo> asstTopicPopupVoList;
    private String warningInfoDateStr;
    private int latepayWarningId;
    private List<String> answersResult;
    private String warningTypeDesc;
    private String rejectRemark;
    private List<String> questionList;
    private List<String> remarks;
    private String questionId;
    private String version;
    private List<String> requireList;
    private String confirmLatePay;
    private String confirmLatePayDesc;
    private String pageFlag;
    private String roleId;
    private Integer dpd;
    private WarningHeaderVo warningHeaderVo;
    private String popUpHistoryFlg;
     
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness; 
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    @Autowired
    private WarningWayOutFormBusiness warningWayOutFormBusiness; 
    @Autowired
    private ParameterBusiness parameterBusiness; 
    @Autowired
    private FormStatusControlBusiness formStatusControlBusiness;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private Action2FormBusiness action2FormBusiness;
    
    @Override
    public String execute() throws Exception {
        log("[execute][Begin]");
        String forward  = null;
        String command  = null;
        try{
            command = request.getParameter("command");
            
            log("[execute] command :: " + command);
            
            if(command==null || command.equals(SUCCESS)){
                forward = success();
            }else if(command.equals("updateData")){
                forward = updateData();
            }else if(command.equals("saveData")){
                forward = saveData();
            }else if(command.equals("goTaskDetail")){
                forward = goTaskDetail();
            }else if(command.equals("goQuestionHistory")){
                forward = goQuestionHistory();
            }else if(command.equals("updateActionFlg")){
                forward = updateActionFlg();
            }else if(command.equals("editByBCM")){
                forward = editByBCM();
            }else if(command.equals("cancel")){
                forward = cancel();
            }else if(command.equals("saveForBCM")){
                forward = saveForBCM();
            }else if(command.equals("normalPage")){
                forward = normalPage();
            }else if(command.equals("openRejectPopup")){
                forward = openRejectPopup();
            }else if(command.equals("saveRemark")){
                forward = saveRemark();
            }else if(command.equals("goHistoricalAssessment")){
                forward = goHistoricalAssessment();
            }
//            else if(command.equals("clickNo")){
//                forward = clickNo();
//            }
//            else if(command.equals("saveDataEdit")){
//                forward = saveDataEdit();
//            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[execute][End]");
        }
        return forward;
    }
    
    @Override
    public String success() throws Exception {
        log("[success][Begin]");
        
        WarningInfoVo   warningInfoVo       = null;
        
        /*Begin เช็คว่าจะดึงข้อมูลของ Late Payment Form หรือ Action form 2 มาแสดง*/
        
        warningInfoVo = new WarningInfoVo();
        warningInfoVo.setWarningHeaderId(warningHeaderId);
        warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
        this.latepayWarningId   = warningInfoBusiness.getMinWarningId(warningInfoVo);
        
        ActionHistoryVo actionHistoryVo = action2FormBusiness.actionHistoryDetail(this.latepayWarningId, "Approve", BusinessConst.WarningTypeCode.LATE_PAY, "C");

        log("[success] ActionDt     :: " + actionHistoryVo.getActionDt());
        log("[success] CurrentDate  :: " + getCurrentDate());
        
        roleId = getCurrentUser().getRoleId();
        
        if(BusinessConst.Flag.RMF.equals(this.infoStatus) || BusinessConst.Flag.BRMP.equals(this.infoStatus) || BusinessConst.Flag.COMPLETE.equals(this.infoStatus)){
            int cntLatePay = warningInfoBusiness.cntLatePay(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
            if(cntLatePay > 1){
                this.pageFlag = "action";
                return actionLatePayment();
            }else{
                this.pageFlag = "normal";
                return normalPage();
            }
        }else{
            // เช็คว่าวันที่อนุมัติ Late Payment Form เท่ากับวันที่ปัจจุบันหรือไม่
            if(!actionHistoryVo.getActionDt().equals(getCurrentDate())){
                this.pageFlag = "action";
                return actionLatePayment();
            }else{
                this.pageFlag = "normal";
                return normalPage();
            }
        }
        
        
        /*if(BusinessConst.Flag.N.equals(this.infoStatus)){
            ActionHistoryVo actionHistoryVo = action2FormBusiness.actionHistoryDetail(this.latepayWarningId, "Approve", BusinessConst.WarningTypeCode.LATE_PAY, "C");

            log("[success] ActionDt  :: " + actionHistoryVo.getActionDt());
            log("[success] CurrentDate  :: " + getCurrentDate());
            
            // เช็คว่าวันที่อนุมัติ Late Payment Form เท่ากับวันที่ปัจจุบันหรือไม่
            if(!actionHistoryVo.getActionDt().equals(getCurrentDate())){
                return actionLatePayment();
            }else{
                return normalPage();
            }
        }else{
            return normalPage();
        }*/
        /*End เช็คว่าจะดึงข้อมูลของ Late Payment Form หรือ Action form 2 มาแสดง*/
    }
    
//    private String clickNo() throws Exception{
//        log("[clickNo][Begin]");
//        
//        try{
//            WarningInfoVo  infoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, this.latepayWarningId, BusinessConst.WarningTypeCode.LATE_PAY);
//            setWarningInfoDateStr(infoVo != null ? infoVo.getWarningDateStr() : "");
//            
//            if (asstTopicPopupVoList == null) {
//                //-------- Find 
//                AsstTopicVo filter = new AsstTopicVo();
//                filter.setCifNo(this.cifNo);
//                filter.setWarningHeaderId(this.warningHeaderId);
//                filter.setWarningId(this.latepayWarningId);
//                filter.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
//                filter.setInfoStatus("C");
//                
//                this.asstTopicPopupVoList = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
//                if(!asstTopicPopupVoList.isEmpty()){ 
//                    //-Start------- NOT Display LAST TOPIC "Other" 
//                    Integer lastSubtopic = null;
//                    if(!ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionId()) && !ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionVersion())){
//                         lastSubtopic = asstQuestionBusiness.getLastSubTopic(infoVo.getAnswerQuestionId(), infoVo.getAnswerQuestionVersion());
//                         log("lastSubtopic = " + lastSubtopic);
//                    }
//                    //-END--------------------------------------------------------
//                    answersResult   = new ArrayList<String>();
//                    for(AsstTopicVo topicAns : asstTopicPopupVoList){
//                        for( AsstSubtopicVo subTopicAns : topicAns.getAsstSubtopicVoList() ){
//                            log("--------------------------------------------------------");
//                            log("getSubTopicId" + subTopicAns.getSubTopicId());
//                            log("getAnswer" + subTopicAns.getAnswer());
//                            
//                            if("1".equals(subTopicAns.getAnswer())){
//                                if(lastSubtopic != null && lastSubtopic > 0 && lastSubtopic == subTopicAns.getSubTopicId()){
//                                    break;
//                                }
//                                answersResult.add(subTopicAns.getSubTopicId()+"."+subTopicAns.getSubTopicDesc());
//                            }
//                            
//                        }
//                    }
//                }
//            }
//            
////            warningInfoVo = new WarningInfoVo();
////            warningInfoVo.setWarningHeaderId(warningHeaderId);
////            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.ACTION1);
////            warningInfoVoDb         = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
////            
////            action2FormBusiness.deleteLatePayAndAction1FormData(this.warningHeaderId, warningInfoVoDb.getWarningId(), this.latepayWarningId, userData);
//        }catch(Exception e){
//            logger.error(e);
//            throw e;
//        }finally{
//            log("[clickNo][End]");
//        }
//        return "latepayPopup";
//    }
//    
//    public String clickYes() throws Exception {
//        logger.info("[clickYes][Begin]");
//        
//        UserData        userData            = getCurrentUser();
//        
//        try{
//            if (EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId())){
//                warningInfoBusiness.updateConfirmLatepayment("Y", null, this.warningId);
//            }else if(BusinessConst.UserRole.BCM.equals(userData.getRoleId())){
//                warningInfoBusiness.updateConfirmLatepayment(null, "Y", this.warningId);
//            }
//            
//        }catch(Exception e){
//            logger.error(e);
//            throw e;
//        }finally{
//            logger.info("[clickYes][End]");
//        }
//        return null;
//    }
    
    private String normalPage() throws Exception{
        log("[normalPage][Begin]");
        
        UserData        userData            = getCurrentUser();
        
        try{
            findDataCommon();
            
            if("saveForBCM".equals(request.getParameter("command"))){
                this.showMode   = "false";//Mode Edit
                this.showButton = "4";//บันทึก, ยกเลิก, อนุมัติ
            }else{
                if (EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId())){

                    if(BusinessConst.Flag.N.equals(this.infoStatus)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "1";//บันทึก, ส่งงาน
                    }else if(BusinessConst.Flag.RMP.equals(this.infoStatus)){
                        if(BusinessConst.UserRole.BCM.equals(holderRole) || BusinessConst.UserRole.CO_BCM.equals(holderRole)){
                            this.showMode = "true";//Mode View
                            this.showButton = "";//ไม่แสดงปุ่ม
                        }else{
                            this.showMode   = "false";//Mode Edit
                            this.showButton = "1";//บันทึก, ส่งงาน
                        }
                    }else if(BusinessConst.Flag.RMF.equals(this.infoStatus) || BusinessConst.Flag.COMPLETE.equals(this.infoStatus)){
                        this.showMode = "true";//Mode View
                        this.showButton = "";//ไม่แสดงปุ่ม
                    }else if(BusinessConst.Flag.BRMP.equals(this.infoStatus)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "1";//บันทึก, ส่งงาน
                    }
                }else if(BusinessConst.UserRole.BCM.equals(userData.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(userData.getRoleId())){
                    if(BusinessConst.Flag.N.equals(this.infoStatus)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "3";//บันทึก, ยืนยัน/อนุมัติ
                    }else if(BusinessConst.Flag.RMP.equals(this.infoStatus)){
                        if(BusinessConst.UserRole.BCM.equals(holderRole) || BusinessConst.UserRole.CO_BCM.equals(holderRole)){
                            this.showMode   = "false";//Mode Edit
                            this.showButton = "3";//บันทึก, ยืนยัน/อนุมัติ
                        }else{
                           this.showMode = "true";//Mode View
                           this.showButton = "";//ไม่แสดงปุ่ม
                        }
                    }else if(BusinessConst.Flag.RMF.equals(this.infoStatus)){
                        this.showMode = "true";//Mode View
                        this.showButton = "2";//แก้ไข, ส่งกลับแก้ไข, ยืนยัน/อนุมัติ
                    }else if(BusinessConst.Flag.COMPLETE.equals(this.infoStatus) || BusinessConst.Flag.BRMP.equals(this.infoStatus)){
                        this.showMode = "true";//Mode View
                        this.showButton = "";//ไม่แสดงปุ่ม
                    }
                }
            }
            
            /*begin Release 3.1*/
            if (EWSConstantValue.ROLE_EDITOR_OLD.contains(getCurrentUser().getRoleId())) {
                WarningHeaderVo wh = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
                if(wh!=null){
                    if(!ValidatorUtil.isNullOrEmpty(wh.getCoRespUnitStr()) && !"0".equals(wh.getCoRespUnitStr())){
                       this.showMode = "true";//Mode View
                       this.showButton = "";//ไม่แสดงปุ่ม
                    }
                }
            }
            /*end Release 3.1*/
            
            if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    this.showMode = "true";//Mode View
                    this.showButton = "";//ไม่แสดงปุ่ม
                }

                request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
            }

//            this.modeView   = "";   
            
    //        this.showMode   = "false";//Mode Edit
    //        this.showButton = "1";//บันทึก, ส่งงาน
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[normalPage][End]");
        }
        
        return SUCCESS;
    }
    
    private String actionLatePayment() throws Exception{
        log("[actionLatePayment][Begin]");
        
        UserData            userData            = getCurrentUser();
        
        try{
            actionLatePaymentFindData();
            
//            if (EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId())){
//                this.showButton = "1";//บันทึก, ส่งงาน
//                this.showMode = "false";//Mode Edit
//            }else if(BusinessConst.UserRole.BCM.equals(userData.getRoleId())){
//                this.showButton = "2";//แก้ไข, ส่งกลับ, ยืนยัน/อนุมัติ
//                this.showMode = "true";//Mode View
//            }
            
            if("saveForBCM".equals(request.getParameter("command"))){
                this.showMode   = "false";//Mode Edit
                this.showButton = "4";//บันทึก, ยกเลิก, อนุมัติ
            }else{
                if (EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId())){

                    if(BusinessConst.Flag.N.equals(this.infoStatus)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "1";//บันทึก, ส่งงาน
                    }else if(BusinessConst.Flag.RMP.equals(this.infoStatus)){
                        if(BusinessConst.UserRole.BCM.equals(holderRole) || BusinessConst.UserRole.CO_BCM.equals(holderRole)){
                            this.showMode = "true";//Mode View
                            this.showButton = "";//ไม่แสดงปุ่ม
                        }else{
                            this.showMode   = "false";//Mode Edit
                            this.showButton = "1";//บันทึก, ส่งงาน
                        }
                    }else if(BusinessConst.Flag.RMF.equals(this.infoStatus) || BusinessConst.Flag.COMPLETE.equals(this.infoStatus)){
                        this.showMode = "true";//Mode View
                        this.showButton = "";//ไม่แสดงปุ่ม
                    }else if(BusinessConst.Flag.BRMP.equals(this.infoStatus)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "1";//บันทึก, ส่งงาน
                    }
                }else if(BusinessConst.UserRole.BCM.equals(userData.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(userData.getRoleId())){
                    if(BusinessConst.Flag.N.equals(this.infoStatus)){
                        this.showMode   = "false";//Mode Edit
                        this.showButton = "3";//บันทึก, ยืนยัน/อนุมัติ
                    }else if(BusinessConst.Flag.RMP.equals(this.infoStatus)){
                        if(BusinessConst.UserRole.BCM.equals(holderRole) || BusinessConst.UserRole.CO_BCM.equals(holderRole)){
                            this.showMode   = "false";//Mode Edit
                            this.showButton = "3";//บันทึก, ยืนยัน/อนุมัติ
                        }else{
                           this.showMode = "true";//Mode View
                           this.showButton = "";//ไม่แสดงปุ่ม
                        }
                    }else if(BusinessConst.Flag.RMF.equals(this.infoStatus)){
                        this.showMode = "true";//Mode View
                        this.showButton = "2";//แก้ไข, ส่งกลับแก้ไข, ยืนยัน/อนุมัติ
                    }else if(BusinessConst.Flag.COMPLETE.equals(this.infoStatus) || BusinessConst.Flag.BRMP.equals(this.infoStatus)){
                        this.showMode = "true";//Mode View
                        this.showButton = "";//ไม่แสดงปุ่ม
                    }
                }
            }
            
            /*begin Release 3.1*/
            if (EWSConstantValue.ROLE_EDITOR_OLD.contains(getCurrentUser().getRoleId())) {
                WarningHeaderVo wh = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
                if(wh!=null){
                    if(!ValidatorUtil.isNullOrEmpty(wh.getCoRespUnitStr()) && !"0".equals(wh.getCoRespUnitStr())){
                       this.showMode = "true";//Mode View
                       this.showButton = "";//ไม่แสดงปุ่ม
                    }
                }
            }
            /*end Release 3.1*/

            if(!ValidatorUtil.isNullOrEmpty(forBackPage)){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    this.showMode = "true";//Mode View
                    this.showButton = "";//ไม่แสดงปุ่ม
                }

                request.getSession(false).setAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL, forBackPage);
            }
            
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[actionLatePayment][End]");
        }
        
        return "latepay";
    }
    
    private void actionLatePaymentFindData() throws Exception{
        log("[actionLatePaymentFindData][Begin]");
        
        UserData            userData                    = getCurrentUser();
        List<AsstTopicVo>   asstTopicVoListTemp         = null;
        AsstTopicVo         filter                      = null;
        int                 maxLatepayWarningId         = 0;
        WarningInfoVo       warningInfoVo               = null;
        WarningInfoVo       warningInfoVoDb             = null;
        List<AsstTopicVo>   asstTopicVoListTempNotBcm   = null;
        
        try{
            findDataCommon();
            
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(warningHeaderId);
            warningInfoVo.setWarningType(warningType);
            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
            if (EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId())){
                
                if(BusinessConst.Flag.BRMP.equals(warningInfoVoDb.getStatus())){
                    this.confirmLatePay     = "";
                }else{
                    this.confirmLatePay     = warningInfoVoDb.getConfirmLatePay();
                }
                this.confirmLatePayDesc = "ยืนยันคำตอบ \"สาเหตุของการผิดนัดชำระหนี้\"";
                
            }else if(BusinessConst.UserRole.BCM.equals(userData.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(userData.getRoleId())){
                this.confirmLatePay     = warningInfoVoDb.getBcmConfirmLatePay();
                this.confirmLatePayDesc = "อนุมัติคำตอบ \"สาเหตุของการผิดนัดชำระหนี้\"";
            }
            
            WarningInfoVo  infoVo = warningInfoBusiness.findWarningInfoObj(warningHeaderId, this.latepayWarningId, BusinessConst.WarningTypeCode.LATE_PAY);
            setWarningInfoDateStr(infoVo != null ? infoVo.getWarningDateStr() : "");
            
            if (asstTopicVoList == null) {
                //-------- Find 
                filter = new AsstTopicVo();
                filter.setCifNo(this.cifNo);
                filter.setWarningHeaderId(this.warningHeaderId);
                filter.setWarningId(this.latepayWarningId);
                filter.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
                filter.setInfoStatus("C");
                
                this.asstTopicVoList = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
                if(!asstTopicVoList.isEmpty()){ 
                    //-Start------- NOT Display LAST TOPIC "Other" 
                    Integer lastSubtopic = null;
                    if(!ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionId()) && !ValidatorUtil.isNullOrEmpty(infoVo.getAnswerQuestionVersion())){
                         lastSubtopic = asstQuestionBusiness.getLastSubTopic(infoVo.getAnswerQuestionId(), infoVo.getAnswerQuestionVersion());
                         log("[actionLatePaymentFindData] lastSubtopic = " + lastSubtopic);
                    }
                    //-END--------------------------------------------------------
                    answersResult = new ArrayList<String>();
                    for(AsstTopicVo topicAns : asstTopicVoList){
                        for( AsstSubtopicVo subTopicAns : topicAns.getAsstSubtopicVoList() ){
                            log("--------------------------------------------------------");
                            log("[actionLatePaymentFindData] getSubTopicId :: " + subTopicAns.getSubTopicId());
                            log("[actionLatePaymentFindData] getAnswer :: " + subTopicAns.getAnswer());
                            
                            if("1".equals(subTopicAns.getAnswer())){
                                if(lastSubtopic != null && lastSubtopic > 0 && lastSubtopic == subTopicAns.getSubTopicId()){
                                    break;
                                }
                                answersResult.add(subTopicAns.getSubTopicId()+"."+subTopicAns.getSubTopicDesc());
                            }
                            
                            if(BusinessConst.Flag.N.equals(this.infoStatus)){
                                subTopicAns.setConfirmAnswer(subTopicAns.getAnswer());
                                subTopicAns.setConfirmChoiceReason(subTopicAns.getChoiceReason());
                            }
                            
                        }
                    }
                }
                
                if(!BusinessConst.Flag.N.equals(this.infoStatus)){
                    if(this.asstTopicVoList!=null && !this.asstTopicVoList.isEmpty()){
                        maxLatepayWarningId = warningInfoBusiness.findMaxWarningId(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);

                        filter = new AsstTopicVo();
                        filter.setCifNo(this.cifNo);
                        filter.setWarningHeaderId(this.warningHeaderId);
                        filter.setWarningId(maxLatepayWarningId);
                        filter.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
                        filter.setInfoStatus("C");

                        asstTopicVoListTemp = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
                        if(asstTopicVoListTemp!=null && !asstTopicVoListTemp.isEmpty()){
                            for(int i=0;i<asstTopicVoListTemp.size();i++){
                                AsstTopicVo topicAns        = asstTopicVoList.get(i);
                                AsstTopicVo topicAnsTemp    = asstTopicVoListTemp.get(i);

                                for(int j=0;j<topicAnsTemp.getAsstSubtopicVoList().size();j++){
                                    AsstSubtopicVo subTopicAnsTemp  = topicAnsTemp.getAsstSubtopicVoList().get(j);

                                    for(AsstSubtopicVo subTopicAns:topicAns.getAsstSubtopicVoList()){
                                        if(subTopicAns.getSubTopicId()==subTopicAnsTemp.getSubTopicId()){
                                            subTopicAns.setConfirmAnswer(subTopicAnsTemp.getAnswer());
                                            subTopicAns.setConfirmChoiceReason(subTopicAnsTemp.getChoiceReason());
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        /*Begin เลือกคำตอบเฉพาะของ RM AE AO*/
                        filter.setSelectBCM(false);
                        asstTopicVoListTempNotBcm = asstQuestionBusiness.findLatePaymentQuestionByFilter(filter);
                        if(asstTopicVoListTempNotBcm!=null && !asstTopicVoListTempNotBcm.isEmpty()){
                            for(int i=0;i<asstTopicVoListTempNotBcm.size();i++){
                                AsstTopicVo topicAns        = asstTopicVoList.get(i);
                                AsstTopicVo topicAnsNotBcm  = asstTopicVoListTempNotBcm.get(i);
                                for(int j=0;j<topicAnsNotBcm.getAsstSubtopicVoList().size();j++){
                                    AsstSubtopicVo subTopicAnsNotBcm  = topicAnsNotBcm.getAsstSubtopicVoList().get(j);
                                    
                                    for(AsstSubtopicVo subTopicAns:topicAns.getAsstSubtopicVoList()){
                                        if(subTopicAns.getSubTopicId()==subTopicAnsNotBcm.getSubTopicId()){
                                            subTopicAns.setConfirmAnswerNotBcm(subTopicAnsNotBcm.getAnswer());
                                            subTopicAns.setConfirmChoiceReasonNotBcm(subTopicAnsNotBcm.getChoiceReason());
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        /*End เลือกคำตอบเฉพาะของ RM AE AO*/
                        
                    }
                }
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[actionLatePaymentFindData][End]");
        }
    }
    
    private void saveLatePayment() throws Exception{
        log("[saveLatePayment][Begin]");
        
        UserData        userData            = getCurrentUser();
        String          questionIdSave      = "";
        String          versionSave         = "";
        TitleVo         titleVo             = (TitleVo) request.getSession().getAttribute(BusinessConst.Session.TITLE_KEY);
        AsstAnswerVo    asstAnswerVo        = null;
        int             newWarningId        = 0;
        int             cntLatePay          = 0;
        
        try{
            cntLatePay = warningInfoBusiness.cntLatePay(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
            if(cntLatePay > 1){
                newWarningId = warningInfoBusiness.findMaxWarningId(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
            }else{
                newWarningId = warningInfoBusiness.insertLatePaymentPopup(userData, titleVo.getWarningHeaderId(), version, questionId);
            }
            
            log("[saveLatePayment] newWarningId    :: " + newWarningId);
            
            if (questionList != null) {
                List<AsstAnswerVo> asstAnswerVoList = new ArrayList<AsstAnswerVo>();
                int tmp = 0;
                for (String question : questionList) {
                    
                    asstAnswerVo = new AsstAnswerVo();
                    String[] s = question.split("\\,", -1);
                    if (s != null && s.length > 0) {
                        questionIdSave = s[0];
                        versionSave = s[1];
                        asstAnswerVo.setQuestionId(questionIdSave);
                        asstAnswerVo.setVersion(versionSave);
                        asstAnswerVo.setTopicId(Integer.parseInt(s[2]));
                        asstAnswerVo.setSubTopicId(Integer.parseInt(s[3]));
                        asstAnswerVo.setWarningId(newWarningId);
                        asstAnswerVo.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
                    }
                    if (answers != null) {
                        if (answers.size() > tmp) {
                            if (answers.get(tmp) != null) {
                                asstAnswerVo.setChoiceId(Integer.parseInt(answers.get(tmp)));
                                if (remarks != null) {
                                    if (remarks.get(tmp) != null) {
                                        asstAnswerVo.setChoiceReason(remarks.get(tmp));
                                    }
                                }
                                asstAnswerVo.setWarningHeaderId(titleVo.getWarningHeaderId());
                                asstAnswerVo.setCifNo(titleVo.getCifNo());
                                asstAnswerVoList.add(asstAnswerVo);
                            }
                        }
                    }
                    tmp++;
                }
                if (asstAnswerVoList.size() > 0) {
                    asstQuestionBusiness.saveAsstAnswerForActionForm2(asstAnswerVoList, getCurrentUser());
                }
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[saveLatePayment][End]");
        }
    }
    
    public String goQuestionHistory() throws Exception {
        log("[goQuestionHistory][Begin]");
        
        UserData        userData            = getCurrentUser();
        WarningInfoVo   warningInfoVo       = null;
        WarningInfoVo   warningInfoVoDb     = null;
        
        log("[goQuestionHistory] warningHeaderIdHistory     :: " + this.warningHeaderIdHistory);
        log("[goQuestionHistory] warningTypeHistory         :: " + this.warningTypeHistory);
        
        this.warningHeaderId    = paresInt(this.warningHeaderIdHistory);
        this.warningType        = this.warningTypeHistory;
        
        warningInfoVo = new WarningInfoVo();
        warningInfoVo.setWarningHeaderId(getWarningHeaderId());
        warningInfoVo.setWarningType(getWarningType());
        warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
        
        this.infoStatus   = warningInfoVoDb.getStatus();
        this.warningId    = this.nullToStr(warningInfoVoDb.getWarningId());
        this.amdFlg       = this.nullToStr(warningInfoVoDb.getAmdFlg());
        
//        warningInfoVo = new WarningInfoVo();
//        warningInfoVo.setWarningHeaderId(getWarningHeaderId());
//        warningInfoVo.setWarningType("WAY_OUT");
//        warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
//        
//        this.wayOutWarningId    = this.nullToStr(warningInfoVoDb.getWarningId());
        
        log("[goQuestionHistory] cifNo             :: " + this.cifNo);
        log("[goQuestionHistory] warningHeaderId   :: " + this.warningHeaderId);
        log("[goQuestionHistory] actionWarningId   :: " + this.warningId);
//        log("[goQuestionHistory] wayOutWarningId   :: " + this.wayOutWarningId);
        log("[goQuestionHistory] warningType       :: " + this.warningType);
        log("[goQuestionHistory] infoStatus        :: " + this.infoStatus);
        log("[goQuestionHistory] RoleId            :: " + userData.getRoleId());
        log("[goQuestionHistory] amdFlg            :: " + this.amdFlg);

        findDataCommon();
        
//        this.modeView   = "VIEW";
        this.showMode   = "true";
        this.showButton = "";
        
        return SUCCESS;
    }
    
    public String updateData() throws Exception {
        log("[updateData][Begin]");
        JSONObject                  obj                     = null;
        HttpSession                 session                 = request.getSession(false);
        List<WarningWayOutFormVo>   warningWayOutFormVoList = (List<WarningWayOutFormVo>) session.getAttribute("warningWayOutFormVoList");
        String                      confFlg                 = null;
        String                      actionStatus            = null;
        String                      actionId                = null;
        String                      confRemark              = null;
        
        try{
            obj           = new JSONObject();
            confFlg       = nullToStr(request.getParameter("confFlg"));
            actionStatus  = nullToStr(request.getParameter("actionStatus"));
            actionId      = nullToStr(request.getParameter("actionId"));
            confRemark    = nullToStr(request.getParameter("confRemark"));
            
            log("[updateData] confFlg       :: " + confFlg);
            log("[updateData] actionStatus  :: " + actionStatus);
            log("[updateData] confRemark    :: " + confRemark);
            log("[updateData] actionId      :: " + actionId);
            
            for(WarningWayOutFormVo vo:warningWayOutFormVoList){
                if(vo.getActionId().equals(actionId)){
                    vo.setConfFlg(confFlg);
                    vo.setActionStatus(actionStatus);
                    vo.setConfRemark(confRemark);
                    
                    break;
                }
            }
            
            
            obj.put("status", 			"SUCCESS");
        }catch(Exception e){
            obj.put("status", 			"ERROR");
            obj.put("errMsg", 			"updateData error");
            logger.error(e);
            throw e;
        }finally{
            this.writeMSG(obj.toString());
            log("[updateData][End]");
        }

        return null;
    }
    
    public String updateActionFlg() throws Exception {
        log("[updateActionFlg][Begin]");
        JSONObject                  obj                     = null;
        HttpSession                 session                 = request.getSession(false);
        List<ActionAccountVo>       actionAccountList       = (List<ActionAccountVo>) session.getAttribute("actionAccountList");
        String                      actionFlg               = null;
        String                      seqTemp                 = null;
        
        try{
            obj            = new JSONObject();
            actionFlg      = nullToStr(request.getParameter("actionFlg"));
            seqTemp        = nullToStr(request.getParameter("seqTemp"));
            
            log("[updateActionFlg] actionFlg    :: " + actionFlg);
            log("[updateActionFlg] seqTemp      :: " + seqTemp);
            
            for(ActionAccountVo vo:actionAccountList){
                if(vo.getSeqTemp().equals(seqTemp)){
                    vo.setActionFlg(actionFlg);
                    break;
                }
            }
            
            
            obj.put("status", 			"SUCCESS");
        }catch(Exception e){
            obj.put("status", 			"ERROR");
            obj.put("errMsg", 			"updateActionFlg error");
            logger.error(e);
            throw e;
        }finally{
            this.writeMSG(obj.toString());
            log("[updateActionFlg][End]");
        }

        return null;
    }

    public String saveData() throws Exception {
        log("[saveData][Begin]");
        
        HttpSession                 session                 = request.getSession(false);
        List<WarningWayOutFormVo>   warningWayOutFormVoList = (List<WarningWayOutFormVo>) session.getAttribute("warningWayOutFormVoList");
        List<ActionAccountVo>       actionAccountList       = (List<ActionAccountVo>) session.getAttribute("actionAccountList");
//        boolean                     insertFlag              = false;
        UserData                    user                    = getCurrentUser();
        String                      nextStatus              = "";
        FormStatusControlVo         formStatusControlVo     = null;
        ActionHistoryVo             actionHistoryVo         = null;
        WarningHeaderVo             warningHeaderVo         = null;
        WarningInfoVo               warningInfoVo           = null;
        JSONObject                  obj                     = null;
        String                      holderRole              = "";
        String                      holderId                = null;
        String                      actionCode              = "";
        String                      rejectRemark            = null;
        String                      nextStatusAction        = null;
        
        try{
            obj                 = new JSONObject();
//            insertFlag          = (Boolean) session.getAttribute("insertFlag");
            
            log("[saveData] actionMode  :: " + actionMode);
            log("[saveData] warningType :: " + warningType);
            log("[saveData] amdFlg      :: " + amdFlg);
            
            actionCode = "SaveAndApprove".equals(actionMode)?"Approve":actionMode;
            
            /*Begin หา status*/
            formStatusControlVo = new FormStatusControlVo();
            formStatusControlVo.setCurrStatus(infoStatus);
            formStatusControlVo.setActionCode(actionCode);
            formStatusControlVo.setWarningType(warningType);
            nextStatus = this.nullToStr(formStatusControlBusiness.getNextStatus(formStatusControlVo));
            nextStatus = nextStatus.equals("")?infoStatus:nextStatus;
            /*End หา status*/
            
            log("[saveData] nextStatus :: " + nextStatus);
            
            if ("Draft".equals(actionMode)) {
                
                holderRole  = user.getRoleId();
                holderId    = user.getEmpNo();
                
                warningWayOutFormBusiness.saveWarningActionForm(warningWayOutFormVoList, this.warningId, user);
                
                action2FormBusiness.insertOrUpdateActionAccount(actionAccountList, String.valueOf(warningHeaderId), this.warningId, user);
                
                if("action".equals(pageFlag)){
                    log("[saveData] confirmLatePay    :: " + confirmLatePay);
            
                    if(confirmLatePay!=null){
                        if (EWSConstantValue.ROLE_ACTION_FORM.contains(user.getRoleId())){
                            warningInfoBusiness.updateConfirmLatepayment(confirmLatePay, null, this.warningId);
                        }else if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                            warningInfoBusiness.updateConfirmLatepayment(null, confirmLatePay, this.warningId);
                        }
                    }
                    
                    saveLatePayment();
                }
                
            }else if ("Save".equals(actionMode)) {
                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "",user.getRoleId());
                
                warningWayOutFormBusiness.saveWarningActionForm(warningWayOutFormVoList, this.warningId, user);
                
                action2FormBusiness.insertOrUpdateActionAccount(actionAccountList, String.valueOf(warningHeaderId), this.warningId, user);
                
                /*Begin Update TBL_WARNING_HEADER*/
                warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setAction2Flg("I");
                warningHeaderVo.setWarningHeaderId(warningHeaderId);
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                
                warningHeaderBusiness.updateAction2Flg(warningHeaderVo);
                
                int cnt = warningHeaderBusiness.findWarningInfoALLNewOrBlank(warningHeaderId);
                if (cnt == 1) {
                    warningHeaderVo.setStatus("N");
                }else{
                    warningHeaderVo.setStatus("I");
                }
                warningHeaderBusiness.updateStatusWarningHeader(warningHeaderVo);
                
                /*End Update TBL_WARNING_HEADER*/
                
                if("action".equals(pageFlag)){
                    log("[saveData] confirmLatePay    :: " + confirmLatePay);
            
                    if(confirmLatePay!=null){
                        if (EWSConstantValue.ROLE_ACTION_FORM.contains(user.getRoleId())){
                            warningInfoBusiness.updateConfirmLatepayment(confirmLatePay, null, this.warningId);
                        }else if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                            warningInfoBusiness.updateConfirmLatepayment(null, confirmLatePay, this.warningId);
                        }
                    }
                    
                    saveLatePayment();
                }
                
            }else if ("Approve".equals(actionMode)) {
                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "",user.getRoleId());
                
                if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                    if(BusinessConst.Flag.N.equals(this.infoStatus)){
                        warningWayOutFormBusiness.saveWarningActionForm(warningWayOutFormVoList, this.warningId, user);
                    }
                }else{
                    warningWayOutFormBusiness.saveWarningActionForm(warningWayOutFormVoList, this.warningId, user);
                }
                
                action2FormBusiness.insertOrUpdateActionAccount(actionAccountList, String.valueOf(warningHeaderId), this.warningId, user);
                
                /*Begin Update TBL_WARNING_HEADER*/
                warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setAction2Flg("C");
                warningHeaderVo.setWarningHeaderId(warningHeaderId);
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                
                warningHeaderBusiness.updateAction2Flg(warningHeaderVo);
                /*End Update TBL_WARNING_HEADER*/
                
                //การ update TBL_WARNING_HEADER เพื่อให้งานหายจาก Pipeline
                warningHeaderBusiness.updateForApprove(warningHeaderVo, "G");
                
                if("action".equals(pageFlag)){
                    log("[saveData] confirmLatePay    :: " + confirmLatePay);
            
                    if(confirmLatePay!=null){
                        if (EWSConstantValue.ROLE_ACTION_FORM.contains(user.getRoleId())){
                            warningInfoBusiness.updateConfirmLatepayment(confirmLatePay, null, this.warningId);
                        }else if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                            warningInfoBusiness.updateConfirmLatepayment(null, confirmLatePay, this.warningId);
                        }
                    }
                    
                    saveLatePayment();
                }
                
            }else if ("Reject".equals(actionMode)) {
                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "",user.getRoleId());
                
                /*Begin Update TBL_WARNING_HEADER*/
                warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setAction2Flg("N");
                warningHeaderVo.setWarningHeaderId(warningHeaderId);
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                
                warningHeaderBusiness.updateAction2Flg(warningHeaderVo);
                /*End Update TBL_WARNING_HEADER*/
                
                int cnt = warningHeaderBusiness.findWarningInfoALLNewOrBlank(warningHeaderId);
                if (cnt == 1) {
                    warningHeaderVo.setStatus("N");
                }else{
                    warningHeaderVo.setStatus("I");
                }
                warningHeaderBusiness.updateStatusWarningHeader(warningHeaderVo);
                
                //ลบข้อมูลจาก TBL_WARNING_ACTION_FORM   ที่ ROLE_CODE = BCM
//                warningWayOutFormBusiness.deleteWarningActionForm(this.warningId, "BCM");
                /*Begin R3.1*/
                if(BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())){
                    warningWayOutFormBusiness.deleteWarningActionForm(this.warningId, BusinessConst.UserRole.BCM);
                }else if(BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())){
                    warningWayOutFormBusiness.deleteWarningActionForm(this.warningId, BusinessConst.UserRole.CO_BCM);
                }
                /*End R3.1*/
                
                log("[saveData] this.rejectRemark :: " + this.rejectRemark);
                
                rejectRemark = this.rejectRemark;
                
                if("action".equals(pageFlag)){
                    int maxLatepayWarningId = warningInfoBusiness.findMaxWarningId(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
//                    asstQuestionBusiness.deleteAnswerByWarningIdAndRoleCode(String.valueOf(maxLatepayWarningId), "BCM");
                    /*Begin R3.1*/
                    if(BusinessConst.UserRole.BCM.equals(getCurrentUser().getRoleId())){
                        asstQuestionBusiness.deleteAnswerByWarningIdAndRoleCode(String.valueOf(maxLatepayWarningId), BusinessConst.UserRole.BCM);
                    }else if(BusinessConst.UserRole.CO_BCM.equals(getCurrentUser().getRoleId())){
                        asstQuestionBusiness.deleteAnswerByWarningIdAndRoleCode(String.valueOf(maxLatepayWarningId), BusinessConst.UserRole.CO_BCM);
                    }
                    /*End R3.1*/
                }
                
            }
//            else if ("SaveAndApprove".equals(actionMode)) {
//                holderRole = asstQuestionBusiness.getHolderRole(nextStatus, "");
//                
//                warningWayOutFormBusiness.saveWarningActionForm(warningWayOutFormVoList, this.warningId, user);
//                
//                action2FormBusiness.insertOrUpdateActionAccount(actionAccountList, String.valueOf(warningHeaderId), this.warningId, user);
//                
//                /*Begin Update TBL_WARNING_HEADER*/
//                warningHeaderVo = new WarningHeaderVo();
//                warningHeaderVo.setAction2Flg("C");
//                warningHeaderVo.setWarningHeaderId(warningHeaderId);
//                warningHeaderVo.setUpdatedBy(user.getEmpNo());
//                
//                warningHeaderBusiness.updateAction2Flg(warningHeaderVo);
//                /*End Update TBL_WARNING_HEADER*/
//                
//                //การ update TBL_WARNING_HEADER เพื่อให้งานหายจาก Pipeline
//                warningHeaderBusiness.updateForApprove(warningHeaderVo, "G");
//            }
            
            if("action".equals(pageFlag)){
               int maxWarningId = warningInfoBusiness.findMaxWarningId(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
               
               /*Begin Update TBL_WARNING_INFO*/
                warningInfoVo = new WarningInfoVo();
                warningInfoVo.setStatus(nextStatus);
                warningInfoVo.setUpdatedBy(user.getEmpNo());
                warningInfoVo.setWarningId(maxWarningId);
                warningInfoVo.setHolderId(holderId);
                warningInfoVo.setHolderRole(holderRole);
                warningInfoVo.setAmdFlg(null);

                warningInfoBusiness.updateStatus(warningInfoVo);
                /*End Update TBL_WARNING_INFO*/
                
                /*Begin Insert TBL_ACTION_HISTORY*/
                //ให้เช็คเพิ่มว่าถ้า actionMode = Approve และ warning_info.status = N ให้ลง action_history 2 record คือ action_code = Save และ Approve
                if ("Approve".equals(actionMode) && BusinessConst.Flag.N.equals(this.infoStatus)) {

                    formStatusControlVo = new FormStatusControlVo();
                    formStatusControlVo.setCurrStatus(infoStatus);
                    formStatusControlVo.setWarningType(warningType);

                    actionHistoryVo = new ActionHistoryVo();
                    actionHistoryVo.setWarningId    (maxWarningId);
                    actionHistoryVo.setActionBy     (user.getEmpNo());
                    actionHistoryVo.setActionDetail (BusinessConst.WarningTypeCode.LATE_PAY);
                    actionHistoryVo.setRoleCode     (user.getRoleId());
                    actionHistoryVo.setDpd          (dpd);

                    /*Begin insert save*/
                    formStatusControlVo.setActionCode("Save");
                    nextStatusAction = this.nullToStr(formStatusControlBusiness.getNextStatus(formStatusControlVo));

                    actionHistoryVo.setActionCode   ("Save");
                    actionHistoryVo.setStatus       (nextStatusAction);

                    actionHistoryBusiness.saveData(actionHistoryVo);
                    /*End insert save*/

                    /*Begin insert Approve*/
                    formStatusControlVo.setActionCode("Approve");
                    nextStatusAction = this.nullToStr(formStatusControlBusiness.getNextStatus(formStatusControlVo));

                    actionHistoryVo.setActionCode   ("Approve");
                    actionHistoryVo.setStatus       (nextStatusAction);
                    actionHistoryBusiness.saveData(actionHistoryVo);
                    /*End insert Approve*/
                }else{
                    actionHistoryVo = new ActionHistoryVo();
                    actionHistoryVo.setWarningId    (maxWarningId);
                    actionHistoryVo.setActionBy     (user.getEmpNo());
                    actionHistoryVo.setActionCode   (actionMode);
                    actionHistoryVo.setActionDetail (BusinessConst.WarningTypeCode.LATE_PAY);
                    actionHistoryVo.setStatus       (nextStatus);
                    actionHistoryVo.setRoleCode     (user.getRoleId());
                    actionHistoryVo.setRemark       (rejectRemark);
                    actionHistoryVo.setDpd          (dpd);

                    actionHistoryBusiness.saveData(actionHistoryVo);
                }
                /*End Insert TBL_ACTION_HISTORY*/
            }
            
            /*Begin Update TBL_WARNING_INFO*/
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setStatus(nextStatus);
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setWarningId(this.paresInt(this.warningId));
            warningInfoVo.setHolderId(holderId);
            warningInfoVo.setHolderRole(holderRole);
//            warningInfoVo.setAmdFlg(nullToStr(this.amdFlg));
            
            if (EWSConstantValue.ROLE_ACTION_FORM.contains(user.getRoleId())){
                warningInfoVo.setAmdFlg(nullToStr(this.amdFlg));
            }else if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                warningInfoVo.setBcmAmdFlg(nullToStr(this.amdFlg));
            }

            warningInfoBusiness.updateStatus(warningInfoVo);
            /*End Update TBL_WARNING_INFO*/
            
            /*Begin Insert TBL_ACTION_HISTORY*/
            //ให้เช็คเพิ่มว่าถ้า actionMode = Approve และ warning_info.status = N หรือ RMP ให้ลง action_history 2 record คือ action_code = Save และ Approve
            if ("Approve".equals(actionMode) && (BusinessConst.Flag.N.equals(this.infoStatus) || BusinessConst.Flag.RMP.equals(this.infoStatus))) {
                
                formStatusControlVo = new FormStatusControlVo();
                formStatusControlVo.setCurrStatus(infoStatus);
                formStatusControlVo.setWarningType(warningType);
                
                actionHistoryVo = new ActionHistoryVo();
                actionHistoryVo.setWarningId    (this.paresInt(this.warningId));
                actionHistoryVo.setActionBy     (user.getEmpNo());
                actionHistoryVo.setActionDetail (warningType);
                actionHistoryVo.setRoleCode     (user.getRoleId());
                actionHistoryVo.setDpd          (dpd);
                
                /*Begin insert save*/
                formStatusControlVo.setActionCode("Save");
                nextStatus = this.nullToStr(formStatusControlBusiness.getNextStatus(formStatusControlVo));
                
                actionHistoryVo.setActionCode   ("Save");
                actionHistoryVo.setStatus       (nextStatus);

                actionHistoryBusiness.saveData(actionHistoryVo);
                /*End insert save*/
                
                /*Begin insert Approve*/
                formStatusControlVo.setActionCode("Approve");
                nextStatus = this.nullToStr(formStatusControlBusiness.getNextStatus(formStatusControlVo));
                
                actionHistoryVo.setActionCode   ("Approve");
                actionHistoryVo.setStatus       (nextStatus);
                actionHistoryBusiness.saveData(actionHistoryVo);
                /*End insert Approve*/
            }else{
                actionHistoryVo = new ActionHistoryVo();
                actionHistoryVo.setWarningId    (this.paresInt(this.warningId));
                actionHistoryVo.setActionBy     (user.getEmpNo());
                actionHistoryVo.setActionCode   (actionMode);
                actionHistoryVo.setActionDetail (warningType);
                actionHistoryVo.setStatus       (nextStatus);
                actionHistoryVo.setRoleCode     (user.getRoleId());
                actionHistoryVo.setRemark       (rejectRemark);
                actionHistoryVo.setDpd          (dpd);

                actionHistoryBusiness.saveData(actionHistoryVo);
            }
            /*End Insert TBL_ACTION_HISTORY*/
            
            obj.put("status", 			"SUCCESS");
            
        }catch(Exception e){
            obj.put("status", 			"ERROR");
            obj.put("errMsg", 			"saveData error");
            logger.error(e);
            throw e;
        }finally{
            //this.writeMSG(obj.toString());
            log("[saveData][End]");
        }
        
        return null;
    }
    
    private void findData() throws Exception {
        log("[findData][Begin]");
        
        boolean         insertFlag          = true;//Insert new record
        WarningInfoVo   warningInfoVo       = null;
        WarningInfoVo   warningInfoVoDb     = null;
        
        try{
            this.warningWayOutFormVoList    = warningWayOutFormBusiness.getDataListByWarningId(this.paresInt(this.warningId));
            this.parameterList              = parameterBusiness.findByParamTypeId("ACTION_STATUS");
            this.actionAccountList          = action2FormBusiness.getActionAccountList(String.valueOf(this.warningHeaderId), this.warningId, this.cifNo, insertFlag, this.infoStatus, getCurrentUser());
            this.findQuestionHistory(cifNo);
            
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(warningHeaderId);
            warningInfoVo.setWarningType(warningType);
            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
            
            if(this.warningWayOutFormVoList!=null && !this.warningWayOutFormVoList.isEmpty()){
                String roleCode = this.warningWayOutFormVoList.get(0).getRoleCode();
                if (EWSConstantValue.ROLE_ACTION_FORM.contains(roleCode)){
                    this.amdFlg = this.nullToStr(warningInfoVoDb.getAmdFlg());
                }else if(BusinessConst.UserRole.BCM.equals(roleCode) || BusinessConst.UserRole.CO_BCM.equals(roleCode)){
                    this.amdFlg = this.nullToStr(warningInfoVoDb.getBcmAmdFlg());
                }
            }
            
            HttpSession    session = request.getSession(false);
            
            session.setAttribute("warningWayOutFormVoList"  , this.warningWayOutFormVoList);
            session.setAttribute("actionAccountList"        , this.actionAccountList);
            session.setAttribute("insertFlag"               , insertFlag);
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[findData][End]");
        }
    }
    
    private void findDataCommon() throws Exception {
        log("[findDataCommon][Begin]");
        
        WarningInfoVo   warningInfoVo       = null;
        WarningInfoVo   warningInfoVoDb     = null;
        UserData        userData            = getCurrentUser();
//        WarningHeaderVo whVo                = null;
        
        try{
            
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(warningHeaderId);
            warningInfoVo.setWarningType(warningType);
            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);

            this.infoStatus         = warningInfoVoDb.getStatus();
            this.warningId          = this.nullToStr(warningInfoVoDb.getWarningId());
//            this.amdFlg             = this.nullToStr(warningInfoVoDb.getAmdFlg());
            this.holderRole         = warningInfoVoDb.getHolderRole();
            this.warningDateStr     = warningInfoVoDb.getWarningDateStr();
            this.warningTypeDesc    = warningInfoVoDb.getWarningTypeDesc();
            
            this.actionHistoryVoList = asstQuestionBusiness.findRemarkFromHistory(Integer.parseInt(this.warningId));
            
            warningHeaderVo         = warningHeaderBusiness.findWarningHeaderByPK(warningHeaderId);
            this.dpd                = warningHeaderVo.getDpd();

//            warningInfoVo = new WarningInfoVo();
//            warningInfoVo.setWarningHeaderId(warningHeaderId);
//            warningInfoVo.setWarningType("WAY_OUT");
//            warningInfoVoDb = warningInfoBusiness.getWarningIdAndStatus(warningInfoVo);
//
//            this.wayOutWarningId    = this.nullToStr(warningInfoVoDb.getWarningId());

            log("[findDataCommon] cifNo             :: " + this.cifNo);
            log("[findDataCommon] warningHeaderId   :: " + this.warningHeaderId);
            log("[findDataCommon] warningId         :: " + this.warningId);
//            log("[findDataCommon] wayOutWarningId   :: " + this.wayOutWarningId);
            log("[findDataCommon] warningType       :: " + this.warningType);
            log("[findDataCommon] infoStatus        :: " + this.infoStatus);
            log("[findDataCommon] RoleId            :: " + userData.getRoleId());
//            log("[findDataCommon] amdFlg            :: " + this.amdFlg);
            log("[findDataCommon] forBackPage       :: " + this.forBackPage);
            log("[findDataCommon] holderRole        :: " + holderRole);
            log("[findDataCommon] dpd               :: " + dpd);
            
            findData();
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[findDataCommon][End]");
        }
    }
    
    public void findQuestionHistory(String cif) throws Exception{
        List<QuestionHistoryVo> historyList = null;
        QuestionHistoryVo tmpVo;
        ArrayList<QuestionHistoryVo> resultList = new ArrayList();
        ArrayList<QuestionHistoryVo> warningIdList = (ArrayList<QuestionHistoryVo>) warningHeaderBusiness.findWarningIdForHistory(cif, warningType);//warningHeaderBusiness.findWarningIdForQuestion(cif, warningType);
        
        if (warningIdList != null && !warningIdList.isEmpty()) {
           for (QuestionHistoryVo vo : warningIdList) {
                    vo.setActionDetail(warningType);
                    vo.setWarningType(warningType);
                    vo.setCif(cif);
                    historyList = actionHistoryBusiness.findQuestionHistory(vo);
                    if (historyList != null && !historyList.isEmpty()) {
                        tmpVo = (QuestionHistoryVo) historyList.get(0);
                        vo.setWarningDateInfo(tmpVo.getWarningDateInfo());
                        vo.setWarningDateHeader(tmpVo.getWarningDateHeader());
                        vo.setActionUserId(tmpVo.getActionUserId());
                        vo.setActionDate(tmpVo.getActionDate());
                        vo.setApproveUserId(tmpVo.getApproveUserId());
                        vo.setApproveDate(tmpVo.getApproveDate());
                        vo.setApproveUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getApproveUserId()));
                        vo.setActionUserName(ktbEmpDirectoryBusiness.searchEmpNameById(vo.getActionUserId()));
                        vo.setCif(cif);
                        if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                            QuestionHistoryVo tmpQuestionVo = actionHistoryBusiness.findQuestionVersion(vo.getWarningId());
                            vo.setVersion(tmpQuestionVo.getVersion());
                            vo.setQuestionId(tmpQuestionVo.getQuestionId());
                        }
                        resultList.add(vo);
                    }  
                }
                if(resultList.size() > 0){
                    setQuestionHistoryList(resultList);
                }
            }
    }
    
    public String goTaskDetail() throws Exception {
        logger.debug("[goTaskDetail][Begin]");
        
        String backToPage   = "backTaskDetail";
        String forBackPage  = null;
        
        try{
            forBackPage = (String) request.getSession(false).getAttribute(BusinessConst.Session.FOR_BACK_PAGE_TASK_DETAIL);
            
            logger.debug("[goTaskDetail] forBackPage :: " + forBackPage);
            
            if(forBackPage!=null && !forBackPage.equals("")){
                if(forBackPage.equals(BusinessConst.PAGE.CLOSE_JOB_REPORT)){
                    backToPage = "backCloseJobTaskList";
                }else if(forBackPage.equals(BusinessConst.PAGE.PIPELINE)){
                    backToPage = "backTaskDetail";
                }
            }
            
            logger.debug("[goTaskDetail][End]");
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[goTaskDetail][End]");
        }
        
        return backToPage;
    }
    
    public String goHistoricalAssessment() throws Exception {
        return "goHistoricalAssessment";
    }
    
    public String editByBCM() throws Exception{
        log("[editByBCM][Begin]");
        
        try{
            log("[editByBCM] pageFlag :: " + pageFlag);
            
//            this.modeView   = "";
            this.showMode   = "false";//Mode Edit
            this.showButton = "4";//บันทึก, ยกเลิก, อนุมัติ
            
            if("action".equals(pageFlag)){
                actionLatePaymentFindData();
                
                return "latepay";
            }else{
                findDataCommon();
                
                return SUCCESS;
            }
            
            
            
        } catch (Exception ex) {
            logger.error(ex);
            throw ex;
        } finally{
            log("[editByBCM][End]");
        }
    }
    
    public String cancel() throws Exception{
        log("[cancel][Begin]");

        try{
//            this.modeView   = "";
            this.showMode = "true";//Mode View
            this.showButton = "2";//แก้ไข, ส่งกลับ, ยืนยัน/อนุมัติ
                
            if("action".equals(pageFlag)){
                actionLatePaymentFindData();
                
                return "latepay";
            }else{
                findDataCommon();
                
                return SUCCESS;
            }

        } catch (Exception ex) {
            logger.error(ex);
            throw ex;
        } finally{
            log("[cancel][End]");
        }
    }
     
    public String saveForBCM() throws Exception {
        log("[saveForBCM][Begin]");
        
        HttpSession                 session                 = request.getSession(false);
        UserData                    user                    = getCurrentUser();
        List<WarningWayOutFormVo>   warningWayOutFormVoList = (List<WarningWayOutFormVo>) session.getAttribute("warningWayOutFormVoList");
        List<ActionAccountVo>       actionAccountList       = (List<ActionAccountVo>) session.getAttribute("actionAccountList");
        WarningInfoVo               warningInfoVo           = new WarningInfoVo();
        ActionHistoryVo             actionHistoryVo         = null;
        
        try{
            
            log("[saveForBCM] amdFlg      :: " + this.amdFlg);
            log("[saveForBCM] infoStatus  :: " + this.infoStatus);
            log("[saveForBCM] warningId   :: " + this.warningId);
            
            warningWayOutFormBusiness.saveWarningActionForm(warningWayOutFormVoList, this.warningId, user);
            action2FormBusiness.insertOrUpdateActionAccount(actionAccountList, String.valueOf(warningHeaderId), this.warningId, user);
            
            /*Begin Update TBL_WARNING_INFO*/
            warningInfoVo = new WarningInfoVo();
            warningInfoVo.setStatus(this.infoStatus);
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setWarningId(this.paresInt(this.warningId));
            warningInfoVo.setHolderId(user.getEmpNo());
            warningInfoVo.setHolderRole(user.getRoleId());
//            warningInfoVo.setAmdFlg(nullToStr(this.amdFlg));
            if (EWSConstantValue.ROLE_ACTION_FORM.contains(user.getRoleId())){
                warningInfoVo.setAmdFlg(nullToStr(this.amdFlg));
            }else if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                warningInfoVo.setBcmAmdFlg(nullToStr(this.amdFlg));
            }

            warningInfoBusiness.updateStatus(warningInfoVo);
            /*End Update TBL_WARNING_INFO*/
            
            /*Begin Insert TBL_ACTION_HISTORY*/
            actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId    (this.paresInt(this.warningId));
            actionHistoryVo.setActionBy     (user.getEmpNo());
            actionHistoryVo.setActionCode   ("Save");
            actionHistoryVo.setActionDetail (warningType);
            actionHistoryVo.setStatus       (infoStatus);
            actionHistoryVo.setRoleCode     (user.getRoleId());
            actionHistoryVo.setRemark       (rejectRemark);
            actionHistoryVo.setDpd          (dpd);

            actionHistoryBusiness.saveData(actionHistoryVo);
            /*End Insert TBL_ACTION_HISTORY*/
            
            findDataCommon();
            
//            this.modeView   = "";
            this.showMode   = "false";//Mode Edit
            this.showButton = "4";//บันทึก, ยกเลิก, อนุมัติ
            
            if("action".equals(pageFlag)){
                log("[saveForBCM] confirmLatePay    :: " + confirmLatePay);

                if(confirmLatePay!=null){
                    if (EWSConstantValue.ROLE_ACTION_FORM.contains(user.getRoleId())){
                        warningInfoBusiness.updateConfirmLatepayment(confirmLatePay, null, this.warningId);
                    }else if(BusinessConst.UserRole.BCM.equals(user.getRoleId()) || BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                        warningInfoBusiness.updateConfirmLatepayment(null, confirmLatePay, this.warningId);
                    }
                }

                saveLatePayment();
                
                /*Begin Insert TBL_ACTION_HISTORY*/
                int maxWarningId = warningInfoBusiness.findMaxWarningId(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
                actionHistoryVo = new ActionHistoryVo();
                actionHistoryVo.setWarningId    (maxWarningId);
                actionHistoryVo.setActionBy     (user.getEmpNo());
                actionHistoryVo.setActionCode   ("Save");
                actionHistoryVo.setActionDetail (BusinessConst.WarningTypeCode.LATE_PAY);
                actionHistoryVo.setStatus       (infoStatus);
                actionHistoryVo.setRoleCode     (user.getRoleId());
                actionHistoryVo.setRemark       (rejectRemark);
                actionHistoryVo.setDpd          (dpd);

                actionHistoryBusiness.saveData(actionHistoryVo);
                /*End Insert TBL_ACTION_HISTORY*/
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            log("[saveForBCM][End]");
        }
        return success();
//        return SUCCESS;
    }
    
    public static Date getCurrentDate() throws Exception {
        Calendar    calDate 	= Calendar.getInstance(Locale.US);
        
//        calDate.set(Calendar.HOUR_OF_DAY, 0);
//        calDate.set(Calendar.MINUTE, 0);
//        calDate.set(Calendar.SECOND, 0);
//        calDate.set(Calendar.MILLISECOND, 0);
        
        calDate.clear(Calendar.HOUR);
        calDate.clear(Calendar.HOUR_OF_DAY);
        calDate.clear(Calendar.AM_PM);
        calDate.clear(Calendar.MINUTE);
        calDate.clear(Calendar.SECOND);
        calDate.clear(Calendar.MILLISECOND);
        
        
        return calDate.getTime();
    } 
    
    public String openRejectPopup() throws Exception {
        log("[openRejectPopup][Begin]");
        JSONObject      obj                 = new JSONObject();
        ActionHistoryVo actionHistoryVo     = null;
        String          rejectRem           = "";
        
        try{
            actionHistoryVo = actionHistoryBusiness.findData(Integer.parseInt(this.warningId), "ACTION2");
            
            if(actionHistoryVo!=null && BusinessConst.Flag.RX.equals(actionHistoryVo.getStatus())){
                rejectRem = actionHistoryVo.getRemark();
            }
            
            this.rejectRemark = rejectRem;
            
            obj.put("status", 		"SUCCESS");
            obj.put("rejectRemark", 	rejectRem);
        }catch(Exception e){
            obj.put("status",           "ERROR");
            obj.put("errMsg", 		"openRejectPopup error");
            logger.error(e);
            throw e;
        }finally{
            this.writeMSG(obj.toString());
            log("[openRejectPopup][End]");
        }

        return null;
    }
    
    public String saveRemark() throws Exception {
        log("[saveRemark][Begin]");
        JSONObject      obj                 = new JSONObject();
        ActionHistoryVo actionHistoryVo     = null;
        ActionHistoryVo vo                  = null;
        
        try{
            log("[saveRemark] warningId :: " + warningId);
            log("[saveRemark] rejectRemark :: " + rejectRemark);
            actionHistoryVo = actionHistoryBusiness.findData(Integer.parseInt(this.warningId), "ACTION2");
            
            if(actionHistoryVo!=null && BusinessConst.Flag.RX.equals(actionHistoryVo.getStatus())){
                actionHistoryVo.setRemark(rejectRemark);
                actionHistoryBusiness.updateRemarkForDraftReject(actionHistoryVo);
            }else{
                /*Begin Insert TBL_ACTION_HISTORY*/
                vo = new ActionHistoryVo();
                vo.setWarningId    (this.paresInt(warningId));
                vo.setActionBy     (getCurrentUser().getEmpNo());
                vo.setActionCode   ("Reject");
                vo.setActionDetail ("ACTION2");
                vo.setStatus       (BusinessConst.Flag.RX);
                vo.setRoleCode     (getCurrentUser().getRoleId());
                vo.setRemark       (rejectRemark);

                actionHistoryBusiness.saveData(vo);
                /*End Insert TBL_ACTION_HISTORY*/
            }
            
            obj.put("status", 		"SUCCESS");
        }catch(Exception e){
            obj.put("status",           "ERROR");
            obj.put("errMsg", 		"saveRemark error");
            logger.error(e);
            throw e;
        }finally{
            this.writeMSG(obj.toString());
            log("[saveRemark][End]");
        }

        return null;
    }
    
    private void writeMSG(String msg) {
        PrintWriter print = null;
        try {
            this.response.setContentType("text/html; charset=UTF-8");
            print = this.response.getWriter();
            print.write(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }
    
    private String nullToStr(Object obj){
        
        return obj==null?"":obj.toString().trim();
        
    }
    
    private int paresInt(Object obj){
        return obj==null?0:Integer.parseInt(obj.toString());
    }
    
    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

//    public String getActionWarningId() {
//        return actionWarningId;
//    }
//
//    public void setActionWarningId(String actionWarningId) {
//        this.actionWarningId = actionWarningId;
//    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public List<String> getAnswers() {
        return answers;
    }

    public void setAnswers(List<String> answers) {
        this.answers = answers;
    }

    public List<QuestionHistoryVo> getQuestionHistoryList() {
        return questionHistoryList;
    }

    public void setQuestionHistoryList(List<QuestionHistoryVo> questionHistoryList) {
        this.questionHistoryList = questionHistoryList;
    }

    public String getShowMode() {
        return showMode;
    }

    public void setShowMode(String showMode) {
        this.showMode = showMode;
    }

    public List<ActionHistoryVo> getActionHistoryVoList() {
        return actionHistoryVoList;
    }

    public void setActionHistoryVoList(List<ActionHistoryVo> actionHistoryVoList) {
        this.actionHistoryVoList = actionHistoryVoList;
    }

    public List<WarningWayOutFormVo> getWarningWayOutFormVoList() {
        return warningWayOutFormVoList;
    }

    public void setWarningWayOutFormVoList(List<WarningWayOutFormVo> warningWayOutFormVoList) {
        this.warningWayOutFormVoList = warningWayOutFormVoList;
    }

    public List<ParameterVo> getParameterList() {
        return parameterList;
    }

    public void setParameterList(List<ParameterVo> parameterList) {
        this.parameterList = parameterList;
    }

    public String getShowButton() {
        return showButton;
    }

    public void setShowButton(String showButton) {
        this.showButton = showButton;
    }

    public String getActionMode() {
        return actionMode;
    }

    public void setActionMode(String actionMode) {
        this.actionMode = actionMode;
    }

//    public String getWayOutWarningId() {
//        return wayOutWarningId;
//    }
//
//    public void setWayOutWarningId(String wayOutWarningId) {
//        this.wayOutWarningId = wayOutWarningId;
//    }

    public String getAmdFlg() {
        return amdFlg;
    }

    public void setAmdFlg(String amdFlg) {
        this.amdFlg = amdFlg;
    }

//    public String getModeView() {
//        return modeView;
//    }
//
//    public void setModeView(String modeView) {
//        this.modeView = modeView;
//    }

    public String getWarningIdHistory() {
        return warningIdHistory;
    }

    public void setWarningIdHistory(String warningIdHistory) {
        this.warningIdHistory = warningIdHistory;
    }

    public String getWarningHeaderIdHistory() {
        return warningHeaderIdHistory;
    }

    public void setWarningHeaderIdHistory(String warningHeaderIdHistory) {
        this.warningHeaderIdHistory = warningHeaderIdHistory;
    }

    public String getQuestionIdHistory() {
        return questionIdHistory;
    }

    public void setQuestionIdHistory(String questionIdHistory) {
        this.questionIdHistory = questionIdHistory;
    }

    public String getVersionHistory() {
        return versionHistory;
    }

    public void setVersionHistory(String versionHistory) {
        this.versionHistory = versionHistory;
    }

    public String getWarningTypeHistory() {
        return warningTypeHistory;
    }

    public void setWarningTypeHistory(String warningTypeHistory) {
        this.warningTypeHistory = warningTypeHistory;
    }

    public String getActionDateHistory() {
        return actionDateHistory;
    }

    public void setActionDateHistory(String actionDateHistory) {
        this.actionDateHistory = actionDateHistory;
    }

    public String getForBackPage() {
        return forBackPage;
    }

    public void setForBackPage(String forBackPage) {
        this.forBackPage = forBackPage;
    }
    
    public List<ActionAccountVo> getActionAccountList() {
        return actionAccountList;
    }

    public void setActionAccountList(List<ActionAccountVo> actionAccountList) {
        this.actionAccountList = actionAccountList;
    }

    public String getWarningDateStr() {
        return warningDateStr;
    }

    public void setWarningDateStr(String warningDateStr) {
        this.warningDateStr = warningDateStr;
    }

    public String getHolderRole() {
        return holderRole;
    }

    public void setHolderRole(String holderRole) {
        this.holderRole = holderRole;
    }

    public String getWarningId() {
        return warningId;
    }

    public void setWarningId(String warningId) {
        this.warningId = warningId;
    }

    public List<AsstTopicVo> getAsstTopicVoList() {
        return asstTopicVoList;
    }

    public void setAsstTopicVoList(List<AsstTopicVo> asstTopicVoList) {
        this.asstTopicVoList = asstTopicVoList;
    }

    public String getWarningInfoDateStr() {
        return warningInfoDateStr;
    }

    public void setWarningInfoDateStr(String warningInfoDateStr) {
        this.warningInfoDateStr = warningInfoDateStr;
    }

    public int getLatepayWarningId() {
        return latepayWarningId;
    }

    public void setLatepayWarningId(int latepayWarningId) {
        this.latepayWarningId = latepayWarningId;
    }

    public List<String> getAnswersResult() {
        return answersResult;
    }

    public void setAnswersResult(List<String> answersResult) {
        this.answersResult = answersResult;
    }

    public String getWarningTypeDesc() {
        return warningTypeDesc;
    }

    public void setWarningTypeDesc(String warningTypeDesc) {
        this.warningTypeDesc = warningTypeDesc;
    }

    public String getRejectRemark() {
        return rejectRemark;
    }

    public void setRejectRemark(String rejectRemark) {
        this.rejectRemark = rejectRemark;
    }

    public List<AsstTopicVo> getAsstTopicPopupVoList() {
        return asstTopicPopupVoList;
    }

    public void setAsstTopicPopupVoList(List<AsstTopicVo> asstTopicPopupVoList) {
        this.asstTopicPopupVoList = asstTopicPopupVoList;
    }

    public List<String> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<String> questionList) {
        this.questionList = questionList;
    }

    public List<String> getRemarks() {
        return remarks;
    }

    public void setRemarks(List<String> remarks) {
        this.remarks = remarks;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public List<String> getRequireList() {
        return requireList;
    }

    public void setRequireList(List<String> requireList) {
        this.requireList = requireList;
    }

    public String getConfirmLatePay() {
        return confirmLatePay;
    }

    public void setConfirmLatePay(String confirmLatePay) {
        this.confirmLatePay = confirmLatePay;
    }

    public String getConfirmLatePayDesc() {
        return confirmLatePayDesc;
    }

    public void setConfirmLatePayDesc(String confirmLatePayDesc) {
        this.confirmLatePayDesc = confirmLatePayDesc;
    }

    public String getPageFlag() {
        return pageFlag;
    }

    public void setPageFlag(String pageFlag) {
        this.pageFlag = pageFlag;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public Integer getDpd() {
        return dpd;
    }

    public void setDpd(Integer dpd) {
        this.dpd = dpd;
    }

    public WarningHeaderVo getWarningHeaderVo() {
        return warningHeaderVo;
    }

    public void setWarningHeaderVo(WarningHeaderVo warningHeaderVo) {
        this.warningHeaderVo = warningHeaderVo;
    }

    public String getPopUpHistoryFlg() {
        return popUpHistoryFlg;
    }

    public void setPopUpHistoryFlg(String popUpHistoryFlg) {
        this.popUpHistoryFlg = popUpHistoryFlg;
    }
    
}
