/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.CRCustReviewEwsServices;
import com.ktb.ewsl.services.CrWarningAcctService;
import com.ktb.ewsl.services.CustomerService;
import com.ktb.ewsl.services.RptIndividualAccountService;
import com.ktb.ewsl.vo.CrWarningAcctVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.RptIndividualAccountVo;
import com.ktbcs.core.utilities.StringUtil;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Pratya
 */
@Service
public class TodayMovementBusinessImpl implements TodayMovementBusiness {
    private static Logger logger = Logger.getLogger(TodayMovementBusinessImpl.class);
  
    @Autowired
    private CustomerService customerService;
    @Autowired
    private RptIndividualAccountService rptIndividualAccountService;
    @Autowired
    private CRCustReviewEwsServices crCustReviewEwsServices;
    @Autowired
    private CrWarningAcctService crWarningAcctService;

    @Override
    public CustomerVo customerInfo(CustomerVo vo) throws Exception {
        return customerService.customerInfo(vo);
    }

    @Override
    public List<RptIndividualAccountVo> getRptIndividualAccountList(RptIndividualAccountVo vo) throws Exception {
        
        List<RptIndividualAccountVo> rptIndividualAccountList = null;
        
        try{
            rptIndividualAccountList = rptIndividualAccountService.getRptIndividualAccountList(vo);
            
            for(RptIndividualAccountVo voDb:rptIndividualAccountList){
                voDb.setLoanGrpProd( getLoanGrpProd( voDb.getProductGroup() , voDb.getProductType(), voDb.getAccountSubType(), voDb.getLoanType() ));
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }
        
        return rptIndividualAccountList;
    }
    
    public String getLoanGrpProd(String prodGroup, String prodType, String acctSubType, String marketCode) throws Exception {
        String loanGrpProd = null;
        
        try{
            if ("00064".equals(acctSubType)) {
                loanGrpProd = "Trade Finance";
            } else {
                if (StringUtil.isNotEmpty(marketCode)) {
                    if(marketCode.equals("9999")){
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType, marketCode);
                    }else{
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(marketCode);
                    }
                } else {
                    if (StringUtil.isNotEmpty(prodGroup) && StringUtil.isNotEmpty(acctSubType) && !"00000".equals(acctSubType)) {
                         loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType);
                    } else if ("1001".equals(prodType)) {
                        loanGrpProd = "O/D";
                    }
                }
            }
        }catch(Exception e){
            throw e;
        }
        
        return loanGrpProd;
    }

    @Override
    public List<CrWarningAcctVo> getCrWarningAcctList(String cif, String flag) throws Exception {
        List<CrWarningAcctVo> crWarningAcctList = null;
        
        try{
            crWarningAcctList = crWarningAcctService.getCrWarningAcctList(cif, flag);
            for(CrWarningAcctVo voDb:crWarningAcctList){
                voDb.setLoanGrpProd( getLoanGrpProd( voDb.getProductGroup() , voDb.getProductType(), voDb.getAccountSubType(), voDb.getLoanType() ));
            }
        }catch(Exception e){
            throw e;
        }
        
        return crWarningAcctList;
    }

}
