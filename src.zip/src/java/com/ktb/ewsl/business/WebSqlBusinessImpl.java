/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WebSqlService;
import com.ktb.ewsl.vo.WebSqlVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class WebSqlBusinessImpl implements WebSqlBusiness{
    
    @Autowired
     private  WebSqlService webSqlService;
            
    @Override
    public WebSqlVo run(String sql) throws Exception {
        WebSqlVo  webSqlVo =  webSqlService.run(sql);
         return webSqlVo;
    }
    
}
