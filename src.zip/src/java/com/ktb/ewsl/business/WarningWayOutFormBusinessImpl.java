/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningWayOutFormService;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.WarningWayOutFormVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Pratya
 */
@Service
public class WarningWayOutFormBusinessImpl extends AbstractBusiness implements WarningWayOutFormBusiness {
    private static Logger log = Logger.getLogger(WarningWayOutFormBusinessImpl.class);
  
    @Autowired
    private WarningWayOutFormService warningWayOutFormService;

    @Override
    public ArrayList<WarningWayOutFormVo> getDataListByWarningId (int warningId) throws Exception {
        
         return warningWayOutFormService.getDataListByWarningId(warningId);
    }

//    @Override
//    public void updateConfirmAnswer(WarningWayOutFormVo vo) throws Exception {
//        warningWayOutFormService.updateConfirmAnswer(vo);
//    }
    
    @Override
    public void saveWarningActionForm(List<WarningWayOutFormVo>   warningWayOutFormVoList, String warningId, UserData user) throws Exception {
        log("[saveWarningActionForm][Begin]");
        
        try{
            deleteWarningActionForm(warningId, user.getRoleId());
            
            for(WarningWayOutFormVo vo:warningWayOutFormVoList){
                vo.setWarningId   (warningId);
                vo.setRoleCode    (user.getRoleId());
                vo.setCreatedBy   (user.getEmpNo());
                
                if(vo.getConfFlg()==null || vo.getConfFlg().equals("") || vo.getConfFlg().equalsIgnoreCase("N")){
                    vo.setActionStatus("");
                    vo.setConfRemark("");
                }

                warningWayOutFormService.insertWarningActionForm(vo);
            }
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log("[saveWarningActionForm][End]");
        }
    }
    
    @Override
    public void deleteWarningActionForm(String warningId, String roleCode) throws Exception {
        log("[deleteWarningActionForm][Begin]");
        
        String roleCodeForDelete = "";
        
        try{
            log("[deleteWarningActionForm] warningId  :: " + warningId);
            log("[deleteWarningActionForm] roleCode   :: " + roleCode);
            
            if(EWSConstantValue.ROLE_ACTION_FORM.contains(roleCode)){
                roleCodeForDelete = "'"+BusinessConst.UserRole.RM+"', '"+BusinessConst.UserRole.AE+"', '"+BusinessConst.UserRole.AO+"', '"+BusinessConst.UserRole.CO_RM+"', '"+BusinessConst.UserRole.CO_AE+"', '"+BusinessConst.UserRole.CO_AO+"'";
                
                
            }else{
                roleCodeForDelete = "'"+BusinessConst.UserRole.BCM+"', '"+BusinessConst.UserRole.CO_BCM + "'";
            }
            
            warningWayOutFormService.deleteWarningActionForm(Integer.parseInt(warningId), roleCodeForDelete);
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log("[deleteWarningActionForm][End]");
        }
    }
    
    private void log(String txt){
        if(log.isInfoEnabled()){
            log.info(txt);
        }
    }
    
}
