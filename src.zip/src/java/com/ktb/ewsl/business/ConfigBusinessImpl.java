/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ConfigService;
import com.ktb.ewsl.vo.ConfigVO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class ConfigBusinessImpl implements ConfigBusiness{
    
    @Autowired
    private ConfigService configService;

    @Override
    public ConfigVO findByConfigGroupAndConfigCode(String configGroupCode, String configCode) throws Exception {
        return configService.findByConfigGroupAndConfigCode(configGroupCode, configCode);
    }
    
    @Override
    public List<ConfigVO> findByConfigGroup(String configGroupCode) throws Exception {
        return configService.findByConfigGroup(configGroupCode);
    }
}
