/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.KtbOrganizationServices;
import com.ktb.ewsl.services.RptIndividualRiskLevelService;
import com.ktb.ewsl.services.WarningHeaderService;
import com.ktb.ewsl.vo.CustomerPortfolioVo;
import com.ktb.ewsl.vo.RptIndividualRiskLevelVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class CustomerPortfolioBusinessImpl  extends AbstractBusiness implements CustomerPortfolioBusiness{
    
    private static Logger log = Logger.getLogger(CustomerPortfolioBusinessImpl.class);
    
    @Autowired
    private WarningHeaderService warningHeaderService;
    @Autowired
    private RptIndividualRiskLevelService rptIndividualRiskLevelService;
    @Autowired
    private KtbOrganizationServices ktbOrganizationServices;
    @Override
    public PaginatedListImpl getCustomerPortfolioList(PaginatedListImpl paginate, SearchBean searchBean, UserData user, int page) throws Exception {
       
        try {
            if (log.isInfoEnabled()) {
                log.info("CustomerPortfolioBusinessImpl.getCustomerPortfolioList");
                log.info("EmpNo : " + user.getEmpNo());
                log.info("RoleId : " + user.getRoleId());
                log.info("DeptCode : " + user.getDeptCode());
            }

            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            searchBean.setResponseUnit(user.getDeptCode());
            searchBean.setRmId(user.getEmpNo());
            searchBean.setRoleId(user.getRoleId());

            paginate = warningHeaderService.getCustomerPortfolioListForPaging(paginate, searchBean, page);

        } catch (Exception e) {
            log.error("Error occur in while process CustomerPortfolioBusinessImpl.getCustomerPortfolioList : " + e.getMessage(), e);
        }
        return paginate;
    }

    @Override
    public List<RptIndividualRiskLevelVo> getIndividualRiskLevel(Integer cifNo, String rishType) throws Exception {
       return rptIndividualRiskLevelService.getIndividualRiskLevel(cifNo, rishType);
    }

    @Override
    public ArrayList<CustomerPortfolioVo> getCustomerPortfolioListExport(SearchBean searchBean) throws Exception {
       ArrayList<CustomerPortfolioVo> customerPortfolioVoList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("CustomerPortfolioBusinessImpl.getCustomerPortfolioListExport");
            }

            if (searchBean == null) {
                searchBean = new SearchBean();
            }

            customerPortfolioVoList = warningHeaderService.getCustomerPortfolioList(searchBean);

        } catch (Exception e) {
            log.error("Error occur in while process CustomerPortfolioBusinessImpl.getCustomerPortfolioListExport : " + e.getMessage(), e);
        }
        return customerPortfolioVoList;
    }

     @Override
    public Map getCustomerPortfolioList(SearchBean searchBean) throws Exception {
        Map<String, List> mapList = new TreeMap<String, List>();
          Map<String, List> mapWithNameList = new TreeMap<String, List>();
          try{
          String displayBreakType = searchBean.getIndividualReportBreakBy();
          List<CustomerPortfolioVo> result = warningHeaderService.getCustomerPortfolioList(searchBean , displayBreakType);
          String currentKey = "";
          List<CustomerPortfolioVo> eachGroup = new ArrayList<CustomerPortfolioVo>();
          for(CustomerPortfolioVo vo : result){
               String dataForBreak = "";
               if(BusinessConst.BREAK_BY.HAVE_DEPARTMENT.equals(displayBreakType)){
                        dataForBreak = vo.getCostcenterCode(); //-- หน่วยงาน
               }else if(BusinessConst.BREAK_BY.HAVE_GROUP_CODE.equals(displayBreakType)){
                        dataForBreak = vo.getGroupCode(); //-- กลุ่ม
               }else{
                        break;
               }
               //------ Break By
              if(!ValidatorUtil.isNullOrEmpty(dataForBreak)){ 
                if(ValidatorUtil.isNullOrEmpty(currentKey)){
                   currentKey = dataForBreak;
                   eachGroup = new ArrayList<CustomerPortfolioVo>();
                }
                if((currentKey != null)&&(!currentKey.equals(dataForBreak))){
                    currentKey = dataForBreak;
                    eachGroup = new ArrayList<CustomerPortfolioVo>();
                    eachGroup.add(vo);
                }else{
                    eachGroup.add(vo);
                }
                //------ TreeMap ----//
                if(mapList.containsKey(currentKey)){
                  mapList.remove(currentKey);
                  mapList.put(currentKey, eachGroup);
                }else{
                  mapList.put(currentKey, eachGroup);
                }   
          }
          }
          
          if(mapList.isEmpty()){
              mapWithNameList.put("NO_BREAK", result);
          }else{
            Iterator entries = mapList.entrySet().iterator();
             while (entries.hasNext()) {
                 Map.Entry entry = (Map.Entry) entries.next();
                 String key = (String)entry.getKey();
                 String keyName = ktbOrganizationServices.findCostCenterName(key);
                 String keyFull = key.concat(" - ").concat(keyName);
                 mapWithNameList.put(keyFull, (List)entry.getValue());
             }
          }
          } catch (Exception e) {
            log.error("Error occur in while process CustomerPortfolioBusinessImpl.getCustomerPortfolioList: " + e.getMessage(), e);
        }
       return mapWithNameList;
    }

    @Override
    public String getMaxBatchDate(SearchBean searchBean) throws Exception {
        return warningHeaderService.getMaxBatchDate(searchBean);
    }
    
}
