/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.CRCustReviewEwsServices;
import com.ktb.ewsl.services.CrWarningAcctService;
import com.ktb.ewsl.services.WarningCompletionService;
import com.ktb.ewsl.services.WarningHeaderService;
import com.ktb.ewsl.vo.CrSubAccountVo;
import com.ktb.ewsl.vo.CrWarningAcctVo;
import com.ktb.ewsl.vo.WarningCompletionVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Pratya
 */
@Service
public class AccountDetailBusinessImpl implements AccountDetailBusiness {
    private static Logger logger = Logger.getLogger(AccountDetailBusinessImpl.class);
  
    @Autowired
    private CrWarningAcctService crWarningAcctService;
    @Autowired
    private CRCustReviewEwsServices crCustReviewEwsServices;
    @Autowired
    private WarningHeaderService warningHeaderService;
    @Autowired
    private WarningCompletionService warningCompletionService;

    @Override
    public ArrayList<CrWarningAcctVo> getCrWarningAcctListByCif(String cif) throws Exception {
        ArrayList<CrWarningAcctVo> crWarningAcctList = null;
        
        try{
            crWarningAcctList = crWarningAcctService.getCrWarningAcctListByCif(cif);
            
            for(CrWarningAcctVo voDb:crWarningAcctList){
                voDb.setLoanGrpProd( getLoanGrpProd( voDb.getProductGroup() , voDb.getProductType(), voDb.getAccountSubType(), voDb.getLoanType() ));
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }
        
        return crWarningAcctList;
    }
    
        
    public String getLoanGrpProd(String prodGroup, String prodType, String acctSubType, String marketCode) throws Exception {
        String loanGrpProd = null;
        
        try{
            if ("00064".equals(acctSubType)) {
                loanGrpProd = "Trade Finance";
            } else {
                if (StringUtil.isNotEmpty(marketCode)) {
                    if(marketCode.equals("9999")){
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType, marketCode);
                    }else{
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(marketCode);
                    }
                } else {
                    if (StringUtil.isNotEmpty(prodGroup) && StringUtil.isNotEmpty(acctSubType) && !"00000".equals(acctSubType)) {
                         loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType);
                    } else if ("1001".equals(prodType)) {
                        loanGrpProd = "O/D";
                    }
                }
            }
        }catch(Exception e){
            throw e;
        }
        
        return loanGrpProd;
    }
    private void log(String msg){
        try{
            if (logger.isDebugEnabled()) {
                logger.debug(msg);
            }
        }catch(Exception e){
            logger.error(e);
        }
    }

}
