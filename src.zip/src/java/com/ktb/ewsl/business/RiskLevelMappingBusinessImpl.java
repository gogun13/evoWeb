/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.RiskLevelMappingService;
import com.ktb.ewsl.vo.RiskLevelMappingVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class RiskLevelMappingBusinessImpl  extends AbstractBusiness implements RiskLevelMappingBusiness{
    
   private static final Logger log = Logger.getLogger(RiskLevelMappingBusinessImpl.class);
    
    @Autowired
    private RiskLevelMappingService riskLevelMappingService;

    @Override
    public String getRiskLevelThatReq(String columnReq, String riskLevelMasterSE) throws Exception {
      String result = "";  
      if(!ValidatorUtil.isNullOrEmpty(columnReq)&&!ValidatorUtil.isNullOrEmpty(riskLevelMasterSE)){
          result = riskLevelMappingService.getRiskLevelThatReq(columnReq, riskLevelMasterSE);
      }
      return result;
    }

    @Override
    public Map<String, String> lookUpDataRiskLevel(String columnReq) throws Exception {
       Map<String, String> dataMap = new HashMap<String, String>();
       try{
           List<RiskLevelMappingVo> dataList =  riskLevelMappingService.getObjectRiskLevelList();
           if(!dataList.isEmpty()){
              for(RiskLevelMappingVo vo : dataList){
                  String resultDest = "";
                  if(BusinessConst.COLUMN_MT_RISK_LEVEL_MAPPING.DISPLAY_ON_SCREEN_INDIVIDUAL_REPORT.equals(columnReq)){
                        resultDest = vo.getRiskLevelIndRptDisp();
                  }else if(BusinessConst.COLUMN_MT_RISK_LEVEL_MAPPING.DISPLAY_ON_SCREEN_LEVEL_HISTORY.equals(columnReq)){
                        resultDest = vo.getRiskLevelHistoryDisp();
                  }else if(BusinessConst.COLUMN_MT_RISK_LEVEL_MAPPING.DISPLAY_ON_SCREEN_PIPELINE.equals(columnReq)){
                        resultDest = vo.getRiskLevelPiplelineDisp();
                  }else if(BusinessConst.COLUMN_MT_RISK_LEVEL_MAPPING.FOR_RENEWAL_DB.equals(columnReq)){
                        resultDest = vo.getRiskLevelRenewalDisp();
                  }
                  //--------- Map Data ------//
                  if(!ValidatorUtil.isNullOrEmpty(resultDest)){
                          dataMap.put(vo.getRiskLevel(), resultDest);
                  }
              }
           }
       }catch(Exception e){
          log.error("Error occur in while process RiskLevelMappingBusinessImpl.lookUpDataRiskLevel : ", e);
       }
       return dataMap;
    }

    @Override
    public Map<String, RiskLevelMappingVo> lookUpRiskLevelVo() throws Exception {
        Map<String, RiskLevelMappingVo> dataVoMap = new HashMap<String, RiskLevelMappingVo>();
       try{
           List<RiskLevelMappingVo> dataList =  riskLevelMappingService.getObjectRiskLevelList();
           if(!dataList.isEmpty()){
              for(RiskLevelMappingVo vo : dataList){
                  if(!ValidatorUtil.isNullOrEmpty(vo.getRiskLevel())){
                          dataVoMap.put(vo.getRiskLevel(), vo);
                  }
              }
           }
       }catch(Exception e){
          log.error("Error occur in while process RiskLevelMappingBusinessImpl.lookUpRiskLevelVo : ", e);
       }
       return dataVoMap;
    }
}
