/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.exceptions.RenowalException;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningHeaderBusiness {
     
    public void updateFlagInWarningHeaderForFin(int warningHeaderId , UserData user , String status) throws Exception ;
    public void closeJob(WarningHeaderVo warningHeaderVo, UserData user, String reason, String remark, String actionMode, Integer warningId, String warningType) throws Exception, RenowalException;
    public WarningHeaderVo findWarningHeaderObject(int warningHeaderId , String cifNo) throws Exception;
    public List<ActionCloseVo> findReasonForClose(Integer warningHeaderId) throws Exception;
    public boolean valueFlagWarningInfo(String data , String closeFlag) throws Exception;
    public boolean valueFlagHeaderFlag(String data) throws Exception;
    public void updateStatusAndFinFlag(int warningHeaderId , UserData user , String status) throws Exception ;
    public WarningHeaderVo findWarningHeaderByPK( int warningHeaderId ) throws Exception;
    public List<QuestionHistoryVo> findWarningIdForQuestion(String cif,String warningType) throws Exception;
    //----------------- EWSL
    public PaginatedListImpl getPipeline(PaginatedListImpl paginate, SearchBean searchBean , UserData userData ,int pageAmt ) throws Exception;
    public Integer countPipelineHaveCoOp(SearchBean searchBean , UserData userData) throws Exception;
    public void updateAction1Flg(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
    public void updateAction2Flg(WarningHeaderVo warningHeaderVo) throws Exception;
    public void updateStatusWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception;
//    public void updateWayOutFlg(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
    public WarningHeaderVo findWarningHeaderObjectOriginal(int warningHeaderId , String cifNo) throws Exception;
    public void updateForApprove(WarningHeaderVo warningHeaderVo, String completeFlg) throws Exception;//Add By Pound
    public void updateStateAfterCheckDataBeforeCloseOutOfPipeline(String updateBy , int warningHeaderId) throws Exception;
    public void updateForApproveForCloaseByCif(WarningHeaderVo warningHeaderVo, String completeFlg) throws Exception;
    public int countForCloseByCif(int warningHeaderId) throws Exception;
    public Integer findWarningInfoALLNewOrBlank(int warningHeaderId) throws Exception;
    //R1.3
    public List<QuestionHistoryVo> findWarningIdForHistory(String cif,String warningType) throws Exception;
}
