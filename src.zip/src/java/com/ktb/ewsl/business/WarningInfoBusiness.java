/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.vo.UserData;
import java.util.List;
import java.util.Map;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningInfoBusiness {


    public void genTrigger(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user, String version, String warningType) throws Exception;
    
    public void updateStatusByWarningIdAndType(int warningInfoId , String warningType , UserData user , String status , String actionCode , String infoStatus) throws Exception; 
    
    public WarningInfoVo findWarningInfoObj(int warningHeaderId,int warningInfoId, String warningType) throws Exception;
    
    public int findWarningIdForGenTrigger(int cif, int currentWarningHeaderId) throws Exception;
    
   // public void resetStatusWhenNewQuestionVersion(int cif, int warningHeaderId, int warningId ,  String warningTypeCode , UserData user)throws Exception;
    public String[] findChangeRiskLevel(int warningHeaderId) throws Exception;
    
    public void genForCombineForm(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user, String version, String warningType) throws Exception;
    
    public List<WarningInfoVo> findFormConbineWithinHeader(int warningHeaderId) throws Exception;
    
     public void genTriggerFollowEwsq(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user) throws Exception;
     
    public void genEwsqAndTriggerTemp(int currentWarningHeaderId, int triggerWarningId, UserData user) throws Exception;
    
    public void insertWarningInfo(WarningInfoVo infoVo, UserData user)throws Exception;
    
    public Integer compareEWSQandTrigPay(int currentWarningHeaderId)throws Exception;
    
    public Map<String,Object> calSla(int currentWarningHeaderId , String warningType)throws Exception;
    
    public void resetInfoEWSQ(String cifNo ,int warningHeaderId ,  int ewsqWarningInfoId, String warningType, UserData user) throws Exception; 
    
    public void resetInfoTrigAndPay(String cifNo , int headerId , int trigAndPayWarningId, String warningType, UserData user) throws Exception;
    
    public WarningInfoVo findLastVersionByWarningTypeAndId(String warningType , int warningInfoId ) throws Exception;
    //---------------- Size L --------------------------//
    public WarningInfoVo findWarningInfoObject(int warningHeaderId, String warningType) throws Exception ;
    public void updateStatus(WarningInfoVo warningInfoVo) throws Exception;//Add By pound
    public WarningInfoVo getWarningIdAndStatus(WarningInfoVo warningInfoVo) throws Exception;//Add By pound
    public void updateStatusForWayOut(WarningInfoVo warningInfoVo) throws Exception;//Add By pound
    public int getMinWarningId(WarningInfoVo warningInfoVo) throws Exception;
    public void updateConfirmLatepayment(String confirmLatePayment, String bcmConfirmLatePayment, String warningId) throws Exception;
    public int insertLatePaymentPopup(UserData userData, int warningHeaderId, String version, String questionId) throws Exception;
    public Integer findMaxWarningId(int warningHeaderId, String warningType) throws Exception;
    public Integer cntLatePay(int warningHeaderId, String warningType) throws Exception;
    public WarningInfoVo findWarningInfoObjectByMaxWarningInfo(int warningHeaderId, String warningType) throws Exception ;
}
