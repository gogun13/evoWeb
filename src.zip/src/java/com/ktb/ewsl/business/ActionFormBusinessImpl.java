/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionAccountService;
import com.ktb.ewsl.services.CRCustReviewEwsServices;
import com.ktb.ewsl.services.RptIndividualAccountService;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.vo.ActionAccountVo;
import com.ktb.ewsl.vo.RptIndividualAccountVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class ActionFormBusinessImpl extends AbstractBusiness implements  ActionFormBusiness{
    
    private static Logger logger = Logger.getLogger(ActionFormBusinessImpl.class);

    @Autowired
    private ActionAccountService actionAccountService;
    @Autowired
    private RptIndividualAccountService rptIndividualAccountService;
    @Autowired
    private CRCustReviewEwsServices crCustReviewEwsServices;

    @Override
    public List<ActionAccountVo> getActionAccountList(String warningHeadId, String warningId, String cif, boolean insertFlag, String infoStatus, UserData userData) throws Exception {
        logger.debug("[getActionAccountList][Begin]");
        
        List<ActionAccountVo>           actionAccountList           = null;
        List<RptIndividualAccountVo>    rptIndividualAccountList    = null;
        RptIndividualAccountVo          rptIndividualAccountVo      = null;
        ActionAccountVo                 actionAccountVo             = null;
        int                             seq                         = 0;
        
        try{
            
            logger.debug("[getActionAccountList] warningHeadId   :: " + warningHeadId);
            logger.debug("[getActionAccountList] warningId       :: " + warningId);
            logger.debug("[getActionAccountList] cif             :: " + cif);
            logger.debug("[getActionAccountList] infoStatus      :: " + infoStatus);
            logger.debug("[getActionAccountList] roleId          :: " + userData.getRoleId());
            
            if ((EWSConstantValue.ROLE_ACTION_FORM.contains(userData.getRoleId()) || BusinessConst.UserRole.BCM.equals(userData.getRoleId()))
                    && !BusinessConst.Flag.COMPLETE.equals(infoStatus)){
                
                rptIndividualAccountVo = new RptIndividualAccountVo();
                rptIndividualAccountVo.setCif(cif);

                rptIndividualAccountList = rptIndividualAccountService.getRptIndividualAccountList(rptIndividualAccountVo);
                actionAccountList        = new ArrayList<ActionAccountVo>();
                insertFlag               = true;//insert new record

                for(RptIndividualAccountVo vo:rptIndividualAccountList){
                    actionAccountVo = new ActionAccountVo();

                    actionAccountVo.setAccountNo(vo.getAccountNo());
                    actionAccountVo.setBillNo(vo.getBillNo());
                    actionAccountVo.setLimitAmt(vo.getLimitAmt());
                    actionAccountVo.setOutstandingAmt(vo.getOutstandingAmt());
                    actionAccountVo.setMaturityDate(vo.getMaturityDate());
                    actionAccountVo.setDueDate(vo.getDueDate());
                    actionAccountVo.setDpd(vo.getDpd());
                    actionAccountVo.setDueAmt(vo.getDueAmt());
                    actionAccountVo.setUnpaidAmt(vo.getUnpaidAmt());
                    actionAccountVo.setUnpaidInterest(vo.getUnpaidInterest());
                    actionAccountVo.setUnpaidPrincipal(vo.getUnpaidPrincipal());
                    actionAccountVo.setLateCharge(vo.getLateCharge());
                    actionAccountVo.setAccountSubType(vo.getAccountSubType());
                    actionAccountVo.setProductGroup(vo.getProductGroup());
                    actionAccountVo.setProductType(vo.getProductType());
                    actionAccountVo.setLoanType(vo.getLoanType());
                    actionAccountVo.setLoanGrpProd( getLoanGrpProd( vo.getProductGroup() , vo.getProductType(), vo.getAccountSubType(), vo.getLoanType() ));
                    actionAccountVo.setcFinal(vo.getcFinal());
                    actionAccountVo.setDpdZeroDate(vo.getDpdZeroDate());
                    actionAccountVo.setInputAccountNo(vo.getInputAccountNo());
                    actionAccountVo.setInputBillNo(vo.getInputBillNo());
                    actionAccountVo.setIsClosed(vo.getIsClosed());
                    actionAccountVo.setOdOverLimit(vo.getOdOverLimit());
                    actionAccountVo.setPaidDate(vo.getPaidDate());
                    actionAccountVo.setSourceSystem(vo.getSourceSystem());
                    actionAccountVo.setWarningHeadId(warningHeadId);
                    actionAccountVo.setWarningId(warningId);
                    actionAccountVo.setActionFlg("N");
                    actionAccountVo.setSeqTemp(String.valueOf(++seq));

                    actionAccountList.add(actionAccountVo);
                }
            }else{
                actionAccountList = actionAccountService.getActionAccountList(warningHeadId, warningId);
                insertFlag        = false;//update record
                
                for(ActionAccountVo voDb:actionAccountList){
                    voDb.setSeqTemp(String.valueOf(++seq));
                    voDb.setLoanGrpProd( getLoanGrpProd( voDb.getProductGroup() , voDb.getProductType(), voDb.getAccountSubType(), voDb.getLoanType() ));
                }
            }
            
//            actionAccountList = actionAccountService.getActionAccountList(warningHeadId, warningId);
//            
//            if(actionAccountList==null || actionAccountList.isEmpty()){
//                rptIndividualAccountVo = new RptIndividualAccountVo();
//                rptIndividualAccountVo.setCif(cif);
//                
//                rptIndividualAccountList = rptIndividualAccountService.getRptIndividualAccountList(rptIndividualAccountVo);
//                actionAccountList        = new ArrayList<ActionAccountVo>();
//                insertFlag               = true;//insert new record
//                
//                for(RptIndividualAccountVo vo:rptIndividualAccountList){
//                    actionAccountVo = new ActionAccountVo();
//                    
//                    actionAccountVo.setAccountNo(vo.getAccountNo());
//                    actionAccountVo.setBillNo(vo.getBillNo());
//                    actionAccountVo.setLimitAmt(vo.getLimitAmt());
//                    actionAccountVo.setOutstandingAmt(vo.getOutstandingAmt());
//                    actionAccountVo.setMaturityDate(vo.getMaturityDate());
//                    actionAccountVo.setDueDate(vo.getDueDate());
//                    actionAccountVo.setDpd(vo.getDpd());
//                    actionAccountVo.setDueAmt(vo.getDueAmt());
//                    actionAccountVo.setUnpaidAmt(vo.getUnpaidAmt());
//                    actionAccountVo.setUnpaidInterest(vo.getUnpaidInterest());
//                    actionAccountVo.setUnpaidPrincipal(vo.getUnpaidPrincipal());
//                    actionAccountVo.setLateCharge(vo.getLateCharge());
//                    actionAccountVo.setAccountSubType(vo.getAccountSubType());
//                    actionAccountVo.setProductGroup(vo.getProductGroup());
//                    actionAccountVo.setProductType(vo.getProductType());
//                    actionAccountVo.setLoanType(vo.getLoanType());
//                    actionAccountVo.setLoanGrpProd( getLoanGrpProd( vo.getProductGroup() , vo.getProductType(), vo.getAccountSubType(), vo.getLoanType() ));
//                    actionAccountVo.setcFinal(vo.getcFinal());
//                    actionAccountVo.setDpdZeroDate(vo.getDpdZeroDate());
//                    actionAccountVo.setInputAccountNo(vo.getInputAccountNo());
//                    actionAccountVo.setInputBillNo(vo.getInputBillNo());
//                    actionAccountVo.setIsClosed(vo.getIsClosed());
//                    actionAccountVo.setOdOverLimit(vo.getOdOverLimit());
//                    actionAccountVo.setPaidDate(vo.getPaidDate());
//                    actionAccountVo.setSourceSystem(vo.getSourceSystem());
//                    actionAccountVo.setWarningHeadId(warningHeadId);
//                    actionAccountVo.setWarningId(warningId);
//                    actionAccountVo.setActionFlg("N");
//                    actionAccountVo.setSeqTemp(String.valueOf(++seq));
//                    
//                    actionAccountList.add(actionAccountVo);
//                }
//                
//            }else{
//                insertFlag               = false;//update record
//                
//                for(ActionAccountVo voDb:actionAccountList){
//                    voDb.setSeqTemp(String.valueOf(++seq));
//                    voDb.setLoanGrpProd( getLoanGrpProd( voDb.getProductGroup() , voDb.getProductType(), voDb.getAccountSubType(), voDb.getLoanType() ));
//                }
//            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[getActionAccountList][End]");
        }
        
        return actionAccountList;
    }
    
    public String getLoanGrpProd(String prodGroup, String prodType, String acctSubType, String marketCode) throws Exception {
        String loanGrpProd = null;
        
        try{
            if ("00064".equals(acctSubType)) {
                loanGrpProd = "Trade Finance";
            } else {
                if (StringUtil.isNotEmpty(marketCode)) {
                    if(marketCode.equals("9999")){
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType, marketCode);
                    }else{
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(marketCode);
                    }
                } else {
                    if (StringUtil.isNotEmpty(prodGroup) && StringUtil.isNotEmpty(acctSubType) && !"00000".equals(acctSubType)) {
                         loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType);
                    } else if ("1001".equals(prodType)) {
                        loanGrpProd = "O/D";
                    }
                }
            }
        }catch(Exception e){
            throw e;
        }
        
        return loanGrpProd;
    }
    
    @Override
    public void insertOrUpdateActionAccount(List<ActionAccountVo> actionAccountList, String warningHeaderId, String warningId, UserData user) throws Exception {
        logger.debug("[insertOrUpdateActionAccount][Begin]");
        
//        ArrayList<ActionAccountVo> actionAccountListDb = null;
        
        try{
            actionAccountService.deleteByWarningHeadIdAndWarningId(Integer.parseInt(warningHeaderId), Integer.parseInt(warningId));
            for(ActionAccountVo vo:actionAccountList){
                vo.setCreatedBy(user.getEmpNo());
                vo.setUpdatedBy(user.getEmpNo());

                actionAccountService.insert(vo);
            }
            
//            actionAccountListDb = actionAccountService.getActionAccountList(warningHeaderId, warningId);
//            
//            if(actionAccountListDb==null || actionAccountListDb.isEmpty()){
//                for(ActionAccountVo vo:actionAccountList){
//                    vo.setCreatedBy(user.getEmpNo());
//                    vo.setUpdatedBy(user.getEmpNo());
//                    
//                    actionAccountService.insert(vo);
//                }
//                
//            }else{
//                for(ActionAccountVo vo:actionAccountList){
//                    vo.setUpdatedBy(user.getEmpNo());
//                    
//                    actionAccountService.updateActionFlag(vo);
//                }
//            }
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.debug("[insertOrUpdateActionAccount][End]");
        }
    }
          
        
}
