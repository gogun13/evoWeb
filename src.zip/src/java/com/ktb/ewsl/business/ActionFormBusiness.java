/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ActionAccountVo;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author Pratya
 */
public interface ActionFormBusiness {
    
    public List<ActionAccountVo> getActionAccountList(String warningHeadId, String warningId,  String cif, boolean insertFlag, String infoStatus, UserData userData) throws Exception;
    public void insertOrUpdateActionAccount(List<ActionAccountVo> actionAccountList, String warningHeaderId, String warningId, UserData user) throws Exception;
    
}
