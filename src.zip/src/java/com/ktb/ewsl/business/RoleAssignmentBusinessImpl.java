/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.RoleAssignmentService;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.UserVo;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import static com.ktbcs.core.utilities.DateUtil.DEFAULT_DATE_FORMAT;
import static com.ktbcs.core.utilities.DateUtil.parseThai;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTB_User
 */
@Service
public class RoleAssignmentBusinessImpl implements RoleAssignmentBusiness {
    private static final Logger log = Logger.getLogger(RoleAssignmentBusinessImpl.class);
    
    @Autowired
    private RoleAssignmentService roleAssignmentService;
    
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    
    @Override 
    public String getRoleCodeDesc(String isConfig, String roleCode) throws Exception {
        return roleAssignmentService.getRoleCodeDesc(isConfig, roleCode);
    }
    
    @Override
    public List<DropdownVo> getRoleList(String isConfig) throws Exception {
        List<DropdownVo> dropdownList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.getRoleList");                             
                log.info("RoleAssignmentBusinessImpl.getRoleList isConfig="+isConfig);  
            }            
            dropdownList = roleAssignmentService.getRoleList(isConfig);
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.getRoleList : " + e.getMessage(), e);
        }
        return dropdownList;
    }
        
    @Override
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        try {
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeList");
            }                        
            
            if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNameThai()))){//Case ตอนค้นหาที่หน้าจอ เอาชื่อวิ่งไปที่ TB ก่อน ได้รหัสมา จากนั้นเอารหัสกลับมาวิ่งหาข้อมูลใน TBL_MT_ROLE_PRIVILEGE
//                String WHERE = " AND (A.EMP_NAME_THAI LIKE '%"+searchBean.getUser().getEmpNameThai()+"%' OR ";                
//                      WHERE += " A.EMP_SURNAME_THAI LIKE '%"+searchBean.getUser().getEmpNameThai()+"%')";
                
                String WHERE = "AND (A.EMP_NAME_THAI||' '|| A.EMP_SURNAME_THAI LIKE '%"+searchBean.getUser().getEmpNameThai()+"%')";
                
                List<UserVo> userTbIdList = roleAssignmentService.getUserTBList(WHERE);
                String employeeId = "'XXX01'";                                                
                for(UserVo tbVo:userTbIdList){
                    log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeList EmpNo="+tbVo.getEmpNo());
                    //log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeList FirstName="+tbVo.getEmpFirstName());
                    //log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeList FullName="+tbVo.getEmpFullName());    
                    employeeId += ",'"+tbVo.getEmpNo()+"'";    
                }
                log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeList employeeId="+employeeId);                 
                searchBean.setByFirstName(employeeId);                
            }else{
                searchBean.setByFirstName("");
            }                                            
            paginate = roleAssignmentService.getUserMtRolePrivilegeList(paginate, searchBean, pageAmt);
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.getUserMtRolePrivilegeList : " + e.getMessage(), e);
        }
        return paginate;
    }
    
    @Override
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeHistoryList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        try {
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeHistoryList");
            }
            if(!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNameThai()))){//Case ตอนค้นหาที่หน้าจอ เอาชื่อวิ่งไปที่ TB ก่อน ได้รหัสมา จากนั้นเอารหัสกลับมาวิ่งหาข้อมูลใน TBL_MT_ROLE_PRIVILEGE
//                String WHERE = " AND (A.EMP_NAME_THAI LIKE '%"+searchBean.getUser().getEmpNameThai()+"%' OR ";
//                      WHERE += " A.EMP_SURNAME_THAI LIKE '%"+searchBean.getUser().getEmpNameThai()+"%')";
                
                String WHERE = "AND (A.EMP_NAME_THAI||' '|| A.EMP_SURNAME_THAI LIKE '%"+searchBean.getUser().getEmpNameThai()+"%')";
                
                List<UserVo> userTbIdList = roleAssignmentService.getUserTBList(WHERE);
                String employeeId = "'XXX01'";                                                
                for(UserVo tbVo:userTbIdList){
                    log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeHistoryList EmpNo="+tbVo.getEmpNo()); 
                    employeeId += ",'"+tbVo.getEmpNo()+"'";    
                }
                log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeHistoryList employeeId="+employeeId);                 
                searchBean.setByFirstName(employeeId);                
            }else{
                searchBean.setByFirstName("");
            }                        
            paginate = roleAssignmentService.getUserMtRolePrivilegeHistoryList(paginate, searchBean, pageAmt);
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.getUserMtRolePrivilegeHistoryList : " + e.getMessage(), e);
        }
        return paginate;
    }
    
    @Override 
    public PaginatedListImpl<UserVo> getUserTBList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        try {
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.getUserTBList");
            }                        
            paginate = roleAssignmentService.getUserTBList(paginate, searchBean, pageAmt);
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.getUserTBList : " + e.getMessage(), e);
        }
        return paginate;
    }
    
    @Override 
    public PaginatedListImpl<UserVo> getDepartmentList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        return roleAssignmentService.getDepartmentList(paginate, searchBean, pageAmt);
    }
        
    @Override
    public int save(SearchBean searchBean, UserData userData) throws Exception {
        int result = 0;
        try {
            UserVo userVo = new UserVo();
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.save");
                log.info("EmpNo : " + searchBean.getUser().getEmpNo());
            }
            Date sysdate = DateUtil.getCurrentDateTime();
            userVo.setEmpNo(StringUtil.getValue(searchBean.getUser().getEmpNo()));
            userVo.setEmpFullName(StringUtil.getValue(searchBean.getUser().getEmpNameThai()));
            userVo.setRoleId(StringUtil.getValue(searchBean.getRoleId()));
            userVo.setCreatedDate(sysdate);
            userVo.setCreatedBy(StringUtil.getValue(userData.getEmpNo()));                                             
            userVo.setEndDate((searchBean.getToDate().equals("")) ? null :  parseThai(searchBean.getToDate(), DEFAULT_DATE_FORMAT));            
            userVo.setIsActive(StringUtil.getValue(searchBean.getStatus()));
            userVo.setDeptCd(searchBean.getUser().getDeptCode()==null ? "" : searchBean.getUser().getDeptCode());
            userVo.setDeptName(searchBean.getUser().getDeptName()==null ? "" : searchBean.getUser().getDeptName());
            
            if("".equals(ktbEmpDirectoryBusiness.searchEmpNameById(StringUtil.getValue(searchBean.getUser().getEmpNo())))){
                return -2;
            }else if(roleAssignmentService.validateSave(userVo)==0){
                String where = " AND A.EMP_NO = '"+userVo.getEmpNo()+"' AND A.DEPT_CODE = '"+userVo.getDeptCd()+"'";
                List<UserVo> list = roleAssignmentService.getUserTBList(where);                
                if(list.isEmpty()){
                    userVo.setCreatedBy("System");
                    userVo.setIsActive("0");
                }                                                                
                result = roleAssignmentService.saveUserMtRolePrivilege(userVo);
                int resultHis = roleAssignmentService.saveUserMtRolePrivilegeHistory(userVo, "", sysdate);
                log.info("RoleAssignmentBusinessImpl.save resultHis="+resultHis);
            }else
                return -1;
             
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.save : " + e.getMessage(), e);
        }
        return result;
    }
    
    @Override
    public int validateUpdate(String empNo, String roleCode, String deptCode) throws Exception{        
        return roleAssignmentService.validateUpdate(empNo, roleCode, deptCode);
    }
    
    @Override
    public int updateUserMtRolePrivilege(SearchBean searchBean, UserData userData, String oldRoleCode, String oldDeptCode) throws Exception {
        int result = 0;
        try {
            UserVo userVo = new UserVo();
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.updateUserMtRolePrivilege");
                log.info("EmpNo : " + searchBean.getUser().getEmpNo());
                log.info("RoleCode : " + searchBean.getRoleId());
                log.info("DeptCode : " + searchBean.getUser().getDeptCode());                
                log.info("oldRoleCode : " + oldRoleCode);
                log.info("oldDeptCode : " + oldDeptCode);
            }      
            
            Date sysdate = DateUtil.getCurrentDateTime();
            userVo.setEmpNo(StringUtil.getValue(searchBean.getUser().getEmpNo()));
            userVo.setEmpFullName(StringUtil.getValue(searchBean.getUser().getEmpNameThai()));
            userVo.setRoleId(StringUtil.getValue(searchBean.getRoleId()));                                    
            userVo.setEndDate((searchBean.getToDate().equals("")) ? null :  parseThai(searchBean.getToDate(), DEFAULT_DATE_FORMAT));            
            userVo.setIsActive(StringUtil.getValue(searchBean.getStatus()));
            userVo.setUpdatedBy(userData.getEmpNo());
            userVo.setUpdatedDate(sysdate);
            userVo.setDeptCd(StringUtil.getValue(searchBean.getUser().getDeptCode()));
            userVo.setDeptName(StringUtil.getValue(searchBean.getUser().getDeptName()));                        
            String where = " AND A.EMP_NO = '"+userVo.getEmpNo()+"' ";
            List<UserVo> list = roleAssignmentService.getUserTBList(where);    
             if(!list.isEmpty() && "1".equals(StringUtil.getValue(searchBean.getStatus()))){
                    UserVo userVoTB = (UserVo)list.get(0);
                    userVo.setDeptCd(userVoTB.getDeptCd());
                    userVo.setDeptName(userVoTB.getDeptName());   
             }
             /* OLD CODE Check DeptCode 25/05/2017
              * String where = " AND A.EMP_NO = '"+userVo.getEmpNo()+"' AND A.DEPT_CODE = '"+userVo.getDeptCd()+"'";
               List<UserVo> list = roleAssignmentService.getUserTBList(where);                
                if(list.isEmpty()){
                    userVo.setIsActive("0");
                    userVo.setUpdatedBy("System");
                } */                       
            result = roleAssignmentService.updateUserMtRolePrivilege(userVo, oldRoleCode, oldDeptCode);
            searchBean.getUser().setRoleId(StringUtil.getValue(searchBean.getRoleId()));
            UserVo vo = roleAssignmentService.getUserMtRolePrivilegeSaveHistory(searchBean);                                   
            userVo.setCreatedDate(sysdate);
            userVo.setCreatedBy(vo.getCreatedBy());
            userVo.setDeptCd(vo.getDeptCd()==null ? "" : vo.getDeptCd());
            userVo.setDeptName(vo.getDeptName()==null ? "" : vo.getDeptName());            

            int resultHis = roleAssignmentService.saveUserMtRolePrivilegeHistory(userVo, "UPDATE", vo.getCreatedDateTs());
            log.info("RoleAssignmentBusinessImpl.updateUserMtRolePrivilege resultHis="+resultHis);                                                          
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.updateUserMtRolePrivilege : " + e.getMessage(), e);
        }
        return result;
    }
    
    //CASE 1:รายการใดๆ ก็ตามที่มี TBL_MT_ROLE_PRIVILEGE.END_DATE "วันที่สิ้นสุดการใช้งาน" น้อยกว่า sysdate ให้อัพเดทข้อมูล
    private void updateByEnddate() throws Exception {            
        //Step 1: SELECT FROM TBL_MT_ROLE_PRIVILEGE WHERE IS_ACTIVE = 1 AND END_DATE < SYSDATE
        String WHERE = "AND IS_ACTIVE = 1 AND END_DATE < current_date ";
             WHERE += " AND ROLE_CODE IN (SELECT ROLE_CODE FROM TBL_MT_ROLE WHERE IS_CONFIG = '"+BusinessConst.Flag.Y+"')";                        
        List<UserVo> userVoList = roleAssignmentService.getUserMtRolePrivilegeList(WHERE);
        Date sysdate = DateUtil.getCurrentDateTime();
        for (UserVo vo : userVoList) {
            //Step 2: วนลูป Update TBL_MT_ROLE_PRIVILEGE By TBL_MT_ROLE_PRIVILEGE.EMPLOYEE_ID                                
            vo.setIsActive("0");
            vo.setUpdatedDate(sysdate);
            vo.setUpdatedBy("System");
            int update = roleAssignmentService.updateUserMtRolePrivilegeBySearch(vo);
            log.info("RoleAssignmentBusinessImpl.updateByEnddate update=" + update);

            //Step 3: วนลูป Insert TBL_MT_ROLE_PRIVILEGE_HISTORY
            SearchBean searchBean = new SearchBean();
            UserData user = new UserData();
            user.setEmpNo(vo.getEmpNo());
            user.setRoleId(vo.getRoleId());
            searchBean.setUser(user);            
            UserVo hisVo = roleAssignmentService.getUserMtRolePrivilegeSaveHistory(searchBean);                                   
            vo.setCreatedDate(sysdate);
            vo.setCreatedBy(hisVo.getCreatedBy());                        
            vo.setUpdatedDate(sysdate);
            vo.setUpdatedBy("System");
            int resultHis = roleAssignmentService.saveUserMtRolePrivilegeHistory(vo, "UPDATE", hisVo.getCreatedDateTs());
            log.info("RoleAssignmentBusinessImpl.updateByEnddate resultHis=" + resultHis);
        }        
    }
    
    //CASE 2:คือรายการใดๆ ก็ตามที่มี TBL_MT_ROLE_PRIVILEGE.DEPT_CODE != USER_DETAIL.DEPT_CODE เมื่อ DeptCode ต่างกัน แสดงว่ามีการเปลี่ยนหน่วยงาน
    private void updateByDeptCode() throws Exception {
        log.info("RoleAssignmentBusinessImpl.updateByDeptCode Start");
        //Step 1: SELECT FROM TBL_MT_ROLE_PRIVILEGE WHERE IS_ACTIVE = 1
        String WHERE = " AND IS_ACTIVE = 1 ";
              WHERE += " AND ROLE_CODE IN (SELECT ROLE_CODE FROM TBL_MT_ROLE WHERE IS_CONFIG = '"+BusinessConst.Flag.Y+"')";
        List<UserVo> userVoList = roleAssignmentService.getUserMtRolePrivilegeList(WHERE);
        
        //Step 2: หาขอ้มูลรหัสหน่วยงานของ EMPLOYEE_ID ใน Telephone Book 
        String employeeId = "'XXX01'";
        for(UserVo user:userVoList){                      
            //log.info("TBL_MT_ROLE_PRIVILEGE EMPLOYEE_ID="+user.getEmpNo()+", DEPT_CODE="+user.getDeptCd());
            employeeId += ",'"+user.getEmpNo()+"'";            
        }
        WHERE = " AND A.EMP_NO IN ("+employeeId+")";
        
        List<UserVo> userTbList = roleAssignmentService.getUserTBList(WHERE);
        Date sysdate = DateUtil.getCurrentDateTime();
        for(UserVo tb:userTbList){
            for(UserVo userVo:userVoList){                
                if(tb.getEmpNo().equals(userVo.getEmpNo()) && (!tb.getDeptCd().equals(userVo.getDeptCd()) || !"A".equals(tb.getEmployedStatus()))){
                    log.info("tb.EmpNo="+tb.getEmpNo()+", user.EmpNo="+userVo.getEmpNo());           
                    log.info("tb.getDeptCd="+tb.getDeptCd()+", user.getDeptCd="+userVo.getDeptCd());                                        
                    //Step 3: วนลูป Update TBL_MT_ROLE_PRIVILEGE By TBL_MT_ROLE_PRIVILEGE.EMPLOYEE_ID                                
                    userVo.setIsActive("0");
                    userVo.setUpdatedBy("System");
                    userVo.setUpdatedDate(sysdate);
                    int update = roleAssignmentService.updateUserMtRolePrivilegeBySearch(userVo);
                    log.info("RoleAssignmentBusinessImpl.updateByDeptCode update=" + update);

                    //Step 4: วนลูป Insert TBL_MT_ROLE_PRIVILEGE_HISTORY      
                    SearchBean searchBean = new SearchBean();
                    UserData data = new UserData(); 
                    data.setEmpNo(userVo.getEmpNo());
                    data.setRoleId(userVo.getRoleId());
                    searchBean.setUser(data);      
                    UserVo hisVo = roleAssignmentService.getUserMtRolePrivilegeSaveHistory(searchBean);                                   
                    userVo.setCreatedDate(sysdate);
                    userVo.setCreatedBy(hisVo.getCreatedBy());                                            
                    userVo.setUpdatedDate(sysdate);
                    userVo.setUpdatedBy("System");
                    int resultHis = roleAssignmentService.saveUserMtRolePrivilegeHistory(userVo, "UPDATE", hisVo.getCreatedDateTs());
                    log.info("RoleAssignmentBusinessImpl.updateByDeptCode resultHis=" + resultHis);                                        
                    break;
                }                
            }            
        }        
        log.info("RoleAssignmentBusinessImpl.updateByDeptCode Finish");
    }
    
    @Override
    public void updateUserMtRolePrivilegeBySearch() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("RoleAssignmentBusinessImpl.updateUserMtRolePrivilegeBySearch Start");
        }
        updateByEnddate();
        updateByDeptCode();                                 
        if (log.isInfoEnabled()) {
            log.info("RoleAssignmentBusinessImpl.updateUserMtRolePrivilegeBySearch Finish");
        } 
    }
    
    //ปุ่ม "Update ข้อมูล User"
    @Override
    public void updateUser(UserVo userVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("RoleAssignmentBusinessImpl.updateUser Start");
        }
        
        //Case:1 Update TBL_MT_ROLE_PRIVILEGE SET IS_ACTIVE = 1 WHERE IS_ACTIVE IS NULL
        int update = roleAssignmentService.updateIsActive(userVo);
        log.info("RoleAssignmentBusinessImpl.updateUser update="+update);
        
        //Case:2 Update TBL_MT_ROLE_PRIVILEGE รายการใดที่มี DEPT_CODE และ DEPT_NAME เป็น null ให้ไปหา DEPT_CODE และ DEPT_NAME จาก TB มา UPDATE ให้                  
        //Step:1 หา Dept_Code หรือ Dept_Name ที่เป็น Null ได้ List ของ EMPLOYEE_ID ออกมา
        String WHERE = "AND DEPT_CODE IS NULL ";
        List<UserVo> userVoList = roleAssignmentService.getUserMtRolePrivilegeList(WHERE);
        
        //Step:2 for loop
        for(UserVo vo:userVoList){
            //2.1 วิ่งไปหา TB โดยใช้ Key EMPLOYEE_ID ได้ Dept_Code และ Dept_Name กลับมา
            WHERE = " AND A.EMP_NO = '"+vo.getEmpNo()+"'";
            List<UserVo> userTbList = roleAssignmentService.getUserTBList(WHERE);
            
            if(userTbList.size()>0){
            //2.2 Update TBL_MT_ROLE_PRIVILEGE Set Dept_Code = ?, Dept_Name = ? By EmpNo 
                log.info("RoleAssignmentBusinessImpl.updateUser EmpNo="+userTbList.get(0).getEmpNo()+", DeptCd="+userTbList.get(0).getDeptCd());                          
                //log.info("RoleAssignmentBusinessImpl.updateUser DeptName="+userTbList.get(0).getDeptName());
                vo.setEmpNo(userTbList.get(0).getEmpNo());
                vo.setDeptCd(userTbList.get(0).getDeptCd());
                vo.setDeptDesc(userTbList.get(0).getDeptName());
                int result = roleAssignmentService.updateDeptCodeByEmployeeId(vo);
                log.info("RoleAssignmentBusinessImpl.updateUser result="+result);
            }            
        }
                                               
        if (log.isInfoEnabled()) {
            log.info("RoleAssignmentBusinessImpl.updateUser Finish");
        } 
    }
    
    @Override
    public int deleteUserMtRolePrivilege(SearchBean searchBean) throws Exception {
        int result = 0;
        if (log.isInfoEnabled()) {
            log.info("RoleAssignmentBusinessImpl.deleteUserMtRolePrivilege Start");
        }
        UserVo vo = new UserVo();
        vo.setEmpNo(searchBean.getUser().getEmpNo());
        vo.setRoleId(searchBean.getUser().getRoleId());
        vo.setDeptCd(searchBean.getUser().getDeptCode());        
        result = roleAssignmentService.deleteUserMtRolePrivilege(vo);
        if (log.isInfoEnabled()) {
            log.info("RoleAssignmentBusinessImpl.deleteUserMtRolePrivilege Finish");
        }
        return result;
    }    
    
    @Override
    public UserVo getUserMtRolePrivilegeByFilter(SearchBean searchBean) throws Exception {
        UserVo userVo = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("RoleAssignmentBusinessImpl.getUserMtRolePrivilegeByFilter");
                log.info("EmpNo : " + searchBean.getUser().getEmpNo());                
            }            
            userVo = roleAssignmentService.getUserMtRolePrivilegeByFilter(searchBean);
        } catch (Exception e) {
            log.error("Error RoleAssignmentBusinessImpl.getUserMtRolePrivilegeByFilter : " + e.getMessage(), e);
        }
        return userVo;
    }
    
}
