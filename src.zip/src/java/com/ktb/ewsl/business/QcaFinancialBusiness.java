/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.FinancialRatioVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author Kat
 */
public interface QcaFinancialBusiness {
     public FinancialVo getFinancialVO(String appID, String cif)throws Exception;
     public List<FinancialRatioVo> getRatioList(String finTrnId) throws Exception;
     public List<FinancialRatioVo> getRatioList(FinancialVo finVO, List<FinancialRatioVo> ratioDBList);
     public boolean saveFinancial(FinancialVo finVO, UserData userObj);
     public FinancialVo checkHVFin(String cifId);
     public FinancialVo getCurrentQcaFin(String cifId)throws Exception; 
     public FinancialVo getLastFinancialVO(String cif)throws Exception;
     public FinancialVo getFinancialVOByWarningId(String waringId)throws Exception;
     public FinancialVo getFinancialForCalDate(String cif , String warningId)throws Exception;
     public void updateQcaFinInDelayReason(FinancialVo finVO)throws Exception;
}
