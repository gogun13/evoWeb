/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.AccountDetailHistoryService;
import com.ktb.ewsl.services.IndividualODAccountService;
import com.ktb.ewsl.vo.AccountDetailVo;
import com.ktb.ewsl.vo.IndividualForBreakVo;
import com.ktb.ewsl.vo.IndividualODAccountVo;
import com.ktb.ewsl.vo.ReportVO;
import com.ktbcs.core.utilities.DateUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Thanakorn Ch.
 */
@Service
public class AccountDetailHistoryBusinessImpl implements AccountDetailHistoryBusiness {

    private static final Logger log = Logger.getLogger(AccountDetailHistoryBusinessImpl.class);
    @Autowired
    private AccountDetailHistoryService accountDetailHistoryService;
    @Autowired
    private CrAccountDetailBusiness crAccountDetailBusiness;
    @Autowired
    private IndividualODAccountService individualODAccountService;


    @Override
    public List<IndividualForBreakVo> findDataByCifForTrack(Integer cif) throws Exception {
        List<IndividualForBreakVo> individualForBreakVoList = new ArrayList<IndividualForBreakVo>();
        List<AccountDetailVo> accountDetailVoList = accountDetailHistoryService.findDataByCifAndCloseJob(cif);
//        List<AccountDetailVo> accountDetailVoListForCR = getDataForTrackRecordeCR(cif.toString());
        ArrayList<AccountDetailVo> valueList = new ArrayList<AccountDetailVo>();
//        ArrayList<AccountDetailVo> value2List = new ArrayList<AccountDetailVo>();
        IndividualForBreakVo individualForBreakVo;
        for (int i = 0; i < 12; i++) {
            Date dd = DateUtil.nextMonth(new Date(), -i);
            int month = DateUtil.getMonth(dd);
            individualForBreakVo = new IndividualForBreakVo();
            individualForBreakVo.setBreakKey(DateUtil.getThaiMonthShort(month) + DateUtil.getShortYearThaiFormat(dd));
            for (AccountDetailVo accountDetailVo : accountDetailVoList) {
                String wDate = DateUtil.getThaiMonthShort(DateUtil.getMonth(accountDetailVo.getDueDate())) + DateUtil.getShortYearThaiFormat(accountDetailVo.getDueDate());
                if (wDate.equals(individualForBreakVo.getBreakKey())) {
                    valueList.add(accountDetailVo);
                }
                if (accountDetailVo.getLastDpd() != null && accountDetailVo.getLastDpd().trim().length() > 0) {
                    accountDetailVo.setDpd(accountDetailVo.getLastDpd());
                }
                accountDetailVo.setLoanGrpProd(crAccountDetailBusiness.getLoanGrpProd(accountDetailVo.getProdGrp(), accountDetailVo.getProdType(), accountDetailVo.getAcctSubType(), accountDetailVo.getMarketCd()));
            }
            if (!valueList.isEmpty()) {
                individualForBreakVo.setValueList(valueList);
                valueList = new ArrayList<AccountDetailVo>();
            }

            individualForBreakVoList.add(individualForBreakVo);
        }
        return individualForBreakVoList;
    }


    @Override
    public List<IndividualForBreakVo> findDataByCifForTrackODOverLimit(String cif) throws Exception {
        List<IndividualForBreakVo> individualForBreakVoList = new ArrayList<IndividualForBreakVo>();
        List<IndividualODAccountVo> individualODAccountVoVoList = individualODAccountService.getWarningODOverLimit12Month(cif);
        ArrayList<IndividualODAccountVo> valueList = null;// new ArrayList<IndividualODAccountVo>(); //----Fix bug By Ann 15/01/2016
        IndividualForBreakVo individualForBreakVo;
        for (int i = 0; i < 12; i++) {
            Date dd = DateUtil.nextMonth(new Date(), -i);
            int month = DateUtil.getMonth(dd);
            individualForBreakVo = new IndividualForBreakVo();
            individualForBreakVo.setBreakKey(DateUtil.getThaiMonthShort(month) + DateUtil.getShortYearThaiFormat(dd));
            valueList = new ArrayList<IndividualODAccountVo>(); //----Fix bug By Ann 15/01/2016
            for (IndividualODAccountVo individualODAccountVo : individualODAccountVoVoList) {
                String wDate = DateUtil.getThaiMonthShort(DateUtil.getMonth(individualODAccountVo.getDelinqDate())) + DateUtil.getShortYearThaiFormat(individualODAccountVo.getDelinqDate());
                if (wDate.equals(individualForBreakVo.getBreakKey())) {
                    valueList.add(individualODAccountVo);
                }
            }
            if (!valueList.isEmpty()) {
                individualForBreakVo.setValueODList(valueList);
                individualForBreakVo.setValueODListSize(valueList.size()); // pumin:for export excel
            } else {
                individualForBreakVo.setValueODList(valueList);
                individualForBreakVo.setValueODListSize(0); //pumin: for export excel
            }
            individualForBreakVoList.add(individualForBreakVo);
        }
        return individualForBreakVoList;
    }
    
    @Override
    public List<ReportVO> findDataByCifForTrackForReport(Integer cif) throws Exception {

        List<AccountDetailVo> accountDetailVoList = accountDetailHistoryService.findDataByCifAndCloseJob(cif);
        List<ReportVO> valueList = new ArrayList<ReportVO>();
        IndividualForBreakVo individualForBreakVo;
        ReportVO repVo;
        boolean breakFlg;
        boolean foundRecord;
        int idx;

        for (int i = 0; i < 12; i++) {
            Date dd = DateUtil.nextMonth(new Date(), -i);
            int month = DateUtil.getMonth(dd);
            individualForBreakVo = new IndividualForBreakVo();
            individualForBreakVo.setBreakKey(DateUtil.getThaiMonthShort(month) + DateUtil.getShortYearThaiFormat(dd));
            breakFlg = true;
            foundRecord = false;
            idx = 1;
            
            for (AccountDetailVo accountDetailVo : accountDetailVoList) {
                if (accountDetailVo.getLastDpd() != null && accountDetailVo.getLastDpd().trim().length() > 0) {
                    accountDetailVo.setDpd(accountDetailVo.getLastDpd());
                }
                if (accountDetailVo.getProdType() != null && !"".equals(accountDetailVo.getProdType())) {
                    accountDetailVo.setLoanGrpProd(accountDetailVo.getProdType() + " : " + crAccountDetailBusiness.getLoanGrpProd(accountDetailVo.getProdGrp(), accountDetailVo.getProdType(), accountDetailVo.getAcctSubType(), accountDetailVo.getMarketCd()));
                }
                repVo = new ReportVO();
                String wDate = DateUtil.getThaiMonthShort(DateUtil.getMonth(accountDetailVo.getDueDate())) + DateUtil.getShortYearThaiFormat(accountDetailVo.getDueDate());
                if (wDate.equals(individualForBreakVo.getBreakKey())) {
                    repVo.setHasAcctDetail(1);
                    repVo.setAccountDetailVo(accountDetailVo);
                    if (breakFlg) {
                        repVo.setBreakStatus(1);
                        repVo.setBreakKey(individualForBreakVo.getBreakKey());
                        breakFlg = false;
                    } else {
                        repVo.setBreakStatus(0);
                    }
                    repVo.setIndex(idx);
                    valueList.add(repVo);
                    foundRecord = true;
                    idx++;
                }
            }
            if (!foundRecord) {
                repVo = new ReportVO();
                repVo.setBreakStatus(1);
                repVo.setBreakKey(individualForBreakVo.getBreakKey());
                repVo.setHasAcctDetail(0);
                valueList.add(repVo);
            }
        }
        return valueList;
    }
}
