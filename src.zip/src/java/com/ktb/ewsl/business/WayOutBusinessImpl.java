/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WayOutService;
import com.ktb.ewsl.vo.QuestionVo;
import com.ktb.ewsl.vo.WarningWayOutVo;
import com.ktbcs.core.business.AbstractBusiness;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTB_User
 */
@Service
public class WayOutBusinessImpl extends AbstractBusiness implements WayOutBusiness {
    private static final Logger log = Logger.getLogger(WayOutBusinessImpl.class);
    
    @Autowired
    private WayOutService wayOutService;
    
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    
    @Override
    public List<QuestionVo> findQuestionWayOut(QuestionVo filter) throws Exception {
        if(log.isInfoEnabled()){
            log.info("findQuestionWayOut");
        }
        return wayOutService.findQuestionWayOut(filter);
    }
    
    @Override
    public List<QuestionVo> findQuestionWayOutForBCM(QuestionVo filter) throws Exception {
        if(log.isInfoEnabled()){
            log.info("findQuestionWayOutForBCM");
        }
        return wayOutService.findQuestionWayOutForBCM(filter);
    }
    
    //บันทึก
//    @Override
//    public void save(int WARNING_HEAD_ID, String cif, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception {        
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.save Start");
//        }
//        
//        QuestionVo filter = new QuestionVo();
//        filter.setWarningId(warningWayOutList.get(0).getWarningId());
//        wayOutService.DeleteTblWarningWayOutForm(filter);        
//        wayOutService.insertTblWarningWayOutForm(warningWayOutList);                
//       
//        FormStatusControlVo formStatusControlVo = new FormStatusControlVo();        
//        formStatusControlVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
//        formStatusControlVo.setCurrStatus(currStatus);
//        formStatusControlVo.setActionCode(actionCode);
//        String status = wayOutService.findStatusTblFormStatusControl(formStatusControlVo);        
//        log.info("WayOutBusinessImpl.save status="+status);
//                
//        ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
//        actionHistoryVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        actionHistoryVo.setActionBy(userData.getEmpNo());
//        actionHistoryVo.setActionCode(actionCode);
//        actionHistoryVo.setActionDetail("");
//        actionHistoryVo.setStatus(status);
//        actionHistoryVo.setRemark("");
//        wayOutService.insertTblActionHistory(actionHistoryVo);
//                
//        WarningInfoVo warningInfoVo = new WarningInfoVo();
//        warningInfoVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        warningInfoVo.setWarningHeaderId(WARNING_HEAD_ID);
//        warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);                
//        warningInfoVo.setStatus(status);     
//        warningInfoVo.setUpdatedBy(userData.getEmpNo());
//        warningInfoVo.setHolderId(userData.getEmpNo());
//        warningInfoVo.setHolderRole(userData.getRoleId());
//        wayOutService.updateTblWarningInfo(warningInfoVo);     
//                
//        //*ย้ายไปที่ "ส่งงาน" แทน Pong 14.30 23/12/2558
//        /*WarningHeaderVo warningHeaderVo = new WarningHeaderVo();                                              
//        warningHeaderVo.setWayOutFlg(BusinessConst.Flag.INPROCESS);
//        warningHeaderVo.setUpdatedBy(actionBy);
//        warningHeaderVo.setWarningHeaderId(WARNING_HEAD_ID);
//        warningHeaderVo.setCif(cif);
//        wayOutService.updateTblWarningHeader(warningHeaderVo);*/
//                
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.save Finish");
//        }
//    }
//    
//    //ส่งงาน
//    @Override
//    public void send(int WARNING_HEAD_ID, String cif, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception {
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.send Start");
//        }        
//        FormStatusControlVo formStatusControlVo = new FormStatusControlVo();        
//        formStatusControlVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
//        formStatusControlVo.setCurrStatus(currStatus);
//        formStatusControlVo.setActionCode(actionCode);
//        String status = wayOutService.findStatusTblFormStatusControl(formStatusControlVo);        
//        log.info("WayOutBusinessImpl.send status="+status);
//                
//        ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
//        actionHistoryVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        actionHistoryVo.setActionBy(userData.getEmpNo());
//        actionHistoryVo.setActionCode(actionCode);
//        actionHistoryVo.setActionDetail("");
//        actionHistoryVo.setStatus(status);
//        actionHistoryVo.setRemark("");
//        wayOutService.insertTblActionHistory(actionHistoryVo);
//        
//        WarningInfoVo warningInfoVo = new WarningInfoVo();
//        warningInfoVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        warningInfoVo.setWarningHeaderId(WARNING_HEAD_ID);
//        warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);                
//        warningInfoVo.setStatus(status);     
//        warningInfoVo.setUpdatedBy(userData.getEmpNo());
//        warningInfoVo.setHolderId(null);
//        
//        String holderRole = asstQuestionBusiness.getHolderRole(status, "");
//        
//        log.info("WayOutBusinessImpl.send holderRole :: " + holderRole);
//        
//        warningInfoVo.setHolderRole(holderRole);
//        wayOutService.updateTblWarningInfo(warningInfoVo); 
//        
//        WarningHeaderVo warningHeaderVo = new WarningHeaderVo();                                              
//        warningHeaderVo.setWayOutFlg(BusinessConst.Flag.INPROCESS);
//        warningHeaderVo.setUpdatedBy(userData.getEmpNo());
//        warningHeaderVo.setWarningHeaderId(WARNING_HEAD_ID);
//        warningHeaderVo.setCif(cif);
//        wayOutService.updateTblWarningHeader(warningHeaderVo);
//        
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.send Finish");
//        }       
//    }
//    
//    //ส่งกลับแก้ไข
//    @Override
//    public void sendBack(int WARNING_HEAD_ID, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception {
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.sendBack Start");
//        }
//        FormStatusControlVo formStatusControlVo = new FormStatusControlVo();        
//        formStatusControlVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
//        formStatusControlVo.setCurrStatus(currStatus);
//        formStatusControlVo.setActionCode(actionCode);
//        String status = wayOutService.findStatusTblFormStatusControl(formStatusControlVo);        
//        log.info("WayOutBusinessImpl.sendBack status="+status);
//        
//        ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
//        actionHistoryVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        actionHistoryVo.setActionBy(userData.getEmpNo());
//        actionHistoryVo.setActionCode(actionCode);
//        actionHistoryVo.setActionDetail("");
//        actionHistoryVo.setStatus(status);
//        actionHistoryVo.setRemark("");
//        wayOutService.insertTblActionHistory(actionHistoryVo);
//        
//        WarningInfoVo warningInfoVo = new WarningInfoVo();
//        warningInfoVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        warningInfoVo.setWarningHeaderId(WARNING_HEAD_ID);
//        warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);                
//        warningInfoVo.setStatus(status);     
//        warningInfoVo.setUpdatedBy(userData.getEmpNo());
//        warningInfoVo.setHolderId(null);
//        
//        String holderRole = asstQuestionBusiness.getHolderRole(status, "");
//        
//        log.info("WayOutBusinessImpl.sendBack holderRole :: " + holderRole);
//        
//        warningInfoVo.setHolderRole(holderRole);
//        wayOutService.updateTblWarningInfo(warningInfoVo);
//        
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.sendBack Finish");
//        }  
//    }
//    
//    //อนุมัติ
//    @Override
//    public void approve(int WARNING_HEAD_ID, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception {
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.approve Start");
//        }        
//        FormStatusControlVo formStatusControlVo = new FormStatusControlVo();        
//        formStatusControlVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);
//        formStatusControlVo.setCurrStatus(currStatus);
//        formStatusControlVo.setActionCode(actionCode);
//        String status = wayOutService.findStatusTblFormStatusControl(formStatusControlVo);        
//        log.info("WayOutBusinessImpl.approve status="+status);
//        
//        ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
//        actionHistoryVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        actionHistoryVo.setActionBy(userData.getEmpNo());
//        actionHistoryVo.setActionCode(actionCode);
//        actionHistoryVo.setActionDetail("");
//        actionHistoryVo.setStatus(status);
//        actionHistoryVo.setRemark("");
//        wayOutService.insertTblActionHistory(actionHistoryVo);
//        
//        WarningInfoVo warningInfoVo = new WarningInfoVo();
//        warningInfoVo.setWarningId(warningWayOutList.get(0).getWarningId());
//        warningInfoVo.setWarningHeaderId(WARNING_HEAD_ID);
//        warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.WAY_OUT);                
//        warningInfoVo.setStatus(status);     
//        warningInfoVo.setUpdatedBy(userData.getEmpNo());
//        warningInfoVo.setHolderId(null);
//        
//        String holderRole = asstQuestionBusiness.getHolderRole(status, "");
//        
//        log.info("WayOutBusinessImpl.approve holderRole :: " + holderRole);
//        
//        warningInfoVo.setHolderRole(holderRole);
//        wayOutService.updateTblWarningInfo(warningInfoVo);
//        
//        if(log.isInfoEnabled()){
//            log.info("WayOutBusinessImpl.approve Finish");
//        }
//    }

    @Override
    public void saveWayOut(List<WarningWayOutVo> warningWayOutList) throws Exception {
        if(log.isInfoEnabled()){
            log.info("WayOutBusinessImpl.saveWayOut Start");
        }
        
        deleteTblWarningWayOutForm(warningWayOutList.get(0).getWarningId(), warningWayOutList.get(0).getRoleCode());
        
        wayOutService.insertTblWarningWayOutForm(warningWayOutList);      
    }
    
    @Override
    public void deleteTblWarningWayOutForm(int warningId, String roleCode) throws Exception {
        QuestionVo filter = new QuestionVo();
        
        if(log.isInfoEnabled()){
            log.info("[deleteTblWarningWayOutForm] warningId :: " + warningId);
            log.info("[deleteTblWarningWayOutForm] roleCode  :: " + roleCode);
        }
        
        
        filter.setWarningId(warningId);
        filter.setRoleCode(roleCode);
        wayOutService.DeleteTblWarningWayOutForm(filter);   
    }
    
}
