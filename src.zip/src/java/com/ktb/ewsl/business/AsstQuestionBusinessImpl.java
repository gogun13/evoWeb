/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionHistoryService;
import com.ktb.ewsl.services.AsstAnswerService;
import com.ktb.ewsl.services.AsstQuestionService;
import com.ktb.ewsl.services.CustomerService;
import com.ktb.ewsl.services.HolidayService;
import com.ktb.ewsl.services.QcaFinancialService;
import com.ktb.ewsl.services.ReasonRenewalMappingService;
import com.ktb.ewsl.services.RptIndividualRiskLevelService;
import com.ktb.ewsl.services.WarningCompletionService;
import com.ktb.ewsl.services.WarningHeaderService;
import com.ktb.ewsl.services.WarningInfoService;
import com.ktb.ewsl.services.WarningProcessService;
import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.utilities.ThaiCutHelper;
import com.ktbcs.core.utilities.StringUtil;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktb.ewsl.vo.AsstChoiceVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktb.ewsl.vo.ReasonRenewalMappingVo;
import com.ktb.ewsl.vo.RptIndividualRiskLevelVo;
import com.ktb.ewsl.vo.ScoreEngineVo;
import com.ktb.ewsl.vo.WSLogVO;
import com.ktb.ewsl.vo.WarningCompletionVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningProcessVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.exceptions.RenowalException;
import com.ktbcs.core.exceptions.ScoreEngineException;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Tum_Surapong
 */
@Service
public class AsstQuestionBusinessImpl implements AsstQuestionBusiness {

    private static final Logger log = Logger.getLogger(AsstQuestionBusinessImpl.class);
    @Autowired
    private AsstQuestionService asstQuestionService;
    @Autowired
    private AsstAnswerService asstAnswerService;
    @Autowired
    private ActionHistoryService actionHistoryService;
    @Autowired
    private WarningInfoService warningInfoService;
    @Autowired
    private WarningInfoBusiness warningInfoBusiness;
    @Autowired
    private WarningHeaderService warningHeaderService;
    @Autowired
    private WarningTypeService warningTypeService;
    @Autowired
    private ScoreEngineBusiness scoreEngineBusiness;
    @Autowired
    private WarningProcessService warningProcessService;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private QcaFinancialService qcaFinancialService;
    @Autowired
    private HolidayService holidayService;
    @Autowired
    private WarningHeaderBusiness warningHeaderBusiness;
    @Autowired
    private WarningCompletionService warningCompletionService;
    @Autowired
    private RptIndividualRiskLevelService rptIndividualRiskLevelService;
    @Autowired
    private ReasonRenewalMappingService reasonRenewalMappingService;
            
    private int MAX_LENGTH_TOPIC_DESC = 110;//OLD 110
    private int MAX_LENGTH_SUB_TOPIC_DESC = 100;//OLD 135
    private int MAX_LENGTH_CHOICE_DESC = 90;//120;//OLD 120

    /*
     * Original P_TUM
     */
    @Override
    public List<AsstTopicVo> findQuestionByFilter(AsstTopicVo filter) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findQuestionByFilter");
        }

        List<AsstTopicVo> asstTopicVoList;
        if (BusinessConst.WarningTypeCode.TRIGANDPAY.equals(filter.getWarningType())) {          
            asstTopicVoList = new ArrayList<AsstTopicVo>();
            List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.TRIGANDPAY);
            List<String> trigList = new ArrayList<String>();
            if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
                for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                    trigList.add(warningTypeVo.getWarningTypeCode());
                }

                List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoActiveByHeaderAndWarningTypeList(filter.getWarningHeaderId(), trigList,filter.getWarningId());
                for (WarningInfoVo warningInfoVo : warningInfoVoList) {
                    List<AsstTopicVo> topicVoList = asstQuestionService.findTopicByWarningType(warningInfoVo.getWarningType());
                    if (topicVoList != null) {
                        List<Integer> topicIdList = new ArrayList<Integer>();
                        for (AsstTopicVo asstTopicVo : topicVoList) {
                            asstTopicVo.setWarningType(warningInfoVo.getWarningType());
                            asstTopicVo.setTopicDesc(ThaiCutHelper.wordwrap(asstTopicVo.getTopicDesc(), MAX_LENGTH_TOPIC_DESC));
                            topicIdList.add(asstTopicVo.getTopicId());

                            List<AsstSubtopicVo> asstSubtopicVoList = null;//asstQuestionService.findSubtopicByTopic(topicIdList, asstTopicVo.getQuestionId(), asstTopicVo.getVersion(), warningInfoVo.getWarningId(), BusinessConst.UserRole.RM);
                            if (asstSubtopicVoList != null) {
                                List<Integer> subtopicIdList = new ArrayList<Integer>();
                                for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                                    subtopicIdList.add(asstSubtopicVo.getSubTopicId());
                                }
                                List<AsstChoiceVo> asstChoiceVoList = asstQuestionService.findChoiceByFilter(topicIdList, subtopicIdList, asstTopicVo.getQuestionId(), asstTopicVo.getVersion());
                                ArrayList<AsstChoiceVo> asstChoiceList;
                                for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                                    asstSubtopicVo.setSubTopicDesc(ThaiCutHelper.wordwrap(asstSubtopicVo.getSubTopicDesc(), MAX_LENGTH_SUB_TOPIC_DESC));
                                    asstSubtopicVo.setWarningId(warningInfoVo.getWarningId());
                                    asstChoiceList = new ArrayList<AsstChoiceVo>();
                                    for (AsstChoiceVo asstChoiceVo : asstChoiceVoList) {
                                        if (asstSubtopicVo.getQuestionId().equals(asstChoiceVo.getQuestionId()) && asstSubtopicVo.getTopicId() == asstChoiceVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstChoiceVo.getSubTopicId() && asstSubtopicVo.getVersion().equals(asstChoiceVo.getVersion())) {
                                            asstChoiceVo.setChoiceDesc(ThaiCutHelper.wordwrap(asstChoiceVo.getChoiceDesc(), MAX_LENGTH_CHOICE_DESC));
                                            asstChoiceList.add(asstChoiceVo);
                                        }
                                    }
                                    asstSubtopicVo.setAsstChoiceVoList(asstChoiceList);
                                }
                                asstTopicVo.setAsstSubtopicVoList((ArrayList)asstSubtopicVoList);
                            }
                            asstTopicVoList.add(asstTopicVo);
                        }
                    }
                }
            }
        } else {
//        1. find topic by question_id and version
//        2. find subtopic by list of topic and question_id and version
            asstTopicVoList = asstQuestionService.findTopicByQuestion(filter.getQuestionId(), filter.getVersion());
            if (asstTopicVoList != null) {
                List<Integer> topicIdList = new ArrayList<Integer>();
                for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                    asstTopicVo.setWarningType(filter.getWarningType());
                    asstTopicVo.setTopicDesc(ThaiCutHelper.wordwrap(asstTopicVo.getTopicDesc(), MAX_LENGTH_TOPIC_DESC));
                    topicIdList.add(asstTopicVo.getTopicId());
                }

                if (!topicIdList.isEmpty()) {
//                start check warningId case default data form old warningId when current warningId not answer
                    int warningId = filter.getWarningId();
                    boolean checkVersion = false;
                    if (EWSConstantValue.STATUS_DEFAULT_ANSWER.contains(filter.getInfoStatus())) {
                        List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerByWarningIdAndQuestId(filter.getWarningId(), filter.getQuestionId());
                        if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
                            for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                                if (filter.getVersion().equals(asstAnswerVo.getVersion())) {
                                    checkVersion = true;
                                    break;
                                }
                            }
                        }
                        if (asstAnswerVoList == null || asstAnswerVoList.size() <= 0 || !checkVersion) {
                            WarningInfoVo warningInfoVo = new WarningInfoVo();
                            warningInfoVo.setCifNo(filter.getCifNo());
                            warningInfoVo.setWarningType(filter.getWarningType());
                            warningInfoVo.setVersion(filter.getVersion());
                            Integer maxWarningId = warningInfoService.findMaxWarningId(warningInfoVo);
                            if (maxWarningId != null) {
                                warningId = maxWarningId.intValue();
                            }
                        }
                    }
//                end check
                    String role = BusinessConst.UserRole.RM;

                    List<AsstSubtopicVo> asstSubtopicVoList = null;//asstQuestionService.findSubtopicByTopic(topicIdList, filter.getQuestionId(), filter.getVersion(), warningId, role);
                    if (asstSubtopicVoList != null) {
                        List<AsstAnswerVo> answerRM = null;
                        List<AsstAnswerVo> answerCM = null;
//                        if (EWSConstantValue.STATUS_QCA_FINAL_LEVEL1.contains(filter.getInfoStatus())) {
//                            answerRM = asstAnswerService.findAsstAnswerByRole(BusinessConst.UserRole.RM, filter.getVersion(), warningId, filter.getQuestionId());
//                        } else if (EWSConstantValue.STATUS_QCA_FINAL_LEVEL2.contains(filter.getInfoStatus())) {
//                            answerRM = asstAnswerService.findAsstAnswerByRole(BusinessConst.UserRole.RM, filter.getVersion(), warningId, filter.getQuestionId());
//                            answerCM = asstAnswerService.findAsstAnswerByRole(BusinessConst.UserRole.CM, filter.getVersion(), warningId, filter.getQuestionId());
//                        }

                        List<Integer> subtopicIdList = new ArrayList<Integer>();
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                            subtopicIdList.add(asstSubtopicVo.getSubTopicId());

                            if (answerRM != null && answerRM.size() > 0) {
                                for (AsstAnswerVo asstAnswerVo : answerRM) {
                                    if (asstSubtopicVo.getTopicId() == asstAnswerVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstAnswerVo.getSubTopicId()) {
                                        asstSubtopicVo.setAnswerRM(String.valueOf(asstAnswerVo.getChoiceId()));
                                        asstSubtopicVo.setRemarkRM(asstAnswerVo.getRemark());
                                        break;
                                    }
                                }
                            }

                            if (answerCM != null && answerCM.size() > 0) {
                                for (AsstAnswerVo asstAnswerVo : answerCM) {
                                    if (asstSubtopicVo.getTopicId() == asstAnswerVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstAnswerVo.getSubTopicId()) {
                                        asstSubtopicVo.setAnswerCM(String.valueOf(asstAnswerVo.getChoiceId()));
                                        asstSubtopicVo.setRemarkCM(asstAnswerVo.getRemark());
                                        break;
                                    }
                                }
                            }
                        }

                        List<AsstChoiceVo> asstChoiceVoList = asstQuestionService.findChoiceByFilter(topicIdList, subtopicIdList, filter.getQuestionId(), filter.getVersion());
                        ArrayList<AsstChoiceVo> asstChoiceList;
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                            asstSubtopicVo.setSubTopicDesc(ThaiCutHelper.wordwrap(asstSubtopicVo.getSubTopicDesc(), MAX_LENGTH_SUB_TOPIC_DESC));
                            asstChoiceList = new ArrayList<AsstChoiceVo>();
                            for (AsstChoiceVo asstChoiceVo : asstChoiceVoList) {
                                if (asstSubtopicVo.getQuestionId().equals(asstChoiceVo.getQuestionId()) && asstSubtopicVo.getTopicId() == asstChoiceVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstChoiceVo.getSubTopicId() && asstSubtopicVo.getVersion().equals(asstChoiceVo.getVersion())) {
                                    asstChoiceVo.setChoiceDesc(ThaiCutHelper.wordwrap(asstChoiceVo.getChoiceDesc(), MAX_LENGTH_CHOICE_DESC));
                                    asstChoiceList.add(asstChoiceVo);
                                }
                            }
                            asstSubtopicVo.setAsstChoiceVoList(asstChoiceList);
                        }
                    }

                    ArrayList<AsstSubtopicVo> asstSubtopicList;
                    for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                        asstSubtopicList = new ArrayList<AsstSubtopicVo>();
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                            if (asstTopicVo.getQuestionId().equals(asstSubtopicVo.getQuestionId()) && asstTopicVo.getTopicId() == asstSubtopicVo.getTopicId() && asstTopicVo.getVersion().equals(asstSubtopicVo.getVersion())) {
                                asstSubtopicList.add(asstSubtopicVo);
                            }
                        }
                        asstTopicVo.setAsstSubtopicVoList(asstSubtopicList);
                    }
                }
            }
        }
        return asstTopicVoList;
    }
 
    @Override
    public String saveAsstAnswer(List<AsstAnswerVo> asstAnswerVoList, UserData user, String actionMode, String infoStatus, String warningType) throws Exception, RenowalException {
        if (log.isInfoEnabled()) {
            log.info("saveAsstAnswer");
        }
        try{
        if (asstAnswerVoList != null) {
            Map warningInfoMap = new HashMap();
            int warningHeaderId = 0;
            int warningId = 0;
            String cifNo = "";
            String roleCode = "";
            List<String> data = null;
            //---------For Prepare DELETE AO , AE , RM --------//
            if(!BusinessConst.UserRole.BCM.equals(user.getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                  data = new ArrayList<String>();
                  data.add(BusinessConst.UserRole.RM);
                  data.add(BusinessConst.UserRole.AE);
                  data.add(BusinessConst.UserRole.AO);
                  
                  data.add(BusinessConst.UserRole.CO_RM);
                  data.add(BusinessConst.UserRole.CO_AE);
                  data.add(BusinessConst.UserRole.CO_AO);
                  
                  roleCode = StringUtil.genSqlInStr(data);
            }else{
                  data = new ArrayList<String>();
                  data.add(user.getRoleId());
                  roleCode = StringUtil.genSqlInStr(data);
            }
            //--------------------------------------//
            for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                List<AsstAnswerVo> asstAnswerVoListForCheck = null;
                warningId = asstAnswerVo.getWarningId();
                warningHeaderId = asstAnswerVo.getWarningHeaderId();
                cifNo = asstAnswerVo.getCifNo();
                asstAnswerVo.setUpdatedBy(user.getEmpNo());
                asstAnswerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                //--OLD CODE asstAnswerVo.setRole(getRoleForAnswer(user.getRoleId(), infoStatus));
                asstAnswerVo.setRole(user.getRoleId());
                //---------For DELETE AO , AE , RM --------//
                if(!BusinessConst.UserRole.BCM.equals(user.getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                     asstAnswerVoListForCheck = asstAnswerService.findAsstAnswerByPKAndManyRole(asstAnswerVo, roleCode);
                     if(asstAnswerVoListForCheck != null && !asstAnswerVoListForCheck.isEmpty()){
                         if(!ValidatorUtil.isNullOrEmpty(asstAnswerVo.getQuestionId()) && !ValidatorUtil.isNullOrEmpty(asstAnswerVo.getVersion())
                                  && asstAnswerVo.getWarningId() != 0 &&asstAnswerVo.getTopicId() != 0 && asstAnswerVo.getSubTopicId() != 0
                                  && !ValidatorUtil.isNullOrEmpty(roleCode) ){
                             asstAnswerService.deleteAnswerByPK(asstAnswerVo, roleCode);
                         }
                     }
                }
               //--------------------------------------//
                
                asstAnswerVoListForCheck = asstAnswerService.findAsstAnswerByPK(asstAnswerVo);
                
                if (asstAnswerVoListForCheck != null && asstAnswerVoListForCheck.size() > 0) {
                    asstAnswerService.updateQuestion(asstAnswerVo,data);
                } else {
                    asstAnswerVo.setCreatedBy(user.getEmpNo());
                    asstAnswerVo.setCreatedDate(DateUtil.getCurrentDateTime());
                    asstAnswerService.saveQuestion(asstAnswerVo);
                }

                warningInfoMap.put(asstAnswerVo.getWarningId(), asstAnswerVo);
            }
                String statusXxFlag;
                String currentStatusInfo;
                WarningInfoVo warningInfoVo = new WarningInfoVo();
                warningInfoVo.setWarningId(warningId);
                warningInfoVo.setWarningType(warningType);
                warningInfoVo.setUpdatedBy(user.getEmpNo());
                warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                //---Start--  ANN Change 23/06/2015  Case : Add QuestionId and question version
                if (warningInfoMap != null && warningInfoMap.size() > 0) {
                   AsstAnswerVo dataAnswer = (AsstAnswerVo)warningInfoMap.get(warningId);
                   if(dataAnswer != null){
                        warningInfoVo.setAnswerQuestionId(dataAnswer.getQuestionId());
                        warningInfoVo.setAnswerQuestionVersion(dataAnswer.getVersion());
                   }
                }
                //---- END ---//
                if ("Save".equals(actionMode)) {
                    currentStatusInfo = getSeqInfoStatus(infoStatus, warningType, actionMode);
                    warningInfoVo.setStatus(currentStatusInfo);
                    warningInfoVo.setHolderId(null);
                    warningInfoVo.setHolderRole(getHolderRole(currentStatusInfo, "",user.getRoleId()));
                } else {
                    currentStatusInfo = infoStatus;
                    warningInfoVo.setStatus(infoStatus);
                    warningInfoVo.setHolderId(user.getEmpNo());
                    warningInfoVo.setHolderRole(user.getRoleId());
                    if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
                        warningInfoVo.setStatus(BusinessConst.Flag.RMP);
                    } 
                }
                 warningInfoService.updateStatusAndQuestionByWarningIdAndType(warningInfoVo);

                //---- Find DPD -----//
                 log.info("warningHeaderId =" + warningHeaderId + ": cifNo =" + cifNo );
                 WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginal(warningHeaderId, cifNo);
                 
                ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
                actionHistoryVo.setWarningId(warningId);
                actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
                actionHistoryVo.setActionBy(user.getEmpNo());
                actionHistoryVo.setActionCode(actionMode);
                actionHistoryVo.setActionDetail(warningType);
                actionHistoryVo.setStatus(warningInfoVo.getStatus());
                actionHistoryVo.setRoleCode(user.getRoleId());
                if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                  actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
                }else{
                  actionHistoryVo.setDpd(null);
                }
                actionHistoryService.saveData(actionHistoryVo);


           if ("Save".equals(actionMode)) {
                WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setWarningHeaderId(warningHeaderId);
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                statusXxFlag = getXxFlagForHeader(currentStatusInfo, warningType, warningHeaderId);
                if (BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
                    warningHeaderVo.setFinFlg(statusXxFlag);
                } else if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                    warningHeaderVo.setEwsFlag(statusXxFlag);
                    warningHeaderVo.setQualiFlg(statusXxFlag);
                } else if (BusinessConst.WarningTypeCode.LATE_PAY.equals(warningType)) {
                    warningHeaderVo.setLatePayFlg(statusXxFlag);
                }
                warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
                //-------------- UPDATE HEADER STATUS ------------------//
                if (BusinessConst.Flag.INPROCESS.equals(statusXxFlag)) {
                    checkAllXxFlagForUpdateHeaderStatus(warningHeaderId, user.getEmpNo(), BusinessConst.GO_ACTION.NAXT);
                }
              }
                return warningInfoVo.getStatus();
             
            
        }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public void saveAsstAnswerForActionForm2(List<AsstAnswerVo> asstAnswerVoList, UserData user) throws Exception, RenowalException {
        log.info("[saveAsstAnswerForActionForm2][Begin]");
        
        try{
            if (asstAnswerVoList != null) {
                String          roleCode    = "";
                List<String>    data        = null;
                //---------For Prepare DELETE AO , AE , RM --------//
                if(!BusinessConst.UserRole.BCM.equals(user.getRoleId())){
                      data = new ArrayList<String>();
                      data.add(BusinessConst.UserRole.RM);
                      data.add(BusinessConst.UserRole.AE);
                      data.add(BusinessConst.UserRole.AO);
                      roleCode = StringUtil.genSqlInStr(data);
                }else{
                      data = new ArrayList<String>();
                      data.add(user.getRoleId());
                      roleCode = StringUtil.genSqlInStr(data);
                }
                //--------------------------------------//
                for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                    List<AsstAnswerVo> asstAnswerVoListForCheck = null;
                    asstAnswerVo.setUpdatedBy(user.getEmpNo());
                    asstAnswerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    //--OLD CODE asstAnswerVo.setRole(getRoleForAnswer(user.getRoleId(), infoStatus));
                    asstAnswerVo.setRole(user.getRoleId());
                    //---------For DELETE AO , AE , RM --------//
                    if(!BusinessConst.UserRole.BCM.equals(user.getRoleId())){
                         asstAnswerVoListForCheck = asstAnswerService.findAsstAnswerByPKAndManyRole(asstAnswerVo, roleCode);
                         if(asstAnswerVoListForCheck != null && !asstAnswerVoListForCheck.isEmpty()){
                             if(!ValidatorUtil.isNullOrEmpty(asstAnswerVo.getQuestionId()) && !ValidatorUtil.isNullOrEmpty(asstAnswerVo.getVersion())
                                      && asstAnswerVo.getWarningId() != 0 &&asstAnswerVo.getTopicId() != 0 && asstAnswerVo.getSubTopicId() != 0
                                      && !ValidatorUtil.isNullOrEmpty(roleCode) ){
                                 asstAnswerService.deleteAnswerByPK(asstAnswerVo, roleCode);
                             }
                         }
                    }
                   //--------------------------------------//

                    asstAnswerVoListForCheck = asstAnswerService.findAsstAnswerByPK(asstAnswerVo);

                    if (asstAnswerVoListForCheck != null && asstAnswerVoListForCheck.size() > 0) {
                        asstAnswerService.updateQuestion(asstAnswerVo,data);
                    } else {
                        asstAnswerVo.setCreatedBy(user.getEmpNo());
                        asstAnswerVo.setCreatedDate(DateUtil.getCurrentDateTime());
                        asstAnswerService.saveQuestion(asstAnswerVo);
                    }
                }

            }
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[saveAsstAnswerForActionForm2][End]");
        }
    }

//    @Override
//    public void approveFinal(AsstTopicVo asstTopicVo, List<AsstAnswerVo> asstAnswerVoList, UserData user, String actionMode, String infoStatus) throws Exception, RenowalException {
//        if (log.isInfoEnabled()) {
//            log.info("approveFinal");
//        }
//
//        if (asstAnswerVoList != null) {
////            int warningHeaderId;
//            int warningId = 0;
//            String warningType = "";
//            for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
//                warningId = asstAnswerVo.getWarningId();
////                warningHeaderId = asstAnswerVo.getWarningHeaderId();
//                warningType = asstAnswerVo.getWarningType();
//                asstAnswerVo.setUpdatedBy(user.getEmpNo());
//                asstAnswerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
//                asstAnswerVo.setRole(getRoleForAnswer(user.getRoleId(), infoStatus));
//                List<AsstAnswerVo> asstAnswerVoListForCheck = asstAnswerService.findAsstAnswerByPK(asstAnswerVo);
//                if (asstAnswerVoListForCheck != null && asstAnswerVoListForCheck.size() > 0) {
//                    asstAnswerService.updateQuestion(asstAnswerVo);
//                } else {
//                    asstAnswerVo.setCreatedBy(user.getEmpNo());
//                    asstAnswerVo.setCreatedDate(DateUtil.getCurrentDateTime());
//                    asstAnswerService.saveQuestion(asstAnswerVo);
//                }
//            }
//
//            WarningInfoVo warningInfoVo = new WarningInfoVo();
//            warningInfoVo.setWarningId(warningId);
//            warningInfoVo.setWarningType(warningType);
//            warningInfoVo.setUpdatedBy(user.getEmpNo());
//            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
//            String currentWarningInfoStatus = getSeqInfoStatus(infoStatus, warningType, actionMode);
//            warningInfoVo.setStatus(currentWarningInfoStatus);
//            warningInfoVo.setHolderId(null);
//            warningInfoVo.setHolderRole(getHolderRole(currentWarningInfoStatus, BusinessConst.Flag.Y,user.getRoleId()));
//            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);
//
//            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
//            actionHistoryVo.setWarningId(warningId);
//            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
//            actionHistoryVo.setActionBy(user.getEmpNo());
//            actionHistoryVo.setActionCode("Approve");
//            actionHistoryVo.setActionDetail(warningType);
//            actionHistoryVo.setStatus(warningInfoVo.getStatus());
//            actionHistoryVo.setRoleCode(user.getRoleId());
//            actionHistoryService.saveData(actionHistoryVo);
//
//            WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
//            warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
//            warningHeaderVo.setUpdatedBy(user.getEmpNo());
//            warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
//            warningHeaderVo.setQcaFlag(BusinessConst.Flag.COMPLETE);
//
//            String headerStatus = BusinessConst.Flag.INPROCESS;
//            WarningHeaderVo headerVoForCheck =  warningHeaderService.findWarningHeaderObjectOriginal(asstTopicVo.getWarningHeaderId(), asstTopicVo.getCifNo());
//            if (headerVoForCheck != null) {
//                if (warningHeaderBusiness.valueFlagHeaderFlag(headerVoForCheck.getCrFlag()) && warningHeaderBusiness.valueFlagHeaderFlag(headerVoForCheck.getTaFlag())
//                        && warningHeaderBusiness.valueFlagHeaderFlag(headerVoForCheck.getFinFlg())
//                        && warningHeaderBusiness.valueFlagHeaderFlag(headerVoForCheck.getEwsFlag()) && warningHeaderBusiness.valueFlagHeaderFlag(headerVoForCheck.getTrigAndPayFlag())) {
//                    headerStatus = BusinessConst.Flag.COMPLETE;
//                }
//
//                if (BusinessConst.Flag.COMPLETE.equals(headerStatus)) {
//                    WarningInfoVo warningInfoVoForChk = warningInfoService.findWarningInfoObj(asstTopicVo.getWarningHeaderId(), asstTopicVo.getWarningId(), BusinessConst.WarningTypeCode.EWSQ);
//                    if (warningInfoVoForChk != null) {
//                        if (!BusinessConst.Flag.Y.equals(warningInfoVoForChk.getQualiSendFlag())) {
//                            if (!BusinessConst.Flag.Y.equals(warningInfoVoForChk.getCloseFlag())) {
//                                headerStatus = BusinessConst.Flag.INPROCESS;
//                            }
//                        }
//                    }
//                }
//            }
//
//            warningHeaderVo.setStatus(headerStatus);
//            sendScroe(asstTopicVo, user);
//        }
//    }

    @Override
    public List<WarningTypeVo> findWarningType() throws Exception {
        return warningTypeService.findWarningTypeForEwsl();
    }

    @Override
    public void approveQuestion(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action , boolean updateHeader) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("approveQuestion");
            log.info("getWarningType : " + asstTopicVo.getWarningType());
            log.info("getWarningId : " + asstTopicVo.getWarningId());
            log.info("getAnswerQuestionId : " + asstTopicVo.getAnswerQuestionId());
            log.info("getAnswerVersion : " + asstTopicVo.getAnswerVersion());
        }
        String status = approve(asstTopicVo, user, infoStatus, action , updateHeader); 
        sendScroe(asstTopicVo, user);
        //-------------- Check Close OUT OF Pipleline
        if(asstTopicVo != null && asstTopicVo.getWarningHeaderId() > 0 && user != null){
            Integer result = warningHeaderService.checkDataBeforeCloseOutOfPipeline(asstTopicVo.getWarningHeaderId());
            log.info(" checkDataBeforeCloseOutOfPipeline result -->> " + result);
            if(result != null && result > 0){
                warningHeaderService.updateStateAfterCheckDataBeforeCloseOutOfPipeline(user.getEmpNo(), asstTopicVo.getWarningHeaderId());
                WarningCompletionVo warningCompletionVo = new WarningCompletionVo();
                warningCompletionVo.setWarningHeadId(String.valueOf(asstTopicVo.getWarningHeaderId()));
                String completeFlag = "";
                if(BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())){
                    completeFlag = BusinessConst.COMPLETE_FLAG_BY_WARNING_TYPE.EWSQ_APPROVE;
                    warningCompletionVo.setRemark("อนุมัติ Qualitative");
                }else if(BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())){
                    completeFlag = BusinessConst.COMPLETE_FLAG_BY_WARNING_TYPE.FIN_APPROVE;
                    warningCompletionVo.setRemark("อนุมัติ Financial");
                }else if (BusinessConst.WarningTypeCode.LATE_PAY.equals(asstTopicVo.getWarningType())){
                    completeFlag = BusinessConst.COMPLETE_FLAG_BY_WARNING_TYPE.LATE_PAY_APPROVE;
                    warningCompletionVo.setRemark("อนุมัติ Late Payment");
                }
                warningCompletionVo.setCreatedDt(DateUtil.getCurrentDateTime());
                warningCompletionVo.setCreatedBy(user.getEmpNo());
                if(!"".equals(completeFlag)){
                    warningCompletionVo.setCompleteFlg(completeFlag);
                    warningCompletionService.InsertWarningCompletion(warningCompletionVo);
                }
            }
        }
        
    }
  @Override
    public void sendbackQuestion(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action) throws Exception, RenowalException {
        if (log.isInfoEnabled()) {
            log.info("sendbackQuestion");
            log.info("asstTopicVo.getWarningType() >>" + asstTopicVo.getWarningType());
        }
       if (BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())) {
            String status = getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action);
            log.info(" asstTopicVo.getWarningId() >>" + asstTopicVo.getWarningId() +" status >> " + status);
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(asstTopicVo.getWarningId());
            warningInfoVo.setWarningType(asstTopicVo.getWarningType());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setStatus(status);
            warningInfoVo.setHolderId(null);
            warningInfoVo.setHolderRole(getHolderRole(status, "",user.getRoleId()));
            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);
            
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode("Reject");
            actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
            actionHistoryVo.setStatus(warningInfoVo.getStatus());
            actionHistoryVo.setRemark(asstTopicVo.getRemark());
            actionHistoryVo.setRoleCode(user.getRoleId());
            actionHistoryService.saveData(actionHistoryVo);
            
                //----DELETE ANSWER & HISTORY "BCM","CO_BCM" SELECT ANSWER
                List data = new ArrayList<String>();
                data.add(BusinessConst.UserRole.BCM);
                data.add(BusinessConst.UserRole.CO_BCM);
                String roleCode = StringUtil.genSqlInStr(data); 
                AsstAnswerVo filter = new AsstAnswerVo();
                filter.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                filter.setWarningId(asstTopicVo.getWarningId());
                List<AsstAnswerVo> answerList = asstAnswerService.findAsstAnswerByHeaderIdForSendBackQuali(filter, roleCode);
                if(answerList != null && !answerList.isEmpty()){
                    StringBuffer warningIdSQL = new StringBuffer();
                    for (int i = 0; i < answerList.size() ; i++) {
                        AsstAnswerVo dataAns = (AsstAnswerVo)answerList.get(i);
                        if(dataAns != null && dataAns.getWarningId() != 0){
                        if (i > 0) {
                            warningIdSQL.append(",");
                        }
                        warningIdSQL.append( dataAns.getWarningId() );
                        }
                    }
                    if( warningIdSQL != null &&  !ValidatorUtil.isNullOrEmpty(warningIdSQL.toString()) && !ValidatorUtil.isNullOrEmpty(roleCode) &&
                        asstTopicVo.getWarningHeaderId() > 0){
                        //---FOR DELETE ANSWER
                        StringBuffer warningIdSQLForAnswer = new StringBuffer();
                        String warningTrigger  = warningIdSQL.toString();
                        warningIdSQLForAnswer.append(warningTrigger).append(",'").append(asstTopicVo.getWarningId()).append("' ");
                        log.info("warningIdSQLForAnswer >>" + warningIdSQLForAnswer.toString());
                        log.info("warningIdSQL >> " + warningIdSQL.toString());
                        asstAnswerService.deleteAnswerByWarningIdAndRoleCode(warningIdSQLForAnswer.toString(), roleCode);
                        actionHistoryService.deleteActionHistoryByWarningIdAndRoleCode(warningIdSQL.toString(), roleCode);
                        warningInfoService.deleteWarningInfoId(asstTopicVo.getWarningHeaderId(),warningIdSQL.toString());
                    }
                 }
                List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ);
                List<String> trigList = new ArrayList<String>();
                if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
                for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                    trigList.add(warningTypeVo.getWarningTypeCode());
                }
                if(trigList != null && !trigList.isEmpty()){
                List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoActiveByHeaderAndWarningTypeList(asstTopicVo.getWarningHeaderId(), trigList, asstTopicVo.getWarningId());
                for (WarningInfoVo warningInfoVos : warningInfoVoList) {
                    //TBL_ACTION_HISTORY
                    log.info(" warningInfoVos.getWarningId() >>" + warningInfoVos.getWarningId() +" warningInfoVo.getStatus() >> " + warningInfoVo.getStatus());
                    ActionHistoryVo actionHistoryVoTrig = new ActionHistoryVo();
                    actionHistoryVoTrig.setWarningId(warningInfoVos.getWarningId());
                    actionHistoryVoTrig.setActionDt(DateUtil.getCurrentDateTime());
                    actionHistoryVoTrig.setActionBy(user.getEmpNo());
                    actionHistoryVoTrig.setActionCode("Reject");
                    actionHistoryVoTrig.setActionDetail(warningInfoVos.getWarningType());
                    actionHistoryVoTrig.setStatus(warningInfoVo.getStatus());
                    actionHistoryVoTrig.setRemark(asstTopicVo.getRemark());
                    actionHistoryVoTrig.setRoleCode(user.getRoleId());
                    actionHistoryService.saveData(actionHistoryVoTrig);
            
                    warningInfoVo = new WarningInfoVo();
                    warningInfoVo.setWarningId(warningInfoVos.getWarningId());
                    warningInfoVo.setWarningType(warningInfoVos.getWarningType());
                    warningInfoVo.setUpdatedBy(user.getEmpNo());
                    warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    warningInfoVo.setStatus(status);
                    warningInfoVo.setHolderId(null);
                    warningInfoVo.setHolderRole(getHolderRole(status, "",user.getRoleId()));
                    warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);
                }
             }//END trigList.isEmpty()
            //------- Update Header : 01/10/2014 : RMF , BRMF send back : So,Header is N the both flag and status ------//
           String xxFlagHeader = getXxFlagForHeader(status, asstTopicVo.getWarningType(), asstTopicVo.getWarningHeaderId());
           if (BusinessConst.Flag.N.equals(xxFlagHeader)) {
               WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
               warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
               warningHeaderVo.setUpdatedBy(user.getEmpNo());
               warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
               warningHeaderVo.setEwsFlag(xxFlagHeader);
               warningHeaderVo.setQualiFlg(xxFlagHeader);
               warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
               checkAllXxFlagForUpdateHeaderStatus(asstTopicVo.getWarningHeaderId(), user.getEmpNo(), BusinessConst.GO_ACTION.PREVIOUS);
           }
           }
        }else if(BusinessConst.WarningTypeCode.LATE_PAY.equals(asstTopicVo.getWarningType())){
            String currentInfoStatus;
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(asstTopicVo.getWarningId());
            warningInfoVo.setWarningType(asstTopicVo.getWarningType());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            currentInfoStatus = getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action);
            warningInfoVo.setStatus(currentInfoStatus);
            warningInfoVo.setHolderId(null);
            warningInfoVo.setHolderRole(getHolderRole(currentInfoStatus, "",user.getRoleId()));
             warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);
//            warningInfoVo.setBcmLatePayAdvice("");
//            warningInfoVo.setBcmLatePayLevel("");
//            warningInfoService.updateStatusByWarningIdAndTypeLatePayment(warningInfoVo);
        
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode("Reject");
            actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
            actionHistoryVo.setStatus(warningInfoVo.getStatus());
            actionHistoryVo.setRemark(asstTopicVo.getRemark());
            actionHistoryVo.setRoleCode(user.getRoleId());
            actionHistoryService.saveData(actionHistoryVo);
            
             //----DELETE ANSWER & HISTORY "BCM" , "CO_BCM" SELECT ANSWER
            List data = new ArrayList<String>();
            data.add(BusinessConst.UserRole.BCM);
             data.add(BusinessConst.UserRole.CO_BCM);
            String roleCode = StringUtil.genSqlInStr(data); 
            List<AsstAnswerVo> answerList = asstAnswerService.findAsstAnswerByWarningIdAndRoleCode(asstTopicVo.getWarningId(), roleCode);
            if(answerList != null && !answerList.isEmpty()){
                  String warningIdStr = "'"+asstTopicVo.getWarningId()+"'"; 
                  asstAnswerService.deleteAnswerByWarningIdAndRoleCode(warningIdStr, roleCode);
             }

            String xxFlagHeader = getXxFlagForHeader(currentInfoStatus, asstTopicVo.getWarningType(), asstTopicVo.getWarningHeaderId());
            if (BusinessConst.Flag.N.equals(xxFlagHeader)) {
                WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                warningHeaderVo.setLatePayFlg(xxFlagHeader);   
                warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
                checkAllXxFlagForUpdateHeaderStatus(asstTopicVo.getWarningHeaderId(), user.getEmpNo(), BusinessConst.GO_ACTION.PREVIOUS);
            }
        }else {
            String currentInfoStatus;
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(asstTopicVo.getWarningId());
            warningInfoVo.setWarningType(asstTopicVo.getWarningType());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
                currentInfoStatus = infoStatus;
            } else {
                currentInfoStatus = getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action);
            }
            warningInfoVo.setStatus(currentInfoStatus);
            warningInfoVo.setHolderId(null);
            warningInfoVo.setHolderRole(getHolderRole(currentInfoStatus, "",user.getRoleId()));
            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);

            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            if (asstTopicVo.getActionCode() != null && BusinessConst.ACTION_CODE.PROSTEST.equals(asstTopicVo.getActionCode())) {
                actionHistoryVo.setActionCode(asstTopicVo.getActionCode());
            } else {
                actionHistoryVo.setActionCode("Reject");
            }
            actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
            actionHistoryVo.setStatus(warningInfoVo.getStatus());
            actionHistoryVo.setRemark(asstTopicVo.getRemark());
            actionHistoryVo.setRoleCode(user.getRoleId());
            actionHistoryService.saveData(actionHistoryVo);

            //---- FIN  : Protest By credit review and turnAround : 18/12/2014
            if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())
                    && BusinessConst.Flag.PRMP.equals(currentInfoStatus)) {

                WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                warningHeaderVo.setFinFlg(BusinessConst.Flag.P);
                warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
            } else {
                //------- Update Header : 01/10/2014 : RMF , BRMF send back : So,Header is N the both flag and status ------//
                String xxFlagHeader = getXxFlagForHeader(currentInfoStatus, asstTopicVo.getWarningType(), asstTopicVo.getWarningHeaderId());
                if (BusinessConst.Flag.N.equals(xxFlagHeader)) {
                    WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
                    warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                    warningHeaderVo.setUpdatedBy(user.getEmpNo());
                    warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
                        warningHeaderVo.setFinFlg(xxFlagHeader);
                    } else if (BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())) {
                        warningHeaderVo.setEwsFlag(xxFlagHeader);
                         warningHeaderVo.setQualiFlg(xxFlagHeader);
                    } else if (BusinessConst.WarningTypeCode.LATE_PAY.equals(asstTopicVo.getWarningType())) {
                        warningHeaderVo.setLatePayFlg(xxFlagHeader);
                    }    
                    warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
                    checkAllXxFlagForUpdateHeaderStatus(asstTopicVo.getWarningHeaderId(), user.getEmpNo(), BusinessConst.GO_ACTION.PREVIOUS);
                }
            }//
        }
        //------------------------------------------//
    }

    
    @Override
    public void sendbackQuestionDraft(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action) throws Exception, RenowalException {
        try{
        if (log.isInfoEnabled()) {
            log.info("sendbackQuestionDraft");
        }
        String   currentInfoStatus = getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action);
        log.info("currentInfoStatus >> " + currentInfoStatus);
        Integer amtRecActionHistory = actionHistoryService.checkActionHistoryBy(asstTopicVo.getWarningId(), "Reject", "RX");
        ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
        actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
        actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
        actionHistoryVo.setActionBy(user.getEmpNo());
        actionHistoryVo.setActionCode("Reject");
        actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
        actionHistoryVo.setStatus("RX");
        actionHistoryVo.setRemark(asstTopicVo.getRemark());
        actionHistoryVo.setRoleCode(user.getRoleId());
        if(amtRecActionHistory != null && amtRecActionHistory > 0){
           actionHistoryService.updateData(actionHistoryVo);
        }else{
           actionHistoryService.saveData(actionHistoryVo);
        }
        
        if (BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())) {
              List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ);
              List<String> trigList = new ArrayList<String>();
              if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
                for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                    trigList.add(warningTypeVo.getWarningTypeCode());
                }
                List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoActiveByHeaderAndWarningTypeList(asstTopicVo.getWarningHeaderId(), trigList , asstTopicVo.getWarningId());
                for (WarningInfoVo warningInfoVos : warningInfoVoList) {
                        Integer amtRecActionHistoryTrig = actionHistoryService.checkActionHistoryBy(warningInfoVos.getWarningId(), "Reject", "RX");
                        ActionHistoryVo actionHistoryVoTrig = new ActionHistoryVo();
                        actionHistoryVoTrig.setWarningId(warningInfoVos.getWarningId());
                        actionHistoryVoTrig.setActionDt(DateUtil.getCurrentDateTime());
                        actionHistoryVoTrig.setActionBy(user.getEmpNo());
                        actionHistoryVoTrig.setActionCode("Reject");
                        actionHistoryVoTrig.setActionDetail(warningInfoVos.getWarningType());
                        actionHistoryVoTrig.setStatus("RX");
                        actionHistoryVoTrig.setRemark(asstTopicVo.getRemark());
                        actionHistoryVoTrig.setRoleCode(user.getRoleId());
                        if(amtRecActionHistoryTrig != null && amtRecActionHistoryTrig > 0){
                           actionHistoryService.updateData(actionHistoryVoTrig);
                        }else{
                           actionHistoryService.saveData(actionHistoryVoTrig);
                        }
                }
              }
         }
        }catch(Exception e){
          e.printStackTrace();
        }
         
    }

    private String approve(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action , boolean updateHeader) throws Exception, RenowalException {
        String status = BusinessConst.Flag.COMPLETE;
        if(BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())){
            //-----Approve quali
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(asstTopicVo.getWarningId());
            warningInfoVo.setWarningType(asstTopicVo.getWarningType());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setStatus(getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action));            
            warningInfoVo.setHolderId(null);
            log.info(" Before get Holder Role  getStatus : " + warningInfoVo.getStatus());
            warningInfoVo.setHolderRole(getHolderRole(warningInfoVo.getStatus(), "",user.getRoleId()));
            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);
            
            //---- Find DPD -----//
           log.info("warningHeaderId =" + asstTopicVo.getWarningHeaderId() + ": cifNo =" + asstTopicVo.getCifNo() );
           WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginal(asstTopicVo.getWarningHeaderId(), asstTopicVo.getCifNo());
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode("Approve");
            actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
            actionHistoryVo.setStatus(warningInfoVo.getStatus());
            actionHistoryVo.setRoleCode(user.getRoleId());
            if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                  actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
            }else{
                  actionHistoryVo.setDpd(null);
            }
            actionHistoryService.saveData(actionHistoryVo);

            //-----Approve Trigger
               log.info("-------------------: Approve Trigger :------------------- ");
            List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ);
            List<String> trigList = new ArrayList<String>();
            if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
                for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                    trigList.add(warningTypeVo.getWarningTypeCode());
                }
                //-------- FIND For Delete -- TRIG NOT SELECT --------//
                if(asstTopicVo.getWarningHeaderId() != 0){
                List data = new ArrayList<String>();
                data.add(BusinessConst.UserRole.BCM);
                data.add(BusinessConst.UserRole.CO_BCM);
                String  roleCode = StringUtil.genSqlInStr(data);
                AsstAnswerVo filter = new AsstAnswerVo();
                filter.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                filter.setWarningId(asstTopicVo.getWarningId());
                List<AsstAnswerVo> answerList = asstAnswerService.findAsstAnswerByHeaderIdForTrigger(filter, roleCode);
                log.info("answerList.size() ==>>> " + answerList == null ? 0 : answerList.size());
                if(answerList == null || answerList.isEmpty()){
                    data = new ArrayList<String>();
                    data.add(BusinessConst.UserRole.RM);
                    data.add(BusinessConst.UserRole.AE);
                    data.add(BusinessConst.UserRole.AO);
                    data.add(BusinessConst.UserRole.CO_RM);
                    data.add(BusinessConst.UserRole.CO_AE);
                    data.add(BusinessConst.UserRole.CO_AO);
                    roleCode = StringUtil.genSqlInStr(data);
                    answerList = asstAnswerService.findAsstAnswerByHeaderIdForTrigger(filter, roleCode);
                }
                if(answerList != null && !answerList.isEmpty()){
                    StringBuffer warningIdSQL = new StringBuffer();
                    for (int i = 0; i < answerList.size() ; i++) {
                        AsstAnswerVo dataAns = (AsstAnswerVo)answerList.get(i);
                        if(dataAns != null && dataAns.getWarningId() != 0){
                        if (i > 0) {
                            warningIdSQL.append(",");
                        }
                        warningIdSQL.append( dataAns.getWarningId() );
                        }
                    }
                    StringBuffer warningIdTrigNotApproveSQL = new StringBuffer();
                    List<Integer> warningIdTrigNotApproveList = warningInfoService.findTriggerNotApprove(asstTopicVo.getWarningHeaderId(), warningIdSQL.toString(),asstTopicVo.getWarningId());
                    if(warningIdTrigNotApproveList != null && !warningIdTrigNotApproveList.isEmpty()){
                            for (int i = 0; i < warningIdTrigNotApproveList.size() ; i++) {
                                Integer dataAnsIns = (Integer)warningIdTrigNotApproveList.get(i);
                                if(dataAnsIns != null && dataAnsIns > 0){
                                if (i > 0) {
                                    warningIdTrigNotApproveSQL.append(",");
                                }
                                warningIdTrigNotApproveSQL.append(dataAnsIns);
                                }
                            }
                    }
                     //------ DELETE TRIIGER  IN ANSWER AND ACTION HISTORY 
                    if(warningIdTrigNotApproveSQL != null && !ValidatorUtil.isNullOrEmpty(warningIdTrigNotApproveSQL.toString())){
                        log.info(" TEST warningIdTrigNotApproveSQL.toString ==>>> " + warningIdTrigNotApproveSQL.toString());
                        asstAnswerService.deleteAnswerByWarningId(warningIdTrigNotApproveSQL.toString());
                        actionHistoryService.deleteActionHistoryByWarningId(warningIdTrigNotApproveSQL.toString());
                    }
                    if(warningIdSQL != null && !ValidatorUtil.isNullOrEmpty(warningIdSQL.toString())){
                    log.info("warningIdSQL.toString ==>>> " + warningIdSQL.toString());
                    warningInfoService.deleteTriggerNotApprove(asstTopicVo.getWarningHeaderId(), warningIdSQL.toString(),asstTopicVo.getWarningId());
                    //------ DELETE ANSWER QUALI 
                     if(asstTopicVo.getWarningId() > 0 ){
                        WarningInfoVo roleCodeAnserQuali = warningInfoService.findWarningInfoObjByWarningInfoId(asstTopicVo.getWarningId(), BusinessConst.WarningTypeCode.EWSQ);
                        if(roleCodeAnserQuali != null && StringUtil.isNotEmpty(roleCodeAnserQuali.getRoleCode())){
                           log.info("asstTopicVo.getWarningId() ==>>> " + asstTopicVo.getWarningId());
                           log.info("roleCodeAnserQuali.getRoleCode() ==>>> " + roleCodeAnserQuali.getRoleCode());
                           asstAnswerService.deleteAnswerQualiByWarningIdAndOtherRoleCode(asstTopicVo.getWarningId(), roleCodeAnserQuali.getRoleCode());
                        }
                     }
                    }
                 }
                }
                //-----------------------------------------//
                List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoActiveByHeaderAndWarningTypeList(asstTopicVo.getWarningHeaderId(), trigList , asstTopicVo.getWarningId());
                for (WarningInfoVo warningInfoVos : warningInfoVoList) {
                    warningInfoVo = new WarningInfoVo();
                    warningInfoVo.setWarningId(warningInfoVos.getWarningId());
                    warningInfoVo.setWarningType(warningInfoVos.getWarningType());
                    warningInfoVo.setUpdatedBy(user.getEmpNo());
                    warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    warningInfoVo.setStatus(getSeqInfoStatus(infoStatus, warningInfoVos.getWarningType(), action));
                    warningInfoVo.setHolderId(null);
                    warningInfoVo.setHolderRole(getHolderRole(warningInfoVo.getStatus(), "",user.getRoleId()));
                    warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);

                    actionHistoryVo = new ActionHistoryVo();
                    actionHistoryVo.setWarningId(warningInfoVos.getWarningId());
                    actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
                    actionHistoryVo.setActionBy(user.getEmpNo());
                    actionHistoryVo.setActionCode("Approve");
                    actionHistoryVo.setActionDetail(warningInfoVos.getWarningType());
                    actionHistoryVo.setStatus(warningInfoVo.getStatus());
                    actionHistoryVo.setRoleCode(user.getRoleId());
                    if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                           actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
                    }else{
                           actionHistoryVo.setDpd(null);
                    }
                    actionHistoryService.saveData(actionHistoryVo);
                }
            }
            //---------- Update Flg  ( C )and status ( I ) in Header
            WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
            warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
            warningHeaderVo.setUpdatedBy(user.getEmpNo());
            warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningHeaderVo.setStatus(BusinessConst.Flag.INPROCESS);
            warningHeaderVo.setQualiFlg(BusinessConst.Flag.COMPLETE); //---SAME
            warningHeaderVo.setEwsFlag(BusinessConst.Flag.COMPLETE); //---SAME
            warningHeaderService.updateStatusAndFlagInWarningHeader(warningHeaderVo);
            
            // ************** send score before close pipeline **************//
        }else if(BusinessConst.WarningTypeCode.LATE_PAY.equals(asstTopicVo.getWarningType())){
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(asstTopicVo.getWarningId());
            warningInfoVo.setWarningType(asstTopicVo.getWarningType());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setStatus(getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action));
            warningInfoVo.setHolderId(null);
            warningInfoVo.setHolderRole(getHolderRole(warningInfoVo.getStatus(), "",user.getRoleId()));
            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);

            String headerStatus = BusinessConst.Flag.INPROCESS;
            WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
            warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
            warningHeaderVo.setUpdatedBy(user.getEmpNo());
            warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningHeaderVo.setStatus(headerStatus);
            warningHeaderVo.setLatePayFlg(status);
            if(updateHeader){
                   warningHeaderService.updateStatusAndFlagInWarningHeader(warningHeaderVo);
            }
              //---- Find DPD -----//
           log.info("warningHeaderId =" + asstTopicVo.getWarningHeaderId() + ": cifNo =" + asstTopicVo.getCifNo() );
           WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginal(asstTopicVo.getWarningHeaderId(), asstTopicVo.getCifNo());
           
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode("Approve");
            actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
            actionHistoryVo.setStatus(warningInfoVo.getStatus());
            actionHistoryVo.setRoleCode(user.getRoleId());
            if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                  actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
            }else{
                  actionHistoryVo.setDpd(null);
            }
            actionHistoryService.saveData(actionHistoryVo);
        
        } else {
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(asstTopicVo.getWarningId());
            warningInfoVo.setWarningType(asstTopicVo.getWarningType());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
                warningInfoVo.setStatus(infoStatus);
                log.debug("approve Info Status" + infoStatus);
            } else {
                warningInfoVo.setStatus(getSeqInfoStatus(infoStatus, asstTopicVo.getWarningType(), action));
            }
            warningInfoVo.setHolderId(null);
            warningInfoVo.setHolderRole(getHolderRole(warningInfoVo.getStatus(), "",user.getRoleId()));
            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);

            if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
                if (BusinessConst.Flag.COMPLETE.equals(infoStatus)) {
                    status = BusinessConst.Flag.COMPLETE;
                } else {
                    status = BusinessConst.Flag.INPROCESS;
                }
                log.debug("approve Header FIN_FLA" + status);
            }
            String headerStatus = BusinessConst.Flag.INPROCESS;
            WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
            warningHeaderVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
            warningHeaderVo.setUpdatedBy(user.getEmpNo());
            warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningHeaderVo.setStatus(headerStatus);

            if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
                warningHeaderVo.setFinFlg(status);
            } else if (BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())) {
                warningHeaderVo.setEwsFlag(status);
                warningHeaderVo.setQualiFlg(status);
            } else if (EWSConstantValue.TRIGGER_GROUP.contains(asstTopicVo.getWarningType())|| BusinessConst.WarningTypeCode.TRIGANDPAY.equals(asstTopicVo.getWarningType())) {
                 warningHeaderVo.setTrigAndPayFlag(status);   
            } else if (BusinessConst.WarningTypeCode.LATE_PAY.equals(asstTopicVo.getWarningType())) {
                warningHeaderVo.setLatePayFlg(status);
            } 
            if(updateHeader){
                   warningHeaderService.updateStatusAndFlagInWarningHeader(warningHeaderVo);
            }
              //---- Find DPD -----//
           log.info("warningHeaderId =" + asstTopicVo.getWarningHeaderId() + ": cifNo =" + asstTopicVo.getCifNo() );
           WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginal(asstTopicVo.getWarningHeaderId(), asstTopicVo.getCifNo());
           
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(asstTopicVo.getWarningId());
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode("Approve");
            actionHistoryVo.setActionDetail(asstTopicVo.getWarningType());
            actionHistoryVo.setStatus(warningInfoVo.getStatus());
            actionHistoryVo.setRoleCode(user.getRoleId());
            if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                  actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
            }else{
                  actionHistoryVo.setDpd(null);
            }
            actionHistoryService.saveData(actionHistoryVo);
        }

        return status;
    }

    public void sendScroe(AsstTopicVo asstTopicVo, UserData user) throws Exception, ScoreEngineException {
        WSLogVO logVo = new WSLogVO();
        logVo.setCifNo(asstTopicVo.getCifNo());
        logVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
        logVo.setWarningId(asstTopicVo.getWarningId());

        if (BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
            if (!ValidatorUtil.isNullOrEmpty(asstTopicVo.getCifNo())) {
                FinancialVo finVo = qcaFinancialService.findCurrentQcaFin(asstTopicVo.getCifNo());
                if (finVo != null) {
                    if (BusinessConst.Flag.Y.equals(finVo.getHvFin())) {
                        ScoreEngineVo scoreEngineVo = qcaFinancialService.findDataForSendScore(asstTopicVo.getWarningId());
                        WarningInfoVo warningInfoVo = new WarningInfoVo();
                        warningInfoVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                        warningInfoVo.setWarningId(asstTopicVo.getWarningId());
                        scoreEngineVo.setCustId(asstTopicVo.getCifNo());
                        scoreEngineBusiness.sendProjectFIN(scoreEngineVo, warningInfoVo, user);
                    }//Not have model
                    else if (BusinessConst.Flag.N.equals(finVo.getHvFin())) {
                        //-------------------- Approve and No have Financal : 24/12/2014
                        WarningProcessVo warningProcessVo = new WarningProcessVo();
                        warningProcessVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                        warningProcessVo.setWarningId(asstTopicVo.getWarningId());
                        warningProcessVo.setFinScore(null);
                        warningProcessVo.setFinPD(null);
                        warningProcessVo.setFinODDS(null);
                        warningProcessVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                        warningProcessVo.setUpdatedBy(user.getEmpNo());
                        warningProcessVo.setHvFin(finVo.getHvFin()); //--N
                        warningProcessService.updateScoreProjectFIN(warningProcessVo);
                    }
                }
            }//Check CIF
        }else if (BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType())) { //---- Send Trigger
            log.info("EWSQ");
            ScoreEngineVo scoreEngineVo = findDataForTrigSendScore(asstTopicVo.getWarningHeaderId(), user, asstTopicVo.getCifNo(), asstTopicVo.getCustName(),asstTopicVo.getWarningId());
            WarningHeaderVo warningHeaderVos = warningHeaderService.findWarningHeaderByPK(asstTopicVo.getWarningHeaderId());
            scoreEngineVo.setFormAssign(warningHeaderVos.getFormAssign());
            scoreEngineVo.setFinalRiskLevel(warningHeaderVos.getEwsRiskLevel());
            scoreEngineVo.setBucketDPD(warningHeaderVos.getBucketDpd());
            CustomerVo customerVo = customerService.selectCustomerByCif(Integer.parseInt(asstTopicVo.getCifNo()));
            scoreEngineVo.setSize(customerVo.getBusinessSize());
            JSONObject jsonObject = scoreEngineBusiness.sendTrigger(scoreEngineVo, logVo);
            if (jsonObject != null) {
                //if (jsonObject.get("formAssessment") != null) {
                if (jsonObject.get("TriggerAssessment") != null) {
                    WarningHeaderVo headerVo = new WarningHeaderVo();
                    headerVo.setWarningHeaderId(asstTopicVo.getWarningHeaderId());
                    headerVo.setTrigPayResult(jsonObject.get("TriggerAssessment").toString());
                    headerVo.setUpdatedBy(user.getEmpNo());
                    headerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    warningHeaderService.updateResultTrigger(headerVo);
                }
            }
        }else if(BusinessConst.WarningTypeCode.LATE_PAY.equals(asstTopicVo.getWarningType())){
             log.info("LATE_PAY");
               ScoreEngineVo scoreEngineVo = findDataForSendScoreLatePayment(asstTopicVo.getQuestionId(), asstTopicVo.getVersion(), asstTopicVo.getWarningId(), user, asstTopicVo.getCifNo(), asstTopicVo.getCustName(), asstTopicVo.getWarningType());
               CustomerVo customerVo = customerService.selectCustomerByCif(Integer.parseInt(asstTopicVo.getCifNo()));
                scoreEngineVo.setSize(customerVo.getBusinessSize());
        
                JSONObject jsonObject = scoreEngineBusiness.sendLatePayment(scoreEngineVo, logVo);
                String latePayAdvice = "";
                String latePayLevel  = "";       
                if (jsonObject != null) {
                    if (jsonObject.get("LatePaymentForm") != null) {
                        latePayLevel = jsonObject.get("LatePaymentForm").toString();
                    }
                    if (jsonObject.get("LatePaymentAdvice") != null) {
                        latePayAdvice = jsonObject.get("LatePaymentAdvice").toString();
                    }
                    WarningInfoVo info = new WarningInfoVo();
                    info.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
                    info.setWarningId(asstTopicVo.getWarningId());
                    info.setUpdatedBy(user.getEmpNo());
                    info.setUpdatedDate(DateUtil.getCurrentDateTime());
                    if(BusinessConst.ACTION_CODE.APPROVE.equals(asstTopicVo.getActionForm())){
                       info.setBcmLatePayLevel(latePayLevel);
                       info.setBcmLatePayAdvice(latePayAdvice);
                    }else{
                       info.setLatePayLevel(latePayLevel);
                       info.setLatePayAdvice(latePayAdvice);
                    }
                    warningInfoService.updateStatusLatePayment(info);
                }   
       } 
          //--------04/05/2017 : New Implement For R1.3-----------//
        //******* ตอบใครก่อนหลังได้ระหว่าง EWSQ , FIN  ภายใต Header รอบที่กำลังทำ
         if (BusinessConst.WarningTypeCode.EWSQ.equals(asstTopicVo.getWarningType()) || BusinessConst.WarningTypeCode.FIN.equals(asstTopicVo.getWarningType())) {
            if ((asstTopicVo.getWarningHeaderId() > 0) && (asstTopicVo.getCifNo() != null && !"".equals(asstTopicVo.getCifNo()))) {
                String[] dataArr =  validateCanSendEWSByfindData(asstTopicVo.getWarningHeaderId(), asstTopicVo.getCifNo());
                if(dataArr != null && dataArr.length == 3){
                    if((StringUtil.isNotEmpty(dataArr[0]) && BusinessConst.Flag.TRUE.equals(dataArr[0]))
                            && (StringUtil.isNotEmpty(dataArr[1]) || StringUtil.isNotEmpty(dataArr[2]))){
                           log.debug(" ENTRY TO ______LOOP  sendEWSQWithLastesAnswer");
                           Integer qualiID = StringUtil.isNotEmpty(dataArr[1]) ? Integer.parseInt(dataArr[1]) : 0 ;
                           Integer finID = StringUtil.isNotEmpty(dataArr[2]) ? Integer.parseInt(dataArr[2]) : 0 ;
                           log.debug(" qualiID : " + qualiID);
                           log.debug(" finID : " + finID);
                           sendEWSQWithLastesAnswer(asstTopicVo.getWarningHeaderId(), user, asstTopicVo.getCifNo(),qualiID , finID ,asstTopicVo.getWarningType());
                    }
                }
            }
        }
    }

    /*
     * resultArr[0] = TRUE , FAIL ส่ง score หรือไม่
     * resultArr[1] = warningId ของ Quali
     * resultArr[2] = warningId ของ FIN
     */
    @Override
    public String[] validateCanSendEWSByfindData(int warningHeaderId ,String cifNo) throws Exception {
        String[] resultArr = new String[3];
        if (log.isInfoEnabled()) {
                log.info("validateCanSendEWSByfindData");
        }
        try{
             List<WarningInfoVo> warningInfo = warningInfoService.findWarningInfoByHeaderId(warningHeaderId);
               if ((warningInfo != null) && (!warningInfo.isEmpty())) {
                   Integer qualiWarningId = null;
                   Integer finWarningId = null;
                   for(WarningInfoVo info : warningInfo){
                       log.debug("------------------------------");
                       log.debug("info.getWarningType() >> " + info.getWarningType());
                       log.debug("info.getStatus() >>" + info.getStatus());
                       log.debug("info.getCloseFlag() >>" + info.getCloseFlag());
                       if(BusinessConst.WarningTypeCode.EWSQ.equals(info.getWarningType()) &&
                                (BusinessConst.Flag.COMPLETE.equals(info.getStatus()) && !BusinessConst.Flag.Y.equals(info.getCloseFlag()))) {
                            
                           qualiWarningId = info.getWarningId();
                           
                       }else if(BusinessConst.WarningTypeCode.FIN.equals(info.getWarningType()) &&
                                (BusinessConst.Flag.COMPLETE.equals(info.getStatus()) && !BusinessConst.Flag.Y.equals(info.getCloseFlag()))) {
                           
                           finWarningId =  info.getWarningId();
                       }
                   }
                    log.debug("qualiWarningId >>" +qualiWarningId);
                    log.debug("finWarningId >>" + finWarningId);
                   //---------- ตรวจสอบว่า ไม่มี FIN ในรอบการแจ้งเตือน HeaderID ตัวเดียวกัน ต้องไปเอาจากรอบก่อนหน้า ที่มีการตอบแบบสอบถาม----------//
                   if(finWarningId == null || finWarningId == 0){
                        finWarningId = warningInfoService.findLatestWarningInfoByCif(cifNo ,BusinessConst.WarningTypeCode.FIN );
                   }
                   //---------- ตรวจสอบว่า ไม่มี QUALI ในรอบการแจ้งเตือน HeaderID ตัวเดียวกัน ต้องไปเอาจากรอบก่อนหน้า ที่มีการตอบแบบสอบถาม--------//
                   if(qualiWarningId == null || qualiWarningId == 0){
                        qualiWarningId = warningInfoService.findLatestWarningInfoByCif(cifNo ,BusinessConst.WarningTypeCode.EWSQ);
                   }
                   //----------มี FIN หรือ QUALI ก็ call score เสมอ ----------------//
                   if((qualiWarningId == null || qualiWarningId == 0)&&(finWarningId == null || finWarningId == 0)){
                        resultArr[0] = BusinessConst.Flag.FAIL;
                   }else{
                        resultArr[0] = BusinessConst.Flag.TRUE;
                   }
                   resultArr[1] = qualiWarningId != null ? String.valueOf(qualiWarningId) : "";
                   resultArr[2] = finWarningId != null ? String.valueOf(finWarningId) : "";
               }
               log.debug(" SEND SCORE EWS ==>  >>" + resultArr[0]);
               log.debug(" QUALI WarningId ==>  >>" + resultArr[1]);
               log.debug(" FIN WarningId ==>  >>" + resultArr[2]);
        }catch (Exception e) {
            throw e;
        }
       return resultArr;  
    }

    @Override
    public boolean checkAnswerInVersion(String questionId, String version, int warningId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("checkAnswerInVersion");
        }
        boolean check = false;
        List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerByWarningIdAndQuestId(warningId, questionId);
        if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
            for (AsstAnswerVo assstAnswerVo : asstAnswerVoList) {
                if (version.equals(assstAnswerVo.getVersion())) {
                    check = true;
                    break;
                }
            }
        } else {
            check = true;
        }

        return check;
    }

    private ScoreEngineVo findDataForSendScore(String questionId, String version, int warningId, UserData user, String cifNo, String cifName, String warningType) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataForSendScore");
            log.info("questionId : " + questionId);
            log.info("version    : " + version);
            log.info("warningId  : " + warningId);
            log.info("cifNo      : " + cifNo);
            log.info("user.getRoleId     : " + user.getRoleId());
        }
        JSONArray topicObjGroup = new JSONArray();
        JSONObject topicObj;
        JSONArray subTopicObjGroup;
        JSONObject subTopicObject;

        List<AsstTopicVo> asstTopicVoList = asstQuestionService.findTopicByQuestion(questionId, version);
        if (asstTopicVoList != null && asstTopicVoList.size() > 0) {
            AsstAnswerVo filter = new AsstAnswerVo();
            filter.setQuestionId(questionId);
            filter.setVersion(version);
            filter.setWarningId(warningId);
            String userRole = BusinessConst.UserRole.RM;
            if(user != null && !ValidatorUtil.isNullOrEmpty(user.getRoleId())){ //Should Be CO_BCM or BCM
              userRole = user.getRoleId();
            }
            log.info("userRole    : " + userRole);
            filter.setRole(userRole);
            
            List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
            if(asstAnswerVoList == null || asstAnswerVoList.isEmpty()){
                  filter.setRole(BusinessConst.UserRole.CO_RM);
                  asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
                  
                  if(asstAnswerVoList == null || asstAnswerVoList.isEmpty()){
                  filter.setRole(BusinessConst.UserRole.CO_AE);
                  asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
                  }
                  if(asstAnswerVoList == null || asstAnswerVoList.isEmpty()){
                  filter.setRole(BusinessConst.UserRole.RM);
                  asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
                  }
                  if(asstAnswerVoList == null || asstAnswerVoList.isEmpty()){
                  filter.setRole(BusinessConst.UserRole.AE);
                  asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
                  }
                  if(asstAnswerVoList == null || asstAnswerVoList.isEmpty()){
                  filter.setRole(BusinessConst.UserRole.AO);
                  asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
                  }
            }
            for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                topicObj = new JSONObject();
                topicObj.put("topicId", asstTopicVo.getTopicId());
                subTopicObjGroup = new JSONArray();
                for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                    if (asstTopicVo.getTopicId() == asstAnswerVo.getTopicId()) {
                        subTopicObject = new JSONObject();
                        subTopicObject.put("subTopicId", asstAnswerVo.getSubTopicId());
                        if (asstAnswerVo.getChoiceId() > 0) {
                            subTopicObject.put("choiceId", asstAnswerVo.getChoiceId());
                        } else {
                            subTopicObject.put("choiceId", -99999999);
                        }
                        subTopicObjGroup.add(subTopicObject);
                    }
                }

                topicObj.put("subTopicObject", subTopicObjGroup);
                topicObjGroup.add(topicObj);
            }
        }

        ScoreEngineVo scoreEngineVo = new ScoreEngineVo();
        scoreEngineVo.setAppId("");
        scoreEngineVo.setCustId(cifNo);
        scoreEngineVo.setCustName(cifName);
        scoreEngineVo.setRespUnitId(user.getDeptCode());
        scoreEngineVo.setQuestionId(questionId);
        scoreEngineVo.setVersion(version);
        scoreEngineVo.setLimitSize("1");
        scoreEngineVo.setTopicObj(topicObjGroup);

        return scoreEngineVo;
    }

    private String getSeqInfoStatus(String infoStatus, String warningType, String action) throws Exception {
        if (BusinessConst.Flag.N.equals(infoStatus)) {
            return BusinessConst.Flag.RMF;
        } else if (BusinessConst.Flag.RMP.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
            return BusinessConst.Flag.RMF;
        } else if (BusinessConst.Flag.RMF.equals(infoStatus)) {
            if ("Approve".equals(action)) {
                return BusinessConst.Flag.COMPLETE;
            } else if("Save".equals(action)){  //------ FOR เก็บตก require : BCM สามารถแก้ไขคำตอบของ RM ได้
                return BusinessConst.Flag.RMF;
            }else {
                return BusinessConst.Flag.BRMP;
            }
        }
        return null;
    }

    private String getRoleForAnswer(String roleCode, String infoStatus) throws Exception {
        if (BusinessConst.UserRole.RISK_EDITOR.equals(roleCode) || BusinessConst.UserRole.BCM.equals(roleCode) || BusinessConst.UserRole.SCM.equals(roleCode) || BusinessConst.UserRole.AE.equals(roleCode) || BusinessConst.UserRole.AO.equals(roleCode)) {
            if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.RMP.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
                return BusinessConst.UserRole.RM;
            } else if (BusinessConst.Flag.BCA.equals(infoStatus) || BusinessConst.Flag.CMP.equals(infoStatus)) {
                return BusinessConst.UserRole.CM;
            } else if (BusinessConst.Flag.CMF.equals(infoStatus) || BusinessConst.Flag.SCMP.equals(infoStatus)) {
                return BusinessConst.UserRole.SCM;
            }
        }
        return roleCode;
    }

    private String getXxFlagForHeader(String statusInfo, String warningTypeCode, int warningHeaderId) throws Exception {
        String result;      
            if (EWSConstantValue.STATUS_HEADER_NOT_SEND_BCM.contains(statusInfo)) {
                result = BusinessConst.Flag.N;
            } else {
                result = BusinessConst.Flag.INPROCESS;
            }
        log.info("getXxFlagForHeader HeaderXxFlag >>  =" + result);
        return result;
    }

    @Override
    public void checkAllXxFlagForUpdateHeaderStatus(int warningHeaderId, String empNo, String goToAction) throws Exception {
        try {
            Integer result =  warningHeaderService.findWarningInfoALLNewOrBlank(warningHeaderId);
            log.info("checkAllXxFlagForUpdateHeaderStatus result >>(Need 1 update)  =" + result);
            if ((result != null) && (result.intValue() > 0)) { //--- ALL flag is N , NA , Blank , null : Should be return 1
                WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setWarningHeaderId(warningHeaderId);
                warningHeaderVo.setUpdatedBy(empNo);
                warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                if (BusinessConst.GO_ACTION.NAXT.equals(goToAction)) {
                    warningHeaderVo.setStatus(BusinessConst.Flag.INPROCESS);
                } else {
                    warningHeaderVo.setStatus(BusinessConst.Flag.N);
                }
               warningHeaderService.updateStatusWarningHeader(warningHeaderVo);
            }
        } catch (Exception e) {
            log.error("Error checkAllXxFlagForUpdateHeaderStatus : " + e.getMessage());
            throw e;
        }
    }

    @Override
    public boolean chkUser(int warningId, String userId) throws Exception {
        log.info("chkUser >>  =" + warningId);
        List<ActionHistoryVo> actionHistoryVoList = actionHistoryService.findDataByWarningIdAndStatus(warningId, BusinessConst.Flag.CMF);
        if (actionHistoryVoList != null && actionHistoryVoList.size() > 0) {
            ActionHistoryVo actionHistoryVo = (ActionHistoryVo) actionHistoryVoList.get(0);
            if (userId.equals(actionHistoryVo.getActionBy())) {
                return true;
            }
        }

        return false;
    }

    @Override
    public List<ActionHistoryVo> findRemarkFromHistory(int warningId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findRemarkFromHistory");
        }
        List<ActionHistoryVo> actionHistoryVoList = actionHistoryService.findRemarkByWarningId(warningId);
        if (!actionHistoryVoList.isEmpty()) {
            for (ActionHistoryVo actionHistoryVo : actionHistoryVoList) {
                if (BusinessConst.Flag.COMPLETE.equals(actionHistoryVo.getStatus())) {
                    actionHistoryVo.setRemark("อนุมัติปิดงาน");
                }
            }
        }
        return actionHistoryVoList;
    }

    private ScoreEngineVo findDataForTrigSendScore(int warningHeaderId, UserData user, String cifNo, String cifName , int qualiWarningIdTrigGen) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataForTrigSendScore >>> " + warningHeaderId);
        }
        JSONArray topicObjectTriggerGroup = new JSONArray();
        JSONArray topicObjectPaymentGroup = new JSONArray();
        JSONObject topicObjectTrigger;
        JSONObject topicObjectPayment;
        JSONArray subTopicObjGroup;
        JSONObject subTopicObject;

        List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ);
        List<String> warningTypeList = new ArrayList<String>();
        if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
            for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                warningTypeList.add(warningTypeVo.getWarningTypeCode());
            }
        }

        List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoActiveByHeaderAndWarningTypeList(warningHeaderId, warningTypeList,qualiWarningIdTrigGen);
        for (WarningInfoVo warningInfoVo : warningInfoVoList) {
                log.info("Trig Id >>> " + warningInfoVo.getWarningId());
                topicObjectTrigger = new JSONObject();
                topicObjectTrigger.put("TriggerQuestionId", warningInfoVo.getQuestionId());
                topicObjectTrigger.put("TriggerQuestionVersion", warningInfoVo.getVersion());

                List<AsstTopicVo> asstTopicVoList = asstQuestionService.findTopicByQuestion(warningInfoVo.getQuestionId(), warningInfoVo.getVersion());
                if (asstTopicVoList != null && asstTopicVoList.size() > 0) {
                    AsstAnswerVo filter = new AsstAnswerVo();
                    filter.setQuestionId(warningInfoVo.getQuestionId());
                    filter.setVersion(warningInfoVo.getVersion());
                    filter.setWarningId(warningInfoVo.getWarningId());
                    filter.setRole(BusinessConst.UserRole.RM);

                    List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForSendData(filter);
                    for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                        topicObjectTrigger.put("topicId", asstTopicVo.getTopicId());
                        subTopicObjGroup = new JSONArray();
                        for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                            if (asstTopicVo.getTopicId() == asstAnswerVo.getTopicId()) {
                                subTopicObject = new JSONObject();
                                subTopicObject.put("subTopicId", asstAnswerVo.getSubTopicId());
                                if (asstAnswerVo.getChoiceId() > 0) {
                                    subTopicObject.put("choiceId", asstAnswerVo.getChoiceId());
                                } else {
                                    subTopicObject.put("choiceId", -99999999);
                                }
                                subTopicObjGroup.add(subTopicObject);
                            }
                        }

                        topicObjectTrigger.put("subTopicObject", subTopicObjGroup);
                        topicObjectTriggerGroup.add(topicObjectTrigger);
                    }
                }
        }

        ScoreEngineVo scoreEngineVo = new ScoreEngineVo();
        scoreEngineVo.setAppId("");
        scoreEngineVo.setCustId(cifNo);
        scoreEngineVo.setCustName(cifName);
        scoreEngineVo.setRespUnitId(user.getDeptCode());
        scoreEngineVo.setLimitSize("1");
        if (!topicObjectTriggerGroup.isEmpty()) {
            scoreEngineVo.setTopicObjectTrigger(topicObjectTriggerGroup);
        }
        scoreEngineVo.setTopicObjectPayment(topicObjectPaymentGroup);
        scoreEngineVo.setWarningInfoVoList((ArrayList)warningInfoVoList);

        return scoreEngineVo;
    }

    @Override
    public String getHolderRole(String infoStatus, String qcaFlag , String roleCode) throws Exception {
      if(roleCode != null && EWSConstantValue.ROLE_EDITOR_CO_OP.contains(roleCode)){
            if (BusinessConst.Flag.N.equals(infoStatus)) {
                return BusinessConst.UserRole.CO_RM;
            } else if (BusinessConst.Flag.RMP.equals(infoStatus)) {
                return BusinessConst.UserRole.CO_RM;
            } else if (BusinessConst.Flag.RMF.equals(infoStatus))  {
                return BusinessConst.UserRole.CO_BCM;
            } else if (BusinessConst.Flag.BRMP.equals(infoStatus)) {
                return BusinessConst.UserRole.CO_RM;
            } else if (BusinessConst.Flag.COMPLETE.equals(infoStatus)) {
                    return BusinessConst.UserRole.CO_BCM;
            }
      }else{
        if (BusinessConst.Flag.N.equals(infoStatus)) {
            return BusinessConst.UserRole.RM;
        } else if (BusinessConst.Flag.RMP.equals(infoStatus)) {
            return BusinessConst.UserRole.RM;
        } else if (BusinessConst.Flag.RMF.equals(infoStatus)) {
            return BusinessConst.UserRole.BCM;
        } else if (BusinessConst.Flag.BRMP.equals(infoStatus)) {
            return BusinessConst.UserRole.RM;
        } else if (BusinessConst.Flag.BCA.equals(infoStatus)) {
            return BusinessConst.UserRole.SCM;
        } else if (BusinessConst.Flag.CMP.equals(infoStatus)) {
            return BusinessConst.UserRole.SCM;
        } else if (BusinessConst.Flag.CMF.equals(infoStatus)) {
            return BusinessConst.UserRole.SCM;
        } else if (BusinessConst.Flag.SCMP.equals(infoStatus)) {
            return BusinessConst.UserRole.SCM;
        } else if (BusinessConst.Flag.COMPLETE.equals(infoStatus)) {
            if (BusinessConst.Flag.Y.equals(qcaFlag)) {
                return BusinessConst.UserRole.SCM;
            } else {
                return BusinessConst.UserRole.BCM;
            }
        }
      }
     return null;
    }

    @Override
    public String checkAnswerVersionAndCurrentVersion(int warningId , String warningType) throws Exception {
        String sameVersion = BusinessConst.Flag.N;
        String currentQuestionId = null;
        String currentVersion = null;
        try{
            if((warningId > 0 )&&(!ValidatorUtil.isNullOrEmpty(warningType))){
                List<WarningTypeVo> wtTypeList = warningTypeService.findWarningTypeByWarningType(warningType);
                if(wtTypeList != null && !wtTypeList.isEmpty()){
                     WarningTypeVo warningTypeVo = wtTypeList.get(0);
                     currentQuestionId  = warningTypeVo != null ? warningTypeVo.getQuestionId() : "" ;
                     currentVersion  = warningTypeVo != null ? warningTypeVo.getQuestionVersion() : "" ;
                }
                if((!ValidatorUtil.isNullOrEmpty(currentQuestionId)) && (!ValidatorUtil.isNullOrEmpty(currentVersion))){
                       String versionAnswerOld = asstAnswerService.findAnswerVersionByWarningIdAndQuestionId(warningId, currentQuestionId);
                       if((!ValidatorUtil.isNullOrEmpty(versionAnswerOld)) &&
                              (!versionAnswerOld.equals(currentVersion))){
                         sameVersion = BusinessConst.Flag.Y;
                       }
                }
            } 
         }catch(Exception e){
            log.error("Error occur in while process checkAnswerVersionAndCurrentVersion : " + e.getMessage(), e);
        }
        return sameVersion;
    }

    @Override
    public List<AsstTopicVo> findQuestionQualitative(AsstTopicVo filter) throws Exception {
      List<AsstTopicVo> asstTopicVoList = new ArrayList<AsstTopicVo>();
        if (log.isInfoEnabled()) {
            log.info("AsstQuestionBusinessImpl.findQuestionQualitative");
            if(filter != null){
                log.info("getWarningHeaderId =>" + filter.getWarningHeaderId());
                log.info("getWarningId =>" + filter.getWarningId());
                log.info("getWarningType =>" + filter.getWarningType());
                log.info("getInfoStatus =>" + filter.getInfoStatus());
            }
        }
//-----1. find topic by question_id and version       
        int warningId = filter.getWarningId();
        String versionAnswer = null;
        String questionIdAnswer = null;
        HashMap<String,String> asstRelation = null;
        String warningDateStr = "";
           if(filter.getWarningId() > 0){
            WarningInfoVo currentInfoVo = warningInfoService.findWarningInfoObject(filter.getWarningId());
            warningDateStr = currentInfoVo != null ? currentInfoVo.getWarningDateStr(): "";
            if(currentInfoVo == null || ValidatorUtil.isNullOrEmpty(currentInfoVo.getAnswerQuestionId()) || ValidatorUtil.isNullOrEmpty(currentInfoVo.getAnswerQuestionVersion())){
                //---------- LASTED VERSION
                   List<WarningTypeVo> warningTypeVoList =   warningTypeService.findWarningTypeByWarningType(BusinessConst.WarningTypeCode.EWSQ);
                    if(!warningTypeVoList.isEmpty() && warningTypeVoList.size()>= 1){
                        WarningTypeVo wtVo = warningTypeVoList.get(0);//--- It should be have 1 record
                        questionIdAnswer = wtVo != null ? wtVo.getQuestionId() : "";
                        versionAnswer = wtVo != null ? wtVo.getQuestionVersion() : "";
                    }
                }else{
                    questionIdAnswer = currentInfoVo.getAnswerQuestionId();
                    versionAnswer = currentInfoVo.getAnswerQuestionVersion();
                }
           } //END Check filter.getWarningId() > 0
           log.info("EWSQ questionIdAnswer =>" + questionIdAnswer);
           log.info("EWSQ versionAnswer =>" + versionAnswer);
//------2. find subtopic by list of topic and question_id and version
           if((!ValidatorUtil.isNullOrEmpty(questionIdAnswer))&&(!ValidatorUtil.isNullOrEmpty(versionAnswer)) && (warningId > 0)){
               asstTopicVoList = asstQuestionService.findTopicByQuestion(questionIdAnswer, versionAnswer);
                if (asstTopicVoList != null) {
                    List<Integer> topicIdList = new ArrayList<Integer>();
                    for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                        asstTopicVo.setWarningType(filter.getWarningType());
                        asstTopicVo.setTopicDesc(ThaiCutHelper.wordwrap(asstTopicVo.getTopicDesc(), MAX_LENGTH_TOPIC_DESC));
                        topicIdList.add(asstTopicVo.getTopicId());//---EWSQ Topic
                    }
                    if (!topicIdList.isEmpty()) {
                    List<String> data = new ArrayList<String>();
                    data.add(BusinessConst.UserRole.CO_BCM);
                    data.add(BusinessConst.UserRole.BCM);
                    String roleCode = StringUtil.genSqlInStr(data);
                    //--Start--- For Check Have Answer BCM
                    AsstAnswerVo filterCheck = new AsstAnswerVo();
                    filterCheck.setWarningId(warningId);
                    filterCheck.setQuestionId(questionIdAnswer);
                    filterCheck.setVersion(versionAnswer);
                    List<AsstAnswerVo> checkAnster = asstAnswerService.findAsstAnswerForSendDataByRole(filterCheck, roleCode);
                    if(checkAnster == null || checkAnster.isEmpty() || BusinessConst.Flag.Y.equals(filter.getRequireOldAnswer())){
                        data = new ArrayList<String>();
                        data.add(BusinessConst.UserRole.RM);
                        data.add(BusinessConst.UserRole.AE);
                        data.add(BusinessConst.UserRole.AO);
                        data.add(BusinessConst.UserRole.CO_RM);
                        data.add(BusinessConst.UserRole.CO_AE);
                        data.add(BusinessConst.UserRole.CO_AO);
                        roleCode = StringUtil.genSqlInStr(data);
                    }
                    //--END----------------------------
                    List<Integer> subtopicIdList = null;
                    List<AsstSubtopicVo> asstSubtopicQualiList = asstQuestionService.findSubtopicByTopic(topicIdList, questionIdAnswer, versionAnswer, warningId,roleCode);
                    if (asstSubtopicQualiList != null) {
                        subtopicIdList = new ArrayList<Integer>();
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicQualiList) {
                            subtopicIdList.add(asstSubtopicVo.getSubTopicId());
                        }
                        List<AsstChoiceVo> asstChoiceVoList = asstQuestionService.findChoiceByFilter(topicIdList, subtopicIdList, questionIdAnswer, versionAnswer);
                        ArrayList<AsstChoiceVo> asstChoiceList;
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicQualiList) {
                            asstSubtopicVo.setSubTopicDesc(ThaiCutHelper.wordwrap(asstSubtopicVo.getSubTopicDesc(), MAX_LENGTH_SUB_TOPIC_DESC));
                            asstChoiceList = new ArrayList<AsstChoiceVo>();
                            for (AsstChoiceVo asstChoiceVo : asstChoiceVoList) {
                                if (asstSubtopicVo.getQuestionId().equals(asstChoiceVo.getQuestionId()) && asstSubtopicVo.getTopicId() == asstChoiceVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstChoiceVo.getSubTopicId() && asstSubtopicVo.getVersion().equals(asstChoiceVo.getVersion())) {
                                    asstChoiceVo.setChoiceDesc(ThaiCutHelper.wordwrap(asstChoiceVo.getChoiceDesc(), MAX_LENGTH_CHOICE_DESC));
                                    asstChoiceList.add(asstChoiceVo);
                                }
                            }
                            asstSubtopicVo.setAsstChoiceVoList(asstChoiceList);
                        }
                    }
                    ArrayList<AsstSubtopicVo> asstSubtopicList;
                    for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                        asstSubtopicList = new ArrayList<AsstSubtopicVo>();
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicQualiList) {
                            asstSubtopicVo.setWarningId(warningId);
                            if (asstTopicVo.getQuestionId().equals(asstSubtopicVo.getQuestionId()) && asstTopicVo.getTopicId() == asstSubtopicVo.getTopicId() && asstTopicVo.getVersion().equals(asstSubtopicVo.getVersion())) {
                                asstSubtopicList.add(asstSubtopicVo);
                            }
                        }
                        asstTopicVo.setAsstSubtopicVoList(asstSubtopicList);
                        asstTopicVo.setAnswerVersion(versionAnswer);
                        asstTopicVo.setWarningDateStr(warningDateStr);
                    }  
                    //------------------- FIND TRIGGER ----------------------//
                    log.info("-------------------------- Trigger --------------------------------------"); 
                    //----FIND TRIG QUESTION & VERTION
                    List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ);
                    List<WarningInfoVo>   warningInfoTrigList = warningInfoService.findWarningInfoAllTrigByHeaderIdAndQualiId(filter.getWarningHeaderId() , filter.getWarningId());
                    HashMap<String,String> questionAndVersionMap = new HashMap<String, String>();
                    List<String> trigCodeList = new ArrayList<String>();
                    if(warningTypeVoList != null){
                          for(WarningTypeVo typeVo : warningTypeVoList){
                              String trigQuest = typeVo.getQuestionId();
                              String trigVersion =   typeVo.getQuestionVersion();
                              trigCodeList.add(typeVo.getWarningTypeCode());
                                  if(!questionAndVersionMap.containsKey(typeVo.getQuestionId())){
                                         if(warningInfoTrigList != null){
                                              for(WarningInfoVo info : warningInfoTrigList){
                                                    if(info.getWarningType().equals(typeVo.getWarningTypeCode()) 
                                                            && info.getQuestionId() != null && info.getQuestionId().equals(trigQuest)
                                                              && info.getVersion() != null &&  !"".equals(info.getVersion())  ){
                                                        trigVersion = info.getVersion();
                                                        break;
                                                    }
                                              }
                                             
                                         }
                                  }
                              questionAndVersionMap.put(trigQuest, trigVersion);
                          }
                    } 
                    List<AsstTopicVo> asstTopicTrigVoList = new ArrayList<AsstTopicVo>();
                    HashMap<Integer,List<AsstTopicVo>> asstTopicTrigVoListAllMap = new HashMap<Integer, List<AsstTopicVo>>();
                    HashMap<String,WarningInfoVo> trigWarningInfoMap = new HashMap<String, WarningInfoVo>();
                    List<AsstSubtopicVo> asstSubtopicTrigList = null;
                    if(subtopicIdList != null && trigCodeList != null){
                          //-- Start- Find warningId of Trig under quali--------------------
                          List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoActiveByHeaderAndWarningTypeList(filter.getWarningHeaderId(), trigCodeList,filter.getWarningId());
                          for (WarningInfoVo warningInfoVo : warningInfoVoList) {
                                trigWarningInfoMap.put(warningInfoVo.getWarningType(), warningInfoVo);
                          } 
                    //------END------------------ TEST PRINT --------------------//
                          //-- END- Find warningId of Trig under quali--------------------
                          for(Integer id : subtopicIdList){
                               String triggerCode = BusinessConst.WarningTypeCode.Trigger+id;
                               String triggerItemForWarningType = MoneyUtil.convertNumberToStringByFormat(id, MoneyUtil.patternTrigger);
                               String triggerCodeForWarningType = BusinessConst.WarningTypeCode.TRIG.concat(triggerItemForWarningType);
                               if(!questionAndVersionMap.isEmpty() && questionAndVersionMap.containsKey(triggerCode)){
                                  String  trigVersion = (String)questionAndVersionMap.get(triggerCode);
                                  asstTopicTrigVoList = asstQuestionService.findTopicByQuestion(triggerCode, trigVersion);
                                  //---------------------------
                                  int warningTriggerId = 0;
                                  if (asstTopicTrigVoList != null) {
                                    List<Integer> trigTopicIdList = new ArrayList<Integer>();
                                    for (AsstTopicVo asstTopicVo : asstTopicTrigVoList) {
                                        asstTopicVo.setWarningType(filter.getWarningType());
                                        asstTopicVo.setTopicDesc(ThaiCutHelper.wordwrap(asstTopicVo.getTopicDesc(), MAX_LENGTH_TOPIC_DESC));
                                        trigTopicIdList.add(asstTopicVo.getTopicId());//---Trig Topic
                                    }
                                    if (!trigTopicIdList.isEmpty()) {
                                          //---Trig SubTopic : Loop map and trigId  warningIdTrig
                                        List<Integer> subtopicTrigIdList = null;
                                        if(!trigWarningInfoMap.isEmpty() && trigWarningInfoMap.containsKey(triggerCodeForWarningType)){
                                            WarningInfoVo warningIdTrigInfo = (WarningInfoVo)trigWarningInfoMap.get(triggerCodeForWarningType);
                                            warningTriggerId = warningIdTrigInfo != null ? warningIdTrigInfo.getWarningId(): 0;
                                        }
                                         asstSubtopicTrigList = asstQuestionService.findSubtopicByTopic(trigTopicIdList, triggerCode, trigVersion, warningTriggerId,roleCode);
                                        if (asstSubtopicTrigList != null) {
                                            subtopicTrigIdList = new ArrayList<Integer>();
                                            for (AsstSubtopicVo asstSubtopicVo : asstSubtopicTrigList) {
                                                subtopicTrigIdList.add(asstSubtopicVo.getSubTopicId());
                                            }//END FOR
                                        }//END asstSubtopicTrigList != null
                                        List<AsstChoiceVo> asstChoiceVoTrigList = asstQuestionService.findChoiceByFilter(trigTopicIdList, subtopicTrigIdList, triggerCode, trigVersion);
                                        ArrayList<AsstChoiceVo> asstChoiceList;
                                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicTrigList) {
                                            asstSubtopicVo.setSubTopicDesc(ThaiCutHelper.wordwrap(asstSubtopicVo.getSubTopicDesc(), MAX_LENGTH_SUB_TOPIC_DESC));
                                            asstChoiceList = new ArrayList<AsstChoiceVo>();
                                            for (AsstChoiceVo asstChoiceVo : asstChoiceVoTrigList) {
                                                if (asstSubtopicVo.getQuestionId().equals(asstChoiceVo.getQuestionId()) && asstSubtopicVo.getTopicId() == asstChoiceVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstChoiceVo.getSubTopicId() && asstSubtopicVo.getVersion().equals(asstChoiceVo.getVersion())) {
                                                    asstChoiceVo.setChoiceDesc(ThaiCutHelper.wordwrap(asstChoiceVo.getChoiceDesc(), MAX_LENGTH_CHOICE_DESC));
                                                    asstChoiceList.add(asstChoiceVo);
                                                }
                                            }
                                            asstSubtopicVo.setAsstChoiceVoList(asstChoiceList);
                                            asstSubtopicVo.setAnswerSubtopicChoice(asstSubtopicVo.getAnswer());
                                            asstSubtopicVo.setChoiceReasonSubtopic(asstSubtopicVo.getChoiceReason());
                                        }

                                    }//END !trigTopicIdList.isEmpty()
                                  }//END asstTopicTrigVoList != null  

                                  ArrayList<AsstSubtopicVo> asstSubTopicTrigDataList;
                                  for (AsstTopicVo asstTopicVo : asstTopicTrigVoList) {
                                        asstSubTopicTrigDataList = new ArrayList<AsstSubtopicVo>();
                                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicTrigList) {
                                            asstSubtopicVo.setWarningId(warningTriggerId);
                                            if (asstTopicVo.getQuestionId().equals(asstSubtopicVo.getQuestionId()) && asstTopicVo.getTopicId() == asstSubtopicVo.getTopicId() && asstTopicVo.getVersion().equals(asstSubtopicVo.getVersion())) {
                                                asstSubTopicTrigDataList.add(asstSubtopicVo);
                                            }
                                        }
                                        asstTopicVo.setAsstSubtopicVoList(asstSubTopicTrigDataList);
                                        asstTopicVo.setAnswerVersion(trigVersion);
                                  }  
                                  //----------------------------
                               }//END if containsKey
                               log.info("put----------------> " + id);
                               asstTopicTrigVoListAllMap.put(id, asstTopicTrigVoList);
                          }//END for(Integer id : subtopicIdList)
                    }//END subtopicIdList != null && trigCodeList != null
                     ///------------------------  Trigger add into Quali ----------------------//
                      if(!asstTopicTrigVoListAllMap.isEmpty()){
                            for (AsstTopicVo asstTopicQualiVo : asstTopicVoList) {
                                for(AsstSubtopicVo qualiSubTopic : asstTopicQualiVo.getAsstSubtopicVoList()){
                                   //for(AsstTopicVo asstTopicTrigVo : asstTopicTrigVoList){
                                     if(asstTopicTrigVoListAllMap.containsKey(qualiSubTopic.getSubTopicId())){
                                         List<AsstTopicVo> trigDataTopic = asstTopicTrigVoListAllMap.get(qualiSubTopic.getSubTopicId());
                                        for(AsstTopicVo topicTrigData : trigDataTopic){
                                                 if(topicTrigData.getAsstSubtopicVoList() != null){
                                                        for(AsstSubtopicVo trigSubtopicVo : topicTrigData.getAsstSubtopicVoList()){
                                                             qualiSubTopic.setAsstSubtopicChoiceVoList(trigSubtopicVo.getAsstChoiceVoList());
                                                             qualiSubTopic.setAnswerSubtopicChoice(trigSubtopicVo.getAnswerSubtopicChoice());
                                                             qualiSubTopic.setChoiceReasonSubtopic(trigSubtopicVo.getChoiceReasonSubtopic());
                                                        break;
                                                    }
                                                }
                                        }
                                     }
                                       
                                   //}//END FOR asstTopicTrigVoList
                                }//END asstTopicQualiVo.getAsstSubtopicVoList()
                            }//END asstTopicVoList
                      }//END !asstTopicTrigVoListAllMap.isEmpty()
                 }//END !topicIdList.isEmpty()
                   }//END asstTopicVoList != null
                }//END Quali id&version is not null
        
        return asstTopicVoList;
    }

    @Override
    public String saveAsstAnswerQuali(List<AsstAnswerVo> asstAnswerVoList, UserData user, String actionMode, String infoStatus, String warningType) throws Exception, RenowalException {
       if (log.isInfoEnabled()) {
            log.info("saveAsstAnswerQuali");
        }

        if (asstAnswerVoList != null) {
            Map warningInfoMap = new HashMap();
            int warningHeaderId = 0;
            int warningId = 0;
            String cifNo = "";
            String roleCode = null;
             //---------For Prepare DELETE OLD ROLE : AO , AE , RM / BCM --------//
               List<String> data = null;
                if(!BusinessConst.UserRole.BCM.equals(user.getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(user.getRoleId())){
                      data = new ArrayList<String>();
                      data.add(BusinessConst.UserRole.RM);
                      data.add(BusinessConst.UserRole.AE);
                      data.add(BusinessConst.UserRole.AO);
                      data.add(BusinessConst.UserRole.CO_RM);
                      data.add(BusinessConst.UserRole.CO_AE);
                      data.add(BusinessConst.UserRole.CO_AO);
                      roleCode = StringUtil.genSqlInStr(data);
                }else{
                      data = new ArrayList<String>();
                      //data.add(user.getRoleId());
                      data.add(BusinessConst.UserRole.BCM);
                      data.add(BusinessConst.UserRole.CO_BCM);
                      roleCode = StringUtil.genSqlInStr(data);
                }
            for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                warningId = asstAnswerVo.getWarningId();
                warningHeaderId = asstAnswerVo.getWarningHeaderId();
                cifNo = asstAnswerVo.getCifNo();
                asstAnswerVo.setUpdatedBy(user.getEmpNo());
                asstAnswerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                asstAnswerVo.setRole(user.getRoleId());
                List<AsstAnswerVo> asstAnswerVoListForCheck = asstAnswerService.findAsstAnswerByPKAndManyRole(asstAnswerVo ,roleCode );
                if (asstAnswerVoListForCheck != null && asstAnswerVoListForCheck.size() > 0) {
                    asstAnswerService.updateQuestion(asstAnswerVo,data);
                } else {
                    asstAnswerVo.setCreatedBy(user.getEmpNo());
                    asstAnswerVo.setCreatedDate(DateUtil.getCurrentDateTime());
                    asstAnswerService.saveQuestion(asstAnswerVo);
              }

                warningInfoMap.put(asstAnswerVo.getWarningId(), asstAnswerVo);
          }
                String statusXxFlag;
                String currentStatusInfo;
                WarningInfoVo warningInfoVo = new WarningInfoVo();
                warningInfoVo.setWarningId(warningId);
                warningInfoVo.setWarningType(warningType);
                warningInfoVo.setUpdatedBy(user.getEmpNo());
                warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                warningInfoVo.setRoleCode(user.getRoleId());
                //---Start--  ANN Change 23/06/2015  Case : Add QuestionId and question version
                if (warningInfoMap != null && warningInfoMap.size() > 0) {
                   AsstAnswerVo dataAnswer = (AsstAnswerVo)warningInfoMap.get(warningId);
                   if(dataAnswer != null){
                        warningInfoVo.setAnswerQuestionId(dataAnswer.getQuestionId());
                        warningInfoVo.setAnswerQuestionVersion(dataAnswer.getVersion());
                   }
                }
                //---- END ---//
                if ("Save".equals(actionMode)) {
                    currentStatusInfo = getSeqInfoStatus(infoStatus, warningType, actionMode);
                    warningInfoVo.setStatus(currentStatusInfo);
                    warningInfoVo.setHolderId(null);
                    if (BusinessConst.Flag.SCMP.equals(currentStatusInfo) || BusinessConst.Flag.CMF.equals(currentStatusInfo)) {
                        warningInfoVo.setHolderId(user.getEmpNo());
                    }
                    warningInfoVo.setHolderRole(getHolderRole(currentStatusInfo, "",user.getRoleId()));
                } else {
                    currentStatusInfo = infoStatus;
                    warningInfoVo.setStatus(infoStatus);
                    warningInfoVo.setHolderId(user.getEmpNo());
                    warningInfoVo.setHolderRole(user.getRoleId());
                    if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
                        warningInfoVo.setStatus(BusinessConst.Flag.RMP);
                    } else if (BusinessConst.Flag.BCA.equals(infoStatus)) {
                        warningInfoVo.setStatus(BusinessConst.Flag.CMP);
                    } else if (BusinessConst.Flag.CMF.equals(infoStatus)) {
                        warningInfoVo.setStatus(BusinessConst.Flag.SCMP);
                    }
                }
                 warningInfoService.updateStatusAndQuestionByWarningIdAndType(warningInfoVo);

                if(warningId != 0 &&!ValidatorUtil.isNullOrEmpty(warningInfoVo.getStatus()) && !ValidatorUtil.isNullOrEmpty(roleCode)){
                     List<ActionHistoryVo> dataHistoryList =  actionHistoryService.findDataByWarningIdAndStatusAndRoleCode(warningId, warningInfoVo.getStatus(), roleCode);
                     if(dataHistoryList != null && !dataHistoryList.isEmpty()){
                         actionHistoryService.deleteActionHistoryByWarningIdAndStatusAndRoleCode(warningId, warningInfoVo.getStatus(), roleCode);
                     }
                }
                //---- Find DPD -----//
                log.info("warningHeaderId =" + warningHeaderId + ": cifNo =" + cifNo );
                WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginal(warningHeaderId, cifNo);
                 
                ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
                actionHistoryVo.setWarningId(warningId);
                actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
                actionHistoryVo.setActionBy(user.getEmpNo());
                actionHistoryVo.setActionCode(actionMode);
                actionHistoryVo.setActionDetail(warningType);
                actionHistoryVo.setStatus(warningInfoVo.getStatus());
                actionHistoryVo.setRoleCode(user.getRoleId());
                if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                  actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
                }else{
                  actionHistoryVo.setDpd(null);
                }
                actionHistoryService.saveData(actionHistoryVo);
                
                WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
                warningHeaderVo.setWarningHeaderId(warningHeaderId);
                warningHeaderVo.setUpdatedBy(user.getEmpNo());
                warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                statusXxFlag = getXxFlagForHeader(currentStatusInfo, warningType, warningHeaderId);
                warningHeaderVo.setEwsFlag(statusXxFlag); //EWSQ
                warningHeaderVo.setQualiFlg(statusXxFlag);
                if (BusinessConst.Flag.INPROCESS.equals(statusXxFlag)) {
                    checkAllXxFlagForUpdateHeaderStatus(warningHeaderId, user.getEmpNo(), BusinessConst.GO_ACTION.NAXT);
                }
 log.info(" statusXxFlag == > " + statusXxFlag);                
                warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
                return warningInfoVo.getStatus();
        }

        return null;
    }
    
    @Override
    public void saveAsstAnswerTrigAndKeepAnswer(List<WarningInfoVo> warningTrigList, List<AsstAnswerVo> asstAnswerVoTrigList, UserData user, String actionMode, String infoStatus, String warningType, int cif, int headerId , int qualiWarningId , String eventTransaction) throws Exception, RenowalException {
        log.info("----------------------- saveAsstAnswerTrigAndKeepAnswer ---------------------");
        log.info("cif = " + cif);
        log.info("headerId = " + headerId);
        log.info("warningTrigList.size() = " + warningTrigList != null ? warningTrigList.size() : 0);
        log.info("user.getRoleId() = " + user.getRoleId());
        String currentStatusInfo = null;
        String roleCode = null;
        try{
            
            //----------------FIND ANSWER BY HEADER ID
            if(headerId != 0){
              //---------For Prepare DELETE OLD ROLE : AO , AE , RM / BCM --------//
               List<String> data = null;
                if(!BusinessConst.UserRole.BCM.equals(user.getRoleId()) && !BusinessConst.UserRole.CO_BCM.equals(user.getRoleId()) &&
                         (BusinessConst.TEXT_STATIC.EVENT_SAVE.equals(eventTransaction))){
                      data = new ArrayList<String>();
                      data.add(BusinessConst.UserRole.RM);
                      data.add(BusinessConst.UserRole.AE);
                      data.add(BusinessConst.UserRole.AO);
                      data.add(BusinessConst.UserRole.CO_RM);
                      data.add(BusinessConst.UserRole.CO_AE);
                      data.add(BusinessConst.UserRole.CO_AO);
                      roleCode = StringUtil.genSqlInStr(data);
                }else{
                      data = new ArrayList<String>();
                      //data.add(user.getRoleId());
                      data.add(BusinessConst.UserRole.CO_BCM);
                      data.add(BusinessConst.UserRole.BCM);
                      roleCode = StringUtil.genSqlInStr(data);
                }
                log.info("roleCode= " + roleCode);
                if(!ValidatorUtil.isNullOrEmpty(roleCode)){
                  AsstAnswerVo filter = new AsstAnswerVo();
                  filter.setWarningHeaderId(headerId);
                  filter.setWarningId(qualiWarningId);
                  List<AsstAnswerVo> checkAnsByRoleandHeader =  asstAnswerService.findAsstAnswerByHeaderIdForTrigger(filter, roleCode);
                  log.info("checkAnsByRoleandHeader.size() = " + checkAnsByRoleandHeader == null ? 0 : checkAnsByRoleandHeader.size());
                  
                  if(checkAnsByRoleandHeader != null && !checkAnsByRoleandHeader.isEmpty()){
                            StringBuffer warningIdSQL = new StringBuffer();
                            for (int i = 0; i < checkAnsByRoleandHeader.size() ; i++) {
                                AsstAnswerVo dataAns = (AsstAnswerVo)checkAnsByRoleandHeader.get(i);
                                if(dataAns != null && dataAns.getWarningId() != 0){
                                if (i > 0) {
                                    warningIdSQL.append(",");
                                }
                                warningIdSQL.append( dataAns.getWarningId() );
                                }
                            }
                     log.info("warningIdSQL.toString() = " + warningIdSQL != null ? warningIdSQL.toString() : ""); 
                    if( warningIdSQL != null &&  !ValidatorUtil.isNullOrEmpty(warningIdSQL.toString()) && !ValidatorUtil.isNullOrEmpty(roleCode)){
                        asstAnswerService.deleteAnswerByWarningIdAndRoleCode(warningIdSQL.toString(),roleCode);
                        actionHistoryService.deleteActionHistoryByWarningIdAndRoleCode(warningIdSQL.toString(),roleCode);
                        warningInfoService.deleteWarningInfoId(headerId,warningIdSQL.toString());
                    }
                  }
                }
            }
           //------------- FIND WARNING TRIG BY HEADER IN TBL_WARNING_INFO
            List<WarningInfoVo> oldWarningTrigInfoList = null;
             if(BusinessConst.TEXT_STATIC.EVENT_EDIT.equals(eventTransaction)){
                List<String> dataRoleCodeAnswer = new ArrayList<String>();
                dataRoleCodeAnswer.add(BusinessConst.UserRole.CO_BCM);
                dataRoleCodeAnswer.add(BusinessConst.UserRole.BCM);
                String roleCodeAnswer = StringUtil.genSqlInStr(dataRoleCodeAnswer);
                oldWarningTrigInfoList = warningInfoService.findWarningInfoAllTrigByHeaderIdAndRoleCode(headerId,roleCodeAnswer,qualiWarningId);
             }else{
                oldWarningTrigInfoList = warningInfoService.findWarningInfoAllTrigByHeaderIdAndQualiId(headerId,qualiWarningId);
             }
            HashMap<String,Integer> oldTrgWarningIdMap = null;
            if(!oldWarningTrigInfoList.isEmpty()){
                oldTrgWarningIdMap = new HashMap<String, Integer>();
                for(WarningInfoVo trigVo : oldWarningTrigInfoList){
                    log.info("trigVo.getWarningType() = " + trigVo.getWarningType()  + "  getWarningId :" + trigVo.getWarningId() );
                    oldTrgWarningIdMap.put(trigVo.getWarningType(), trigVo.getWarningId());
                }
            }
             //------------- INSERT TRIG TO TBL_WARNING_INFO
            if(!warningTrigList.isEmpty()){
                //--Start--- R11 SLA_MASTER
                 HashMap<String,Integer> slaMasterTrigger = new HashMap<String, Integer>();
                 List<WarningTypeVo> warningTypeMaster = warningTypeService.findWarningTypeForUnderWarningTypeEwsq();
                 if(warningTypeMaster != null && !warningTypeMaster.isEmpty()){
                       for(WarningTypeVo wt : warningTypeMaster){
                           slaMasterTrigger.put(wt.getWarningTypeCode(), wt.getSla());
                       }
                 }
                //--End--- R11 SLA_MASTER  
                 for(WarningInfoVo infoVo : warningTrigList){
                   log.info("infoVo.getWarningType() = " + infoVo.getWarningType() );
                       if ("Save".equals(actionMode)) {
                            currentStatusInfo = getSeqInfoStatus(infoStatus, warningType, actionMode);
                            infoVo.setStatus(currentStatusInfo);
                            infoVo.setHolderId(null);
                            infoVo.setHolderRole(getHolderRole(currentStatusInfo, "",user.getRoleId()));
                        } else {
                            currentStatusInfo = infoStatus;
                            infoVo.setStatus(currentStatusInfo);
                            infoVo.setHolderId(user.getEmpNo());
                            infoVo.setHolderRole(user.getRoleId());
                            if (BusinessConst.Flag.N.equals(infoStatus) || BusinessConst.Flag.BRMP.equals(infoStatus)) {
                                infoVo.setStatus(BusinessConst.Flag.RMP);
                                currentStatusInfo = BusinessConst.Flag.RMP;
                            } 
                        }
                     infoVo.setUpdatedBy(user.getEmpNo());
                     infoVo.setUpdatedDate(DateUtil.getCurrentDateTime());   
                     infoVo.setRoleCode(user.getRoleId());
                    if(oldTrgWarningIdMap != null && oldTrgWarningIdMap.containsKey(infoVo.getWarningType())){//--- OLD WARNING TYPE
                        infoVo.setWarningId(oldTrgWarningIdMap.get(infoVo.getWarningType()));
                        warningInfoService.updateStatusByWarningIdAndTypeRoleCodeAns(infoVo);
                    }else{
                        infoVo.setCreatedBy(user.getEmpNo());
                        infoVo.setCreatedDate(DateUtil.getCurrentDateTime());
                        if(slaMasterTrigger != null && !slaMasterTrigger.isEmpty()){ //----- R11 SLA_MASTER
                           if(slaMasterTrigger.containsKey(infoVo.getWarningType())){
                                   infoVo.setSlaMaster(slaMasterTrigger.get(infoVo.getWarningType()));
                           }
                        }
                        warningInfoService.saveWarningInfo(infoVo);
                    }
               }
            }
            //------------- SELECT WARNING_ID TRIG FOR INSERT TBL_ASST_ANSWER >>> AFTER INSER & UPDATE INFO
            List<WarningInfoVo> newWarningTrigInfoList  = warningInfoService.findWarningInfoAllTrigByHeaderIdAndQualiId(headerId,qualiWarningId);
            HashMap<String,Integer> trgWarningIdMap = null;
            if(!newWarningTrigInfoList.isEmpty()){
                trgWarningIdMap = new HashMap<String, Integer>();
                for(WarningInfoVo trigVo : newWarningTrigInfoList){
                          log.info("getWarningType = " + trigVo.getWarningType()  + "  getWarningId :" + trigVo.getWarningId() );
                          trgWarningIdMap.put(trigVo.getWarningType(), trigVo.getWarningId());
                }
            }
            //------------- INSERT TBL_ASST_ANSWER
            if(asstAnswerVoTrigList != null && !trgWarningIdMap.isEmpty()){
                 Integer warningTrgId = 0;
                  for(AsstAnswerVo trigAsstAnswerVo : asstAnswerVoTrigList){
                   log.info("------- loop find warning ID trigAsstAnswerVo.getWarningType() = " +trigAsstAnswerVo.getWarningType());
                     if(trgWarningIdMap.containsKey(trigAsstAnswerVo.getWarningType())){
                        warningTrgId = (Integer)trgWarningIdMap.get(trigAsstAnswerVo.getWarningType());
                         log.info("warningTrgId = " +warningTrgId);
                        if(warningTrgId != null && warningTrgId > 0){
                         trigAsstAnswerVo.setWarningId(warningTrgId);
                         trigAsstAnswerVo.setCreatedBy(user.getEmpNo());
                         trigAsstAnswerVo.setCreatedDate(DateUtil.getCurrentDateTime());
                         trigAsstAnswerVo.setUpdatedBy(user.getEmpNo());
                         trigAsstAnswerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                         String roleCodeTrig = user.getRoleId();//getRoleForAnswer(user.getRoleId(), infoStatus);
                         trigAsstAnswerVo.setRoleCode(roleCodeTrig);
                         trigAsstAnswerVo.setRole(roleCodeTrig);
                         trigAsstAnswerVo.setWarningHeaderId(headerId);
                         asstAnswerService.saveQuestion(trigAsstAnswerVo);
                         //---- Find DPD -----//
                         log.info("warningHeaderId =" + headerId + ": cifNo =" + cif );
                         WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginal(headerId, String.valueOf(cif));
                         log.info("currentStatusInfo = " + currentStatusInfo );
                          //------------------TBL_ACTION_HISTORY ------------------//
                           ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
                           actionHistoryVo.setWarningId(warningTrgId);
                           actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
                           actionHistoryVo.setActionBy(user.getEmpNo());
                           actionHistoryVo.setActionCode(actionMode);
                           actionHistoryVo.setActionDetail(trigAsstAnswerVo.getWarningType());
                           actionHistoryVo.setStatus(currentStatusInfo);
                           actionHistoryVo.setRoleCode(user.getRoleId());
                           if(StringUtil.isNotEmpty(voGetDPD.getDpdStr())){ //-- FOR NULL , 0
                                actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
                           }else{
                                actionHistoryVo.setDpd(null);
                           }
                           actionHistoryService.saveData(actionHistoryVo);
                        }
                     }
                 }
            }
            
        }catch(Exception e){
            log.error("Error occur in while process saveAsstAnswerTrigAndKeepAnswer : " + e.getMessage(), e);
            throw e;
        }
    }
    
    @Override
    public List<AsstTopicVo> findLatePaymentQuestionByFilter(AsstTopicVo filter) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findLatePaymentQuestionByFilter");
        }
    //  1. find topic by question_id and version
        List<AsstTopicVo> asstTopicVoList;
        int warningId = filter.getWarningId();
        log.info("warningId " + warningId);
        String versionAnswer = null;
        String questionIdAnswer = null;
           if(filter.getWarningId() > 0){
            WarningInfoVo currentInfoVo = warningInfoService.findWarningInfoObject(filter.getWarningId());
            if(currentInfoVo == null || ValidatorUtil.isNullOrEmpty(currentInfoVo.getAnswerQuestionId()) || ValidatorUtil.isNullOrEmpty(currentInfoVo.getAnswerQuestionVersion())){ 
                //---------- LASTED VERSION
                   List<WarningTypeVo> warningTypeVoList =   warningTypeService.findWarningTypeByWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
                    if(!warningTypeVoList.isEmpty() && warningTypeVoList.size()>= 1){
                         log.info("LOOP 1.1 ");
                        WarningTypeVo wtVo = warningTypeVoList.get(0);//--- It should be have 1 record
                        questionIdAnswer = wtVo != null ? wtVo.getQuestionId() : "";
                        versionAnswer = wtVo != null ? wtVo.getQuestionVersion() : "";
                    }
                }else{
                log.info("LOOP 2  ");
                    questionIdAnswer = currentInfoVo.getAnswerQuestionId();
                    versionAnswer = currentInfoVo.getAnswerQuestionVersion();
                }
           } //END Check filter.getWarningId() > 0
           log.info("Late Payment questionIdAnswer =>" + questionIdAnswer);
           log.info("Late Payment versionAnswer =>" + versionAnswer);
//        2. find subtopic by list of topic and question_id and version
            asstTopicVoList = asstQuestionService.findTopicByQuestion(questionIdAnswer, versionAnswer);
            if (asstTopicVoList != null) {
                List<Integer> topicIdList = new ArrayList<Integer>();
                for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                    asstTopicVo.setWarningType(filter.getWarningType());
                    asstTopicVo.setTopicDesc(ThaiCutHelper.wordwrap(asstTopicVo.getTopicDesc(), MAX_LENGTH_TOPIC_DESC));
                    topicIdList.add(asstTopicVo.getTopicId());
                }

                if (!topicIdList.isEmpty()) {
//                start check warningId case default data form old warningId when current warningId not answer
                    boolean checkVersion = false;
                    if (EWSConstantValue.STATUS_DEFAULT_ANSWER.contains(filter.getInfoStatus())) {
                        List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerByWarningIdAndQuestId(warningId, questionIdAnswer);
                        if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
                            for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                                if (versionAnswer.equals(asstAnswerVo.getVersion())) {
                                    checkVersion = true;
                                    break;
                                }
                            }
                        }
                        if (asstAnswerVoList == null || asstAnswerVoList.size() <= 0 || !checkVersion) {
                            WarningInfoVo warningInfoVo = new WarningInfoVo();
                            warningInfoVo.setCifNo(filter.getCifNo());
                            warningInfoVo.setWarningType(filter.getWarningType());
                            warningInfoVo.setVersion(filter.getVersion());
                            Integer maxWarningId = warningInfoService.findMaxWarningId(warningInfoVo);
                            if (maxWarningId != null) {
                                warningId = maxWarningId.intValue();
                            }
                        }
                    }
//                end check
                    List<String> data = new ArrayList<String>();
                    data.add(BusinessConst.UserRole.BCM);
                    data.add(BusinessConst.UserRole.CO_BCM);
                    String roleCode = StringUtil.genSqlInStr(data);
                    //--Start--- For Check Have Answer BCM
                    AsstAnswerVo filterCheck = new AsstAnswerVo();
                    filterCheck.setWarningId(warningId);
                    filterCheck.setQuestionId(questionIdAnswer);
                    filterCheck.setVersion(versionAnswer);
                    List<AsstAnswerVo> checkAnster = asstAnswerService.findAsstAnswerForSendDataByRole(filterCheck, roleCode);
                    
                    /*Begin Add by Pound สำหรับ ActionForm 2 แบบมี LatePayment */
                    if(!filter.isSelectBCM()){
                        checkAnster = null;
                    }
                    /*End Add by Pound สำหรับ ActionForm 2 แบบมี LatePayment */
                    
                    if(checkAnster == null || checkAnster.isEmpty() || BusinessConst.Flag.Y.equals(filter.getRequireOldAnswer())){
                        data = new ArrayList<String>();
                        data.add(BusinessConst.UserRole.RM);
                        data.add(BusinessConst.UserRole.AE);
                        data.add(BusinessConst.UserRole.AO);
                        
                        data.add(BusinessConst.UserRole.CO_RM);
                        data.add(BusinessConst.UserRole.CO_AE);
                        data.add(BusinessConst.UserRole.CO_AO);
                        
                        roleCode = StringUtil.genSqlInStr(data);
                    }
                    //--END----------------------------
                    List<AsstSubtopicVo> asstSubtopicVoList = asstQuestionService.findSubtopicByTopic(topicIdList, questionIdAnswer, versionAnswer, warningId,roleCode);
                   
                    if (asstSubtopicVoList != null) {
                       
                        List<Integer> subtopicIdList = new ArrayList<Integer>();
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                            subtopicIdList.add(asstSubtopicVo.getSubTopicId());
                        }

                        List<AsstChoiceVo> asstChoiceVoList = asstQuestionService.findChoiceByFilter(topicIdList, subtopicIdList, questionIdAnswer, versionAnswer);
                        ArrayList<AsstChoiceVo> asstChoiceList;
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                            asstSubtopicVo.setSubTopicDesc(ThaiCutHelper.wordwrap(asstSubtopicVo.getSubTopicDesc(), MAX_LENGTH_SUB_TOPIC_DESC));
                            asstChoiceList = new ArrayList<AsstChoiceVo>();
                            for (AsstChoiceVo asstChoiceVo : asstChoiceVoList) {
                                if (asstSubtopicVo.getQuestionId().equals(asstChoiceVo.getQuestionId()) && asstSubtopicVo.getTopicId() == asstChoiceVo.getTopicId() && asstSubtopicVo.getSubTopicId() == asstChoiceVo.getSubTopicId() && asstSubtopicVo.getVersion().equals(asstChoiceVo.getVersion())) {
                                    //--asstChoiceVo.setChoiceDesc(ThaiCutHelper.wordwrap(asstChoiceVo.getChoiceDesc(), MAX_LENGTH_CHOICE_DESC));
                                    asstChoiceVo.setChoiceDesc(""); //---ANN Use coz,not show ใช่ ไม่ใช่
                                    asstChoiceList.add(asstChoiceVo);
                                }
                            }
                            asstSubtopicVo.setAsstChoiceVoList(asstChoiceList);
                        }
                    }

                    ArrayList<AsstSubtopicVo> asstSubtopicList;
                    for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                        asstSubtopicList = new ArrayList<AsstSubtopicVo>();
                        for (AsstSubtopicVo asstSubtopicVo : asstSubtopicVoList) {
                            if (asstTopicVo.getQuestionId().equals(asstSubtopicVo.getQuestionId()) && asstTopicVo.getTopicId() == asstSubtopicVo.getTopicId() && asstTopicVo.getVersion().equals(asstSubtopicVo.getVersion())) {
                                asstSubtopicList.add(asstSubtopicVo);
                            }
                        }
                        asstTopicVo.setAsstSubtopicVoList(asstSubtopicList);
                        asstTopicVo.setAnswerVersion(versionAnswer);
                        asstTopicVo.setAnswerQuestionId(questionIdAnswer);
                    }
                }
            }
        return asstTopicVoList;
    }

    private ScoreEngineVo findDataForSendScoreLatePayment(String questionId, String version, int warningId, UserData user, String cifNo, String cifName, String warningType) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataForSendScore");
        }
        JSONArray subTopicObjGroup;
        JSONObject subTopicObject;
        JSONArray topicObjectLatePaymentGroup = new JSONArray();
        JSONObject topicObjectLatePayment  = new JSONObject();

        topicObjectLatePayment.put("LatePaymentQuestionId", questionId);
        topicObjectLatePayment.put("LatePaymentQuestionVersion", version);
        List<AsstTopicVo> asstTopicVoList = asstQuestionService.findTopicByQuestion(questionId, version);
       
        if (asstTopicVoList != null && asstTopicVoList.size() > 0) {
            AsstAnswerVo filter = new AsstAnswerVo();
            filter.setQuestionId(questionId);
            filter.setVersion(version);
            filter.setWarningId(warningId);
            
             List<String> data = new ArrayList<String>();
             data.add(BusinessConst.UserRole.BCM);
             data.add(BusinessConst.UserRole.CO_BCM);
             String roleCode = StringUtil.genSqlInStr(data);
             List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForSendDataByRole(filter,roleCode);  
             if(asstAnswerVoList == null || asstAnswerVoList.isEmpty()){
                data = new ArrayList<String>();
                data.add(BusinessConst.UserRole.RM);
                data.add(BusinessConst.UserRole.AE);
                data.add(BusinessConst.UserRole.AO);
                
                data.add(BusinessConst.UserRole.CO_RM);
                data.add(BusinessConst.UserRole.CO_AE);
                data.add(BusinessConst.UserRole.CO_AO);
                roleCode = StringUtil.genSqlInStr(data);
                asstAnswerVoList = asstAnswerService.findAsstAnswerForSendDataByRole(filter,roleCode);  
            }
                    
            log.info("findDataForSendScoreLatePayment asstAnswerVoList.size() ==" + asstAnswerVoList != null ? asstAnswerVoList.size() : 0);
            //-Start------- NOT SEND LAST TOPIC "Other" : Send to Score 
             Integer lastSubtopic = asstQuestionService.getLastSubTopic(questionId, version);
             if(lastSubtopic != null && lastSubtopic != 0 && asstAnswerVoList != null){
                for (int i=0 ; i < asstAnswerVoList.size() ; i++) {
                    AsstAnswerVo aa = (AsstAnswerVo)asstAnswerVoList.get(i);
                         if(lastSubtopic == aa.getSubTopicId()){
                              asstAnswerVoList.remove(i);
                              break;
                         }
                }
             }
            log.info("After Remove asstAnswerVoList.size() ==" + asstAnswerVoList != null ? asstAnswerVoList.size() : 0);
            //-END--------------------------------------------------------
            for (AsstTopicVo asstTopicVo : asstTopicVoList) {
                topicObjectLatePayment.put("topicId", asstTopicVo.getTopicId());
                subTopicObjGroup = new JSONArray();
                for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                    if (asstTopicVo.getTopicId() == asstAnswerVo.getTopicId()) {
                        subTopicObject = new JSONObject();
                        subTopicObject.put("subTopicId", asstAnswerVo.getSubTopicId());
                        if (asstAnswerVo.getChoiceId() > 0) {
                            subTopicObject.put("choiceId", asstAnswerVo.getChoiceId());
                        } else {
                            subTopicObject.put("choiceId", -99999999);
                        }
                        subTopicObjGroup.add(subTopicObject);
                    }
                }
               topicObjectLatePayment.put("subTopicObject", subTopicObjGroup);
               topicObjectLatePaymentGroup.add(topicObjectLatePayment);
            }
        }

        ScoreEngineVo scoreEngineVo = new ScoreEngineVo();
        scoreEngineVo.setAppId("");
        scoreEngineVo.setCustId(cifNo);
        scoreEngineVo.setCustName(cifName);
        scoreEngineVo.setRespUnitId(user.getDeptCode());
        scoreEngineVo.setQuestionId(questionId);
        scoreEngineVo.setVersion(version);
        scoreEngineVo.setLimitSize("1");
        if (!topicObjectLatePaymentGroup.isEmpty()) {
            scoreEngineVo.setTopicObjectLatePayment(topicObjectLatePaymentGroup);
        }

        return scoreEngineVo;
    }

    @Override
    public Integer getLastSubTopic(String questionId, String version) throws Exception {
       return asstQuestionService.getLastSubTopic(questionId, version);
    }

    @Override
    public void deleteAnswerByWarningIdAndRoleCode(String warningId, String roleCode) throws Exception {
       if(StringUtil.isNotEmpty(warningId) && StringUtil.isNotEmpty(roleCode)){
         asstAnswerService.deleteAnswerByWarningIdAndRoleCode("'" + warningId + "'", "'" + roleCode + "'");
       }
       
    }

    @Override
    public void sendEWSQWithLastesAnswer(int warningHeaderId, UserData user, String cifNo, Integer qualiWarningId, Integer finWarningId , String currentWarningType) throws Exception, RenowalException, ScoreEngineException {
        if (log.isInfoEnabled()) {
            log.info("sendEWSQWithLastesAnswer");
            log.info(" warningHeaderId      >> "+ warningHeaderId);
            log.info(" cifNo                >> "+ cifNo);
            log.info(" qualiWarningId       >> "+ qualiWarningId);
            log.info(" finWarningId         >> "+ finWarningId);
            log.info(" currentWarningType   >> "+ currentWarningType);
        }
        String answerVersion = null;
        String questionID = null;
        WarningInfoVo qualiInfo = null;
        String creditRatingFlg = null;
        if(qualiWarningId != null && qualiWarningId > 0){
        qualiInfo = warningInfoService.findLastVersionByWarningInfoID(qualiWarningId,BusinessConst.WarningTypeCode.EWSQ);
        if(qualiInfo != null){
            log.debug("getWarningHeaderId >> " + qualiInfo.getWarningHeaderId());
            log.debug("getWarningType >> " + qualiInfo.getWarningType());
            log.debug("getAnswerQuestionId >> " + qualiInfo.getAnswerQuestionId());
            log.debug("getAnswerQuestionVersion >> " + qualiInfo.getAnswerQuestionVersion());
            log.debug("warningTYPE QuestionId >> " + qualiInfo.getQuestionId());
            log.debug("warningTYPE version >> " + qualiInfo.getVersion());
        }
        //---- Case เพื่อรองรับการตอบแบบสอบถามเก่าที่ไม่ได้ลง QuestionID&Version ใน INFO ต้องไปหาใน ANSWER ก่อน ให้ตอบแบบสอบถามได้
        if(!ValidatorUtil.isNullOrEmpty(qualiInfo.getAnswerQuestionId()) && !ValidatorUtil.isNullOrEmpty(qualiInfo.getAnswerQuestionVersion())){
            questionID = qualiInfo.getAnswerQuestionId();
            answerVersion = qualiInfo.getAnswerQuestionVersion();
        }else if(qualiInfo.getWarningId() > 0 && (!ValidatorUtil.isNullOrEmpty(qualiInfo.getQuestionId()))){
            questionID = qualiInfo.getQuestionId();
            answerVersion = asstAnswerService.findAnswerVersionByWarningIdAndQuestionId(qualiInfo.getWarningId(),qualiInfo.getQuestionId());
        }
        //---- กรณี ที่หา version ที่ตอบล่าสุดใน ANSWER ไม่เจอให้ questionVersion เป็น Version ปัจจุบัน
        if(ValidatorUtil.isNullOrEmpty(answerVersion)){ //-- Is null or blank
            answerVersion = qualiInfo.getVersion();
        }
        log.debug("Current todo questionID >> " + questionID);
        log.debug("Current todo  version >> " + answerVersion);
        }
        //---29/06/2015 : Coz,EWSQ is close by form. Not need to send EWSQ Obj to ScoreEngine but it need fin obj (WarningProcess)----------//
        ScoreEngineVo scoreEngineVo = null;
        if((qualiInfo != null) &&(!BusinessConst.Flag.Y.equals(qualiInfo.getCloseFlag()))){
                scoreEngineVo = findDataForSendScore(questionID, answerVersion , qualiInfo.getWarningId(), user, cifNo, "", BusinessConst.WarningTypeCode.EWSQ);
        }else{ //--- IS CloseJob = 'Y'
                scoreEngineVo = new ScoreEngineVo();
                scoreEngineVo.setAppId("");
                scoreEngineVo.setCustId(cifNo);
                scoreEngineVo.setCustName("");
                scoreEngineVo.setRespUnitId(user.getDeptCode());
                scoreEngineVo.setQuestionId("");
                scoreEngineVo.setVersion("");
                scoreEngineVo.setLimitSize("1");
                //scoreEngineVo.setTopicObj(topicObjGroup);
        }
        //---- Comment Original 29/06/2015 ---//ScoreEngineVo scoreEngineVo = findDataForSendScore(warningInfoVo.getQuestionId(), answerVersion , warningInfoVo.getWarningId(), user, cifNo, "", BusinessConst.WarningTypeCode.EWSQ);
         boolean requireDataFIN = true;
        if (scoreEngineVo != null) {
            CustomerVo customerVo = customerService.selectCustomerByCif(Integer.parseInt(cifNo));
            scoreEngineVo.setSize(customerVo.getBusinessSize());
            scoreEngineVo.setCustName(customerVo.getCustName());
             WarningProcessVo warningProcessVo = null;
            if(qualiWarningId != null && qualiWarningId > 0 && qualiWarningId > finWarningId){   //Quali ล่าสุดกว่า FIN 
                   warningProcessVo = warningProcessService.findWarningProcessByInfoId(qualiWarningId);
           }else if(finWarningId != null && finWarningId > 0 && finWarningId > qualiWarningId){ //FIN ล่าสุดกว่า Quali
                   warningProcessVo = warningProcessService.findWarningProcessByInfoId(finWarningId);
                   requireDataFIN = false;
            }else{
                   warningProcessVo = warningProcessService.findWarningProcessByHeaderId(warningHeaderId);
            }
            
            if(warningProcessVo == null){
                 warningProcessVo = warningProcessService.findWarningProcessByHeaderId(warningHeaderId);
            }
            WarningHeaderVo headerVoObj = warningHeaderService.findWarningHeaderObjectOriginal(warningHeaderId, cifNo);
            if (warningProcessVo != null) {     
                scoreEngineVo.setFinPD(warningProcessVo.getFinPD());
                scoreEngineVo.setFinODDS(warningProcessVo.getFinODDS());
                scoreEngineVo.setHvFin(warningProcessVo.getHvFin());
                scoreEngineVo.setHvNCB(warningProcessVo.getHvNCB());
                scoreEngineVo.setHvQuanti(warningProcessVo.getHvQuanti());
                scoreEngineVo.setHvRating(warningProcessVo.getHvRating());
                scoreEngineVo.setNcbLastUpdate(warningProcessVo.getNcbLastUpdate());
                scoreEngineVo.setNcbODDSEWS(warningProcessVo.getNcbODDSEWS());
                scoreEngineVo.setNcbODDSEWSOnline(warningProcessVo.getNcbODDSEWSOnline());
                scoreEngineVo.setNcbODDSIndEWS(warningProcessVo.getNcbODDSIndEWS());
                scoreEngineVo.setNcbODDSIndEWSBackup(warningProcessVo.getNcbODDSIndEWSBackup());
                scoreEngineVo.setNcbODDSIndEWSBackupOnline(warningProcessVo.getNcbODDSIndEWSBackupOnline());
                scoreEngineVo.setNcbODDSIndEWSOnline(warningProcessVo.getNcbODDSIndEWSOnline());
                scoreEngineVo.setQuantiBhvPD(warningProcessVo.getQuantiBhvODDS());
                scoreEngineVo.setRatingODDS(warningProcessVo.getRatingODDS());
                scoreEngineVo.setRenewal(warningProcessVo.getRenewal());
                 if(finWarningId != null && finWarningId > 0 && requireDataFIN){
                      WarningProcessVo finWarningProcessVo = warningProcessService.findWarningProcessByHeaderIdAndInfoId(warningHeaderId, finWarningId);
                      if(finWarningProcessVo != null){
                           scoreEngineVo.setHvFin(finWarningProcessVo.getHvFin());
                           scoreEngineVo.setFinPD(finWarningProcessVo.getFinPD());
                           scoreEngineVo.setFinODDS(finWarningProcessVo.getFinODDS());
                           // Note : FIN_SCORE , FIN_SCORE ไม่ส่ง Score เส้นรวม
                      }
                }
                if (headerVoObj != null) {
                    scoreEngineVo.setDpd(headerVoObj.getDpd() != null ? String.valueOf(headerVoObj.getDpd()) : null);
                    scoreEngineVo.setBucketDPD(headerVoObj.getBucketDpd());
                    scoreEngineVo.setBucketRenewal(headerVoObj.getBucketRenewal());
                    //----EWS-L
                    scoreEngineVo.setHvDelinqDate(headerVoObj.getHvDelinqDate());
                    scoreEngineVo.setDelinqDate(headerVoObj.getDelinqDate());
                    scoreEngineVo.setDpdOd(headerVoObj.getDpdOd());
                    scoreEngineVo.setBucketDpdOd(headerVoObj.getBucketDpdOd());
                    scoreEngineVo.setBucketRating(headerVoObj.getBucketRating());  //----- CR-L R3
                    creditRatingFlg = headerVoObj.getCreditRatingFlg();
                }
                 //----- CR-L R3
                scoreEngineVo.setcClass(warningProcessVo.getcClass());
                scoreEngineVo.setAuthorizeReviewDate(warningProcessVo.getAuthorizeReviewDateStr());
                scoreEngineVo.setMinReviewDate(warningProcessVo.getMinReviewDateStr());
                scoreEngineVo.setPauseFlag(warningProcessVo.getPauseFlg());
                scoreEngineVo.setModelID(warningProcessVo.getModelID());
                scoreEngineVo.setAuthorizeRatingDate(warningProcessVo.getAuthorizeRatingDateStr());
                scoreEngineVo.setNextRatingDate(warningProcessVo.getNextRatingDateStr());
                scoreEngineVo.setRatingMTH(warningProcessVo.getRatingMth());
            }

            WSLogVO logVO = new WSLogVO();
            logVO.setWarningHeaderId(warningHeaderId);
            logVO.setCifNo(cifNo);
            String warningInfoIDRemark =  "";
            if(qualiWarningId != null && qualiWarningId > 0){
                 warningInfoIDRemark ="QualiID:"+qualiWarningId+"";
            }
            if(finWarningId != null && finWarningId > 0){
                if(StringUtil.isNotEmpty(warningInfoIDRemark)){
                    warningInfoIDRemark = warningInfoIDRemark + " , ";
                }
                 warningInfoIDRemark = warningInfoIDRemark + "FinID:"+finWarningId+"";
            }
            logVO.setWarningInfoIdAndType(warningInfoIDRemark);

            log.debug("Before send EWSQ");
            JSONObject jsonObject = scoreEngineBusiness.sendProjectEWS(scoreEngineVo, logVO);
            if (jsonObject != null) {
                String assignTask = "";
                String bucketDPD = "";
                String finalRiskLevel = "";
                String assignAction = "";
                String bucketRenewal = "";
                String quantiRiskLevel = "";
                String qualiRiskLevel = "";
                if (jsonObject.get("AssignTask") != null) {//--ASSIGN_TASK
                    assignTask = jsonObject.get("AssignTask").toString();
                }
                if (jsonObject.get("Bucket_DPD") != null) {//--BUCKET_DPD
                    bucketDPD = jsonObject.get("Bucket_DPD").toString();
                }
                if (jsonObject.get("FinalRiskLevel") != null) {//--EWS_RISK_LEVEL
                    finalRiskLevel = jsonObject.get("FinalRiskLevel").toString();
                }
                if (jsonObject.get("AssignAction") != null) { //--ASSIGN_ACTION
                    assignAction = jsonObject.get("AssignAction").toString();
                }
                if (jsonObject.get("Bucket_Renewal") != null) { //--CR_BUCKET --- ไม่มี Field ใน table HEADER
                    bucketRenewal = jsonObject.get("Bucket_Renewal").toString();
                }
                if (jsonObject.get("FirstPD_USE") != null) { //--QUANTI_RISK_LEVEL
                    quantiRiskLevel = jsonObject.get("FirstPD_USE").toString();
                }
                if (jsonObject.get("QualiResult") != null) { //--QUALI_RISK_LEVEL
                    qualiRiskLevel = jsonObject.get("QualiResult").toString();
                }
                //----- CR-L R3
                String bucketRenewalFinal = "";
                String bucketRating = "";
                String bucketRatingFinal = "";
                String reviewDateFinal = "";
                String reasonRenewal = "";
                String ratingDateFinal = "";
                String assignRating = "";
                String reasonRating = "";
                Date reviewDateFinalDT = null;
                Date ratingDateFinalDT = null;
                
                if (jsonObject.get("Bucket_Renewal_Final") != null) { 
                    bucketRenewalFinal = jsonObject.get("Bucket_Renewal_Final").toString();
                }
                if (jsonObject.get("Bucket_Rating") != null) { 
                    bucketRating = jsonObject.get("Bucket_Rating").toString();
                }
                if (jsonObject.get("Bucket_Rating_Final") != null) { 
                    bucketRatingFinal = jsonObject.get("Bucket_Rating_Final").toString();
                }
                if (jsonObject.get("Review_Date_Final") != null) { 
                    reviewDateFinal = jsonObject.get("Review_Date_Final").toString();
                }
                if (jsonObject.get("Reason_Renewal") != null) { 
                    reasonRenewal = jsonObject.get("Reason_Renewal").toString();
                }
                if (jsonObject.get("Rating_Date_Final") != null) { 
                    ratingDateFinal = jsonObject.get("Rating_Date_Final").toString();
                }
                if (jsonObject.get("AssignRating") != null) { 
                    assignRating = jsonObject.get("AssignRating").toString();
                }
                if (jsonObject.get("Reason_Rating") != null) { 
                    reasonRating = jsonObject.get("Reason_Rating").toString();
                }
                 
                
                //*********  Update Info : TBL_WARNING_PROCESS ******-//
             /*   if(warningProcessVo != null && warningProcessVo.getWarningHeaderId() > 0 && warningProcessVo.getWarningId() > 0){
                WarningProcessVo warningProcessVoUpdate = new  WarningProcessVo();
                warningProcessVoUpdate.setWarningHeaderId(warningProcessVo.getWarningHeaderId());
                warningProcessVoUpdate.setWarningId(warningProcessVo.getWarningId());
                warningProcessVoUpdate.setBucketRenewalFinal(bucketRenewalFinal);
                warningProcessVoUpdate.setBucketRating(bucketRating);
                warningProcessVoUpdate.setBucketRatingFinal(bucketRatingFinal);
                if(StringUtil.isNotEmpty(reviewDateFinal)){
                   reviewDateFinalDT =  DateUtil.getDate(reviewDateFinal);
                }
                warningProcessVoUpdate.setReviewDateFinal(reviewDateFinalDT);
                warningProcessVoUpdate.setReasonRenewal(reasonRenewal);
                if(StringUtil.isNotEmpty(ratingDateFinal)){
                   ratingDateFinalDT =  DateUtil.getDate(ratingDateFinal);
                }
                warningProcessVoUpdate.setRatingDateFinal(ratingDateFinalDT);
                warningProcessVoUpdate.setAssignRating(assignRating);
                warningProcessVoUpdate.setReasonRating(reasonRating);
                warningProcessService.updateScoreProjectFIN(warningProcessVo);
                }*/
                 //*********  EWS-M : R9 (Mail)"[EWS-M R9] การจัดเก็บข้อมูล EWS Risk Level"******-//
                RptIndividualRiskLevelVo riskLevelVo = null;
                Date curDate = DateUtil.getCurrentDateTime();
                if(!ValidatorUtil.isNullOrEmpty(cifNo) && !cifNo.equals("0")){
                RptIndividualRiskLevelVo oldData = rptIndividualRiskLevelService.findLastedRecordRptIndividualRiskLevel(Integer.parseInt(cifNo));
                if(BusinessConst.WarningTypeCode.EWSQ.equals(currentWarningType)){
                     riskLevelVo = new RptIndividualRiskLevelVo();
                     if(oldData != null){
                         riskLevelVo.setQuantiRiskDate(oldData.getQuantiRiskDate());
                         riskLevelVo.setQuantiRiskLevel(oldData.getQuantiRiskLevel());
                     }
                        riskLevelVo.setQualiRiskDate(curDate);
                        riskLevelVo.setQualiRiskLevel(qualiRiskLevel);
                        riskLevelVo.setFinalRiskDate(curDate);
                        riskLevelVo.setFinalRiskLevel(finalRiskLevel);
                }else if(BusinessConst.WarningTypeCode.FIN.equals(currentWarningType)){
                    log.info("oldData.getQuantiRiskLevel() >> " + oldData.getQuantiRiskLevel());
                    log.info("quantiRiskLevel >> " + quantiRiskLevel);
                    if(oldData != null){
                    String oldQuanti = ValidatorUtil.isNullOrEmpty(oldData.getQuantiRiskLevel()) ? "" : oldData.getQuantiRiskLevel() ;
                    if(!quantiRiskLevel.equals(oldQuanti)){ // QuantiRiskLevel(OLD) != FirstPD_USE(Score) : it can compare with null value
                        riskLevelVo = new RptIndividualRiskLevelVo();
                        riskLevelVo.setQualiRiskDate(oldData.getQualiRiskDate());
                        riskLevelVo.setQualiRiskLevel(oldData.getQualiRiskLevel());
                        riskLevelVo.setQuantiRiskDate(curDate);
                        riskLevelVo.setQuantiRiskLevel(quantiRiskLevel);
                        riskLevelVo.setFinalRiskDate(curDate);
                        riskLevelVo.setFinalRiskLevel(finalRiskLevel);
                     }// Case Risk Level equal not insert
                    }else{//---- First Record
                        riskLevelVo = new RptIndividualRiskLevelVo();
                        riskLevelVo.setQuantiRiskDate(curDate);
                        riskLevelVo.setQuantiRiskLevel(quantiRiskLevel);
                        riskLevelVo.setFinalRiskDate(curDate);
                        riskLevelVo.setFinalRiskLevel(finalRiskLevel);
                    }
                }
                if(riskLevelVo != null){
                       riskLevelVo.setCif(Integer.parseInt(cifNo));
                       riskLevelVo.setCreatedDate(DateUtil.getCurrentDateTime());
                       riskLevelVo.setCreatedBy(user.getEmpNo());
                       rptIndividualRiskLevelService.insertIndividualRiskLevel(riskLevelVo);
                }
                }
                //*********  Update Info : Already Send Score : Y******-//
                if (qualiInfo != null &&  (qualiInfo.getWarningHeaderId() > 0 ) && (qualiInfo.getWarningId() != null && qualiInfo.getWarningId() > 0)) {
                    qualiInfo.setUpdatedBy(user.getEmpNo());
                    qualiInfo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    qualiInfo.setWarningType(BusinessConst.WarningTypeCode.EWSQ);
                    qualiInfo.setQualiSendFlag(BusinessConst.Flag.Y);
                    warningInfoService.updateQualiSendFlag(qualiInfo);
                }
                WarningHeaderVo headerVo = new WarningHeaderVo();
                headerVo.setWarningHeaderId(warningHeaderId);
                headerVo.setUpdatedBy(user.getEmpNo());
                headerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                //*********  Update Header : Data from Score System
                headerVo.setFormAssign(assignTask);
                headerVo.setBucketDpd(bucketDPD);
                headerVo.setCrBucket(bucketRenewal);
                headerVo.setCrFormAssign(assignAction);
                if(riskLevelVo != null){
                  headerVo.setEwsRiskLevel(ValidatorUtil.isNullOrEmpty(riskLevelVo.getFinalRiskLevel()) ? "" : riskLevelVo.getFinalRiskLevel());
                  headerVo.setQualiRiskLevel(ValidatorUtil.isNullOrEmpty(riskLevelVo.getQualiRiskLevel()) ? "" : riskLevelVo.getQualiRiskLevel());
                  headerVo.setQuantiRiskLevel(ValidatorUtil.isNullOrEmpty(riskLevelVo.getQuantiRiskLevel()) ? "" : riskLevelVo.getQuantiRiskLevel());
                }
                //--- CR-L R3
                //*********  Update Info : TBL_WARNING_HEADER ******-//
                headerVo.setBucketRenewalFinal(bucketRenewalFinal);
                headerVo.setBucketRating(bucketRating);
                headerVo.setBucketRatingFinal(bucketRatingFinal);
                if(!ValidatorUtil.isNullOrEmpty(reviewDateFinal)){
                   reviewDateFinalDT = DateUtil.getDateFromString(reviewDateFinal, DateUtil.DATE_FORMAT_YYYYMMDD, DateUtil.APPLICATION_LOCALE);
                   log.debug("reviewDateFinalDT >> " + reviewDateFinalDT);
                   headerVo.setReviewDateFinal(reviewDateFinalDT);
                   headerVo.setReviewDateFinalStr(reviewDateFinal);
                }
                log.debug("reasonRenewal >> " + reasonRenewal);
                if(!ValidatorUtil.isNullOrEmpty(reasonRenewal)){
                ReasonRenewalMappingVo renewalMappingVo =  reasonRenewalMappingService.getObjectReasonRenewalMapping(reasonRenewal);
                if(renewalMappingVo != null && !ValidatorUtil.isNullOrEmpty(renewalMappingVo.getReasonRenewalSAS()) && !ValidatorUtil.isNullOrEmpty(renewalMappingVo.getTypesFlg())){
                    log.debug("creditRatingFlg >> " + creditRatingFlg);
                    log.debug("getReasonRenewalSAS >> " + renewalMappingVo.getReasonRenewalSAS());
                    log.debug("getTypesFlg >> " + renewalMappingVo.getTypesFlg());
                    headerVo.setReasonRenewal(renewalMappingVo.getReasonRenewalSAS());
                    String typesFlag = renewalMappingVo.getTypesFlg();
                    if(!ValidatorUtil.isNullOrEmpty(creditRatingFlg) && !"D".equals(creditRatingFlg) && !ValidatorUtil.isNullOrEmpty(typesFlag)){
                        typesFlag = typesFlag + ",D";
                    }
                    headerVo.setTypesFlg(typesFlag);
                } 
                }
                log.debug("ratingDateFinal >> " + ratingDateFinal);
                if(!ValidatorUtil.isNullOrEmpty(ratingDateFinal)){
                   ratingDateFinalDT =  DateUtil.getDateFromString(ratingDateFinal, DateUtil.DATE_FORMAT_YYYYMMDD, DateUtil.APPLICATION_LOCALE);
                   log.debug("ratingDateFinalDT >> " + ratingDateFinalDT);
                   headerVo.setRatingDateFinal(ratingDateFinalDT);
                   headerVo.setRatingDateFinalStr(ratingDateFinal);
                }
                headerVo.setAssignRating(assignRating);
                headerVo.setReasonRating(reasonRating);
                warningHeaderService.updateFlagInWarningHeader(headerVo);
            }//END sendScore */
        }
    
    }

  
    

}
