/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.WarningFileAttachmentVo;
import java.util.List;

/**
 *
 * @author Thanakorn Ch.
 */
public interface WarningFileAttachmentsBusiness {
    public List<WarningFileAttachmentVo> findByWarningHeaderID( int warnHeadID ) throws Exception;
    public WarningFileAttachmentVo findFileName( int warnHeadID, int seq ) throws Exception;
    public void deleteFile( int warnHeadID, int seq ) throws Exception;
    public void saveFile( WarningFileAttachmentVo vo ) throws Exception;
}
