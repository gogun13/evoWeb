/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktb.ewsl.services.AnnouncementService;
import com.ktb.ewsl.vo.AnnouncementVo;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.DisplayUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.ValidatorUtil;

/**
 *
 * @author KapookZa
 */
@Service
public class AnnouncementBusinessImpl implements AnnouncementBusiness {

    private static final Logger log = Logger.getLogger(AnnouncementBusinessImpl.class);
    @Autowired
    private AnnouncementService announcementService;

    @Override
    public Integer saveAnnouncement(AnnouncementVo announcementVo) throws Exception {
        return announcementService.saveAnnouncement(announcementVo);
    }

    @Override
    public void deleteAnnouncement(int seq, String updatedBy) throws Exception {
        announcementService.deleteAnnouncement(seq, updatedBy);
    }

    @Override
    public PaginatedListImpl<AnnouncementVo> getListAnnouncement(AnnouncementVo announcementVo, PaginatedListImpl<AnnouncementVo> paginate, int pageAmt) throws Exception {
        return announcementService.getListAnnouncement(announcementVo, paginate, pageAmt);
    }
    
    @Override
    public PaginatedListImpl<AnnouncementVo> getListPostAnnouncement(PaginatedListImpl<AnnouncementVo> paginate) throws Exception{
    	return announcementService.getListPostAnnouncement(paginate);
    }

    @Override
    public AnnouncementVo getAnnouncementVo(AnnouncementVo announcementVo) throws Exception {
        return announcementService.getAnnouncementVo(announcementVo);
    }

    @Override
    public void updateAnnouncement(AnnouncementVo announcementVo) throws Exception {
        announcementService.updateAnnouncement(announcementVo);
    }

    @Override
    public InputStream getInputStreamFromFile(String directory, String fileName) throws Exception, IOException {
        log.info("getInputStreamFromFile");

        File file = new File(directory + "/" + fileName);
        InputStream is = new FileInputStream(file);

        return is;
    }

    @Override
    public void saveFileOutputStream(String pathFile, AnnouncementVo announcementVo) throws Exception {
        log.info("saveFileOutputStream");

        FileOutputStream fos = null;
        OutputStreamWriter writer = null;

        try {
            if (ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceStartDateStr())) {
                announcementVo.setAnnounceStartDateStr("99999999");
            }
            if (ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceEndDateStr())) {
                announcementVo.setAnnounceEndDateStr("99999999");
            }
            /* Format Filename = annnounceDate_seq_ANNOUCEMENT_startDate_endDate.TXT 
             * Example: 25600928_5_ANNOUCEMENT_29092560_30092560.TXT
             */
            String announceDateStr = announcementVo.getAnnounceDateStr().replace("/", "");
            String reverseDate = "";
            if (announceDateStr != null && announceDateStr.length() == 8) {
                reverseDate = announceDateStr.substring(4) + "" + announceDateStr.substring(2, 4) + "" + announceDateStr.substring(0, 2);
            }

            String fileName = reverseDate + "_"
                    + announcementVo.getSeq() + "_ANNOUCEMENT_"
                    + announcementVo.getAnnounceStartDateStr().replace("/", "") + "_"
                    + announcementVo.getAnnounceEndDateStr().replace("/", "") + ".TXT";
            log.info("fileName =>" + fileName);
            boolean flagDeleteFile = false;
            if (!"99999999".equals(announcementVo.getAnnounceEndDateStr())) {
                Date curDate = DateUtil.convertStringToDateByFormat(DateUtil.getCurrentDateString("ddMMyyyy"), "ddMMyyyy");
                Date endDate = DateUtil.convertStringToDateByFormat(DateUtil.convertThEnYearStr(announcementVo.getAnnounceEndDateStr(), true), "ddMMyyyy");
                if (curDate.compareTo(endDate) > 0) {
                    flagDeleteFile = true;
                }
            }

            if (flagDeleteFile || announcementVo.getIsActive() == 0) {// delete file if status is InActive
                // current date should less than AnnounceEndDate
                try {
                    File file = new File(pathFile + fileName);
                    if (announcementVo.getIsActive() == 0) {
                        if (file.delete()) {
                            log.info(file.getName() + " is deleted!");
                        } else {
                            log.info("Delete operation is failed.");
                        }
                    } else {
                        deleteFileInDirectory(pathFile, announcementVo.getSeq());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                File tmpFileFolder = new File(pathFile);

                // Create Folder
                if (tmpFileFolder.exists()) {
                    log.info(" filePath is exists ");
                } else {
                    if (tmpFileFolder.mkdirs()) {
                        log.info(" Create filePath Success !!! ");
                    } else {
                        throw new BusinessException(" File path errors ");
                    }
                }
                //Check is have exit file then delete it 
                deleteFileInDirectory(pathFile, announcementVo.getSeq());
                // Write file into fig path
                fos = new FileOutputStream(pathFile + fileName);
                writer = new OutputStreamWriter(fos, "UTF-8");
                StringBuilder str = new StringBuilder();
                str.append("<br />");
               
                str.append("<h3><font style=\"color:mediumblue;font-family:kanit;\">วันที่ ");
                str.append("<span style=\"font-family:kanit;\">").append(DisplayUtil.getFullDateThai(DateUtil.convertStringToDateByFormat(DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStr(), true), "ddMMyyyy"))).append("</span>");
                str.append("<br />").append("<div style=\"font-family:kanit;\">").append("<span style=\"vertical-align:middle;\">").append("หัวข้อ : ").append("</span>");
                str.append("<span style=\"vertical-align:middle;\">").append(announcementVo.getAnnounceTitle()).append("</span>").append("&nbsp;");
                if ("Y".equals(announcementVo.getNewFlag())) {
                    str.append("<img style=\"vertical-align:middle;\" width=\"60\" height=\"60\" src=\"../img/icons/new.gif\" />");
                }
                if ("Y".equals(announcementVo.getUpdateFlag())) {
                    str.append("<img style=\"vertical-align:middle;\" width=\"80\" height=\"80\" src=\"../img/icons/update.gif\" />");
                }
                str.append("</div>");
                str.append("</h3>");

                str.append("</font><br>");
                str.append(announcementVo.getAnnounceDetail());
                writer.write(str.toString());
                writer.flush();
                writer.close();
            }
            //Delete all file if enddate < currentDate
            deleteOldFileInDirectory(pathFile);
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("saveFileOutputStream :" + ex.getMessage());
        } finally {
            if (fos != null) {
                fos.flush();
                fos.close();
            }
        }
    }

    private void deleteFileInDirectory(String pathFile, final Integer seqFile) {
        File directoty = new File(pathFile);

        File[] filesDelete = directoty.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                if (name.contains("_" + seqFile + "_ANNOUCEMENT_")) {
                    return true;
                }
                return false;
            }
        });

        for (File f : filesDelete) {
            if (f.delete()) {
                log.info(f.getName() + " is deleted!");
            } else {
                log.info("Delete operation is failed.");
            }
        }
    }

    private void deleteOldFileInDirectory(String pathFile) {
        try {
            File directoty = new File(pathFile);
            List<File> files = null;
            String[] fileNames = null;

            if (directoty.listFiles() != null) {
                files = Arrays.asList(directoty.listFiles());
            }
            if (files != null) {
                for (int a = 0; a < files.size(); a++) {
                    File file = (File) files.get(a);
                    String fileName = file.getName();
                    boolean deleteFlag = false;
                    if (file.isFile()) {
                        String startDateStr = "";
                        String endDateStr = "";
                        fileNames = fileName.split("_");
                        for (int i = 0; i < fileNames.length; i++) {
                            if (i == 3) {
                                startDateStr = fileNames[i];
                            } else if (i == 4) {
                                endDateStr = fileNames[i].substring(0, 8);
                            }
                        }
                        if (!"99999999".equals(startDateStr) && (!"99999999".equals(endDateStr))) {
                            Date curDate = DateUtil.convertStringToDateByFormat(DateUtil.getCurrentDateString("ddMMyyyy"), "ddMMyyyy");
                            
                            Date endDate = DateUtil.parseThai(endDateStr, "ddMMyyyy");
                            if (curDate.compareTo(endDate) > 0) {
                                deleteFlag = true;
                            } 
                        } else {
                            deleteFlag = false;
                        }
                    }
                    if (deleteFlag) {
                        if (file.delete()) {
                            log.info(file.getName() + " is deleted!");
                        } else {
                            log.info("Delete operation is failed.");
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Integer getMaxSeq() throws Exception {
        return announcementService.getSeq();

    }
}
