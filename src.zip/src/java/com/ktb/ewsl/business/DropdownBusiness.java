/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ktb.ewsl.vo.DropdownVo;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
@Service
public interface DropdownBusiness {
    
    public List getWorkLine()throws Exception;
    public List getOrganizationGroup(String businessUnit)throws Exception;
    public List getDepartment(String businessUnit , String groupCode)throws Exception;
    public List getOrganizationGroupAndEwsUse(String businessUnit)throws Exception;
    public ArrayList getStatusDropdown() throws Exception ;
   
    
}
