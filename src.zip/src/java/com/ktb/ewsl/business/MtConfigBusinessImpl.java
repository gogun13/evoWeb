/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.MtFormStatusService;
import com.ktb.ewsl.vo.MtFormStatusVo;
import com.ktbcs.core.business.AbstractBusiness;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class MtConfigBusinessImpl extends AbstractBusiness implements MtConfigBusiness {

  
    @Autowired
    private MtFormStatusService mtFormConfigService;

    @Override
    public ArrayList<MtFormStatusVo> getMtFormDetail() throws Exception {

        return mtFormConfigService.getFormConfigDetail();


    }
    
    @Override
    public ArrayList<MtFormStatusVo> getStatusNameAndSeq() throws Exception {
        return mtFormConfigService.getStatusNameAndSeq();
    }
    
}
