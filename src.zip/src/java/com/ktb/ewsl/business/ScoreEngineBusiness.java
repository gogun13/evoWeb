/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ScoreEngineVo;
import com.ktb.ewsl.vo.WSLogVO;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.vo.UserData;
import org.json.simple.JSONObject;

/**
 *
 * @author Siriwat Asamo
 */
public interface ScoreEngineBusiness {        
    public void updateAsstQuestion(WarningTypeVo warningType, UserData user) throws Exception;    
    public void sendProjectFIN(ScoreEngineVo scoreEngine, WarningInfoVo warningInfo, UserData user) throws Exception;
    public JSONObject sendProjectEWS(ScoreEngineVo scoreEngine,WSLogVO logVo) throws Exception;
    public String checkConnection() throws Exception;
    public JSONObject sendLatePayment(ScoreEngineVo scoreEngine, WSLogVO logVo) throws Exception;
    public JSONObject sendTrigger(ScoreEngineVo scoreEngine, WSLogVO logVo) throws Exception;
}
