/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.CustomerVo;

/**
 *
 * @author KTBDevLoan
 */
public interface CustomerBusiness {
    
    public CustomerVo selectCustomerByCif(Integer cif) throws Exception;
    
    public CustomerVo selectCustomerByCifWithCostCenterName(Integer cif) throws Exception;
}
