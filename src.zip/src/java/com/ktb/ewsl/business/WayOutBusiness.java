/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.QuestionVo;
import com.ktb.ewsl.vo.WarningWayOutVo;
import java.util.List;

/**
 *
 * @author KTB_User
 */
public interface WayOutBusiness {
    public List<QuestionVo> findQuestionWayOut(QuestionVo filter) throws Exception;
    public List<QuestionVo> findQuestionWayOutForBCM(QuestionVo filter) throws Exception;
//    public void save(int WARNING_HEAD_ID, String cif, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception;
//    public void send(int WARNING_HEAD_ID, String cif, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception;
//    public void sendBack(int WARNING_HEAD_ID, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception;
//    public void approve(int WARNING_HEAD_ID, String currStatus, String actionCode, UserData userData, List<WarningWayOutVo> warningWayOutList) throws Exception;
    
    public void saveWayOut(List<WarningWayOutVo> warningWayOutList) throws Exception;
    public void deleteTblWarningWayOutForm(int warningId, String roleCode) throws Exception;
}
