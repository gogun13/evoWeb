/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.KtbOrganizationServices;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.KtbOrganization;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class KtbOrganizationBusinessImpl implements KtbOrganizationBusiness{

    private static final Logger log = Logger.getLogger(KtbOrganizationBusinessImpl.class);
 
    @Autowired
    private KtbOrganizationServices ktbOrganizationServices;
    
    @Override
    public KtbOrganization getOrganizationByCostcenter(String costcenter) throws Exception {
       return ktbOrganizationServices.getOrganizationByCostcenter(costcenter);
    }

    @Override
    public String findCostCenterName(String costcenter) throws Exception {
        return ValidatorUtil.isNullOrEmpty(costcenter) ? "" : ktbOrganizationServices.findCostCenterName(costcenter);
    }

    @Override
    public ArrayList<DropdownVo> getResponseUnit(String businessUnit, String groupCode, String fieldOrder) throws Exception {
        return ktbOrganizationServices.getResponseUnit(businessUnit, groupCode, fieldOrder);
    }

    @Override
    public ArrayList<DropdownVo> getOrganizationResponseUnit(String costcenterCode, String fieldOrder) throws Exception {
          return ktbOrganizationServices.getOrganizationResponseUnit(costcenterCode, fieldOrder);
    }
    
    @Override
    public String getCostCenterDescByCode(String costCenterCode) throws Exception {
        return ktbOrganizationServices.getCostCenterDescByCode(costCenterCode);
    }
    
}
