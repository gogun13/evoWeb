/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.vo.WarningTypeVo;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTB_User
 */
@Service
public class AssignSlaBusinessImpl implements AssignSlaBusiness {
    private static final Logger logger = Logger.getLogger(AssignSlaBusinessImpl.class);
    
    @Autowired
    private WarningTypeService warningTypeService;

    @Override
    public ArrayList<WarningTypeVo> findWarningTypeUnderWarningTypeIsNull(WarningTypeVo warningTypeVo) throws Exception {
        return warningTypeService.findWarningTypeUnderWarningTypeIsNull(warningTypeVo);
    }

    @Override
    public void updateSla(WarningTypeVo warningTypeVo) throws Exception {
        logger.info("[updateSla][Begin]");
        
        int couUnderWarningType = 0;
        
        try{
            warningTypeService.updateSlaByWarningTypeCode(warningTypeVo.getSla(), warningTypeVo.getWarningTypeCode(),warningTypeVo.getUpdatedBy());
            
            couUnderWarningType = warningTypeService.countUnderWarningTypeCode(warningTypeVo.getWarningTypeCode());
            if(couUnderWarningType > 0)warningTypeService.updateSlaByUnderWarningTypeCode(warningTypeVo.getSla(), warningTypeVo.getWarningTypeCode(),warningTypeVo.getUpdatedBy());
            
            warningTypeService.insertWarningTypeSlaHistory(warningTypeVo);
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[updateSla][End]");
        }
    }

    @Override
    public WarningTypeVo getWarningTypeDetail(String warningTypeCode) throws Exception {
        return warningTypeService.getWarningTypeDetail(warningTypeCode);
    }
    
    
    
}
