/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.FormStatusControlService;
import com.ktb.ewsl.vo.FormStatusControlVo;
import com.ktbcs.core.business.AbstractBusiness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Pratya
 */
@Service
public class FormStatusControlBusinessImpl extends AbstractBusiness implements FormStatusControlBusiness {

  
    @Autowired
    private FormStatusControlService formStatusControlService;

    @Override
    public String getNextStatus (FormStatusControlVo vo) throws Exception {

        return formStatusControlService.getNextStatus(vo);


    }
}
