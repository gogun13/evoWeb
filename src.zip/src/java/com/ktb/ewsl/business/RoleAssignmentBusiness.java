/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.UserVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author KTB_User
 */
public interface RoleAssignmentBusiness {
    public String getRoleCodeDesc(String isConfig, String roleCode) throws Exception;
    public List<DropdownVo> getRoleList(String isConfig) throws Exception;
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeHistoryList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public PaginatedListImpl<UserVo> getUserTBList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public PaginatedListImpl<UserVo> getDepartmentList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public int save(SearchBean searchBean, UserData userData) throws Exception;    
    public int validateUpdate(String empNo, String roleCode, String deptCode) throws Exception;    
    public int updateUserMtRolePrivilege(SearchBean searchBean, UserData userData, String oldRoleCode, String oldDeptCode) throws Exception;
    public void updateUserMtRolePrivilegeBySearch() throws Exception;
    public void updateUser(UserVo userVo) throws Exception;
    public int deleteUserMtRolePrivilege(SearchBean searchBean) throws Exception;
    public UserVo getUserMtRolePrivilegeByFilter(SearchBean searchBean) throws Exception;
}
