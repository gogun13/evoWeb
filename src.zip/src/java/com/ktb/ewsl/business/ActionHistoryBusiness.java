/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface ActionHistoryBusiness {
    
      public ActionHistoryVo findDataByWarningIdAndStatus(int warningId, String status) throws Exception;
      public List<QuestionHistoryVo> findQuestionHistory(QuestionHistoryVo vo) throws Exception;
      public QuestionHistoryVo findQuestionVersion(String warningId) throws Exception ;
      public void saveData(ActionHistoryVo vo) throws Exception;
      public ActionHistoryVo findActionHistory(int warningId,String actionCode , String status) throws Exception ;
      public ActionHistoryVo findData(int warningId, String actionDetail) throws Exception;
      public void updateRemarkForDraftReject(ActionHistoryVo vo) throws Exception;
}
