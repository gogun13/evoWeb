/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.InOutLogVo;
import com.ktbcs.core.vo.UserData;


/**
 *
 * @author KTBDevLoan
 */
public interface InOutLogBusiness {
    
    public void insertInOutLog(UserData user , String loginStatus , String loginStatusDesc )throws Exception;
    public void checkAndKickOfUserInOutLog(String userId , String userIP , String serverIP)throws Exception;
    public boolean checkUserLoginBeforeNextProcess(String userId, String userIP, String serverIP,String sessionId) throws Exception;
    public void updateLogout(InOutLogVo inOutLogVo)throws Exception;
}
