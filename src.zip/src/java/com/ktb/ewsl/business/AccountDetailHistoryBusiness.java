/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import java.util.List;

import com.ktb.ewsl.vo.IndividualForBreakVo;
import com.ktb.ewsl.vo.ReportVO;

/**
 *
 * @author Thanakorn Ch.
 */
public interface AccountDetailHistoryBusiness {

    public List<IndividualForBreakVo> findDataByCifForTrack(Integer cif) throws Exception;
    public List<IndividualForBreakVo> findDataByCifForTrackODOverLimit(String cif) throws Exception;
    public List<ReportVO> findDataByCifForTrackForReport(Integer cif) throws Exception;
    
}
