/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.exceptions.RenowalException;
import com.ktbcs.core.exceptions.ScoreEngineException;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public interface AsstQuestionBusiness {
    public List<AsstTopicVo> findQuestionByFilter(AsstTopicVo filter) throws Exception;
    public String saveAsstAnswer(List<AsstAnswerVo> asstAnswerVoList, UserData user, String actionMode, String infoStatus, String warningType) throws Exception , RenowalException;
    public void approveQuestion(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action , boolean updateHeaderFlg) throws Exception;
    public List<WarningTypeVo> findWarningType() throws Exception;
    public void sendbackQuestion(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action) throws Exception, RenowalException ;
//    public void approveFinal(AsstTopicVo asstTopicVo, List<AsstAnswerVo> asstAnswerVoList, UserData user, String actionMode, String infoStatus) throws Exception, RenowalException  ;
    public boolean checkAnswerInVersion(String questionId, String version, int warningId) throws Exception;
    public void checkAllXxFlagForUpdateHeaderStatus(int warningHeaderId , String empNo , String goToAction ) throws Exception;
    public boolean chkUser(int warningId, String userId) throws Exception;
    public List<ActionHistoryVo> findRemarkFromHistory(int warningId) throws Exception;
    public String getHolderRole(String infoStatus, String qcaFlag , String roleCode) throws Exception;
    public String checkAnswerVersionAndCurrentVersion(int warningId , String warningType)throws Exception;
    //--------------------- EWS-L --------------------//
    public List<AsstTopicVo> findQuestionQualitative(AsstTopicVo filter) throws Exception; 
    public String saveAsstAnswerQuali(List<AsstAnswerVo> asstAnswerVoList, UserData user, String actionMode, String infoStatus, String warningType) throws Exception , RenowalException;
    public List<AsstTopicVo> findLatePaymentQuestionByFilter(AsstTopicVo filter) throws Exception;
    public void sendScroe(AsstTopicVo asstTopicVo, UserData user) throws Exception, ScoreEngineException;
    public Integer getLastSubTopic(String questionId, String version) throws Exception;
    public void saveAsstAnswerTrigAndKeepAnswer(List<WarningInfoVo> warningTrigList, List<AsstAnswerVo> asstAnswerVoTrigList, UserData user, String actionMode, String infoStatus, String warningType , int cif ,int headerId,int qualiWarningId,String eventTransaction) throws Exception, RenowalException ;
    public void sendbackQuestionDraft(AsstTopicVo asstTopicVo, UserData user, String infoStatus, String action) throws Exception, RenowalException ;
    public void saveAsstAnswerForActionForm2(List<AsstAnswerVo> asstAnswerVoList, UserData user) throws Exception, RenowalException;
    public void deleteAnswerByWarningIdAndRoleCode(String warningId,String roleCode) throws Exception;
    public void sendEWSQWithLastesAnswer(int warningHeaderId, UserData user, String cifNo, Integer qualiWarningId , Integer finWarningId , String currentWarningType) throws Exception, RenowalException, ScoreEngineException;
    public String[] validateCanSendEWSByfindData(int warningHeaderId ,String cifNo) throws Exception;
}
