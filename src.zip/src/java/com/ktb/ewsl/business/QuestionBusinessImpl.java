/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionHistoryService;
import com.ktb.ewsl.services.QuestionService;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AnswerVo;
import com.ktb.ewsl.vo.QuestionVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author surapong
 */
@Service
public class QuestionBusinessImpl extends AbstractBusiness implements QuestionBusiness{
    private static final Logger log = Logger.getLogger(QuestionBusinessImpl.class);
    
    @Autowired
    private QuestionService questionService;
    @Autowired
    private ActionHistoryService actionHistoryService;
    
    @Override
    public List<QuestionVo> findQuestionByFilter(QuestionVo filter) throws Exception{
        if(log.isInfoEnabled()){
            log.info("findQuestionByFilter");
        }
        List<QuestionVo> questionVoList = questionService.findQuestionByFilter(filter);
        if(questionVoList != null && questionVoList.size() > 0){
            List<Integer> questIdList = new ArrayList<Integer>();
            for(QuestionVo questionVo : questionVoList){
                questIdList.add(questionVo.getQuestId());
            }
            if(questIdList.size() > 0){
                List<AnswerVo> answerVoAllList = questionService.findChoiceByQuestion(questIdList);
                if(!answerVoAllList.isEmpty()){
                    ArrayList<AnswerVo> answerVoList;
                    for(QuestionVo questionVo : questionVoList){
                        answerVoList = new ArrayList<AnswerVo>();
                        for(AnswerVo answerVo : answerVoAllList){
                            if(questionVo.getQuestId() == answerVo.getQuestId()){
                                answerVoList.add(answerVo);
                            }
                        }
                        
                        if(answerVoList.size() > 0){
                            questionVo.setAnswerVoList(answerVoList);
                        }
                    }
                }
            }
        }
      
        return questionVoList;
    }
    
    @Override
    public void saveAssessmentAnswer(List<QuestionVo> questionVoList, UserData user, String actionMode) throws Exception{
        if(log.isInfoEnabled()){
            log.info("saveAssessmentAnswer");
        }
        if(!questionVoList.isEmpty()){
            int warningId = 0;
            String asstCode = "";
            for(QuestionVo questionVo : questionVoList){
                warningId = questionVo.getWarningId();
                asstCode = questionVo.getAsstCode();
                
                questionVo.setUpdatedBy(user.getEmpNo());
                questionVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                if(questionService.findAssessmentAnswerByWraningIdAndQuestId(questionVo.getWarningId(), questionVo.getQuestId()).isEmpty()){
                    questionVo.setCreatedBy(user.getEmpNo());
                    questionVo.setCreatedDate(DateUtil.getCurrentDateTime());
                    questionService.saveQuestion(questionVo);
                }else{
                    questionService.updateQuestion(questionVo);
                }
            }
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(warningId);
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode(actionMode+" "+asstCode);
            actionHistoryService.saveData(actionHistoryVo);
        }
         
    }
}
