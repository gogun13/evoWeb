/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ParameterVo;
import java.util.List;
import com.ktb.ewsl.vo.ParameterVo;
import java.util.ArrayList;
/**
 *
 * @author KTBDevLoan
 */
public interface ParameterBusiness {
    
    public int numRowDataGrid()throws Exception;
    public int numPageDisplayOnDataGrid()throws Exception;
    public List<ParameterVo> findByParamTypeId(String paramTypeId) throws Exception;
    public ArrayList<ParameterVo> getParameterByTypeId(String paramTypeId  , String orderBy) throws Exception;
    public ParameterVo findByParamIdAndParamType(String paramId, String paramTypeId) throws Exception;

}
