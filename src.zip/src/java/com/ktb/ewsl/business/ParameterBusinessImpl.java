/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ParameterService;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktbcs.core.utilities.BusinessConst;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class ParameterBusinessImpl implements ParameterBusiness{
    
     private static final Logger log = Logger.getLogger(ParameterBusinessImpl.class);
    
    @Autowired
    private ParameterService parameterService;

    @Override
    public int numRowDataGrid() throws Exception {
       int numRow = 0;
       try{
           ParameterVo paramVo =  parameterService.findByParamIdAndParamType(BusinessConst.PARAMETER.ID_RECORD_PER_PAGE, BusinessConst.PARAMETER.TYPE_ID_PAGE);
           if(paramVo != null){
              numRow = paramVo.getValue1()!= null ? paramVo.getValue1().intValue() : 0;
           }
       }catch (Exception e) {
            log.error("Error occur in while process ParameterBusinessImpl.numRowDataGrid: " + e.getMessage(), e);
       }
       return numRow;
    }

    @Override
    public int numPageDisplayOnDataGrid() throws Exception {
       int numPage = 0;
       try{
          ParameterVo paramVo =  parameterService.findByParamIdAndParamType(BusinessConst.PARAMETER.ID_PAGE_PER_PAGE, BusinessConst.PARAMETER.TYPE_ID_PAGE);
           if(paramVo != null){
              numPage = paramVo.getValue1()!= null ? paramVo.getValue1().intValue() : 0;
           }
       }catch (Exception e) {
            log.error("Error occur in while process ParameterBusinessImpl.numPageDisplayOnDataGrid: " + e.getMessage(), e);
       }
       return numPage;
    }

    @Override
    public List<ParameterVo> findByParamTypeId(String paramTypeId) throws Exception {
        return parameterService.findByParamTypeId(paramTypeId);
    }

    @Override
    public ArrayList<ParameterVo> getParameterByTypeId(String paramTypeId , String orderBy) throws Exception {
        return parameterService.findByParamType(paramTypeId , orderBy );
    }

    @Override
    public ParameterVo findByParamIdAndParamType(String paramId, String paramTypeId) throws Exception {
        return parameterService.findByParamIdAndParamType(paramId, paramTypeId);
    }
}
