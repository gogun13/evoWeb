/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.AsstQuestionService;
import com.ktb.ewsl.services.WarningFactorService;
import com.ktb.ewsl.services.WarningProcessServiceImpl;
import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.vo.AsstChoiceVo;
import com.ktb.ewsl.vo.AsstQuestionVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import com.ktb.ewsl.vo.ScoreEngineVo;
import com.ktb.ewsl.vo.WSLogVO;
import com.ktb.ewsl.vo.WarningFactorVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningProcessVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.exceptions.BusinessException;
import com.ktbcs.core.exceptions.ScoreEngineException;
import com.ktbcs.core.external.services.ScoreEngineService;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Siriwat Asamo
 */
@Service
public class ScoreEngineBusinessImpl implements ScoreEngineBusiness {

    private static final Logger logger = Logger.getLogger(ScoreEngineBusinessImpl.class);
    @Autowired
    private AsstQuestionService asstQuestionService;
    @Autowired
    private ScoreEngineService scoreEngineService;
    @Autowired
    private WarningProcessServiceImpl warningProcessService;
    @Autowired
    private WarningFactorService warningFactorService;
    @Autowired
    private WarningTypeService warningTypeService;

    @Override
    public void updateAsstQuestion(WarningTypeVo warningType, UserData user) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateAsstQuestion");
        }

        List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByFilter(warningType);

        if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
            for (int x = 0; x < warningTypeVoList.size(); x++) {
                WarningTypeVo warningTypeVo = warningTypeVoList.get(x);

                String channelId = BusinessConst.WSChannel.EWS_L_CHANNEL;
                String projectName = BusinessConst.ProjectName.EQUS_PROJECT;

                SimpleDateFormat dfTime = new SimpleDateFormat("HHmmss");
                SimpleDateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
                Date d = new Date();

                JSONObject inputData = new JSONObject();
                inputData.put("channelId", channelId);
                inputData.put("refId", dfDate.format(d) + dfTime.format(d));
                inputData.put("transDt", dfDate.format(d));
                inputData.put("transTime", dfTime.format(d));
                inputData.put("questionId", warningTypeVo.getQuestionId());

                WSLogVO logVo = new WSLogVO();
                logVo.setChannelID(channelId);
                logVo.setRemark(getRemarkWSLog(null, null,warningTypeVo.getQuestionId(),null));
                logVo.setServiceID(projectName);
                logVo.setSystemID(BusinessConst.SYSTEM_ID.SCORE_ENGINE);
                
                JSONArray arrResponse = null;
                try{
                arrResponse = scoreEngineService.inquiryScoreEngine(projectName, inputData,logVo);
                
                logger.info("arrResponse :: " + arrResponse.toJSONString());
                
                }catch(Exception e){
                   logger.error("Error updateAsstQuestion : " + e.getMessage());
                   throw new ScoreEngineException(e.getMessage());
                }
                JSONArray jsonErrors = (JSONArray) arrResponse.get(0);
                JSONObject jsonResponse = (JSONObject) arrResponse.get(1);

                if (jsonErrors != null && jsonErrors.size() > 0) {
                    JSONObject error = (JSONObject) jsonErrors.get(0);
                    throw new Exception(error.get("message").toString());
                }

                 logger.info("jsonResponse.get  version  >>" + jsonResponse.get("version").toString());
                 
                if (!warningTypeVo.getQuestionVersion().equals(jsonResponse.get("version").toString())) {

                    logger.debug("questionId " + jsonResponse.get("questionId").toString());
                    logger.debug("questionDesc " + jsonResponse.get("questionDesc").toString());
                    logger.debug("version " + jsonResponse.get("version").toString());
                    logger.debug("questionStartDt " + jsonResponse.get("questionStartDt").toString());

                    AsstQuestionVo asstQuestionVo = new AsstQuestionVo();
                    asstQuestionVo.setQuestionId(jsonResponse.get("questionId").toString());
                    asstQuestionVo.setQuestionDesc(jsonResponse.get("questionDesc").toString());
                    asstQuestionVo.setVersion(jsonResponse.get("version").toString());
                    asstQuestionVo.setQuestionStartDt(new SimpleDateFormat("yyyymmdd").parse(jsonResponse.get("questionStartDt").toString()));
                    asstQuestionVo.setCreatedDate(DateUtil.getCurrentDateTime());
                    asstQuestionVo.setCreatedBy(user.getEmpNo());

                    asstQuestionService.saveAsstQuestion(asstQuestionVo);

                    JSONArray topicObject = (JSONArray) jsonResponse.get("topicObject");
                    if (topicObject != null) {
                        for (int i = 0; i < topicObject.size(); i++) {
                            JSONObject sr = (JSONObject) topicObject.get(i);

                            logger.debug("topicId " + sr.get("topicId").toString());
                            logger.debug("topicDesc " + sr.get("topicDesc").toString());

                            AsstTopicVo asstTopicVo = new AsstTopicVo();
                            asstTopicVo.setQuestionId(jsonResponse.get("questionId").toString());
                            asstTopicVo.setVersion(jsonResponse.get("version").toString());
                            asstTopicVo.setTopicId(Integer.parseInt(sr.get("topicId").toString()));
                            asstTopicVo.setTopicDesc(sr.get("topicDesc").toString());
                            asstTopicVo.setCreatedDate(DateUtil.getCurrentDateTime());
                            asstTopicVo.setCreatedBy(user.getEmpNo());

                            asstQuestionService.saveAsstTopic(asstTopicVo);

                            JSONArray subTopicObject = (JSONArray) sr.get("subTopicObject");
                            if (subTopicObject != null) {
                                for (int j = 0; j < subTopicObject.size(); j++) {
                                    JSONObject sr2 = (JSONObject) subTopicObject.get(j);

                                    logger.debug("subTopicId " + sr2.get("subTopicId").toString());
                                    logger.debug("subTopicDesc " + sr2.get("subTopicDesc").toString());
                                    logger.debug("needChoice " + sr2.get("needChoice").toString());

                                    AsstSubtopicVo asstSubtopicVo = new AsstSubtopicVo();
                                    asstSubtopicVo.setQuestionId(jsonResponse.get("questionId").toString());
                                    asstSubtopicVo.setVersion(jsonResponse.get("version").toString());
                                    asstSubtopicVo.setTopicId(Integer.parseInt(sr.get("topicId").toString()));
                                    asstSubtopicVo.setSubTopicId(Integer.parseInt(sr2.get("subTopicId").toString()));
                                    asstSubtopicVo.setSubTopicDesc(sr2.get("subTopicDesc").toString());
                                    asstSubtopicVo.setNeedChoice(Integer.parseInt(sr2.get("needChoice").toString()));
                                    asstSubtopicVo.setChoiceType("R");
                                    asstSubtopicVo.setCreatedDate(DateUtil.getCurrentDateTime());
                                    asstSubtopicVo.setCreatedBy(user.getEmpNo());

                                    asstQuestionService.saveAsstSubTopic(asstSubtopicVo);

                                    JSONArray choiceObject = (JSONArray) sr2.get("choiceObject");
                                    if (choiceObject != null) {
                                        for (int k = 0; k < choiceObject.size(); k++) {
                                            JSONObject sr3 = (JSONObject) choiceObject.get(k);

                                            logger.debug("choiceId " + sr3.get("choiceId").toString());
                                            logger.debug("choiceDesc " + sr3.get("choiceDesc").toString());
                                            logger.debug("choiceReasonFlag " + sr3.get("choiceReasonFlag").toString());

                                            AsstChoiceVo asstChoiceVo = new AsstChoiceVo();
                                            asstChoiceVo.setQuestionId(jsonResponse.get("questionId").toString());
                                            asstChoiceVo.setVersion(jsonResponse.get("version").toString());
                                            asstChoiceVo.setTopicId(Integer.parseInt(sr.get("topicId").toString()));
                                            asstChoiceVo.setSubTopicId(Integer.parseInt(sr2.get("subTopicId").toString()));
                                            asstChoiceVo.setChoiceId(Integer.parseInt(sr3.get("choiceId").toString()));
                                            asstChoiceVo.setChoiceDesc(sr3.get("choiceDesc").toString());
                                            asstChoiceVo.setChoiceReasonFlag(Integer.parseInt(sr3.get("choiceReasonFlag").toString()));
                                            asstChoiceVo.setCreatedDate(DateUtil.getCurrentDateTime());
                                            asstChoiceVo.setCreatedBy(user.getEmpNo());

                                            asstQuestionService.saveAsstChoice(asstChoiceVo);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    logger.debug("update version " + jsonResponse.get("version").toString());

                    warningTypeVo.setQuestionVersion(jsonResponse.get("version").toString());
                    warningTypeVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    warningTypeVo.setUpdatedBy(user.getEmpNo());

                    warningTypeService.updateWarningType(warningTypeVo);
                }else{
                    throw new BusinessException("ข้อมูลยังเป็น Version เดิม");
                }
            }
        }
    }

    @Override
    public void sendProjectFIN(ScoreEngineVo scoreEngine, WarningInfoVo warningInfo, UserData user) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("sendProjectFIN");
        }

        Date d = new Date();
        SimpleDateFormat dfTime = new SimpleDateFormat("HHmmss");
        SimpleDateFormat dfDate = new SimpleDateFormat("yyyyMMdd");

        JSONObject inputData = new JSONObject();
        inputData.put("channelId", BusinessConst.WSChannel.EWS_L_CHANNEL);
        inputData.put("refId", dfDate.format(d) + dfTime.format(d));
        inputData.put("transDt", dfDate.format(d));
        inputData.put("transTime", dfTime.format(d));
        inputData.put("finalFlag", "N");
        inputData.put("finalDt", dfDate.format(d));

        inputData.put("appId", "");
        inputData.put("custId", scoreEngine.getCustId());
        inputData.put("custName", scoreEngine.getCustName());
        inputData.put("respUnitId", scoreEngine.getRespUnitId());

        inputData.put("Hv_Fin", "Y");
        inputData.put("Limit_Size", scoreEngine.getLimitSize()); 

        if ("A".equals(scoreEngine.getStateType())) {
            inputData.put("Statetype", scoreEngine.getStateType());
            inputData.put("COGS_SALES", scoreEngine.getCogsSales());
            inputData.put("DSCR_CFO", scoreEngine.getDsceCfo());
            inputData.put("DE", scoreEngine.getDe());
            inputData.put("INTEREST_RATIO", scoreEngine.getInterestRatio());
            inputData.put("OPERATING_ROTE", scoreEngine.getOperationRote());
            inputData.put("SLOPE_PROFIT_MARGIN", scoreEngine.getSlopeProfitMargin());
            inputData.put("QUICK_RATIO", scoreEngine.getQuickRatio());
        } else {
            inputData.put("Statetype", scoreEngine.getStateType());
            inputData.put("R_COGS_SALES", scoreEngine.getCogsSales());
            inputData.put("R_DSCR_CFO", scoreEngine.getDsceCfo());
            inputData.put("R_DE", scoreEngine.getDe());
            inputData.put("R_INTEREST_RATIO", scoreEngine.getInterestRatio());
            inputData.put("R_OPERATING_ROTE", scoreEngine.getOperationRote());
            inputData.put("R_SLOPE_PROFIT_MARGIN", scoreEngine.getSlopeProfitMargin());
            inputData.put("R_QUICK_RATIO", scoreEngine.getQuickRatio());
        }
        logger.debug("data for send " + inputData.toJSONString());
        
        WSLogVO logVo = new WSLogVO();
        logVo.setChannelID(BusinessConst.WSChannel.EWS_L_CHANNEL);
        String header =  warningInfo.getWarningHeaderId() > 0 ? String.valueOf(warningInfo.getWarningHeaderId()) : "";
        String info =  warningInfo.getWarningId() != null ? String.valueOf(warningInfo.getWarningId()) : "";
        logVo.setRemark(getRemarkWSLog(header, warningInfo.getCifNo(),null,info));
        logVo.setServiceID(BusinessConst.ProjectName.FIN_PROJECT);
        logVo.setSystemID(BusinessConst.SYSTEM_ID.SCORE_ENGINE);
        logVo.setCifNo(warningInfo.getCifNo());
                
        JSONArray arrResponse = null;
        try{
               arrResponse =  scoreEngineService.inquiryScoreEngine(BusinessConst.ProjectName.FIN_PROJECT, inputData,logVo);
        }catch(Exception e){
               logger.error("Error sendProjectFIN : " + e.getMessage());
              throw new ScoreEngineException(e.getMessage());
         }
        JSONArray jsonErrors = (JSONArray) arrResponse.get(0);
        JSONObject jsonResponse = (JSONObject) arrResponse.get(1);

        if (jsonErrors != null && jsonErrors.size() > 0) {
            JSONObject error = (JSONObject) jsonErrors.get(0);
            throw new ScoreEngineException(error.get("message").toString());
        }
        JSONArray responseErrorDescObj = (JSONArray) jsonResponse.get("responseErrorDesc");
        if(responseErrorDescObj != null && responseErrorDescObj.size() >0){
            JSONObject error = (JSONObject) responseErrorDescObj.get(0);
            throw new ScoreEngineException(error.get("errorCode").toString()+" : "+error.get("errorDescription").toString());
        }

        logger.debug("FinScore " + jsonResponse.get("FinScore").toString());
        logger.debug("Fin_PD " + jsonResponse.get("Fin_PD").toString());
        logger.debug("FinOdds " + jsonResponse.get("FinOdds").toString());

        WarningProcessVo warningProcessVo = new WarningProcessVo();
        warningProcessVo.setWarningHeaderId(warningInfo.getWarningHeaderId());
        warningProcessVo.setWarningId(warningInfo.getWarningId());
        warningProcessVo.setFinScore(new BigDecimal((jsonResponse.get("FinScore") != null ? jsonResponse.get("FinScore").toString() : "0")));
        warningProcessVo.setFinPD(new BigDecimal((jsonResponse.get("Fin_PD") != null ? jsonResponse.get("Fin_PD").toString() : "0")));
        warningProcessVo.setFinODDS(new BigDecimal((jsonResponse.get("FinOdds") != null ? jsonResponse.get("FinOdds").toString() : "0")));
        warningProcessVo.setUpdatedDate(DateUtil.getCurrentDateTime());
        warningProcessVo.setUpdatedBy(user.getEmpNo());
        warningProcessVo.setHvFin(BusinessConst.Flag.Y);
        
        warningProcessService.updateScoreProjectFIN(warningProcessVo);

        WarningFactorVo warningFactorVo = new WarningFactorVo();
        warningFactorVo.setWarningId(warningInfo.getWarningId());

        warningFactorService.deleteWarningFactor(warningFactorVo);

        JSONArray scoreFactorObj = (JSONArray) jsonResponse.get("ScoreFactorObj");
        JSONArray scoreFactorObj_Re = (JSONArray) jsonResponse.get("ScoreFactorObj_Re");
        String stateType = (String) jsonResponse.get("Statetype");
        if (stateType != null) {
            if (stateType.equalsIgnoreCase("A")) { //Statetype equals "A"
                if (scoreFactorObj != null) {
                    for (int i = 0; i < scoreFactorObj.size(); i++) {
                        JSONObject sr = (JSONObject) scoreFactorObj.get(i);

                        logger.debug("FactorCd " + sr.get("FactorCd").toString());
                        logger.debug("FactorDesc " + sr.get("FactorDesc").toString());
                        logger.debug("FactorValue " + sr.get("FactorValue").toString());
                        logger.debug("WeightedScroe " + sr.get("WeightedScroe").toString());
                        logger.debug("AttributeID " + sr.get("AttributeID").toString());

                        warningFactorVo = new WarningFactorVo();
                        warningFactorVo.setWarningId(warningInfo.getWarningId());
                        warningFactorVo.setFactorCd(new BigDecimal((sr.get("FactorCd") != null ? sr.get("FactorCd").toString() : "0")));
                        warningFactorVo.setFactorDesc(sr.get("FactorDesc").toString());
                        warningFactorVo.setFactorValue(sr.get("FactorValue").toString());
                        warningFactorVo.setWeightedScore(Double.valueOf(sr.get("WeightedScroe").toString()));
                        warningFactorVo.setAttributeId(Integer.valueOf(sr.get("AttributeID").toString()));

                        warningFactorService.saveWarningFactor(warningFactorVo);
                    }
                }
            } else if (stateType.equalsIgnoreCase("R")) { //Statetype equals "R"
                if (scoreFactorObj_Re != null) {
                    for (int i = 0; i < scoreFactorObj_Re.size(); i++) {
                        JSONObject sr_Re = (JSONObject) scoreFactorObj_Re.get(i);

                        logger.debug("FactorCd " + sr_Re.get("FactorCd").toString());
                        logger.debug("FactorDesc " + sr_Re.get("FactorDesc").toString());
                        logger.debug("FactorValue " + sr_Re.get("FactorValue").toString());
                        logger.debug("WeightedScroe " + sr_Re.get("WeightedScroe").toString());
                        logger.debug("AttributeID " + sr_Re.get("AttributeID").toString());

                        warningFactorVo = new WarningFactorVo();
                        warningFactorVo.setWarningId(warningInfo.getWarningId());
                        warningFactorVo.setFactorCd(new BigDecimal((sr_Re.get("FactorCd") != null ? sr_Re.get("FactorCd").toString() : "0")));
                        warningFactorVo.setFactorDesc(sr_Re.get("FactorDesc").toString());
                        warningFactorVo.setFactorValue(sr_Re.get("FactorValue").toString());
                        warningFactorVo.setWeightedScore(Double.valueOf(sr_Re.get("WeightedScroe").toString()));
                        warningFactorVo.setAttributeId(Integer.valueOf(sr_Re.get("AttributeID").toString()));

                        warningFactorService.saveWarningFactor(warningFactorVo);
                    }
                }
            }
        }
       
    }

    @Override
    public JSONObject sendProjectEWS(ScoreEngineVo scoreEngine , WSLogVO logVo) throws Exception , ScoreEngineException {
        if (logger.isInfoEnabled()) {
            logger.info("sendProjectEWS");
        }

        Date d = new Date();
        SimpleDateFormat dfDate = new SimpleDateFormat("yyyyMMdd");

        JSONObject inputData = new JSONObject();
        inputData.put("timeKey", dfDate.format(d));
        inputData.put("appId", scoreEngine.getAppId());
        inputData.put("custId", scoreEngine.getCustId());
        inputData.put("custName", scoreEngine.getCustName());
        inputData.put("Size", scoreEngine.getSize());
        
        inputData.put("Hv_Rating", scoreEngine.getHvRating());
        inputData.put("RatingOdds", scoreEngine.getRatingODDS());
        inputData.put("Hv_NCB", scoreEngine.getHvNCB());
        inputData.put("NCB_LastUpdate", scoreEngine.getNcbLastUpdate());
        inputData.put("NCBOdds_Ind_EWS", scoreEngine.getNcbODDSIndEWS());
        inputData.put("NCBOdds_Ind_EWS_backup", scoreEngine.getNcbODDSIndEWSBackup());
        inputData.put("NCBOdds_EWS", scoreEngine.getNcbODDSEWS());
        inputData.put("NCBOdds_Ind_EWS_Online", scoreEngine.getNcbODDSIndEWSOnline());
        inputData.put("NCBOdds_Ind_EWS_backup_Online", scoreEngine.getNcbODDSIndEWSBackupOnline());
        inputData.put("NCBOdds_EWS_Online", scoreEngine.getNcbODDSEWSOnline());
        inputData.put("Hv_Fin", scoreEngine.getHvFin());
        inputData.put("FinOdds", scoreEngine.getFinODDS());
        inputData.put("Hv_Quanti", scoreEngine.getHvQuanti());
        inputData.put("QuantiBhvOdds", scoreEngine.getQuantiBhvPD());
        inputData.put("questionId", scoreEngine.getQuestionId());
        inputData.put("version", scoreEngine.getVersion());
        inputData.put("topicObject", scoreEngine.getTopicObj());       
        inputData.put("DPD", scoreEngine.getDpd());
        inputData.put("Bucket_DPD", scoreEngine.getBucketDPD());
        //---------- OD
        inputData.put("Hv_DelingDate", scoreEngine.getHvDelinqDate());
        if(scoreEngine.getDelinqDate() != null){
                inputData.put("DelinquencyDate", dfDate.format(scoreEngine.getDelinqDate()));
        }else{
                inputData.put("DelinquencyDate", null);
        }
        inputData.put("DPD_OD", scoreEngine.getDpdOdBigdecimal());
        inputData.put("Bucket_DPD_OD", scoreEngine.getBucketDpdOd());
        inputData.put("Renewal", scoreEngine.getRenewal());
        inputData.put("Bucket_Renewal", scoreEngine.getBucketRenewal());
        //----- CR-L R3
        inputData.put("C-Class", scoreEngine.getcClass());
        inputData.put("Authorize_Review_Date",scoreEngine.getAuthorizeReviewDate() );
        inputData.put("Min_Review_Date", scoreEngine.getMinReviewDate());
        inputData.put("PauseFlag", scoreEngine.getPauseFlag());
        inputData.put("ModelID",scoreEngine.getModelID() );
        inputData.put("Authorize_Rating_Date", scoreEngine.getAuthorizeRatingDate());
        inputData.put("Next_Rating_Date", scoreEngine.getNextRatingDate());
        inputData.put("Rating_MTH", scoreEngine.getRatingMTH());
        inputData.put("Bucket_Rating", scoreEngine.getBucketRating());
        
        logger.debug("data for send " + inputData.toJSONString());
         if(logVo == null){
           logVo = new WSLogVO();
        }
        String header =  logVo.getWarningHeaderId() > 0 ? String.valueOf(logVo.getWarningHeaderId()) : "";
        String info =  logVo.getWarningId() > 0 ? String.valueOf(logVo.getWarningId()) : "";
        logVo.setChannelID(BusinessConst.WSChannel.EWS_CHANNEL);
        String remark = getRemarkWSLog(header, logVo.getCifNo(),scoreEngine.getQuestionId(),info);
        if(StringUtil.isNotEmpty(remark) && StringUtil.isNotEmpty(logVo.getWarningInfoIdAndType()) ){
              remark = remark + "," + logVo.getWarningInfoIdAndType();
        }
        logVo.setRemark(remark);
        logVo.setServiceID(BusinessConst.ProjectName.EWSQ_PROJECT);
        logVo.setSystemID(BusinessConst.SYSTEM_ID.SCORE_ENGINE);
        
        JSONArray arrResponse = null;
        try{
            arrResponse = scoreEngineService.inquiryScoreEngine(BusinessConst.ProjectName.EWSQ_PROJECT, inputData,logVo);
        }catch(Exception e){
               logger.error("Error sendProjectEWS : " + e.getMessage());
              throw new ScoreEngineException(e.getMessage());
         }
        JSONArray jsonErrors = (JSONArray) arrResponse.get(0);
        JSONObject jsonResponse = (JSONObject) arrResponse.get(1);

        if (jsonErrors != null && jsonErrors.size() > 0) {
            JSONObject error = (JSONObject) jsonErrors.get(0);
            throw new ScoreEngineException(error.get("message").toString());
        }
        logger.debug("JSONString " + jsonResponse.toJSONString());
        JSONArray responseErrorDescObj = (JSONArray) jsonResponse.get("responseErrorDesc");
        if(responseErrorDescObj != null && responseErrorDescObj.size() >0){
            JSONObject error = (JSONObject) responseErrorDescObj.get(0);
            throw new ScoreEngineException(error.get("errorCode").toString()+" : "+error.get("errorDescription").toString());
        }
        
        return jsonResponse;
    }
   

    @Override
    public String checkConnection() throws Exception {
        String resultCon = "P";
        String channelId = BusinessConst.WSChannel.EWS_CHANNEL;
        String projectName = BusinessConst.ProjectName.EQUS_PROJECT;

        SimpleDateFormat dfTime = new SimpleDateFormat("HHmmss");
        SimpleDateFormat dfDate = new SimpleDateFormat("yyyyMMdd");
        Date d = new Date();

        JSONObject inputData = new JSONObject();
        inputData.put("channelId", channelId);
        inputData.put("refId", dfDate.format(d) + dfTime.format(d));
        inputData.put("transDt", dfDate.format(d));
        inputData.put("transTime", dfTime.format(d));

        JSONArray arrResponse = null;
        try{
             arrResponse = scoreEngineService.inquiryScoreEngine(projectName, inputData ,null);
        }catch(Exception e){
           logger.error("Error checkConnection : " + e.getMessage());
           return "E";
        }
      return resultCon;
    }
    
  
    private String getRemarkWSLog(String warningHeaderId , String cif , String questionId , String warningInfoId){
      String result = "";
      try{
          if(!ValidatorUtil.isNullOrEmpty(warningHeaderId)){ 
             result = "WarningHeaderID:".concat(warningHeaderId);
          }
          if(!ValidatorUtil.isNullOrEmpty(cif)){
              if(result.trim().length() > 0){
                 result = result + ",";
              } 
              result = result.concat("CifNo:").concat(cif);
          }
          if(!ValidatorUtil.isNullOrEmpty(warningInfoId)){
             if(result.trim().length() > 0){
                 result = result + ",";
              } 
              result = result.concat("WarningInfoID:").concat(warningInfoId);
          }
          if(!ValidatorUtil.isNullOrEmpty(questionId)){
             if(result.trim().length() > 0){
                 result = result + ",";
              } 
              result = result.concat("QuestionID:").concat(questionId);
          }
         
          
      }catch(Exception e){
         logger.error("" + e.getMessage());
      }
      return result;
    }

    @Override
    public JSONObject sendLatePayment(ScoreEngineVo scoreEngine, WSLogVO logVo) throws Exception {
         if (logger.isInfoEnabled()) {
            logger.info("sendTriggerAndPayment");
        }

        Date d = new Date();
        SimpleDateFormat dfTime = new SimpleDateFormat("HHmmss");
        SimpleDateFormat dfDate = new SimpleDateFormat("yyyyMMdd");

        JSONObject inputData = new JSONObject();
        inputData.put("channelID", BusinessConst.WSChannel.EWS_L_CHANNEL);
        inputData.put("transDt", dfDate.format(d));
        inputData.put("transTime", dfTime.format(d));
        inputData.put("appId", scoreEngine.getAppId());
        inputData.put("custId", scoreEngine.getCustId());
        inputData.put("custName", scoreEngine.getCustName());
        inputData.put("Limit_Size", scoreEngine.getLimitSize());
        inputData.put("Size", scoreEngine.getSize());
        inputData.put("topicObjectLatePayment", scoreEngine.getTopicObjectLatePayment());
        
        logger.debug("data for send " + inputData.toJSONString());
        if(logVo == null){
           logVo = new WSLogVO();
        }
        String header =  logVo.getWarningHeaderId() > 0 ? String.valueOf(logVo.getWarningHeaderId()) : "";
        String info =  logVo.getWarningId() > 0 ? String.valueOf(logVo.getWarningId()) : "";
        logVo.setChannelID(BusinessConst.WSChannel.EWS_L_CHANNEL);
        logVo.setRemark(getRemarkWSLog(header,  logVo.getCifNo() ,scoreEngine.getQuestionId(),info));
        logVo.setServiceID(BusinessConst.ProjectName.LATEPAYMENT_PROJECT);
        logVo.setSystemID(BusinessConst.SYSTEM_ID.SCORE_ENGINE);
                
        JSONArray arrResponse = null;
        try{
            arrResponse = scoreEngineService.inquiryScoreEngine(BusinessConst.ProjectName.LATEPAYMENT_PROJECT, inputData,logVo);
        }catch(Exception e){
              logger.error("Error sendPayment : " + e.getMessage());
              throw new ScoreEngineException(e.getMessage());
         }
        JSONArray jsonErrors = (JSONArray) arrResponse.get(0);
        JSONObject jsonResponse = (JSONObject) arrResponse.get(1);

        if (jsonErrors != null && jsonErrors.size() > 0) {
            JSONObject error = (JSONObject) jsonErrors.get(0);
            throw new ScoreEngineException(error.get("message").toString());
        }
        logger.debug("JSONString " + jsonResponse.toJSONString());
        JSONArray responseErrorDescObj = (JSONArray) jsonResponse.get("responseErrorDesc");
        if(responseErrorDescObj != null && responseErrorDescObj.size() >0){
            JSONObject error = (JSONObject) responseErrorDescObj.get(0);
            throw new ScoreEngineException(error.get("errorCode").toString()+" : "+error.get("errorDescription").toString());
        }
        return jsonResponse;
    }
    @Override
    public JSONObject sendTrigger(ScoreEngineVo scoreEngine, WSLogVO logVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("sendTriggerAndPayment");
        }

        Date d = new Date();
        SimpleDateFormat dfTime = new SimpleDateFormat("HHmmss");
        SimpleDateFormat dfDate = new SimpleDateFormat("yyyyMMdd");

        JSONObject inputData = new JSONObject();
        inputData.put("channelID", BusinessConst.WSChannel.EWS_L_CHANNEL);
        inputData.put("transDt", dfDate.format(d));
        inputData.put("transTime", dfTime.format(d));
        inputData.put("appId", scoreEngine.getAppId());
        inputData.put("custId", scoreEngine.getCustId());
        inputData.put("custName", scoreEngine.getCustName());
        inputData.put("Limit_Size", scoreEngine.getLimitSize());
        inputData.put("Size", scoreEngine.getSize());
        inputData.put("topicObjectTrigger", scoreEngine.getTopicObjectTrigger());
        inputData.put("topicObjectPayment", scoreEngine.getTopicObjectPayment());
        
        logger.debug("data for send " + inputData.toJSONString());
        if(logVo == null){
           logVo = new WSLogVO();
        }
        String header =  logVo.getWarningHeaderId() > 0 ? String.valueOf(logVo.getWarningHeaderId()) : "";
        String info =  logVo.getWarningId() > 0 ? String.valueOf(logVo.getWarningId()) : "";
        logVo.setChannelID(BusinessConst.WSChannel.EWS_L_CHANNEL);
        logVo.setRemark(getRemarkWSLog(header,  logVo.getCifNo() ,scoreEngine.getQuestionId(),info));
        logVo.setServiceID(BusinessConst.ProjectName.TRIGGER_PROJECT);
        logVo.setSystemID(BusinessConst.SYSTEM_ID.SCORE_ENGINE);
                
        JSONArray arrResponse = null;
        try{
            arrResponse = scoreEngineService.inquiryScoreEngine(BusinessConst.ProjectName.TRIGGER_PROJECT, inputData,logVo);
        }catch(Exception e){
              logger.error("Error sendPayment : " + e.getMessage());
              throw new ScoreEngineException(e.getMessage());
         }
        JSONArray jsonErrors = (JSONArray) arrResponse.get(0);
        JSONObject jsonResponse = (JSONObject) arrResponse.get(1);

        if (jsonErrors != null && jsonErrors.size() > 0) {
            JSONObject error = (JSONObject) jsonErrors.get(0);
            throw new ScoreEngineException(error.get("message").toString());
        }
        logger.debug("JSONString " + jsonResponse.toJSONString());
        JSONArray responseErrorDescObj = (JSONArray) jsonResponse.get("responseErrorDesc");
        if(responseErrorDescObj != null && responseErrorDescObj.size() >0){
            JSONObject error = (JSONObject) responseErrorDescObj.get(0);
            throw new ScoreEngineException(error.get("errorCode").toString()+" : "+error.get("errorDescription").toString());
        }
        return jsonResponse;
    }
}