/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface ActionCloseBusiness {
    
    public PaginatedListImpl getCloseList(PaginatedListImpl paginate, SearchBean searchBean, UserData user , int page) throws Exception;  
    public PaginatedListImpl getCloseListForExport(SearchBean searchBean) throws Exception; 
    public PaginatedListImpl getCloseListEwsl(PaginatedListImpl paginate, SearchBean searchBean, UserData user, int pageAmt) throws Exception;
    public PaginatedListImpl getCloseListForExportEwsl(SearchBean searchBean) throws Exception;
    public List<ActionCloseVo> getcloseJobDetailList(String warningHeadId, String warningType) throws Exception;
    public List<ActionCloseVo> getcloseJobDetailListByWarningHeadId(String warningHeadId, String warningType) throws Exception;
    
}
