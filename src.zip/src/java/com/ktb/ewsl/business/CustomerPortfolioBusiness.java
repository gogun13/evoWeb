/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.CustomerPortfolioVo;
import com.ktb.ewsl.vo.RptIndividualRiskLevelVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author KTBDevLoan
 */
public interface CustomerPortfolioBusiness {
    
    public PaginatedListImpl getCustomerPortfolioList(PaginatedListImpl paginate, SearchBean searchBean, UserData user , int page) throws Exception;    
    public List<RptIndividualRiskLevelVo> getIndividualRiskLevel(Integer cifNo, String rishType) throws Exception;
    public ArrayList<CustomerPortfolioVo> getCustomerPortfolioListExport(SearchBean searchBean) throws Exception;
    //R4
    public Map getCustomerPortfolioList(SearchBean searchBean) throws Exception;
    public String getMaxBatchDate(SearchBean searchBean) throws Exception;
}
