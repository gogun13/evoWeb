package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningFileAttachmentsService;
import com.ktb.ewsl.vo.WarningFileAttachmentVo;
import com.ktbcs.core.business.AbstractBusiness;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Thanakorn Ch.
 */
@Service
public class WarningFileAttachmentsBusinessImpl extends AbstractBusiness implements WarningFileAttachmentsBusiness{
    private static final Logger log = Logger.getLogger(WarningFileAttachmentsBusinessImpl.class);

    @Autowired
    WarningFileAttachmentsService warningFileAttachmentsService;

    @Override
    public List<WarningFileAttachmentVo> findByWarningHeaderID( int warnHeadID ) throws Exception {
        if(log.isInfoEnabled()){
            log.info("findByWarningHeaderID");
        }
        return warningFileAttachmentsService.findByWarningHeaderID( warnHeadID );
    }

    @Override
    public void deleteFile(int warnHeadID, int seq) throws Exception {
        if(log.isInfoEnabled()){
            log.info("deleteFile");
        }
        warningFileAttachmentsService.deleteFile(warnHeadID, seq);
    }

    @Override
    public void saveFile(WarningFileAttachmentVo vo) throws Exception {
        if(log.isInfoEnabled()){
            log.info("saveFile");
        }
        warningFileAttachmentsService.saveFile( vo );
    }

    @Override
    public WarningFileAttachmentVo findFileName(int warnHeadID, int seq) throws Exception {
        if(log.isInfoEnabled()){
            log.info("findFileName");
        }
        return warningFileAttachmentsService.findFileName( warnHeadID, seq);
    }
}
