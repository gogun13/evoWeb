/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningTypePrivilegeService;
import com.ktb.ewsl.vo.WarningTypePrivilegeVo;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class WarningTypePrivilegeBusinessImpl implements WarningTypePrivilegeBusiness{
    
    @Autowired
    private  WarningTypePrivilegeService warningTypePrivilegeService;

    @Override
    public ArrayList<WarningTypePrivilegeVo> findWarningTypePrivilegeByRole(String roleId) throws Exception {
        return warningTypePrivilegeService.findWarningTypePrivilegeByRole(roleId);
    }
}
