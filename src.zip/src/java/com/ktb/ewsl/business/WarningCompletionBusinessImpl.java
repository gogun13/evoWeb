/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningCompletionService;
import com.ktb.ewsl.vo.WarningCompletionVo;
import com.ktbcs.core.business.AbstractBusiness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author pumin
 */
@Service
public class WarningCompletionBusinessImpl extends AbstractBusiness implements WarningCompletionBusiness{

    @Autowired
    private WarningCompletionService sarningCompletionService;

    @Override
    public void InsertWarningCompletion(WarningCompletionVo vo) throws Exception {
        sarningCompletionService.InsertWarningCompletion(vo);
    }
    
  
}
