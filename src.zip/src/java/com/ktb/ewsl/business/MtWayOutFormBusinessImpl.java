/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.MtWayOutFormService;
import com.ktb.ewsl.vo.MtWayOutFormVo;
import com.ktbcs.core.business.AbstractBusiness;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Pratya
 */
@Service
public class MtWayOutFormBusinessImpl extends AbstractBusiness implements MtWayOutFormBusiness {

  
    @Autowired
    private MtWayOutFormService mtWayOutFormService;

    @Override
    public ArrayList<MtWayOutFormVo> getQuestionList() throws Exception {

        return mtWayOutFormService.getQuestionList();


    }
}
