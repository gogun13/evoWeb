/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.CRCustReviewEwsServices;
import com.ktbcs.core.utilities.StringUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Tum_Surapong
 */
@Service
public class CrAccountDetailBusinessImpl implements CrAccountDetailBusiness {

    private static final Logger log = Logger.getLogger(CrAccountDetailBusinessImpl.class);
    @Autowired
    private CRCustReviewEwsServices crCustReviewEwsServices;

    @Override
    public String getLoanGrpProd(String prodGroup, String prodType, String acctSubType, String marketCode) throws Exception {
        String loanGrpProd = null;
        
        try{
            if ("00064".equals(acctSubType)) {
                loanGrpProd = "Trade Finance";
            } else {
                if (StringUtil.isNotEmpty(marketCode)) {
                    if(marketCode.equals("9999")){
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType, marketCode);
                    }else{
                        loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(marketCode);
                    }
                } else {
                    if (StringUtil.isNotEmpty(prodGroup) && StringUtil.isNotEmpty(acctSubType) && !"00000".equals(acctSubType)) {
                         loanGrpProd = crCustReviewEwsServices.getLoanGrpProd(prodGroup, acctSubType);
                    } else if ("1001".equals(prodType)) {
                        loanGrpProd = "O/D";
                    }
                }
            }
        }catch(Exception e){
            throw e;
        }
        
        return loanGrpProd;
    }
}
