/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.RiskLevelMappingVo;
import java.util.Map;

/**
 *
 * @author KTBDevLoan
 */
public interface RiskLevelMappingBusiness {
    
    public String getRiskLevelThatReq(String columnReq, String riskLevelMasterSE)throws Exception;
    public Map<String,String> lookUpDataRiskLevel(String columnReq)throws Exception;
    public Map<String, RiskLevelMappingVo> lookUpRiskLevelVo()throws Exception;
}
