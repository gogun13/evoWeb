/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.RolePrivilegeService;
import com.ktb.ewsl.vo.RolePrivilegeVo;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



/**
 *
 * @author KTBDevLoan
 */
@Service
public class RolePrivilegeBusinessImpl implements RolePrivilegeBusiness{
    
    private static final Logger log = Logger.getLogger(RolePrivilegeBusinessImpl.class);
    @Autowired
    private RolePrivilegeService rolePrivilegeService;

    @Override
    public String getEmployeeID(String roleCode) throws Exception {
        String employeeAll = "";
        try{
            List<RolePrivilegeVo> roleList =  rolePrivilegeService.getEmployeeID(roleCode);
              if(roleList != null && roleList.size() > 0){
                for(int i=0 ; i < roleList.size(); i++){
			 RolePrivilegeVo roleVo = (RolePrivilegeVo)roleList.get(i);
                         if((roleVo != null )&&(roleVo.getEmployeeId() != null) && (!"".equals(roleVo.getEmployeeId()))){
                           String data = roleVo.getEmployeeId();
                           employeeAll = employeeAll.concat("'").concat(data).concat("'");
                            if(i < roleList.size() - 1 ){
                                   employeeAll  = employeeAll.concat(",");
                            }
                         }
		}
            }
              
        }catch(Exception e){
           log.error("Error occur in while process RolePrivilegeBusinessImpl.getEmployeeID: " + e.getMessage() , e);
        }
        return employeeAll;
    }
    
    
}
