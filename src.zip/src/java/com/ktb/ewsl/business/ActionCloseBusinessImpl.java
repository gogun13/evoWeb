/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionCloseService;
import com.ktb.ewsl.services.WarningCloseService;
import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktb.ewsl.vo.ReportCloseJobVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.services.KTBEmpDirectoryService;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class ActionCloseBusinessImpl extends AbstractBusiness implements  ActionCloseBusiness{
    
    private static Logger log = Logger.getLogger(ActionCloseBusinessImpl.class);

    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    @Autowired
    private ActionCloseService actionCloseService;
    @Autowired
    private WarningCloseService warningCloseService;
    @Autowired
    private KTBEmpDirectoryService kTBEmpDirectoryService;
          
    @Override
    public PaginatedListImpl getCloseList(PaginatedListImpl paginate, SearchBean searchBean, UserData user, int pageAmt) throws Exception {
          try {
            if (log.isInfoEnabled()) {
                log.info("ActionCloseBusinessImpl.getCloseList");
                log.info("EmpNo : " + user.getEmpNo());
                log.info("RoleId : " + user.getRoleId());
                log.info("DeptCode : " + user.getDeptCode());
            }

            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            searchBean.setResponseUnit(user.getDeptCode());
            searchBean.setRmId(user.getEmpNo());
            searchBean.setRoleId(user.getRoleId());
//            if (BusinessConst.SearchTitle.RM_NAME.equals(searchBean.getTextSearch()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getByName()))) {
//                searchBean.setEmpNoCondition(ktbEmpDirectoryBusiness.searchForFindEmpNo(searchBean.getByName()));
//            }

            String roleQuery = user.getRoleId();
            paginate = actionCloseService.getCloseListReport(paginate, searchBean, pageAmt, roleQuery);

        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseBusinessImpl.getTaskList : " + e.getMessage(), e);
        }
        return paginate;
    }
          
    @Override
    public PaginatedListImpl getCloseListEwsl(PaginatedListImpl paginate, SearchBean searchBean, UserData user, int pageAmt) throws Exception {
        ArrayList<ReportCloseJobVo> reportList                  = null;
        UserData                    userData                    = null;
//        List<ReportCloseJobVo>      typeOfCloaseFlagList        = null;
//        String                      closeJobType                = "";
//        String                      reasonDetail                = "";
//        String                      remark                      = "";
//        String                      actionBy                    = "";
//        String                      actionDtS                   = "";
//        String                      approveBy                   = "";
//        String                      approveDtS                  = "";
        
          try {
            if (log.isInfoEnabled()) {
                log.info("ActionCloseBusinessImpl.getCloseList");
                log.info("EmpNo : " + user.getEmpNo());
                log.info("RoleId : " + user.getRoleId());
                log.info("DeptCode : " + user.getDeptCode());
            }

            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            searchBean.setResponseUnit(user.getDeptCode());
            searchBean.setRmId(user.getEmpNo());
            searchBean.setRoleId(user.getRoleId());
//            if (BusinessConst.SearchTitle.RM_NAME.equals(searchBean.getTextSearch()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getByName()))) {
//                searchBean.setEmpNoCondition(ktbEmpDirectoryBusiness.searchForFindEmpNo(searchBean.getByName()));
//            }

            String roleQuery = user.getRoleId();
            paginate    = actionCloseService.getCloseListReportEwsl(paginate, searchBean, pageAmt, roleQuery);
            reportList  = paginate.getList();
            
            if(reportList!=null){
                for(ReportCloseJobVo reportCloseJobVo:reportList){
                    userData = kTBEmpDirectoryService.getUserDetail(reportCloseJobVo.getActionBy());
                    if(userData!=null){
                        reportCloseJobVo.setActionByFullName(user.getFullName());
                    }
                    
                    userData = kTBEmpDirectoryService.getUserDetail(reportCloseJobVo.getApproveBy());
                    if(userData!=null){
                        reportCloseJobVo.setApproveByFullName(user.getFullName());
                    }
                }
            }
            
//            if(reportList!=null){
//                for(ReportCloseJobVo reportCloseJobVo:reportList){
//                    closeJobType         = "";
//                    reasonDetail         = "";
//                    remark               = "";
//                    actionBy             = "";
//                    actionDtS            = "";
//                    approveBy            = "";
//                    approveDtS           = "";
//                    typeOfCloaseFlagList = actionCloseService.getDataByWarningHeadIdForEwsl(reportCloseJobVo.getWarningHeaderId());
//                    if(typeOfCloaseFlagList!=null && !typeOfCloaseFlagList.isEmpty()){
//                        for(ReportCloseJobVo vo:typeOfCloaseFlagList){
//                            closeJobType += closeJobType.equals("")?"- " + vo.getCloseJobType():"<br/>- " + vo.getCloseJobType();
//                            reasonDetail += reasonDetail.equals("")?"- " + vo.getReasonDetail():"<br/>- " + vo.getReasonDetail();
//                            remark       += remark.equals("")?"- " + vo.getRemark():"<br/>- " + vo.getRemark();
//                            
////                            if(vo.getCloseJobFlg().equals("CIF")){
////                                approveBy  += approveBy.equals("")?"- " + vo.getCrBy():"<br/>- " + vo.getCrBy();
////                                approveDtS += approveDtS.equals("")?"- " + vo.getCrDtS():"<br/>- " + vo.getCrDtS();
////                            }else if(vo.getCloseJobFlg().equals("JOB")){
////                                actionBy  += actionBy.equals("")?"- " + vo.getCrBy():"<br/>- " + vo.getCrBy();
////                                actionDtS += actionDtS.equals("")?"- " + vo.getCrDtS():"<br/>- " + vo.getCrDtS();
////                            }
//                            
//                        }
//                    }
//                    reportCloseJobVo.setCloseJobType(closeJobType);
//                    reportCloseJobVo.setReasonDetail(reasonDetail);
//                    reportCloseJobVo.setRemark(remark);
//                    reportCloseJobVo.setApproveBy(approveBy);
//                    reportCloseJobVo.setApproveDtS(approveDtS);
//                    reportCloseJobVo.setActionBy(actionBy);
//                    reportCloseJobVo.setActionDtS(actionDtS);
//                }
//            }

        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseBusinessImpl.getCloseListEwsl : " + e.getMessage(), e);
        }
        return paginate;
    }
    
    @Override
    public PaginatedListImpl getCloseListForExport(SearchBean searchBean) throws Exception {
        return actionCloseService.getCloseListReportForExport(searchBean);
    }
    
    @Override
    public PaginatedListImpl getCloseListForExportEwsl(SearchBean searchBean) throws Exception {
//        ArrayList<ReportCloseJobVo> reportList                  = null;
//        List<ReportCloseJobVo>      typeOfCloaseFlagList        = null;
//        String                      closeJobType                = "";
//        String                      reasonDetail                = "";
//        String                      remark                      = "";
//        String                      actionBy                    = "";
//        String                      actionDtS                   = "";
//        String                      approveBy                   = "";
//        String                      approveDtS                  = "";
        PaginatedListImpl           paginate                    = null;
        
        try{
            paginate    = actionCloseService.getCloseListReportForExportEwsl(searchBean);
//            reportList  = paginate.getList();
            
//            if(reportList!=null){
//                for(ReportCloseJobVo reportCloseJobVo:reportList){
//                    closeJobType         = "";
//                    reasonDetail         = "";
//                    remark               = "";
//                    actionBy             = "";
//                    actionDtS            = "";
//                    approveBy            = "";
//                    approveDtS           = "";
//                    typeOfCloaseFlagList = actionCloseService.getDataByWarningHeadIdForEwsl(reportCloseJobVo.getWarningHeaderId());
//                    if(typeOfCloaseFlagList!=null && !typeOfCloaseFlagList.isEmpty()){
//                        for(ReportCloseJobVo vo:typeOfCloaseFlagList){
//                            closeJobType += closeJobType.equals("")?"- " + vo.getCloseJobType():"\n- " + vo.getCloseJobType();
//                            reasonDetail += reasonDetail.equals("")?"- " + vo.getReasonDetail():"\n- " + vo.getReasonDetail();
//                            remark       += remark.equals("")?"- " + vo.getRemark():"\n- " + vo.getRemark();
//                            
////                            if(vo.getCloseJobFlg().equals("CIF")){
////                                approveBy  += approveBy.equals("")?"- " + vo.getCrBy():"<br/>- " + vo.getCrBy();
////                                approveDtS += approveDtS.equals("")?"- " + vo.getCrDtS():"<br/>- " + vo.getCrDtS();
////                            }else if(vo.getCloseJobFlg().equals("JOB")){
////                                actionBy  += actionBy.equals("")?"- " + vo.getCrBy():"<br/>- " + vo.getCrBy();
////                                actionDtS += actionDtS.equals("")?"- " + vo.getCrDtS():"<br/>- " + vo.getCrDtS();
////                            }
//                            
//                        }
//                    }
//                    reportCloseJobVo.setCloseJobType(closeJobType);
//                    reportCloseJobVo.setReasonDetail(reasonDetail);
//                    reportCloseJobVo.setRemark(remark);
//                    reportCloseJobVo.setApproveBy(approveBy);
//                    reportCloseJobVo.setApproveDtS(approveDtS);
//                    reportCloseJobVo.setActionBy(actionBy);
//                    reportCloseJobVo.setActionDtS(actionDtS);
//                }
//            }
            
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }
        
        return paginate;
    }

    @Override
    public List<ActionCloseVo> getcloseJobDetailList(String warningHeadId, String warningType) throws Exception {
        return actionCloseService.getcloseJobDetailList(warningHeadId, warningType);
    }
    
    @Override
    public List<ActionCloseVo> getcloseJobDetailListByWarningHeadId(String warningHeadId, String warningType) throws Exception {
        return actionCloseService.getcloseJobDetailListByWarningHeadId(warningHeadId, warningType);
    }
    
}
