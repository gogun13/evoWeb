/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.QcaFinancialService;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ktb.ewsl.vo.FinancialRatioVo;
import com.ktb.ewsl.vo.FinancialVo;
/**
 *
 * @author Kat
 */
@Service
public class QcaFinancialBusinessImpl extends AbstractBusiness implements QcaFinancialBusiness{
     private static final Logger logger = Logger.getLogger(QcaFinancialBusinessImpl.class);
     
    @Autowired
    private QcaFinancialService qcaFinancialService;

    @Override
    public FinancialVo getFinancialVO(String appID, String cif)throws Exception {
        return qcaFinancialService.getFinancialVO(appID, cif);
    }

    @Override
    public List<FinancialRatioVo> getRatioList(String finTrnId) throws Exception {
        return qcaFinancialService.getRatioList(finTrnId);
    }
    
    public List<FinancialRatioVo> getRatioList(FinancialVo finVO, List<FinancialRatioVo> ratioDBList) {
        List<FinancialRatioVo> ratioList = null;
        if (ratioDBList != null && ratioDBList.size() > 0) {
            ratioList = new ArrayList<FinancialRatioVo>();
            FinancialRatioVo ratioVO = null;
            String orderNo = "";
            for (int i = 0; i < ratioDBList.size(); i++) {
                FinancialRatioVo dbVO = ratioDBList.get(i);
                if (!orderNo.equals(dbVO.getOrderNo())) {
                    orderNo = dbVO.getOrderNo();
                    ratioVO = new FinancialRatioVo();
                    ratioVO.setOrderNo(dbVO.getOrderNo());
                    ratioVO.setAccountCode(dbVO.getAccountCode());
                    ratioVO.setDescriptionTh(dbVO.getDescriptionTh());
                    ratioVO.setGroupCode(dbVO.getGroupCode());
                    ratioVO.setUnit(dbVO.getUnit());
                    if (finVO.getModelIdFnAudit() != null && finVO.getModelIdFnAudit().equals(dbVO.getModelId())) {
                        if (finVO.getFinStatementAuditDate1() != null && finVO.getFinStatementAuditDate1().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAudit1(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAuditDate2() != null && finVO.getFinStatementAuditDate2().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAudit2(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAuditDate3() != null && finVO.getFinStatementAuditDate3().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAudit3(dbVO.getFinRatioValue());
                        }
                    } else if (finVO.getModelIdFnAdjust() != null && finVO.getModelIdFnAdjust().equals(dbVO.getModelId())) {
                        if (finVO.getFinStatementAdjustDate1() != null && finVO.getFinStatementAdjustDate1().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAdjust1(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAdjustDate2() != null && finVO.getFinStatementAdjustDate2().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAdjust2(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAdjustDate3() != null && finVO.getFinStatementAdjustDate3().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAdjust3(dbVO.getFinRatioValue());
                        }
                    }
                    ratioList.add(ratioVO);
                } else {
                    if (finVO.getModelIdFnAudit() != null && finVO.getModelIdFnAudit().equals(dbVO.getModelId())) {
                        if (finVO.getFinStatementAuditDate1() != null && finVO.getFinStatementAuditDate1().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAudit1(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAuditDate2() != null && finVO.getFinStatementAuditDate2().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAudit2(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAuditDate3() != null && finVO.getFinStatementAuditDate3().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAudit3(dbVO.getFinRatioValue());
                        }
                    } else if (finVO.getModelIdFnAdjust() != null && finVO.getModelIdFnAdjust().equals(dbVO.getModelId())) {
                        if (finVO.getFinStatementAdjustDate1() != null && finVO.getFinStatementAdjustDate1().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAdjust1(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAdjustDate2() != null && finVO.getFinStatementAdjustDate2().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAdjust2(dbVO.getFinRatioValue());
                        } else if (finVO.getFinStatementAdjustDate3() != null && finVO.getFinStatementAdjustDate3().equals(dbVO.getFinStatementDate())) {
                            ratioVO.setRatioAdjust3(dbVO.getFinRatioValue());
                        }
                    }
                }
            }
        }

        return ratioList;
    }
    
     @Override
    public boolean saveFinancial(FinancialVo finVO, UserData userObj) {
        boolean result = false;
        boolean samedb = false;
        boolean canUpdate = false;
        FinancialVo existFinVO;
        try {
            if (finVO.getCif() != null) {
              //  samedb = qcaFinancialService.checkDBFinancial(finVO);
                canUpdate = true;
                // pumin add find finId for update cond.
                if(finVO.getFinId() ==null || "".equals(finVO.getFinId())){
                    existFinVO = qcaFinancialService.getFinancialVO(null, finVO.getCif());
                    if(existFinVO !=null && existFinVO.getFinId()!=null && !"".equals(existFinVO.getFinId())){
                        finVO.setFinId(existFinVO.getFinId());
                     }
                }
            }
          //  if (samedb) { // pumin comment this : alway  add new rec
          //      qcaFinancialService.updateFinancial(finVO, userObj, "1");
          //  } else {
                qcaFinancialService.updateFinancialFlagByCIF(finVO, userObj, "0");
                qcaFinancialService.insertFinancial(finVO, userObj, "1");
          //  }
            result = true;
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        } 
        return result;
        
    }

    @Override
    public FinancialVo checkHVFin(String cifId) {
        return qcaFinancialService.checkHVFin(cifId);
    }

     
    public FinancialVo getCurrentQcaFin(String cifId)throws Exception{
       return qcaFinancialService.findCurrentQcaFin(cifId);
   }

    @Override
    public FinancialVo getLastFinancialVO(String cif) throws Exception {
            return qcaFinancialService.getLastFinancialVO(cif);
    }

    @Override
    public FinancialVo getFinancialVOByWarningId(String waringId) throws Exception {
        return qcaFinancialService.getFinancialVOByWarningId(waringId);
    }
    @Override
    public FinancialVo getFinancialForCalDate(String cif, String warningId) throws Exception {
         return qcaFinancialService.getFinancialForCalDate(cif, warningId);
    }

    @Override
    public void updateQcaFinInDelayReason(FinancialVo finVO) throws Exception {
         qcaFinancialService.updateQcaFinInDelayReason(finVO);
    }
}
