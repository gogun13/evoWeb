/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.IndividualODAccountService;
import com.ktb.ewsl.vo.IndividualODAccountVo;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class IndividualODAccountBusinessImpl implements IndividualODAccountBusiness{
    
     private static final Logger log = Logger.getLogger(IndividualODAccountBusinessImpl.class);
     
    @Autowired
    private IndividualODAccountService individualODAccountService;

    @Override
    public List<IndividualODAccountVo> getWarningBeforeODOverLimit(String cif) throws Exception {
       return individualODAccountService.getWarningBeforeODOverLimit(cif);
    }

    @Override
    public List<IndividualODAccountVo> getWarningODOverLimit(String cif) throws Exception {
       return individualODAccountService.getWarningODOverLimit(cif);
    }

    @Override
    public List<IndividualODAccountVo> getWarningODOverLimit12Month(String cif) throws Exception {
         return individualODAccountService.getWarningODOverLimit12Month(cif);
    }
}
