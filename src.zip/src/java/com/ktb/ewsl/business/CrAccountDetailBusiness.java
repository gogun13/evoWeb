/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

/**
 *
 * @author Tum_Surapong
 */
public interface CrAccountDetailBusiness {
    public String getLoanGrpProd(String prodGroup, String prodType, String acctSubType, String marketCode) throws Exception;
}
