/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktbcs.core.vo.UserData;
import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import java.util.ArrayList;

/**
 *
 * @author Luksamee
 */
public interface MenuBusiness {
    
    ArrayList<MenuInfoVo> getMainMenu(UserData user) throws Exception;
    
    ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass) throws Exception;

    ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass, String menuGroup) throws Exception;

    MenuInfoVo getFirstChild(String menuId, String userClass) throws Exception;

    MenuInfoVo getFirstChild(String menuId, String userClass, String menuGroup) throws Exception;
}
