/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.vo.WarningTypeVo;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 *
 * @author Tum_Surapong
 */
@Service
public class CacheBusinessImpl implements CacheBusiness{
    private static final Logger log = Logger.getLogger(CacheBusinessImpl.class);
    
    @Autowired
    private WarningTypeService warningTypeService;
    
    @Cacheable(value = "warningType")
    @Override
    public WarningTypeVo findWarningTypeDetail(String warningType) throws Exception{
        if(log.isInfoEnabled()){
            log.info("findWarningTypeDetail");
        }
        List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningType();
        if(warningTypeVoList != null && warningTypeVoList.size() > 0){
            for(WarningTypeVo warningTypeVo : warningTypeVoList){
                if(warningType.equals(warningTypeVo.getWarningTypeCode())){
                    return warningTypeVo;
                }
            }
        }
        
        return null;
    }
    
    @CacheEvict(value = "warningType", allEntries = true)
    @Override
    public void resetWarningTypeDetail(){
        if(log.isInfoEnabled()){
            log.info("resetWarningTypeDetail");
        }
    }
}
