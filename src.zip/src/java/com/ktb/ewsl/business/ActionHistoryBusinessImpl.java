/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionHistoryService;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class ActionHistoryBusinessImpl implements ActionHistoryBusiness{
    
    private static final Logger log = Logger.getLogger(QuestionBusinessImpl.class);
    @Autowired
    private ActionHistoryService actionHistoryService;

    @Override
    public ActionHistoryVo findDataByWarningIdAndStatus(int warningId, String status) throws Exception {
         ActionHistoryVo  historyVo = null;
         List<ActionHistoryVo> historyVoList = actionHistoryService.findDataByWarningIdAndStatus(warningId, status);
         if((historyVoList != null)&&(!historyVoList.isEmpty())){
              historyVo = (ActionHistoryVo) historyVoList.get(0);
         }
         return historyVo;
    }

    @Override
    public List<QuestionHistoryVo> findQuestionHistory(QuestionHistoryVo vo) throws Exception {
        return actionHistoryService.findQuestionHistory(vo);
    }

    @Override
    public QuestionHistoryVo findQuestionVersion(String warningId) throws Exception {
        return actionHistoryService.findQuestionVersion(warningId);
    }

    @Override
    public void saveData(ActionHistoryVo vo) throws Exception {
        actionHistoryService.saveData(vo);
    }

    @Override
    public ActionHistoryVo findActionHistory(int warningId, String actionCode, String status) throws Exception {
        return actionHistoryService.findActionHistory(warningId, actionCode, status);
    }

    @Override
    public ActionHistoryVo findData(int warningId, String actionDetail) throws Exception {
        return actionHistoryService.findData(warningId, actionDetail);
    }

    @Override
    public void updateRemarkForDraftReject(ActionHistoryVo vo) throws Exception {
        actionHistoryService.updateRemarkForDraftReject(vo);
    }
}
