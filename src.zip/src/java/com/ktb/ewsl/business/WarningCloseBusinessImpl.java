/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningCloseService;
import com.ktb.ewsl.vo.WarningCloseVo;
import com.ktbcs.core.business.AbstractBusiness;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author pumin
 */
@Service
public class WarningCloseBusinessImpl extends AbstractBusiness implements WarningCloseBusiness{

    @Autowired
    private WarningCloseService warningCloseService;
    
    @Override
    public ArrayList<WarningCloseVo> getWarningClose(String WarningHeaderId) throws Exception {
        return warningCloseService.getWarningClose(WarningHeaderId);
    }

    @Override
    public void insertWarningClose(WarningCloseVo vo) throws Exception {
        warningCloseService.insertWarningClose(vo);
    }

    @Override
    public String getReasonFlg(String warningHeadId) throws Exception {
        return warningCloseService.getReasonFlg(warningHeadId);
    }

    @Override
    public String getStatusByMaxCreatedDt(String warningHeadId) throws Exception {
        return warningCloseService.getStatusByMaxCreatedDt(warningHeadId);
    }
    
}
