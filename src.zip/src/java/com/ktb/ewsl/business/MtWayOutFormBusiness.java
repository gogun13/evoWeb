/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.MtWayOutFormVo;
import java.util.ArrayList;

/**
 *
 * @author Pratya
 */
public interface MtWayOutFormBusiness {
    
    ArrayList<MtWayOutFormVo> getQuestionList() throws Exception;
   
}
