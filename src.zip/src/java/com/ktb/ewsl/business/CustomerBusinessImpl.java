/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.CustomerService;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.RoleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class CustomerBusinessImpl extends AbstractBusiness implements CustomerBusiness{
    
    private static Logger log = Logger.getLogger(CustomerBusinessImpl.class);
    
    @Autowired
    private CustomerService customerService;

    @Override
    public CustomerVo selectCustomerByCif(Integer cif) throws Exception {
     return  customerService.selectCustomerByCif(cif);
    }

    @Override
    public CustomerVo selectCustomerByCifWithCostCenterName(Integer cif) throws Exception {
     return customerService.selectCustomerByCifWithCostCenterName(cif);
    }
    
    
}
