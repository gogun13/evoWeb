/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.WarningTypeVo;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningTypeBusiness {
    
     public ArrayList<WarningTypeVo> getColumnByPrivilege(String roleId , String warningTypeGroup)throws Exception;
    
}
