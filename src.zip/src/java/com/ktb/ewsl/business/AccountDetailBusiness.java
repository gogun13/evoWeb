/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.CrWarningAcctVo;
import java.util.ArrayList;

/**
 *
 * @author Pratya
 */
public interface AccountDetailBusiness {
    
    public ArrayList<CrWarningAcctVo> getCrWarningAcctListByCif (String cif) throws Exception;
   
}
