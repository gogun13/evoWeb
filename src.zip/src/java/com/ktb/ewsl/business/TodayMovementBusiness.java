/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.CrWarningAcctVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.RptIndividualAccountVo;
import java.util.List;

/**
 *
 * @author Pratya
 */
public interface TodayMovementBusiness {
    
    public CustomerVo customerInfo(CustomerVo vo) throws Exception;
    public List<RptIndividualAccountVo> getRptIndividualAccountList(RptIndividualAccountVo vo) throws Exception;
    public List<CrWarningAcctVo> getCrWarningAcctList (String cif, String flag) throws Exception;
   
}
