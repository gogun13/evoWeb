/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.IndividualODAccountVo;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface IndividualODAccountBusiness {
    
    public List<IndividualODAccountVo> getWarningBeforeODOverLimit(String cif) throws Exception;
    
    public List<IndividualODAccountVo> getWarningODOverLimit(String cif) throws Exception;
    
    public List<IndividualODAccountVo> getWarningODOverLimit12Month(String cif) throws Exception;
}
