/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionHistoryService;
import com.ktb.ewsl.services.AsstAnswerService;
import com.ktb.ewsl.services.CustomerService;
import com.ktb.ewsl.services.HolidayService;
import com.ktb.ewsl.services.WarningHeaderService;
import com.ktb.ewsl.services.WarningInfoService;
import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.utilities.CalculateDueDateUtil;
import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.utilities.EWSDateUtil;
import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.HolidayVo;
import com.ktb.ewsl.vo.RoleVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.business.KTBEmpDirectoryBusiness;
import com.ktbcs.core.business.UserBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.TreeMap;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class WarningInfoBusinessImpl extends AbstractBusiness implements WarningInfoBusiness {

    private PropertyResourceBundle appSouce = (PropertyResourceBundle) PropertyResourceBundle.getBundle("applications", Locale.US);
    private static Logger log = Logger.getLogger(WarningInfoBusinessImpl.class);
    @Autowired
    private WarningInfoService warningInfoService;
    @Autowired
    AsstAnswerService asstAnswerService;
    @Autowired
    private ActionHistoryService actionHistoryService;
    @Autowired
    private WarningTypeService warningTypeService;
    @Autowired
    private HolidayService holidayService;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private WarningHeaderService warningHeaderService;
    @Autowired
    private KTBEmpDirectoryBusiness ktbEmpDirectoryBusiness;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private ActionHistoryBusiness actionHistoryBusiness;
    @Autowired
    private UserBusiness userBusiness;
    @Autowired
    private KtbFieldMapBusiness ktbFieldMapBusiness;

    @Override
    public void genTrigger(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user, String version, String warningType) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("genTrigger");
        }
        if (BusinessConst.WarningTypeCode.TRIG.equals(warningType)) {
            genTriggerOnly(currentWarningHeaderId, triggerWarningId, ewsqWarningId, user, version);
        } else if (BusinessConst.WarningTypeCode.TRIGANDPAY.equals(warningType)) {
            genTriggerAndPayment(currentWarningHeaderId, triggerWarningId, ewsqWarningId, user, version);
        }
    }

    @Override
    public void updateStatusByWarningIdAndType(int warningInfoId, String warningType, UserData user, String status, String actionCode, String infoStatus) throws Exception {
        try {
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningId(warningInfoId);
            warningInfoVo.setWarningType(warningType);
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setStatus(status);
            if ("Save".equals(actionCode)) {
                warningInfoVo.setHolderId(null);
               //--OLD CODE warningInfoVo.setHolderRole(asstQuestionBusiness.getHolderRole(status, ""));
                warningInfoVo.setHolderRole(user.getRoleId());
            } else {
                warningInfoVo.setHolderId(user.getEmpNo());
                warningInfoVo.setHolderRole(user.getRoleId());
            }
            warningInfoService.updateStatusByWarningIdAndType(warningInfoVo);

            //---- Find DPD -----//
            log.info("warningInfoId =" + warningInfoId );
            WarningHeaderVo voGetDPD = warningHeaderService.findWarningHeaderObjectOriginalFromWarningId(warningInfoId);

                 
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(warningInfoId);
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode(actionCode);
            actionHistoryVo.setActionDetail(warningType);
            actionHistoryVo.setStatus(infoStatus);
            actionHistoryVo.setDpd(voGetDPD != null ? voGetDPD.getDpd() : null);
            actionHistoryService.saveData(actionHistoryVo);

        } catch (Exception e) {
            log.error("Error occur in while process WarningInfoBusinessImpl.updateStatusByWarningIdAndType : " + e.getMessage(), e);
        }
    }

    @Override
    public WarningInfoVo findWarningInfoObj(int warningHeaderId, int warningInfoId, String warningType) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findWarningInfoObj");
            log.info("warningHeaderId >>> " + warningHeaderId);
            log.info("warningInfoId >>> " + warningInfoId);
            log.info("warningType >>> " + warningType);
        }
        WarningInfoVo vo = new WarningInfoVo();
        try {

            vo = warningInfoService.findWarningInfoObj(warningHeaderId, warningInfoId, warningType);

        } catch (Exception e) {
            log.error("Error occur in while process WarningInfoBusinessImpl.findWarningInfoObj : " + e.getMessage(), e);
        }
        return vo;
    }

    @Override
    public int findWarningIdForGenTrigger(int cif, int currentWarningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findWarningInfoForGenTrigger >> " + cif);
        }
        List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoSendEwsqComplet(currentWarningHeaderId, BusinessConst.WarningTypeCode.EWSQ, BusinessConst.Flag.Y);
        if (warningInfoVoList != null && warningInfoVoList.size() > 0) {
            return warningInfoVoList.get(0).getWarningId();
        } else {
            warningInfoVoList = warningInfoService.findEwsqCompletByCif(cif);
            if (warningInfoVoList != null && warningInfoVoList.size() > 0) {
                return warningInfoVoList.get(0).getWarningId();
            }
        }
        return 0;
    }

    @Override
    public String[] findChangeRiskLevel(int warningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findChangeRiskLevel");
        }
//        0 = quanti
//        1 = quali

        String[] returnValue = new String[2];
        returnValue[0] = BusinessConst.Flag.N;
        returnValue[1] = BusinessConst.Flag.N;
        List<WarningInfoVo> warningInfoVoList = warningInfoService.findFinOrQcaOrQualiComplete(warningHeaderId);
        if (!warningInfoVoList.isEmpty()) {
            for (WarningInfoVo warningInfoVo : warningInfoVoList) {
                if (BusinessConst.WarningTypeCode.FIN.equals(warningInfoVo.getWarningType())) {
                    returnValue[0] = BusinessConst.Flag.Y;
                }
                if (BusinessConst.WarningTypeCode.EWSQ.equals(warningInfoVo.getWarningType())) {
                    returnValue[1] = BusinessConst.Flag.Y;
                }
            }
        }
//        else {
//            int warningId = 0;
//            for (WarningInfoVo warningInfoVo : warningInfoVoList) {
//                if (BusinessConst.WarningTypeCode.FIN.equals(warningInfoVo.getWarningType())) {
//                    return true;
//                }
//                warningId = warningInfoVo.getWarningId();
//            }
//
//            List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAnswerByWarningIdInCurrentDate(warningId);
//            if (!asstAnswerVoList.isEmpty()) {
//                return true;
//            }
//        }

        return returnValue;

    }

    private void genTriggerAndPayment(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user, String version) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("genTriggerAndPayment");
        }

        List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.TRIGANDPAY);
        Map<String, WarningTypeVo> warningTypeVoMap = new HashMap<String, WarningTypeVo>();
        if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
            for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                warningTypeVoMap.put(warningTypeVo.getWarningTypeCode(), warningTypeVo);
            }
            /************ SLA ******************/
            Integer slaCal = 0;
            Date dueDate = null;
            Map<String,Object> dataMap = calSla(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIGANDPAY);
            if(!dataMap.isEmpty()){
                if(dataMap.containsKey(BusinessConst.FIELD_NAME.INT_SLA_CAL)){
                       slaCal = (Integer)dataMap.get(BusinessConst.FIELD_NAME.INT_SLA_CAL);
                }
                if(dataMap.containsKey(BusinessConst.FIELD_NAME.DATE_DUEDATE)){
                       dueDate = (Date)dataMap.get(BusinessConst.FIELD_NAME.DATE_DUEDATE);
                }
            }
            /**
             * ********** Cancel old sub trig&pay *****************
             */
//            warningInfoService.deleteSubTrigger(currentWarningHeaderId);
            WarningInfoVo warningInfoVoForCancel = new WarningInfoVo();
            warningInfoVoForCancel.setWarningHeaderId(currentWarningHeaderId);
            warningInfoVoForCancel.setUpdatedBy(user.getEmpNo());
            warningInfoVoForCancel.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVoForCancel.setStatus(BusinessConst.Flag.CANCEL);
            warningInfoVoForCancel.setTrigShowFlag(BusinessConst.Flag.N);
            warningInfoService.cancelTriggerAndPayment(warningInfoVoForCancel);

//            Last version from warningType
//            List<WarningTypeVo> warningTypeVoLists = warningTypeService.findWarningTypeByWarningType(BusinessConst.WarningTypeCode.EWSQ);
//            if (warningTypeVoLists != null) {
//                version = warningTypeVoLists.get(0).getQuestionVersion();
//            }

//            Last version from answer
            List<AsstAnswerVo> asstAnswerVoListForVersion = asstAnswerService.findAsstAnswerByWarningId(ewsqWarningId);
            if (asstAnswerVoListForVersion != null && asstAnswerVoListForVersion.size() > 0) {
                version = asstAnswerVoListForVersion.get(0).getVersion();
            }

            WarningInfoVo warningInfoVos = warningInfoService.findTriggerWarningDate(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIGANDPAY);
            List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForGenTrigger(ewsqWarningId, version);

            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(currentWarningHeaderId);
            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.PAY);
            warningInfoVo.setStatus(BusinessConst.Flag.N);
            warningInfoVo.setTrigShowFlag(BusinessConst.Flag.N);
            warningInfoVo.setCreatedBy(user.getEmpNo());
            warningInfoVo.setCreatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setWarningDate(warningInfoVos.getWarningDate());
            warningInfoVo.setSla(slaCal);
            warningInfoVo.setSlaDueDate(dueDate);
            warningInfoVo.setQualiWarningId(ewsqWarningId);
            warningInfoService.saveWarningInfo(warningInfoVo);

            if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
                int idx = 1;
                for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                    if (1 == asstAnswerVo.getChoiceId()) {
                        String triggerItem = MoneyUtil.convertNumberToStringByFormat(idx, MoneyUtil.patternTrigger);
                        String triggerCode = BusinessConst.WarningTypeCode.TRIG.concat(triggerItem);
                        if (warningTypeVoMap.containsKey(triggerCode)) {
                            WarningInfoVo warningInfoVoT = new WarningInfoVo();
                            warningInfoVoT.setWarningHeaderId(currentWarningHeaderId);
                            warningInfoVoT.setWarningType(triggerCode);
                            warningInfoVoT.setStatus(BusinessConst.Flag.N);
                            warningInfoVoT.setTrigShowFlag(BusinessConst.Flag.N);
                            warningInfoVoT.setCreatedBy(user.getEmpNo());
                            warningInfoVoT.setCreatedDate(DateUtil.getCurrentDateTime());
                            warningInfoVoT.setUpdatedBy(user.getEmpNo());
                            warningInfoVoT.setUpdatedDate(DateUtil.getCurrentDateTime());
                            warningInfoVoT.setWarningDate(warningInfoVos.getWarningDate());
                            warningInfoVoT.setSla(slaCal);
                            warningInfoVoT.setSlaDueDate(dueDate);
                            warningInfoVoT.setQualiWarningId(ewsqWarningId);
                            warningInfoService.saveWarningInfo(warningInfoVoT);
                        }
                    }
                    idx++;
                }
            }

            WarningInfoVo warningInfoVoU = new WarningInfoVo();
            warningInfoVoU.setWarningId(triggerWarningId);
            warningInfoVoU.setTrigGenFlag(BusinessConst.Flag.Y);
            warningInfoVoU.setTrigShowFlag(BusinessConst.Flag.Y);
            warningInfoVoU.setStatus(BusinessConst.Flag.N);
            warningInfoVoU.setUpdatedBy(user.getEmpNo());
            warningInfoVoU.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoService.updateShowAndGen(warningInfoVoU);
        }
    }

    private void genTriggerOnly(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user, String version) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("genTriggerOnly");
        }

        List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.TRIG);
        Map<String, WarningTypeVo> warningTypeVoMap = new HashMap<String, WarningTypeVo>();
        if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
            for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                warningTypeVoMap.put(warningTypeVo.getWarningTypeCode(), warningTypeVo);
            }
            /************ SLA ******************/
            Integer slaCal = 0;
            Date dueDate = null;
            Map<String,Object> dataMap = calSla(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIGANDPAY);
            if(!dataMap.isEmpty()){
                if(dataMap.containsKey(BusinessConst.FIELD_NAME.INT_SLA_CAL)){
                       slaCal = (Integer)dataMap.get(BusinessConst.FIELD_NAME.INT_SLA_CAL);
                }
                if(dataMap.containsKey(BusinessConst.FIELD_NAME.DATE_DUEDATE)){
                       dueDate = (Date)dataMap.get(BusinessConst.FIELD_NAME.DATE_DUEDATE);
                }
            }
            /**
             * ********** *****************
             */
            warningInfoService.deleteSubTrigger(currentWarningHeaderId);
            List<WarningTypeVo> warningTypeVoLists = warningTypeService.findWarningTypeByWarningType(BusinessConst.WarningTypeCode.EWSQ);
            if (warningTypeVoLists != null) {
                version = warningTypeVoLists.get(0).getQuestionVersion();
            }
            List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForGenTrigger(ewsqWarningId, version);
            if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
                int idx = 1;
                WarningInfoVo warningInfoVos = warningInfoService.findTriggerWarningDate(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIG);
                for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                    if (1 == asstAnswerVo.getChoiceId()) {
                        String triggerItem = MoneyUtil.convertNumberToStringByFormat(idx, MoneyUtil.patternTrigger);
                        String triggerCode = BusinessConst.WarningTypeCode.TRIG.concat(triggerItem);
                        if (warningTypeVoMap.containsKey(triggerCode)) {
                            WarningInfoVo warningInfoVo = new WarningInfoVo();
                            warningInfoVo.setWarningHeaderId(currentWarningHeaderId);
                            warningInfoVo.setWarningType(triggerCode);
                            warningInfoVo.setStatus(BusinessConst.Flag.N);
                            warningInfoVo.setTrigShowFlag(BusinessConst.Flag.Y);
                            warningInfoVo.setCreatedBy(user.getEmpNo());
                            warningInfoVo.setCreatedDate(DateUtil.getCurrentDateTime());
                            warningInfoVo.setUpdatedBy(user.getEmpNo());
                            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                            warningInfoVo.setWarningDate(warningInfoVos.getWarningDate());
                            warningInfoVo.setSla(slaCal);
                            warningInfoVo.setSlaDueDate(dueDate);
                            warningInfoVo.setQualiWarningId(ewsqWarningId);
                            warningInfoService.saveWarningInfo(warningInfoVo);
                        }
                    }
                    idx++;
                }
                WarningInfoVo warningInfoVo = new WarningInfoVo();
                warningInfoVo.setWarningId(triggerWarningId);
                warningInfoVo.setTrigGenFlag(BusinessConst.Flag.Y);
                warningInfoVo.setTrigShowFlag(BusinessConst.Flag.N);
                warningInfoVo.setStatus(BusinessConst.Flag.N);
                warningInfoVo.setUpdatedBy(user.getEmpNo());
                warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                warningInfoService.updateShowAndGen(warningInfoVo);
            }
        }
    }

    private TreeMap<String, String> getRoleAndPersionResponsible(UserData user, int warningInfoId,
            String warningTypeCode, String warningInfoStatus,
            String holderID, String holderRole,
            String cifNo, int warningHeaderId) throws Exception {
        TreeMap<String, String> responsibleList = new TreeMap<String, String>();
        try {
            log.info(" getRoleAndPersionResponsible  ");
            log.info(" warningTypeCode   = " + warningTypeCode);
            log.info("  warningInfoStatus  = " + warningInfoStatus);
            log.info("  holderID  = " + holderID);
            log.info("  holderRole  = " + holderRole);
            log.info("  cifNo  = " + cifNo);
            log.info("  warningHeaderId = " + warningHeaderId);
            log.info("  warningInfoId = " + warningInfoId);
            if (BusinessConst.WarningTypeCode.CREDIT_REVIEW.equals(warningTypeCode)) {
                if (warningHeaderId > 0) {
                    String holderId = "";
                    if (BusinessConst.Flag.N.equals(warningInfoStatus)) {
                       // holderId = crTaskHolderServices.getHolderIdNotCreateApp(String.valueOf(warningHeaderId));
                    } else if (BusinessConst.Flag.INPROCESS.equals(warningInfoStatus)) {
                       // holderId = crTaskHolderServices.getHolderIdNotCreateApp(String.valueOf(warningHeaderId));
                    }
                    //****** Get full namme form Emp ID ****** //
                    String userCrName = getName(holderId);
                    if (!ValidatorUtil.isNullOrEmpty(userCrName)) {
                        responsibleList.put(BusinessConst.UserRole.CREDIT_CONTROLER, userCrName);
                    }
                }
            } else if (BusinessConst.WarningTypeCode.TURNAROUND.equals(warningTypeCode)) {
                if (warningHeaderId > 0) {
                    if (BusinessConst.Flag.N.equals(warningInfoStatus)) {
                        String holderId =null;//taTaskHolderServices.getHolderIdNotCreateApp(String.valueOf(warningHeaderId));
                        String userTaName = getName(holderId);
                        if (!ValidatorUtil.isNullOrEmpty(userTaName)) {
                            responsibleList.put(BusinessConst.UserRole.TURNAROUND, userTaName);
                        }
                    } else if (BusinessConst.Flag.INPROCESS.equals(warningInfoStatus)) {
                        List<String> userNameStr =null; //taTaskHolderServices.getHolderIdCreatedApp(String.valueOf(warningHeaderId));
                        if (userNameStr != null & !userNameStr.isEmpty()) {
                            List<String> userFullName = new ArrayList<String>();
                            //****** Get full namme form Emp ID ****** //
                            for (String data : userNameStr) {
                                String name = getName(data);
                                if (!ValidatorUtil.isNullOrEmpty(name)) {
                                    userFullName.add(name);
                                }
                            }
                            //****** For Render on screen
                            String userTaName = getNameFromListString(userFullName);
                            if (!ValidatorUtil.isNullOrEmpty(userTaName)) {
                                responsibleList.put(BusinessConst.UserRole.TURNAROUND, userTaName);
                            }
                        }
                    }
                }
            } else if (!EWSConstantValue.STATUS_NO_FIND_HOLDER_ID_ROLE.contains(warningInfoStatus)) { //--NOT = C , O , CC
                if (!ValidatorUtil.isNullOrEmpty(holderID) && !ValidatorUtil.isNullOrEmpty(holderRole)) {
                    String userName = getName(holderID);
                    if (!ValidatorUtil.isNullOrEmpty(userName)) {
                        responsibleList.put(holderRole, userName);
                    }
                } else {
                    CustomerVo cust = customerService.selectCustomerByCif(Integer.parseInt(cifNo));
                    if (cust != null) {
                        String responseUnit = cust.getResponseUnit() == null ? "" : cust.getResponseUnit().trim();
                        //****** Have HolderRole ****** //
                        if (!ValidatorUtil.isNullOrEmpty(holderRole) && !ValidatorUtil.isNullOrEmpty(responseUnit)) {
                            List<UserData> userList = null;
                            if (BusinessConst.UserRole.AE.equals(holderRole)) {
                                String rankCodeAE = ktbFieldMapBusiness.getRankCodeByGroup(BusinessConst.KTB_FIELD_MAP_GROUP.GROUP_AE);
                                if (ValidatorUtil.isNullOrEmpty(rankCodeAE)) {
                                    rankCodeAE = appSouce.getString("RANK_CODE_AE").toString();
                                }
                                userList = ktbEmpDirectoryBusiness.findByRankCodeAndDeptCode(rankCodeAE, responseUnit);
                                responsibleList.put(BusinessConst.UserRole.AE, getNameFromList(userList));

                            } else if (BusinessConst.UserRole.RM.equals(holderRole)) {
                                String rmId = cust.getRmId() == null ? "" : cust.getRmId().trim();
                                String rmUser = getName(rmId);
                                if (!ValidatorUtil.isNullOrEmpty(rmUser)) {
                                    responsibleList.put(BusinessConst.UserRole.RM, rmUser);
                                }
                                //String rankCodeRM =  appSouce.getString("RANK_CODE_RM").toString();
                                //userList = ktbEmpDirectoryBusiness.findByRankCodeAndDeptCode(rankCodeRM, responseUnit);
                                //responsibleList.put(BusinessConst.UserRole.RM, getNameFromList(userList));

                            } else if (BusinessConst.UserRole.BCM.equals(holderRole)) {
                                String rankCodeBCM = ktbFieldMapBusiness.getRankCodeByGroup(BusinessConst.KTB_FIELD_MAP_GROUP.GROUP_BCM);
                                if (ValidatorUtil.isNullOrEmpty(rankCodeBCM)) {
                                    rankCodeBCM = appSouce.getString("RANK_CODE_BCM").toString();
                                }
                                userList = ktbEmpDirectoryBusiness.findByRankCodeAndDeptCode(rankCodeBCM, responseUnit);
                                responsibleList.put(BusinessConst.UserRole.BCM, getNameFromList(userList));

                            } else if (BusinessConst.UserRole.SCM.equals(holderRole)) {
                                String rankCodeSCM = ktbFieldMapBusiness.getRankCodeByGroup(BusinessConst.KTB_FIELD_MAP_GROUP.GROUP_SCM);
                                if (ValidatorUtil.isNullOrEmpty(rankCodeSCM)) {
                                    rankCodeSCM = appSouce.getString("RANK_CODE_SCM").toString();
                                }
                                userList = ktbEmpDirectoryBusiness.findByRankCode(rankCodeSCM);
                                responsibleList.put(BusinessConst.UserRole.SCM, getNameFromList(userList));
                            }
                        } else {
                            //******  Case First Import || Not Migrate Data : Holder_id = "" , Holder_role = ""
                            if (warningInfoStatus != null && !ValidatorUtil.isNullOrEmpty(cifNo)) {
                                if (BusinessConst.Flag.N.equals(warningInfoStatus)
                                        || BusinessConst.Flag.BRMP.equals(warningInfoStatus)
                                        || BusinessConst.Flag.PRMP.equals(warningInfoStatus)) {
                                    //******  First Import ****** RM 
                                    String rmId = cust.getRmId() == null ? "" : cust.getRmId().trim();
                                    String rmUser = getName(rmId);
                                    if (!ValidatorUtil.isNullOrEmpty(rmUser)) {
                                        responsibleList.put(BusinessConst.UserRole.RM, rmUser);
                                    }
                                    //******  AE : For FIN ****** //
                                    if (BusinessConst.WarningTypeCode.FIN.equals(warningTypeCode)) {
                                        String aeId = cust.getAeId() == null ? "" : cust.getAeId().trim();
                                        String aeUser = getName(aeId);
                                        if (!ValidatorUtil.isNullOrEmpty(aeUser)) {
                                            responsibleList.put(BusinessConst.UserRole.AE, aeUser);
                                        }
                                    }//END cifNo != null
                                } else if (EWSConstantValue.STATUS_FIND_NEXT_HOLDER_ID.contains(warningInfoStatus)) {
                                    List<UserData> userList = null;
                                    if (BusinessConst.Flag.RMF.equals(warningInfoStatus)) {
                                        String rankCodeBCM = ktbFieldMapBusiness.getRankCodeByGroup(BusinessConst.KTB_FIELD_MAP_GROUP.GROUP_BCM);
                                        if (ValidatorUtil.isNullOrEmpty(rankCodeBCM)) {
                                            rankCodeBCM = appSouce.getString("RANK_CODE_BCM").toString();
                                        }
                                        userList = ktbEmpDirectoryBusiness.findByRankCodeAndDeptCode(rankCodeBCM, responseUnit);
                                        responsibleList.put(BusinessConst.UserRole.BCM, getNameFromList(userList));

                                    } else if (BusinessConst.Flag.BCA.equals(warningInfoStatus)) {
                                        String rankCodeSCM = ktbFieldMapBusiness.getRankCodeByGroup(BusinessConst.KTB_FIELD_MAP_GROUP.GROUP_SCM);
                                        if (ValidatorUtil.isNullOrEmpty(rankCodeSCM)) {
                                            rankCodeSCM = appSouce.getString("RANK_CODE_SCM").toString();
                                        }
                                        userList = ktbEmpDirectoryBusiness.findByRankCode(rankCodeSCM);
                                        responsibleList.put(BusinessConst.UserRole.SCM, getNameFromList(userList));
                                    }
                                } else if (EWSConstantValue.STATUS_FIND_HOLDER_ID_AE_RM_BCM_SCM.contains(warningInfoStatus)) {
                                    ActionHistoryVo actionHistoryVo = actionHistoryBusiness.findDataByWarningIdAndStatus(warningInfoId, warningInfoStatus);
                                    if ((actionHistoryVo != null) && (!ValidatorUtil.isNullOrEmpty(actionHistoryVo.getActionBy()))) {
                                        String userId = actionHistoryVo.getActionBy();
                                        log.info("  getActionBy = " + userId);
                                        /**
                                         * **** Telephone book *****
                                         */
                                        UserData userFind = ktbEmpDirectoryBusiness.findById(userId);
                                        if (userFind != null) {
                                            /**
                                             * **** Role in System *****
                                             */
                                            RoleVo roleVO = null;//userBusiness.findUserRole(userFind);
                                            if ((roleVO != null) && (!ValidatorUtil.isNullOrEmpty(roleVO.getRoleId()))) {
                                                String empNo = userFind.getEmpNo() == null ? "" : userFind.getEmpNo().trim();
                                                String title = userFind.getTitleNameThai() == null ? "" : userFind.getTitleNameThai().trim();
                                                String fName = userFind.getEmpNameThai() == null ? "" : userFind.getEmpNameThai().trim();
                                                String lName = userFind.getEmpSurnameThai() == null ? "" : userFind.getEmpSurnameThai().trim();
                                                String name = empNo.concat(" ").concat(title).concat(fName).concat(" ").concat(lName);
                                                responsibleList.put(roleVO.getRoleId(), name);
                                            }
                                        }
                                    }
                                }
                                //--NOTE : -Case -- C , O , CC display "" 
                            } else {
                                //--- RM 
                                String rmId = cust.getRmId() == null ? "" : cust.getRmId().trim();
                                String rmName = getName(rmId);
                                if (!ValidatorUtil.isNullOrEmpty(rmName)) {
                                    responsibleList.put(BusinessConst.UserRole.RM, rmName);
                                }
                            }//END ELSE
                        }//END cust != null
                    }
                }
            }
            log.info(" responsibleList.size() == " + responsibleList != null ? responsibleList.size() : "");
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return responsibleList;
    }

    private String getName(String userId) throws Exception {
        String data = "";
        try {
            if (!ValidatorUtil.isNullOrEmpty(userId)) {
                UserData userFindVo = ktbEmpDirectoryBusiness.findById(userId);
                if (userFindVo != null) {
                    String empNo = userFindVo.getEmpNo() == null ? "" : userFindVo.getEmpNo().trim();
                    String fulName = userFindVo.getFullName() == null ? "" : userFindVo.getFullName().trim();
                    data = empNo.concat(" ").concat(fulName);
                }
            }
        } catch (Exception e) {
            throw e;
        }
        return data;
    }

    private String getNameFromList(List<UserData> userList) throws Exception {
        String data = "";
        try {
            if (userList != null && !userList.isEmpty()) {
                for (int i = 0; i < userList.size(); i++) {
                    UserData obj = (UserData) userList.get(i);
                    String empNo = obj.getEmpNo() == null ? "" : obj.getEmpNo().trim();
                    String name = obj.getFullName() == null ? "" : obj.getFullName().trim();
                    data = data + empNo.concat(" ").concat(name);
                    if (i < userList.size() - 1) {
                        data = data.concat(" \n");
                    }
                }
            }

            System.out.println("getNameFromList " + data);
        } catch (Exception e) {
            throw e;
        }
        return data;
    }

    private String getNameFromListString(List<String> userList) throws Exception {
        String data = "";
        try {
            if (userList != null && !userList.isEmpty()) {
                for (int i = 0; i < userList.size(); i++) {
                    String objName = (String) userList.get(i);
                    data = data + objName;
                    if (i < userList.size() - 1) {
                        data = data.concat("<br/>");
                    }
                }
            }
        } catch (Exception e) {
            throw e;
        }
        return data;
    }

    @Override
    public void genForCombineForm(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user, String version, String warningType) throws Exception {
        
           //***************-Have Payment ? ***************//
           WarningInfoVo infoPayOld =  warningInfoService.findWarningInfoObject(currentWarningHeaderId, BusinessConst.WarningTypeCode.PAY);
           if(infoPayOld == null){ //--- Not Have Pay
                    /************ SLA ******************/
                    int slaCal = 0;
                    Date dueDate = null;
                    WarningInfoVo infoTrigAndPayOld = warningInfoService.findWarningInfoObject(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIGANDPAY);
                    if (infoTrigAndPayOld == null) {
                        log.info(" SLA New Cal For genForCombineForm");
                        Integer sla = warningTypeService.findSLAByWarningType(BusinessConst.WarningTypeCode.TRIGANDPAY);
                        ArrayList<HolidayVo> holidayVoList = (ArrayList<HolidayVo>) holidayService.getHoliday();
                        Date currentDate = EWSDateUtil.getDateNow();
                        if ((!holidayVoList.isEmpty()) && (currentDate != null)) {
                            dueDate = CalculateDueDateUtil.getDueDate(currentDate, DateUtil.getCurrentDateTime(), sla.intValue(), holidayVoList);
                            slaCal = CalculateDueDateUtil.getDueDay(currentDate, dueDate, holidayVoList);
                        }
                    } else {
                        log.info(" SLA Old For genForCombineForm");
                        slaCal = infoTrigAndPayOld.getSla();
                        dueDate = infoTrigAndPayOld.getSlaDueDate();
                    }

                    //*************** GEN PAY ***************//
                    WarningInfoVo warningInfoVo = new WarningInfoVo();
                    warningInfoVo.setWarningHeaderId(currentWarningHeaderId);
                    warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.PAY);
                    warningInfoVo.setStatus(BusinessConst.Flag.N);
                    warningInfoVo.setTrigShowFlag(BusinessConst.Flag.N);
                    warningInfoVo.setCreatedBy(user.getEmpNo());
                    warningInfoVo.setCreatedDate(DateUtil.getCurrentDateTime());
                    warningInfoVo.setUpdatedBy(user.getEmpNo());
                    warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                    if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                      warningInfoVo.setWarningDate(infoTrigAndPayOld.getWarningDate());
                    }
                    warningInfoVo.setSla(slaCal);
                    warningInfoVo.setSlaDueDate(dueDate);
                    warningInfoService.saveWarningInfo(warningInfoVo);
                    
                  //----IS EWSQ in Current Header ? Yes, it is.  Insert(gen) Trigger follow ewsq answer No,it isn't. Waiting for confirm ewsq anser on screen  ------------//
                    log.info(" currentWarningHeaderId = " + currentWarningHeaderId );
                    log.info(" ewsqWarningId = " + ewsqWarningId );
                    log.info(" type = " + BusinessConst.WarningTypeCode.EWSQ );
                   WarningInfoVo infoEWSCurrent =  warningInfoService.findWarningInfoObj(currentWarningHeaderId, ewsqWarningId, BusinessConst.WarningTypeCode.EWSQ);
                   if(infoEWSCurrent != null){
                       //*************** FIND : WARNING_TYPE Under TRIGANDPAY ***************//
                        List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.TRIGANDPAY);
                        Map<String, WarningTypeVo> warningTypeVoMap = new HashMap<String, WarningTypeVo>();
                        if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
                            for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                                warningTypeVoMap.put(warningTypeVo.getWarningTypeCode(), warningTypeVo);
                            }
                        }
                       //***************FIND : Answer of EWQS for gen trigger ***************//
                        String answerCurrentVersion  = asstAnswerService.getLastVersionAnswerOfWarningId(ewsqWarningId);
                        log.info(" answerCurrentVersion = " + answerCurrentVersion );
                        String currentEwsVersion = "";
                        //*************** Is EWSQ same version ? ***************//
                        List<WarningTypeVo>  warningTypeList = warningTypeService.findWarningTypeByWarningType(BusinessConst.WarningTypeCode.EWSQ);
                        if(!warningTypeList.isEmpty()){
                           WarningTypeVo wtVo = warningTypeList.get(0);
                           currentEwsVersion = wtVo != null ? wtVo.getQuestionVersion() : "";
                        }
                        if((!ValidatorUtil.isNullOrEmpty(answerCurrentVersion))&&(!ValidatorUtil.isNullOrEmpty(currentEwsVersion))&&
                               (answerCurrentVersion.equals(currentEwsVersion))){
                       //*************** Last Version that ewsqWarningId answer ***************//
                       List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForGenTrigger(ewsqWarningId, answerCurrentVersion);
                        if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
                            int idx = 1;
                            for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                                if (1 == asstAnswerVo.getChoiceId()) {
                                    String triggerItem = MoneyUtil.convertNumberToStringByFormat(idx, MoneyUtil.patternTrigger);
                                    String triggerCode = BusinessConst.WarningTypeCode.TRIG.concat(triggerItem);
                                    if (warningTypeVoMap.containsKey(triggerCode)) {
                                        WarningInfoVo warningInfoVoT = new WarningInfoVo();
                                        warningInfoVoT.setWarningHeaderId(currentWarningHeaderId);
                                        warningInfoVoT.setWarningType(triggerCode);
                                        warningInfoVoT.setStatus(BusinessConst.Flag.N);
                                        warningInfoVoT.setTrigShowFlag(BusinessConst.Flag.N);
                                        warningInfoVoT.setCreatedBy(user.getEmpNo());
                                        warningInfoVoT.setCreatedDate(DateUtil.getCurrentDateTime());
                                        warningInfoVoT.setUpdatedBy(user.getEmpNo());
                                        warningInfoVoT.setUpdatedDate(DateUtil.getCurrentDateTime());
                                        if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                                            warningInfoVoT.setWarningDate(infoTrigAndPayOld.getWarningDate());
                                         }
                                        warningInfoVoT.setSla(slaCal);
                                        warningInfoVoT.setSlaDueDate(dueDate);

                                        warningInfoService.saveWarningInfo(warningInfoVoT);
                                    }
                                }
                                idx++;
                            }
                            //*************** UPDATE TRIG&PAY ***************//
                                WarningInfoVo warningInfoVoU = new WarningInfoVo();
                                warningInfoVoU.setWarningId(triggerWarningId);
                                warningInfoVoU.setTrigGenFlag(BusinessConst.Flag.Y);
                                warningInfoVoU.setTrigShowFlag(BusinessConst.Flag.Y);
                                warningInfoVoU.setStatus(BusinessConst.Flag.N);
                                warningInfoVoU.setUpdatedBy(user.getEmpNo());
                                warningInfoVoU.setUpdatedDate(DateUtil.getCurrentDateTime());
                                warningInfoService.updateShowAndGen(warningInfoVoU);
                       }//END HAVE ANSWER
                    }//END Check CurrentEWSVersion = AnswerVersion 
                  }else{
                         log.info("NOT HAVE CURRENT EWSQ ewsqWarningId = " + ewsqWarningId);
                         WarningInfoVo oldEWSQInfo = null;
                          //------------ OLD EWSQ : DIFF CURRENT HEADER ------------//
                         if(ewsqWarningId > 0){
                               oldEWSQInfo = warningInfoService.findWarningInfoObjByWarningInfoId(ewsqWarningId, BusinessConst.WarningTypeCode.EWSQ);
                         }
                         if(oldEWSQInfo == null){
                              log.info("oldEWSQInfo is null = ");
                         //------------- NOTE HAVE OLD : GEN TEMP AUTO UNDER TEMP----------------------------//
                             //----------------------- INSERT EWSQ_TEMP -- 1record ---------------------------//
                            WarningInfoVo warningInfoEWSQVo = new WarningInfoVo();
                            warningInfoEWSQVo.setWarningHeaderId(currentWarningHeaderId);
                           // warningInfoEWSQVo.setWarningType(BusinessConst.WarningTypeCode.EWSQ_TMP);
                            warningInfoEWSQVo.setStatus(BusinessConst.Flag.N);
                            warningInfoEWSQVo.setTrigShowFlag(BusinessConst.Flag.N);
                            warningInfoEWSQVo.setCreatedBy("SYSTEM_GEN");
                            warningInfoEWSQVo.setCreatedDate(DateUtil.getCurrentDateTime());
                            warningInfoEWSQVo.setUpdatedBy("SYSTEM_GEN");
                            warningInfoEWSQVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                            if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                              warningInfoEWSQVo.setWarningDate(infoTrigAndPayOld.getWarningDate());
                            }
                            warningInfoEWSQVo.setSla(slaCal);
                            warningInfoEWSQVo.setSlaDueDate(dueDate);
                            warningInfoService.saveWarningInfo(warningInfoEWSQVo);
                          //----------------------- INSERT TRIGGER_TEMP -- 19 record ---------------------------//
                          List<WarningTypeVo> warningTypeTempVoList = null;//warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ_TMP);
                          log.info(" warningTypeTempVoList.size() = " +  warningTypeTempVoList != null ? warningTypeTempVoList.size() : 0 );
                          if(warningTypeTempVoList != null && !warningTypeTempVoList.isEmpty()){
                              for(WarningTypeVo warningTypeTempVo : warningTypeTempVoList){
                                  if(warningTypeTempVo != null && !ValidatorUtil.isNullOrEmpty(warningTypeTempVo.getWarningTypeCode())){
                                   WarningInfoVo warningInfoVoT = new WarningInfoVo();
                                        warningInfoVoT.setWarningHeaderId(currentWarningHeaderId);
                                        warningInfoVoT.setWarningType(warningTypeTempVo.getWarningTypeCode());
                                        warningInfoVoT.setStatus(BusinessConst.Flag.N);
                                        warningInfoVoT.setTrigShowFlag(BusinessConst.Flag.N);
                                        warningInfoVoT.setCreatedBy(user.getEmpNo());
                                        warningInfoVoT.setCreatedDate(DateUtil.getCurrentDateTime());
                                        warningInfoVoT.setUpdatedBy(user.getEmpNo());
                                        warningInfoVoT.setUpdatedDate(DateUtil.getCurrentDateTime());
                                        if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                                            warningInfoVoT.setWarningDate(infoTrigAndPayOld.getWarningDate());
                                         }
                                        warningInfoVoT.setSla(slaCal);
                                        warningInfoVoT.setSlaDueDate(dueDate);

                                        warningInfoService.saveWarningInfo(warningInfoVoT);
                                  }
                              }//END FOR
                             //-------------- UPDATE TRIG&PAY --------------//
                                WarningInfoVo warningInfoVoU = new WarningInfoVo();
                                warningInfoVoU.setWarningId(triggerWarningId);
                                warningInfoVoU.setTrigGenFlag(BusinessConst.Flag.Y);
                                warningInfoVoU.setTrigShowFlag(BusinessConst.Flag.Y);
                                warningInfoVoU.setStatus(BusinessConst.Flag.N);
                                warningInfoVoU.setUpdatedBy(user.getEmpNo());
                                warningInfoVoU.setUpdatedDate(DateUtil.getCurrentDateTime());
                                warningInfoService.updateShowAndGen(warningInfoVoU);
                                
                          }//END GEN TEMP
                         }
   
                   }//END ELSE
                    /* Note Remark :
                     * if it have old ewsq (Difference HeaderId)
                     * Should be confirm on screen (AND Display format 2)before insert EWSQ and trigger follow old answer.(AND Display format 1)
                     * If reject onscreen it should be insert ewsq_temp and trigger_temp(AND Display format 3)
                     */
           }//END infoPayOld == null        
    }

    @Override
    public List<WarningInfoVo> findFormConbineWithinHeader(int warningHeaderId) throws Exception {
      return warningInfoService.findFormConbineWithinHeader(warningHeaderId);
    }
    
    /*
     * Gen Payment & Trigger folloeEwsq ; And stamp "CC" to old record
     */
    @Override
    public void genTriggerFollowEwsq(int currentWarningHeaderId, int triggerWarningId, int ewsqWarningId, UserData user) throws Exception {
      try{
          if(ewsqWarningId > 0){
                /************ SLA ******************/
                    int slaCal = 0;
                    Date dueDate = null;
                    WarningInfoVo infoTrigAndPayOld = warningInfoService.findWarningInfoObject(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIGANDPAY);
                    if (infoTrigAndPayOld == null) {
                        log.info(" SLA New Cal For genForCombineForm");
                        Integer sla = warningTypeService.findSLAByWarningType(BusinessConst.WarningTypeCode.TRIGANDPAY);
                        ArrayList<HolidayVo> holidayVoList = (ArrayList<HolidayVo>) holidayService.getHoliday();
                        Date currentDate = EWSDateUtil.getDateNow();
                        if ((!holidayVoList.isEmpty()) && (currentDate != null)) {
                            dueDate = CalculateDueDateUtil.getDueDate(currentDate, DateUtil.getCurrentDateTime(), sla.intValue(), holidayVoList);
                            slaCal = CalculateDueDateUtil.getDueDay(currentDate, dueDate, holidayVoList);
                        }
                    } else {
                        log.info(" SLA Old For genForCombineForm");
                        slaCal = infoTrigAndPayOld.getSla();
                        dueDate = infoTrigAndPayOld.getSlaDueDate();
                    }
             /**END********** SLA ******************/
            //*************** FIND : WARNING_TYPE Under TRIGANDPAY ***************//
                List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.TRIGANDPAY);
                Map<String, WarningTypeVo> warningTypeVoMap = new HashMap<String, WarningTypeVo>();
                if (warningTypeVoList != null && warningTypeVoList.size() > 0) {
                    for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                        warningTypeVoMap.put(warningTypeVo.getWarningTypeCode(), warningTypeVo);
                    }
                }
                /********** Mask CC :03/06/2015*********/
                WarningInfoVo warningInfoVoForCancel = new WarningInfoVo();
                warningInfoVoForCancel.setWarningHeaderId(currentWarningHeaderId);
                warningInfoVoForCancel.setUpdatedBy(user.getEmpNo());
                warningInfoVoForCancel.setUpdatedDate(DateUtil.getCurrentDateTime());
                warningInfoVoForCancel.setStatus(BusinessConst.Flag.CANCEL);
                warningInfoVoForCancel.setTrigShowFlag(BusinessConst.Flag.N);
                warningInfoService.cancelTriggerAndPayment(warningInfoVoForCancel);
               //***************FIND : Answer of EWQS for gen trigger ***************//
                String answerCurrentVersion  = asstAnswerService.getLastVersionAnswerOfWarningId(ewsqWarningId);
                log.info(" answerCurrentVersion = " + answerCurrentVersion );
                String currentEwsVersion = "";
                //*************** Is EWSQ same version ? ***************//
                List<WarningTypeVo>  warningTypeList = warningTypeService.findWarningTypeByWarningType(BusinessConst.WarningTypeCode.EWSQ);
                if(!warningTypeList.isEmpty()){
                   WarningTypeVo wtVo = warningTypeList.get(0);
                   currentEwsVersion = wtVo != null ? wtVo.getQuestionVersion() : "";
                }
                if((!ValidatorUtil.isNullOrEmpty(answerCurrentVersion))&&(!ValidatorUtil.isNullOrEmpty(currentEwsVersion))&&
                       (answerCurrentVersion.equals(currentEwsVersion))){
                /********** Save Payment 03/06/2015*********/                    
                WarningInfoVo warningInfoVo = new WarningInfoVo();
                warningInfoVo.setWarningHeaderId(currentWarningHeaderId);
                warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.PAY);
                warningInfoVo.setStatus(BusinessConst.Flag.N);
                warningInfoVo.setTrigShowFlag(BusinessConst.Flag.N);
                warningInfoVo.setCreatedBy(user.getEmpNo());
                warningInfoVo.setCreatedDate(DateUtil.getCurrentDateTime());
                warningInfoVo.setUpdatedBy(user.getEmpNo());
                warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
                if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                     warningInfoVo.setWarningDate(infoTrigAndPayOld.getWarningDate());
                 }
                warningInfoVo.setSla(slaCal);
                warningInfoVo.setSlaDueDate(dueDate);
                warningInfoVo.setQualiWarningId(ewsqWarningId);
                warningInfoService.saveWarningInfo(warningInfoVo);
               //*************** Last Version that ewsqWarningId answer ***************//
               List<AsstAnswerVo> asstAnswerVoList = asstAnswerService.findAsstAnswerForGenTrigger(ewsqWarningId, answerCurrentVersion);
                if (asstAnswerVoList != null && asstAnswerVoList.size() > 0) {
                    int idx = 1;
                    for (AsstAnswerVo asstAnswerVo : asstAnswerVoList) {
                        if (1 == asstAnswerVo.getChoiceId()) {
                            String triggerItem = MoneyUtil.convertNumberToStringByFormat(idx, MoneyUtil.patternTrigger);
                            String triggerCode = BusinessConst.WarningTypeCode.TRIG.concat(triggerItem);
                            if (warningTypeVoMap.containsKey(triggerCode)) {
                                WarningInfoVo warningInfoVoT = new WarningInfoVo();
                                warningInfoVoT.setWarningHeaderId(currentWarningHeaderId);
                                warningInfoVoT.setWarningType(triggerCode);
                                warningInfoVoT.setStatus(BusinessConst.Flag.N);
                                warningInfoVoT.setTrigShowFlag(BusinessConst.Flag.N);
                                warningInfoVoT.setCreatedBy(user.getEmpNo());
                                warningInfoVoT.setCreatedDate(DateUtil.getCurrentDateTime());
                                warningInfoVoT.setUpdatedBy(user.getEmpNo());
                                warningInfoVoT.setUpdatedDate(DateUtil.getCurrentDateTime());
                                if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                                    warningInfoVoT.setWarningDate(infoTrigAndPayOld.getWarningDate());
                                 }
                                warningInfoVoT.setSla(slaCal);
                                warningInfoVoT.setSlaDueDate(dueDate);
                                warningInfoVoT.setQualiWarningId(ewsqWarningId);
                                warningInfoService.saveWarningInfo(warningInfoVoT);
                            }
                        }
                        idx++;
                    }
                    //*************** UPDATE TRIG&PAY ***************//
                    WarningInfoVo warningInfoVoU = new WarningInfoVo();
                    warningInfoVoU.setWarningId(triggerWarningId);
                    warningInfoVoU.setTrigGenFlag(BusinessConst.Flag.Y);
                    warningInfoVoU.setTrigShowFlag(BusinessConst.Flag.Y);
                    warningInfoVoU.setStatus(BusinessConst.Flag.N);
                    warningInfoVoU.setUpdatedBy(user.getEmpNo());
                    warningInfoVoU.setUpdatedDate(DateUtil.getCurrentDateTime());
                    warningInfoService.updateShowAndGen(warningInfoVoU);
               }//END HAVE ANSWER
          }
        }
      }catch(Exception e){
         log.error("Error occur in while process WarningInfoBusinessImpl.genTriggerFollowEwsq :" + e.getMessage(),e);
      }
    }

    @Override
    public void genEwsqAndTriggerTemp(int currentWarningHeaderId, int triggerWarningId, UserData user) throws Exception {
       try{
        /**START********** SLA ******************/
                    int slaCal = 0;
                    Date dueDate = null;
                    WarningInfoVo infoTrigAndPayOld = warningInfoService.findWarningInfoObject(currentWarningHeaderId, BusinessConst.WarningTypeCode.TRIGANDPAY);
                    if (infoTrigAndPayOld == null) {
                        log.info(" SLA New Cal For genForCombineForm");
                        Integer sla = warningTypeService.findSLAByWarningType(BusinessConst.WarningTypeCode.TRIGANDPAY);
                        ArrayList<HolidayVo> holidayVoList = (ArrayList<HolidayVo>) holidayService.getHoliday();
                        Date currentDate = EWSDateUtil.getDateNow();
                        if ((!holidayVoList.isEmpty()) && (currentDate != null)) {
                            dueDate = CalculateDueDateUtil.getDueDate(currentDate, DateUtil.getCurrentDateTime(), sla.intValue(), holidayVoList);
                            slaCal = CalculateDueDateUtil.getDueDay(currentDate, dueDate, holidayVoList);
                        }
                    } else {
                        log.info(" SLA Old For genForCombineForm");
                        slaCal = infoTrigAndPayOld.getSla();
                        dueDate = infoTrigAndPayOld.getSlaDueDate();
                    }
             /**END********** SLA ******************/
            //------------- NOTE HAVE OLD : GEN TEMP AUTO UNDER TEMP----------------------------//
            //----------------------- INSERT EWSQ_TEMP -- 1record ---------------------------//
               WarningInfoVo warningInfoEWSQVo = new WarningInfoVo();
               warningInfoEWSQVo.setWarningHeaderId(currentWarningHeaderId);
              // warningInfoEWSQVo.setWarningType(BusinessConst.WarningTypeCode.EWSQ_TMP);
               warningInfoEWSQVo.setStatus(BusinessConst.Flag.N);
               warningInfoEWSQVo.setTrigShowFlag(BusinessConst.Flag.N);
               warningInfoEWSQVo.setCreatedBy("SYSTEM_GEN");
               warningInfoEWSQVo.setCreatedDate(DateUtil.getCurrentDateTime());
               warningInfoEWSQVo.setUpdatedBy("SYSTEM_GEN");
               warningInfoEWSQVo.setUpdatedDate(DateUtil.getCurrentDateTime());
               if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                 warningInfoEWSQVo.setWarningDate(infoTrigAndPayOld.getWarningDate());
               }
               warningInfoEWSQVo.setSla(slaCal);
               warningInfoEWSQVo.setSlaDueDate(dueDate);
               warningInfoService.saveWarningInfo(warningInfoEWSQVo);
             //----------------------- INSERT TRIGGER_TEMP -- 19 record ---------------------------//
             List<WarningTypeVo> warningTypeTempVoList = null;//warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ_TMP);
             log.info(" warningTypeTempVoList.size() = " +  warningTypeTempVoList != null ? warningTypeTempVoList.size() : 0 );
             if(warningTypeTempVoList != null && !warningTypeTempVoList.isEmpty()){
                 for(WarningTypeVo warningTypeTempVo : warningTypeTempVoList){
                     if(warningTypeTempVo != null && !ValidatorUtil.isNullOrEmpty(warningTypeTempVo.getWarningTypeCode())){
                      WarningInfoVo warningInfoVoT = new WarningInfoVo();
                           warningInfoVoT.setWarningHeaderId(currentWarningHeaderId);
                           warningInfoVoT.setWarningType(warningTypeTempVo.getWarningTypeCode());
                           warningInfoVoT.setStatus(BusinessConst.Flag.N);
                           warningInfoVoT.setTrigShowFlag(BusinessConst.Flag.N);
                           warningInfoVoT.setCreatedBy(user.getEmpNo());
                           warningInfoVoT.setCreatedDate(DateUtil.getCurrentDateTime());
                           warningInfoVoT.setUpdatedBy(user.getEmpNo());
                           warningInfoVoT.setUpdatedDate(DateUtil.getCurrentDateTime());
                           if(infoTrigAndPayOld != null && infoTrigAndPayOld.getWarningDate() != null){
                               warningInfoVoT.setWarningDate(infoTrigAndPayOld.getWarningDate());
                            }
                           warningInfoVoT.setSla(slaCal);
                           warningInfoVoT.setSlaDueDate(dueDate);

                           warningInfoService.saveWarningInfo(warningInfoVoT);
                     }
                 }//END FOR
                //-------------- UPDATE TRIG&PAY --------------//
                   WarningInfoVo warningInfoVoU = new WarningInfoVo();
                   warningInfoVoU.setWarningId(triggerWarningId);
                   warningInfoVoU.setTrigGenFlag(BusinessConst.Flag.Y);
                   warningInfoVoU.setTrigShowFlag(BusinessConst.Flag.Y);
                   warningInfoVoU.setStatus(BusinessConst.Flag.N);
                   warningInfoVoU.setUpdatedBy(user.getEmpNo());
                   warningInfoVoU.setUpdatedDate(DateUtil.getCurrentDateTime());
                   warningInfoService.updateShowAndGen(warningInfoVoU);

             }//END GEN TEMP
      }catch(Exception e){
         log.error("Error occur in while process WarningInfoBusinessImpl.genEwsqAndTriggerTemp :" + e.getMessage(),e);
      }
    }

    @Override
    public void insertWarningInfo(WarningInfoVo infoVo , UserData user) throws Exception {
           /**START********** SLA ******************/
            int slaCal = 0;
            Date dueDate = null;
            Integer sla = warningTypeService.findSLAByWarningType(BusinessConst.WarningTypeCode.EWSQ);
            ArrayList<HolidayVo> holidayVoList = (ArrayList<HolidayVo>) holidayService.getHoliday();
            Date currentDate = EWSDateUtil.getDateNow();
            if ((!holidayVoList.isEmpty()) && (currentDate != null)) {
                dueDate = CalculateDueDateUtil.getDueDate(currentDate, DateUtil.getCurrentDateTime(), sla.intValue(), holidayVoList);
                slaCal = CalculateDueDateUtil.getDueDay(currentDate, dueDate, holidayVoList);
            }
             /**END********** SLA ******************/
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setWarningHeaderId(infoVo.getWarningHeaderId());
            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.EWSQ);
            warningInfoVo.setStatus(BusinessConst.Flag.N);
            warningInfoVo.setTrigShowFlag(BusinessConst.Flag.Y);
            warningInfoVo.setWarningDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setSla(slaCal);
            warningInfoVo.setSlaDueDate(dueDate);
            warningInfoVo.setCreatedBy(user.getEmpNo());
            warningInfoVo.setCreatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoService.saveWarningInfo(warningInfoVo);
            
            //----------- UPDATE :  TBL_WARNING_HEADER -------------------//
            WarningHeaderVo headerVo = new  WarningHeaderVo();
            headerVo.setCif(infoVo.getCifNo());
            headerVo.setWarningHeaderId(infoVo.getWarningHeaderId());
            headerVo.setUpdatedBy(user.getEmpNo());
            headerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            headerVo.setEwsFlag(BusinessConst.Flag.N);
       //     warningHeaderService.updateFlagInWarningHeader(headerVo);
            
            //----------- UPDATE :  TBL_CUST_REVIEW_EWS -------------------//
//            Integer haveCrOrTa = warningHeaderService.haveCrOrTaWithinHeader(infoVo.getWarningHeaderId());
//                if(haveCrOrTa != null && haveCrOrTa > 0){
//                 if((!ValidatorUtil.isNullOrEmpty(infoVo.getCifNo()))&&(infoVo.getWarningHeaderId() > 0)){
//                  crCustReviewEwsBusiness.updateFlagForChangeStatus(infoVo.getCifNo(), infoVo.getWarningHeaderId(), BusinessConst.WarningTypeCode.EWSQ, BusinessConst.Flag.N, user);
//               }
//            }
    }

    /* Step 1 : Warning Quali & Trigger are same warningDate :: Return 0
     * Step 2 : UpdateDate Quali < WarningDate Trigger (LessThan):: Return -1
     *          UpdateDate Quali > WarningDate Trigger (MoreThan):: Return 1
     */
    @Override
    public Integer compareEWSQandTrigPay(int currentWarningHeaderId) throws Exception {
        Integer result = null;
        try{
            List<WarningInfoVo> warningInfo = warningInfoService.findWarningInfoByHeaderId(currentWarningHeaderId);
            if(warningInfo != null && !warningInfo.isEmpty()){
                Date ewsqWarningDate = null;
                Date ewsqUpdateDate = null;
                Date trigAndPayWarningDate= null;
                for(WarningInfoVo data : warningInfo){
                       if(BusinessConst.WarningTypeCode.EWSQ.equals(data.getWarningType())){
                              ewsqWarningDate = data.getWarningDate();
                              ewsqUpdateDate =  data.getUpdatedDate();
                        }else if(BusinessConst.WarningTypeCode.TRIGANDPAY.equals(data.getWarningType())){
                                trigAndPayWarningDate = data.getWarningDate();
                        }        
                
                }
                log.info("ewsqWarningDate = " +  ewsqWarningDate );
                log.info("trigAndPayWarningDate = " +  trigAndPayWarningDate );
                log.info("ewsqUpdateDate = " +  ewsqUpdateDate );
                if(ewsqWarningDate != null && trigAndPayWarningDate != null){ 
                    boolean qualiSameDayWithTrigPay = DateUtil.isSameDay(ewsqWarningDate, trigAndPayWarningDate);
                    log.info("qualiSameDayWithTrigPay = " +  qualiSameDayWithTrigPay );
                    if(qualiSameDayWithTrigPay){ //------ WarningDate EWSQ = WarningDate TrigAndPay
                        result = 0;
                    }else{
                        if(ewsqUpdateDate != null){
                            boolean qualiLessDayWithTrigPay = DateUtil.isLessDate(ewsqUpdateDate, trigAndPayWarningDate);
                            log.info("qualiLessDayWithTrigPay = " +  qualiSameDayWithTrigPay );
                            if(qualiLessDayWithTrigPay){//------ UpdateDate EWSQ < WarningDate TrigAndPay
                                result = -1;
                            }else{  //------ UpdateDate EWSQ >= WarningDate TrigAndPay
                                result = 1;
                            }
                        }
                    }
                }
            }
             log.info("result = " +  result );
       }catch(Exception e){
         log.error("Error occur in while process WarningInfoBusinessImpl.compareWarningDateEWSQandQuali :" + e.getMessage(),e);
      }
        return result ;
    }
    @Override
    public Map<String,Object> calSla(int currentWarningHeaderId , String warningType)throws Exception{
    Map<String,Object>  dataMap = null;    
    try{
            int slaCal = 0;
            Date dueDate = null;
            WarningInfoVo infoOld = warningInfoService.findWarningInfoObject(currentWarningHeaderId, warningType);
            if (infoOld == null) {
                Integer sla = warningTypeService.findSLAByWarningType(warningType);
                ArrayList<HolidayVo> holidayVoList = (ArrayList<HolidayVo>) holidayService.getHoliday();
                Date currentDate = EWSDateUtil.getDateNow();
                if ((!holidayVoList.isEmpty()) && (currentDate != null)) {
                    dueDate = CalculateDueDateUtil.getDueDate(currentDate, DateUtil.getCurrentDateTime(), sla.intValue(), holidayVoList);
                    slaCal = CalculateDueDateUtil.getDueDay(currentDate, dueDate, holidayVoList);
                }
            } else {
                slaCal = infoOld.getSla();
                dueDate = infoOld.getSlaDueDate();
            }
            
            dataMap = new HashMap<String, Object>();
            dataMap.put(BusinessConst.FIELD_NAME.INT_SLA_CAL, slaCal );
            dataMap.put(BusinessConst.FIELD_NAME.DATE_DUEDATE, dueDate);       
            }catch(Exception e){
                log.error("Error occur in while process WarningInfoBusinessImpl.calSla :" + e.getMessage(),e);
            }
    return dataMap;
    }

    @Override
    public void resetInfoEWSQ(String cifNo ,int warningHeaderId ,  int ewsqWarningInfoId, String warningType, UserData user) throws Exception {
        try{
            WarningInfoVo warningInfoVo = new WarningInfoVo();
            warningInfoVo.setStatus(BusinessConst.Flag.N);
            warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setUpdatedBy(user.getEmpNo());
            warningInfoVo.setQualiSendFlag("");
            warningInfoVo.setHolderId("");
            warningInfoVo.setHolderRole("");
            warningInfoVo.setCloseFlag(BusinessConst.Flag.N);
            warningInfoVo.setWarningId(ewsqWarningInfoId);
            warningInfoVo.setWarningType(warningType);
            warningInfoService.resetEwsqInfo(warningInfoVo);
            
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(ewsqWarningInfoId);
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode(BusinessConst.ACTION_CODE.RESET);
            actionHistoryVo.setActionDetail(warningType);
            actionHistoryVo.setStatus(BusinessConst.Flag.N);
            actionHistoryService.saveData(actionHistoryVo);
            
            //----------- UPDATE :  TBL_WARNING_HEADER -------------------//
            WarningHeaderVo headerVo = new  WarningHeaderVo();
            headerVo.setCif(cifNo);
            headerVo.setWarningHeaderId(warningHeaderId);
            headerVo.setUpdatedBy(user.getEmpNo());
            headerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            headerVo.setEwsFlag(BusinessConst.Flag.N);
       //     warningHeaderService.updateFlagInWarningHeader(headerVo);
            
             //----------- UPDATE :  TBL_CUST_REVIEW_EWS -------------------//
//             Integer haveCrOrTa = warningHeaderService.haveCrOrTaWithinHeader(warningHeaderId);
//             if(haveCrOrTa != null && haveCrOrTa > 0){
//                if((!ValidatorUtil.isNullOrEmpty(cifNo))&&(warningHeaderId > 0)){
//                    crCustReviewEwsBusiness.updateFlagForChangeStatus(cifNo, warningHeaderId, BusinessConst.WarningTypeCode.EWSQ, BusinessConst.Flag.N, user);
//                 }
//             }
        }catch(Exception e){
            log.error("Error occur in while process WarningInfoBusinessImpl.resetInfoEWSQ :" + e.getMessage(),e);
        }
    }

    @Override
    public void resetInfoTrigAndPay(String cifNo , int headerId , int trigAndPayWarningId, String warningType, UserData user) throws Exception {
         try{
            /********** Mask CC :03/06/2015*********/
            WarningInfoVo warningInfoVoForCancel = new WarningInfoVo();
            warningInfoVoForCancel.setWarningHeaderId(headerId);
            warningInfoVoForCancel.setUpdatedBy(user.getEmpNo());
            warningInfoVoForCancel.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoVoForCancel.setStatus(BusinessConst.Flag.CANCEL);
            warningInfoVoForCancel.setTrigShowFlag(BusinessConst.Flag.N);
            warningInfoService.cancelTriggerAndPayment(warningInfoVoForCancel);
                
            WarningInfoVo warningInfoVoU = new WarningInfoVo();
            warningInfoVoU.setWarningId(trigAndPayWarningId);
            warningInfoVoU.setTrigGenFlag(BusinessConst.Flag.N);
            warningInfoVoU.setTrigShowFlag(BusinessConst.Flag.Y);
            warningInfoVoU.setStatus(BusinessConst.Flag.N);
            warningInfoVoU.setUpdatedBy(user.getEmpNo());
            warningInfoVoU.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningInfoService.updateShowAndGen(warningInfoVoU);
            
             //----------- UPDATE :  TBL_WARNING_HEADER -------------------//
            WarningHeaderVo headerVo = new  WarningHeaderVo();
            headerVo.setCif(cifNo);
            headerVo.setWarningHeaderId(headerId);
            headerVo.setUpdatedBy(user.getEmpNo());
            headerVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            headerVo.setTrigAndPayFlag(BusinessConst.Flag.N);
  //          warningHeaderService.updateFlagInWarningHeader(headerVo);
            
            ActionHistoryVo actionHistoryVo = new ActionHistoryVo();
            actionHistoryVo.setWarningId(trigAndPayWarningId);
            actionHistoryVo.setActionDt(DateUtil.getCurrentDateTime());
            actionHistoryVo.setActionBy(user.getEmpNo());
            actionHistoryVo.setActionCode(BusinessConst.ACTION_CODE.RESET);
            actionHistoryVo.setActionDetail(warningType);
            actionHistoryVo.setStatus(BusinessConst.Flag.N);
            actionHistoryService.saveData(actionHistoryVo);

            //----------- UPDATE :  TBL_CUST_REVIEW_EWS -------------------//
//            Integer haveCrOrTa = warningHeaderService.haveCrOrTaWithinHeader(headerId);
//                if(haveCrOrTa != null && haveCrOrTa > 0){
//                 if((!ValidatorUtil.isNullOrEmpty(cifNo))&&(headerId > 0)){
//                  crCustReviewEwsBusiness.updateFlagForChangeStatus(cifNo, headerId, BusinessConst.WarningTypeCode.TRIGANDPAY, BusinessConst.Flag.N, user);
//               }
//            }
        }catch(Exception e){
                log.error("Error occur in while process WarningInfoBusinessImpl.resetInfoTrigAndPay :" + e.getMessage(),e);
        }
    }

    @Override
    public WarningInfoVo findLastVersionByWarningTypeAndId(String warningType, int warningInfoId) throws Exception {
       return warningInfoService.findLastVersionByWarningTypeAndId(warningType, warningInfoId);
    }

    @Override
    public WarningInfoVo findWarningInfoObject(int warningHeaderId, String warningType) throws Exception {
        return warningInfoService.findWarningInfoObject(warningHeaderId, warningType);
    }

    @Override
    public void updateStatus(WarningInfoVo warningInfoVo) throws Exception {
        warningInfoService.updateStatus(warningInfoVo);
    }

    @Override
    public WarningInfoVo getWarningIdAndStatus(WarningInfoVo warningInfoVo) throws Exception {
        return warningInfoService.getWarningIdAndStatus(warningInfoVo);
    }
    
    @Override
    public void updateStatusForWayOut(WarningInfoVo warningInfoVo) throws Exception {
        warningInfoService.updateStatusForWayOut(warningInfoVo);
    }

    @Override
    public int getMinWarningId(WarningInfoVo warningInfoVo) throws Exception {
        return warningInfoService.getMinWarningId(warningInfoVo);
    }

    @Override
    public void updateConfirmLatepayment(String confirmLatePayment, String bcmConfirmLatePayment, String warningId) throws Exception {
        warningInfoService.updateConfirmLatepayment(confirmLatePayment, bcmConfirmLatePayment, warningId);
    }
    
    @Override
    public int insertLatePaymentPopup(UserData user, int warningHeaderId, String version, String questionId) throws Exception {
        log.info("[insertLatePaymentPopup][Begin]");
        
        WarningInfoVo   warningInfoVo = new WarningInfoVo();
        int             warningId   = 0;
        
        try{
            log.info("[insertLatePaymentPopup] warningHeaderId  :: " + warningHeaderId);
            log.info("[insertLatePaymentPopup] version          :: " + version);
            log.info("[insertLatePaymentPopup] questionId       :: " + questionId);
            
            warningInfoVo.setWarningHeaderId(warningHeaderId);
            warningInfoVo.setWarningType(BusinessConst.WarningTypeCode.LATE_PAY);
            warningInfoVo.setWarningDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setStatus(BusinessConst.Flag.N);
            warningInfoVo.setCreatedDate(DateUtil.getCurrentDateTime());
            warningInfoVo.setCreatedBy(user.getEmpNo());
            warningInfoVo.setSlaFlag(BusinessConst.Flag.N);
            warningInfoVo.setHolderId(user.getEmpNo());
            warningInfoVo.setHolderRole(user.getRoleId());
            warningInfoVo.setQuestionId(questionId);
            warningInfoVo.setVersion(version);
            
            warningInfoService.saveWarningInfo(warningInfoVo);
            
            warningId = warningInfoService.findMaxWarningId(warningHeaderId, BusinessConst.WarningTypeCode.LATE_PAY);
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[insertLatePaymentPopup][End]");
        }
        
        return warningId;
    }

    @Override
    public Integer findMaxWarningId(int warningHeaderId, String warningType) throws Exception {
        return warningInfoService.findMaxWarningId(warningHeaderId, warningType);
    }

    @Override
    public Integer cntLatePay(int warningHeaderId, String warningType) throws Exception {
        return warningInfoService.cntLatePay(warningHeaderId, warningType);
    }

    @Override
    public WarningInfoVo findWarningInfoObjectByMaxWarningInfo(int warningHeaderId, String warningType) throws Exception {
        return warningInfoService.findWarningInfoObjectByMaxWarningInfo(warningHeaderId, warningType);
    }
    
}
