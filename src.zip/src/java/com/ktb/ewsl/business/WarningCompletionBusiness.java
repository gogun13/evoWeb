/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.WarningCompletionVo;

/**
 *
 * @author pumin
 */
public interface WarningCompletionBusiness {
    
   public void InsertWarningCompletion(WarningCompletionVo vo) throws Exception;
   
}
