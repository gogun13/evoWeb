/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.KtbOrganizationServices;
import com.ktb.ewsl.services.ParameterService;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.ParameterVo;
import com.ktbcs.core.business.AbstractBusiness;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class DropdownBusinessImpl extends AbstractBusiness implements DropdownBusiness{
    
     private static Logger log = Logger.getLogger(DropdownBusinessImpl.class);
      
    @Autowired
    private KtbOrganizationServices ktbOrganizationServices;
    
    @Autowired
    private ParameterService parameterService;

    @Override
    public List getWorkLine() throws Exception {
        return ktbOrganizationServices.getWorkLine();
    }

    @Override
    public List getOrganizationGroup(String businessUnit) throws Exception {
         return ktbOrganizationServices.getOrganizationGroup(businessUnit);
    }

    @Override
    public List getDepartment(String businessUnit, String groupCode) throws Exception {
         return ktbOrganizationServices.getDepartment(businessUnit, groupCode);
    }

    @Override
    public List getOrganizationGroupAndEwsUse(String businessUnit) throws Exception {
         return ktbOrganizationServices.getOrganizationGroupAndEwsUse(businessUnit);
    }
    
 @Override
    public ArrayList getStatusDropdown() throws Exception {
        ArrayList<DropdownVo> result = new ArrayList<DropdownVo>();
        List<ParameterVo> paraList = parameterService.findByParamTypeId("STATUS");
        if(paraList!=null && paraList.size() > 0) {            
            for (int i=0; i<paraList.size(); i++){
                ParameterVo vo = (ParameterVo)paraList.get(i);
                DropdownVo item = new DropdownVo();
                item.setId(String.valueOf(vo.getValue1()));
                item.setDesc(vo.getParameterName());
                result.add(item);
            }
        }        
                    
        return result;
    }
    
}
