/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.WarningWayOutFormVo;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Pratya
 */
public interface WarningWayOutFormBusiness {
    
    public ArrayList<WarningWayOutFormVo> getDataListByWarningId (int warningId) throws Exception;
//    public void updateConfirmAnswer(WarningWayOutFormVo vo) throws Exception;
    public void saveWarningActionForm(List<WarningWayOutFormVo>   warningWayOutFormVoList, String actionWarningId, UserData user) throws Exception;
    public void deleteWarningActionForm(String actionWarningId, String roleCode) throws Exception;
   
}
