/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.MenuService;
import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Luksamee
 */
@Service
public class MenuBusinessImpl extends AbstractBusiness implements MenuBusiness {

    @Autowired
    private MenuService menuService;

    @Override
    public ArrayList<MenuInfoVo> getMainMenu(UserData user) throws Exception {
        ArrayList<MenuInfoVo> menuList = null;
        try {
            if(user != null){
               menuList = menuService.getMainMenu(user.getRoleId());
            }
           
        } catch (Exception e) {
            throw e;
        }
        return menuList;
    }

    public ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass) throws Exception {
        ArrayList<MenuLevelVo> menuLevelList;
        try {
            menuLevelList = menuService.getTabMenu(mainMenuId, userClass);
        } catch (Exception e) {
            throw e;
        }
        return menuLevelList;

    }

    public ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass, String menuGroup) throws Exception {
        ArrayList<MenuLevelVo> menuLevelList;
        try {
            menuLevelList = menuService.getTabMenu(mainMenuId, userClass, menuGroup);
        } catch (Exception e) {
            throw e;
        }
        return menuLevelList;

    }

    public MenuInfoVo getFirstChild(String menuId, String userClass) throws Exception{
        MenuInfoVo menu = null;

        try {
            menu = menuService.getFirstChild(menuId, userClass);
        } catch (Exception e) {
            throw e;
        }

        return menu;
    }

    public MenuInfoVo getFirstChild(String menuId, String userClass, String menuGroup) throws Exception{
        MenuInfoVo menu = null;

        try {
            menu = menuService.getFirstChild(menuId, userClass, menuGroup);
        } catch (Exception e) {
            throw e;
        }

        return menu;
    }
}
