/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.QuestionVo;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author surapong
 */
public interface QuestionBusiness {
    public List<QuestionVo> findQuestionByFilter(QuestionVo filter) throws Exception;
    public void saveAssessmentAnswer(List<QuestionVo> questionVoList, UserData user, String actionMode) throws Exception;
}
