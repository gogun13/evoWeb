/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.ActionCloseService;
import com.ktb.ewsl.services.ActionHistoryService;
import com.ktb.ewsl.services.ParameterService;
import com.ktb.ewsl.services.WarningCompletionService;
import com.ktb.ewsl.services.WarningHeaderService;
import com.ktb.ewsl.services.WarningInfoService;
import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.CustomerPortfolioVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.WarningCompletionVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.exceptions.RenowalException;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import com.ktbcs.core.vo.UserData;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class WarningHeaderBusinessImpl extends AbstractBusiness implements WarningHeaderBusiness {

    private static Logger log = Logger.getLogger(WarningHeaderBusinessImpl.class);
    @Autowired
    private WarningHeaderService warningHeaderService;
    @Autowired
    private ActionCloseService actionCloseService;
    @Autowired
    private WarningInfoService warningInfoService;
    @Autowired
    private AsstQuestionBusiness asstQuestionBusiness;
    @Autowired
    private ActionHistoryService actionHistoryService;
    @Autowired
    private WarningTypeService warningTypeService;
    @Autowired
    private ParameterService parameterService;
    @Autowired
    private WarningCompletionService warningCompletionService;


    @Override
    public void updateFlagInWarningHeaderForFin(int warningHeaderId, UserData user, String status) throws Exception {
        try {
            WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
            warningHeaderVo.setWarningHeaderId(warningHeaderId);
            warningHeaderVo.setUpdatedBy(user.getEmpNo());
            warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningHeaderVo.setFinFlg(status);
            warningHeaderService.updateFlagInWarningHeader(warningHeaderVo);
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderBusinessImpl.updateFlagInWarningHeaderForFin : " + e.getMessage(), e);
        }
    }
    
    @Override
    public void closeJob(WarningHeaderVo warningHeaderVo, UserData user, String reason, String remark, String actionMode, Integer warningId, String warningType) throws Exception, RenowalException {
        if (log.isInfoEnabled()) {
            log.info("WarningHeaderBusinessImpl.closeJob");
            log.info(" Status 2 = " + warningHeaderVo.getStatus());
        }
        warningHeaderVo.setUpdatedBy(user.getEmpNo());
        warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());

//update status BY CIF
        if (warningId == null || warningId.intValue() <= 0) {
            warningHeaderVo.setStatus(BusinessConst.Flag.CLOSE_JOB); //---ANN MOVE FORM ACTION
            if (!"Approve".equals(actionMode)) {
                warningHeaderService.updateStatusWarningHeader(warningHeaderVo);
            }
// insert data to action close
            ActionCloseVo actionCloseVo = new ActionCloseVo();
            actionCloseVo.setWarningHeadId(warningHeaderVo.getWarningHeaderId());
            actionCloseVo.setWarningId(warningId);
            actionCloseVo.setActionDt(DateUtil.getCurrentDateTime());
            actionCloseVo.setActionBy(user.getEmpNo());
            // actionCloseVo.setReasonCode(reason);
            actionCloseVo.setReasonDetail( reason == null || reason.trim().length() == 0 ? null : parameterService.findByParamIdAndParamType(reason, BusinessConst.PARAMETER_TYPE_ID.CLOSEJOB).getParameterName());
            actionCloseVo.setStatus(warningHeaderVo.getStatus());
            actionCloseVo.setRemark(remark);
            actionCloseVo.setRoleCode(user.getRoleId());
            actionCloseService.saveData(actionCloseVo);

            log.info(" actionMode = " + actionMode);
            
            if ("Approve".equals(actionMode)) {
                List<WarningInfoVo> warningInfoVoList = warningInfoService.findWarningInfoByHeaderId(warningHeaderVo.getWarningHeaderId());
                
                log.info(" warningInfoVoList = " + warningInfoVoList);
                
                if (!warningInfoVoList.isEmpty()) {
                    for (WarningInfoVo warningInfoVo : warningInfoVoList) {
                        if (BusinessConst.WarningTypeCode.TURNAROUND.equals(warningInfoVo.getWarningType()) || BusinessConst.WarningTypeCode.CREDIT_REVIEW.equals(warningInfoVo.getWarningType())) {
                            continue;
                        }
                        closeJobByWarningId(warningHeaderVo, user, "", "", actionMode, warningInfoVo.getWarningId(), warningInfoVo.getWarningType(), true);
                    }
                }
            }
        } else { //update status BY FORM
            log.info("  getStatus ==>" + warningHeaderVo.getStatus());
            closeJobByWarningId(warningHeaderVo, user, reason, remark, actionMode, warningId, warningType, false);
           /*23/08/2017 ขึ้นพร้อม R9 แก้ไขให้ถูกต้องเมื่อปิดงานไม่ต้อง Call ScoreEngine
            *if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType) || BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
                if (warningHeaderVo.getWarningHeaderId() > 0) {
                    if (asstQuestionBusiness.validateCanSendEWS(warningHeaderVo.getWarningHeaderId())) {
                        asstQuestionBusiness.sendEWSQ(warningHeaderVo.getWarningHeaderId(), user, warningHeaderVo.getCif().toString());
                    }
                }
            }*/
        }
    }

    private void closeJobByWarningId(WarningHeaderVo warningHeaderVo, UserData user, String reason, String remark, String actionMode, Integer warningId, String warningType, boolean closeByCifFlag) throws Exception, RenowalException {
        log.info("Entry to .........WarningHeaderBusinessImpl.closeJobByWarningId");
        log.info(" actionMode = " + actionMode);
        String actionStatus = warningHeaderVo.getStatus();
        
        WarningInfoVo warningInfoVo = new WarningInfoVo();
        warningInfoVo.setWarningId(warningId);
        warningInfoVo.setUpdatedBy(user.getEmpNo());
        warningInfoVo.setUpdatedDate(DateUtil.getCurrentDateTime());
        warningInfoVo.setCloseFlag(BusinessConst.Flag.Y);
        warningInfoVo.setHolderId(null);
        warningInfoVo.setHolderRole(BusinessConst.UserRole.BCM);
        if ("Reject".equals(actionMode)) {
            warningInfoVo.setCloseFlag(BusinessConst.Flag.N);
            warningInfoVo.setHolderId(null);
            warningInfoVo.setHolderRole(null);
            WarningInfoVo warningInfoVoForCheck = warningInfoService.findWarningInfoObj(warningHeaderVo.getWarningHeaderId(), warningId, warningType);
            if (warningInfoVoForCheck != null) {
                if (BusinessConst.Flag.RMP.equals(warningInfoVoForCheck.getStatus()) || BusinessConst.Flag.CMP.equals(warningInfoVoForCheck.getStatus()) || BusinessConst.Flag.SCMP.equals(warningInfoVoForCheck.getStatus())) {
                    List<ActionHistoryVo> actionHistoryVoList = actionHistoryService.findDataByWarningId(warningId);
                    if (!actionHistoryVoList.isEmpty()) {
                        ActionHistoryVo actionHistoryVo = actionHistoryVoList.get(0);
                        warningInfoVo.setHolderId(actionHistoryVo.getActionBy());
                        warningInfoVo.setHolderRole(asstQuestionBusiness.getHolderRole(actionHistoryVo.getStatus(), "" , user.getRoleId()));
                    }
                }
            }
            warningInfoService.updateClosejob(warningInfoVo);
        } else if ("Approve".equals(actionMode)) {
            warningInfoVo.setHolderId(user.getEmpNo());
            warningInfoVo.setHolderRole(user.getRoleId());
            warningInfoVo.setStatus(BusinessConst.Flag.COMPLETE);
            warningInfoVo.setCloseFlag(BusinessConst.Flag.Y);

            warningInfoService.updateStatusAndCloseFlag(warningInfoVo);
            if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                List<WarningTypeVo> warningTypeVoList = warningTypeService.findWarningTypeByUnderType(BusinessConst.WarningTypeCode.EWSQ);
                if (!warningTypeVoList.isEmpty()) {
                    List<String> warningTypeList = new ArrayList<String>();
                    for (WarningTypeVo warningTypeVo : warningTypeVoList) {
                        warningTypeList.add(warningTypeVo.getWarningTypeCode());
                    }
                    List<WarningInfoVo> warningInfoVoListForUpdate = warningInfoService.findWarningInfoByHeaderAndWarningTypeList(warningHeaderVo.getWarningHeaderId(), warningTypeList);
                    for (WarningInfoVo warningInfoVoForUpdate : warningInfoVoListForUpdate) {
                        if (BusinessConst.Flag.COMPLETE.equals(warningInfoVoForUpdate.getStatus()) || BusinessConst.Flag.CANCEL.equals(warningInfoVoForUpdate.getStatus())) {
                            continue;
                        }
                        warningInfoVoForUpdate.setCloseFlag(BusinessConst.Flag.Y);
                        warningInfoVoForUpdate.setHolderId(user.getEmpNo());
                        warningInfoVoForUpdate.setHolderRole(user.getRoleId());
                        warningInfoVoForUpdate.setStatus(warningHeaderVo.getStatus());
                        warningInfoVoForUpdate.setUpdatedBy(user.getEmpNo());
                        warningInfoVoForUpdate.setUpdatedDate(DateUtil.getCurrentDateTime());
                        warningInfoService.updateStatusAndCloseFlag(warningInfoVoForUpdate);
                    }

                }
            }
        } else {
            warningInfoService.updateClosejob(warningInfoVo);
        }

        WarningHeaderVo warningHeaderVoforCheck = warningHeaderService.findWarningHeaderObjectOriginal(warningHeaderVo.getWarningHeaderId(), warningHeaderVo.getCif());//warningHeaderService.findWarningHeaderByPK(warningHeaderVo.getWarningHeaderId());
        if (warningHeaderVoforCheck != null) {
            if ("Reject".equals(actionMode)) {
                if (BusinessConst.WarningTypeCode.TRIGANDPAY.equals(warningType)) {
                    warningHeaderVo.setTrigAndPayFlag(warningHeaderVoforCheck.getTrigAndPayFlag().substring(1, warningHeaderVoforCheck.getTrigAndPayFlag().length()));
                } else if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                    warningHeaderVo.setQualiFlg(warningHeaderVoforCheck.getQualiFlg().substring(1, warningHeaderVoforCheck.getQualiFlg().length()));
                } else if (BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
                    warningHeaderVo.setFinFlg(warningHeaderVoforCheck.getFinFlg().substring(1, warningHeaderVoforCheck.getFinFlg().length()));
                }
            } else if ("Approve".equals(actionMode)) {
                  if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                    warningHeaderVo.setQualiFlg(BusinessConst.Flag.E);
                    warningHeaderVo.setFinFlg(null);
                } else if (BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
                    warningHeaderVo.setFinFlg(BusinessConst.Flag.E);
                    warningHeaderVo.setQualiFlg(null);
                }
            } else {
                if (BusinessConst.WarningTypeCode.EWSQ.equals(warningType)) {
                    warningHeaderVo.setQualiFlg("R".concat(warningHeaderVoforCheck.getQualiFlg()));
                } else if (BusinessConst.WarningTypeCode.FIN.equals(warningType)) {
                    warningHeaderVo.setFinFlg("R".concat(warningHeaderVoforCheck.getFinFlg()));
                }
            }
            warningHeaderVo.setStatus(warningHeaderVoforCheck.getStatus());
            warningHeaderService.updateFlagInWarningHeader(warningHeaderVo); //----- NOTE NEED TO UPDATE HEADER STATUS
        }
       
        if (!closeByCifFlag) {
            ActionCloseVo actionCloseVo = new ActionCloseVo();
            actionCloseVo.setWarningHeadId(warningHeaderVo.getWarningHeaderId());
            actionCloseVo.setWarningId(warningId);
            actionCloseVo.setActionDt(DateUtil.getCurrentDateTime());
            actionCloseVo.setActionBy(user.getEmpNo());
//            actionCloseVo.setReasonCode(reason);
            actionCloseVo.setReasonDetail( reason == null || reason.trim().length() == 0 ? null : parameterService.findByParamIdAndParamType(reason, BusinessConst.PARAMETER_TYPE_ID.CLOSEJOBBYTYPE).getParameterName());
//            actionCloseVo.setStatus(warningHeaderVo.getStatus());//actionStatus
            actionCloseVo.setStatus(!ValidatorUtil.isNullOrEmpty(actionStatus) ? actionStatus : BusinessConst.Flag.CLOSE_JOB );
            actionCloseVo.setRemark(remark);
            if ("Approve".equals(actionMode)){ // pumin: 17/09/2015 insert reason_code = 'E' when click approve
                actionCloseVo.setReasonCode("E");
            }
            actionCloseVo.setRoleCode(user.getRoleId());
            actionCloseService.saveData(actionCloseVo);
        }
       
        
        if ("Approve".equals(actionMode)) {
             //-------------- Check Close OUT OF Pipleline
            if(warningHeaderVo.getWarningHeaderId() != null && warningHeaderVo.getWarningHeaderId() > 0 && user!= null){
                 Integer result = warningHeaderService.checkDataBeforeCloseOutOfPipeline(warningHeaderVo.getWarningHeaderId());
                 log.info(" checkDataBeforeCloseOutOfPipeline result -->> " + result);
                 if(result != null && result > 0){
                     warningHeaderService.updateStateAfterCheckDataBeforeCloseOutOfPipeline(user.getEmpNo(), warningHeaderVo.getWarningHeaderId());
                     WarningCompletionVo warningCompletionVo = new WarningCompletionVo();
                     warningCompletionVo.setWarningHeadId(String.valueOf(warningHeaderVo.getWarningHeaderId()));
                      String completeFlag = "";
                        if(BusinessConst.WarningTypeCode.EWSQ.equals(warningType)){
                            completeFlag = BusinessConst.COMPLETE_FLAG_BY_WARNING_TYPE.EWSQ_CLOSE;
                            warningCompletionVo.setRemark("อนุมัติ ปิดฟอร์ม Qualitative");
                        }else if(BusinessConst.WarningTypeCode.FIN.equals(warningType)){
                            completeFlag = BusinessConst.COMPLETE_FLAG_BY_WARNING_TYPE.FIN_CLOSE;
                            warningCompletionVo.setRemark("อนุมัติ ปิดฟอร์ม Financial");
                        }
                        warningCompletionVo.setCreatedDt(DateUtil.getCurrentDateTime());
                        warningCompletionVo.setCreatedBy(user.getEmpNo());
                        if(!"".equals(completeFlag)){
                            warningCompletionVo.setCompleteFlg(completeFlag);
                            warningCompletionService.InsertWarningCompletion(warningCompletionVo);
                        }
                 }
             }
        }
    }

    @Override
    public WarningHeaderVo findWarningHeaderObject(int warningHeaderId, String cifNo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findWarningHeaderObject");
        }

        return warningHeaderService.findWarningHeaderObject(warningHeaderId, cifNo);
    }

    @Override
    public List<ActionCloseVo> findReasonForClose(Integer warningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findReasonForClose");
        }

        return actionCloseService.findDataByWarningHeadId(warningHeaderId);
    }

    @Override
    public boolean valueFlagWarningInfo(String data , String closeFlag) throws Exception {
        boolean valueResult = false;
        /* if data is null or "" that mean not have Record ing waringInfo */
        if (data == null || data.trim().equals("") || BusinessConst.Flag.DEFAULT.equals(data)) {
            valueResult = true;
        } else {
           // if (BusinessConst.Flag.COMPLETE.equals(data.trim()) || BusinessConst.Flag.E.equals(data.trim())) { // FIX Bug : 2.0.1 : 03/04/2560 ปิดงานไม่ส่ง Score
            if(BusinessConst.Flag.COMPLETE.equals(data.trim()) && !BusinessConst.Flag.Y.equals(closeFlag)){
                valueResult = true;
            }
        }
        return valueResult;
    }
    
    @Override
    public boolean valueFlagHeaderFlag(String dataStatus) throws Exception{
        boolean valueResult = false;
        /* if data is null or "" that mean not alert that form */
        if (dataStatus == null || dataStatus.trim().equals("")) {
            valueResult = true;
        } else {
            if (BusinessConst.Flag.COMPLETE.equals(dataStatus.trim()) || BusinessConst.Flag.E.equals(dataStatus.trim())) {
                valueResult = true;
            }
        }
        return valueResult;
    }
    
    @Override
    public void updateStatusAndFinFlag(int warningHeaderId, UserData user, String status) throws Exception {
         try {
            WarningHeaderVo warningHeaderVo = new WarningHeaderVo();
            warningHeaderVo.setWarningHeaderId(warningHeaderId);
            warningHeaderVo.setUpdatedBy(user.getEmpNo());
            warningHeaderVo.setUpdatedDate(DateUtil.getCurrentDateTime());
            warningHeaderVo.setFinFlg(status);
            warningHeaderVo.setStatus(BusinessConst.Flag.INPROCESS);
            warningHeaderService.updateStatusWarningHeaderAndFinFlag(warningHeaderVo);
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderBusinessImpl.updateStatusAndFinFlag : " + e.getMessage(), e);
        }
    }

    @Override
    public WarningHeaderVo findWarningHeaderByPK(int warningHeaderId) throws Exception {
        return  warningHeaderService.findWarningHeaderByPK( warningHeaderId );
    }

    @Override
    public List<QuestionHistoryVo> findWarningIdForQuestion(String cif ,String warningType) throws Exception {
        return  warningHeaderService.findWarningIdForQuestion(cif,warningType);
    }

    @Override
    public PaginatedListImpl getPipeline(PaginatedListImpl paginate, SearchBean searchBean,UserData userData , int pageAmt) throws Exception {
        log.info("[getPipeline][Begin]");
        
        PaginatedListImpl           paginateDb  = null;
        ArrayList<WarningHeaderVo>  taskList    = null;
        int                         crSla       = 0;
        String                      cName       = "";
        
        try{
            if (searchBean == null) {
                searchBean = new SearchBean();
            }
            searchBean.setResponseUnit(userData.getDeptCode());
            searchBean.setRoleId(userData.getRoleId());
            searchBean.setEmpNo(userData.getEmpNo());
            
            
            paginateDb  = warningHeaderService.getPipeline(paginate, searchBean, pageAmt);
            taskList    = paginateDb.getList();
            
            for(WarningHeaderVo vo:taskList){
                if(vo.getMaturityDateStr()==null || vo.getMaturityDateStr().equals("")){
                    vo.setCrAcctCnt("");
                    vo.setCrWarningCnt("");
                }else{
                    crSla   = vo.getCrSla();
                    cName   = "";
                    
//                    log.info("[getPipeline] crSla :: " + crSla);
                    if(crSla > 0 && crSla<=15){
                        cName = "warningClass";
                    }else if(crSla<=0){
                        cName = "errorClass";
                    }
                    
                    vo.setcName(cName);
                }
            }
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[getPipeline][End]");
        }
            
        return paginateDb;
    }
    
    @Override
    public void updateStatusWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception{
        warningHeaderService.updateStatusWarningHeader(warningHeaderVo);
    }

    @Override
    public void updateAction1Flg(WarningHeaderVo warningHeaderVo) throws Exception {
        warningHeaderService.updateAction1Flg(warningHeaderVo);
    }
    
    @Override
    public void updateAction2Flg(WarningHeaderVo warningHeaderVo) throws Exception {
        warningHeaderService.updateAction2Flg(warningHeaderVo);
    }
    
//    @Override
//    public void updateWayOutFlg(WarningHeaderVo warningHeaderVo) throws Exception {
//        warningHeaderService.updateWayOutFlg(warningHeaderVo);
//    }
    
    @Override
    public void updateForApprove(WarningHeaderVo warningHeaderVo, String completeFlg) throws Exception {
        log.info("[updateForApprove][Begin]");
        
        int                 rowEffiected        = 0;
        WarningCompletionVo warningCompletionVo = null;
        
        try{
            rowEffiected = warningHeaderService.updateStateAfterCheckDataBeforeCloseOutOfPipeline(warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId());
            
            log.info("[updateForApprove] rowEffiected :: " + rowEffiected);
            
            if(rowEffiected==1){
                warningCompletionVo = new WarningCompletionVo();
                warningCompletionVo.setWarningHeadId(String.valueOf(warningHeaderVo.getWarningHeaderId()));
                warningCompletionVo.setCreatedBy(warningHeaderVo.getUpdatedBy());
                warningCompletionVo.setCompleteFlg(completeFlg);
                
                warningCompletionService.InsertWarningCompletionForApprove(warningCompletionVo);
            }
            
        }catch(Exception e){
            throw e;
        }finally{
            log.info("[updateForApprove][End]");
        }
    }

    @Override
    public WarningHeaderVo findWarningHeaderObjectOriginal(int warningHeaderId, String cifNo) throws Exception {
       return warningHeaderService.findWarningHeaderObjectOriginal(warningHeaderId, cifNo);
    }

    @Override
    public void updateStateAfterCheckDataBeforeCloseOutOfPipeline(String updateBy, int warningHeaderId) throws Exception {
       warningHeaderService.updateStateAfterCheckDataBeforeCloseOutOfPipeline(updateBy, warningHeaderId);
    }
    
    @Override
    public void updateForApproveForCloaseByCif(WarningHeaderVo warningHeaderVo, String completeFlg) throws Exception {
        log.info("[updateForApprove][Begin]");
        
        int                 rowEffiected        = 0;
        WarningCompletionVo warningCompletionVo = null;
        
        try{
            rowEffiected = warningHeaderService.updateForApproveForCloaseByCif(warningHeaderVo);
            
            log.info("[updateForApprove] rowEffiected :: " + rowEffiected);
            
            if(rowEffiected==1){
                warningCompletionVo = new WarningCompletionVo();
                warningCompletionVo.setWarningHeadId(String.valueOf(warningHeaderVo.getWarningHeaderId()));
                warningCompletionVo.setCreatedBy(warningHeaderVo.getUpdatedBy());
                warningCompletionVo.setCompleteFlg(completeFlg);
                
                warningCompletionService.InsertWarningCompletionForApprove(warningCompletionVo);
            } /*else{
                warningHeaderVo.setStatus("W");
                warningHeaderService.updateStatusWarningHeader(warningHeaderVo);
            }*/
            
        }catch(Exception e){
            throw e;
        }finally{
            log.info("[updateForApprove][End]");
        }
    }

    @Override
    public int countForCloseByCif(int warningHeaderId) throws Exception {
        return warningHeaderService.countForCloseByCif(warningHeaderId);
    }

    @Override
    public Integer findWarningInfoALLNewOrBlank(int warningHeaderId) throws Exception {
        return warningHeaderService.findWarningInfoALLNewOrBlank(warningHeaderId);
    }
    
    @Override
    public List<QuestionHistoryVo> findWarningIdForHistory(String cif, String warningType) throws Exception {
          return warningHeaderService.findWarningIdForHistory(cif,warningType);
    }

    @Override
    public Integer countPipelineHaveCoOp(SearchBean searchBean, UserData userData) throws Exception {
        Integer amtHaveCoOp = 0;
        try{
            SearchBean sbForCountCoOp = new SearchBean();
            sbForCountCoOp.setRoleId(userData.getRoleId());
            sbForCountCoOp.setEmpNo(userData.getEmpNo());
            sbForCountCoOp.setResponseUnit(userData.getDeptCode());
            amtHaveCoOp = warningHeaderService.countPipelineHaveCoOp(sbForCountCoOp);
            
        }catch(Exception e){
           throw e;
        }
        return amtHaveCoOp;
    }

}
