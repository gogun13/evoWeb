/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import java.io.IOException;
import java.io.InputStream;

import com.ktb.ewsl.vo.AnnouncementVo;
import com.ktbcs.core.utilities.PaginatedListImpl;

/**
 *
 * @author KapookZa
 */
public interface AnnouncementBusiness {

    public Integer saveAnnouncement(AnnouncementVo announcementVo) throws Exception;

    public void deleteAnnouncement(int seq,String updatedBy) throws Exception;

    public PaginatedListImpl<AnnouncementVo> getListAnnouncement(AnnouncementVo announcementVo, PaginatedListImpl<AnnouncementVo> paginate, int pageAmt) throws Exception;

    public AnnouncementVo getAnnouncementVo(AnnouncementVo announcementVo) throws Exception;

    public void updateAnnouncement(AnnouncementVo announcementVo) throws Exception;

    public InputStream getInputStreamFromFile(String directory, String fileName) throws Exception, IOException;

    public void saveFileOutputStream(String pathFile, AnnouncementVo announcementVo) throws Exception;
    
    public Integer getMaxSeq() throws Exception ;

	PaginatedListImpl<AnnouncementVo> getListPostAnnouncement(PaginatedListImpl<AnnouncementVo> paginate)
			throws Exception;
}
