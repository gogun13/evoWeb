/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.KtbOrganization;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public interface KtbOrganizationBusiness {
    
    public KtbOrganization getOrganizationByCostcenter(String costcenter)throws Exception;
    
    public String findCostCenterName(String costcenter)throws Exception;
    
    public ArrayList<DropdownVo> getResponseUnit(String businessUnit, String groupCode, String fieldOrder) throws Exception;
    
    public ArrayList<DropdownVo> getOrganizationResponseUnit(String costcenterCode, String fieldOrder) throws Exception;
    
    //R4
    public String getCostCenterDescByCode(String costCenterCode) throws Exception;
}
