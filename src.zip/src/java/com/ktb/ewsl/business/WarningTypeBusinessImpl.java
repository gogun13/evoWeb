/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.WarningTypeService;
import com.ktb.ewsl.vo.WarningTypeVo;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class WarningTypeBusinessImpl implements WarningTypeBusiness{
    
    private static Logger log = Logger.getLogger(WarningTypeBusinessImpl.class);
      
    @Autowired
    private  WarningTypeService warningTypeService;

    @Override
    public ArrayList<WarningTypeVo> getColumnByPrivilege(String roleId, String warningTypeGroup) throws Exception {
         return warningTypeService.getColumnByPrivilege(roleId, warningTypeGroup);
    }
}
