/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.InOutLogService;
import com.ktb.ewsl.vo.InOutLogVo;
import com.ktbcs.core.business.AbstractBusiness;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class InOutLogBusinessImpl extends AbstractBusiness implements InOutLogBusiness{
    
    private static Logger log = Logger.getLogger(InOutLogBusinessImpl.class);
      
    @Autowired
    private InOutLogService inOutLogService;

    @Override
    public void insertInOutLog(UserData user ,String loginStatus , String loginStatusDesc ) throws Exception {
        try{
            if(user != null){
                 InOutLogVo data = new InOutLogVo();
                 data.setDepCode(user.getDeptCode());
                 data.setDepName(user.getDeptName());
                 data.setLoginStatus(loginStatus);
                 data.setLoginStatusDesc(loginStatusDesc);
                 data.setLogoutStatus(null);
                 data.setLogoutStatusDesc(null);
                 data.setLoginDate(DateUtil.getCurrentDateTime());
                 data.setLogoutDate(null);
                 data.setPosCode(user.getKtbFieldMap());
                 data.setPosName(user.getEmpPosition());
                 data.setServerIP(user.getRemoteIp());
                 data.setSessionId(user.getSessionId());
                 data.setUserId(user.getEmpNo());
                 data.setUserIP(user.getUserIP());
                 data.setUserName(user.getFullName());   
                 data.setUpdatedBy(user.getEmpNo());
                 data.setUpdatedDate(DateUtil.getCurrentDateTime());
                 inOutLogService.insertInOutLog(data);
            }
        
        }catch(Exception e){
           log.error("Error occur in while process InOutLogBusinessImpl.insertInOutLog : " + e.getMessage());
        }
    }
     @Override
    public void checkAndKickOfUserInOutLog(String userId ,  String userIP , String serverIP ) throws Exception {
       log.debug("Entry to InOutLogBusinessImpl.checkAndKickOfUserInOutLog");
       try{
           //----------FIND : UserID And userIP
           if(!ValidatorUtil.isNullOrEmpty(userId) && (!ValidatorUtil.isNullOrEmpty(userIP) || !ValidatorUtil.isNullOrEmpty(serverIP))){
                Integer resultDup  =  inOutLogService.findUserIdAndDeviceIPOnJob(userId, userIP, serverIP);
                 if(resultDup != null && resultDup > 0 ){
                     InOutLogVo inOutVo = new InOutLogVo();
                     inOutVo.setLogoutStatus(BusinessConst.ACCESS_SYSTEM.EXP);
                     inOutVo.setLogoutStatusDesc(BusinessConst.ACCESS_SYSTEM.EXPIRED);
                     inOutVo.setUserId(userId);
                     inOutVo.setUserIP(userIP);
                     inOutVo.setUpdatedBy(userId);
                     inOutVo.setServerIP(serverIP);
                     //-------- UPDATE
                     inOutLogService.updateExpire(inOutVo);
                 }
           }
           //--------- FIND : By User
           if(!ValidatorUtil.isNullOrEmpty(userId)){
                 Integer resultDup  =  inOutLogService.findUserIdOnJob(userId);
                 if(resultDup != null && resultDup > 0 ){
                     InOutLogVo inOutVo = new InOutLogVo();
                     inOutVo.setLogoutStatus(BusinessConst.ACCESS_SYSTEM.EXP);
                     inOutVo.setLogoutStatusDesc(BusinessConst.ACCESS_SYSTEM.EXPIRED);
                     inOutVo.setUserId(userId);
                     inOutVo.setUserIP(null);
                     inOutVo.setUpdatedBy(userId);
                     inOutVo.setServerIP(null);
                     //-------- UPDATE
                     inOutLogService.updateExpire(inOutVo);
                 }
           }
           //---------- FIND : By IP
          if(!ValidatorUtil.isNullOrEmpty(userIP) || !ValidatorUtil.isNullOrEmpty(serverIP)){
           Integer resultDup  =  inOutLogService.findDeviceIPOnJob(userIP, serverIP);
                 if(resultDup != null && resultDup > 0 ){
                     InOutLogVo inOutVo = new InOutLogVo();
                     inOutVo.setLogoutStatus(BusinessConst.ACCESS_SYSTEM.EXP);
                     inOutVo.setLogoutStatusDesc(BusinessConst.ACCESS_SYSTEM.EXPIRED);
                     inOutVo.setUserId(null);
                     inOutVo.setUserIP(userIP);
                     inOutVo.setUpdatedBy(userId);
                     inOutVo.setServerIP(serverIP);
                     //-------- UPDATE
                     inOutLogService.updateExpire(inOutVo);
                 }
           }
           
           
       }catch(Exception e){
             log.error("Error occur in while process InOutLogBusinessImpl.checkAndKickOfUserInOutLog : " + e.getMessage());
       } 
    }

    @Override
    public void updateLogout(InOutLogVo inOutLogVo) throws Exception {
         inOutLogService.updateLogout(inOutLogVo);
    }

    @Override
    public boolean checkUserLoginBeforeNextProcess(String userId, String userIP, String serverIP,String sessionId) throws Exception {
       log.debug("Entry to InOutLogBusinessImpl.checkUserLoginBeforeNextProcess");
       boolean onProcess = true;
       try{
           //----------FIND : UserID And userIP
           if(!ValidatorUtil.isNullOrEmpty(userId) && (!ValidatorUtil.isNullOrEmpty(userIP) || !ValidatorUtil.isNullOrEmpty(serverIP)) || !ValidatorUtil.isNullOrEmpty(sessionId)){
                Integer result  =  inOutLogService.findUserIdAndDeviceIPForBaseAction(userId, userIP, serverIP, sessionId);
                 if(result == null ||  result == 0 ){
                    onProcess = false;
                 }
           }
           
       }catch(Exception e){
             log.error("Error occur in while process InOutLogBusinessImpl.checkUserLoginBeforeNextProcess : " + e.getMessage());
       } 
       return onProcess;
    }
}
