/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.services.KtbFieldMapService;
import com.ktb.ewsl.vo.KtbFieldMapVO;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author KTBDevLoan
 */
@Service
public class KtbFieldMapBusinessImpl implements KtbFieldMapBusiness{
    
    private static final Logger log = Logger.getLogger(KtbFieldMapBusinessImpl.class);
 
    @Autowired
    private KtbFieldMapService ktbFieldMapService;
      
    @Override
    public String getRankCodeByGroup(int ktbFieldMapGroup) throws Exception {
        String param = new String();
        try{
            List datalist = ktbFieldMapService.getKtbFieldMapList(ktbFieldMapGroup);
            if(!datalist.isEmpty()){
                for(int i=0 ; i < datalist.size(); i++){
			 KtbFieldMapVO dataVO = (KtbFieldMapVO)datalist.get(i);
                         if(!ValidatorUtil.isNullOrEmpty(dataVO.getKtbFieldMapCode())){
                            String  data = dataVO.getKtbFieldMapCode() != null ?  dataVO.getKtbFieldMapCode() : ""; 
                            param = param.concat("'").concat(data).concat("'");
                            if(i < datalist.size() - 1 ){
                                   param  = param.concat(",");
                            } 
                         }
		}
            }
        System.out.println("getRankCodeByGroup param = " + param);
        }catch(Exception e){
          log.error("Error occur in while process KtbFieldMapBusinessImpl.getRankCodeByGroup: " + e.getMessage() , e);
        }
        return param ; 
    }
    
}
