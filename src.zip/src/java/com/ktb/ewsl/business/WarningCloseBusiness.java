/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.business;

import com.ktb.ewsl.vo.WarningCloseVo;
import java.util.ArrayList;

/**
 *
 * @author pumin
 */
public interface WarningCloseBusiness {
    
    public ArrayList<WarningCloseVo> getWarningClose(String WarningHeaderId) throws Exception;
    public void insertWarningClose(WarningCloseVo vo) throws Exception;
    public String getReasonFlg(String warningHeadId) throws Exception;
    public String getStatusByMaxCreatedDt(String warningHeadId) throws Exception;
   
}
