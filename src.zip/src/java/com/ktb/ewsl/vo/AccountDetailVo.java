/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Tum_Surapong
 */
public class AccountDetailVo extends BaseVo{
    
    private String cif;
    private String accountNo;
    private String billNo;
    private BigDecimal mainLimitAmt;
    private BigDecimal limitAmt;
    private String limitAmtS;
    private String mainLimitAmtS;
    private BigDecimal outstandingAmt;
    private BigDecimal mainOutstandingAmt;
    private String outstandingAmtS;
    private String mainOutstandingAmtS;
    private Date maturityDate;
    private String maturityDateS;
    private Date dueDate;
    private String dueDateS;
    private String dpd;
    private String lastDpd;
    private Date warningDate;
    private String warningDateS;
    private BigDecimal dueAmt;
    private String dueAmtS;
    private BigDecimal unpaidAmt;
    private String unpaidAmtS;
    private Date expiryDt;
    private String expiryDtS;
    private Date nextExpiryDt;
    private String nextExpiryDtS;
    private Date createdDtm;
    private String createdDtmS;
    private Date approveDtm;
    private String approveDtmS;
    private String approveBy;
    private String prodGrp;
    private String prodType;
    private String acctSubType;
    private String editorRole;
    private String approveRole;
    private String acctclassName;
    private BigDecimal unpaidInterest;
    private BigDecimal unpaidPrincipal;
    private BigDecimal lateCharge;
    private String loanGrpProd;
    private String marketCd;
    private Date paidDate;
    private String paidDateStr;
    
    public String getMarketCd() {
        return marketCd;
    }

    public void setMarketCd(String marketCd) {
        this.marketCd = marketCd;
    }
    
    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public BigDecimal getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(BigDecimal limitAmt) {
        this.limitAmt = limitAmt;
    }

    public BigDecimal getOutstandingAmt() {
        return outstandingAmt;
    }

    public void setOutstandingAmt(BigDecimal outstandingAmt) {
        this.outstandingAmt = outstandingAmt;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getMaturityDateS() {
        if(getMaturityDate() != null){
            return DateUtil.getDateInThaiFormat(getMaturityDate());
        }
        return "";
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getDueDateS() {
        if(getDueDate() != null){
            return DateUtil.getDateInThaiFormat(getDueDate());
        }
        return "";
    }

    public String getDpd() {
        return dpd;
    }

    public void setDpd(String dpd) {
        this.dpd = dpd;
    }

    public Date getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(Date warningDate) {
        this.warningDate = warningDate;
    }

    public String getWarningDateS() {
        if(getWarningDate() != null){
            return DateUtil.getDateInThaiFormat(getWarningDate());
        }
        return "";
    }

    public String getLimitAmtS() {
        if(getBillNo() != null && getBillNo().trim().length() > 0){
            if(getLimitAmt() != null){
                return StringUtil.formatCurrentcy(getLimitAmt());
            }
        }else{
            if(getMainLimitAmt() != null){
                return StringUtil.formatCurrentcy(getMainLimitAmt());
            }
        }
        
        return "-";
    }
    
    public String getMainLimitAmtS() {
        if(getMainLimitAmt() != null){
            return StringUtil.formatCurrentcy(getMainLimitAmt());
        }
        
        return "-";
    }

    public String getOutstandingAmtS() {
        if(getBillNo() != null && getBillNo().trim().length() > 0){
            if(getOutstandingAmt() != null){
                return StringUtil.formatCurrentcy(getOutstandingAmt());
            }
        }else{
            if(getMainOutstandingAmt() != null){
                return StringUtil.formatCurrentcy(getMainOutstandingAmt());
            }
        }
        
        return "-";
    }
    
    public String getMainOutstandingAmtS() {
        if(getMainOutstandingAmt() != null){
            return StringUtil.formatCurrentcy(getMainOutstandingAmt());
        }
        
        return "-";
    }

    public BigDecimal getDueAmt() {
        return dueAmt;
    }

    public void setDueAmt(BigDecimal dueAmt) {
        this.dueAmt = dueAmt;
    }

    public String getDueAmtS() {
        if(getDueAmt() != null){
            return StringUtil.formatCurrentcy(getDueAmt());
        }
        return "-";
    }

    public BigDecimal getUnpaidAmt() {
        return unpaidAmt;
    }

    public void setUnpaidAmt(BigDecimal unpaidAmt) {
        this.unpaidAmt = unpaidAmt;
    }

    public String getUnpaidAmtS() {
        if(getUnpaidAmt() != null){
            return StringUtil.formatCurrentcy(getUnpaidAmt());
        }
        return "-";
    }

    public Date getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Date expiryDt) {
        this.expiryDt = expiryDt;
    }

    public String getExpiryDtS() {
        if(getExpiryDt() != null){
            return DateUtil.getDateInThaiFormat(getExpiryDt());
        }
        return "";
    }

    public Date getNextExpiryDt() {
        return nextExpiryDt;
    }

    public void setNextExpiryDt(Date nextExpiryDt) {
        this.nextExpiryDt = nextExpiryDt;
    }

    public String getNextExpiryDtS() {
        if(getNextExpiryDt() != null){
            return DateUtil.getDateInThaiFormat(getNextExpiryDt());
        }
        return "";
    }

    public Date getCreatedDtm() {
        return createdDtm;
    }

    public void setCreatedDtm(Date createdDtm) {
        this.createdDtm = createdDtm;
    }

    public String getCreatedDtmS() {
        if(getCreatedDtm() != null){
            return DateUtil.getDateInThaiFormat(getCreatedDtm());
        }
        return "";
    }

    public Date getApproveDtm() {
        return approveDtm;
    }

    public void setApproveDtm(Date approveDtm) {
        this.approveDtm = approveDtm;
    }

    public String getApproveDtmS() {
        if(getApproveDtm() != null){
            return DateUtil.getDateInThaiFormat(getApproveDtm());
        }
        return "";
    }

    public String getApproveBy() {
        return approveBy;
    }

    public void setApproveBy(String approveBy) {
        this.approveBy = approveBy;
    }

    public String getProdGrp() {
        return prodGrp;
    }

    public void setProdGrp(String prodGrp) {
        this.prodGrp = prodGrp;
    }

    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    public String getAcctSubType() {
        return acctSubType;
    }

    public void setAcctSubType(String acctSubType) {
        this.acctSubType = acctSubType;
    }

    public String getEditorRole() {
        return editorRole;
    }

    public void setEditorRole(String editorRole) {
        this.editorRole = editorRole;
    }

    public String getApproveRole() {
        return approveRole;
    }

    public void setApproveRole(String approveRole) {
        this.approveRole = approveRole;
    }

    public String getAcctclassName() {
        return acctclassName;
    }

    public void setAcctclassName(String acctclassName) {
        this.acctclassName = acctclassName;
    }

    public BigDecimal getMainLimitAmt() {
        return mainLimitAmt;
    }

    public void setMainLimitAmt(BigDecimal mainLimitAmt) {
        this.mainLimitAmt = mainLimitAmt;
    }

    public BigDecimal getMainOutstandingAmt() {
        return mainOutstandingAmt;
    }

    public void setMainOutstandingAmt(BigDecimal mainOutstandingAmt) {
        this.mainOutstandingAmt = mainOutstandingAmt;
    }

    public String getLastDpd() {
        return lastDpd;
    }

    public void setLastDpd(String lastDpd) {
        this.lastDpd = lastDpd;
    } 

    public BigDecimal getUnpaidInterest() {
        return unpaidInterest;
    }

    public void setUnpaidInterest(BigDecimal unpaidInterest) {
        this.unpaidInterest = unpaidInterest;
    }

    public BigDecimal getUnpaidPrincipal() {
        return unpaidPrincipal;
    }

    public void setUnpaidPrincipal(BigDecimal unpaidPrincipal) {
        this.unpaidPrincipal = unpaidPrincipal;
    }

    public BigDecimal getLateCharge() {
        return lateCharge;
    }

    public void setLateCharge(BigDecimal lateCharge) {
        this.lateCharge = lateCharge;
    }
    
    public String getUnpaidPrincipalStr() {
        if( getUnpaidPrincipal()!= null ){
            return StringUtil.formatCurrentcy( getUnpaidPrincipal() );
        }
        return "-";
    }
    
    public String getLateChargeStr() {
        if( getLateCharge()!= null ){
            return StringUtil.formatCurrentcy( getLateCharge() );
        }
        return "-";
    }
    
    public String getUnpaidInterestStr() {
        if( getUnpaidInterest()!= null ){
            return StringUtil.formatCurrentcy( getUnpaidInterest() );
        }
        return "-";
    }

    public String getLoanGrpProd() {
        return loanGrpProd;
    }

    public void setLoanGrpProd(String loanGrpProd) {
        this.loanGrpProd = loanGrpProd;
    }

    public Date getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(Date paidDate) {
        this.paidDate = paidDate;
    }
     public String getPaidDateStr() {
        if(getPaidDate() != null){
            return DateUtil.getDateInThaiFormat(getPaidDate());
        }
        return "";
    }
    
    
}
