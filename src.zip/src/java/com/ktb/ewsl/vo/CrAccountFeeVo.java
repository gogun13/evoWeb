/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Tum_Surapong
 */
public class CrAccountFeeVo implements Serializable{
    private Integer warningHeaderId;
    private String acctNo;
    private String mainAcctNo;
    private String feeType;
    private String feeTypeDesc;
    private BigDecimal remFeeAmt;
    private BigDecimal feeAssess;
    private BigDecimal feePaid;
    private BigDecimal feeRate;
    private BigDecimal feeMinAmount;
    private BigDecimal feeMaxAmount;
    private String feeTermType;
    private String createdBy;
    private Date createdDtm;

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getMainAcctNo() {
        return mainAcctNo;
    }

    public void setMainAcctNo(String mainAcctNo) {
        this.mainAcctNo = mainAcctNo;
    }

    public String getFeeType() {
        return feeType;
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType;
    }

    public String getFeeTypeDesc() {
        return feeTypeDesc;
    }

    public void setFeeTypeDesc(String feeTypeDesc) {
        this.feeTypeDesc = feeTypeDesc;
    }

    public BigDecimal getRemFeeAmt() {
        return remFeeAmt;
    }

    public void setRemFeeAmt(BigDecimal remFeeAmt) {
        this.remFeeAmt = remFeeAmt;
    }

    public BigDecimal getFeeAssess() {
        return feeAssess;
    }

    public void setFeeAssess(BigDecimal feeAssess) {
        this.feeAssess = feeAssess;
    }

    public BigDecimal getFeePaid() {
        return feePaid;
    }

    public void setFeePaid(BigDecimal feePaid) {
        this.feePaid = feePaid;
    }

    public BigDecimal getFeeRate() {
        return feeRate;
    }

    public void setFeeRate(BigDecimal feeRate) {
        this.feeRate = feeRate;
    }

    public BigDecimal getFeeMinAmount() {
        return feeMinAmount;
    }

    public void setFeeMinAmount(BigDecimal feeMinAmount) {
        this.feeMinAmount = feeMinAmount;
    }

    public BigDecimal getFeeMaxAmount() {
        return feeMaxAmount;
    }

    public void setFeeMaxAmount(BigDecimal feeMaxAmount) {
        this.feeMaxAmount = feeMaxAmount;
    }

    public String getFeeTermType() {
        return feeTermType;
    }

    public void setFeeTermType(String feeTermType) {
        this.feeTermType = feeTermType;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDtm() {
        return createdDtm;
    }

    public void setCreatedDtm(Date createdDtm) {
        this.createdDtm = createdDtm;
    }
    
}
