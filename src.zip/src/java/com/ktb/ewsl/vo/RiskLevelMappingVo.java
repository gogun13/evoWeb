/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author KTBDevLoan
 */
public class RiskLevelMappingVo {
    
    private Integer orderSeq;
    private String riskLevel;
    private String riskLevelDesc;
    private String riskLevelHistoryDisp;
    private String riskLevelIndRptDisp;
    private String riskLevelPiplelineDisp;
    private String riskLevelRenewalDisp;

    public Integer getOrderSeq() {
        return orderSeq;
    }

    public void setOrderSeq(Integer orderSeq) {
        this.orderSeq = orderSeq;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public String getRiskLevelDesc() {
        return riskLevelDesc;
    }

    public void setRiskLevelDesc(String riskLevelDesc) {
        this.riskLevelDesc = riskLevelDesc;
    }

    public String getRiskLevelHistoryDisp() {
        return riskLevelHistoryDisp;
    }

    public void setRiskLevelHistoryDisp(String riskLevelHistoryDisp) {
        this.riskLevelHistoryDisp = riskLevelHistoryDisp;
    }

    public String getRiskLevelIndRptDisp() {
        return riskLevelIndRptDisp;
    }

    public void setRiskLevelIndRptDisp(String riskLevelIndRptDisp) {
        this.riskLevelIndRptDisp = riskLevelIndRptDisp;
    }

    public String getRiskLevelPiplelineDisp() {
        return riskLevelPiplelineDisp;
    }

    public void setRiskLevelPiplelineDisp(String riskLevelPiplelineDisp) {
        this.riskLevelPiplelineDisp = riskLevelPiplelineDisp;
    }

    public String getRiskLevelRenewalDisp() {
        return riskLevelRenewalDisp;
    }

    public void setRiskLevelRenewalDisp(String riskLevelRenewalDisp) {
        this.riskLevelRenewalDisp = riskLevelRenewalDisp;
    }

        
}
