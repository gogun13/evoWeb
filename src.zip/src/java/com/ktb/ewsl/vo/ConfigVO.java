/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class ConfigVO {
    
    private String configCode;
    private String configGroupCode;
    private String configValue;
    private String createdBy;
    private Date crestedDt;
    private String updatedBy;
    private Date updatedDt;
    private String remark;
    private Integer seq;

    public String getConfigCode() {
        return configCode;
    }

    public void setConfigCode(String configCode) {
        this.configCode = configCode;
    }

    public String getConfigGroupCode() {
        return configGroupCode;
    }

    public void setConfigGroupCode(String configGroupCode) {
        this.configGroupCode = configGroupCode;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCrestedDt() {
        return crestedDt;
    }

    public void setCrestedDt(Date crestedDt) {
        this.crestedDt = crestedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }
  
    

}
