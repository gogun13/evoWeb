/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author pumin
 */
public class TaskListExportVo {
    String warningDate;
    String cif;
    String custName;
    String rmId;
    int hasRmId = 0;
    String aeId;
    int hasAeId= 0;
    String aoId;
    int hasAoId= 0;
    String respUint;
    int hasRespUnit= 0;
    String coRmId;
    int hasCoRmId = 0;
    String coAeId;
    int hasCoAeId= 0;
    String coRespUnit;
    int hasCoRespUnit= 0;
    String ewsRisk;
    String cFinal;
    String moniDpd;
    int hasMoniDpd= 0;
    String moniAcct;
    int hasMoniAcct= 0;
    String moniUnpaidAmt;
    int hasMoniUnpaidAmt= 0;
    String spAcct;
    String odOverLimit;
    int hasOdOverLimit= 0;
    String odAcct;
    int hasOdAcct= 0;
    String odOverBalance;
    int hasOdBalance= 0;
    String latePayForm;
    int hasLatePayForm= 0;
//    String wayOutForm;
//    int hasWayOutForm= 0;
//    String actionForm;
//    int hasActionForm= 0;
    String action1Form;
    int hasAction1Form= 0;
    String action2Form;
    int hasAction2Form= 0;
    String quali;
    int hasQuali= 0;
    String creditRating;
    int hasCreditRating= 0;
    String fin;
    int hasFin= 0;
    String creditReview;
    int hasCreditReview= 0;
    String maturityDate;
    int hasMaturityDate= 0;
    String taAcct;
    int hasTaAcct= 0;
    String taWaringDate;
    int hasTaWarningDate= 0;
    String businessSize;
    //----- CR-L R3 ---------//
    String cr;
    String crrm;
    String typesFlg;
    String reviewDateStr;
    String nextRatingDateStr;
    int crAmount = 0;
    int crrmAmount = 0;

    public String getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(String warningDate) {
        this.warningDate = warningDate;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public int getHasRmId() {
        return hasRmId;
    }

    public void setHasRmId(int hasRmId) {
        this.hasRmId = hasRmId;
    }

    public String getAeId() {
        return aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public int getHasAeId() {
        return hasAeId;
    }

    public void setHasAeId(int hasAeId) {
        this.hasAeId = hasAeId;
    }

    public String getAoId() {
        return aoId;
    }

    public void setAoId(String aoId) {
        this.aoId = aoId;
    }

    public int getHasAoId() {
        return hasAoId;
    }

    public void setHasAoId(int hasAoId) {
        this.hasAoId = hasAoId;
    }

    public String getRespUnit() {
        return respUint;
    }

    public void setRespUnit(String respUint) {
        this.respUint = respUint;
    }

    public int getHasRespUnit() {
        return hasRespUnit;
    }

    public void setHasRespUnit(int hasRespUnit) {
        this.hasRespUnit = hasRespUnit;
    }

    public String getEwsRisk() {
        return ewsRisk;
    }

    public void setEwsRisk(String ewsRisk) {
        this.ewsRisk = ewsRisk;
    }

    public String getcFinal() {
        return cFinal;
    }

    public void setcFinal(String cFinal) {
        this.cFinal = cFinal;
    }

    public String getMoniDpd() {
        return moniDpd;
    }

    public void setMoniDpd(String moniDpd) {
        this.moniDpd = moniDpd;
    }

    public int getHasMoniDpd() {
        return hasMoniDpd;
    }

    public void setHasMoniDpd(int hasMoniDpd) {
        this.hasMoniDpd = hasMoniDpd;
    }

    public String getMoniAcct() {
        return moniAcct;
    }

    public void setMoniAcct(String moniAcct) {
        this.moniAcct = moniAcct;
    }

    public int getHasMoniAcct() {
        return hasMoniAcct;
    }

    public void setHasMoniAcct(int hasMoniAcct) {
        this.hasMoniAcct = hasMoniAcct;
    }

    public String getMoniUnpaidAmt() {
        return moniUnpaidAmt;
    }

    public void setMoniUnpaidAmt(String moniUnpaidAmt) {
        this.moniUnpaidAmt = moniUnpaidAmt;
    }

    public int getHasMoniUnpaidAmt() {
        return hasMoniUnpaidAmt;
    }

    public void setHasMoniUnpaidAmt(int hasMoniUnpaidAmt) {
        this.hasMoniUnpaidAmt = hasMoniUnpaidAmt;
    }

    public String getSpAcct() {
        return spAcct;
    }

    public void setSpAcct(String spAcct) {
        this.spAcct = spAcct;
    }

    public String getOdOverLimit() {
        return odOverLimit;
    }

    public void setOdOverLimit(String odOverLimit) {
        this.odOverLimit = odOverLimit;
    }

    public int getHasOdOverLimit() {
        return hasOdOverLimit;
    }

    public void setHasOdOverLimit(int hasOdOverLimit) {
        this.hasOdOverLimit = hasOdOverLimit;
    }

    public String getOdAcct() {
        return odAcct;
    }

    public void setOdAcct(String odAcct) {
        this.odAcct = odAcct;
    }

    public int getHasOdAcct() {
        return hasOdAcct;
    }

    public void setHasOdAcct(int hasOdAcct) {
        this.hasOdAcct = hasOdAcct;
    }

    public String getOdOverBalance() {
        return odOverBalance;
    }

    public void setOdOverBalance(String odOverBalance) {
        this.odOverBalance = odOverBalance;
    }

    public int getHasOdBalance() {
        return hasOdBalance;
    }

    public void setHasOdBalance(int hasOdBalance) {
        this.hasOdBalance = hasOdBalance;
    }

    public String getLatePayForm() {
        return latePayForm;
    }

    public void setLatePayForm(String latePayForm) {
        this.latePayForm = latePayForm;
    }

    public int getHasLatePayForm() {
        return hasLatePayForm;
    }

    public void setHasLatePayForm(int hasLatePayForm) {
        this.hasLatePayForm = hasLatePayForm;
    }

    public String getAction1Form() {
        return action1Form;
    }

    public void setAction1Form(String action1Form) {
        this.action1Form = action1Form;
    }

    public int getHasAction1Form() {
        return hasAction1Form;
    }

    public void setHasAction1Form(int hasAction1Form) {
        this.hasAction1Form = hasAction1Form;
    }

    public String getAction2Form() {
        return action2Form;
    }

    public void setAction2Form(String action2Form) {
        this.action2Form = action2Form;
    }

    public int getHasAction2Form() {
        return hasAction2Form;
    }

    public void setHasAction2Form(int hasAction2Form) {
        this.hasAction2Form = hasAction2Form;
    }

    public String getQuali() {
        return quali;
    }

    public void setQuali(String quali) {
        this.quali = quali;
    }

    public int getHasQuali() {
        return hasQuali;
    }

    public void setHasQuali(int hasQuali) {
        this.hasQuali = hasQuali;
    }

    public String getCreditRating() {
        return creditRating;
    }

    public void setCreditRating(String creditRating) {
        this.creditRating = creditRating;
    }

    public int getHasCreditRating() {
        return hasCreditRating;
    }

    public void setHasCreditRating(int hasCreditRating) {
        this.hasCreditRating = hasCreditRating;
    }

    public String getFin() {
        return fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }

    public int getHasFin() {
        return hasFin;
    }

    public void setHasFin(int hasFin) {
        this.hasFin = hasFin;
    }

    public String getCreditReview() {
        return creditReview;
    }

    public void setCreditReview(String creditReview) {
        this.creditReview = creditReview;
    }

    public int getHasCreditReview() {
        return hasCreditReview;
    }

    public void setHasCreditReview(int hasCreditReview) {
        this.hasCreditReview = hasCreditReview;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public int getHasMaturityDate() {
        return hasMaturityDate;
    }

    public void setHasMaturityDate(int hasMaturityDate) {
        this.hasMaturityDate = hasMaturityDate;
    }

    public String getTaAcct() {
        return taAcct;
    }

    public void setTaAcct(String taAcct) {
        this.taAcct = taAcct;
    }

    public int getHasTaAcct() {
        return hasTaAcct;
    }

    public void setHasTaAcct(int hasTaAcct) {
        this.hasTaAcct = hasTaAcct;
    }

    public String getTaWaringDate() {
        return taWaringDate;
    }

    public void setTaWaringDate(String taWaringDate) {
        this.taWaringDate = taWaringDate;
    }

    public int getHasTaWarningDate() {
        return hasTaWarningDate;
    }

    public void setHasTaWarningDate(int hasTaWarningDate) {
        this.hasTaWarningDate = hasTaWarningDate;
    }

    public String getBusinessSize() {
        return businessSize;
    }

    public void setBusinessSize(String businessSize) {
        this.businessSize = businessSize;
    }

    public String getRespUint() {
        return respUint;
    }

    public void setRespUint(String respUint) {
        this.respUint = respUint;
    }

    public String getCoRmId() {
        return coRmId;
    }

    public void setCoRmId(String coRmId) {
        this.coRmId = coRmId;
    }

    public int getHasCoRmId() {
        return hasCoRmId;
    }

    public void setHasCoRmId(int hasCoRmId) {
        this.hasCoRmId = hasCoRmId;
    }

    public String getCoAeId() {
        return coAeId;
    }

    public void setCoAeId(String coAeId) {
        this.coAeId = coAeId;
    }

    public int getHasCoAeId() {
        return hasCoAeId;
    }

    public void setHasCoAeId(int hasCoAeId) {
        this.hasCoAeId = hasCoAeId;
    }

    public String getCoRespUnit() {
        return coRespUnit;
    }

    public void setCoRespUnit(String coRespUnit) {
        this.coRespUnit = coRespUnit;
    }
    
    public int getHasCoRespUnit() {
        return hasCoRespUnit;
    }

    public void setHasCoRespUnit(int hasCoRespUnit) {
        this.hasCoRespUnit = hasCoRespUnit;
    }

    public String getCr() {
        return cr;
    }

    public void setCr(String cr) {
        this.cr = cr;
    }

    public String getCrrm() {
        return crrm;
    }

    public void setCrrm(String crrm) {
        this.crrm = crrm;
    }

    public String getTypesFlg() {
        return typesFlg;
    }

    public void setTypesFlg(String typesFlg) {
        this.typesFlg = typesFlg;
    }

    public String getReviewDateStr() {
        return reviewDateStr;
    }

    public void setReviewDateStr(String reviewDateStr) {
        this.reviewDateStr = reviewDateStr;
    }

    public String getNextRatingDateStr() {
        return nextRatingDateStr;
    }

    public void setNextRatingDateStr(String nextRatingDateStr) {
        this.nextRatingDateStr = nextRatingDateStr;
    }

    public int getCrAmount() {
        return crAmount;
    }

    public void setCrAmount(int crAmount) {
        this.crAmount = crAmount;
    }

    public int getCrrmAmount() {
        return crrmAmount;
    }

    public void setCrrmAmount(int crrmAmount) {
        this.crrmAmount = crrmAmount;
    }

}
