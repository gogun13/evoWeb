/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class InOutLogVo extends BaseVo{
    private String depCode;
    private String depName;
    private String loginStatus;
    private String loginStatusDesc;
    private String logoutStatus;
    private String logoutStatusDesc;
    private Date loginDate;
    private Date logoutDate;
    private String posCode;
    private String posName;
    private String serverIP;
    private String sessionId;
    private String userId;
    private String userIP;
    private String userName;

    public String getDepCode() {
        return depCode;
    }

    public void setDepCode(String depCode) {
        this.depCode = depCode;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public String getLoginStatus() {
        return loginStatus;
    }

    public void setLoginStatus(String loginStatus) {
        this.loginStatus = loginStatus;
    }

    public String getLoginStatusDesc() {
        return loginStatusDesc;
    }

    public void setLoginStatusDesc(String loginStatusDesc) {
        this.loginStatusDesc = loginStatusDesc;
    }

    public String getLogoutStatus() {
        return logoutStatus;
    }

    public void setLogoutStatus(String logoutStatus) {
        this.logoutStatus = logoutStatus;
    }

    public String getLogoutStatusDesc() {
        return logoutStatusDesc;
    }

    public void setLogoutStatusDesc(String logoutStatusDesc) {
        this.logoutStatusDesc = logoutStatusDesc;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Date loginDate) {
        this.loginDate = loginDate;
    }

    public Date getLogoutDate() {
        return logoutDate;
    }

    public void setLogoutDate(Date logoutDate) {
        this.logoutDate = logoutDate;
    }

    public String getPosCode() {
        return posCode;
    }

    public void setPosCode(String posCode) {
        this.posCode = posCode;
    }

    public String getPosName() {
        return posName;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public String getServerIP() {
        return serverIP;
    }

    public void setServerIP(String serverIP) {
        this.serverIP = serverIP;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserIP() {
        return userIP;
    }

    public void setUserIP(String userIP) {
        this.userIP = userIP;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    
}
