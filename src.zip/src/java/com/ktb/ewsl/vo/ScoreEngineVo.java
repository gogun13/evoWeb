/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import org.json.simple.JSONArray;

/**
 *
 * @author Siriwat Asamo
 */
public class ScoreEngineVo extends BaseVo{
    
    private String questionId;
    private String version;
    private String custName;
    private String respUnitId;
    private String appId;
    private String custId;    
    private String limitSize;
    private String size;
    private String stateType;
    private String cogsSales;
    private String dsceCfo;       
    private String de;
    private String interestRatio;
    private String operationRote;
    private String slopeProfitMargin;        
    private String quickRatio;             
    private String borrowType;
    private String hvQCA;
    private BigDecimal qcaPD;
    private String hvNCB;
    private String ncbType;
    private BigDecimal ncbPDInd;
    private BigDecimal ncbPDIndEWS;
    private BigDecimal ncbPD;
    private BigDecimal ncbPDbackup;
    private BigDecimal ncbPDEWS;  
    private String hvFin;
    private BigDecimal finPD;
    private String hvQuanti;
    private BigDecimal quantiBhvPD;
    private String dpd;
    private String bucketDPD;
    private String finalRiskLevel;
    private String formAssign;
    private String questionGrp;
    private String bucketRenewal;
    private String renewal;
    private JSONArray topicObj;
    private JSONArray topicObjectTrigger;
    private JSONArray topicObjectPayment;
    private ArrayList<WarningInfoVo> warningInfoVoList;
    private JSONArray  topicObjectLatePayment;
    //---- OD
    private String hvDelinqDate;
    private Date delinqDate;
    private String delinqDateStr;
    private BigDecimal dpdOdBigdecimal;
    private String bucketDpdOd;
    private Integer dpdOd;
    
    private String hvRating;
    private BigDecimal finODDS;
    private BigDecimal ncbODDSEWS;
    private BigDecimal ncbODDSEWSOnline;
    private BigDecimal ncbODDSIndEWS;
    private BigDecimal ncbODDSIndEWSBackup;
    private BigDecimal ncbODDSIndEWSBackupOnline;
    private BigDecimal ncbODDSIndEWSOnline;
    private BigDecimal quantiBhvODDS;
    private BigDecimal ratingODDS;
    private String ncbLastUpdate;
    //----------- CR-L R3
    private String cClass;
    private String authorizeReviewDate;
    private String minReviewDate;
    private String pauseFlag;
    private String modelID;
    private String authorizeRatingDate;
    private String nextRatingDate;
    private String ratingMTH;
    private String bucketRating;
    
    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getRespUnitId() {
        return respUnitId;
    }

    public void setRespUnitId(String respUnitId) {
        this.respUnitId = respUnitId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getLimitSize() {
        return limitSize;
    }

    public void setLimitSize(String limitSize) {
        this.limitSize = limitSize;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getStateType() {
        return stateType;
    }

    public void setStateType(String stateType) {
        this.stateType = stateType;
    }

    public String getCogsSales() {
        return cogsSales;
    }

    public void setCogsSales(String cogsSales) {
        this.cogsSales = cogsSales;
    }


    public String getDe() {
        return de;
    }

    public void setDe(String de) {
        this.de = de;
    }

    public String getInterestRatio() {
        return interestRatio;
    }

    public void setInterestRatio(String interestRatio) {
        this.interestRatio = interestRatio;
    }

    public String getSlopeProfitMargin() {
        return slopeProfitMargin;
    }

    public void setSlopeProfitMargin(String slopeProfitMargin) {
        this.slopeProfitMargin = slopeProfitMargin;
    }

    public String getBorrowType() {
        return borrowType;
    }

    public void setBorrowType(String borrowType) {
        this.borrowType = borrowType;
    }

    public String getHvQCA() {
        return hvQCA;
    }

    public void setHvQCA(String hvQCA) {
        this.hvQCA = hvQCA;
    }

    public BigDecimal getQcaPD() {
        return qcaPD;
    }

    public void setQcaPD(BigDecimal qcaPD) {
        this.qcaPD = qcaPD;
    }

    public String getHvNCB() {
        return hvNCB;
    }

    public void setHvNCB(String hvNCB) {
        this.hvNCB = hvNCB;
    }

    public String getNcbType() {
        return ncbType;
    }

    public void setNcbType(String ncbType) {
        this.ncbType = ncbType;
    }

    public BigDecimal getNcbPDInd() {
        return ncbPDInd;
    }

    public void setNcbPDInd(BigDecimal ncbPDInd) {
        this.ncbPDInd = ncbPDInd;
    }

    public BigDecimal getNcbPDIndEWS() {
        return ncbPDIndEWS;
    }

    public void setNcbPDIndEWS(BigDecimal ncbPDIndEWS) {
        this.ncbPDIndEWS = ncbPDIndEWS;
    }

    public BigDecimal getNcbPD() {
        return ncbPD;
    }

    public void setNcbPD(BigDecimal ncbPD) {
        this.ncbPD = ncbPD;
    }

    public BigDecimal getNcbPDbackup() {
        return ncbPDbackup;
    }

    public void setNcbPDbackup(BigDecimal ncbPDbackup) {
        this.ncbPDbackup = ncbPDbackup;
    }

    public BigDecimal getNcbPDEWS() {
        return ncbPDEWS;
    }

    public void setNcbPDEWS(BigDecimal ncbPDEWS) {
        this.ncbPDEWS = ncbPDEWS;
    }

    public String getHvFin() {
        return hvFin;
    }

    public void setHvFin(String hvFin) {
        this.hvFin = hvFin;
    }

    public BigDecimal getFinPD() {
        return finPD;
    }

    public void setFinPD(BigDecimal finPD) {
        this.finPD = finPD;
    }

    public String getHvQuanti() {
        return hvQuanti;
    }

    public void setHvQuanti(String hvQuanti) {
        this.hvQuanti = hvQuanti;
    }

    public BigDecimal getQuantiBhvPD() {
        return quantiBhvPD;
    }

    public void setQuantiBhvPD(BigDecimal quantiBhvPD) {
        this.quantiBhvPD = quantiBhvPD;
    }

    public String getDpd() {
        return dpd;
    }

    public void setDpd(String dpd) {
        this.dpd = dpd;
    }

    public String getBucketDPD() {
        return bucketDPD;
    }

    public void setBucketDPD(String bucketDPD) {
        this.bucketDPD = bucketDPD;
    }

    public JSONArray getTopicObj() {
        return topicObj;
    }

    public void setTopicObj(JSONArray topicObj) {
        this.topicObj = topicObj;
    }    

    public String getFinalRiskLevel() {
        return finalRiskLevel;
    }

    public void setFinalRiskLevel(String finalRiskLevel) {
        this.finalRiskLevel = finalRiskLevel;
    }

    public String getFormAssign() {
        return formAssign;
    }

    public void setFormAssign(String formAssign) {
        this.formAssign = formAssign;
    }

    public String getQuestionGrp() {
        return questionGrp;
    }

    public void setQuestionGrp(String questionGrp) {
        this.questionGrp = questionGrp;
    }

    public String getBucketRenewal() {
        return bucketRenewal;
    }

    public void setBucketRenewal(String bucketRenewal) {
        this.bucketRenewal = bucketRenewal;
    }

    public String getRenewal() {
        return renewal;
    }

    public void setRenewal(String renewal) {
        this.renewal = renewal;
    }

    public JSONArray getTopicObjectTrigger() {
        return topicObjectTrigger;
    }

    public void setTopicObjectTrigger(JSONArray topicObjectTrigger) {
        this.topicObjectTrigger = topicObjectTrigger;
    }

    public JSONArray getTopicObjectPayment() {
        return topicObjectPayment;
    }

    public void setTopicObjectPayment(JSONArray topicObjectPayment) {
        this.topicObjectPayment = topicObjectPayment;
    }

    public ArrayList<WarningInfoVo> getWarningInfoVoList() {
        return warningInfoVoList;
    }

    public void setWarningInfoVoList(ArrayList<WarningInfoVo> warningInfoVoList) {
        this.warningInfoVoList = warningInfoVoList;
    }



    public String getDsceCfo() {
        return dsceCfo;
    }

    public void setDsceCfo(String dsceCfo) {
        this.dsceCfo = dsceCfo;
    }

    public String getOperationRote() {
        return operationRote;
    }

    public void setOperationRote(String operationRote) {
        this.operationRote = operationRote;
    }

    public String getQuickRatio() {
        return quickRatio;
    }

    public void setQuickRatio(String quickRatio) {
        this.quickRatio = quickRatio;
    }

    public JSONArray getTopicObjectLatePayment() {
        return topicObjectLatePayment;
    }

    public void setTopicObjectLatePayment(JSONArray topicObjectLatePayment) {
        this.topicObjectLatePayment = topicObjectLatePayment;
    }

    public String getHvDelinqDate() {
        return hvDelinqDate;
    }

    public void setHvDelinqDate(String hvDelinqDate) {
        this.hvDelinqDate = hvDelinqDate;
    }

    public Date getDelinqDate() {
        return delinqDate;
    }

    public void setDelinqDate(Date delinqDate) {
        this.delinqDate = delinqDate;
    }

    public String getDelinqDateStr() {
        return delinqDateStr;
    }

    public void setDelinqDateStr(String delinqDateStr) {
        this.delinqDateStr = delinqDateStr;
    }

    public BigDecimal getDpdOdBigdecimal() {
        return dpdOdBigdecimal;
    }

    public void setDpdOdBigdecimal(BigDecimal dpdOdBigdecimal) {
        this.dpdOdBigdecimal = dpdOdBigdecimal;
    }

    public String getBucketDpdOd() {
        return bucketDpdOd;
    }

    public void setBucketDpdOd(String bucketDpdOd) {
        this.bucketDpdOd = bucketDpdOd;
    }

    public Integer getDpdOd() {
        return dpdOd;
    }

    public void setDpdOd(Integer dpdOd) {
        this.dpdOd = dpdOd;
    }

    public String getHvRating() {
        return hvRating;
    }

    public void setHvRating(String hvRating) {
        this.hvRating = hvRating;
    }

    public BigDecimal getFinODDS() {
        return finODDS;
    }

    public void setFinODDS(BigDecimal finODDS) {
        this.finODDS = finODDS;
    }

    public BigDecimal getNcbODDSEWS() {
        return ncbODDSEWS;
    }

    public void setNcbODDSEWS(BigDecimal ncbODDSEWS) {
        this.ncbODDSEWS = ncbODDSEWS;
    }

    public BigDecimal getNcbODDSEWSOnline() {
        return ncbODDSEWSOnline;
    }

    public void setNcbODDSEWSOnline(BigDecimal ncbODDSEWSOnline) {
        this.ncbODDSEWSOnline = ncbODDSEWSOnline;
    }

    public BigDecimal getNcbODDSIndEWS() {
        return ncbODDSIndEWS;
    }

    public void setNcbODDSIndEWS(BigDecimal ncbODDSIndEWS) {
        this.ncbODDSIndEWS = ncbODDSIndEWS;
    }

    public BigDecimal getNcbODDSIndEWSBackup() {
        return ncbODDSIndEWSBackup;
    }

    public void setNcbODDSIndEWSBackup(BigDecimal ncbODDSIndEWSBackup) {
        this.ncbODDSIndEWSBackup = ncbODDSIndEWSBackup;
    }

    public BigDecimal getNcbODDSIndEWSBackupOnline() {
        return ncbODDSIndEWSBackupOnline;
    }

    public void setNcbODDSIndEWSBackupOnline(BigDecimal ncbODDSIndEWSBackupOnline) {
        this.ncbODDSIndEWSBackupOnline = ncbODDSIndEWSBackupOnline;
    }

    public BigDecimal getNcbODDSIndEWSOnline() {
        return ncbODDSIndEWSOnline;
    }

    public void setNcbODDSIndEWSOnline(BigDecimal ncbODDSIndEWSOnline) {
        this.ncbODDSIndEWSOnline = ncbODDSIndEWSOnline;
    }

    public BigDecimal getQuantiBhvODDS() {
        return quantiBhvODDS;
    }

    public void setQuantiBhvODDS(BigDecimal quantiBhvODDS) {
        this.quantiBhvODDS = quantiBhvODDS;
    }

    public BigDecimal getRatingODDS() {
        return ratingODDS;
    }

    public void setRatingODDS(BigDecimal ratingODDS) {
        this.ratingODDS = ratingODDS;
    }

    public String getNcbLastUpdate() {
        return ncbLastUpdate;
    }

    public void setNcbLastUpdate(String ncbLastUpdate) {
        this.ncbLastUpdate = ncbLastUpdate;
    }

    public String getcClass() {
        return cClass;
    }

    public void setcClass(String cClass) {
        this.cClass = cClass;
    }

    public String getAuthorizeReviewDate() {
        return authorizeReviewDate;
    }

    public void setAuthorizeReviewDate(String authorizeReviewDate) {
        this.authorizeReviewDate = authorizeReviewDate;
    }

    public String getMinReviewDate() {
        return minReviewDate;
    }

    public void setMinReviewDate(String minReviewDate) {
        this.minReviewDate = minReviewDate;
    }

    public String getPauseFlag() {
        return pauseFlag;
    }

    public void setPauseFlag(String pauseFlag) {
        this.pauseFlag = pauseFlag;
    }

    public String getModelID() {
        return modelID;
    }

    public void setModelID(String modelID) {
        this.modelID = modelID;
    }

    public String getAuthorizeRatingDate() {
        return authorizeRatingDate;
    }

    public void setAuthorizeRatingDate(String authorizeRatingDate) {
        this.authorizeRatingDate = authorizeRatingDate;
    }

    public String getNextRatingDate() {
        return nextRatingDate;
    }

    public void setNextRatingDate(String nextRatingDate) {
        this.nextRatingDate = nextRatingDate;
    }

    public String getRatingMTH() {
        return ratingMTH;
    }

    public void setRatingMTH(String ratingMTH) {
        this.ratingMTH = ratingMTH;
    }

    public String getBucketRating() {
        return bucketRating;
    }

    public void setBucketRating(String bucketRating) {
        this.bucketRating = bucketRating;
    }
    
    
}
