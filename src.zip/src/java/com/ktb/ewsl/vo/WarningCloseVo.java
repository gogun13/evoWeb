/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.Date;

/**
 *
 * @author pumin
 */
public class WarningCloseVo {

    private String createdBy;
    private Date createdDt;
    private String reasonFlg;
    private String remark;
    private String status;
    private String warningHeadId;
    private String createdDtThai;
    private String reasonDetail;
    private String closeRemark;
    private String roleCode;

    public String getCreatedDtThai() {
        return createdDtThai;
    }

    public void setCreatedDtThai(String createdDtThai) {
        this.createdDtThai = createdDtThai;
    }

    public String getReasonDetail() {
        return reasonDetail;
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public String getCloseRemark() {
        return closeRemark;
    }

    public void setCloseRemark(String closeRemark) {
        this.closeRemark = closeRemark;
    }
    

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public String getReasonFlg() {
        return reasonFlg;
    }

    public void setReasonFlg(String reasonFlg) {
        this.reasonFlg = reasonFlg;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWarningHeadId() {
        return warningHeadId;
    }

    public void setWarningHeadId(String warningHeadId) {
        this.warningHeadId = warningHeadId;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
}
