package com.ktb.ewsl.vo;

import java.util.Date;
import java.util.List;

public class FinancialVo {
    private String applicationNo;
    private String cifNo;
    private String custNo;
    private String custName;
    private String custTypeName;

    private String finId;
    private String cif;
    private String hvFin;
    private String reasonCode;
    private String reasonDetail;
    private String finConfigId;
    private String trnId;
    private String modelIdFnAudit;
    private String modelIdFnAdjust;
    private String modelIdPrimary;
    private String finStatementAuditDate1;
    private String finStatementAuditDate2;
    private String finStatementAuditDate3;
    private String finStatementAdjustDate1;
    private String finStatementAdjustDate2;
    private String finStatementAdjustDate3;
    private String optimistPpnTm;
    private int warningInfoId;
    private String reasonSelectN;
    private String reasonSelectY;
    //--------------------- FIN Validate Over 18 Month---------------------//
    private String stateType;
    private String updatedBy;
    private java.util.Date updatedDate;
    private String finTrnId;
    private String delayReason;
    
    private List<FinancialRatioVo> ratioList;

    public String getReasonSelectN() {
        return reasonSelectN;
    }

    public void setReasonSelectN(String reasonSelectN) {
        this.reasonSelectN = reasonSelectN;
    }

    public String getReasonSelectY() {
        return reasonSelectY;
    }

    public void setReasonSelectY(String reasonSelectY) {
        this.reasonSelectY = reasonSelectY;
    }

   

    
    public List<FinancialRatioVo> getRatioList() {
        return ratioList;
    }

    public void setRatioList(List<FinancialRatioVo> ratioList) {
        this.ratioList = ratioList;
    }
           
    public String getApplicationNo() {
        return applicationNo;
    }

    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getCustNo() {
        return custNo;
    }

    public void setCustNo(String custNo) {
        this.custNo = custNo;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustTypeName() {
        return custTypeName;
    }

    public void setCustTypeName(String custTypeName) {
        this.custTypeName = custTypeName;
    }
    
    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getFinConfigId() {
        return finConfigId;
    }

    public void setFinConfigId(String finConfigId) {
        this.finConfigId = finConfigId;
    }

    public String getFinId() {
        return finId;
    }

    public void setFinId(String finId) {
        this.finId = finId;
    }

    public String getHvFin() {
        return hvFin;
    }

    public void setHvFin(String hvFin) {
        this.hvFin = hvFin;
    }

    public String getModelIdFnAdjust() {
        return modelIdFnAdjust;
    }

    public void setModelIdFnAdjust(String modelIdFnAdjust) {
        this.modelIdFnAdjust = modelIdFnAdjust;
    }

    public String getModelIdFnAudit() {
        return modelIdFnAudit;
    }

    public void setModelIdFnAudit(String modelIdFnAudit) {
        this.modelIdFnAudit = modelIdFnAudit;
    }

    public String getModelIdPrimary() {
        return modelIdPrimary;
    }

    public void setModelIdPrimary(String modelIdPrimary) {
        this.modelIdPrimary = modelIdPrimary;
    }

    public String getOptimistPpnTm() {
        return optimistPpnTm;
    }

    public void setOptimistPpnTm(String optimistPpnTm) {
        this.optimistPpnTm = optimistPpnTm;
    }

    public String getReasonCode() {
        if(reasonCode!=null && reasonCode.trim().length()>0&& !"null".equalsIgnoreCase(reasonCode)) {
            return reasonCode;
        }
        return "";
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public String getReasonDetail() {
        if(reasonDetail!=null && reasonDetail.trim().length()>0&& !"null".equalsIgnoreCase(reasonDetail)) {
            return reasonDetail;
        }
        return "";
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public String getTrnId() {
        return trnId;
    }

    public void setTrnId(String trnId) {
        this.trnId = trnId;
    }

    public String getFinStatementAdjustDate1() {
        return finStatementAdjustDate1;
    }

    public void setFinStatementAdjustDate1(String finStatementAdjustDate1) {
        this.finStatementAdjustDate1 = finStatementAdjustDate1;
    }

    public String getFinStatementAdjustDate2() {
        return finStatementAdjustDate2;
    }

    public void setFinStatementAdjustDate2(String finStatementAdjustDate2) {
        this.finStatementAdjustDate2 = finStatementAdjustDate2;
    }

    public String getFinStatementAdjustDate3() {
        return finStatementAdjustDate3;
    }

    public void setFinStatementAdjustDate3(String finStatementAdjustDate3) {
        this.finStatementAdjustDate3 = finStatementAdjustDate3;
    }

    public String getFinStatementAuditDate1() {
        return finStatementAuditDate1;
    }

    public void setFinStatementAuditDate1(String finStatementAuditDate1) {
        this.finStatementAuditDate1 = finStatementAuditDate1;
    }

    public String getFinStatementAuditDate2() {
        return finStatementAuditDate2;
    }

    public void setFinStatementAuditDate2(String finStatementAuditDate2) {
        this.finStatementAuditDate2 = finStatementAuditDate2;
    }

    public String getFinStatementAuditDate3() {
        return finStatementAuditDate3;
    }

    public void setFinStatementAuditDate3(String finStatementAuditDate3) {
        this.finStatementAuditDate3 = finStatementAuditDate3;
    }

    public int getWarningInfoId() {
        return warningInfoId;
    }

    public void setWarningInfoId(int warningInfoId) {
        this.warningInfoId = warningInfoId;
    }

    public String getStateType() {
        return stateType;
    }

    public void setStateType(String stateType) {
        this.stateType = stateType;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getFinTrnId() {
        return finTrnId;
    }

    public void setFinTrnId(String finTrnId) {
        this.finTrnId = finTrnId;
    }

    public String getDelayReason() {
        return delayReason;
    }

    public void setDelayReason(String delayReason) {
        this.delayReason = delayReason;
    }
    
}
