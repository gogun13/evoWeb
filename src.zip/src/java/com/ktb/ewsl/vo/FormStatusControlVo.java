package com.ktb.ewsl.vo;

public class FormStatusControlVo {  
    //public FormStatusControlVo () {}
    private String warningType; 
    private String currStatus; 
    private String actionCode; 
    private String newStatus; 

    public String getWarningType(){ 
        return warningType; 
    } 
    public void setWarningType(String warningType){ 
        this.warningType = warningType; 
    } 
    public String getCurrStatus(){ 
        return currStatus; 
    } 
    public void setCurrStatus(String currStatus){ 
        this.currStatus = currStatus; 
    } 
    public String getActionCode(){ 
        return actionCode; 
    } 
    public void setActionCode(String actionCode){ 
        this.actionCode = actionCode; 
    } 
    public String getNewStatus(){ 
        return newStatus; 
    } 
    public void setNewStatus(String newStatus){ 
        this.newStatus = newStatus; 
    } 
}
