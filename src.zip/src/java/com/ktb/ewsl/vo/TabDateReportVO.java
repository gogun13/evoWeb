/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class TabDateReportVO {
    
    private Date date;
    private String monthDTThaiShort;
    private int month;
    private int year;
    private String monthYear;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

   

    public String getMonthDTThaiShort() {
        return monthDTThaiShort;
    }

    public void setMonthDTThaiShort(String monthDTThaiShort) {
        this.monthDTThaiShort = monthDTThaiShort;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getMonthYear() {
         monthYear = this.month + "_" + this.year;
        return monthYear;
    }

    public void setMonthYear(String monthYear) {
        this.monthYear = monthYear;
    }
    
    
    
    
}
