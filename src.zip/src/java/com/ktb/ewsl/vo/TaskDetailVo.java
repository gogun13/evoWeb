/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class TaskDetailVo extends BaseVo {
    
    private String ewsQuestionnaireCode;
    private String ewsQuestionnaireName;
    private String answerStatus;
    private String ewsRisk;
    private String slaAmount;

    public String getEwsQuestionnaireCode() {
        return ewsQuestionnaireCode;
    }

    public void setEwsQuestionnaireCode(String ewsQuestionnaireCode) {
        this.ewsQuestionnaireCode = ewsQuestionnaireCode;
    }

    public String getEwsQuestionnaireName() {
        return ewsQuestionnaireName;
    }

    public void setEwsQuestionnaireName(String ewsQuestionnaireName) {
        this.ewsQuestionnaireName = ewsQuestionnaireName;
    }

    public String getAnswerStatus() {
        return answerStatus;
    }

    public void setAnswerStatus(String answerStatus) {
        this.answerStatus = answerStatus;
    }

    public String getEwsRisk() {
        return ewsRisk;
    }

    public void setEwsRisk(String ewsRisk) {
        this.ewsRisk = ewsRisk;
    }

    public String getSlaAmount() {
        return slaAmount;
    }

    public void setSlaAmount(String slaAmount) {
        this.slaAmount = slaAmount;
    }
    
    
    
    
}
