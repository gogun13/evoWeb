/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public class CrSubAccountVo implements Serializable{
    private Integer warningHeaderId;
    private String acctNo;
    private String prodGrp;
    private String prodType;
    private String acctSubType;
    private String marketCd;
    private BigDecimal limitAmt;
    private BigDecimal outsBal;
    private BigDecimal availBal;
    private String currCd;
    private Date expiryDt;
    private Date createdDtm;
    private String indexCd;
    private String intSpread;
    private String newAcctRateSchedule;
    private String createdBy;
    private int seq;
    private String mainAcctNo;
    private ArrayList<CrAccountFeeVo> loanFeeList;
    private String commIndexCd;
    private String commIntSpread;
    private String marketCdDesc;
    private String loanTerm;
    private String itemTermPeriod;

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getProdGrp() {
        return prodGrp;
    }

    public void setProdGrp(String prodGrp) {
        this.prodGrp = prodGrp;
    }

    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    public String getAcctSubType() {
        return acctSubType;
    }

    public void setAcctSubType(String acctSubType) {
        this.acctSubType = acctSubType;
    }

    public String getMarketCd() {
        return marketCd;
    }

    public void setMarketCd(String marketCd) {
        this.marketCd = marketCd;
    }

    public BigDecimal getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(BigDecimal limitAmt) {
        this.limitAmt = limitAmt;
    }

    public BigDecimal getOutsBal() {
        return outsBal;
    }

    public void setOutsBal(BigDecimal outsBal) {
        this.outsBal = outsBal;
    }

    public BigDecimal getAvailBal() {
        return availBal;
    }

    public void setAvailBal(BigDecimal availBal) {
        this.availBal = availBal;
    }

    public String getCurrCd() {
        return currCd;
    }

    public void setCurrCd(String currCd) {
        this.currCd = currCd;
    }

    public Date getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Date expiryDt) {
        this.expiryDt = expiryDt;
    }

    public Date getCreatedDtm() {
        return createdDtm;
    }

    public void setCreatedDtm(Date createdDtm) {
        this.createdDtm = createdDtm;
    }

    public String getIndexCd() {
        return indexCd;
    }

    public void setIndexCd(String indexCd) {
        this.indexCd = indexCd;
    }

    public String getIntSpread() {
        return intSpread;
    }

    public void setIntSpread(String intSpread) {
        this.intSpread = intSpread;
    }

    public String getNewAcctRateSchedule() {
        return newAcctRateSchedule;
    }

    public void setNewAcctRateSchedule(String newAcctRateSchedule) {
        this.newAcctRateSchedule = newAcctRateSchedule;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getMainAcctNo() {
        return mainAcctNo;
    }

    public void setMainAcctNo(String mainAcctNo) {
        this.mainAcctNo = mainAcctNo;
    }

    public ArrayList<CrAccountFeeVo> getLoanFeeList() {
        return loanFeeList;
    }

    public void setLoanFeeList(ArrayList<CrAccountFeeVo> loanFeeList) {
        this.loanFeeList = loanFeeList;
    }

  
    public String getCommIndexCd() {
        return commIndexCd;
    }

    public void setCommIndexCd(String commIndexCd) {
        this.commIndexCd = commIndexCd;
    }

    public String getCommIntSpread() {
        return commIntSpread;
    }

    public void setCommIntSpread(String commIntSpread) {
        this.commIntSpread = commIntSpread;
    }

    public String getMarketCdDesc() {
        return marketCdDesc;
    }

    public void setMarketCdDesc(String marketCdDesc) {
        this.marketCdDesc = marketCdDesc;
    }

    public String getLoanTerm() {
        return loanTerm;
    }

    public void setLoanTerm(String loanTerm) {
        this.loanTerm = loanTerm;
    }

    public String getItemTermPeriod() {
        return itemTermPeriod;
    }

    public void setItemTermPeriod(String itemTermPeriod) {
        this.itemTermPeriod = itemTermPeriod;
    }
}
