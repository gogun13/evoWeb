/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;

/**
 *
 * @author KTBDevLoan
 */
public class CountDataVo implements Serializable{
    private int countFin;
    private int countEwsq;
    private int countTrig;
    private int countQca;
    private int countPay;
    private int countCr;
    private int countTa;
    private String countFinStr;
    private String countEwsqStr;
    private String countTrigStr;
    private String countQcaStr;
    private String countPayStr;
    private String countCrStr;
    private String countTaStr;
    private int countTrigAndPay;
    private String countTrigAndPayStr;
    //----------------- EWSL --------------//
     private int latePayFlgCount;
     private String latePayFlgCountStr;         
//    private int wayOutFlgCount;
//    private String wayOutFlgCountStr; 
    private int action1FlgCount;
    private String action1FlgCountStr; 
    private int action2FlgCount;
    private String action2FlgCountStr; 
    private int qualiFlgCount;
    private String qualiFlgCountStr; 
    private int creditRatingFlgCount;
    private String creditRatingFlgCountStr; 
    private int finFlgCount;
    private String finFlgCountStr; 
    private int crFlgCount;
    private String crFlgCountStr; 
     
      
         

    public int getCountFin() {
        return countFin;
    }

    public void setCountFin(int countFin) {
        this.countFin = countFin;
    }

    public int getCountEwsq() {
        return countEwsq;
    }

    public void setCountEwsq(int countEwsq) {
        this.countEwsq = countEwsq;
    }

    public int getCountTrig() {
        return countTrig;
    }

    public void setCountTrig(int countTrig) {
        this.countTrig = countTrig;
    }

    public int getCountQca() {
        return countQca;
    }

    public void setCountQca(int countQca) {
        this.countQca = countQca;
    }

    public int getCountPay() {
        return countPay;
    }

    public void setCountPay(int countPay) {
        this.countPay = countPay;
    }

    public int getCountCr() {
        return countCr;
    }

    public void setCountCr(int countCr) {
        this.countCr = countCr;
    }

    public int getCountTa() {
        return countTa;
    }

    public void setCountTa(int countTa) {
        this.countTa = countTa;
    }

    public String getCountFinStr() {
        return countFinStr;
    }

    public void setCountFinStr(String countFinStr) {
        this.countFinStr = countFinStr;
    }

    public String getCountEwsqStr() {
        return countEwsqStr;
    }

    public void setCountEwsqStr(String countEwsqStr) {
        this.countEwsqStr = countEwsqStr;
    }

    public String getCountTrigStr() {
        return countTrigStr;
    }

    public void setCountTrigStr(String countTrigStr) {
        this.countTrigStr = countTrigStr;
    }

    public String getCountQcaStr() {
        return countQcaStr;
    }

    public void setCountQcaStr(String countQcaStr) {
        this.countQcaStr = countQcaStr;
    }

    public String getCountPayStr() {
        return countPayStr;
    }

    public void setCountPayStr(String countPayStr) {
        this.countPayStr = countPayStr;
    }

    public String getCountCrStr() {
        return countCrStr;
    }

    public void setCountCrStr(String countCrStr) {
        this.countCrStr = countCrStr;
    }

    public String getCountTaStr() {
        return countTaStr;
    }

    public void setCountTaStr(String countTaStr) {
        this.countTaStr = countTaStr;
    }

    public int getCountTrigAndPay() {
        return countTrigAndPay;
    }

    public void setCountTrigAndPay(int countTrigAndPay) {
        this.countTrigAndPay = countTrigAndPay;
    }

    public String getCountTrigAndPayStr() {
        return countTrigAndPayStr;
    }

    public void setCountTrigAndPayStr(String countTrigAndPayStr) {
        this.countTrigAndPayStr = countTrigAndPayStr;
    }

    public int getLatePayFlgCount() {
        return latePayFlgCount;
    }

    public void setLatePayFlgCount(int latePayFlgCount) {
        this.latePayFlgCount = latePayFlgCount;
    }

    public String getLatePayFlgCountStr() {
        return latePayFlgCountStr;
    }

    public void setLatePayFlgCountStr(String latePayFlgCountStr) {
        this.latePayFlgCountStr = latePayFlgCountStr;
    }

    public int getQualiFlgCount() {
        return qualiFlgCount;
    }

    public void setQualiFlgCount(int qualiFlgCount) {
        this.qualiFlgCount = qualiFlgCount;
    }

    public String getQualiFlgCountStr() {
        return qualiFlgCountStr;
    }

    public void setQualiFlgCountStr(String qualiFlgCountStr) {
        this.qualiFlgCountStr = qualiFlgCountStr;
    }

    public int getCreditRatingFlgCount() {
        return creditRatingFlgCount;
    }

    public void setCreditRatingFlgCount(int creditRatingFlgCount) {
        this.creditRatingFlgCount = creditRatingFlgCount;
    }

    public String getCreditRatingFlgCountStr() {
        return creditRatingFlgCountStr;
    }

    public void setCreditRatingFlgCountStr(String creditRatingFlgCountStr) {
        this.creditRatingFlgCountStr = creditRatingFlgCountStr;
    }

    public int getFinFlgCount() {
        return finFlgCount;
    }

    public void setFinFlgCount(int finFlgCount) {
        this.finFlgCount = finFlgCount;
    }

    public String getFinFlgCountStr() {
        return finFlgCountStr;
    }

    public void setFinFlgCountStr(String finFlgCountStr) {
        this.finFlgCountStr = finFlgCountStr;
    }

    public int getCrFlgCount() {
        return crFlgCount;
    }

    public void setCrFlgCount(int crFlgCount) {
        this.crFlgCount = crFlgCount;
    }

    public String getCrFlgCountStr() {
        return crFlgCountStr;
    }

    public void setCrFlgCountStr(String crFlgCountStr) {
        this.crFlgCountStr = crFlgCountStr;
    }

    public int getAction1FlgCount() {
        return action1FlgCount;
    }

    public void setAction1FlgCount(int action1FlgCount) {
        this.action1FlgCount = action1FlgCount;
    }

    public String getAction1FlgCountStr() {
        return action1FlgCountStr;
    }

    public void setAction1FlgCountStr(String action1FlgCountStr) {
        this.action1FlgCountStr = action1FlgCountStr;
    }

    public int getAction2FlgCount() {
        return action2FlgCount;
    }

    public void setAction2FlgCount(int action2FlgCount) {
        this.action2FlgCount = action2FlgCount;
    }

    public String getAction2FlgCountStr() {
        return action2FlgCountStr;
    }

    public void setAction2FlgCountStr(String action2FlgCountStr) {
        this.action2FlgCountStr = action2FlgCountStr;
    }
    
    
}
