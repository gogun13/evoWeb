/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.vo.BaseVo;
import java.util.ArrayList;

/**
 *
 * @author Tum_Surapong
 */
public class AsstTopicVo extends BaseVo{
    private String questionId;
    private String version;
    private int topicId;
    private String topicDesc;
    private int warningId;
    private ArrayList<AsstSubtopicVo> asstSubtopicVoList;
    private String cifNo;
    private String custName;
    private int warningHeaderId;
    private String warningType;
    private String infoStatus;
    private String remark;
    private String actionCode;
    //-------- For Combine Form ----//
    private String warningTypeDesc;
    private String answerVersion;
    private String answerQuestionId;
    private String warningDateStr;
    //-------- For LatePayment Send Score ----//
    private String actionForm;
    //--------- QUALI Query Old Answer
    private String requireOldAnswer = BusinessConst.Flag.N;
    
    private boolean selectBCM;
    
    public AsstTopicVo(){
        selectBCM = true;
    }

    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    public String getTopicDesc() {
        return topicDesc;
    }

    public void setTopicDesc(String topicDesc) {
        this.topicDesc = topicDesc;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public ArrayList<AsstSubtopicVo> getAsstSubtopicVoList() {
        return asstSubtopicVoList;
    }

    public void setAsstSubtopicVoList(ArrayList<AsstSubtopicVo> asstSubtopicVoList) {
        this.asstSubtopicVoList = asstSubtopicVoList;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getInfoStatus() {
        return infoStatus;
    }

    public void setInfoStatus(String infoStatus) {
        this.infoStatus = infoStatus;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getActionCode() {
        return actionCode;
    }

    public void setActionCode(String actionCode) {
        this.actionCode = actionCode;
    }

    public String getWarningTypeDesc() {
        return warningTypeDesc;
    }

    public void setWarningTypeDesc(String warningTypeDesc) {
        this.warningTypeDesc = warningTypeDesc;
    }

    public String getAnswerVersion() {
        return answerVersion;
    }

    public void setAnswerVersion(String answerVersion) {
        this.answerVersion = answerVersion;
    }

    public String getAnswerQuestionId() {
        return answerQuestionId;
    }

    public void setAnswerQuestionId(String answerQuestionId) {
        this.answerQuestionId = answerQuestionId;
    }

    public String getWarningDateStr() {
        return warningDateStr;
    }

    public void setWarningDateStr(String warningDateStr) {
        this.warningDateStr = warningDateStr;
    }

    public String getActionForm() {
        return actionForm;
    }

    public void setActionForm(String actionForm) {
        this.actionForm = actionForm;
    }

    public String getRequireOldAnswer() {
        return requireOldAnswer;
    }

    public void setRequireOldAnswer(String requireOldAnswer) {
        this.requireOldAnswer = requireOldAnswer;
    }

    public boolean isSelectBCM() {
        return selectBCM;
    }

    public void setSelectBCM(boolean selectBCM) {
        this.selectBCM = selectBCM;
    }
    
}
