/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author Tum_Surapong
 */
public class AsstChoiceVo extends BaseVo{
    private String questionId;
    private String version;
    private int topicId;
    private int subTopicId;
    private int choiceId;
    private String choiceDesc;
    private int choiceReasonFlag;
    private String choiceDescNull = "";
 

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    public int getChoiceId() {
        return choiceId;
    }

    public void setChoiceId(int choiceId) {
        this.choiceId = choiceId;
    }

    public String getChoiceDesc() {
        return choiceDesc;
    }

    public void setChoiceDesc(String choiceDesc) {
        this.choiceDesc = choiceDesc;
    }

    public int getChoiceReasonFlag() {
        return choiceReasonFlag;
    }

    public void setChoiceReasonFlag(int choiceReasonFlag) {
        this.choiceReasonFlag = choiceReasonFlag;
    }

    public int getSubTopicId() {
        return subTopicId;
    }

    public void setSubTopicId(int subTopicId) {
        this.subTopicId = subTopicId;
    }

    public String getChoiceDescNull() {
        return choiceDescNull;
    }

    public void setChoiceDescNull(String choiceDescNull) {
        this.choiceDescNull = choiceDescNull;
    }
    
}
