/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class ReportCloseJobVo {
    private WarningHeaderVo warningHeaderVo;
    private String reasonCode;
    private String reasonDetail;
    private String status;
    private String remark;
    private Date actionDt;
    private String actionDtS;
    private String actionBy;
    private String actionByFullName;
    private Date approveDt;
    private String approveDtS;
    private String approveBy;
    private String approveByFullName;
    private Date crDt;
    private String crDtS;
    private String crBy;
    private Date taDt;
    private String taDtS;
    private String taBy;
    private Integer warningHeaderId;
    private Integer warningId;
    int index;
    private String closeJobFlg;
    private String closeJobType;
    
    private String sortLatePayForm;
//    private String sortWayOutForm;
    private String sortAction1Form;
    private String sortAction2Form;
    private String sortQuali;
    private String sortCreditRating;
    private String sortFin;
    private String sortCreditReview;
    private String warningType;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
    
    public WarningHeaderVo getWarningHeaderVo() {
        return warningHeaderVo;
    }

    public void setWarningHeaderVo(WarningHeaderVo warningHeaderVo) {
        this.warningHeaderVo = warningHeaderVo;
    }

    public String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public String getReasonDetail() {
        return reasonDetail;
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getActionDt() {
        return actionDt;
    }

    public void setActionDt(Date actionDt) {
        this.actionDt = actionDt;
    }

    public String getActionDtS() {
        return actionDtS;
    }

    public void setActionDtS(String actionDtS) {
        this.actionDtS = actionDtS;
    }

    public String getActionBy() {
        return actionBy;
    }

    public void setActionBy(String actionBy) {
        this.actionBy = actionBy;
    }

    public Date getApproveDt() {
        return approveDt;
    }

    public void setApproveDt(Date approveDt) {
        this.approveDt = approveDt;
    }

    public String getApproveDtS() {
        return approveDtS;
    }

    public void setApproveDtS(String approveDtS) {
        this.approveDtS = approveDtS;
    }

    public String getApproveBy() {
        return approveBy;
    }

    public void setApproveBy(String approveBy) {
        this.approveBy = approveBy;
    }

    public Date getCrDt() {
        return crDt;
    }

    public void setCrDt(Date crDt) {
        this.crDt = crDt;
    }

    public String getCrDtS() {
        return crDtS;
    }

    public void setCrDtS(String crDtS) {
        this.crDtS = crDtS;
    }

    public String getCrBy() {
        return crBy;
    }

    public void setCrBy(String crBy) {
        this.crBy = crBy;
    }

    public Date getTaDt() {
        return taDt;
    }

    public void setTaDt(Date taDt) {
        this.taDt = taDt;
    }

    public String getTaDtS() {
        return taDtS;
    }

    public void setTaDtS(String taDtS) {
        this.taDtS = taDtS;
    }

    public String getTaBy() {
        return taBy;
    }

    public void setTaBy(String taBy) {
        this.taBy = taBy;
    }

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public Integer getWarningId() {
        return warningId;
    }

    public void setWarningId(Integer warningId) {
        this.warningId = warningId;
    }

    public String getCloseJobFlg() {
        return closeJobFlg;
    }

    public void setCloseJobFlg(String closeJobFlg) {
        this.closeJobFlg = closeJobFlg;
    }

    public String getCloseJobType() {
        return closeJobType;
    }

    public void setCloseJobType(String closeJobType) {
        this.closeJobType = closeJobType;
    }

    public String getSortLatePayForm() {
        return sortLatePayForm;
    }

    public void setSortLatePayForm(String sortLatePayForm) {
        this.sortLatePayForm = sortLatePayForm;
    }

//    public String getSortWayOutForm() {
//        return sortWayOutForm;
//    }
//
//    public void setSortWayOutForm(String sortWayOutForm) {
//        this.sortWayOutForm = sortWayOutForm;
//    }
//
//    public String getSortActionForm() {
//        return sortActionForm;
//    }
//
//    public void setSortActionForm(String sortActionForm) {
//        this.sortActionForm = sortActionForm;
//    }

    public String getSortQuali() {
        return sortQuali;
    }

    public void setSortQuali(String sortQuali) {
        this.sortQuali = sortQuali;
    }

    public String getSortCreditRating() {
        return sortCreditRating;
    }

    public void setSortCreditRating(String sortCreditRating) {
        this.sortCreditRating = sortCreditRating;
    }

    public String getSortFin() {
        return sortFin;
    }

    public void setSortFin(String sortFin) {
        this.sortFin = sortFin;
    }

    public String getSortCreditReview() {
        return sortCreditReview;
    }

    public void setSortCreditReview(String sortCreditReview) {
        this.sortCreditReview = sortCreditReview;
    }

    public String getActionByFullName() {
        return actionByFullName;
    }

    public void setActionByFullName(String actionByFullName) {
        this.actionByFullName = actionByFullName;
    }

    public String getApproveByFullName() {
        return approveByFullName;
    }

    public void setApproveByFullName(String approveByFullName) {
        this.approveByFullName = approveByFullName;
    }

    public String getSortAction1Form() {
        return sortAction1Form;
    }

    public void setSortAction1Form(String sortAction1Form) {
        this.sortAction1Form = sortAction1Form;
    }

    public String getSortAction2Form() {
        return sortAction2Form;
    }

    public void setSortAction2Form(String sortAction2Form) {
        this.sortAction2Form = sortAction2Form;
    }

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    
    
}
