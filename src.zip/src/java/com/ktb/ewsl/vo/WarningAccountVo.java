/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Tum_Surapong
 */
public class WarningAccountVo extends BaseVo{
    private int warningHeaderId;
    private int accountNo;
    private BigDecimal limitAmount;
    private int dpd;
    private Date lastPaidDate;
    private String lastPaidDateS;

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public BigDecimal getLimitAmount() {
        return limitAmount;
    }

    public void setLimitAmount(BigDecimal limitAmount) {
        this.limitAmount = limitAmount;
    }

    public int getDpd() {
        return dpd;
    }

    public void setDpd(int dpd) {
        this.dpd = dpd;
    }

    public Date getLastPaidDate() {
        return lastPaidDate;
    }

    public void setLastPaidDate(Date lastPaidDate) {
        this.lastPaidDate = lastPaidDate;
    }

    public String getLastPaidDateS() {
        if(getLastPaidDate() != null){
            return DateUtil.getDateInThaiFormat(getLastPaidDate());
        }
        return "";
    }
}
