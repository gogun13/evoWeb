/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class KtbFieldMapVO  extends BaseVo{
    
    private String ktbFieldMapCode;
    private int ktbFieldMapGroup;
    private String ktbFieldMapName;

    public String getKtbFieldMapCode() {
        return ktbFieldMapCode;
    }

    public void setKtbFieldMapCode(String ktbFieldMapCode) {
        this.ktbFieldMapCode = ktbFieldMapCode;
    }

    public int getKtbFieldMapGroup() {
        return ktbFieldMapGroup;
    }

    public void setKtbFieldMapGroup(int ktbFieldMapGroup) {
        this.ktbFieldMapGroup = ktbFieldMapGroup;
    }

    public String getKtbFieldMapName() {
        return ktbFieldMapName;
    }

    public void setKtbFieldMapName(String ktbFieldMapName) {
        this.ktbFieldMapName = ktbFieldMapName;
    }
    
    
        
}
