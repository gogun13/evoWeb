package com.ktb.ewsl.vo;

import java.util.Date;

public class WarningWayOutVo {
    //public WarningWayOutVo () {}
    private int warningId; 
    private int wayoutId; 
    private String wayoutFlg; 
    private String wayoutRemark; 
    private String confWayoutFlg; 
    private String confWayoutRemark; 
    private int actionStatus; 
    private Date createdDt; 
    private String createdBy; 
    private Date updatedDt; 
    private String updatedBy;
    private String roleCode;

    public int getWarningId(){ 
        return warningId; 
    } 
    public void setWarningId(int warningId){ 
        this.warningId = warningId; 
    } 
    public int getWayoutId(){ 
        return wayoutId; 
    } 
    public void setWayoutId(int wayoutId){ 
        this.wayoutId = wayoutId; 
    } 
    public String getWayoutFlg(){ 
        return wayoutFlg; 
    } 
    public void setWayoutFlg(String wayoutFlg){ 
        this.wayoutFlg = wayoutFlg; 
    } 
    public String getWayoutRemark(){ 
        return wayoutRemark; 
    } 
    public void setWayoutRemark(String wayoutRemark){ 
        this.wayoutRemark = wayoutRemark; 
    } 
    public String getConfWayoutFlg(){ 
        return confWayoutFlg; 
    } 
    public void setConfWayoutFlg(String confWayoutFlg){ 
        this.confWayoutFlg = confWayoutFlg; 
    } 
    public String getConfWayoutRemark(){ 
        return confWayoutRemark; 
    } 
    public void setConfWayoutRemark(String confWayoutRemark){ 
        this.confWayoutRemark = confWayoutRemark; 
    } 
    public int getActionStatus(){ 
        return actionStatus; 
    } 
    public void setActionStatus(int actionStatus){ 
        this.actionStatus = actionStatus; 
    } 
    public Date getCreatedDt(){ 
        return createdDt; 
    } 
    public void setCreatedDt(Date createdDt){ 
        this.createdDt = createdDt; 
    } 
    public String getCreatedBy(){ 
        return createdBy; 
    } 
    public void setCreatedBy(String createdBy){ 
        this.createdBy = createdBy; 
    } 
    public Date getUpdatedDt(){ 
        return updatedDt; 
    } 
    public void setUpdatedDt(Date updatedDt){ 
        this.updatedDt = updatedDt; 
    } 
    public String getUpdatedBy(){ 
        return updatedBy; 
    } 
    public void setUpdatedBy(String updatedBy){ 
        this.updatedBy = updatedBy; 
    } 

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
}
