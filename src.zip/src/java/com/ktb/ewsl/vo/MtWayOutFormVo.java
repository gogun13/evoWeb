/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author Pratya
 */
public class MtWayOutFormVo {
    private String wayOutId;
    private String wayOutDesc;
    private String isActive;
    private String seq;
    private String showType;
    private String createdDt;
    private String createdBy;
    private String updatedDt;
    private String updatedBy;
    
    public MtWayOutFormVo(){
        this.wayOutId   = "";
        this.wayOutDesc = "";
        this.isActive   = "";
        this.seq        = "";
        this.showType   = "";
        this.createdDt  = "";
        this.createdBy  = "";
        this.updatedDt  = "";
        this.updatedBy  = "";
    }

    public String getWayOutId() {
        return wayOutId;
    }

    public void setWayOutId(String wayOutId) {
        this.wayOutId = wayOutId;
    }

    public String getWayOutDesc() {
        return wayOutDesc;
    }

    public void setWayOutDesc(String wayOutDesc) {
        this.wayOutDesc = wayOutDesc;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getShowType() {
        return showType;
    }

    public void setShowType(String showType) {
        this.showType = showType;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(String updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}
