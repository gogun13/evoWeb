/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;

/**
 *
 * @author KTBDevLoan
 */
public class WarningTypeSessionVo implements Serializable {
    
    private String ewsFlag;
    private String finFlag;
    private String payFlag;
    private String qcaFlag;
    private String trigFlag;
    private String selectAllFlag;
    private int approveEWSQ;
    private String qualiSendFlag;
    private String trigAndPayFlag;
    
    private String ewsEnable;
    private String finEnable;
    private String payEnable;
    private String qcaEnable;
    private String trigEnable;
    private String trigAndPayEnable;
    private String genTrigFlag;
    private String qualiCloseJob;
    private int trigPayId;
   
    

    public String getEwsFlag() {
        return ewsFlag;
    }

    public void setEwsFlag(String ewsFlag) {
        this.ewsFlag = ewsFlag;
    }

    public String getFinFlag() {
        return finFlag;
    }

    public void setFinFlag(String finFlag) {
        this.finFlag = finFlag;
    }

    public String getPayFlag() {
        return payFlag;
    }

    public void setPayFlag(String payFlag) {
        this.payFlag = payFlag;
    }

    public String getQcaFlag() {
        return qcaFlag;
    }

    public void setQcaFlag(String qcaFlag) {
        this.qcaFlag = qcaFlag;
    }

    public String getTrigFlag() {
        return trigFlag;
    }

    public void setTrigFlag(String trigFlag) {
        this.trigFlag = trigFlag;
    }

    public String getSelectAllFlag() {
        return selectAllFlag;
    }

    public void setSelectAllFlag(String selectAllFlag) {
        this.selectAllFlag = selectAllFlag;
    }

    public int getApproveEWSQ() {
        return approveEWSQ;
    }

    public void setApproveEWSQ(int approveEWSQ) {
        this.approveEWSQ = approveEWSQ;
    }

    public String getQualiSendFlag() {
        return qualiSendFlag;
    }

    public void setQualiSendFlag(String qualiSendFlag) {
        this.qualiSendFlag = qualiSendFlag;
    }

    public String getEwsEnable() {
        return ewsEnable;
    }

    public void setEwsEnable(String ewsEnable) {
        this.ewsEnable = ewsEnable;
    }

    public String getFinEnable() {
        return finEnable;
    }

    public void setFinEnable(String finEnable) {
        this.finEnable = finEnable;
    }

    public String getPayEnable() {
        return payEnable;
    }

    public void setPayEnable(String payEnable) {
        this.payEnable = payEnable;
    }

    public String getQcaEnable() {
        return qcaEnable;
    }

    public void setQcaEnable(String qcaEnable) {
        this.qcaEnable = qcaEnable;
    }

    public String getTrigEnable() {
        return trigEnable;
    }

    public void setTrigEnable(String trigEnable) {
        this.trigEnable = trigEnable;
    }

    public String getTrigAndPayFlag() {
        return trigAndPayFlag;
    }

    public void setTrigAndPayFlag(String trigAndPayFlag) {
        this.trigAndPayFlag = trigAndPayFlag;
    }

    public String getTrigAndPayEnable() {
        return trigAndPayEnable;
    }

    public void setTrigAndPayEnable(String trigAndPayEnable) {
        this.trigAndPayEnable = trigAndPayEnable;
    }

    public String getGenTrigFlag() {
        return genTrigFlag;
    }

    public void setGenTrigFlag(String genTrigFlag) {
        this.genTrigFlag = genTrigFlag;
    }

    public String getQualiCloseJob() {
        return qualiCloseJob;
    }

    public void setQualiCloseJob(String qualiCloseJob) {
        this.qualiCloseJob = qualiCloseJob;
    }

    public int getTrigPayId() {
        return trigPayId;
    }

    public void setTrigPayId(int trigPayId) {
        this.trigPayId = trigPayId;
    }

   
    
    
    
}
