/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author Tum_Surapong
 */
public class WarningDateDataVo extends BaseVo{
    private Date warningDate;
    private Date batchDate;
    private Date cbsDate;
    private Date tfsDate;
    private String warningDateS;
    private String batchDateS;
    private String cbsDateS;
    private String tfsDateS;

    public Date getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(Date warningDate) {
        this.warningDate = warningDate;
    }

    public Date getBatchDate() {
        return batchDate;
    }

    public void setBatchDate(Date batchDate) {
        this.batchDate = batchDate;
    }

    public Date getCbsDate() {
        return cbsDate;
    }

    public void setCbsDate(Date cbsDate) {
        this.cbsDate = cbsDate;
    }

    public Date getTfsDate() {
        return tfsDate;
    }

    public void setTfsDate(Date tfsDate) {
        this.tfsDate = tfsDate;
    }

    public String getWarningDateS() {
        if(getWarningDate() != null){
            return DateUtil.getDateInThaiFormat(getWarningDate());
        }
        return "";
    }

    public String getBatchDateS() {
        if(getBatchDate() != null){
            return DateUtil.getDateInThaiFormat(getBatchDate());
        }
        return "";
    }

    public String getCbsDateS() {
        if(getCbsDate() != null){
            return DateUtil.getDateInThaiFormat(getCbsDate());
        }
        return "";
    }

    public String getTfsDateS() {
        if(getTfsDate() != null){
            return DateUtil.getDateInThaiFormat(getTfsDate());
        }
        return "";
    }
}
