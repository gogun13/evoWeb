/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;
import com.ktbcs.core.vo.BaseVo;
import java.util.Date;
/**
 *
 * @author KapookZa
 */

public class AnnouncementVo extends BaseVo {
    private Integer seq;
    private Date announceDate; 
    private String announceDateStr; 
    private String announceDateStrFrom; 
    private String announceDateStrTo; 
    private String announceTitle;
    private Date announceStartDate;
    private String announceStartDateStr;
    private Date announceEndDate;
    private String announceEndDateStr;
    private String newFlag;
    private String updateFlag;    
    private Integer isActive;
    private String announceDetail;
    private String statusDesc;
    private String searchPageIndex;
    private String createdDateStr; 
    private int announceDetailLength;
    private String announcementTXT;

    public Date getAnnounceDate() {
        return announceDate;
    }

    public String getAnnounceTitle() {
        return announceTitle;
    }

    public Date getAnnounceStartDate() {
        return announceStartDate;
    }

    public Date getAnnounceEndDate() {
        return announceEndDate;
    }

    public String getNewFlag() {
        return newFlag;
    }

    public String getUpdateFlag() {
        return updateFlag;
    }

    public String getAnnounceDetail() {
        return announceDetail;
    }

    public void setAnnounceDate(Date announceDate) {
        this.announceDate = announceDate;
    }

    public void setAnnounceTitle(String announceTitle) {
        this.announceTitle = announceTitle;
    }

    public void setAnnounceStartDate(Date announceStartDate) {
        this.announceStartDate = announceStartDate;
    }

    public void setAnnounceEndDate(Date announceEndDate) {
        this.announceEndDate = announceEndDate;
    }

    public void setNewFlag(String newFlag) {
        this.newFlag = newFlag;
    }

    public void setUpdateFlag(String updateFlag) {
        this.updateFlag = updateFlag;
    }

    public void setAnnounceDetail(String announceDetail) {
        this.announceDetail = announceDetail;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    /**
     * @return the isActive
     */
    public Integer getIsActive() {
        return isActive;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }

    public String getAnnounceDateStr() {
        return announceDateStr;
    }

    public String getAnnounceDateStrFrom() {
        return announceDateStrFrom;
    }

    public String getAnnounceDateStrTo() {
        return announceDateStrTo;
    }

    public String getAnnounceStartDateStr() {
        return announceStartDateStr;
    }

    public String getAnnounceEndDateStr() {
        return announceEndDateStr;
    }

    public void setAnnounceDateStr(String announceDateStr) {
        this.announceDateStr = announceDateStr;
    }

    public void setAnnounceDateStrFrom(String announceDateStrFrom) {
        this.announceDateStrFrom = announceDateStrFrom;
    }

    public void setAnnounceDateStrTo(String announceDateStrTo) {
        this.announceDateStrTo = announceDateStrTo;
    }

    public void setAnnounceStartDateStr(String announceStartDateStr) {
        this.announceStartDateStr = announceStartDateStr;
    }

    public void setAnnounceEndDateStr(String announceEndDateStr) {
        this.announceEndDateStr = announceEndDateStr;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    public void setSearchPageIndex(String searchPageIndex) {
        this.searchPageIndex = searchPageIndex;
    }

    public String getSearchPageIndex() {
        return searchPageIndex;
    }

    public String getCreatedDateStr() {
        return createdDateStr;
    }

    public void setCreatedDateStr(String createdDateStr) {
        this.createdDateStr = createdDateStr;
    }

    public int getAnnounceDetailLength() {
        return announceDetailLength;
    }

    public void setAnnounceDetailLength(int announceDetailLength) {
        this.announceDetailLength = announceDetailLength;
    }

    public String getAnnouncementTXT() {
        return announcementTXT;
    }

    public void setAnnouncementTXT(String announcementTXT) {
        this.announcementTXT = announcementTXT;
    }
    
  
}
