/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author aon
 */
public class MtDepartmentVo extends BaseVo {

    private String deptCd;
    private String deptName;
    private String address;
    private String latitude;
    private String longtitude;
    private String hubCd;
    private String hubManager;
    private String deptManager;
    private String hubName;
    
    
    private int isAppraisal;
    private int isActive;
    
    /**
     * @return the deptCd
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * @param deptCd the deptCd to set
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the latitude
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * @param latitude the latitude to set
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longtitude
     */
    public String getLongtitude() {
        return longtitude;
    }

    /**
     * @param longtitude the longtitude to set
     */
    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    /**
     * @return the isAppraisal
     */
    public int getIsAppraisal() {
        return isAppraisal;
    }

    /**
     * @param isAppraisal the isAppraisal to set
     */
    public void setIsAppraisal(int isAppraisal) {
        this.isAppraisal = isAppraisal;
    }

    /**
     * @return the isActive
     */
    public int getIsActive() {
        return isActive;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    /**
     * @return the hubCd
     */
    public String getHubCd() {
        return hubCd;
    }

    /**
     * @param hubCd the hubCd to set
     */
    public void setHubCd(String hubCd) {
        this.hubCd = hubCd;
    }

    /**
     * @return the hubManager
     */
    public String getHubManager() {
        return hubManager;
    }

    /**
     * @param hubManager the hubManager to set
     */
    public void setHubManager(String hubManager) {
        this.hubManager = hubManager;
    }

    /**
     * @return the deptManager
     */
    public String getDeptManager() {
        return deptManager;
    }

    /**
     * @param deptManager the deptManager to set
     */
    public void setDeptManager(String deptManager) {
        this.deptManager = deptManager;
    }

    /**
     * @return the hubName
     */
    public String getHubName() {
        return hubName;
    }

    /**
     * @param hubName the hubName to set
     */
    public void setHubName(String hubName) {
        this.hubName = hubName;
    }

}
