/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class RptIndividualRiskLevelVo extends BaseVo{
    
    private Integer cif;
    private String createdBy;
    private Date createdDt;
    private Date finalRiskDate;
    private String finalRiskLevel;
    private Date qualiRiskDate;
    private String qualiRiskLevel;
    private Date quantiRiskDate;
    private String quantiRiskLevel;
    //-------
    private String riskLevel;
    private String riskDateStr; 
    private String riskType;
    private Date riskDate;

    public Integer getCif() {
        return cif;
    }

    public void setCif(Integer cif) {
        this.cif = cif;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Date getFinalRiskDate() {
        return finalRiskDate;
    }

    public void setFinalRiskDate(Date finalRiskDate) {
        this.finalRiskDate = finalRiskDate;
    }

    public String getFinalRiskLevel() {
        return finalRiskLevel;
    }

    public void setFinalRiskLevel(String finalRiskLevel) {
        this.finalRiskLevel = finalRiskLevel;
    }

    public Date getQualiRiskDate() {
        return qualiRiskDate;
    }

    public void setQualiRiskDate(Date qualiRiskDate) {
        this.qualiRiskDate = qualiRiskDate;
    }

    public String getQualiRiskLevel() {
        return qualiRiskLevel;
    }

    public void setQualiRiskLevel(String qualiRiskLevel) {
        this.qualiRiskLevel = qualiRiskLevel;
    }

    public Date getQuantiRiskDate() {
        return quantiRiskDate;
    }

    public void setQuantiRiskDate(Date quantiRiskDate) {
        this.quantiRiskDate = quantiRiskDate;
    }

    public String getQuantiRiskLevel() {
        return quantiRiskLevel;
    }

    public void setQuantiRiskLevel(String quantiRiskLevel) {
        this.quantiRiskLevel = quantiRiskLevel;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public String getRiskDateStr() {
        return riskDateStr;
    }

    public void setRiskDateStr(String riskDateStr) {
        this.riskDateStr = riskDateStr;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public Date getRiskDate() {
        return riskDate;
    }

    public void setRiskDate(Date riskDate) {
        this.riskDate = riskDate;
    }
        
        
        
   
}
