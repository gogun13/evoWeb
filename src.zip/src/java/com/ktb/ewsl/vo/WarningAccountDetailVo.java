/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class WarningAccountDetailVo  extends BaseVo{
    
    private String accountNo;
    private String accountSubType;
    private String billNo;
    private String cFinal;
    private String cif;
    private String pdp;
    private String pdpZeroFlag;
    private BigDecimal dueAmt;
    private String dueAmtS;
    private Date dueDate;
    private String dueDateS;
    private String inputAccountNo;
    private String inputBillNo;
    private Date lastBatchDate;
    private String lastBatchDateS;
    private BigDecimal lateCharge;
    private String lateChargeS;
    private BigDecimal limitAmt;
    private String limitAmtS;
    private String loanType;
    private Date maturityDate;
    private String maturityDateS;
    private Integer odOverLimit;
    private String odOverLimitS;
    private BigDecimal outstandingAmt;
    private String outstandingAmtS;
    private Date paidDate;
    private String paidDateS;
    private String productGroup;
    private String productType;
    private String sourceSystem;
    private BigDecimal unpaidAmt;
    private String unpaidAmtS;
    private BigDecimal unpaidInterest;
    private String unpaidInterestS;
    private BigDecimal unpaidPrincipal;
    private String unpaidPrincipalS;
    private Integer warningHeaderId;

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountSubType() {
        return accountSubType;
    }

    public void setAccountSubType(String accountSubType) {
        this.accountSubType = accountSubType;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getcFinal() {
        return cFinal;
    }

    public void setcFinal(String cFinal) {
        this.cFinal = cFinal;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getPdp() {
        return pdp;
    }

    public void setPdp(String pdp) {
        this.pdp = pdp;
    }

    public String getPdpZeroFlag() {
        return pdpZeroFlag;
    }

    public void setPdpZeroFlag(String pdpZeroFlag) {
        this.pdpZeroFlag = pdpZeroFlag;
    }

    public BigDecimal getDueAmt() {
        return dueAmt;
    }

    public void setDueAmt(BigDecimal dueAmt) {
        this.dueAmt = dueAmt;
    }

    public String getDueAmtS() {
        if(getDueAmt() != null){
            return StringUtil.formatCurrentcy(getDueAmt());
        }
        return "-";
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getDueDateS() {
        if(getDueDate() != null){
            return DateUtil.getDateInThaiFormat(getDueDate());
        }
        return "";
    }


    public String getInputAccountNo() {
        return inputAccountNo;
    }

    public void setInputAccountNo(String inputAccountNo) {
        this.inputAccountNo = inputAccountNo;
    }

    public String getInputBillNo() {
        return inputBillNo;
    }

    public void setInputBillNo(String inputBillNo) {
        this.inputBillNo = inputBillNo;
    }

    public Date getLastBatchDate() {
        return lastBatchDate;
    }

    public void setLastBatchDate(Date lastBatchDate) {
        this.lastBatchDate = lastBatchDate;
    }

    public String getLastBatchDateS() {
        if(getLastBatchDate() != null){
            return DateUtil.getDateInThaiFormat(getLastBatchDate());
        }
        return "";
    }


    public BigDecimal getLateCharge() {
        return lateCharge;
    }

    public void setLateCharge(BigDecimal lateCharge) {
        this.lateCharge = lateCharge;
    }

    public String getLateChargeS() {
        if(getLateCharge() != null){
            return StringUtil.formatCurrentcy(getLateCharge());
        }
        return "-";
    }


    public BigDecimal getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(BigDecimal limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getLimitAmtS() {
        if(getLimitAmt() != null){
            return StringUtil.formatCurrentcy(getLimitAmt());
        }
        return "-";
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getMaturityDateS() {
        if(getMaturityDate() != null){
            return DateUtil.getDateInThaiFormat(getMaturityDate());
        }
        return "";
    }

    public Integer getOdOverLimit() {
        return odOverLimit;
    }

    public void setOdOverLimit(Integer odOverLimit) {
        this.odOverLimit = odOverLimit;
    }

    public String getOdOverLimitS() {
        return odOverLimitS;
    }

    public void setOdOverLimitS(String odOverLimitS) {
        this.odOverLimitS = odOverLimitS;
    }

    public BigDecimal getOutstandingAmt() {
        return outstandingAmt;
    }

    public void setOutstandingAmt(BigDecimal outstandingAmt) {
        this.outstandingAmt = outstandingAmt;
    }

    public String getOutstandingAmtS() {
       if(getOutstandingAmt() != null){
            return StringUtil.formatCurrentcy(getOutstandingAmt());
        }
        return "-";
    }

    public Date getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(Date paidDate) {
        this.paidDate = paidDate;
    }

    public String getPaidDateS() {
       if(getPaidDate() != null){
            return DateUtil.getDateInThaiFormat(getPaidDate());
        }
        return "";
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public BigDecimal getUnpaidAmt() {
        return unpaidAmt;
    }

    public void setUnpaidAmt(BigDecimal unpaidAmt) {
        this.unpaidAmt = unpaidAmt;
    }

    public String getUnpaidAmtS() {
      if(getUnpaidAmt() != null){
            return StringUtil.formatCurrentcy(getUnpaidAmt());
        }
        return "-";
    }

    public BigDecimal getUnpaidInterest() {
        return unpaidInterest;
    }

    public void setUnpaidInterest(BigDecimal unpaidInterest) {
        this.unpaidInterest = unpaidInterest;
    }

    public String getUnpaidInterestS() {
        if(getUnpaidInterest() != null){
            return StringUtil.formatCurrentcy(getUnpaidInterest());
        }
        return "-";
    }

    public BigDecimal getUnpaidPrincipal() {
        return unpaidPrincipal;
    }

    public void setUnpaidPrincipal(BigDecimal unpaidPrincipal) {
        this.unpaidPrincipal = unpaidPrincipal;
    }

    public String getUnpaidPrincipalS() {
          if(getUnpaidPrincipal() != null){
            return StringUtil.formatCurrentcy(getUnpaidPrincipal());
        }
        return "-";
    }

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

        
}
