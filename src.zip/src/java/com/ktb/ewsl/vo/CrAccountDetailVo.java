/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public class CrAccountDetailVo implements Serializable{
    private Integer warningHeaderId;
    private String acctName;
    private String acctNo;
    private String acctRelInfo;
    private String acctStatus;
    private String acctSubType;
    private String appId;
    private String arrPurCd;
    private double authLimit;
    private String autoLnPayAcct;
    private double availBal;
    private String commitAcct;
    private String commitLine;
    private String communityCd;
    private Date contractDt;
    private String costCenter;
    private String currCd;
    private BigDecimal earlyPayOffPenalty;
    private Date expiryDt;
    private String extCfinal;
    private String extCoverride;
    private String extCtdr;
    private String facilityRate;
    private int firstStageOfPastDue;
    private BigDecimal fixedIntAmt;
    private BigDecimal fixedPrinAmt;
    private String fullWriteOffFlag;
    private BigDecimal fullWriteOffIntAmt;
    private BigDecimal fullWriteOffLateChrgAmt;
    private BigDecimal fullWriteOffMiscChrgAmt;
    private BigDecimal fullWriteOffPrinAmt;
    private double intRec;
    private double intSus;
    private String isicGc;
    private String isicKtb;
    private String isicSd;
    private String isicTs;
    private String isicTsDesc;
    private String isicAll;
    private String isicAllDesc;
    private Date lastTransDate;
    private Date lastWriteOffDate;
    private BigDecimal lateChargeAmt;
    private String legalActionFlag;
    private String legalId;
    private BigDecimal limitAmt;
    private String loanClass;
    private String loanClassFinal;
    private String loanTerm;
    private String marketCd;
    private String newLegalStatus;
    private Date nextPayDt;
    private String officerCd;
    private BigDecimal outsBal;
    private String ownerBr;
    private BigDecimal partWriteOffAmt;
    private String partWriteOffFlag;
    private String partWriteOffStat;
    private Date pastDueDate;
    private String paymentFreq;
    private String pcmCd;
    private String perConsumpCd;
    private BigDecimal piPayment;
    private long primaryCif;
    private String prodClass;
    private String prodGrp;
    private String prodType;
    private String respUnit;
    private String restructFlag;
    private int secondStageOfPastDue;
    private String smeCd;
    private String specLendType;
    private String subAcctOpt;
    private String subAcctOptDesc;
    private BigDecimal intRate;
    private int thirdStageOfPastDue;
    private double totDue;
    private BigDecimal totLoanBal;
    //description
    private String prodGrpDesc;
    private String prodTypeDesc;
    private String ownerBrDesc;
    private String costCenterDesc;
    private String acctStatusDesc;
    private String respUnitDesc;
    private String acctRelInfoDesc;
    private String perConsumpDesc;
    private String marketCdDesc;
    private String loanClassDesc;
    private String pcmCdDesc;
    private String specLendTypeDesc;
    private String loanClassFinalDesc;
    private String legalActionFlagDesc;
    private String newLegalStatusDesc;
    private String extCtdrdesc;
    private String extCoverridedesc;
    private String extCfinaldesc;
    private String arrPurDesc;
    private String isicKtbDesc;
    private String smeDesc;
    private String communityDesc;
    private String currDesc;
    private String acctSubTypeDesc;
    private ArrayList<CrAccountInterestVo> loanInfoInterest;
    private String selected;
    private Date writeOffDate;
    private BigDecimal writeOffAmt;
    private String writeOffFlg;
    private BigDecimal acctAmtField8;
    private BigDecimal acctAmtField9;
    private BigDecimal lastCreditAmt;
    private BigDecimal intSusWriteOff;
    private Date dateOfLastCredit;
    private String indexCd;
    private String intSpread;
    private String commitmentIntIndex;
    private String commitmentIntSpread;
    private String deliquencyStatusCd;
    private String deliquencyStatusDesc;
    private String apprCd;
    private String apprCdDesc;
    private String apprId1;
    private String apprId2;
    private String apprId3;
    private String apprId4;
    private String apprId5;
    private String apprId6;
    private long relatedDepAcctNo;
    private double fixedIntRateDiff;
    private ArrayList<CrSubAccountVo> subAccountList;
    private ArrayList<CrAccountFeeVo> loanFeeList;
    private BigDecimal ledgerBal;
    private String acctClass;
    private String interestDesc;
    private String cifNo;
    private int diffAmt;
    private String acctCate;
    private String soldLoanFlag;
    private String soldLoanFlagDesc;
    private String samCode;
    private String samCodeDesc;
    private String transferComCode;
    private String transferComCodeDesc;
    private BigDecimal intChargeOffAmount;
    private BigDecimal feeChargeOffAmount;
    private String moneyPerYear;
    private String acctFlag;
    private String baseRateCd;
    private String baseRateSign;
    private BigDecimal baseRateInt;
    private String baseRateIntStr;
    private String revolvingFlag;
    private String closFacilityType;
    private String limitAmtS;
    private String outstandingBalS;
    private String expiryDtS;
    private String utilizeS;
    private BigDecimal utilize;
    private String loanGrpProd;
    private Date downloadDate;
    private String downloadDateS;
    
    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getLimitAmtS() {
        if(getLimitAmt() != null){
            return StringUtil.formatCurrentcy(getLimitAmt());
        }
        return "-";
    }

    public String getOutstandingBalS() {
        if(getOutsBal() != null){
            return StringUtil.formatCurrentcy(getOutsBal());
        }
        return "-";
    }

    public String getUtilizeS() {
        if(getUtilize() != null){
            return StringUtil.formatCurrentcy(getUtilize());
        }
        return "-";
    }

    public String getExpiryDtS() {
        if(getExpiryDt() != null){
            return DateUtil.getDateInThaiFormat(getExpiryDt());
        }
        return "";
    }

    public String getAcctName() {
        return acctName;
    }

    public void setAcctName(String acctName) {
        this.acctName = acctName;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getAcctRelInfo() {
        return acctRelInfo;
    }

    public void setAcctRelInfo(String acctRelInfo) {
        this.acctRelInfo = acctRelInfo;
    }

    public String getAcctStatus() {
        return acctStatus;
    }

    public void setAcctStatus(String acctStatus) {
        this.acctStatus = acctStatus;
    }

    public String getAcctSubType() {
        return acctSubType;
    }

    public void setAcctSubType(String acctSubType) {
        this.acctSubType = acctSubType;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getArrPurCd() {
        return arrPurCd;
    }

    public void setArrPurCd(String arrPurCd) {
        this.arrPurCd = arrPurCd;
    }

    public double getAuthLimit() {
        return authLimit;
    }

    public void setAuthLimit(double authLimit) {
        this.authLimit = authLimit;
    }

    public String getAutoLnPayAcct() {
        return autoLnPayAcct;
    }

    public void setAutoLnPayAcct(String autoLnPayAcct) {
        this.autoLnPayAcct = autoLnPayAcct;
    }

    public double getAvailBal() {
        return availBal;
    }

    public void setAvailBal(double availBal) {
        this.availBal = availBal;
    }

    public String getCommitAcct() {
        return commitAcct;
    }

    public void setCommitAcct(String commitAcct) {
        this.commitAcct = commitAcct;
    }

    public String getCommitLine() {
        return commitLine;
    }

    public void setCommitLine(String commitLine) {
        this.commitLine = commitLine;
    }

    public String getCommunityCd() {
        return communityCd;
    }

    public void setCommunityCd(String communityCd) {
        this.communityCd = communityCd;
    }

    public Date getContractDt() {
        return contractDt;
    }

    public void setContractDt(Date contractDt) {
        this.contractDt = contractDt;
    }

    public String getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public String getCurrCd() {
        return currCd;
    }

    public void setCurrCd(String currCd) {
        this.currCd = currCd;
    }

    public BigDecimal getEarlyPayOffPenalty() {
        return earlyPayOffPenalty;
    }

    public void setEarlyPayOffPenalty(BigDecimal earlyPayOffPenalty) {
        this.earlyPayOffPenalty = earlyPayOffPenalty;
    }

    public Date getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Date expiryDt) {
        this.expiryDt = expiryDt;
    }

    public String getExtCfinal() {
        return extCfinal;
    }

    public void setExtCfinal(String extCfinal) {
        this.extCfinal = extCfinal;
    }

    public String getExtCoverride() {
        return extCoverride;
    }

    public void setExtCoverride(String extCoverride) {
        this.extCoverride = extCoverride;
    }

    public String getExtCtdr() {
        return extCtdr;
    }

    public void setExtCtdr(String extCtdr) {
        this.extCtdr = extCtdr;
    }

    public String getFacilityRate() {
        return facilityRate;
    }

    public void setFacilityRate(String facilityRate) {
        this.facilityRate = facilityRate;
    }

    public int getFirstStageOfPastDue() {
        return firstStageOfPastDue;
    }

    public void setFirstStageOfPastDue(int firstStageOfPastDue) {
        this.firstStageOfPastDue = firstStageOfPastDue;
    }

    public BigDecimal getFixedIntAmt() {
        return fixedIntAmt;
    }

    public void setFixedIntAmt(BigDecimal fixedIntAmt) {
        this.fixedIntAmt = fixedIntAmt;
    }

    public BigDecimal getFixedPrinAmt() {
        return fixedPrinAmt;
    }

    public void setFixedPrinAmt(BigDecimal fixedPrinAmt) {
        this.fixedPrinAmt = fixedPrinAmt;
    }

    public String getFullWriteOffFlag() {
        return fullWriteOffFlag;
    }

    public void setFullWriteOffFlag(String fullWriteOffFlag) {
        this.fullWriteOffFlag = fullWriteOffFlag;
    }

    public BigDecimal getFullWriteOffIntAmt() {
        return fullWriteOffIntAmt;
    }

    public void setFullWriteOffIntAmt(BigDecimal fullWriteOffIntAmt) {
        this.fullWriteOffIntAmt = fullWriteOffIntAmt;
    }

    public BigDecimal getFullWriteOffLateChrgAmt() {
        return fullWriteOffLateChrgAmt;
    }

    public void setFullWriteOffLateChrgAmt(BigDecimal fullWriteOffLateChrgAmt) {
        this.fullWriteOffLateChrgAmt = fullWriteOffLateChrgAmt;
    }

    public BigDecimal getFullWriteOffMiscChrgAmt() {
        return fullWriteOffMiscChrgAmt;
    }

    public void setFullWriteOffMiscChrgAmt(BigDecimal fullWriteOffMiscChrgAmt) {
        this.fullWriteOffMiscChrgAmt = fullWriteOffMiscChrgAmt;
    }

    public BigDecimal getFullWriteOffPrinAmt() {
        return fullWriteOffPrinAmt;
    }

    public void setFullWriteOffPrinAmt(BigDecimal fullWriteOffPrinAmt) {
        this.fullWriteOffPrinAmt = fullWriteOffPrinAmt;
    }

    public double getIntRec() {
        return intRec;
    }

    public void setIntRec(double intRec) {
        this.intRec = intRec;
    }

    public double getIntSus() {
        return intSus;
    }

    public void setIntSus(double intSus) {
        this.intSus = intSus;
    }

    public String getIsicGc() {
        return isicGc;
    }

    public void setIsicGc(String isicGc) {
        this.isicGc = isicGc;
    }

    public String getIsicKtb() {
        return isicKtb;
    }

    public void setIsicKtb(String isicKtb) {
        this.isicKtb = isicKtb;
    }

    public String getIsicSd() {
        return isicSd;
    }

    public void setIsicSd(String isicSd) {
        this.isicSd = isicSd;
    }

    public String getIsicTs() {
        return isicTs;
    }

    public void setIsicTs(String isicTs) {
        this.isicTs = isicTs;
    }

    public String getIsicTsDesc() {
        return isicTsDesc;
    }

    public void setIsicTsDesc(String isicTsDesc) {
        this.isicTsDesc = isicTsDesc;
    }

    public String getIsicAll() {
        return isicAll;
    }

    public void setIsicAll(String isicAll) {
        this.isicAll = isicAll;
    }

    public String getIsicAllDesc() {
        return isicAllDesc;
    }

    public void setIsicAllDesc(String isicAllDesc) {
        this.isicAllDesc = isicAllDesc;
    }

    public Date getLastTransDate() {
        return lastTransDate;
    }

    public void setLastTransDate(Date lastTransDate) {
        this.lastTransDate = lastTransDate;
    }

    public Date getLastWriteOffDate() {
        return lastWriteOffDate;
    }

    public void setLastWriteOffDate(Date lastWriteOffDate) {
        this.lastWriteOffDate = lastWriteOffDate;
    }

    public BigDecimal getLateChargeAmt() {
        return lateChargeAmt;
    }

    public void setLateChargeAmt(BigDecimal lateChargeAmt) {
        this.lateChargeAmt = lateChargeAmt;
    }

    public String getLegalActionFlag() {
        return legalActionFlag;
    }

    public void setLegalActionFlag(String legalActionFlag) {
        this.legalActionFlag = legalActionFlag;
    }

    public String getLegalId() {
        return legalId;
    }

    public void setLegalId(String legalId) {
        this.legalId = legalId;
    }

    public BigDecimal getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(BigDecimal limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getLoanClass() {
        return loanClass;
    }

    public void setLoanClass(String loanClass) {
        this.loanClass = loanClass;
    }

    public String getLoanClassFinal() {
        return loanClassFinal;
    }

    public void setLoanClassFinal(String loanClassFinal) {
        this.loanClassFinal = loanClassFinal;
    }

    public String getLoanTerm() {
        return loanTerm;
    }

    public void setLoanTerm(String loanTerm) {
        this.loanTerm = loanTerm;
    }

    public String getMarketCd() {
        return marketCd;
    }

    public void setMarketCd(String marketCd) {
        this.marketCd = marketCd;
    }

    public String getNewLegalStatus() {
        return newLegalStatus;
    }

    public void setNewLegalStatus(String newLegalStatus) {
        this.newLegalStatus = newLegalStatus;
    }

    public Date getNextPayDt() {
        return nextPayDt;
    }

    public void setNextPayDt(Date nextPayDt) {
        this.nextPayDt = nextPayDt;
    }

    public String getOfficerCd() {
        return officerCd;
    }

    public void setOfficerCd(String officerCd) {
        this.officerCd = officerCd;
    }

    public BigDecimal getOutsBal() {
        return outsBal;
    }

    public void setOutsBal(BigDecimal outsBal) {
        this.outsBal = outsBal;
    }

    public String getOwnerBr() {
        return ownerBr;
    }

    public void setOwnerBr(String ownerBr) {
        this.ownerBr = ownerBr;
    }

    public BigDecimal getPartWriteOffAmt() {
        return partWriteOffAmt;
    }

    public void setPartWriteOffAmt(BigDecimal partWriteOffAmt) {
        this.partWriteOffAmt = partWriteOffAmt;
    }

    public String getPartWriteOffFlag() {
        return partWriteOffFlag;
    }

    public void setPartWriteOffFlag(String partWriteOffFlag) {
        this.partWriteOffFlag = partWriteOffFlag;
    }

    public String getPartWriteOffStat() {
        return partWriteOffStat;
    }

    public void setPartWriteOffStat(String partWriteOffStat) {
        this.partWriteOffStat = partWriteOffStat;
    }

    public Date getPastDueDate() {
        return pastDueDate;
    }

    public void setPastDueDate(Date pastDueDate) {
        this.pastDueDate = pastDueDate;
    }

    public String getPaymentFreq() {
        return paymentFreq;
    }

    public void setPaymentFreq(String paymentFreq) {
        this.paymentFreq = paymentFreq;
    }

    public String getPcmCd() {
        return pcmCd;
    }

    public void setPcmCd(String pcmCd) {
        this.pcmCd = pcmCd;
    }

    public String getPerConsumpCd() {
        return perConsumpCd;
    }

    public void setPerConsumpCd(String perConsumpCd) {
        this.perConsumpCd = perConsumpCd;
    }

    public BigDecimal getPiPayment() {
        return piPayment;
    }

    public void setPiPayment(BigDecimal piPayment) {
        this.piPayment = piPayment;
    }

    public long getPrimaryCif() {
        return primaryCif;
    }

    public void setPrimaryCif(long primaryCif) {
        this.primaryCif = primaryCif;
    }

    public String getProdClass() {
        return prodClass;
    }

    public void setProdClass(String prodClass) {
        this.prodClass = prodClass;
    }

    public String getProdGrp() {
        return prodGrp;
    }

    public void setProdGrp(String prodGrp) {
        this.prodGrp = prodGrp;
    }

    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    public String getRespUnit() {
        return respUnit;
    }

    public void setRespUnit(String respUnit) {
        this.respUnit = respUnit;
    }

    public String getRestructFlag() {
        return restructFlag;
    }

    public void setRestructFlag(String restructFlag) {
        this.restructFlag = restructFlag;
    }

    public int getSecondStageOfPastDue() {
        return secondStageOfPastDue;
    }

    public void setSecondStageOfPastDue(int secondStageOfPastDue) {
        this.secondStageOfPastDue = secondStageOfPastDue;
    }

    public String getSmeCd() {
        return smeCd;
    }

    public void setSmeCd(String smeCd) {
        this.smeCd = smeCd;
    }

    public String getSpecLendType() {
        return specLendType;
    }

    public void setSpecLendType(String specLendType) {
        this.specLendType = specLendType;
    }

    public String getSubAcctOpt() {
        return subAcctOpt;
    }

    public void setSubAcctOpt(String subAcctOpt) {
        this.subAcctOpt = subAcctOpt;
    }

    public String getSubAcctOptDesc() {
        return subAcctOptDesc;
    }

    public void setSubAcctOptDesc(String subAcctOptDesc) {
        this.subAcctOptDesc = subAcctOptDesc;
    }

    public BigDecimal getIntRate() {
        return intRate;
    }

    public void setIntRate(BigDecimal intRate) {
        this.intRate = intRate;
    }

    public int getThirdStageOfPastDue() {
        return thirdStageOfPastDue;
    }

    public void setThirdStageOfPastDue(int thirdStageOfPastDue) {
        this.thirdStageOfPastDue = thirdStageOfPastDue;
    }

    public double getTotDue() {
        return totDue;
    }

    public void setTotDue(double totDue) {
        this.totDue = totDue;
    }

    public BigDecimal getTotLoanBal() {
        return totLoanBal;
    }

    public void setTotLoanBal(BigDecimal totLoanBal) {
        this.totLoanBal = totLoanBal;
    }

    public String getProdGrpDesc() {
        return prodGrpDesc;
    }

    public void setProdGrpDesc(String prodGrpDesc) {
        this.prodGrpDesc = prodGrpDesc;
    }

    public String getProdTypeDesc() {
        return prodTypeDesc;
    }

    public void setProdTypeDesc(String prodTypeDesc) {
        this.prodTypeDesc = prodTypeDesc;
    }

    public String getOwnerBrDesc() {
        return ownerBrDesc;
    }

    public void setOwnerBrDesc(String ownerBrDesc) {
        this.ownerBrDesc = ownerBrDesc;
    }

    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    public void setCostCenterDesc(String costCenterDesc) {
        this.costCenterDesc = costCenterDesc;
    }

    public String getAcctStatusDesc() {
        return acctStatusDesc;
    }

    public void setAcctStatusDesc(String acctStatusDesc) {
        this.acctStatusDesc = acctStatusDesc;
    }

    public String getRespUnitDesc() {
        return respUnitDesc;
    }

    public void setRespUnitDesc(String respUnitDesc) {
        this.respUnitDesc = respUnitDesc;
    }

    public String getAcctRelInfoDesc() {
        return acctRelInfoDesc;
    }

    public void setAcctRelInfoDesc(String acctRelInfoDesc) {
        this.acctRelInfoDesc = acctRelInfoDesc;
    }

    public String getPerConsumpDesc() {
        return perConsumpDesc;
    }

    public void setPerConsumpDesc(String perConsumpDesc) {
        this.perConsumpDesc = perConsumpDesc;
    }

    public String getMarketCdDesc() {
        return marketCdDesc;
    }

    public void setMarketCdDesc(String marketCdDesc) {
        this.marketCdDesc = marketCdDesc;
    }

    public String getLoanClassDesc() {
        return loanClassDesc;
    }

    public void setLoanClassDesc(String loanClassDesc) {
        this.loanClassDesc = loanClassDesc;
    }

    public String getPcmCdDesc() {
        return pcmCdDesc;
    }

    public void setPcmCdDesc(String pcmCdDesc) {
        this.pcmCdDesc = pcmCdDesc;
    }

    public String getSpecLendTypeDesc() {
        return specLendTypeDesc;
    }

    public void setSpecLendTypeDesc(String specLendTypeDesc) {
        this.specLendTypeDesc = specLendTypeDesc;
    }

    public String getLoanClassFinalDesc() {
        return loanClassFinalDesc;
    }

    public void setLoanClassFinalDesc(String loanClassFinalDesc) {
        this.loanClassFinalDesc = loanClassFinalDesc;
    }

    public String getLegalActionFlagDesc() {
        return legalActionFlagDesc;
    }

    public void setLegalActionFlagDesc(String legalActionFlagDesc) {
        this.legalActionFlagDesc = legalActionFlagDesc;
    }

    public String getNewLegalStatusDesc() {
        return newLegalStatusDesc;
    }

    public void setNewLegalStatusDesc(String newLegalStatusDesc) {
        this.newLegalStatusDesc = newLegalStatusDesc;
    }

    public String getExtCtdrdesc() {
        return extCtdrdesc;
    }

    public void setExtCtdrdesc(String extCtdrdesc) {
        this.extCtdrdesc = extCtdrdesc;
    }

    public String getExtCoverridedesc() {
        return extCoverridedesc;
    }

    public void setExtCoverridedesc(String extCoverridedesc) {
        this.extCoverridedesc = extCoverridedesc;
    }

    public String getExtCfinaldesc() {
        return extCfinaldesc;
    }

    public void setExtCfinaldesc(String extCfinaldesc) {
        this.extCfinaldesc = extCfinaldesc;
    }

    public String getArrPurDesc() {
        return arrPurDesc;
    }

    public void setArrPurDesc(String arrPurDesc) {
        this.arrPurDesc = arrPurDesc;
    }

    public String getIsicKtbDesc() {
        return isicKtbDesc;
    }

    public void setIsicKtbDesc(String isicKtbDesc) {
        this.isicKtbDesc = isicKtbDesc;
    }

    public String getSmeDesc() {
        return smeDesc;
    }

    public void setSmeDesc(String smeDesc) {
        this.smeDesc = smeDesc;
    }

    public String getCommunityDesc() {
        return communityDesc;
    }

    public void setCommunityDesc(String communityDesc) {
        this.communityDesc = communityDesc;
    }

    public String getCurrDesc() {
        return currDesc;
    }

    public void setCurrDesc(String currDesc) {
        this.currDesc = currDesc;
    }

    public String getAcctSubTypeDesc() {
        return acctSubTypeDesc;
    }

    public void setAcctSubTypeDesc(String acctSubTypeDesc) {
        this.acctSubTypeDesc = acctSubTypeDesc;
    }

    public ArrayList<CrAccountInterestVo> getLoanInfoInterest() {
        return loanInfoInterest;
    }

    public void setLoanInfoInterest(ArrayList<CrAccountInterestVo> loanInfoInterest) {
        this.loanInfoInterest = loanInfoInterest;
    }

    public String getSelected() {
        return selected;
    }

    public void setSelected(String selected) {
        this.selected = selected;
    }

    public Date getWriteOffDate() {
        return writeOffDate;
    }

    public void setWriteOffDate(Date writeOffDate) {
        this.writeOffDate = writeOffDate;
    }

    public BigDecimal getWriteOffAmt() {
        return writeOffAmt;
    }

    public void setWriteOffAmt(BigDecimal writeOffAmt) {
        this.writeOffAmt = writeOffAmt;
    }

    public String getWriteOffFlg() {
        return writeOffFlg;
    }

    public void setWriteOffFlg(String writeOffFlg) {
        this.writeOffFlg = writeOffFlg;
    }

    public BigDecimal getAcctAmtField8() {
        return acctAmtField8;
    }

    public void setAcctAmtField8(BigDecimal acctAmtField8) {
        this.acctAmtField8 = acctAmtField8;
    }

    public BigDecimal getAcctAmtField9() {
        return acctAmtField9;
    }

    public void setAcctAmtField9(BigDecimal acctAmtField9) {
        this.acctAmtField9 = acctAmtField9;
    }

    public BigDecimal getLastCreditAmt() {
        return lastCreditAmt;
    }

    public void setLastCreditAmt(BigDecimal lastCreditAmt) {
        this.lastCreditAmt = lastCreditAmt;
    }

    public BigDecimal getIntSusWriteOff() {
        return intSusWriteOff;
    }

    public void setIntSusWriteOff(BigDecimal intSusWriteOff) {
        this.intSusWriteOff = intSusWriteOff;
    }

    public Date getDateOfLastCredit() {
        return dateOfLastCredit;
    }

    public void setDateOfLastCredit(Date dateOfLastCredit) {
        this.dateOfLastCredit = dateOfLastCredit;
    }

    public String getIndexCd() {
        return indexCd;
    }

    public void setIndexCd(String indexCd) {
        this.indexCd = indexCd;
    }

    public String getIntSpread() {
        return intSpread;
    }

    public void setIntSpread(String intSpread) {
        this.intSpread = intSpread;
    }

    public String getCommitmentIntIndex() {
        return commitmentIntIndex;
    }

    public void setCommitmentIntIndex(String commitmentIntIndex) {
        this.commitmentIntIndex = commitmentIntIndex;
    }

    public String getCommitmentIntSpread() {
        return commitmentIntSpread;
    }

    public void setCommitmentIntSpread(String commitmentIntSpread) {
        this.commitmentIntSpread = commitmentIntSpread;
    }

    public String getDeliquencyStatusCd() {
        return deliquencyStatusCd;
    }

    public void setDeliquencyStatusCd(String deliquencyStatusCd) {
        this.deliquencyStatusCd = deliquencyStatusCd;
    }

    public String getDeliquencyStatusDesc() {
        return deliquencyStatusDesc;
    }

    public void setDeliquencyStatusDesc(String deliquencyStatusDesc) {
        this.deliquencyStatusDesc = deliquencyStatusDesc;
    }

    public String getApprCd() {
        return apprCd;
    }

    public void setApprCd(String apprCd) {
        this.apprCd = apprCd;
    }

    public String getApprCdDesc() {
        return apprCdDesc;
    }

    public void setApprCdDesc(String apprCdDesc) {
        this.apprCdDesc = apprCdDesc;
    }

    public String getApprId1() {
        return apprId1;
    }

    public void setApprId1(String apprId1) {
        this.apprId1 = apprId1;
    }

    public String getApprId2() {
        return apprId2;
    }

    public void setApprId2(String apprId2) {
        this.apprId2 = apprId2;
    }

    public String getApprId3() {
        return apprId3;
    }

    public void setApprId3(String apprId3) {
        this.apprId3 = apprId3;
    }

    public String getApprId4() {
        return apprId4;
    }

    public void setApprId4(String apprId4) {
        this.apprId4 = apprId4;
    }

    public String getApprId5() {
        return apprId5;
    }

    public void setApprId5(String apprId5) {
        this.apprId5 = apprId5;
    }

    public String getApprId6() {
        return apprId6;
    }

    public void setApprId6(String apprId6) {
        this.apprId6 = apprId6;
    }

    public long getRelatedDepAcctNo() {
        return relatedDepAcctNo;
    }

    public void setRelatedDepAcctNo(long relatedDepAcctNo) {
        this.relatedDepAcctNo = relatedDepAcctNo;
    }

    public double getFixedIntRateDiff() {
        return fixedIntRateDiff;
    }

    public void setFixedIntRateDiff(double fixedIntRateDiff) {
        this.fixedIntRateDiff = fixedIntRateDiff;
    }

    public ArrayList<CrSubAccountVo> getSubAccountList() {
        return subAccountList;
    }

    public void setSubAccountList(ArrayList<CrSubAccountVo> subAccountList) {
        this.subAccountList = subAccountList;
    }

    public ArrayList<CrAccountFeeVo> getLoanFeeList() {
        return loanFeeList;
    }

    public void setLoanFeeList(ArrayList<CrAccountFeeVo> loanFeeList) {
        this.loanFeeList = loanFeeList;
    }

   

    public BigDecimal getLedgerBal() {
        return ledgerBal;
    }

    public void setLedgerBal(BigDecimal ledgerBal) {
        this.ledgerBal = ledgerBal;
    }

    public String getAcctClass() {
        return acctClass;
    }

    public void setAcctClass(String acctClass) {
        this.acctClass = acctClass;
    }

    public String getInterestDesc() {
        return interestDesc;
    }

    public void setInterestDesc(String interestDesc) {
        this.interestDesc = interestDesc;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public int getDiffAmt() {
        return diffAmt;
    }

    public void setDiffAmt(int diffAmt) {
        this.diffAmt = diffAmt;
    }

    public String getAcctCate() {
        return acctCate;
    }

    public void setAcctCate(String acctCate) {
        this.acctCate = acctCate;
    }

    public String getSoldLoanFlag() {
        return soldLoanFlag;
    }

    public void setSoldLoanFlag(String soldLoanFlag) {
        this.soldLoanFlag = soldLoanFlag;
    }

    public String getSoldLoanFlagDesc() {
        return soldLoanFlagDesc;
    }

    public void setSoldLoanFlagDesc(String soldLoanFlagDesc) {
        this.soldLoanFlagDesc = soldLoanFlagDesc;
    }

    public String getSamCode() {
        return samCode;
    }

    public void setSamCode(String samCode) {
        this.samCode = samCode;
    }

    public String getSamCodeDesc() {
        return samCodeDesc;
    }

    public void setSamCodeDesc(String samCodeDesc) {
        this.samCodeDesc = samCodeDesc;
    }

    public String getTransferComCode() {
        return transferComCode;
    }

    public void setTransferComCode(String transferComCode) {
        this.transferComCode = transferComCode;
    }

    public String getTransferComCodeDesc() {
        return transferComCodeDesc;
    }

    public void setTransferComCodeDesc(String transferComCodeDesc) {
        this.transferComCodeDesc = transferComCodeDesc;
    }

    public BigDecimal getIntChargeOffAmount() {
        return intChargeOffAmount;
    }

    public void setIntChargeOffAmount(BigDecimal intChargeOffAmount) {
        this.intChargeOffAmount = intChargeOffAmount;
    }

    public BigDecimal getFeeChargeOffAmount() {
        return feeChargeOffAmount;
    }

    public void setFeeChargeOffAmount(BigDecimal feeChargeOffAmount) {
        this.feeChargeOffAmount = feeChargeOffAmount;
    }

    public String getMoneyPerYear() {
        return moneyPerYear;
    }

    public void setMoneyPerYear(String moneyPerYear) {
        this.moneyPerYear = moneyPerYear;
    }

    public String getAcctFlag() {
        return acctFlag;
    }

    public void setAcctFlag(String acctFlag) {
        this.acctFlag = acctFlag;
    }

    public String getBaseRateCd() {
        return baseRateCd;
    }

    public void setBaseRateCd(String baseRateCd) {
        this.baseRateCd = baseRateCd;
    }

    public String getBaseRateSign() {
        return baseRateSign;
    }

    public void setBaseRateSign(String baseRateSign) {
        this.baseRateSign = baseRateSign;
    }

    public BigDecimal getBaseRateInt() {
        return baseRateInt;
    }

    public void setBaseRateInt(BigDecimal baseRateInt) {
        this.baseRateInt = baseRateInt;
    }

    public String getBaseRateIntStr() {
        return baseRateIntStr;
    }

    public void setBaseRateIntStr(String baseRateIntStr) {
        this.baseRateIntStr = baseRateIntStr;
    }

    public String getRevolvingFlag() {
        return revolvingFlag;
    }

    public void setRevolvingFlag(String revolvingFlag) {
        this.revolvingFlag = revolvingFlag;
    }

    public String getClosFacilityType() {
        return closFacilityType;
    }

    public void setClosFacilityType(String closFacilityType) {
        this.closFacilityType = closFacilityType;
    }

    public BigDecimal getUtilize() {
        return utilize;
    }

    public void setUtilize(BigDecimal utilize) {
        this.utilize = utilize;
    }

    public String getLoanGrpProd() {
        return loanGrpProd;
    }

    public void setLoanGrpProd(String loanGrpProd) {
        this.loanGrpProd = loanGrpProd;
    }

    public Date getDownloadDate() {
        return downloadDate;
    }

    public void setDownloadDate(Date downloadDate) {
        this.downloadDate = downloadDate;
    }

    public String getDownloadDateS() {
        if(getDownloadDate() != null){
            return DateUtil.getDateTimeInThaiFormat(getDownloadDate(),"");
        }
        return "";
    }
}
