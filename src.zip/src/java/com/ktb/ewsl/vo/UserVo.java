/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.ArrayList;

/**
 *
 * @author aon
 */
public class UserVo extends BaseVo {
    private String empNo;
    private String empTitleCd;
    private String empTitleDesc;
    private String empFirstName;
    private String empLastName;
    private String deptCd;
    private String deptName;
    private String respUnit;
    private String status;
    private java.util.Date lastLoginDate;
    private java.util.Date lastLogoutDate;
    private String username;
    private String roleId;
    private String roleDesc;
    private String teamId;
    private String phone;
    private MtUserTeamRoleVo userTeamRole;
    private ArrayList<MtUserTeamRoleVo> userTeamRoleList;

    private String costCenter;
    private String costCenterDesc;
    private String respUnitDesc;

    private String deptDesc;
    private String rankCode;
    private String rankDesc;

    private String email;
    
    private String abstype;
    private String appflag;
    private String beginflag;
    private String comment;
    private String endflag;
    private String leaveflag;
    private String empFullName;
    private String isActive;    
    private String isActiveDesc;    
    
    private String employedStatus;
    
    
    /**
     * @return the empNo
     */
    public String getEmpNo() {
        return empNo;
    }

    /**
     * @param empNo the empNo to set
     */
    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    /**
     * @return the empTitleCd
     */
    public String getEmpTitleCd() {
        return empTitleCd;
    }

    /**
     * @param empTitleCd the empTitleCd to set
     */
    public void setEmpTitleCd(String empTitleCd) {
        this.empTitleCd = empTitleCd;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the empFirstName
     */
    public String getEmpFirstName() {
        return empFirstName;
    }

    /**
     * @param empFirstName the empFirstName to set
     */
    public void setEmpFirstName(String empFirstName) {
        this.empFirstName = empFirstName;
    }

    /**
     * @return the empLastName
     */
    public String getEmpLastName() {
        return empLastName;
    }

    /**
     * @param empLastName the empLastName to set
     */
    public void setEmpLastName(String empLastName) {
        this.empLastName = empLastName;
    }

    /**
     * @return the respUnit
     */
    public String getRespUnit() {
        return respUnit;
    }

    /**
     * @param respUnit the respUnit to set
     */
    public void setRespUnit(String respUnit) {
        this.respUnit = respUnit;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the lastLoginDate
     */
    public java.util.Date getLastLoginDate() {
        return lastLoginDate;
    }

    /**
     * @param lastLoginDate the lastLoginDate to set
     */
    public void setLastLoginDate(java.util.Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    /**
     * @return the lastLogoutDate
     */
    public java.util.Date getLastLogoutDate() {
        return lastLogoutDate;
    }

    /**
     * @param lastLogoutDate the lastLogoutDate to set
     */
    public void setLastLogoutDate(java.util.Date lastLogoutDate) {
        this.lastLogoutDate = lastLogoutDate;
    }

    /**
     * @return the empTitleDesc
     */
    public String getEmpTitleDesc() {
        return empTitleDesc;
    }

    /**
     * @param empTitleDesc the empTitleDesc to set
     */
    public void setEmpTitleDesc(String empTitleDesc) {
        this.empTitleDesc = empTitleDesc;
    }

    /**
     * @return the deptCd
     */
    public String getDeptCd() {
        return deptCd;
    }

    /**
     * @param deptCd the deptCd to set
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the userTeamRoleList
     */
    public ArrayList<MtUserTeamRoleVo> getUserTeamRoleList() {
        return userTeamRoleList;
    }

    /**
     * @param userTeamRoleList the userTeamRoleList to set
     */
    public void setUserTeamRoleList(ArrayList<MtUserTeamRoleVo> userTeamRoleList) {
        this.userTeamRoleList = userTeamRoleList;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public MtUserTeamRoleVo getUserTeamRole() {
        return userTeamRole;
    }

    public void setUserTeamRole(MtUserTeamRoleVo userTeamRole) {
        this.userTeamRole = userTeamRole;
    }

    /**
     * @return the costCenter
     */
    public String getCostCenter() {
        return costCenter;
    }

    /**
     * @param costCenter the costCenter to set
     */
    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    /**
     * @return the costCenterDesc
     */
    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    /**
     * @param costCenterDesc the costCenterDesc to set
     */
    public void setCostCenterDesc(String costCenterDesc) {
        this.costCenterDesc = costCenterDesc;
    }

    /**
     * @return the respUnitDesc
     */
    public String getRespUnitDesc() {
        return respUnitDesc;
    }

    /**
     * @param respUnitDesc the respUnitDesc to set
     */
    public void setRespUnitDesc(String respUnitDesc) {
        this.respUnitDesc = respUnitDesc;
    }

    /**
     * @return the deptDesc
     */
    public String getDeptDesc() {
        return deptDesc;
    }

    /**
     * @param deptDesc the deptDesc to set
     */
    public void setDeptDesc(String deptDesc) {
        this.deptDesc = deptDesc;
    }

    /**
     * @return the rankCode
     */
    public String getRankCode() {
        return rankCode;
    }

    /**
     * @param rankCode the rankCode to set
     */
    public void setRankCode(String rankCode) {
        this.rankCode = rankCode;
    }

    /**
     * @return the rankDesc
     */
    public String getRankDesc() {
        return rankDesc;
    }

    /**
     * @param rankDesc the rankDesc to set
     */
    public void setRankDesc(String rankDesc) {
        this.rankDesc = rankDesc;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the abstype
     */
    public String getAbstype() {
        return abstype;
    }

    /**
     * @param abstype the abstype to set
     */
    public void setAbstype(String abstype) {
        this.abstype = abstype;
    }

    /**
     * @return the appflag
     */
    public String getAppflag() {
        return appflag;
    }

    /**
     * @param appflag the appflag to set
     */
    public void setAppflag(String appflag) {
        this.appflag = appflag;
    }

    /**
     * @return the beginflag
     */
    public String getBeginflag() {
        return beginflag;
    }

    /**
     * @param beginflag the beginflag to set
     */
    public void setBeginflag(String beginflag) {
        this.beginflag = beginflag;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the endflag
     */
    public String getEndflag() {
        return endflag;
    }

    /**
     * @param endflag the endflag to set
     */
    public void setEndflag(String endflag) {
        this.endflag = endflag;
    }

    /**
     * @return the leaveflag
     */
    public String getLeaveflag() {
        return leaveflag;
    }

    /**
     * @param leaveflag the leaveflag to set
     */
    public void setLeaveflag(String leaveflag) {
        this.leaveflag = leaveflag;
    }

    /**
     * @return the empFullName
     */
    public String getEmpFullName() {
        return empFullName;
    }

    /**
     * @param empFullName the empFullName to set
     */
    public void setEmpFullName(String empFullName) {
        this.empFullName = empFullName;
    }

    /**
     * @return the isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    /**
     * @return the roleDesc
     */
    public String getRoleDesc() {
        return roleDesc;
    }

    /**
     * @param roleDesc the roleDesc to set
     */
    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    /**
     * @return the isActiveDesc
     */
    public String getIsActiveDesc() {
        return isActiveDesc;
    }

    /**
     * @param isActiveDesc the isActiveDesc to set
     */
    public void setIsActiveDesc(String isActiveDesc) {
        this.isActiveDesc = isActiveDesc;
    }

    public String getEmployedStatus() {
        return employedStatus;
    }

    public void setEmployedStatus(String employedStatus) {
        this.employedStatus = employedStatus;
    }
}
