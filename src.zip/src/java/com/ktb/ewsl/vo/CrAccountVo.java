/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.StringUtil;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;

/**
 *
 * @author Tum_Surapong
 */
public class CrAccountVo implements Serializable{
    
    private ArrayList<CrAccountDetailVo> crAccountDetailVoList;
    
    private BigDecimal sumLimitAmt;
    private BigDecimal sumOutsBal;
    private String sumLimitAmtS;
    private String sumOutsBalS;
    private String worthC;
    private String downloadDateS;

    public ArrayList<CrAccountDetailVo> getCrAccountDetailVoList() {
        return crAccountDetailVoList;
    }

    public void setCrAccountDetailVoList(ArrayList<CrAccountDetailVo> crAccountDetailVoList) {
        this.crAccountDetailVoList = crAccountDetailVoList;
    }

  

    public BigDecimal getSumLimitAmt() {
        return sumLimitAmt;
    }

    public void setSumLimitAmt(BigDecimal sumLimitAmt) {
        this.sumLimitAmt = sumLimitAmt;
    }

    public BigDecimal getSumOutsBal() {
        return sumOutsBal;
    }

    public void setSumOutsBal(BigDecimal sumOutsBal) {
        this.sumOutsBal = sumOutsBal;
    }

    public String getSumLimitAmtS() {
        if(getSumLimitAmt() != null){
            return StringUtil.formatCurrentcy(getSumLimitAmt());
        }
        return "-";
    }

    public String getSumOutsBalS() {
        if(getSumOutsBal() != null){
            return StringUtil.formatCurrentcy(getSumOutsBal());
        }
        return "-";
    } 

    public String getWorthC() {
        return worthC;
    }

    public void setWorthC(String worthC) {
        this.worthC = worthC;
    }

    public String getDownloadDateS() {
        return downloadDateS;
    }

    public void setDownloadDateS(String downloadDateS) {
        this.downloadDateS = downloadDateS;
    }
    
}
