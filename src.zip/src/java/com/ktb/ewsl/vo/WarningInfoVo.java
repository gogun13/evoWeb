/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;
import java.util.TreeMap;

/**
 *
 * @author KTBDevLoan
 */
public class WarningInfoVo  extends BaseVo{
    
    private String riskLevel;
    private String status;
    private int warningHeaderId;
    private Integer warningId;
    private String warningType;
    private String slaStr;
    private Date warningDate;
    private String warningDateStr;
    private String cifNo;
    private BigDecimal score; 
    private BigDecimal pd;
    private BigDecimal odds;
    private String approveBy;
    private String approveDateStr;  
    private int sla;
    private Date slaDueDate;
    private String slaDueDateStr;
    private String trigShowFlag;
    private String trigGenFlag;
    private WarningTypeVo warningTypeVo;
    private String version;
    private String questionId;
    private String qualiSendFlag;
    private String questionVersionFlag; // Y = Same , N = New Version
    private String trigPayResult;
    private TreeMap<String, String> responsibleList = new TreeMap<String, String>(); // ROLE : PERSON List>()
    private String holderId;
    private String holderRole;
    private String closeFlag;
    private String slaFlag;
    private String answerQuestionVersion; //QUESTION_VERSION
    private String answerQuestionId; //QUESTION_ID
    private Integer qualiWarningId;  //QUALI_WARNING_ID
    private String amdFlg;
    private String latePayLevel;
    private String latePayAdvice;
    private String bcmLatePayLevel;
    private String bcmLatePayAdvice;
    private String warningTypeDesc;
    private String confirmLatePay;
    private String bcmConfirmLatePay;
    private String bcmAmdFlg;
    private String roleCode;
    private int slaMaster;
    
    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }


    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }


    public String getSlaStr() {
        return slaStr;
    }

    public void setSlaStr(String slaStr) {
        this.slaStr = slaStr;
    }

    public String getWarningDateStr() {
        return warningDateStr;
    }

    public void setWarningDateStr(String warningDateStr) {
        this.warningDateStr = warningDateStr;
    }

    public Date getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(Date warningDate) {
        this.warningDate = warningDate;
    }

    public Integer getWarningId() {
        return warningId;
    }

    public void setWarningId(Integer warningId) {
        this.warningId = warningId;
    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public BigDecimal getScore() {
        return score;
    }

    public void setScore(BigDecimal score) {
        this.score = score;
    }

    public BigDecimal getPd() {
        return pd;
    }

    public void setPd(BigDecimal pd) {
        this.pd = pd;
    }

    public BigDecimal getOdds() {
        return odds;
    }

    public void setOdds(BigDecimal odds) {
        this.odds = odds;
    }

    public WarningTypeVo getWarningTypeVo() {
        return warningTypeVo;
    }

    public void setWarningTypeVo(WarningTypeVo warningTypeVo) {
        this.warningTypeVo = warningTypeVo;
    }

    public String getApproveBy() {
        return approveBy;
    }

    public void setApproveBy(String approveBy) {
        this.approveBy = approveBy;
    }

    public String getApproveDateStr() {
        return approveDateStr;
    }

    public void setApproveDateStr(String approveDateStr) {
        this.approveDateStr = approveDateStr;
    }

    public int getSla() {
        return sla;
    }

    public void setSla(int sla) {
        this.sla = sla;
    }

    public Date getSlaDueDate() {
        return slaDueDate;
    }

    public void setSlaDueDate(Date slaDueDate) {
        this.slaDueDate = slaDueDate;
    }

    public String getSlaDueDateStr() {
        return slaDueDateStr;
    }

    public void setSlaDueDateStr(String slaDueDateStr) {
        this.slaDueDateStr = slaDueDateStr;
    }

    public String getTrigShowFlag() {
        return trigShowFlag;
    }

    public void setTrigShowFlag(String trigShowFlag) {
        this.trigShowFlag = trigShowFlag;
    }

    public String getTrigGenFlag() {
        return trigGenFlag;
    }

    public void setTrigGenFlag(String trigGenFlag) {
        this.trigGenFlag = trigGenFlag;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getQualiSendFlag() {
        return qualiSendFlag;
    }

    public void setQualiSendFlag(String qualiSendFlag) {
        this.qualiSendFlag = qualiSendFlag;
    }

    public String getQuestionVersionFlag() {
        return questionVersionFlag;
    }

    public void setQuestionVersionFlag(String questionVersionFlag) {
        this.questionVersionFlag = questionVersionFlag;
    }

    public String getTrigPayResult() {
        return trigPayResult;
    }

    public void setTrigPayResult(String trigPayResult) {
        this.trigPayResult = trigPayResult;
    }

    public TreeMap<String, String> getResponsibleList() {
        return responsibleList;
    }

    public void setResponsibleList(TreeMap<String, String> responsibleList) {
        this.responsibleList = responsibleList;
    }


    public String getHolderId() {
        return holderId;
    }

    public void setHolderId(String holderId) {
        this.holderId = holderId;
    }

    public String getHolderRole() {
        return holderRole;
    }

    public void setHolderRole(String holderRole) {
        this.holderRole = holderRole;
    }

    public String getCloseFlag() {
        return closeFlag;
    }

    public void setCloseFlag(String closeFlag) {
        this.closeFlag = closeFlag;
    }

    public String getSlaFlag() {
        return slaFlag;
    }

    public void setSlaFlag(String slaFlag) {
        this.slaFlag = slaFlag;
    }

    public String getAnswerQuestionVersion() {
        return answerQuestionVersion;
    }

    public void setAnswerQuestionVersion(String answerQuestionVersion) {
        this.answerQuestionVersion = answerQuestionVersion;
    }

    public String getAnswerQuestionId() {
        return answerQuestionId;
    }

    public void setAnswerQuestionId(String answerQuestionId) {
        this.answerQuestionId = answerQuestionId;
    }

    public Integer getQualiWarningId() {
        return qualiWarningId;
    }

    public void setQualiWarningId(Integer qualiWarningId) {
        this.qualiWarningId = qualiWarningId;
    }

    public String getAmdFlg() {
        return amdFlg;
    }

    public void setAmdFlg(String amdFlg) {
        this.amdFlg = amdFlg;
    }

    public String getLatePayLevel() {
        return latePayLevel;
    }

    public void setLatePayLevel(String latePayLevel) {
        this.latePayLevel = latePayLevel;
    }

    public String getLatePayAdvice() {
        return latePayAdvice;
    }

    public void setLatePayAdvice(String latePayAdvice) {
        this.latePayAdvice = latePayAdvice;
    }

    public String getBcmLatePayLevel() {
        return bcmLatePayLevel;
    }

    public void setBcmLatePayLevel(String bcmLatePayLevel) {
        this.bcmLatePayLevel = bcmLatePayLevel;
    }

    public String getBcmLatePayAdvice() {
        return bcmLatePayAdvice;
    }

    public void setBcmLatePayAdvice(String bcmLatePayAdvice) {
        this.bcmLatePayAdvice = bcmLatePayAdvice;
    }

    public String getWarningTypeDesc() {
        return warningTypeDesc;
    }

    public void setWarningTypeDesc(String warningTypeDesc) {
        this.warningTypeDesc = warningTypeDesc;
    }

    public String getConfirmLatePay() {
        return confirmLatePay;
    }

    public void setConfirmLatePay(String confirmLatePay) {
        this.confirmLatePay = confirmLatePay;
    }

    public String getBcmConfirmLatePay() {
        return bcmConfirmLatePay;
    }

    public void setBcmConfirmLatePay(String bcmConfirmLatePay) {
        this.bcmConfirmLatePay = bcmConfirmLatePay;
    }

    public String getBcmAmdFlg() {
        return bcmAmdFlg;
    }

    public void setBcmAmdFlg(String bcmAmdFlg) {
        this.bcmAmdFlg = bcmAmdFlg;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public int getSlaMaster() {
        return slaMaster;
    }

    public void setSlaMaster(int slaMaster) {
        this.slaMaster = slaMaster;
    }

   
    
}
