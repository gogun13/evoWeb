/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Tum_Surapong
 */
public class ActionCloseVo implements Serializable{
    private Integer warningHeadId;
    private Integer warningId;
    private Date actionDt;
    private String actionDtS;
    private String actionBy;
    private String reasonCode;
    private String reasonDetail;
    private String status;
    private String remark;
    private String closeJobType;
    private String roleCode;

    public Integer getWarningHeadId() {
        return warningHeadId;
    }

    public void setWarningHeadId(Integer warningHeadId) {
        this.warningHeadId = warningHeadId;
    }

    public Date getActionDt() {
        return actionDt;
    }

    public void setActionDt(Date actionDt) {
        this.actionDt = actionDt;
    }

    public String getActionDtS() {
        if(getActionDt() != null){
            return DateUtil.getDateTimeInThaiFormat(getActionDt(),"");
        }
        return "";
    }

    public String getActionBy() {
        return actionBy;
    }

    public void setActionBy(String actionBy) {
        this.actionBy = actionBy;
    }

    public String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public String getReasonDetail() {
        return reasonDetail;
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getWarningId() {
        return warningId;
    }

    public void setWarningId(Integer warningId) {
        this.warningId = warningId;
    }

    public String getCloseJobType() {
        return closeJobType;
    }

    public void setCloseJobType(String closeJobType) {
        this.closeJobType = closeJobType;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
    
    
}
