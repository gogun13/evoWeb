/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class CustomerPortfolioVo extends BaseVo{
    
    private Integer warningHeaderId;
    private Integer cif;
    private Date warningDate;
    private String warningDateStr;
    private String status;
    private Integer maxDpd;
    private String maxDpdStrFormat;
    private String ewsRiskLevel;
    private String quantiBehavModle;
    private String qualitativeAssessment;
    private String creditReviewFlag;
    private String turaroundFlag;
    private String custName;
    private String rmId;
    private String aeId; 
    private String aoId; 
    private String responseUnit;
    private String costcenterName;
    private String businessUnitCode;
    private String groupCode;
    private String costcenterCode;
    private String amdResponseUnit;
    private int index ;

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public Integer getCif() {
        return cif;
    }

    public void setCif(Integer cif) {
        this.cif = cif;
    }

    public Date getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(Date warningDate) {
        this.warningDate = warningDate;
    }

    public String getWarningDateStr() {
        return warningDateStr;
    }

    public void setWarningDateStr(String warningDateStr) {
        this.warningDateStr = warningDateStr;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getMaxDpd() {
        return maxDpd;
    }

    public void setMaxDpd(Integer maxDpd) {
        this.maxDpd = maxDpd;
    }

    public String getEwsRiskLevel() {
        return ewsRiskLevel;
    }

    public void setEwsRiskLevel(String ewsRiskLevel) {
        this.ewsRiskLevel = ewsRiskLevel;
    }

    public String getQuantiBehavModle() {
        return quantiBehavModle;
    }

    public void setQuantiBehavModle(String quantiBehavModle) {
        this.quantiBehavModle = quantiBehavModle;
    }

    public String getQualitativeAssessment() {
        return qualitativeAssessment;
    }

    public void setQualitativeAssessment(String qualitativeAssessment) {
        this.qualitativeAssessment = qualitativeAssessment;
    }

  

    public String getCreditReviewFlag() {
        return creditReviewFlag;
    }

    public void setCreditReviewFlag(String creditReviewFlag) {
        this.creditReviewFlag = creditReviewFlag;
    }

    public String getTuraroundFlag() {
        return turaroundFlag;
    }

    public void setTuraroundFlag(String turaroundFlag) {
        this.turaroundFlag = turaroundFlag;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public String getAeId() {
        return aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public String getResponseUnit() {
        return responseUnit;
    }

    public void setResponseUnit(String responseUnit) {
        this.responseUnit = responseUnit;
    }

    public String getCostcenterName() {
        return costcenterName;
    }

    public void setCostcenterName(String costcenterName) {
        this.costcenterName = costcenterName;
    }

    public String getBusinessUnitCode() {
        return businessUnitCode;
    }

    public void setBusinessUnitCode(String businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getCostcenterCode() {
        return costcenterCode;
    }

    public void setCostcenterCode(String costcenterCode) {
        this.costcenterCode = costcenterCode;
    }

    public String getMaxDpdStrFormat() {
        return maxDpdStrFormat;
    }

    public void setMaxDpdStrFormat(String maxDpdStrFormat) {
        this.maxDpdStrFormat = maxDpdStrFormat;
    }

    public String getAoId() {
        return aoId;
    }

    public void setAoId(String aoId) {
        this.aoId = aoId;
    }

    public String getAmdResponseUnit() {
        return amdResponseUnit;
    }

    public void setAmdResponseUnit(String amdResponseUnit) {
        this.amdResponseUnit = amdResponseUnit;
    }

  
    
    
}

