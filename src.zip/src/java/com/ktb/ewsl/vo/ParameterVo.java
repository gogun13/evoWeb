/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class ParameterVo extends BaseVo{
    
    private String parameterId;
    private String parameterName;
    private String parameterTypeId;
    private BigDecimal value1;
    private BigDecimal value2;
    private String value3;
    private Date value4;
    private String strValue4;
    private BigDecimal isActive;

    public String getParameterId() {
        return parameterId;
    }

    public void setParameterId(String parameterId) {
        this.parameterId = parameterId;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public String getParameterTypeId() {
        return parameterTypeId;
    }

    public void setParameterTypeId(String parameterTypeId) {
        this.parameterTypeId = parameterTypeId;
    }

    public BigDecimal getValue1() {
        return value1;
    }

    public void setValue1(BigDecimal value1) {
        this.value1 = value1;
    }

    public BigDecimal getValue2() {
        return value2;
    }

    public void setValue2(BigDecimal value2) {
        this.value2 = value2;
    }

    public String getValue3() {
        return value3;
    }

    public void setValue3(String value3) {
        this.value3 = value3;
    }

    public Date getValue4() {
        return value4;
    }

    public void setValue4(Date value4) {
        this.value4 = value4;
    }

    public String getStrValue4() {
        return strValue4;
    }

    public void setStrValue4(String strValue4) {
        this.strValue4 = strValue4;
    }

    public BigDecimal getIsActive() {
        return isActive;
    }

    public void setIsActive(BigDecimal isActive) {
        this.isActive = isActive;
    }

    
        
}
