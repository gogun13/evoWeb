/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class WarningTypePrivilegeVo extends BaseVo {
    
   private String roleCode;
   private String warningTypeCode;

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getWarningTypeCode() {
        return warningTypeCode;
    }

    public void setWarningTypeCode(String warningTypeCode) {
        this.warningTypeCode = warningTypeCode;
    }

   
        
}
