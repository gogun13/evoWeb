/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Tum_Surapong
 */
public class AccountVo implements Serializable{
    private String appId;
    private String contractDt;
    private String accountNo;
    private String accountName;
    private String accountBranch;
    private String accountBranchDesc;
    private String accountType;
    private String accountAvaiBal;
    private String accountOutsBal;
    private String accountIntReceive;
    private String accountIntSuspense;
    private String accountCostCenter;
    private String accountFixedPrinAmt;
    private String accountPIPayment;
    private String accountDtOpened;
    private String accountProductGrp;
    private String accountProductGrpDesc;
    private String accountProductType;
    private String accountProductTypeDesc;
    private String accountMarketCd;
    private String accountMarketCdDesc;
    private String accountLimitAmt;
    private String accountContractDt;
    private String accountExpiryDt;
    private String masterAccountNo;
    private ArrayList accountSequence;
    private ArrayList accountOriginalAmount;

    //    private LineItem[] lineItem;
    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getContractDt() {
        return contractDt;
    }

    public void setContractDt(String contractDt) {
        this.contractDt = contractDt;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountBranch() {
        return accountBranch;
    }

    public void setAccountBranch(String accountBranch) {
        this.accountBranch = accountBranch;
    }

    public String getAccountBranchDesc() {
        return accountBranchDesc;
    }

    public void setAccountBranchDesc(String accountBranchDesc) {
        this.accountBranchDesc = accountBranchDesc;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountAvaiBal() {
        return accountAvaiBal;
    }

    public void setAccountAvaiBal(String accountAvaiBal) {
        this.accountAvaiBal = accountAvaiBal;
    }

    public String getAccountOutsBal() {
        return accountOutsBal;
    }

    public void setAccountOutsBal(String accountOutsBal) {
        this.accountOutsBal = accountOutsBal;
    }

    public String getAccountIntReceive() {
        return accountIntReceive;
    }

    public void setAccountIntReceive(String accountIntReceive) {
        this.accountIntReceive = accountIntReceive;
    }

    public String getAccountIntSuspense() {
        return accountIntSuspense;
    }

    public void setAccountIntSuspense(String accountIntSuspense) {
        this.accountIntSuspense = accountIntSuspense;
    }

    public String getAccountCostCenter() {
        return accountCostCenter;
    }

    public void setAccountCostCenter(String accountCostCenter) {
        this.accountCostCenter = accountCostCenter;
    }

    public String getAccountFixedPrinAmt() {
        return accountFixedPrinAmt;
    }

    public void setAccountFixedPrinAmt(String accountFixedPrinAmt) {
        this.accountFixedPrinAmt = accountFixedPrinAmt;
    }

    public String getAccountPIPayment() {
        return accountPIPayment;
    }

    public void setAccountPIPayment(String accountPIPayment) {
        this.accountPIPayment = accountPIPayment;
    }

    public String getAccountDtOpened() {
        return accountDtOpened;
    }

    public void setAccountDtOpened(String accountDtOpened) {
        this.accountDtOpened = accountDtOpened;
    }

    public String getAccountProductGrp() {
        return accountProductGrp;
    }

    public void setAccountProductGrp(String accountProductGrp) {
        this.accountProductGrp = accountProductGrp;
    }

    public String getAccountProductGrpDesc() {
        return accountProductGrpDesc;
    }

    public void setAccountProductGrpDesc(String accountProductGrpDesc) {
        this.accountProductGrpDesc = accountProductGrpDesc;
    }

    public String getAccountProductType() {
        return accountProductType;
    }

    public void setAccountProductType(String accountProductType) {
        this.accountProductType = accountProductType;
    }

    public String getAccountProductTypeDesc() {
        return accountProductTypeDesc;
    }

    public void setAccountProductTypeDesc(String accountProductTypeDesc) {
        this.accountProductTypeDesc = accountProductTypeDesc;
    }

    public String getAccountMarketCd() {
        return accountMarketCd;
    }

    public void setAccountMarketCd(String accountMarketCd) {
        this.accountMarketCd = accountMarketCd;
    }

    public String getAccountMarketCdDesc() {
        return accountMarketCdDesc;
    }

    public void setAccountMarketCdDesc(String accountMarketCdDesc) {
        this.accountMarketCdDesc = accountMarketCdDesc;
    }

    public String getAccountLimitAmt() {
        return accountLimitAmt;
    }

    public void setAccountLimitAmt(String accountLimitAmt) {
        this.accountLimitAmt = accountLimitAmt;
    }

    public String getAccountContractDt() {
        return accountContractDt;
    }

    public void setAccountContractDt(String accountContractDt) {
        this.accountContractDt = accountContractDt;
    }

    public String getAccountExpiryDt() {
        return accountExpiryDt;
    }

    public void setAccountExpiryDt(String accountExpiryDt) {
        this.accountExpiryDt = accountExpiryDt;
    }

    public String getMasterAccountNo() {
        return masterAccountNo;
    }

    public void setMasterAccountNo(String masterAccountNo) {
        this.masterAccountNo = masterAccountNo;
    }

    public ArrayList getAccountSequence() {
        return accountSequence;
    }

    public void setAccountSequence(ArrayList accountSequence) {
        this.accountSequence = accountSequence;
    }

    public ArrayList getAccountOriginalAmount() {
        return accountOriginalAmount;
    }

    public void setAccountOriginalAmount(ArrayList accountOriginalAmount) {
        this.accountOriginalAmount = accountOriginalAmount;
    }

   
    
}
