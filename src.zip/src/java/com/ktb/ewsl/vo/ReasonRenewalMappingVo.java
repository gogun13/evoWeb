/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author KTBDevLoan
 */
public class ReasonRenewalMappingVo {
    private String reasonRenewalSAS;
    private String reasonRenewScore;
    private String typesFlg;

    public String getReasonRenewalSAS() {
        return reasonRenewalSAS;
    }

    public void setReasonRenewalSAS(String reasonRenewalSAS) {
        this.reasonRenewalSAS = reasonRenewalSAS;
    }

    public String getReasonRenewScore() {
        return reasonRenewScore;
    }

    public void setReasonRenewScore(String reasonRenewScore) {
        this.reasonRenewScore = reasonRenewScore;
    }

    public String getTypesFlg() {
        return typesFlg;
    }

    public void setTypesFlg(String typesFlg) {
        this.typesFlg = typesFlg;
    }
   
    
}
