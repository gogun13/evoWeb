/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author aon
 */
public class MenuLevelVo implements Serializable {
    private int level;
    private ArrayList<MenuInfoVo> menuInfoList;



    public MenuLevelVo(int level){
        menuInfoList = new ArrayList<MenuInfoVo>();
        this.level = level;
    }
    /**
     * @return the level
     */
    public int getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(int level) {
        this.level = level;
    }

    /**
     * @return the menuInfoList
     */
    public ArrayList<MenuInfoVo> getMenuInfoList() {
        return menuInfoList;
    }

    /**
     * @param menuInfoList the menuInfoList to set
     */
    public void setMenuInfoList(ArrayList<MenuInfoVo> menuInfoList) {
        this.menuInfoList = menuInfoList;
    }

}
