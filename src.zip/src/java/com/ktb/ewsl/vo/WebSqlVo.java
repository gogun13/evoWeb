/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public class WebSqlVo implements Serializable{
    
    private String flag;
    private ArrayList<String> columnNames;
    private ArrayList<HashMap<String, Object>> rowList;
    private int returnRows;
    private String sqlCommand;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public ArrayList<String> getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(ArrayList<String> columnNames) {
        this.columnNames = columnNames;
    }

    public ArrayList<HashMap<String, Object>> getRowList() {
        return rowList;
    }

    public void setRowList(ArrayList<HashMap<String, Object>> rowList) {
        this.rowList = rowList;
    }

   

    public int getReturnRows() {
        return returnRows;
    }

    public void setReturnRows(int returnRows) {
        this.returnRows = returnRows;
    }

    public String getSqlCommand() {
        return sqlCommand;
    }

    public void setSqlCommand(String sqlCommand) {
        this.sqlCommand = sqlCommand;
    }
    
    
    
}
