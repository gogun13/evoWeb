/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public class CrAccountInterestVo implements Serializable{
    private Integer warningHeaderId;
    private String acctNo;
    private Date startDt;
    private Date endDt;
    private String intRateTypeCd;
    private String intRateTypeDesc;
    private double rateDiffAmt;
    private int seq;
    private BigDecimal computeRate;
    private String computeRateStr; // สำหรับแสดงบนหน้าจอที่มีเลขทศหลายหลัก
    private BigDecimal value;
    private String activateFlg;
    private String courtOrderFlg;
    private String activeFlg;
    private String intType;
    private String intTypeDesc;
    private BigDecimal intRate;
    private int cnt;
    private String relAcctNo;
    private ArrayList<CrSubAccountVo> subAccountList;

    private String relIndexCd;
    private String relTerm;
    private String createdBy;
    private Date createdDt;

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public Date getStartDt() {
        return startDt;
    }

    public void setStartDt(Date startDt) {
        this.startDt = startDt;
    }

    public Date getEndDt() {
        return endDt;
    }

    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }

    public String getIntRateTypeCd() {
        return intRateTypeCd;
    }

    public void setIntRateTypeCd(String intRateTypeCd) {
        this.intRateTypeCd = intRateTypeCd;
    }

    public String getIntRateTypeDesc() {
        return intRateTypeDesc;
    }

    public void setIntRateTypeDesc(String intRateTypeDesc) {
        this.intRateTypeDesc = intRateTypeDesc;
    }

    public double getRateDiffAmt() {
        return rateDiffAmt;
    }

    public void setRateDiffAmt(double rateDiffAmt) {
        this.rateDiffAmt = rateDiffAmt;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public BigDecimal getComputeRate() {
        return computeRate;
    }

    public void setComputeRate(BigDecimal computeRate) {
        this.computeRate = computeRate;
    }

    public String getComputeRateStr() {
        return computeRateStr;
    }

    public void setComputeRateStr(String computeRateStr) {
        this.computeRateStr = computeRateStr;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public String getActivateFlg() {
        return activateFlg;
    }

    public void setActivateFlg(String activateFlg) {
        this.activateFlg = activateFlg;
    }

    public String getCourtOrderFlg() {
        return courtOrderFlg;
    }

    public void setCourtOrderFlg(String courtOrderFlg) {
        this.courtOrderFlg = courtOrderFlg;
    }

    public String getActiveFlg() {
        return activeFlg;
    }

    public void setActiveFlg(String activeFlg) {
        this.activeFlg = activeFlg;
    }

    public String getIntType() {
        return intType;
    }

    public void setIntType(String intType) {
        this.intType = intType;
    }

    public String getIntTypeDesc() {
        return intTypeDesc;
    }

    public void setIntTypeDesc(String intTypeDesc) {
        this.intTypeDesc = intTypeDesc;
    }

    public BigDecimal getIntRate() {
        return intRate;
    }

    public void setIntRate(BigDecimal intRate) {
        this.intRate = intRate;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public String getRelAcctNo() {
        return relAcctNo;
    }

    public void setRelAcctNo(String relAcctNo) {
        this.relAcctNo = relAcctNo;
    }

    public ArrayList<CrSubAccountVo> getSubAccountList() {
        return subAccountList;
    }

    public void setSubAccountList(ArrayList<CrSubAccountVo> subAccountList) {
        this.subAccountList = subAccountList;
    }

   
    public String getRelIndexCd() {
        return relIndexCd;
    }

    public void setRelIndexCd(String relIndexCd) {
        this.relIndexCd = relIndexCd;
    }

    public String getRelTerm() {
        return relTerm;
    }

    public void setRelTerm(String relTerm) {
        this.relTerm = relTerm;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }
    
}
