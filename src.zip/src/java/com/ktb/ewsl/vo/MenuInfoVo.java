/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author aon
 */
public class MenuInfoVo implements Serializable, Cloneable {

    private String menuId;
    private String menuUnder;
    private Integer menuLevel;
    private Integer menuSeq;
    private String menuLabel;
    private Integer menuType;
    private String mainMenuFlg;
    private String menuGroup;
    private String actionName;
    private String commandName;
    private String menuRemark;
    private Integer isActive;
    private String isCurrent;
    private String mainMenuId;
    private String previousMenuId;
    private String nextMenuId;
    private String level;
    private String divTarget;
    private String link;
    private Integer width;
    private ArrayList<MenuInfoVo> childMenuList;

    private String linkParam;
    private int autoShowFlg;

    private String action;

    @Override
    public MenuInfoVo clone() throws CloneNotSupportedException {
        MenuInfoVo clone = (MenuInfoVo) super.clone();
        return clone;
    }

    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }

    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    /**
     * @return the menuUnder
     */
    public String getMenuUnder() {
        return menuUnder;
    }

    /**
     * @param menuUnder the menuUnder to set
     */
    public void setMenuUnder(String menuUnder) {
        this.menuUnder = menuUnder;
    }

    /**
     * @return the menuLevel
     */
    public Integer getMenuLevel() {
        return menuLevel;
    }

    /**
     * @param menuLevel the menuLevel to set
     */
    public void setMenuLevel(Integer menuLevel) {
        this.menuLevel = menuLevel;
    }

    /**
     * @return the menuSeq
     */
    public Integer getMenuSeq() {
        return menuSeq;
    }

    /**
     * @param menuSeq the menuSeq to set
     */
    public void setMenuSeq(Integer menuSeq) {
        this.menuSeq = menuSeq;
    }

    /**
     * @return the menuLabel
     */
    public String getMenuLabel() {
        return menuLabel;
    }

    /**
     * @param menuLabel the menuLabel to set
     */
    public void setMenuLabel(String menuLabel) {
        this.menuLabel = menuLabel;
    }

    /**
     * @return the menuType
     */
    public Integer getMenuType() {
        return menuType;
    }

    /**
     * @param menuType the menuType to set
     */
    public void setMenuType(Integer menuType) {
        this.menuType = menuType;
    }

    /**
     * @return the mainMenuFlg
     */
    public String getMainMenuFlg() {
        return mainMenuFlg;
    }

    /**
     * @param mainMenuFlg the mainMenuFlg to set
     */
    public void setMainMenuFlg(String mainMenuFlg) {
        this.mainMenuFlg = mainMenuFlg;
    }

    /**
     * @return the menuGroup
     */
    public String getMenuGroup() {
        return menuGroup;
    }

    /**
     * @param menuGroup the menuGroup to set
     */
    public void setMenuGroup(String menuGroup) {
        this.menuGroup = menuGroup;
    }

    /**
     * @return the actionName
     */
    public String getActionName() {
        return actionName;
    }

    /**
     * @param actionName the actionName to set
     */
    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    /**
     * @return the commandName
     */
    public String getCommandName() {
        return commandName;
    }

    /**
     * @param commandName the commandName to set
     */
    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }

    /**
     * @return the menuRemark
     */
    public String getMenuRemark() {
        return menuRemark;
    }

    /**
     * @param menuRemark the menuRemark to set
     */
    public void setMenuRemark(String menuRemark) {
        this.menuRemark = menuRemark;
    }

    /**
     * @return the isActive
     */
    public Integer getIsActive() {
        return isActive;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the divTarget
     */
    public String getDivTarget() {
        return divTarget;
    }

    /**
     * @param divTarget the divTarget to set
     */
    public void setDivTarget(String divTarget) {
        this.divTarget = divTarget;
    }

    /**
     * @return the mainMenuId
     */
    public String getMainMenuId() {
        return mainMenuId;
    }

    /**
     * @param mainMenuId the mainMenuId to set
     */
    public void setMainMenuId(String mainMenuId) {
        this.mainMenuId = mainMenuId;
    }

    /**
     * @return the childMenuList
     */
    public ArrayList<MenuInfoVo> getChildMenuList() {
        return childMenuList;
    }

    /**
     * @param childMenuList the childMenuList to set
     */
    public void setChildMenuList(ArrayList<MenuInfoVo> childMenuList) {
        this.childMenuList = childMenuList;
    }

    /**
     * @return the isCurrent
     */
    public String getIsCurrent() {
        return isCurrent;
    }

    /**
     * @param isCurrent the isCurrent to set
     */
    public void setIsCurrent(String isCurrent) {
        this.isCurrent = isCurrent;
    }

    /**
     * @return the link
     */
    public String getLink() {
        return link;
    }

    /**
     * @param link the link to set
     */
    public void setLink(String link) {
        this.link = link;
    }

    /**
     * @return the previousMenuId
     */
    public String getPreviousMenuId() {
        return previousMenuId;
    }

    /**
     * @param previousMenuId the previousMenuId to set
     */
    public void setPreviousMenuId(String previousMenuId) {
        this.previousMenuId = previousMenuId;
    }

    /**
     * @return the nextMenuId
     */
    public String getNextMenuId() {
        return nextMenuId;
    }

    /**
     * @param nextMenuId the nextMenuId to set
     */
    public void setNextMenuId(String nextMenuId) {
        this.nextMenuId = nextMenuId;
    }

    /**
     * @return the width
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * @param width the width to set
     */
    public void setWidth(Integer width) {
        this.width = width;
    }

    /**
     * @return the linkParam
     */
    public String getLinkParam() {
        return linkParam;
    }

    /**
     * @param linkParam the linkParam to set
     */
    public void setLinkParam(String linkParam) {
        this.linkParam = linkParam;
    }

    /**
     * @return the autoShowFlg
     */
    public int getAutoShowFlg() {
        return autoShowFlg;
    }

    /**
     * @param autoShowFlg the autoShowFlg to set
     */
    public void setAutoShowFlg(int autoShowFlg) {
        this.autoShowFlg = autoShowFlg;
    }

    /**
     * @return the action
     */
    public String getAction() {
        if (actionName != null) {
            String[] menu = actionName.split("\\.");
            if (menu.length == 2) {
                action = menu[0];
            }
        }
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

}
