/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author pumin
 */
public class MtFormStatusVo {
    private String formStatusFlg;
    private String formStatusName;
    private String isActive;
    private String seq;

    public String getFormStatusFlg() {
        return formStatusFlg;
    }

    public void setFormStatusFlg(String formStatusFlg) {
        this.formStatusFlg = formStatusFlg;
    }

    public String getFormStatusName() {
        return formStatusName;
    }

    public void setFormStatusName(String formStatusName) {
        this.formStatusName = formStatusName;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }
    
    
    
}
