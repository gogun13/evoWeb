/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class IndividualODAccountVo extends BaseVo{
    
    private String accountNo;
    private BigDecimal avgMonthlyInt;
    private String avgMonthlyIntStr;
    private BigDecimal bookValueBalance;
    private String bookValueBalanceStr;
    private String cFinal;
    private String cif;
    private Date delinqDate;
    private String delinqDateStr;
    private Date lastBatchDate;
    private String lastBatchDateStr;
    private BigDecimal limitAmt;
    private String limitAmtStr;
    private Date maturityDate;
    private String maturityDateStr;
    private BigDecimal negAccruedAuth;
    private String negAccruedAuthStr;
    private BigDecimal negAccruedUnAuth;
    private String negAccruedUnAuthStr;
    private BigDecimal odOverLimit;
    private String odOverLimitStr;
    private BigDecimal outstandingAmt;
    private String outstandingAmtStr;
    private Date paidDate;
    private String paidDateStr;
    private BigDecimal outstandingOverLimitAmt;
    private String outstandingOverLimitAmtStr;

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public BigDecimal getAvgMonthlyInt() {
        return avgMonthlyInt;
    }

    public void setAvgMonthlyInt(BigDecimal avgMonthlyInt) {
        this.avgMonthlyInt = avgMonthlyInt;
    }

    public String getAvgMonthlyIntStr() {
        return avgMonthlyIntStr;
    }

    public void setAvgMonthlyIntStr(String avgMonthlyIntStr) {
        this.avgMonthlyIntStr = avgMonthlyIntStr;
    }

    public BigDecimal getBookValueBalance() {
        return bookValueBalance;
    }

    public void setBookValueBalance(BigDecimal bookValueBalance) {
        this.bookValueBalance = bookValueBalance;
    }

    public String getBookValueBalanceStr() {
        return bookValueBalanceStr;
    }

    public void setBookValueBalanceStr(String bookValueBalanceStr) {
        this.bookValueBalanceStr = bookValueBalanceStr;
    }

    public String getCFinal() {
        return cFinal;
    }

    public void setCFinal(String cFinal) {
        this.cFinal = cFinal;
    }


    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public Date getDelinqDate() {
        return delinqDate;
    }

    public void setDelinqDate(Date delinqDate) {
        this.delinqDate = delinqDate;
    }

    public String getDelinqDateStr() {
        return delinqDateStr;
    }

    public void setDelinqDateStr(String delinqDateStr) {
        this.delinqDateStr = delinqDateStr;
    }

    public Date getLastBatchDate() {
        return lastBatchDate;
    }

    public void setLastBatchDate(Date lastBatchDate) {
        this.lastBatchDate = lastBatchDate;
    }

    public String getLastBatchDateStr() {
        return lastBatchDateStr;
    }

    public void setLastBatchDateStr(String lastBatchDateStr) {
        this.lastBatchDateStr = lastBatchDateStr;
    }

    public BigDecimal getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(BigDecimal limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getLimitAmtStr() {
        return limitAmtStr;
    }

    public void setLimitAmtStr(String limitAmtStr) {
        this.limitAmtStr = limitAmtStr;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getMaturityDateStr() {
        return maturityDateStr;
    }

    public void setMaturityDateStr(String maturityDateStr) {
        this.maturityDateStr = maturityDateStr;
    }

    public BigDecimal getNegAccruedAuth() {
        return negAccruedAuth;
    }

    public void setNegAccruedAuth(BigDecimal negAccruedAuth) {
        this.negAccruedAuth = negAccruedAuth;
    }

    public String getNegAccruedAuthStr() {
        return negAccruedAuthStr;
    }

    public void setNegAccruedAuthStr(String negAccruedAuthStr) {
        this.negAccruedAuthStr = negAccruedAuthStr;
    }

    public BigDecimal getNegAccruedUnAuth() {
        return negAccruedUnAuth;
    }

    public void setNegAccruedUnAuth(BigDecimal negAccruedUnAuth) {
        this.negAccruedUnAuth = negAccruedUnAuth;
    }

    public String getNegAccruedUnAuthStr() {
        return negAccruedUnAuthStr;
    }

    public void setNegAccruedUnAuthStr(String negAccruedUnAuthStr) {
        this.negAccruedUnAuthStr = negAccruedUnAuthStr;
    }

    public BigDecimal getOdOverLimit() {
        return odOverLimit;
    }

    public void setOdOverLimit(BigDecimal odOverLimit) {
        this.odOverLimit = odOverLimit;
    }

    public String getOdOverLimitStr() {
        return odOverLimitStr;
    }

    public void setOdOverLimitStr(String odOverLimitStr) {
        this.odOverLimitStr = odOverLimitStr;
    }

    public BigDecimal getOutstandingAmt() {
        return outstandingAmt;
    }

    public void setOutstandingAmt(BigDecimal outstandingAmt) {
        this.outstandingAmt = outstandingAmt;
    }

    public String getOutstandingAmtStr() {
        return outstandingAmtStr;
    }

    public void setOutstandingAmtStr(String outstandingAmtStr) {
        this.outstandingAmtStr = outstandingAmtStr;
    }

    public Date getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(Date paidDate) {
        this.paidDate = paidDate;
    }

    public String getPaidDateStr() {
        return paidDateStr;
    }

    public void setPaidDateStr(String paidDateStr) {
        this.paidDateStr = paidDateStr;
    }

    public BigDecimal getOutstandingOverLimitAmt() {
        return outstandingOverLimitAmt;
    }

    public void setOutstandingOverLimitAmt(BigDecimal outstandingOverLimitAmt) {
        this.outstandingOverLimitAmt = outstandingOverLimitAmt;
    }

    public String getOutstandingOverLimitAmtStr() {
        return outstandingOverLimitAmtStr;
    }

    public void setOutstandingOverLimitAmtStr(String outstandingOverLimitAmtStr) {
        this.outstandingOverLimitAmtStr = outstandingOverLimitAmtStr;
    }



}
