/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class TrackingHistoryVo extends BaseVo{
   
    private String trackDateStr;
    //------- DB
    private int warningHeaderId;
    private String remark;
    private String trackBy;
    private Date trackDate;
    private int trackResponseUnit;
    private int trackEwsFlag;
    private int trackFinFlag;
    private int trackPayFlag;
    private int trackQcaFlag;
    private int trackTrigFlag;
    private int trackTrigAndPayFlag;

    public String getTrackDateStr() {
        return trackDateStr;
    }

    public void setTrackDateStr(String trackDateStr) {
        this.trackDateStr = trackDateStr;
    }


    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

  
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTrackBy() {
        return trackBy;
    }

    public void setTrackBy(String trackBy) {
        this.trackBy = trackBy;
    }

    public Date getTrackDate() {
        return trackDate;
    }

    public void setTrackDate(Date trackDate) {
        this.trackDate = trackDate;
    }


    public int getTrackEwsFlag() {
        return trackEwsFlag;
    }

    public void setTrackEwsFlag(int trackEwsFlag) {
        this.trackEwsFlag = trackEwsFlag;
    }

    public int getTrackFinFlag() {
        return trackFinFlag;
    }

    public void setTrackFinFlag(int trackFinFlag) {
        this.trackFinFlag = trackFinFlag;
    }

    public int getTrackPayFlag() {
        return trackPayFlag;
    }

    public void setTrackPayFlag(int trackPayFlag) {
        this.trackPayFlag = trackPayFlag;
    }

    public int getTrackQcaFlag() {
        return trackQcaFlag;
    }

    public void setTrackQcaFlag(int trackQcaFlag) {
        this.trackQcaFlag = trackQcaFlag;
    }

    public int getTrackTrigFlag() {
        return trackTrigFlag;
    }

    public void setTrackTrigFlag(int trackTrigFlag) {
        this.trackTrigFlag = trackTrigFlag;
    }

    public int getTrackResponseUnit() {
        return trackResponseUnit;
    }

    public void setTrackResponseUnit(int trackResponseUnit) {
        this.trackResponseUnit = trackResponseUnit;
    }

    public int getTrackTrigAndPayFlag() {
        return trackTrigAndPayFlag;
    }

    public void setTrackTrigAndPayFlag(int trackTrigAndPayFlag) {
        this.trackTrigAndPayFlag = trackTrigAndPayFlag;
    }
    
    
}
