/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.Date;

/**
 *
 * @author pumin
 */
public class WarningCompletionVo {
   private String completeFlg;
   private String createdBy;
   private String remark;
   private String warningHeadId;
   private Date createdDt;

    public String getCompleteFlg() {
        return completeFlg;
    }

    public void setCompleteFlg(String completeFlg) {
        this.completeFlg = completeFlg;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getWarningHeadId() {
        return warningHeadId;
    }

    public void setWarningHeadId(String warningHeadId) {
        this.warningHeadId = warningHeadId;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }
   
   
}
