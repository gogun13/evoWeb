/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.Date;

/**
 *
 * @author pumin
 */
public class CrWarningAcctVo {
    private String accountNo;
    private String accountSubType;
    private String cFinal;
    private String cif;
    private String createdBy;
    private String createdDt;
    private String limitAmt;
    private String loanType;
    private String maturityDate;
    private Date maturityDateDt;
    private String nextMaturityDate;
    private Date nextMaturityDateDt;
    private String outstandingAmt;
    private String productGroup;
    private String productType;
    private String renewDate;
    private Date renewDateDt;
    private String renewFlg;
    private String revolveFlg;
    private String sourceSystem;
    private String updatedBy;
    private Date updatedDt;
    private String warningDate;
    private Date warningDateDt;
    private String loanGrpProd;

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountSubType() {
        return accountSubType;
    }

    public void setAccountSubType(String accountSubType) {
        this.accountSubType = accountSubType;
    }

    public String getcFinal() {
        return cFinal;
    }

    public void setcFinal(String cFinal) {
        this.cFinal = cFinal;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }

    public String getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(String limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getOutstandingAmt() {
        return outstandingAmt;
    }

    public void setOutstandingAmt(String outstandingAmt) {
        this.outstandingAmt = outstandingAmt;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getRenewDate() {
        return renewDate;
    }

    public void setRenewDate(String renewDate) {
        this.renewDate = renewDate;
    }

    public String getRenewFlg() {
        return renewFlg;
    }

    public void setRenewFlg(String renewFlg) {
        this.renewFlg = renewFlg;
    }

    public String getRevolveFlg() {
        return revolveFlg;
    }

    public void setRevolveFlg(String revolveFlg) {
        this.revolveFlg = revolveFlg;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(String warningDate) {
        this.warningDate = warningDate;
    }

    public String getLoanGrpProd() {
        return loanGrpProd;
    }

    public void setLoanGrpProd(String loanGrpProd) {
        this.loanGrpProd = loanGrpProd;
    }

    public String getNextMaturityDate() {
        return nextMaturityDate;
    }

    public void setNextMaturityDate(String nextMaturityDate) {
        this.nextMaturityDate = nextMaturityDate;
    }

    public Date getMaturityDateDt() {
        return maturityDateDt;
    }

    public void setMaturityDateDt(Date maturityDateDt) {
        this.maturityDateDt = maturityDateDt;
    }

    public Date getNextMaturityDateDt() {
        return nextMaturityDateDt;
    }

    public void setNextMaturityDateDt(Date nextMaturityDateDt) {
        this.nextMaturityDateDt = nextMaturityDateDt;
    }

    public Date getWarningDateDt() {
        return warningDateDt;
    }

    public void setWarningDateDt(Date warningDateDt) {
        this.warningDateDt = warningDateDt;
    }

    public Date getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public Date getRenewDateDt() {
        return renewDateDt;
    }

    public void setRenewDateDt(Date renewDateDt) {
        this.renewDateDt = renewDateDt;
    }
    
    

}
