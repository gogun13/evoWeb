/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class RptIndividualAccountVo extends BaseVo  {
    
    private String lastBatchDate;
    private String dueDate;
    private String cif;
    private String accountNo;
    private String billNo;
    private String limitAmt;
    private String mainLimitAmt;
    private String outstandingAmt;
    private String mainOutstandingAmt;
    private String maturityDate;
    private String dpd;
    private String cFinal;
    private String dueAmt;
    private String unpaidAmt;
    private String inputAccountNo;
    private String inputBillNo;
    private String paidDate;
    private String productGroup;
    private String productType;
    private String accountSubType;
    private String loanType;
    private String sourceSystem;
    private String odOverLimit;
    private String unpaidInterest;
    private String unpaidPrincipal;
    private String lateCharge;
    private String isClosed;
    private String dpdZeroDate;
    private String loanGrpProd;

    public String getLastBatchDate() {
        return lastBatchDate;
    }

    public void setLastBatchDate(String lastBatchDate) {
        this.lastBatchDate = lastBatchDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(String limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getOutstandingAmt() {
        return outstandingAmt;
    }

    public void setOutstandingAmt(String outstandingAmt) {
        this.outstandingAmt = outstandingAmt;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getDpd() {
        return dpd;
    }

    public void setDpd(String dpd) {
        this.dpd = dpd;
    }

    public String getcFinal() {
        return cFinal;
    }

    public void setcFinal(String cFinal) {
        this.cFinal = cFinal;
    }

    public String getDueAmt() {
        return dueAmt;
    }

    public void setDueAmt(String dueAmt) {
        this.dueAmt = dueAmt;
    }

    public String getUnpaidAmt() {
        return unpaidAmt;
    }

    public void setUnpaidAmt(String unpaidAmt) {
        this.unpaidAmt = unpaidAmt;
    }

    public String getInputAccountNo() {
        return inputAccountNo;
    }

    public void setInputAccountNo(String inputAccountNo) {
        this.inputAccountNo = inputAccountNo;
    }

    public String getInputBillNo() {
        return inputBillNo;
    }

    public void setInputBillNo(String inputBillNo) {
        this.inputBillNo = inputBillNo;
    }

    public String getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(String paidDate) {
        this.paidDate = paidDate;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getAccountSubType() {
        return accountSubType;
    }

    public void setAccountSubType(String accountSubType) {
        this.accountSubType = accountSubType;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getOdOverLimit() {
        return odOverLimit;
    }

    public void setOdOverLimit(String odOverLimit) {
        this.odOverLimit = odOverLimit;
    }

    public String getUnpaidInterest() {
        return unpaidInterest;
    }

    public void setUnpaidInterest(String unpaidInterest) {
        this.unpaidInterest = unpaidInterest;
    }

    public String getUnpaidPrincipal() {
        return unpaidPrincipal;
    }

    public void setUnpaidPrincipal(String unpaidPrincipal) {
        this.unpaidPrincipal = unpaidPrincipal;
    }

    public String getLateCharge() {
        return lateCharge;
    }

    public void setLateCharge(String lateCharge) {
        this.lateCharge = lateCharge;
    }

    public String getIsClosed() {
        return isClosed;
    }

    public void setIsClosed(String isClosed) {
        this.isClosed = isClosed;
    }

    public String getDpdZeroDate() {
        return dpdZeroDate;
    }

    public void setDpdZeroDate(String dpdZeroDate) {
        this.dpdZeroDate = dpdZeroDate;
    }

    public String getMainLimitAmt() {
        return mainLimitAmt;
    }

    public void setMainLimitAmt(String mainLimitAmt) {
        this.mainLimitAmt = mainLimitAmt;
    }

    public String getMainOutstandingAmt() {
        return mainOutstandingAmt;
    }

    public void setMainOutstandingAmt(String mainOutstandingAmt) {
        this.mainOutstandingAmt = mainOutstandingAmt;
    }

    public String getLoanGrpProd() {
        return loanGrpProd;
    }

    public void setLoanGrpProd(String loanGrpProd) {
        this.loanGrpProd = loanGrpProd;
    }
    
    
}
