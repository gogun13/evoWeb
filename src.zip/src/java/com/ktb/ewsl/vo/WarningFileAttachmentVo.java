package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.BaseVo;
/**
 *
 * @author Thanakorn Ch.
 */
public class WarningFileAttachmentVo extends BaseVo{
    private Integer warningHeadId;
    private Integer warningAttachId;
    private String fileName;
    private String filePath;
    private String createdByName;
    private String fileLogicalName;

    public Integer getWarningHeadId() {
        return warningHeadId;
    }

    public void setWarningHeadId(Integer warningHeadId) {
        this.warningHeadId = warningHeadId;
    }

    public Integer getWarningAttachId() {
        return warningAttachId;
    }

    public void setWarningAttachId(Integer warningAttachId) {
        this.warningAttachId = warningAttachId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    public String getCreateDateString () {
        return DateUtil.getDateTimeInThaiFormat( this.getCreatedDate(), DateUtil.DEFAULT_DATETIME_FORMAT );
    }

    public String getCreatedByName() {
        return createdByName;
    }

    public void setCreatedByName(String createdByName) {
        this.createdByName = createdByName;
    }

    public String getFileLogicalName() {
        return fileLogicalName;
    }

    public void setFileLogicalName(String fileLogicalName) {
        this.fileLogicalName = fileLogicalName;
    }
}
