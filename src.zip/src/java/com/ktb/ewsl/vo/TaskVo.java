/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;

/**
 *
 * @author aon
 */
public class TaskVo extends BaseVo {

    private String taskId;
    private String rasId;
    private String appId;
    private String collId;    
    private String cifNo;
    
    private String costCenter;
    private String costCenterDesc;
    private String seq;
    private String transTypeId;
    private String transTypeName;
    private String referenceNo;
    private String customerName;
    private String sendBackReason;
    private String adminReason;
    private String rejectReason;
    private String cancelReason;

    private String status;
    private String statusName;

    private String menuId;
    private String menuLabel;
    private String actionName;
    private String commandName;
    private String refTaskId;
    private String taskTypeId;

    private String approvedBy;
    private String approvedIp;
    private java.util.Date approvedDate;
    private BigDecimal approveAmount;

    private String holderId;
    
    private TransLockVo lock;
    
    private String developerName;
    private java.util.Date appointAppraisalDate;
    
    private String collTypeCode;
    private String collTypeDesc;
    
    private String collSubtypeCode;
    private String collSubtypeDesc;
    
    private String apprGroupCode;
    private String apprGroupDesc;

    private String committeeId;
    private String committeeName;
    private java.util.Date approvalDate;
    private BigDecimal approveTotalAmount;
    
    private String surveyNo;
    private String surveyName;
    
    //------- FOR EWS-SME 
    private String name;
    private String dpdAmount;
    private String ewsRisk;
    private String slaAmount;
    private String taskSumAmount;
               
        
    public TaskVo(){
        this.lock = new TransLockVo();
    }
    
    /**
     * @return the taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * @param taskId the taskId to set
     */
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the transTypeId
     */
    public String getTransTypeId() {
        return transTypeId;
    }

    /**
     * @param transTypeId the transTypeId to set
     */
    public void setTransTypeId(String transTypeId) {
        this.transTypeId = transTypeId;
    }

    /**
     * @return the transTypeName
     */
    public String getTransTypeName() {
        return transTypeName;
    }

    /**
     * @param transTypeName the transTypeName to set
     */
    public void setTransTypeName(String transTypeName) {
        this.transTypeName = transTypeName;
    }

    /**
     * @return the referenceNo
     */
    public String getReferenceNo() {
        return referenceNo;
    }

    /**
     * @param referenceNo the referenceNo to set
     */
    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    /**
     * @return the customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * @param customerName the customerName to set
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * @return the sendBackReason
     */
    public String getSendBackReason() {
        return sendBackReason;
    }

    /**
     * @param sendBackReason the sendBackReason to set
     */
    public void setSendBackReason(String sendBackReason) {
        this.sendBackReason = sendBackReason;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the statusName
     */
    public String getStatusName() {
        return statusName;
    }

    /**
     * @param statusName the statusName to set
     */
    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }

    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    /**
     * @return the menuLabel
     */
    public String getMenuLabel() {
        return menuLabel;
    }

    /**
     * @param menuLabel the menuLabel to set
     */
    public void setMenuLabel(String menuLabel) {
        this.menuLabel = menuLabel;
    }

    /**
     * @return the actionName
     */
    public String getActionName() {
        return actionName;
    }

    /**
     * @param actionName the actionName to set
     */
    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    /**
     * @return the commandName
     */
    public String getCommandName() {
        return commandName;
    }

    /**
     * @param commandName the commandName to set
     */
    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }

    /**
     * @return the refTaskId
     */
    public String getRefTaskId() {
        return refTaskId;
    }

    /**
     * @param refTaskId the refTaskId to set
     */
    public void setRefTaskId(String refTaskId) {
        this.refTaskId = refTaskId;
    }

    /**
     * @return the taskTypeId
     */
    public String getTaskTypeId() {
        return taskTypeId;
    }

    /**
     * @param taskTypeId the taskTypeId to set
     */
    public void setTaskTypeId(String taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    /**
     * @return the approvedBy
     */
    public String getApprovedBy() {
        return approvedBy;
    }

    /**
     * @param approvedBy the approvedBy to set
     */
    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    /**
     * @return the approvedIp
     */
    public String getApprovedIp() {
        return approvedIp;
    }

    /**
     * @param approvedIp the approvedIp to set
     */
    public void setApprovedIp(String approvedIp) {
        this.approvedIp = approvedIp;
    }

    /**
     * @return the approvedDate
     */
    public java.util.Date getApprovedDate() {
        return approvedDate;
    }

    /**
     * @param approvedDate the approvedDate to set
     */
    public void setApprovedDate(java.util.Date approvedDate) {
        this.approvedDate = approvedDate;
    }

    /**
     * @return the rejectReason
     */
    public String getRejectReason() {
        return rejectReason;
    }

    /**
     * @param rejectReason the rejectReason to set
     */
    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    /**
     * @return the adminReason
     */
    public String getAdminReason() {
        return adminReason;
    }

    /**
     * @param adminReason the adminReason to set
     */
    public void setAdminReason(String adminReason) {
        this.adminReason = adminReason;
    }

    /**
     * @return the cancelReason
     */
    public String getCancelReason() {
        return cancelReason;
    }

    /**
     * @param cancelReason the cancelReason to set
     */
    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    /**
     * @return the holderId
     */
    public String getHolderId() {
        return holderId;
    }

    /**
     * @param holderId the holderId to set
     */
    public void setHolderId(String holderId) {
        this.holderId = holderId;
    }

    /**
     * @return the lock
     */
    public TransLockVo getLock() {
        return lock;
    }

    /**
     * @param lock the lock to set
     */
    public void setLock(TransLockVo lock) {
        this.lock = lock;
    }

    /**
     * @return the rasId
     */
    public String getRasId() {
        return rasId;
    }

    /**
     * @param rasId the rasId to set
     */
    public void setRasId(String rasId) {
        this.rasId = rasId;
    }

    /**
     * @return the appId
     */
    public String getAppId() {
        return appId;
    }

    /**
     * @param appId the appId to set
     */
    public void setAppId(String appId) {
        this.appId = appId;
    }

    /**
     * @return the collId
     */
    public String getCollId() {
        return collId;
    }

    /**
     * @param collId the collId to set
     */
    public void setCollId(String collId) {
        this.collId = collId;
    }

    /**
     * @return the costCenter
     */
    public String getCostCenter() {
        return costCenter;
    }

    /**
     * @param costCenter the costCenter to set
     */
    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    /**
     * @return the costCenterDesc
     */
    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    /**
     * @param costCenterDesc the costCenterDesc to set
     */
    public void setCostCenterDesc(String costCenterDesc) {
        this.costCenterDesc = costCenterDesc;
    }

    /**
     * @return the cifNo
     */
    public String getCifNo() {
        return cifNo;
    }

    /**
     * @param cifNo the cifNo to set
     */
    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    /**
     * @return the approveAmount
     */
    public BigDecimal getApproveAmount() {
        return approveAmount;
    }

    /**
     * @param approveAmount the approveAmount to set
     */
    public void setApproveAmount(BigDecimal approveAmount) {
        this.approveAmount = approveAmount;
    }

    /**
     * @return the developerName
     */
    public String getDeveloperName() {
        return developerName;
    }

    /**
     * @param developerName the developerName to set
     */
    public void setDeveloperName(String developerName) {
        this.developerName = developerName;
    }

    /**
     * @return the appointAppraisalDate
     */
    public java.util.Date getAppointAppraisalDate() {
        return appointAppraisalDate;
    }

    /**
     * @param appointAppraisalDate the appointAppraisalDate to set
     */
    public void setAppointAppraisalDate(java.util.Date appointAppraisalDate) {
        this.appointAppraisalDate = appointAppraisalDate;
    }

    /**
     * @return the collTypeCode
     */
    public String getCollTypeCode() {
        return collTypeCode;
    }

    /**
     * @param collTypeCode the collTypeCode to set
     */
    public void setCollTypeCode(String collTypeCode) {
        this.collTypeCode = collTypeCode;
    }

    /**
     * @return the collTypeDesc
     */
    public String getCollTypeDesc() {
        return collTypeDesc;
    }

    /**
     * @param collTypeDesc the collTypeDesc to set
     */
    public void setCollTypeDesc(String collTypeDesc) {
        this.collTypeDesc = collTypeDesc;
    }

    /**
     * @return the collSubtypeCode
     */
    public String getCollSubtypeCode() {
        return collSubtypeCode;
    }

    /**
     * @param collSubtypeCode the collSubtypeCode to set
     */
    public void setCollSubtypeCode(String collSubtypeCode) {
        this.collSubtypeCode = collSubtypeCode;
    }

    /**
     * @return the collSubtypeDesc
     */
    public String getCollSubtypeDesc() {
        return collSubtypeDesc;
    }

    /**
     * @param collSubtypeDesc the collSubtypeDesc to set
     */
    public void setCollSubtypeDesc(String collSubtypeDesc) {
        this.collSubtypeDesc = collSubtypeDesc;
    }

    /**
     * @return the apprGroupCode
     */
    public String getApprGroupCode() {
        return apprGroupCode;
    }

    /**
     * @param apprGroupCode the apprGroupCode to set
     */
    public void setApprGroupCode(String apprGroupCode) {
        this.apprGroupCode = apprGroupCode;
    }

    /**
     * @return the apprGroupDesc
     */
    public String getApprGroupDesc() {
        return apprGroupDesc;
    }

    /**
     * @param apprGroupDesc the apprGroupDesc to set
     */
    public void setApprGroupDesc(String apprGroupDesc) {
        this.apprGroupDesc = apprGroupDesc;
    }

    /**
     * @return the committeeId
     */
    public String getCommitteeId() {
        return committeeId;
    }

    /**
     * @param committeeId the committeeId to set
     */
    public void setCommitteeId(String committeeId) {
        this.committeeId = committeeId;
    }

    /**
     * @return the committeeName
     */
    public String getCommitteeName() {
        return committeeName;
    }

    /**
     * @param committeeName the committeeName to set
     */
    public void setCommitteeName(String committeeName) {
        this.committeeName = committeeName;
    }

    /**
     * @return the approvalDate
     */
    public java.util.Date getApprovalDate() {
        return approvalDate;
    }

    /**
     * @param approvalDate the approvalDate to set
     */
    public void setApprovalDate(java.util.Date approvalDate) {
        this.approvalDate = approvalDate;
    }

    /**
     * @return the approveTotalAmount
     */
    public BigDecimal getApproveTotalAmount() {
        return approveTotalAmount;
    }

    /**
     * @param approveTotalAmount the approveTotalAmount to set
     */
    public void setApproveTotalAmount(BigDecimal approveTotalAmount) {
        this.approveTotalAmount = approveTotalAmount;
    }

    /**
     * @return the surveyNo
     */
    public String getSurveyNo() {
        return surveyNo;
    }

    /**
     * @param surveyNo the surveyNo to set
     */
    public void setSurveyNo(String surveyNo) {
        this.surveyNo = surveyNo;
    }

    /**
     * @return the surveyName
     */
    public String getSurveyName() {
        return surveyName;
    }

    /**
     * @param surveyName the surveyName to set
     */
    public void setSurveyName(String surveyName) {
        this.surveyName = surveyName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDpdAmount() {
        return dpdAmount;
    }

    public void setDpdAmount(String dpdAmount) {
        this.dpdAmount = dpdAmount;
    }

    public String getEwsRisk() {
        return ewsRisk;
    }

    public void setEwsRisk(String ewsRisk) {
        this.ewsRisk = ewsRisk;
    }

    public String getSlaAmount() {
        return slaAmount;
    }

    public void setSlaAmount(String slaAmount) {
        this.slaAmount = slaAmount;
    }

    public String getTaskSumAmount() {
        return taskSumAmount;
    }

    public void setTaskSumAmount(String taskSumAmount) {
        this.taskSumAmount = taskSumAmount;
    }

    
    
}
