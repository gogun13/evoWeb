/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.ArrayList;

/**
 *
 * @author surapong
 */
public class QuestionVo extends BaseVo{
    private int questId;
    private String asstCode;
    private String asstName;
    private String asstDesc;
    private String questCode;
    private String questDesc;
    private String questUnder;
    private int questSeq;
    private String choiceType;
    private int isRequire;
    private int isRemark;
    
    private int warningId;
    private String answer;
    private ArrayList<AnswerVo> answerVoList;
    private String remark;
    private String roleCode;
    private ArrayList<String> roleCodeList;
    private String wayoutFlgNotBcm;
    private String wayoutRemarkNotBcm;

    public int getQuestId() {
        return questId;
    }

    public void setQuestId(int questId) {
        this.questId = questId;
    }

    public String getAsstCode() {
        return asstCode;
    }

    public void setAsstCode(String asstCode) {
        this.asstCode = asstCode;
    }

    public String getQuestCode() {
        return questCode;
    }

    public void setQuestCode(String questCode) {
        this.questCode = questCode;
    }

    public String getQuestDesc() {
        return questDesc;
    }

    public void setQuestDesc(String questDesc) {
        this.questDesc = questDesc;
    }

    public String getQuestUnder() {
        return questUnder;
    }

    public void setQuestUnder(String questUnder) {
        this.questUnder = questUnder;
    }

    public int getQuestSeq() {
        return questSeq;
    }

    public void setQuestSeq(int questSeq) {
        this.questSeq = questSeq;
    }

    public String getChoiceType() {
        return choiceType;
    }

    public void setChoiceType(String choiceType) {
        this.choiceType = choiceType;
    }

    public int getIsRequire() {
        return isRequire;
    }

    public void setIsRequire(int isRequire) {
        this.isRequire = isRequire;
    }

    public int getIsRemark() {
        return isRemark;
    }

    public void setIsRemark(int isRemark) {
        this.isRemark = isRemark;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAsstName() {
        return asstName;
    }

    public void setAsstName(String asstName) {
        this.asstName = asstName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAsstDesc() {
        return asstDesc;
    }

    public void setAsstDesc(String asstDesc) {
        this.asstDesc = asstDesc;
    }

    public int getWarningId() {
        return warningId;
    }

    public void setWarningId(int warningId) {
        this.warningId = warningId;
    }

    public ArrayList<AnswerVo> getAnswerVoList() {
        return answerVoList;
    }

    public void setAnswerVoList(ArrayList<AnswerVo> answerVoList) {
        this.answerVoList = answerVoList;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public ArrayList<String> getRoleCodeList() {
        return roleCodeList;
    }

    public void setRoleCodeList(ArrayList<String> roleCodeList) {
        this.roleCodeList = roleCodeList;
    }

    public String getWayoutFlgNotBcm() {
        return wayoutFlgNotBcm;
    }

    public void setWayoutFlgNotBcm(String wayoutFlgNotBcm) {
        this.wayoutFlgNotBcm = wayoutFlgNotBcm;
    }

    public String getWayoutRemarkNotBcm() {
        return wayoutRemarkNotBcm;
    }

    public void setWayoutRemarkNotBcm(String wayoutRemarkNotBcm) {
        this.wayoutRemarkNotBcm = wayoutRemarkNotBcm;
    }

    
}
