/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class KtbOrganization extends BaseVo {
    
    private Integer costCenterCode;
    private String costCenterName;
    private String organizationType;
    private Integer parentCode;
    private Integer businessUnitCode;
    private Integer groupCode;
    private Integer regionCode;
    private Integer departmentCode;
    private int isActive;

    public Integer getCostCenterCode() {
        return costCenterCode;
    }

    public void setCostCenterCode(Integer costCenterCode) {
        this.costCenterCode = costCenterCode;
    }

    public String getCostCenterName() {
        return costCenterName;
    }

    public void setCostCenterName(String costCenterName) {
        this.costCenterName = costCenterName;
    }

    public String getOrganizationType() {
        return organizationType;
    }

    public void setOrganizationType(String organizationType) {
        this.organizationType = organizationType;
    }

    public Integer getParentCode() {
        return parentCode;
    }

    public void setParentCode(Integer parentCode) {
        this.parentCode = parentCode;
    }

    public Integer getBusinessUnitCode() {
        return businessUnitCode;
    }

    public void setBusinessUnitCode(Integer businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
    }

    public Integer getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(Integer groupCode) {
        this.groupCode = groupCode;
    }

    public Integer getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(Integer regionCode) {
        this.regionCode = regionCode;
    }

    public Integer getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(Integer departmentCode) {
        this.departmentCode = departmentCode;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }


        
}
