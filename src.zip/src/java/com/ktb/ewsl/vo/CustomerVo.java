/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class CustomerVo extends BaseVo  {
    
    private String aeId;
    private String aoId;
    private String businessSize;
    private String citizenId;
    private String custName;
    private String isicCode;
    private String juristicId;    
    private String responseUnit;
    private String rmId;
    private String taxId;
    private String responseUnitName; // CostcenterName
    private String rmName;
    private String aeName;
    private String aoName;
    private String rmEmpNo;
    private String rmTitleName;
    private String rmEmpName;
    private String rmEmpSurName;
    private String aeEmpNo;
    private String aeTitleName;
    private String aeEmpName;
    private String aeEmpSurName;
    private Integer cif; 
    private String coRmId;
    private String coRmName;
    private String coAeId;
    private String coAeName;
    private String coResponseUnit;
    private String coResponseUnitName;
    
    public String getRmName() {
        return rmName;
    }

    public void setRmName(String rmName) {
        this.rmName = rmName;
    }

    public String getAeName() {
        return aeName;
    }

    public void setAeName(String aeName) {
        this.aeName = aeName;
    }
        
    public String getAeId() {
        return aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public String getAoId() {
        return aoId;
    }

    public void setAoId(String aoId) {
        this.aoId = aoId;
    }

    public String getCitizenId() {
        return citizenId;
    }

    public void setCitizenId(String citizenId) {
        this.citizenId = citizenId;
    }


    public String getIsicCode() {
        return isicCode;
    }

    public void setIsicCode(String isicCode) {
        this.isicCode = isicCode;
    }

    public String getJuristicId() {
        return juristicId;
    }

    public void setJuristicId(String juristicId) {
        this.juristicId = juristicId;
    }

    public String getResponseUnit() {
        return responseUnit;
    }

    public void setResponseUnit(String responseUnit) {
        this.responseUnit = responseUnit;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public String getBusinessSize() {
        return businessSize;
    }

    public void setBusinessSize(String businessSize) {
        this.businessSize = businessSize;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getResponseUnitName() {
        return responseUnitName;
    }

    public void setResponseUnitName(String responseUnitName) {
        this.responseUnitName = responseUnitName;
    }

    public Integer getCif() {
        return cif;
    }

    public void setCif(Integer cif) {
        this.cif = cif;
    }

    public String getAoName() {
        return aoName;
    }

    public void setAoName(String aoName) {
        this.aoName = aoName;
    }

    public String getRmEmpNo() {
        return rmEmpNo;
    }

    public void setRmEmpNo(String rmEmpNo) {
        this.rmEmpNo = rmEmpNo;
    }

    public String getRmTitleName() {
        return rmTitleName;
    }

    public void setRmTitleName(String rmTitleName) {
        this.rmTitleName = rmTitleName;
    }

    public String getRmEmpName() {
        return rmEmpName;
    }

    public void setRmEmpName(String rmEmpName) {
        this.rmEmpName = rmEmpName;
    }

    public String getRmEmpSurName() {
        return rmEmpSurName;
    }

    public void setRmEmpSurName(String rmEmpSurName) {
        this.rmEmpSurName = rmEmpSurName;
    }

    public String getAeEmpNo() {
        return aeEmpNo;
    }

    public void setAeEmpNo(String aeEmpNo) {
        this.aeEmpNo = aeEmpNo;
    }

    public String getAeTitleName() {
        return aeTitleName;
    }

    public void setAeTitleName(String aeTitleName) {
        this.aeTitleName = aeTitleName;
    }

    public String getAeEmpName() {
        return aeEmpName;
    }

    public void setAeEmpName(String aeEmpName) {
        this.aeEmpName = aeEmpName;
    }

    public String getAeEmpSurName() {
        return aeEmpSurName;
    }

    public void setAeEmpSurName(String aeEmpSurName) {
        this.aeEmpSurName = aeEmpSurName;
    }

    public String getCoRmId() {
        return coRmId;
    }

    public void setCoRmId(String coRmId) {
        this.coRmId = coRmId;
    }

    public String getCoAeId() {
        return coAeId;
    }

    public void setCoAeId(String coAeId) {
        this.coAeId = coAeId;
    }

    public String getCoResponseUnit() {
        return coResponseUnit;
    }

    public void setCoResponseUnit(String coResponseUnit) {
        this.coResponseUnit = coResponseUnit;
    }

    public String getCoResponseUnitName() {
        return coResponseUnitName;
    }

    public void setCoResponseUnitName(String coResponseUnitName) {
        this.coResponseUnitName = coResponseUnitName;
    }

    public String getCoRmName() {
        return coRmName;
    }

    public void setCoRmName(String coRmName) {
        this.coRmName = coRmName;
    }

    public String getCoAeName() {
        return coAeName;
    }

    public void setCoAeName(String coAeName) {
        this.coAeName = coAeName;
    }
    
}
