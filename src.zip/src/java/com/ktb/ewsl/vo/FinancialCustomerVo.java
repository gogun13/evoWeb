package com.ktb.ewsl.vo;

import java.io.Serializable;

public class FinancialCustomerVo implements Serializable {

//    private String appNo;
    private String joinTypeId;
    private String qcaPurposeCd;
    private String custNo;
    private String isMain;
    private String relCd;
    private String cifNo;
    private String custCatCd;
    private String salutationTh;
    private String firstNameTh;
    private String lastNameTh;
    private String hvFin;
    private String reasonCode;
    private String reasonDetail;
    private String computeDate;

//    public String getAppNo() {
//        return appNo;
//    }
//
//    public void setAppNo(String appNo) {
//        this.appNo = appNo;
//    }

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getComputeDate() {
        return computeDate;
    }

    public void setComputeDate(String computeDate) {
        this.computeDate = computeDate;
    }

    public String getCustCatCd() {
        return custCatCd;
    }

    public void setCustCatCd(String custCatCd) {
        this.custCatCd = custCatCd;
    }

    public String getCustNo() {
        return custNo;
    }

    public void setCustNo(String custNo) {
        this.custNo = custNo;
    }

    public String getFirstNameTh() {
        return firstNameTh;
    }

    public void setFirstNameTh(String firstNameTh) {
        this.firstNameTh = firstNameTh;
    }

    public String getHvFin() {
        return hvFin;
    }

    public void setHvFin(String hvFin) {
        this.hvFin = hvFin;
    }

    public String getIsMain() {
        return isMain;
    }

    public void setIsMain(String isMain) {
        this.isMain = isMain;
    }

    public String getJoinTypeId() {
        return joinTypeId;
    }

    public void setJoinTypeId(String joinTypeId) {
        this.joinTypeId = joinTypeId;
    }

    public String getLastNameTh() {
        return lastNameTh;
    }

    public void setLastNameTh(String lastNameTh) {
        this.lastNameTh = lastNameTh;
    }

    public String getQcaPurposeCd() {
        return qcaPurposeCd;
    }

    public void setQcaPurposeCd(String qcaPurposeCd) {
        this.qcaPurposeCd = qcaPurposeCd;
    }

    public String getReasonCode() {
        if(reasonCode!=null && reasonCode.trim().length()>0 && !"null".equalsIgnoreCase(reasonCode)) {
            return reasonCode;
        }
        return "";
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public String getReasonDetail() {
        if(reasonDetail!=null && reasonDetail.trim().length()>0&& !"null".equalsIgnoreCase(reasonDetail)) {
            return reasonDetail;
        }
        return "";
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public String getRelCd() {
        return relCd;
    }

    public void setRelCd(String relCd) {
        this.relCd = relCd;
    }

    public String getSalutationTh() {
        return salutationTh;
    }

    public void setSalutationTh(String salutationTh) {
        this.salutationTh = salutationTh;
    }

}
