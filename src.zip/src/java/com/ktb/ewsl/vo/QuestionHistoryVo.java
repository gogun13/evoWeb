/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author pumin
 */
public class QuestionHistoryVo implements Serializable{
    private String warningId;
    private String approveUserId;
    private String approveUserName;
    private String actionUserId;
    private String actionUserName;
    private String approveDate;
    private String actionDate;
    private String actionCode;
    private String actionDetail;
    private String version;
    private String warningDateInfo;
    private String cif;
    private String questionId;
    private String warningDateHeader;
    private String headerId;
    private String warningType;
    private String warningDateInfoStrFormat; //--ANN
    private String maturityDateStrFormat;

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }
    
    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    
    public String getWarningDateHeader() {
        return warningDateHeader;
    }

    public void setWarningDateHeader(String warningDateHeader) {
        this.warningDateHeader = warningDateHeader;
    }

    
    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    
    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getWarningDateInfo() {
        return warningDateInfo;
    }

    public void setWarningDateInfo(String warningDateInfo) {
        this.warningDateInfo = warningDateInfo;
    }


    public String getActionCode() {
        return actionCode;
    }

    public void setActionCode(String actionCode) {
        this.actionCode = actionCode;
    }

    public String getActionDetail() {
        return actionDetail;
    }

    public void setActionDetail(String actionDetail) {
        this.actionDetail = actionDetail;
    }

    public String getWarningId() {
        return warningId;
    }

    public void setWarningId(String warningId) {
        this.warningId = warningId;
    }

    public String getApproveUserId() {
        return approveUserId;
    }

    public void setApproveUserId(String approveUserId) {
        this.approveUserId = approveUserId;
    }

    public String getApproveUserName() {
        return approveUserName;
    }

    public void setApproveUserName(String approveUserName) {
        this.approveUserName = approveUserName;
    }

    public String getActionUserId() {
        return actionUserId;
    }

    public void setActionUserId(String actionUserId) {
        this.actionUserId = actionUserId;
    }

    public String getActionUserName() {
        return actionUserName;
    }

    public void setActionUserName(String actionUserName) {
        this.actionUserName = actionUserName;
    }

    public String getApproveDate() {
        return approveDate;
    }

    public void setApproveDate(String approveDate) {
        this.approveDate = approveDate;
    }

    public String getActionDate() {
        return actionDate;
    }

    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }

    public String getWarningDateInfoStrFormat() {
        return warningDateInfoStrFormat;
    }

    public void setWarningDateInfoStrFormat(String warningDateInfoStrFormat) {
        this.warningDateInfoStrFormat = warningDateInfoStrFormat;
    }

    public String getMaturityDateStrFormat() {
        return maturityDateStrFormat;
    }

    public void setMaturityDateStrFormat(String maturityDateStrFormat) {
        this.maturityDateStrFormat = maturityDateStrFormat;
    }
    
}
