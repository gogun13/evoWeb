/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;

/**
 *
 * @author Tum_Surapong
 */
public class AccountSpecialDetailVo implements Serializable{
    private String acctNo;
    private String productClass;
    private String productType;
    private String productTypeDesc;
    private String productGrp;
    private String productGrpDesc;
    private String acctName;
    private String acctName2;
    private String acctName3;
    private String acctName4;
    private String acctBranch;
    private String acctBranchDesc;
    private String primaryCif;
    private String dtOpened;
    private String lastTransDate;
    private String dtClosed;
    private String costCenter;
    private String costCenterDesc;
    private String currCd;
    private String acctStatus;
    private String acctStatusDesc;
    private String responseUnit;
    private String responseUnitDesc;
    private String acctRelInfo;
    private String acctRelInfoDesc;
    private String acctAddr1;
    private String acctAddr2;
    private String acctAddr3;
    private String acctSubDistrict;
    private String acctSubDistrictDesc;
    private String acctDistrict;
    private String acctDistrictDesc;
    private String acctStateProv;
    private String acctStateProvDesc;
    private String acctPostalCd;
    private String acctCountry;
    private String acctCountryDesc;
    private String outsBal;
    private String availBal;
    private String arrPurCd;
    private String arrPurDesc;
    private String perConsumpCd;
    private String perConsumpDesc;
    private String apprCd;
    private String apprID1;
    private String apprID2;
    private String apprID3;
    private String apprID4;
    private String apprID5;
    private String apprID6;
    private String isic1;
    private String isic1Desc;
    private String isic2;
    private String isic2Desc;
    private String isic3;
    private String isic3Desc;
    private String mailFlag;
    private String statementFlag;
    private String glSetCd;
    private String intRate;
    private String indexCd;
    private String smeCd;
    private String smeDesc;
    private String pcmCd;
    private String pcmCdDesc;
    private String commCd;
    private String commCdDesc;
    private String contractDt;
    private String expiryDt;
    private String commitLine;
    private String specLendType;
    private String specLendTypeDesc;
    private String officerCd;
    private String limitAmt;
    private String marketCd;
    private String marketCdDesc;
    private String acctSubType;
    private String ownerBr;
    private String ownerBrDesc;
    private String loanTerm;
    private String paymentFrequence;
    private String fixedPrinAmt;
    private String nextPayDt;    
    private String earlyPayoffPenalty;
    private String masterAccount;
    private String collReq;
    private String commitAcct;
    private String revolvingFlag;

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getProductClass() {
        return productClass;
    }

    public void setProductClass(String productClass) {
        this.productClass = productClass;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductTypeDesc() {
        return productTypeDesc;
    }

    public void setProductTypeDesc(String productTypeDesc) {
        this.productTypeDesc = productTypeDesc;
    }

    public String getProductGrp() {
        return productGrp;
    }

    public void setProductGrp(String productGrp) {
        this.productGrp = productGrp;
    }

    public String getProductGrpDesc() {
        return productGrpDesc;
    }

    public void setProductGrpDesc(String productGrpDesc) {
        this.productGrpDesc = productGrpDesc;
    }

    public String getAcctName() {
        return acctName;
    }

    public void setAcctName(String acctName) {
        this.acctName = acctName;
    }

    public String getAcctName2() {
        return acctName2;
    }

    public void setAcctName2(String acctName2) {
        this.acctName2 = acctName2;
    }

    public String getAcctName3() {
        return acctName3;
    }

    public void setAcctName3(String acctName3) {
        this.acctName3 = acctName3;
    }

    public String getAcctName4() {
        return acctName4;
    }

    public void setAcctName4(String acctName4) {
        this.acctName4 = acctName4;
    }

    public String getAcctBranch() {
        return acctBranch;
    }

    public void setAcctBranch(String acctBranch) {
        this.acctBranch = acctBranch;
    }

    public String getAcctBranchDesc() {
        return acctBranchDesc;
    }

    public void setAcctBranchDesc(String acctBranchDesc) {
        this.acctBranchDesc = acctBranchDesc;
    }

    public String getPrimaryCif() {
        return primaryCif;
    }

    public void setPrimaryCif(String primaryCif) {
        this.primaryCif = primaryCif;
    }

    public String getDtOpened() {
        return dtOpened;
    }

    public void setDtOpened(String dtOpened) {
        this.dtOpened = dtOpened;
    }

    public String getLastTransDate() {
        return lastTransDate;
    }

    public void setLastTransDate(String lastTransDate) {
        this.lastTransDate = lastTransDate;
    }

    public String getDtClosed() {
        return dtClosed;
    }

    public void setDtClosed(String dtClosed) {
        this.dtClosed = dtClosed;
    }

    public String getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    public void setCostCenterDesc(String costCenterDesc) {
        this.costCenterDesc = costCenterDesc;
    }

    public String getCurrCd() {
        return currCd;
    }

    public void setCurrCd(String currCd) {
        this.currCd = currCd;
    }

    public String getAcctStatus() {
        return acctStatus;
    }

    public void setAcctStatus(String acctStatus) {
        this.acctStatus = acctStatus;
    }

    public String getAcctStatusDesc() {
        return acctStatusDesc;
    }

    public void setAcctStatusDesc(String acctStatusDesc) {
        this.acctStatusDesc = acctStatusDesc;
    }

    public String getResponseUnit() {
        return responseUnit;
    }

    public void setResponseUnit(String responseUnit) {
        this.responseUnit = responseUnit;
    }

    public String getResponseUnitDesc() {
        return responseUnitDesc;
    }

    public void setResponseUnitDesc(String responseUnitDesc) {
        this.responseUnitDesc = responseUnitDesc;
    }

    public String getAcctRelInfo() {
        return acctRelInfo;
    }

    public void setAcctRelInfo(String acctRelInfo) {
        this.acctRelInfo = acctRelInfo;
    }

    public String getAcctRelInfoDesc() {
        return acctRelInfoDesc;
    }

    public void setAcctRelInfoDesc(String acctRelInfoDesc) {
        this.acctRelInfoDesc = acctRelInfoDesc;
    }

    public String getAcctAddr1() {
        return acctAddr1;
    }

    public void setAcctAddr1(String acctAddr1) {
        this.acctAddr1 = acctAddr1;
    }

    public String getAcctAddr2() {
        return acctAddr2;
    }

    public void setAcctAddr2(String acctAddr2) {
        this.acctAddr2 = acctAddr2;
    }

    public String getAcctAddr3() {
        return acctAddr3;
    }

    public void setAcctAddr3(String acctAddr3) {
        this.acctAddr3 = acctAddr3;
    }

    public String getAcctSubDistrict() {
        return acctSubDistrict;
    }

    public void setAcctSubDistrict(String acctSubDistrict) {
        this.acctSubDistrict = acctSubDistrict;
    }

    public String getAcctSubDistrictDesc() {
        return acctSubDistrictDesc;
    }

    public void setAcctSubDistrictDesc(String acctSubDistrictDesc) {
        this.acctSubDistrictDesc = acctSubDistrictDesc;
    }

    public String getAcctDistrict() {
        return acctDistrict;
    }

    public void setAcctDistrict(String acctDistrict) {
        this.acctDistrict = acctDistrict;
    }

    public String getAcctDistrictDesc() {
        return acctDistrictDesc;
    }

    public void setAcctDistrictDesc(String acctDistrictDesc) {
        this.acctDistrictDesc = acctDistrictDesc;
    }

    public String getAcctStateProv() {
        return acctStateProv;
    }

    public void setAcctStateProv(String acctStateProv) {
        this.acctStateProv = acctStateProv;
    }

    public String getAcctStateProvDesc() {
        return acctStateProvDesc;
    }

    public void setAcctStateProvDesc(String acctStateProvDesc) {
        this.acctStateProvDesc = acctStateProvDesc;
    }

    public String getAcctPostalCd() {
        return acctPostalCd;
    }

    public void setAcctPostalCd(String acctPostalCd) {
        this.acctPostalCd = acctPostalCd;
    }

    public String getAcctCountry() {
        return acctCountry;
    }

    public void setAcctCountry(String acctCountry) {
        this.acctCountry = acctCountry;
    }

    public String getAcctCountryDesc() {
        return acctCountryDesc;
    }

    public void setAcctCountryDesc(String acctCountryDesc) {
        this.acctCountryDesc = acctCountryDesc;
    }

    public String getOutsBal() {
        return outsBal;
    }

    public void setOutsBal(String outsBal) {
        this.outsBal = outsBal;
    }

    public String getAvailBal() {
        return availBal;
    }

    public void setAvailBal(String availBal) {
        this.availBal = availBal;
    }

    public String getArrPurCd() {
        return arrPurCd;
    }

    public void setArrPurCd(String arrPurCd) {
        this.arrPurCd = arrPurCd;
    }

    public String getArrPurDesc() {
        return arrPurDesc;
    }

    public void setArrPurDesc(String arrPurDesc) {
        this.arrPurDesc = arrPurDesc;
    }

    public String getPerConsumpCd() {
        return perConsumpCd;
    }

    public void setPerConsumpCd(String perConsumpCd) {
        this.perConsumpCd = perConsumpCd;
    }

    public String getPerConsumpDesc() {
        return perConsumpDesc;
    }

    public void setPerConsumpDesc(String perConsumpDesc) {
        this.perConsumpDesc = perConsumpDesc;
    }

    public String getApprCd() {
        return apprCd;
    }

    public void setApprCd(String apprCd) {
        this.apprCd = apprCd;
    }

    public String getApprID1() {
        return apprID1;
    }

    public void setApprID1(String apprID1) {
        this.apprID1 = apprID1;
    }

    public String getApprID2() {
        return apprID2;
    }

    public void setApprID2(String apprID2) {
        this.apprID2 = apprID2;
    }

    public String getApprID3() {
        return apprID3;
    }

    public void setApprID3(String apprID3) {
        this.apprID3 = apprID3;
    }

    public String getApprID4() {
        return apprID4;
    }

    public void setApprID4(String apprID4) {
        this.apprID4 = apprID4;
    }

    public String getApprID5() {
        return apprID5;
    }

    public void setApprID5(String apprID5) {
        this.apprID5 = apprID5;
    }

    public String getApprID6() {
        return apprID6;
    }

    public void setApprID6(String apprID6) {
        this.apprID6 = apprID6;
    }

    public String getIsic1() {
        return isic1;
    }

    public void setIsic1(String isic1) {
        this.isic1 = isic1;
    }

    public String getIsic1Desc() {
        return isic1Desc;
    }

    public void setIsic1Desc(String isic1Desc) {
        this.isic1Desc = isic1Desc;
    }

    public String getIsic2() {
        return isic2;
    }

    public void setIsic2(String isic2) {
        this.isic2 = isic2;
    }

    public String getIsic2Desc() {
        return isic2Desc;
    }

    public void setIsic2Desc(String isic2Desc) {
        this.isic2Desc = isic2Desc;
    }

    public String getIsic3() {
        return isic3;
    }

    public void setIsic3(String isic3) {
        this.isic3 = isic3;
    }

    public String getIsic3Desc() {
        return isic3Desc;
    }

    public void setIsic3Desc(String isic3Desc) {
        this.isic3Desc = isic3Desc;
    }

    public String getMailFlag() {
        return mailFlag;
    }

    public void setMailFlag(String mailFlag) {
        this.mailFlag = mailFlag;
    }

    public String getStatementFlag() {
        return statementFlag;
    }

    public void setStatementFlag(String statementFlag) {
        this.statementFlag = statementFlag;
    }

    public String getGlSetCd() {
        return glSetCd;
    }

    public void setGlSetCd(String glSetCd) {
        this.glSetCd = glSetCd;
    }

    public String getIntRate() {
        return intRate;
    }

    public void setIntRate(String intRate) {
        this.intRate = intRate;
    }

    public String getIndexCd() {
        return indexCd;
    }

    public void setIndexCd(String indexCd) {
        this.indexCd = indexCd;
    }

    public String getSmeCd() {
        return smeCd;
    }

    public void setSmeCd(String smeCd) {
        this.smeCd = smeCd;
    }

    public String getSmeDesc() {
        return smeDesc;
    }

    public void setSmeDesc(String smeDesc) {
        this.smeDesc = smeDesc;
    }

    public String getPcmCd() {
        return pcmCd;
    }

    public void setPcmCd(String pcmCd) {
        this.pcmCd = pcmCd;
    }

    public String getPcmCdDesc() {
        return pcmCdDesc;
    }

    public void setPcmCdDesc(String pcmCdDesc) {
        this.pcmCdDesc = pcmCdDesc;
    }

    public String getCommCd() {
        return commCd;
    }

    public void setCommCd(String commCd) {
        this.commCd = commCd;
    }

    public String getCommCdDesc() {
        return commCdDesc;
    }

    public void setCommCdDesc(String commCdDesc) {
        this.commCdDesc = commCdDesc;
    }

    public String getContractDt() {
        return contractDt;
    }

    public void setContractDt(String contractDt) {
        this.contractDt = contractDt;
    }

    public String getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(String expiryDt) {
        this.expiryDt = expiryDt;
    }

    public String getCommitLine() {
        return commitLine;
    }

    public void setCommitLine(String commitLine) {
        this.commitLine = commitLine;
    }

    public String getSpecLendType() {
        return specLendType;
    }

    public void setSpecLendType(String specLendType) {
        this.specLendType = specLendType;
    }

    public String getSpecLendTypeDesc() {
        return specLendTypeDesc;
    }

    public void setSpecLendTypeDesc(String specLendTypeDesc) {
        this.specLendTypeDesc = specLendTypeDesc;
    }

    public String getOfficerCd() {
        return officerCd;
    }

    public void setOfficerCd(String officerCd) {
        this.officerCd = officerCd;
    }

    public String getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(String limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getMarketCd() {
        return marketCd;
    }

    public void setMarketCd(String marketCd) {
        this.marketCd = marketCd;
    }

    public String getMarketCdDesc() {
        return marketCdDesc;
    }

    public void setMarketCdDesc(String marketCdDesc) {
        this.marketCdDesc = marketCdDesc;
    }

    public String getAcctSubType() {
        return acctSubType;
    }

    public void setAcctSubType(String acctSubType) {
        this.acctSubType = acctSubType;
    }

    public String getOwnerBr() {
        return ownerBr;
    }

    public void setOwnerBr(String ownerBr) {
        this.ownerBr = ownerBr;
    }

    public String getOwnerBrDesc() {
        return ownerBrDesc;
    }

    public void setOwnerBrDesc(String ownerBrDesc) {
        this.ownerBrDesc = ownerBrDesc;
    }

    public String getLoanTerm() {
        return loanTerm;
    }

    public void setLoanTerm(String loanTerm) {
        this.loanTerm = loanTerm;
    }

    public String getPaymentFrequence() {
        return paymentFrequence;
    }

    public void setPaymentFrequence(String paymentFrequence) {
        this.paymentFrequence = paymentFrequence;
    }

    public String getFixedPrinAmt() {
        return fixedPrinAmt;
    }

    public void setFixedPrinAmt(String fixedPrinAmt) {
        this.fixedPrinAmt = fixedPrinAmt;
    }

    public String getNextPayDt() {
        return nextPayDt;
    }

    public void setNextPayDt(String nextPayDt) {
        this.nextPayDt = nextPayDt;
    }

    public String getEarlyPayoffPenalty() {
        return earlyPayoffPenalty;
    }

    public void setEarlyPayoffPenalty(String earlyPayoffPenalty) {
        this.earlyPayoffPenalty = earlyPayoffPenalty;
    }

    public String getMasterAccount() {
        return masterAccount;
    }

    public void setMasterAccount(String masterAccount) {
        this.masterAccount = masterAccount;
    }

    public String getCollReq() {
        return collReq;
    }

    public void setCollReq(String collReq) {
        this.collReq = collReq;
    }

    public String getCommitAcct() {
        return commitAcct;
    }

    public void setCommitAcct(String commitAcct) {
        this.commitAcct = commitAcct;
    }

    public String getRevolvingFlag() {
        return revolvingFlag;
    }

    public void setRevolvingFlag(String revolvingFlag) {
        this.revolvingFlag = revolvingFlag;
    }
    
}
