/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class CRCustReviewEwsVO extends BaseVo{
    
    private String cifNo;
    private String titleTH;
    private String fNameTH;
    private String lNameTH;
    private String officerCd;
    private String cizidId;
    private String taxId;
    private String respUnit;
    private String respUnitDesc;
    private Integer dpd;
    private String qcaFlg;
    private String finFlg;
    private String ewsFlg;
    private String riskLevel;
    private String triggerFlg;
    private String paymentFlg;
    private String custName;
    private String refId;
    private Date expiryDate; 
    private String caseType;
    private String acctNo;
    private String actionFlg;
    private Integer expiryCount;
    private String bucket;
    private String overLimitFlag;

    public String getCifNo() {
        return cifNo;
    }

    public void setCifNo(String cifNo) {
        this.cifNo = cifNo;
    }

    public String getTitleTH() {
        return titleTH;
    }

    public void setTitleTH(String titleTH) {
        this.titleTH = titleTH;
    }

    public String getfNameTH() {
        return fNameTH;
    }

    public void setfNameTH(String fNameTH) {
        this.fNameTH = fNameTH;
    }

    public String getlNameTH() {
        return lNameTH;
    }

    public void setlNameTH(String lNameTH) {
        this.lNameTH = lNameTH;
    }

    public String getOfficerCd() {
        return officerCd;
    }

    public void setOfficerCd(String officerCd) {
        this.officerCd = officerCd;
    }

    public String getCizidId() {
        return cizidId;
    }

    public void setCizidId(String cizidId) {
        this.cizidId = cizidId;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public String getRespUnit() {
        return respUnit;
    }

    public void setRespUnit(String respUnit) {
        this.respUnit = respUnit;
    }

    public String getRespUnitDesc() {
        return respUnitDesc;
    }

    public void setRespUnitDesc(String respUnitDesc) {
        this.respUnitDesc = respUnitDesc;
    }

    public String getQcaFlg() {
        return qcaFlg;
    }

    public void setQcaFlg(String qcaFlg) {
        this.qcaFlg = qcaFlg;
    }

    public String getFinFlg() {
        return finFlg;
    }

    public void setFinFlg(String finFlg) {
        this.finFlg = finFlg;
    }

    public String getEwsFlg() {
        return ewsFlg;
    }

    public void setEwsFlg(String ewsFlg) {
        this.ewsFlg = ewsFlg;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public String getTriggerFlg() {
        return triggerFlg;
    }

    public void setTriggerFlg(String triggerFlg) {
        this.triggerFlg = triggerFlg;
    }

    public String getPaymentFlg() {
        return paymentFlg;
    }

    public void setPaymentFlg(String paymentFlg) {
        this.paymentFlg = paymentFlg;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getActionFlg() {
        return actionFlg;
    }

    public void setActionFlg(String actionFlg) {
        this.actionFlg = actionFlg;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public Integer getDpd() {
        return dpd;
    }

    public void setDpd(Integer dpd) {
        this.dpd = dpd;
    }

    public Integer getExpiryCount() {
        return expiryCount;
    }

    public void setExpiryCount(Integer expiryCount) {
        this.expiryCount = expiryCount;
    }

    public String getOverLimitFlag() {
        return overLimitFlag;
    }

    public void setOverLimitFlag(String overLimitFlag) {
        this.overLimitFlag = overLimitFlag;
    }


}
