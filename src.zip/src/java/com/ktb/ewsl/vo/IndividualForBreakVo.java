/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public class IndividualForBreakVo implements Serializable{
    private String breakKey;
    private ArrayList<AccountDetailVo> valueList;
    private ArrayList<AccountDetailVo> value2List;
    
    private ArrayList<IndividualODAccountVo> valueODList;
    //private ArrayList<IndividualODAccountVo> value2ODList;
    
    private int valueODListSize; //pumin: for export excel

    public int getValueODListSize() {
        return valueODListSize;
    }

    public void setValueODListSize(int valueODListSize) {
        this.valueODListSize = valueODListSize;
    }

    public String getBreakKey() {
        return breakKey;
    }

    public void setBreakKey(String breakKey) {
        this.breakKey = breakKey;
    }

    public ArrayList<AccountDetailVo> getValueList() {
        return valueList;
    }

    public void setValueList(ArrayList<AccountDetailVo> valueList) {
        this.valueList = valueList;
    }

    public ArrayList<AccountDetailVo> getValue2List() {
        return value2List;
    }

    public void setValue2List(ArrayList<AccountDetailVo> value2List) {
        this.value2List = value2List;
    }

    public ArrayList<IndividualODAccountVo> getValueODList() {
        return valueODList;
    }

    public void setValueODList(ArrayList<IndividualODAccountVo> valueODList) {
        this.valueODList = valueODList;
    }

//    public ArrayList<IndividualODAccountVo> getValue2ODList() {
//        return value2ODList;
//    }
//
//    public void setValue2ODList(ArrayList<IndividualODAccountVo> value2ODList) {
//        this.value2ODList = value2ODList;
//    }

   
    
}
