/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author KTBDevLoan
 */
public class KtbOrganizationCtrl extends BaseVo  {
   
    private Integer costCenterCode;
    private Integer subCostCenterCode;

    public Integer getCostCenterCode() {
        return costCenterCode;
    }

    public void setCostCenterCode(Integer costCenterCode) {
        this.costCenterCode = costCenterCode;
    }

    public Integer getSubCostCenterCode() {
        return subCostCenterCode;
    }

    public void setSubCostCenterCode(Integer subCostCenterCode) {
        this.subCostCenterCode = subCostCenterCode;
    }
    

}
