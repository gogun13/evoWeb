/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class WarningLevelHistoryVo extends BaseVo{
    
    private Integer cif;
    private Integer warningHeaderId;
    private String riskLevel;
    private String riskType;
    private String createdDtStr;
    private String riskDateStr;
    private Date riskDate;
    private String riskUpdateFlag;
   

    public Integer getCif() {
        return cif;
    }

    public void setCif(Integer cif) {
        this.cif = cif;
    }

    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getCreatedDtStr() {
        return createdDtStr;
    }

    public void setCreatedDtStr(String createdDtStr) {
        this.createdDtStr = createdDtStr;
    }

    public String getRiskDateStr() {
        return riskDateStr;
    }

    public void setRiskDateStr(String riskDateStr) {
        this.riskDateStr = riskDateStr;
    }

    public Date getRiskDate() {
        return riskDate;
    }

    public void setRiskDate(Date riskDate) {
        this.riskDate = riskDate;
    }

    public String getRiskUpdateFlag() {
        return riskUpdateFlag;
    }

    public void setRiskUpdateFlag(String riskUpdateFlag) {
        this.riskUpdateFlag = riskUpdateFlag;
    }
    

        
}
