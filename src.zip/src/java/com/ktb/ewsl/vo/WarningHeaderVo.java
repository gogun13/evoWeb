/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author KTBDevLoan
 */
public class WarningHeaderVo extends BaseVo{
    
    private Integer warningHeaderId;
    //private Integer cif;
    private String bcmFlag;
    private String crFlag; //-- SIZE  L
    private Integer dpd;  //-- SIZE  L 
    private String ewsFlag;
    private String ewsRiskLevel;  //-- SIZE  L 
    private String payFlag;
    private String qcaFlag;
    private String status; // Status of cif in transaction //-- SIZE  L 
    private String taFlag;
    private String trigFlag;
    private Date warningDate;//-- SIZE  L 
    //----- Render Screen ------//
    private CustomerVo customerVo;
    private String warningDateStr;//-- SIZE  L 
    private Integer sla;
    private String slaStr;
    private String bucketDpd;
    private String dpdStrFormat;  //-- SIZE  L 
    private String formAssign;
    private String crFormAssign;
    private String crBucket;
    private Integer crExpiryCount;
    private Date crExpiryDt;
    private String trigPayResult;
    private String crExpiryDtStr;
    private String overLimitFlag;
    private int  sumTrackingEwsq;
    private int  sumTrackingFin;
    private int  sumTrackingPay;
    private int  sumTrackingQca;
    private int  sumTrackingTrig;
    private String quantiRiskLevel = "";
    private String qualiRiskLevel  = "";                                   
    private int  sumTrackingTrigAndPay;
    private String trigAndPayFlag;
    private String warningDateS;
    private String batchDateS;
    private String disableFlag;
    private String cFinal;  //-- SIZE  L 
    private String updateFinFlg;
    private String updateQcaFlg;
    private String updateQualFlg;
    private Date ewsRiskDt;
    private String ewsRiskDtStr;
    private Integer odOverLimit; //-- SIZE  L 
    private String odOverLimitStr;  
    //--------ADD MORE SIZE  L --------//
    private String aeId;
    private String aoId;
    private String cif;
    private String crAcctCnt;
    private String crWarningCnt;
    private String creditRatingFlg;
    private int dpdAcctCnt;
    private String finFlg;
    private String latePayFlg;
    private Date maturityDate;
    private String maturityDateStr;
    private int odAcctCnt;
    private BigDecimal odOverAmt;
    private String qualiFlg;
    private Integer respUnit;
    private String respUnitStr;
    private String rmId;
    private BigDecimal unpaidAmt;
    private BigDecimal warningHeaderIdDec;
    private String crFlg;
    private String spAccount;
    private String unpaidAmtStr;
    private String odOverAmtStr;
    private String odAcctCntStr;
    private String dpdAcctCntStr;
    private String cName;
    private String countAlertLp;
    private String countAlertQf;
    private String countAlertAf1;
    private String countAlertAf2;
    private String countAlertFf;
    private int crSla;
    private Integer dpdOd;  //-- SIZE  L 

    private BigDecimal dpdOdBigdecimal;
    private String bucketDpdOd;
    private String bucketDpdFinal;
    private Date delinqDate;
    private String delinqDateStr;
    private String hvDelinqDate;
    private String riskLevelChange;
    private BigDecimal crSlaBigDecimal;
    private String action1Flg;
    private String action2Flg;
    private String dpdStr;
    private String coRmId;
    private String coAeId;
    private Integer coRespUnit;
    private String coRespUnitStr;
    private String coAoId;
    //---Export excel
    private int index ;
    //--- CRL-R3
    private String typesFlg;
    private Date nextRatingDate;
    private String nextRatingDateStr;
    private String bucketRenewalFinal;
    private String bucketRating;
    private String bucketRatingFinal;
    private Date reviewDateFinal;
    private String reviewDateFinalStr;
    private String reasonRenewal;
    private Date ratingDateFinal;
    private String ratingDateFinalStr;
    private String assignRating;
    private String reasonRating;
    private String bucketRenewal;

               
    public String getSpAccount() {
        return spAccount;
    }

    public void setSpAccount(String spAccount) {
        this.spAccount = spAccount;
    }
   
    
    public Integer getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(Integer warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public String getBcmFlag() {
        return bcmFlag;
    }

    public void setBcmFlag(String bcmFlag) {
        this.bcmFlag = bcmFlag;
    }

    public String getCrFlag() {
        return crFlag;
    }

    public void setCrFlag(String crFlag) {
        this.crFlag = crFlag;
    }

    public Integer getDpd() {
        return dpd;
    }

    public void setDpd(Integer dpd) {
        this.dpd = dpd;
    }


    public String getEwsFlag() {
        return ewsFlag;
    }

    public void setEwsFlag(String ewsFlag) {
        this.ewsFlag = ewsFlag;
    }

    public String getEwsRiskLevel() {
        return ewsRiskLevel;
    }

    public void setEwsRiskLevel(String ewsRiskLevel) {
        this.ewsRiskLevel = ewsRiskLevel;
    }

    public String getPayFlag() {
        return payFlag;
    }

    public void setPayFlag(String payFlag) {
        this.payFlag = payFlag;
    }

    public String getQcaFlag() {
        return qcaFlag;
    }

    public void setQcaFlag(String qcaFlag) {
        this.qcaFlag = qcaFlag;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTaFlag() {
        return taFlag;
    }

    public void setTaFlag(String taFlag) {
        this.taFlag = taFlag;
    }

    public String getTrigFlag() {
        return trigFlag;
    }

    public void setTrigFlag(String trigFlag) {
        this.trigFlag = trigFlag;
    }

    public Date getWarningDate() {
        return warningDate;
    }

    public void setWarningDate(Date warningDate) {
        this.warningDate = warningDate;
    }

   

    public CustomerVo getCustomerVo() {
        return customerVo;
    }

    public void setCustomerVo(CustomerVo customerVo) {
        this.customerVo = customerVo;
    }

    public String getWarningDateStr() {
        return warningDateStr;
    }

    public void setWarningDateStr(String warningDateStr) {
        this.warningDateStr = warningDateStr;
    }

    public Integer getSla() {
        return sla;
    }

    public void setSla(Integer sla) {
        this.sla = sla;
    }

    public String getSlaStr() {
        return slaStr;
    }

    public void setSlaStr(String slaStr) {
        this.slaStr = slaStr;
    }

    public String getBucketDpd() {
        return bucketDpd;
    }

    public void setBucketDpd(String bucketDpd) {
        this.bucketDpd = bucketDpd;
    }

    public String getDpdStrFormat() {
        return dpdStrFormat;
    }

    public void setDpdStrFormat(String dpdStrFormat) {
        this.dpdStrFormat = dpdStrFormat;
    }

    public String getCrBucket() {
        return crBucket;
    }

    public void setCrBucket(String crBucket) {
        this.crBucket = crBucket;
    }

    public Integer getCrExpiryCount() {
        return crExpiryCount;
    }

    public void setCrExpiryCount(Integer crExpiryCount) {
        this.crExpiryCount = crExpiryCount;
    }

    

    public Date getCrExpiryDt() {
        return crExpiryDt;
    }

    public void setCrExpiryDt(Date crExpiryDt) {
        this.crExpiryDt = crExpiryDt;
    }

    public String getFormAssign() {
        return formAssign;
    }

    public void setFormAssign(String formAssign) {
        this.formAssign = formAssign;
    }

    public String getCrFormAssign() {
        return crFormAssign;
    }

    public void setCrFormAssign(String crFormAssign) {
        this.crFormAssign = crFormAssign;
    }

    public String getTrigPayResult() {
        return trigPayResult;
    }

    public void setTrigPayResult(String trigPayResult) {
        this.trigPayResult = trigPayResult;
    }

    public String getCrExpiryDtStr() {
        return crExpiryDtStr;
    }

    public void setCrExpiryDtStr(String crExpiryDtStr) {
        this.crExpiryDtStr = crExpiryDtStr;
    }

    public String getOverLimitFlag() {
        return overLimitFlag;
    }

    public void setOverLimitFlag(String overLimitFlag) {
        this.overLimitFlag = overLimitFlag;
    }

    public int getSumTrackingEwsq() {
        return sumTrackingEwsq;
    }

    public void setSumTrackingEwsq(int sumTrackingEwsq) {
        this.sumTrackingEwsq = sumTrackingEwsq;
    }

    public int getSumTrackingFin() {
        return sumTrackingFin;
    }

    public void setSumTrackingFin(int sumTrackingFin) {
        this.sumTrackingFin = sumTrackingFin;
    }

    public int getSumTrackingPay() {
        return sumTrackingPay;
    }

    public void setSumTrackingPay(int sumTrackingPay) {
        this.sumTrackingPay = sumTrackingPay;
    }

    public int getSumTrackingQca() {
        return sumTrackingQca;
    }

    public void setSumTrackingQca(int sumTrackingQca) {
        this.sumTrackingQca = sumTrackingQca;
    }

    public int getSumTrackingTrig() {
        return sumTrackingTrig;
    }

    public void setSumTrackingTrig(int sumTrackingTrig) {
        this.sumTrackingTrig = sumTrackingTrig;
    }

    public String getQuantiRiskLevel() {
        return quantiRiskLevel;
    }

    public void setQuantiRiskLevel(String quantiRiskLevel) {
        this.quantiRiskLevel = quantiRiskLevel;
    }

    public String getQualiRiskLevel() {
        return qualiRiskLevel;
    }

    public void setQualiRiskLevel(String qualiRiskLevel) {
        this.qualiRiskLevel = qualiRiskLevel;
    }

    public int getSumTrackingTrigAndPay() {
        return sumTrackingTrigAndPay;
    }

    public void setSumTrackingTrigAndPay(int sumTrackingTrigAndPay) {
        this.sumTrackingTrigAndPay = sumTrackingTrigAndPay;
    }

    public String getTrigAndPayFlag() {
        return trigAndPayFlag;
    }

    public void setTrigAndPayFlag(String trigAndPayFlag) {
        this.trigAndPayFlag = trigAndPayFlag;
    }
    
    public String getWarningDateS() {
        if(getWarningDate() != null){
            return DateUtil.getDateInThaiFormat(getWarningDate());
        }
        return "";
    }

    public String getBatchDateS() {
        if(getCreatedDate() != null){
            return DateUtil.getDateInThaiFormat(getCreatedDate());
        }
        return "";
    }

    public String getDisableFlag() {
        return disableFlag;
    }

    public void setDisableFlag(String disableFlag) {
        this.disableFlag = disableFlag;
    }

    public String getCFinal() {
        return cFinal;
    }

    public void setCFinal(String cFinal) {
        this.cFinal = cFinal;
    }

    public String getUpdateFinFlg() {
        return updateFinFlg;
    }

    public void setUpdateFinFlg(String updateFinFlg) {
        this.updateFinFlg = updateFinFlg;
    }

    public String getUpdateQcaFlg() {
        return updateQcaFlg;
    }

    public void setUpdateQcaFlg(String updateQcaFlg) {
        this.updateQcaFlg = updateQcaFlg;
    }

    public String getUpdateQualFlg() {
        return updateQualFlg;
    }

    public void setUpdateQualFlg(String updateQualFlg) {
        this.updateQualFlg = updateQualFlg;
    }

    public Date getEwsRiskDt() {
        return ewsRiskDt;
    }

    public void setEwsRiskDt(Date ewsRiskDt) {
        this.ewsRiskDt = ewsRiskDt;
    }

    public String getEwsRiskDtStr() {
        return ewsRiskDtStr;
    }

    public void setEwsRiskDtStr(String ewsRiskDtStr) {
        this.ewsRiskDtStr = ewsRiskDtStr;
    }

    public Integer getOdOverLimit() {
        return odOverLimit;
    }

    public void setOdOverLimit(Integer odOverLimit) {
        this.odOverLimit = odOverLimit;
    }

    public String getOdOverLimitStr() {
        return odOverLimitStr;
    }

    public void setOdOverLimitStr(String odOverLimitStr) {
        this.odOverLimitStr = odOverLimitStr;
    }

    public String getcFinal() {
        return cFinal;
    }

    public void setcFinal(String cFinal) {
        this.cFinal = cFinal;
    }

//    public String getActionFlg() {
//        return actionFlg;
//    }
//
//    public void setActionFlg(String actionFlg) {
//        this.actionFlg = actionFlg;
//    }

    public String getAeId() {
        return aeId;
    }

    public void setAeId(String aeId) {
        this.aeId = aeId;
    }

    public String getAoId() {
        return aoId;
    }

    public void setAoId(String aoId) {
        this.aoId = aoId;
    }

    public String getCrAcctCnt() {
        return crAcctCnt;
    }

    public void setCrAcctCnt(String crAcctCnt) {
        this.crAcctCnt = crAcctCnt;
    }

    public String getCrWarningCnt() {
        return crWarningCnt;
    }

    public void setCrWarningCnt(String crWarningCnt) {
        this.crWarningCnt = crWarningCnt;
    }

    public String getCreditRatingFlg() {
        return creditRatingFlg;
    }

    public void setCreditRatingFlg(String creditRatingFlg) {
        this.creditRatingFlg = creditRatingFlg;
    }

    public int getDpdAcctCnt() {
        return dpdAcctCnt;
    }

    public void setDpdAcctCnt(int dpdAcctCnt) {
        this.dpdAcctCnt = dpdAcctCnt;
    }

    public String getFinFlg() {
        return finFlg;
    }

    public void setFinFlg(String finFlg) {
        this.finFlg = finFlg;
    }

    public String getLatePayFlg() {
        return latePayFlg;
    }

    public void setLatePayFlg(String latePayFlg) {
        this.latePayFlg = latePayFlg;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getMaturityDateStr() {
        return maturityDateStr;
    }

    public void setMaturityDateStr(String maturityDateStr) {
        this.maturityDateStr = maturityDateStr;
    }

 

  

    public int getOdAcctCnt() {
        return odAcctCnt;
    }

    public void setOdAcctCnt(int odAcctCnt) {
        this.odAcctCnt = odAcctCnt;
    }

    public BigDecimal getOdOverAmt() {
        return odOverAmt;
    }

    public void setOdOverAmt(BigDecimal odOverAmt) {
        this.odOverAmt = odOverAmt;
    }

    public String getQualiFlg() {
        return qualiFlg;
    }

    public void setQualiFlg(String qualiFlg) {
        this.qualiFlg = qualiFlg;
    }

    public Integer getRespUnit() {
        return respUnit;
    }

    public void setRespUnit(Integer respUnit) {
        this.respUnit = respUnit;
    }

    public String getRmId() {
        return rmId;
    }

    public void setRmId(String rmId) {
        this.rmId = rmId;
    }

    public BigDecimal getUnpaidAmt() {
        return unpaidAmt;
    }

    public void setUnpaidAmt(BigDecimal unpaidAmt) {
        this.unpaidAmt = unpaidAmt;
    }

    public BigDecimal getWarningHeaderIdDec() {
        return warningHeaderIdDec;
    }

    public void setWarningHeaderIdDec(BigDecimal warningHeaderIdDec) {
        this.warningHeaderIdDec = warningHeaderIdDec;
    }

//    public String getWayOutFlg() {
//        return wayOutFlg;
//    }
//
//    public void setWayOutFlg(String wayOutFlg) {
//        this.wayOutFlg = wayOutFlg;
//    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getCrFlg() {
        return crFlg;
    }

    public void setCrFlg(String crFlg) {
        this.crFlg = crFlg;
    }

    public String getRespUnitStr() {
        return respUnitStr;
    }

    public void setRespUnitStr(String respUnitStr) {
        this.respUnitStr = respUnitStr;
    }

    public String getUnpaidAmtStr() {
        return unpaidAmtStr;
    }

    public void setUnpaidAmtStr(String unpaidAmtStr) {
        this.unpaidAmtStr = unpaidAmtStr;
    }

    public String getOdOverAmtStr() {
        return odOverAmtStr;
    }

    public void setOdOverAmtStr(String odOverAmtStr) {
        this.odOverAmtStr = odOverAmtStr;
    }

    public String getOdAcctCntStr() {
        return odAcctCntStr;
    }

    public void setOdAcctCntStr(String odAcctCntStr) {
        this.odAcctCntStr = odAcctCntStr;
    }

    public String getDpdAcctCntStr() {
        return dpdAcctCntStr;
    }

    public void setDpdAcctCntStr(String dpdAcctCntStr) {
        this.dpdAcctCntStr = dpdAcctCntStr;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getCountAlertLp() {
        return countAlertLp;
    }

    public void setCountAlertLp(String countAlertLp) {
        this.countAlertLp = countAlertLp;
    }

//    public String getCountAlertWo() {
//        return countAlertWo;
//    }
//
//    public void setCountAlertWo(String countAlertWo) {
//        this.countAlertWo = countAlertWo;
//    }

    public String getCountAlertQf() {
        return countAlertQf;
    }

    public void setCountAlertQf(String countAlertQf) {
        this.countAlertQf = countAlertQf;
    }

//    public String getCountAlertAf() {
//        return countAlertAf;
//    }
//
//    public void setCountAlertAf(String countAlertAf) {
//        this.countAlertAf = countAlertAf;
//    }

    public String getCountAlertFf() {
        return countAlertFf;
    }

    public void setCountAlertFf(String countAlertFf) {
        this.countAlertFf = countAlertFf;
    }

    public int getCrSla() {
        return crSla;
    }

    public void setCrSla(int crSla) {
        this.crSla = crSla;
    }
    public String getBucketDpdOd() {
        return bucketDpdOd;
    }

    public void setBucketDpdOd(String bucketDpdOd) {
        this.bucketDpdOd = bucketDpdOd;
    }

    public String getBucketDpdFinal() {
        return bucketDpdFinal;
    }

    public void setBucketDpdFinal(String bucketDpdFinal) {
        this.bucketDpdFinal = bucketDpdFinal;
    }

    public Date getDelinqDate() {
        return delinqDate;
    }

    public void setDelinqDate(Date delinqDate) {
        this.delinqDate = delinqDate;
    }

    public String getDelinqDateStr() {
        return delinqDateStr;
    }

    public void setDelinqDateStr(String delinqDateStr) {
        this.delinqDateStr = delinqDateStr;
    }

    public String getHvDelinqDate() {
        return hvDelinqDate;
    }

    public void setHvDelinqDate(String hvDelinqDate) {
        this.hvDelinqDate = hvDelinqDate;
    }

    public String getRiskLevelChange() {
        return riskLevelChange;
    }

    public void setRiskLevelChange(String riskLevelChange) {
        this.riskLevelChange = riskLevelChange;
    }

    public BigDecimal getCrSlaBigDecimal() {
        return crSlaBigDecimal;
    }

    public void setCrSlaBigDecimal(BigDecimal crSlaBigDecimal) {
        this.crSlaBigDecimal = crSlaBigDecimal;
    }
    public Integer getDpdOd() {
        return dpdOd;
    }

    public void setDpdOd(Integer dpdOd) {
        this.dpdOd = dpdOd;
    }

    public BigDecimal getDpdOdBigdecimal() {
        return dpdOdBigdecimal;
    }

    public void setDpdOdBigdecimal(BigDecimal dpdOdBigdecimal) {
        this.dpdOdBigdecimal = dpdOdBigdecimal;
    }

    public String getAction1Flg() {
        return action1Flg;
    }

    public void setAction1Flg(String action1Flg) {
        this.action1Flg = action1Flg;
    }

    public String getAction2Flg() {
        return action2Flg;
    }

    public void setAction2Flg(String action2Flg) {
        this.action2Flg = action2Flg;
    }

    public String getCountAlertAf1() {
        return countAlertAf1;
    }

    public void setCountAlertAf1(String countAlertAf1) {
        this.countAlertAf1 = countAlertAf1;
    }

    public String getCountAlertAf2() {
        return countAlertAf2;
    }

    public void setCountAlertAf2(String countAlertAf2) {
        this.countAlertAf2 = countAlertAf2;
    }

    public String getDpdStr() {
        return dpdStr;
    }

    public void setDpdStr(String dpdStr) {
        this.dpdStr = dpdStr;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getCoRmId() {
        return coRmId;
    }

    public void setCoRmId(String coRmId) {
        this.coRmId = coRmId;
    }

    public String getCoAeId() {
        return coAeId;
    }

    public void setCoAeId(String coAeId) {
        this.coAeId = coAeId;
    }

    public Integer getCoRespUnit() {
        return coRespUnit;
    }

    public void setCoRespUnit(Integer coRespUnit) {
        this.coRespUnit = coRespUnit;
    }

    public String getCoRespUnitStr() {
        return coRespUnitStr;
    }

    public void setCoRespUnitStr(String coRespUnitStr) {
        this.coRespUnitStr = coRespUnitStr;
    }

    public String getCoAoId() {
        return coAoId;
    }

    public void setCoAoId(String coAoId) {
        this.coAoId = coAoId;
    }

    public String getTypesFlg() {
        return typesFlg;
    }

    public void setTypesFlg(String typesFlg) {
        this.typesFlg = typesFlg;
    }


    public Date getNextRatingDate() {
        return nextRatingDate;
    }

    public void setNextRatingDate(Date nextRatingDate) {
        this.nextRatingDate = nextRatingDate;
    }

    public String getNextRatingDateStr() {
        return nextRatingDateStr;
    }

    public void setNextRatingDateStr(String nextRatingDateStr) {
        this.nextRatingDateStr = nextRatingDateStr;
    }

    public String getBucketRenewalFinal() {
        return bucketRenewalFinal;
    }

    public void setBucketRenewalFinal(String bucketRenewalFinal) {
        this.bucketRenewalFinal = bucketRenewalFinal;
    }



    public String getBucketRating() {
        return bucketRating;
    }

    public void setBucketRating(String bucketRating) {
        this.bucketRating = bucketRating;
    }

    public String getBucketRatingFinal() {
        return bucketRatingFinal;
    }

    public void setBucketRatingFinal(String bucketRatingFinal) {
        this.bucketRatingFinal = bucketRatingFinal;
    }

    public Date getReviewDateFinal() {
        return reviewDateFinal;
    }

    public void setReviewDateFinal(Date reviewDateFinal) {
        this.reviewDateFinal = reviewDateFinal;
    }

    public String getReviewDateFinalStr() {
        return reviewDateFinalStr;
    }

    public void setReviewDateFinalStr(String reviewDateFinalStr) {
        this.reviewDateFinalStr = reviewDateFinalStr;
    }

  

    public String getReasonRenewal() {
        return reasonRenewal;
    }

    public void setReasonRenewal(String reasonRenewal) {
        this.reasonRenewal = reasonRenewal;
    }

    public Date getRatingDateFinal() {
        return ratingDateFinal;
    }

    public void setRatingDateFinal(Date ratingDateFinal) {
        this.ratingDateFinal = ratingDateFinal;
    }

    public String getRatingDateFinalStr() {
        return ratingDateFinalStr;
    }

    public void setRatingDateFinalStr(String ratingDateFinalStr) {
        this.ratingDateFinalStr = ratingDateFinalStr;
    }

    public String getAssignRating() {
        return assignRating;
    }

    public void setAssignRating(String assignRating) {
        this.assignRating = assignRating;
    }

    public String getReasonRating() {
        return reasonRating;
    }

    public void setReasonRating(String reasonRating) {
        this.reasonRating = reasonRating;
    }

    public String getBucketRenewal() {
        return bucketRenewal;
    }

    public void setBucketRenewal(String bucketRenewal) {
        this.bucketRenewal = bucketRenewal;
    }
    
}
