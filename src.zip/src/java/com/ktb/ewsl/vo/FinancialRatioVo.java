package com.ktb.ewsl.vo;

public class FinancialRatioVo {
    private String orderNo;
    private String groupCode;
    private String accountCode;
    private String descriptionTh;
    private String unit;
    private String modelId;
    private String finStatementDate;
    private String finRatioValue;

    private String ratioAudit1;
    private String ratioAudit2;
    private String ratioAudit3;
    private String ratioAdjust1;
    private String ratioAdjust2;
    private String ratioAdjust3;

    public String getAccountCode() {
        return accountCode;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public String getDescriptionTh() {
        return descriptionTh;
    }

    public void setDescriptionTh(String descriptionTh) {
        this.descriptionTh = descriptionTh;
    }

    public String getFinRatioValue() {
        return finRatioValue;
    }

    public void setFinRatioValue(String finRatioValue) {
        this.finRatioValue = finRatioValue;
    }

    public String getFinStatementDate() {
        return finStatementDate;
    }

    public void setFinStatementDate(String finStatementDate) {
        this.finStatementDate = finStatementDate;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }

    public String getRatioAdjust1() {
        if(ratioAdjust1==null || ratioAdjust1.trim().length() == 0) return "n/a";
        return ratioAdjust1;
    }

    public void setRatioAdjust1(String ratioAdjust1) {
        this.ratioAdjust1 = ratioAdjust1;
    }

    public String getRatioAdjust2() {
         if(ratioAdjust2==null || ratioAdjust2.trim().length() == 0) return "n/a";
        return ratioAdjust2;
    }

    public void setRatioAdjust2(String ratioAdjust2) {
        this.ratioAdjust2 = ratioAdjust2;
    }

    public String getRatioAdjust3() {
         if(ratioAdjust3==null || ratioAdjust3.trim().length() == 0) return "n/a";
        return ratioAdjust3;
    }

    public void setRatioAdjust3(String ratioAdjust3) {
        this.ratioAdjust3 = ratioAdjust3;
    }

    public String getRatioAudit1() {
         if(ratioAudit1==null || ratioAudit1.trim().length() == 0) return "n/a";
        return ratioAudit1;
    }

    public void setRatioAudit1(String ratioAudit1) {
        this.ratioAudit1 = ratioAudit1;
    }

    public String getRatioAudit2() {
         if(ratioAudit2==null || ratioAudit2.trim().length() == 0) return "n/a";
        return ratioAudit2;
    }

    public void setRatioAudit2(String ratioAudit2) {
        this.ratioAudit2 = ratioAudit2;
    }

    public String getRatioAudit3() {
         if(ratioAudit3==null || ratioAudit3.trim().length() == 0) return "n/a";
        return ratioAudit3;
    }

    public void setRatioAudit3(String ratioAudit3) {
        this.ratioAudit3 = ratioAudit3;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

}
