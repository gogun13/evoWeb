/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author pumin
 */
public class ActionAccountVo {
    private String accountNo;
    private String accountSubType;
    private String actionFlg;
    private String billNo;
    private String cFinal;
    private String createdBy;
    private String createdDt;
    private String dpd;
    private String dpdZeroDate;
    private String dueAmt;
    private String dueDate;
    private String inputAccountNo;
    private String inputBillNo;
    private String isClosed;
    private String lateCharge;
    private String limitAmt;
    private String loanType;
    private String maturityDate;
    private String odOverLimit;
    private String outstandingAmt;
    private String paidDate;
    private String productGroup;
    private String productType;
    private String sourceSystem;
    private String unpaidAmt;
    private String unpaidInterest;
    private String unpaidPrincipal;
    private String updatedBy;
    private String updatedDt;
    private String warningHeadId;
    private String loanGrpProd;
    private String seqTemp;
    private String warningId;

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountSubType() {
        return accountSubType;
    }

    public void setAccountSubType(String accountSubType) {
        this.accountSubType = accountSubType;
    }

    public String getActionFlg() {
        return actionFlg;
    }

    public void setActionFlg(String actionFlg) {
        this.actionFlg = actionFlg;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getcFinal() {
        return cFinal;
    }

    public void setcFinal(String cFinal) {
        this.cFinal = cFinal;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }

    public String getDpd() {
        return dpd;
    }

    public void setDpd(String dpd) {
        this.dpd = dpd;
    }

    public String getDpdZeroDate() {
        return dpdZeroDate;
    }

    public void setDpdZeroDate(String dpdZeroDate) {
        this.dpdZeroDate = dpdZeroDate;
    }

    public String getDueAmt() {
        return dueAmt;
    }

    public void setDueAmt(String dueAmt) {
        this.dueAmt = dueAmt;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getInputAccountNo() {
        return inputAccountNo;
    }

    public void setInputAccountNo(String inputAccountNo) {
        this.inputAccountNo = inputAccountNo;
    }

    public String getInputBillNo() {
        return inputBillNo;
    }

    public void setInputBillNo(String inputBillNo) {
        this.inputBillNo = inputBillNo;
    }

    public String getIsClosed() {
        return isClosed;
    }

    public void setIsClosed(String isClosed) {
        this.isClosed = isClosed;
    }

    public String getLateCharge() {
        return lateCharge;
    }

    public void setLateCharge(String lateCharge) {
        this.lateCharge = lateCharge;
    }

    public String getLimitAmt() {
        return limitAmt;
    }

    public void setLimitAmt(String limitAmt) {
        this.limitAmt = limitAmt;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getOdOverLimit() {
        return odOverLimit;
    }

    public void setOdOverLimit(String odOverLimit) {
        this.odOverLimit = odOverLimit;
    }

    public String getOutstandingAmt() {
        return outstandingAmt;
    }

    public void setOutstandingAmt(String outstandingAmt) {
        this.outstandingAmt = outstandingAmt;
    }

    public String getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(String paidDate) {
        this.paidDate = paidDate;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getUnpaidAmt() {
        return unpaidAmt;
    }

    public void setUnpaidAmt(String unpaidAmt) {
        this.unpaidAmt = unpaidAmt;
    }

    public String getUnpaidInterest() {
        return unpaidInterest;
    }

    public void setUnpaidInterest(String unpaidInterest) {
        this.unpaidInterest = unpaidInterest;
    }

    public String getUnpaidPrincipal() {
        return unpaidPrincipal;
    }

    public void setUnpaidPrincipal(String unpaidPrincipal) {
        this.unpaidPrincipal = unpaidPrincipal;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(String updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getWarningHeadId() {
        return warningHeadId;
    }

    public void setWarningHeadId(String warningHeadId) {
        this.warningHeadId = warningHeadId;
    }

    public String getLoanGrpProd() {
        return loanGrpProd;
    }

    public void setLoanGrpProd(String loanGrpProd) {
        this.loanGrpProd = loanGrpProd;
    }

    public String getSeqTemp() {
        return seqTemp;
    }

    public void setSeqTemp(String seqTemp) {
        this.seqTemp = seqTemp;
    }

    public String getWarningId() {
        return warningId;
    }

    public void setWarningId(String warningId) {
        this.warningId = warningId;
    }

        
}
