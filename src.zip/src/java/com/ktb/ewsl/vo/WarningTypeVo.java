/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;


/**
 *
 * @author Tum_Surapong
 */
public class WarningTypeVo extends BaseVo{
    private String warningTypeCode;
    private String warningTypeDesc;
    private String questionId;
    private String questionVersion;   
    private String updateDtSt;
    private int sla;
    private String warningTypeGroup;
    private int seq;
    private String shortName;
    private WarningTypePrivilegeVo warningTypePrivilegeVo;
    private String isActive;
    private String underWarningType;
    private String alertFirstWarningFlg;
    private String alertType;
    private String alertValue;
    private String exceedSlaAlertType;
    private String exceedSlaAlertValue;
    private String exceedSlaAlertLimit;
    private String alertAtEndSlaFlg;
    private String isActiveDesc;
    
    public String getWarningTypeCode() {
        return warningTypeCode;
    }

    public void setWarningTypeCode(String warningTypeCode) {
        this.warningTypeCode = warningTypeCode;
    }

    public String getWarningTypeDesc() {
        return warningTypeDesc;
    }

    public void setWarningTypeDesc(String warningTypeDesc) {
        this.warningTypeDesc = warningTypeDesc;
    }

    public String getQuestionVersion() {
        return questionVersion;
    }

    public void setQuestionVersion(String questionVersion) {
        this.questionVersion = questionVersion;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public int getSla() {
        return sla;
    }

    public void setSla(int sla) {
        this.sla = sla;
    }

    public String getUpdateDtSt() {
        return updateDtSt;
    }

    public void setUpdateDtSt(String updateDtSt) {
        this.updateDtSt = updateDtSt;
    }

    public WarningTypePrivilegeVo getWarningTypePrivilegeVo() {
        return warningTypePrivilegeVo;
    }

    public void setWarningTypePrivilegeVo(WarningTypePrivilegeVo warningTypePrivilegeVo) {
        this.warningTypePrivilegeVo = warningTypePrivilegeVo;
    }

    public String getWarningTypeGroup() {
        return warningTypeGroup;
    }

    public void setWarningTypeGroup(String warningTypeGroup) {
        this.warningTypeGroup = warningTypeGroup;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getUnderWarningType() {
        return underWarningType;
    }

    public void setUnderWarningType(String underWarningType) {
        this.underWarningType = underWarningType;
    }

    public String getAlertFirstWarningFlg() {
        return alertFirstWarningFlg;
    }

    public void setAlertFirstWarningFlg(String alertFirstWarningFlg) {
        this.alertFirstWarningFlg = alertFirstWarningFlg;
    }

    public String getAlertType() {
        return alertType;
    }

    public void setAlertType(String alertType) {
        this.alertType = alertType;
    }

    public String getAlertValue() {
        return alertValue;
    }

    public void setAlertValue(String alertValue) {
        this.alertValue = alertValue;
    }

    public String getExceedSlaAlertType() {
        return exceedSlaAlertType;
    }

    public void setExceedSlaAlertType(String exceedSlaAlertType) {
        this.exceedSlaAlertType = exceedSlaAlertType;
    }

    public String getExceedSlaAlertValue() {
        return exceedSlaAlertValue;
    }

    public void setExceedSlaAlertValue(String exceedSlaAlertValue) {
        this.exceedSlaAlertValue = exceedSlaAlertValue;
    }

    public String getExceedSlaAlertLimit() {
        return exceedSlaAlertLimit;
    }

    public void setExceedSlaAlertLimit(String exceedSlaAlertLimit) {
        this.exceedSlaAlertLimit = exceedSlaAlertLimit;
    }

    public String getAlertAtEndSlaFlg() {
        return alertAtEndSlaFlg;
    }

    public void setAlertAtEndSlaFlg(String alertAtEndSlaFlg) {
        this.alertAtEndSlaFlg = alertAtEndSlaFlg;
    }

    public String getIsActiveDesc() {
        return isActiveDesc;
    }

    public void setIsActiveDesc(String isActiveDesc) {
        this.isActiveDesc = isActiveDesc;
    }

    
   
}
