/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Tum_Surapong
 */
public class AsstQuestionVo extends BaseVo{
    private String questionId;
    private String questionDesc;
    private String version;
    private Date questionStartDt;
    
    private ArrayList<AsstTopicVo> asstTopicVoList;

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getQuestionDesc() {
        return questionDesc;
    }

    public void setQuestionDesc(String questionDesc) {
        this.questionDesc = questionDesc;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getQuestionStartDt() {
        return questionStartDt;
    }

    public void setQuestionStartDt(Date questionStartDt) {
        this.questionStartDt = questionStartDt;
    }

    public ArrayList<AsstTopicVo> getAsstTopicVoList() {
        return asstTopicVoList;
    }

    public void setAsstTopicVoList(ArrayList<AsstTopicVo> asstTopicVoList) {
        this.asstTopicVoList = asstTopicVoList;
    }

   
    
}
