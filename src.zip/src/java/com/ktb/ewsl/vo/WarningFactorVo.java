/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;

/**
 *
 * @author Siriwat Asamo
 */
public class WarningFactorVo extends BaseVo {
 
    private Integer warningId;
    private BigDecimal factorCd;
    private String factorDesc;
    private String factorValue;
    private Double weightedScore;
    private int attributeId;

    public Integer getWarningId() {
        return warningId;
    }

    public void setWarningId(Integer warningId) {
        this.warningId = warningId;
    }

    public BigDecimal getFactorCd() {
        return factorCd;
    }

    public void setFactorCd(BigDecimal factorCd) {
        this.factorCd = factorCd;
    }

    public String getFactorDesc() {
        return factorDesc;
    }

    public void setFactorDesc(String factorDesc) {
        this.factorDesc = factorDesc;
    }

    public String getFactorValue() {
        return factorValue;
    }

    public void setFactorValue(String factorValue) {
        this.factorValue = factorValue;
    }

    public Double getWeightedScore() {
        return weightedScore;
    }

    public void setWeightedScore(Double weightedScore) {
        this.weightedScore = weightedScore;
    }

    public int getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(int attributeId) {
        this.attributeId = attributeId;
    }       
    
}
