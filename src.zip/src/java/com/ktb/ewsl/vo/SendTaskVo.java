/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author KTBDevLoan
 */
public class SendTaskVo {
    
     private int sendTaskId;
     private String appId;
     private String frmUserId;
     private String toUserId;   
     private String frmStatus;
     private String toStatus;
     private String frmTitle;
     private String frmFname;
     private String frmLname;

    public int getSendTaskId() {
        return sendTaskId;
    }

    public void setSendTaskId(int sendTaskId) {
        this.sendTaskId = sendTaskId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getFrmUserId() {
        return frmUserId;
    }

    public void setFrmUserId(String frmUserId) {
        this.frmUserId = frmUserId;
    }

    public String getToUserId() {
        return toUserId;
    }

    public void setToUserId(String toUserId) {
        this.toUserId = toUserId;
    }

    public String getFrmStatus() {
        return frmStatus;
    }

    public void setFrmStatus(String frmStatus) {
        this.frmStatus = frmStatus;
    }

    public String getToStatus() {
        return toStatus;
    }

    public void setToStatus(String toStatus) {
        this.toStatus = toStatus;
    }

    public String getFrmTitle() {
        return frmTitle;
    }

    public void setFrmTitle(String frmTitle) {
        this.frmTitle = frmTitle;
    }

    public String getFrmFname() {
        return frmFname;
    }

    public void setFrmFname(String frmFname) {
        this.frmFname = frmFname;
    }

    public String getFrmLname() {
        return frmLname;
    }

    public void setFrmLname(String frmLname) {
        this.frmLname = frmLname;
    }
  
}
