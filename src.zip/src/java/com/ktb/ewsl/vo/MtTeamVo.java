/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;

/**
 *
 * @author aon
 */
public class MtTeamVo extends BaseVo {

    private String teamId;
    private String teamName;
    private String dispRoleId;
    private String dispRoleName;
    private String status;

    private boolean selected;
    /**
     * @return the teamId
     */
    public String getTeamId() {
        return teamId;
    }

    /**
     * @param teamId the teamId to set
     */
    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    /**
     * @return the teamName
     */
    public String getTeamName() {
        return teamName;
    }

    /**
     * @param teamName the teamName to set
     */
    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
  

    /**
     * @return the selected
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * @param selected the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * @return the dispRoleId
     */
    public String getDispRoleId() {
        return dispRoleId;
    }

    /**
     * @param dispRoleId the dispRoleId to set
     */
    public void setDispRoleId(String dispRoleId) {
        this.dispRoleId = dispRoleId;
    }

    /**
     * @return the dispRoleName
     */
    public String getDispRoleName() {
        return dispRoleName;
    }

    /**
     * @param dispRoleName the dispRoleName to set
     */
    public void setDispRoleName(String dispRoleName) {
        this.dispRoleName = dispRoleName;
    }
}
