/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Siriwat Asamo
 */
public class WarningProcessVo extends BaseVo {

     private int warningHeaderId;  
     private BigDecimal finODDS;
     private String hvFin;
     private String hvNCB;
     private String hvQuanti;
     private String hvRating;
     private BigDecimal ncbODDSEWS;
     private BigDecimal ncbODDSEWSOnline;
     private BigDecimal ncbODDSIndEWS;
     private BigDecimal ncbODDSIndEWSBackup;
     private BigDecimal ncbODDSIndEWSBackupOnline;
     private BigDecimal ncbODDSIndEWSOnline;
     private BigDecimal quantiBhvODDS;
     private BigDecimal ratingODDS;
     private BigDecimal finPD;
     private BigDecimal finScore;
     private String ncbLastUpdate;
     private Integer warningId;
     //------- CRL-R3
     private String assignRating;
     private String authorizeRatingDateStr;
     private Date authorizeRatingDate;
     private String authorizeReviewDateStr;
     private Date authorizeReviewDate;
     private String bucketRating;
     private String bucketRatingFinal;
     private String bucketRenewalFinal;
     private String cClass;
     private Date minReviewDate;
     private String minReviewDateStr;
     private String modelID;
     private String nextRatingDateStr;
     private Date nextRatingDate;
     private String pauseFlg;
     private Date ratingDateFinal;
     private String ratingDateFinalStr ;
     private String ratingMth;
     private String reasonRating;
     private String reasonRenewal;
     private Date reviewDateFinal;
     private String reviewDateFinalStr;
     private String renewal;
             
    public int getWarningHeaderId() {
        return warningHeaderId;
    }

    public void setWarningHeaderId(int warningHeaderId) {
        this.warningHeaderId = warningHeaderId;
    }

    public BigDecimal getFinODDS() {
        return finODDS;
    }

    public void setFinODDS(BigDecimal finODDS) {
        this.finODDS = finODDS;
    }

    public String getHvFin() {
        return hvFin;
    }

    public void setHvFin(String hvFin) {
        this.hvFin = hvFin;
    }

    public String getHvNCB() {
        return hvNCB;
    }

    public void setHvNCB(String hvNCB) {
        this.hvNCB = hvNCB;
    }

    public String getHvQuanti() {
        return hvQuanti;
    }

    public void setHvQuanti(String hvQuanti) {
        this.hvQuanti = hvQuanti;
    }

    public String getHvRating() {
        return hvRating;
    }

    public void setHvRating(String hvRating) {
        this.hvRating = hvRating;
    }

    public BigDecimal getNcbODDSEWS() {
        return ncbODDSEWS;
    }

    public void setNcbODDSEWS(BigDecimal ncbODDSEWS) {
        this.ncbODDSEWS = ncbODDSEWS;
    }

    public BigDecimal getNcbODDSEWSOnline() {
        return ncbODDSEWSOnline;
    }

    public void setNcbODDSEWSOnline(BigDecimal ncbODDSEWSOnline) {
        this.ncbODDSEWSOnline = ncbODDSEWSOnline;
    }

    public BigDecimal getNcbODDSIndEWS() {
        return ncbODDSIndEWS;
    }

    public void setNcbODDSIndEWS(BigDecimal ncbODDSIndEWS) {
        this.ncbODDSIndEWS = ncbODDSIndEWS;
    }

    public BigDecimal getNcbODDSIndEWSBackup() {
        return ncbODDSIndEWSBackup;
    }

    public void setNcbODDSIndEWSBackup(BigDecimal ncbODDSIndEWSBackup) {
        this.ncbODDSIndEWSBackup = ncbODDSIndEWSBackup;
    }

    public BigDecimal getNcbODDSIndEWSBackupOnline() {
        return ncbODDSIndEWSBackupOnline;
    }

    public void setNcbODDSIndEWSBackupOnline(BigDecimal ncbODDSIndEWSBackupOnline) {
        this.ncbODDSIndEWSBackupOnline = ncbODDSIndEWSBackupOnline;
    }

    public BigDecimal getNcbODDSIndEWSOnline() {
        return ncbODDSIndEWSOnline;
    }

    public void setNcbODDSIndEWSOnline(BigDecimal ncbODDSIndEWSOnline) {
        this.ncbODDSIndEWSOnline = ncbODDSIndEWSOnline;
    }

    public BigDecimal getQuantiBhvODDS() {
        return quantiBhvODDS;
    }

    public void setQuantiBhvODDS(BigDecimal quantiBhvODDS) {
        this.quantiBhvODDS = quantiBhvODDS;
    }

    public BigDecimal getRatingODDS() {
        return ratingODDS;
    }

    public void setRatingODDS(BigDecimal ratingODDS) {
        this.ratingODDS = ratingODDS;
    }

    public BigDecimal getFinPD() {
        return finPD;
    }

    public void setFinPD(BigDecimal finPD) {
        this.finPD = finPD;
    }

    public BigDecimal getFinScore() {
        return finScore;
    }

    public void setFinScore(BigDecimal finScore) {
        this.finScore = finScore;
    }

    public String getNcbLastUpdate() {
        return ncbLastUpdate;
    }

    public void setNcbLastUpdate(String ncbLastUpdate) {
        this.ncbLastUpdate = ncbLastUpdate;
    }

    public Integer getWarningId() {
        return warningId;
    }

    public void setWarningId(Integer warningId) {
        this.warningId = warningId;
    }

    public String getAssignRating() {
        return assignRating;
    }

    public void setAssignRating(String assignRating) {
        this.assignRating = assignRating;
    }

    public String getAuthorizeRatingDateStr() {
        return authorizeRatingDateStr;
    }

    public void setAuthorizeRatingDateStr(String authorizeRatingDateStr) {
        this.authorizeRatingDateStr = authorizeRatingDateStr;
    }

    public Date getAuthorizeRatingDate() {
        return authorizeRatingDate;
    }

    public void setAuthorizeRatingDate(Date authorizeRatingDate) {
        this.authorizeRatingDate = authorizeRatingDate;
    }

    public String getAuthorizeReviewDateStr() {
        return authorizeReviewDateStr;
    }

    public void setAuthorizeReviewDateStr(String authorizeReviewDateStr) {
        this.authorizeReviewDateStr = authorizeReviewDateStr;
    }

    public Date getAuthorizeReviewDate() {
        return authorizeReviewDate;
    }

    public void setAuthorizeReviewDate(Date authorizeReviewDate) {
        this.authorizeReviewDate = authorizeReviewDate;
    }

    public String getBucketRating() {
        return bucketRating;
    }

    public void setBucketRating(String bucketRating) {
        this.bucketRating = bucketRating;
    }

    public String getBucketRatingFinal() {
        return bucketRatingFinal;
    }

    public void setBucketRatingFinal(String bucketRatingFinal) {
        this.bucketRatingFinal = bucketRatingFinal;
    }

    public String getBucketRenewalFinal() {
        return bucketRenewalFinal;
    }

    public void setBucketRenewalFinal(String bucketRenewalFinal) {
        this.bucketRenewalFinal = bucketRenewalFinal;
    }

    public String getcClass() {
        return cClass;
    }

    public void setcClass(String cClass) {
        this.cClass = cClass;
    }

    public Date getMinReviewDate() {
        return minReviewDate;
    }

    public void setMinReviewDate(Date minReviewDate) {
        this.minReviewDate = minReviewDate;
    }

    public String getMinReviewDateStr() {
        return minReviewDateStr;
    }

    public void setMinReviewDateStr(String minReviewDateStr) {
        this.minReviewDateStr = minReviewDateStr;
    }

    public String getModelID() {
        return modelID;
    }

    public void setModelID(String modelID) {
        this.modelID = modelID;
    }

    public String getNextRatingDateStr() {
        return nextRatingDateStr;
    }

    public void setNextRatingDateStr(String nextRatingDateStr) {
        this.nextRatingDateStr = nextRatingDateStr;
    }

    public Date getNextRatingDate() {
        return nextRatingDate;
    }

    public void setNextRatingDate(Date nextRatingDate) {
        this.nextRatingDate = nextRatingDate;
    }

    public String getPauseFlg() {
        return pauseFlg;
    }

    public void setPauseFlg(String pauseFlg) {
        this.pauseFlg = pauseFlg;
    }

    public Date getRatingDateFinal() {
        return ratingDateFinal;
    }

    public void setRatingDateFinal(Date ratingDateFinal) {
        this.ratingDateFinal = ratingDateFinal;
    }

    public String getRatingDateFinalStr() {
        return ratingDateFinalStr;
    }

    public void setRatingDateFinalStr(String ratingDateFinalStr) {
        this.ratingDateFinalStr = ratingDateFinalStr;
    }

    public String getRatingMth() {
        return ratingMth;
    }

    public void setRatingMth(String ratingMth) {
        this.ratingMth = ratingMth;
    }

    public String getReasonRating() {
        return reasonRating;
    }

    public void setReasonRating(String reasonRating) {
        this.reasonRating = reasonRating;
    }

    public String getReasonRenewal() {
        return reasonRenewal;
    }

    public void setReasonRenewal(String reasonRenewal) {
        this.reasonRenewal = reasonRenewal;
    }

    public Date getReviewDateFinal() {
        return reviewDateFinal;
    }

    public void setReviewDateFinal(Date reviewDateFinal) {
        this.reviewDateFinal = reviewDateFinal;
    }

    public String getReviewDateFinalStr() {
        return reviewDateFinalStr;
    }

    public void setReviewDateFinalStr(String reviewDateFinalStr) {
        this.reviewDateFinalStr = reviewDateFinalStr;
    }

    public String getRenewal() {
        return renewal;
    }

    public void setRenewal(String renewal) {
        this.renewal = renewal;
    }
        
}