/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import com.ktbcs.core.vo.BaseVo;
import java.util.ArrayList;

/**
 *
 * @author Tum_Surapong
 */
public class AsstSubtopicVo extends BaseVo{
    private String questionId;
    private String version;
    private int topicId;
    private int subTopicId;
    private String subTopicDesc;
    private int needChoice;
    private String choiceType;            
    private String answer;
    private String remark;
    private String choiceReason;
    private ArrayList<AsstChoiceVo> asstChoiceVoList;
    //---- For Trigger
    private ArrayList<AsstChoiceHaveTopicVo> asstChoiceHaveTopicVoList;
    
    private String answerRM;
    private String answerCM;
    private String remarkRM;
    private String remarkCM;
    private Integer warningId;
    //-----For EWS-L
    private ArrayList<AsstChoiceVo> asstSubtopicChoiceVoList;
    private String answerSubtopicChoice;
    private String choiceReasonSubtopic;
    //-----FOR OLD ANSWER BY AE/AO/RM
    private String oldAnswerQuali;
    private String oldAnswerSubtopicChoice;
    private String confirmAnswer;
    private String confirmChoiceReason;
    private String confirmAnswerNotBcm;
    private String confirmChoiceReasonNotBcm;

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    public int getSubTopicId() {
        return subTopicId;
    }

    public void setSubTopicId(int subTopicId) {
        this.subTopicId = subTopicId;
    }

    public String getSubTopicDesc() {
        return subTopicDesc;
    }

    public void setSubTopicDesc(String subTopicDesc) {
        this.subTopicDesc = subTopicDesc;
    }

    public int getNeedChoice() {
        return needChoice;
    }

    public void setNeedChoice(int needChoice) {
        this.needChoice = needChoice;
    }

    public String getChoiceType() {
        return choiceType;
    }

    public void setChoiceType(String choiceType) {
        this.choiceType = choiceType;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAnswerRM() {
        return answerRM;
    }

    public void setAnswerRM(String answerRM) {
        this.answerRM = answerRM;
    }

    public String getAnswerCM() {
        return answerCM;
    }

    public void setAnswerCM(String answerCM) {
        this.answerCM = answerCM;
    }

    public String getChoiceReason() {
        return choiceReason;
    }

    public void setChoiceReason(String choiceReason) {
        this.choiceReason = choiceReason;
    }

    public String getRemarkRM() {
        return remarkRM;
    }

    public void setRemarkRM(String remarkRM) {
        this.remarkRM = remarkRM;
    }

    public String getRemarkCM() {
        return remarkCM;
    }

    public void setRemarkCM(String remarkCM) {
        this.remarkCM = remarkCM;
    }

    public Integer getWarningId() {
        return warningId;
    }

    public void setWarningId(Integer warningId) {
        this.warningId = warningId;
    }

    public ArrayList<AsstChoiceVo> getAsstChoiceVoList() {
        return asstChoiceVoList;
    }

    public void setAsstChoiceVoList(ArrayList<AsstChoiceVo> asstChoiceVoList) {
        this.asstChoiceVoList = asstChoiceVoList;
    }

    public ArrayList<AsstChoiceHaveTopicVo> getAsstChoiceHaveTopicVoList() {
        return asstChoiceHaveTopicVoList;
    }

    public void setAsstChoiceHaveTopicVoList(ArrayList<AsstChoiceHaveTopicVo> asstChoiceHaveTopicVoList) {
        this.asstChoiceHaveTopicVoList = asstChoiceHaveTopicVoList;
    }

    public ArrayList<AsstChoiceVo> getAsstSubtopicChoiceVoList() {
        return asstSubtopicChoiceVoList;
    }

    public void setAsstSubtopicChoiceVoList(ArrayList<AsstChoiceVo> asstSubtopicChoiceVoList) {
        this.asstSubtopicChoiceVoList = asstSubtopicChoiceVoList;
    }

    public String getAnswerSubtopicChoice() {
        return answerSubtopicChoice;
    }

    public void setAnswerSubtopicChoice(String answerSubtopicChoice) {
        this.answerSubtopicChoice = answerSubtopicChoice;
    }

    public String getChoiceReasonSubtopic() {
        return choiceReasonSubtopic;
    }

    public void setChoiceReasonSubtopic(String choiceReasonSubtopic) {
        this.choiceReasonSubtopic = choiceReasonSubtopic;
    }

    public String getOldAnswerQuali() {
        return oldAnswerQuali;
    }

    public void setOldAnswerQuali(String oldAnswerQuali) {
        this.oldAnswerQuali = oldAnswerQuali;
    }

    public String getOldAnswerSubtopicChoice() {
        return oldAnswerSubtopicChoice;
    }

    public void setOldAnswerSubtopicChoice(String oldAnswerSubtopicChoice) {
        this.oldAnswerSubtopicChoice = oldAnswerSubtopicChoice;
    }

    public String getConfirmAnswer() {
        return confirmAnswer;
    }

    public void setConfirmAnswer(String confirmAnswer) {
        this.confirmAnswer = confirmAnswer;
    }

    public String getConfirmChoiceReason() {
        return confirmChoiceReason;
    }

    public void setConfirmChoiceReason(String confirmChoiceReason) {
        this.confirmChoiceReason = confirmChoiceReason;
    }

    public String getConfirmAnswerNotBcm() {
        return confirmAnswerNotBcm;
    }

    public void setConfirmAnswerNotBcm(String confirmAnswerNotBcm) {
        this.confirmAnswerNotBcm = confirmAnswerNotBcm;
    }

    public String getConfirmChoiceReasonNotBcm() {
        return confirmChoiceReasonNotBcm;
    }

    public void setConfirmChoiceReasonNotBcm(String confirmChoiceReasonNotBcm) {
        this.confirmChoiceReasonNotBcm = confirmChoiceReasonNotBcm;
    }
  
}
