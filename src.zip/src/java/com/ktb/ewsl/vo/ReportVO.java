/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

import java.util.ArrayList;

/**
 *
 * @author pumin
 */
public class ReportVO {
    private String tableName ;
    private ArrayList listData;
    private WarningLevelHistoryVo warningLevelHistoryVo;
    private AccountDetailVo accountDetailVo;
    private int index;
    private String ewsCrateDate;
    private String pd1CreateDate;
    private String pd2CreateDate;
    private String ewsRiskLevel;
    private String pd1RiskLevel;
    private String pd2RiskLevel;
    private AccountDetailVo acctDetailVo;
    private int breakStatus ;
    private int hasAcctDetail;
    private String breakKey;

    public int getHasAcctDetail() {
        return hasAcctDetail;
    }

    public void setHasAcctDetail(int hasAcctDetail) {
        this.hasAcctDetail = hasAcctDetail;
    }

    
    public int getBreakStatus() {
        return breakStatus;
    }

    public void setBreakStatus(int breakStatus) {
        this.breakStatus = breakStatus;
    }

    public String getBreakKey() {
        return breakKey;
    }

    public void setBreakKey(String breakKey) {
        this.breakKey = breakKey;
    }
  
    public AccountDetailVo getAcctDetailVo() {
        return acctDetailVo;
    }

    public void setAcctDetailVo(AccountDetailVo acctDetailVo) {
        this.acctDetailVo = acctDetailVo;
    }
    
    public AccountDetailVo getAccountDetailVo() {
        return accountDetailVo;
    }

    public void setAccountDetailVo(AccountDetailVo accountDetailVo) {
        this.accountDetailVo = accountDetailVo;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    
    public String getEwsCrateDate() {
        return ewsCrateDate;
    }

    public void setEwsCrateDate(String ewsCrateDate) {
        this.ewsCrateDate = ewsCrateDate;
    }

    public String getPd1CreateDate() {
        return pd1CreateDate;
    }

    public void setPd1CreateDate(String pd1CreateDate) {
        this.pd1CreateDate = pd1CreateDate;
    }

    public String getPd2CreateDate() {
        return pd2CreateDate;
    }

    public void setPd2CreateDate(String pd2CreateDate) {
        this.pd2CreateDate = pd2CreateDate;
    }

    public String getEwsRiskLevel() {
        return ewsRiskLevel;
    }

    public void setEwsRiskLevel(String ewsRiskLevel) {
        this.ewsRiskLevel = ewsRiskLevel;
    }

    public String getPd1RiskLevel() {
        return pd1RiskLevel;
    }

    public void setPd1RiskLevel(String pd1RiskLevel) {
        this.pd1RiskLevel = pd1RiskLevel;
    }

    public String getPd2RiskLevel() {
        return pd2RiskLevel;
    }

    public void setPd2RiskLevel(String pd2RiskLevel) {
        this.pd2RiskLevel = pd2RiskLevel;
    }
    
    
    public WarningLevelHistoryVo getWarningLevelHistoryVo() {
        return warningLevelHistoryVo;
    }

    public void setWarningLevelHistoryVo(WarningLevelHistoryVo warningLevelHistoryVo) {
        this.warningLevelHistoryVo = warningLevelHistoryVo;
    }

    
    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public ArrayList getListData() {
        return listData;
    }

    public void setListData(ArrayList listData) {
        this.listData = listData;
    }
    
}
