/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.vo;

/**
 *
 * @author Pratya
 */
public class WarningWayOutFormVo extends MtActionFormVo{
    
//    private String wayOutFlg;
//    private String wayOutRemark;
//    private String confWayOutFlg;
//    private String confWayOutRemark;
//    private String confWayOutFlgNotBcm;
//    private String confWayOutRemarkNotBcm;
//    private String actionWarningId;
    
    private String warningId;
    private String actionStatus;
    private String roleCode;
    private String confFlg;
    private String confRemark;
    private String confFlgNotBcm;
    private String confRemarkNotBcm;
    private String actionStatusNotBcm;
    
    public WarningWayOutFormVo(){
//        this.wayOutFlg                  = "";
//        this.wayOutRemark               = "";
//        this.confWayOutFlg              = "";
//        this.confWayOutRemark           = "";
//        this.confWayOutFlgNotBcm        = "";
//        this.confWayOutRemarkNotBcm     = "";
        
        this.warningId            = "";
        this.actionStatus         = "";
//        this.actionWarningId      = "";
        this.roleCode             = "";
        this.confFlg              = "";
        this.confRemark           = "";
        this.confFlgNotBcm        = "";
        this.confRemarkNotBcm     = "";
        this.actionStatusNotBcm   = "";
    }

    public String getWarningId() {
        return warningId;
    }

    public void setWarningId(String warningId) {
        this.warningId = warningId;
    }

    public String getActionStatus() {
        return actionStatus;
    }

    public void setActionStatus(String actionStatus) {
        this.actionStatus = actionStatus;
    }

//    public String getActionWarningId() {
//        return actionWarningId;
//    }
//
//    public void setActionWarningId(String actionWarningId) {
//        this.actionWarningId = actionWarningId;
//    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getConfFlg() {
        return confFlg;
    }

    public void setConfFlg(String confFlg) {
        this.confFlg = confFlg;
    }

    public String getConfRemark() {
        return confRemark;
    }

    public void setConfRemark(String confRemark) {
        this.confRemark = confRemark;
    }

    public String getConfFlgNotBcm() {
        return confFlgNotBcm;
    }

    public void setConfFlgNotBcm(String confFlgNotBcm) {
        this.confFlgNotBcm = confFlgNotBcm;
    }

    public String getConfRemarkNotBcm() {
        return confRemarkNotBcm;
    }

    public void setConfRemarkNotBcm(String confRemarkNotBcm) {
        this.confRemarkNotBcm = confRemarkNotBcm;
    }

    public String getActionStatusNotBcm() {
        return actionStatusNotBcm;
    }

    public void setActionStatusNotBcm(String actionStatusNotBcm) {
        this.actionStatusNotBcm = actionStatusNotBcm;
    }
}
