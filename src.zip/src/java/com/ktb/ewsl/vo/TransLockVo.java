/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ktb.ewsl.vo;

import java.io.Serializable;

/**
 *
 * @author aon
 */
public class TransLockVo implements Serializable{
    private String transTypeId;
    private String refId;
    private String sessionId;
    private String lockedBy;
    private String lockedIp;
    private java.util.Date lockedDate;
    
    private boolean owner;

    /**
     * @return the transTypeId
     */
    public String getTransTypeId() {
        return transTypeId;
    }

    /**
     * @param transTypeId the transTypeId to set
     */
    public void setTransTypeId(String transTypeId) {
        this.transTypeId = transTypeId;
    }

    /**
     * @return the refId
     */
    public String getRefId() {
        return refId;
    }

    /**
     * @param refId the refId to set
     */
    public void setRefId(String refId) {
        this.refId = refId;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId the sessionId to set
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the lockedBy
     */
    public String getLockedBy() {
        return lockedBy;
    }

    /**
     * @param lockedBy the lockedBy to set
     */
    public void setLockedBy(String lockedBy) {
        this.lockedBy = lockedBy;
    }

    /**
     * @return the lockedIp
     */
    public String getLockedIp() {
        return lockedIp;
    }

    /**
     * @param lockedIp the lockedIp to set
     */
    public void setLockedIp(String lockedIp) {
        this.lockedIp = lockedIp;
    }

    /**
     * @return the lockedDate
     */
    public java.util.Date getLockedDate() {
        return lockedDate;
    }

    /**
     * @param lockedDate the lockedDate to set
     */
    public void setLockedDate(java.util.Date lockedDate) {
        this.lockedDate = lockedDate;
    }

    /**
     * @return the owner
     */
    public boolean isOwner() {
        return owner;
    }

    /**
     * @param owner the owner to set
     */
    public void setOwner(boolean owner) {
        this.owner = owner;
    }
    
}
