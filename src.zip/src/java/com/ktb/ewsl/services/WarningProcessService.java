/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningProcessVo;

/**
 *
 * @author Siriwat Asamo
 */
public interface WarningProcessService {
    public void updateScoreProjectFIN(WarningProcessVo warningProcessVo) throws Exception;
    public WarningProcessVo findWarningProcessByHeaderId(int warningHeaderId) throws Exception;
    //R1.3
    public WarningProcessVo findWarningProcessByHeaderIdAndInfoId(int warningHeaderId , Integer warningInfoId) throws Exception;
    public WarningProcessVo findMaxWarningInfoWithinHeaderId(int warningHeaderId) throws Exception;
    public void insertWarningProcess(WarningProcessVo warningProcessVo) throws Exception;
    public WarningProcessVo findWarningProcessByInfoId(Integer warningInfoId) throws Exception;
}
