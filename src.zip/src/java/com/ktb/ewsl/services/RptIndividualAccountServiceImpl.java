/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.RptIndividualAccountVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class RptIndividualAccountServiceImpl implements RptIndividualAccountService{
    
    private static final Logger log = Logger.getLogger(AbstractJdbcService.class);
     
    @Autowired
    public JdbcTemplate jdbcTemplate;
           
    @Override
    public List<RptIndividualAccountVo> getRptIndividualAccountList(RptIndividualAccountVo vo) throws Exception {
       List<RptIndividualAccountVo> list  = null;
       
      try{
        if(log.isInfoEnabled()){
              log.info("[getRptIndividualAccountList][Begin]");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT AD1.ACCOUNT_NO");
        sql.append("      ,AD1.BILL_NO");
        sql.append("      ,AD1.LIMIT_AMT AS LIMITAMT");
        sql.append("      ,AD1.LIMIT_AMT AS MAINLIMITAMT");
        sql.append("      ,AD1.OUTSTANDING_AMT AS OUTSTANDINGAMT");
        sql.append("      ,AD1.OUTSTANDING_AMT AS MAINOUTSTANDINGAMT");
        sql.append("      ,AD1.MATURITY_DATE");
        sql.append("      ,AD1.DUE_DATE");
        sql.append("      ,AD1.DPD");
        sql.append("      ,AD1.DUE_AMT");
        sql.append("      ,AD1.UNPAID_AMT");
        sql.append("      ,AD1.UNPAID_INTEREST");
        sql.append("      ,AD1.UNPAID_PRINCIPAL");
        sql.append("      ,AD1.LATE_CHARGE");
        sql.append("      ,AD1.ACCOUNT_SUB_TYPE AS ACCTSUBTYPE");
        sql.append("      ,AD1.PRODUCT_GROUP AS PRODGRP");
        sql.append("      ,AD1.PRODUCT_TYPE AS PRODTYPE");
        sql.append("      ,AD1.LOAN_TYPE AS MARKETCD");
        sql.append("      ,AD1.C_FINAL");
        sql.append("      ,AD1.DPD_ZERO_DATE");
        sql.append("      ,AD1.INPUT_ACCOUNT_NO");
        sql.append("      ,AD1.INPUT_BILL_NO");
        sql.append("      ,AD1.IS_CLOSED");
        sql.append("      ,AD1.OD_OVER_LIMIT");
        sql.append("      ,AD1.PAID_DATE");
        sql.append("      ,AD1.SOURCE_SYSTEM");
        
        sql.append("    FROM TBL_RPT_INDIVIDUAL_ACCOUNT  AD1");
//        sql.append("    WHERE NVL(DPD,0) >= 0");
        sql.append("    WHERE NVL(DPD,0) > 0");
        sql.append("        AND DPD_ZERO_DATE IS NULL AND PAID_DATE IS NULL");
        sql.append("        AND AD1.CIF = ?");
        sql.append("    ORDER BY AD1.DUE_DATE DESC");
        
        if(log.isInfoEnabled()){
              log.info("sql :: " + sql);
        }
         
        list = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{vo.getCif()}, new RowMapper() {
              
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    RptIndividualAccountVo item = new RptIndividualAccountVo();
                    
                    try{
                        item.setAccountNo(StringUtil.getValue(rs.getString("ACCOUNT_NO")));
                        item.setBillNo(StringUtil.getValue(rs.getString("BILL_NO")));
                        item.setLimitAmt(MoneyUtil.formatMoney(rs.getString("LIMITAMT")));
                        item.setMainLimitAmt(MoneyUtil.formatMoney(rs.getString("MAINLIMITAMT")));
                        item.setOutstandingAmt(MoneyUtil.formatMoney(rs.getString("OUTSTANDINGAMT")));
                        item.setMainOutstandingAmt(MoneyUtil.formatMoney(rs.getString("MAINOUTSTANDINGAMT")));
                        item.setMaturityDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
                        item.setDueDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("DUE_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("DUE_DATE")));
                        item.setDpd(StringUtil.getValue(rs.getString("DPD")));
                        item.setDueAmt(MoneyUtil.formatMoney(rs.getString("DUE_AMT")));
                        item.setUnpaidAmt(MoneyUtil.formatMoney(rs.getString("UNPAID_AMT")));
                        item.setUnpaidInterest(MoneyUtil.formatMoney(rs.getString("UNPAID_INTEREST")));
                        item.setUnpaidPrincipal(MoneyUtil.formatMoney(rs.getString("UNPAID_PRINCIPAL")));
                        item.setLateCharge(StringUtil.getValue(rs.getString("LATE_CHARGE")));
                        item.setAccountSubType(StringUtil.getValue(rs.getString("ACCTSUBTYPE")));
                        item.setProductGroup(StringUtil.getValue(rs.getString("PRODGRP")));
                        item.setProductType(StringUtil.getValue(rs.getString("PRODTYPE")));
                        item.setLoanType(StringUtil.getValue(rs.getString("MARKETCD")));
                        item.setcFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                        item.setDpdZeroDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("DPD_ZERO_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("DPD_ZERO_DATE")));
                        item.setInputAccountNo(StringUtil.getValue(rs.getString("INPUT_ACCOUNT_NO")));
                        item.setInputBillNo(StringUtil.getValue(rs.getString("INPUT_BILL_NO")));
                        item.setIsClosed(StringUtil.getValue(rs.getString("IS_CLOSED")));
                        item.setOdOverLimit(MoneyUtil.formatMoney(rs.getString("OD_OVER_LIMIT")));
                        item.setPaidDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("PAID_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("PAID_DATE")));
                        item.setSourceSystem(StringUtil.getValue(rs.getString("SOURCE_SYSTEM")));
                        

                    }catch(Exception e){
                        log.error(e);
                    }
                    return item;
                }
            });
        
        if(log.isInfoEnabled()){
              log.info("[getRptIndividualAccountList][End]");
        }
        
      }catch(Exception e){
          log.error("Error occur in while process RptIndividualAccountServiceImpl.getRptIndividualAccountList : " + e.getMessage() , e);
          throw e;
      }
      return list;
    }

   
}
