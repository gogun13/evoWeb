/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningFactorVo;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Siriwat Asamo
 */
@Repository
public class WarningFactorServiceImpl implements WarningFactorService {
    
    private static final Logger logger = Logger.getLogger(WarningFactorServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void saveWarningFactor(WarningFactorVo warningFactorVo) throws Exception {
        if(logger.isInfoEnabled()){
            logger.info("saveWarningFactor");
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_WARNING_FACTOR (WARNING_ID,FACTOR_CD,FACTOR_DESC,FACTOR_VALUE,WEIGHTED_SCROE,ATTRIBUTE_ID)");
        sql.append("\nVALUEs(?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{warningFactorVo.getWarningId(), warningFactorVo.getFactorCd(), warningFactorVo.getFactorDesc(),
                warningFactorVo.getFactorValue(), warningFactorVo.getWeightedScore(), warningFactorVo.getAttributeId()}
        );
    }    

    @Override
    public void deleteWarningFactor(WarningFactorVo warningFactorVo) throws Exception {
        if(logger.isInfoEnabled()){
            logger.info("deleteWarningFactor");
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_FACTOR WHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningFactorVo.getWarningId()});
    }
    
}
