/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ParameterVo;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public interface ParameterService {
    
    public ParameterVo findByParamIdAndParamType(String paramId, String paramTypeId) throws Exception;
    public List<ParameterVo> findByParamTypeId(String paramTypeId) throws Exception;
    public ArrayList<ParameterVo> findByParamType(String paramTypeId  , String orderby ) throws Exception;
    
}
