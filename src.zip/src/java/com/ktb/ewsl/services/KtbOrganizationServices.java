/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.KtbOrganization;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public interface KtbOrganizationServices {
    
    public String findCostCenterName(String responUnit)throws Exception;
    public ArrayList<DropdownVo> getWorkLine()throws Exception;
    public ArrayList<DropdownVo> getOrganizationGroup(String businessUnit)throws Exception;
    public ArrayList<DropdownVo> getDepartment(String businessUnit , String groupCode)throws Exception;
    public KtbOrganization getOrganizationByCostcenter(String costcenter)throws Exception;
    public ArrayList<DropdownVo> getResponseUnit(String businessUnit , String groupCode , String fieldOrder)throws Exception;
    public ArrayList<DropdownVo> getOrganizationResponseUnit(String costcenter , String fieldOrder)throws Exception;
    public ArrayList getOrganizationGroupAndEwsUse(String businessUnit)throws Exception;
    public String getCostCenterDescByCode(String costCenterCode) throws Exception;
    
    
}
