/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningCloseVo;
import com.ktbcs.core.utilities.DateUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author pumin
 */
@Repository
public class WarningCloseServiceImpl implements WarningCloseService {

    private static final Logger log = Logger.getLogger(WarningCloseServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public ArrayList<WarningCloseVo> getWarningClose(String warningHeadId) throws Exception {
        ArrayList<WarningCloseVo> result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("WarningCloseServiceImpl.getWarningClose");
            }
            StringBuilder sql = new StringBuilder("SELECT WARNING_HEAD_ID ,REASON_FLG, REMARK,STATUS,CREATED_DT,CREATED_BY FROM TBL_WARNING_CLOSE WHERE WARNING_HEAD_ID=? ORDER BY CREATED_DT ");
            result = (ArrayList<WarningCloseVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningCloseVo vo = new WarningCloseVo();
                    vo.setWarningHeadId(rs.getString("WARNING_HEAD_ID"));
                    vo.setRemark(rs.getString("REMARK"));
                    vo.setReasonFlg(rs.getString("REASON_FLG"));
                    vo.setStatus(rs.getString("STATUS"));
                    vo.setCreatedBy(rs.getString("CREATED_BY"));
                    vo.setCreatedDt(rs.getDate("CREATED_DT"));
                    vo.setCreatedDtThai( DateUtil.getDateInThaiFormat(rs.getDate("CREATED_DT")));
                    return vo;
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process WarningCloseServiceImpl.getWarningClose: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public void insertWarningClose(WarningCloseVo vo) throws Exception {

        try {
            log.info("WARNING_HEAD_ID = " + vo.getWarningHeadId());
            log.info("REASON_FLG = " + vo.getReasonFlg());
            log.info("REMARK = " + vo.getRemark());
            log.info("STATUS = " + vo.getStatus());
            log.info("CREATED_BY = " + vo.getCreatedBy());
            log.info("ROLE_CODE = " + vo.getRoleCode());
            
            StringBuilder sql = new StringBuilder("INSERT INTO TBL_WARNING_CLOSE ( WARNING_HEAD_ID,REASON_FLG,REMARK,STATUS,CREATED_DT,CREATED_BY, ROLE_CODE ) VALUES(?,?,?,?,?,?,?) ");
            jdbcTemplate.update(sql.toString(), new Object[]{vo.getWarningHeadId(), vo.getReasonFlg(), vo.getRemark(), vo.getStatus(), vo.getCreatedDt(), vo.getCreatedBy(), vo.getRoleCode()});

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process WarningCloseServiceImpl.insertWarningClose : " + e.getMessage(), e);
        }


    }
    
    @Override
    public String getReasonFlg(String warningHeadId) throws Exception {
        ArrayList<WarningCloseVo>   result      = null;
        StringBuilder               sql         = new StringBuilder();
        String                      reasonFlg   = null;
        
        try {
            if (log.isInfoEnabled()) {
                log.info("WarningCloseServiceImpl.getReasonFlg");
            }
            sql.append("select t.reason_flg");
            sql.append("    from TBL_WARNING_CLOSE t");
            sql.append("    where t.status = 'R'");
            sql.append("        and t.warning_head_id = ?");
            sql.append("        and t.created_dt = (select max(created_dt)");
            sql.append("                                from TBL_WARNING_CLOSE a");
            sql.append("                                where a.status = 'R'");
            sql.append("                                    and a.warning_head_id = t.warning_head_id)");
            
            
            
            result = (ArrayList<WarningCloseVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningCloseVo vo = new WarningCloseVo();
                    vo.setReasonFlg(rs.getString("REASON_FLG"));
                    return vo;
                }
            });
            
            if(result!=null && result.size() > 0){
                reasonFlg = result.get(0).getReasonFlg();
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process WarningCloseServiceImpl.getWarningClose: " + e.getMessage(), e);
        }
        return reasonFlg;
    }
    
    @Override
    public String getStatusByMaxCreatedDt(String warningHeadId) throws Exception {
        ArrayList<WarningCloseVo>   result      = null;
        StringBuilder               sql         = new StringBuilder();
        String                      status      = null;
        
        try {
            if (log.isInfoEnabled()) {
                log.info("WarningCloseServiceImpl.getStatusByMaxCreatedDt");
            }
            sql.append("select t.status");
            sql.append("    from TBL_WARNING_CLOSE t");
            sql.append("    where t.warning_head_id = ?");
            sql.append("        and t.created_dt = (select max(a.created_dt)");
            sql.append("                                from TBL_WARNING_CLOSE a");
            sql.append("                                where a.warning_head_id = t.warning_head_id)");
            sql.append("    order by t.created_dt desc");
            
            result = (ArrayList<WarningCloseVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningCloseVo vo = new WarningCloseVo();
                    vo.setStatus(rs.getString("status"));
                    return vo;
                }
            });
            
            if(result!=null && result.size() > 0){
                status = result.get(0).getStatus();
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process WarningCloseServiceImpl.getStatusByMaxCreatedDt: " + e.getMessage(), e);
        }
        return status;
    }
    
}
