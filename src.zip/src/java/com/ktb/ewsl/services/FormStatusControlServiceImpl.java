/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.FormStatusControlVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Pratya
 */
@Repository
public class FormStatusControlServiceImpl implements FormStatusControlService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(FormStatusControlServiceImpl.class);

    @Override
    public String getNextStatus (FormStatusControlVo vo) throws Exception {

        ArrayList<FormStatusControlVo>  result      = null;
        String                          sqlStr      = null;
        String                          nextStatus  = null;
        FormStatusControlVo             voDb        = null;
        
        
        try {
            
            sqlStr = "select * "
                    + "     from TBL_FORM_STATUS_CONTROL"
                    + "     where CURR_STATUS = ?"
                    + "         and ACTION_CODE = ?"
                    + "         and WARNING_TYPE = ?";
            
            if (log.isInfoEnabled()) {
                log.info("[getNextStatus] sqlStr :: " + sqlStr);
            }

            StringBuilder sql = new StringBuilder(sqlStr);
            result = (ArrayList<FormStatusControlVo>) jdbcTemplate.query(sql.toString(), new Object[]{vo.getCurrStatus(),vo.getActionCode(),vo.getWarningType()}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    FormStatusControlVo vo = new FormStatusControlVo();
                    
                    vo.setWarningType   (rs.getString("WARNING_TYPE"));
                    vo.setCurrStatus    (rs.getString("CURR_STATUS"));
                    vo.setActionCode    (rs.getString("ACTION_CODE"));
                    vo.setNewStatus     (rs.getString("NEW_STATUS"));
                    
                    return vo;
                }
            });
            
            if(result!=null && !result.isEmpty()){
                voDb        = result.get(0);
                nextStatus  = voDb.getNewStatus();
            }

        } catch (Exception e) {
            log.error("Error occur in while process FormStatusControlServiceImpl.getNextStatus: " + e.getMessage(), e);
            throw e;
        }
        return nextStatus;
    }
}
