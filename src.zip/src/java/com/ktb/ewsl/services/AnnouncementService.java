/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AnnouncementVo;
import com.ktbcs.core.utilities.PaginatedListImpl;

/**
 *
 * @author KapookZa
 */
public interface AnnouncementService {

    public Integer saveAnnouncement(AnnouncementVo announcementVo) throws Exception;

    public Integer getSeq() throws Exception;

    public void deleteAnnouncement(int seq,String updatedBy) throws Exception;

    public PaginatedListImpl<AnnouncementVo> getListAnnouncement(AnnouncementVo announcementVo, PaginatedListImpl<AnnouncementVo> paginate, int pageAmt) throws Exception;

    public AnnouncementVo getAnnouncementVo(AnnouncementVo announcementVo) throws Exception;

    public void updateAnnouncement(AnnouncementVo announcementVo) throws Exception;

	PaginatedListImpl<AnnouncementVo> getListPostAnnouncement(PaginatedListImpl<AnnouncementVo> paginate)
			throws Exception;
}
