/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ConfigVO;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface ConfigService {
    
    public ConfigVO findByConfigGroupAndConfigCode(String configGroupCode , String configCode )throws Exception;
    public List<ConfigVO> findByConfigGroup(String configGroupCode) throws Exception;
}
