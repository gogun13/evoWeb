/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.UserVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import java.util.List;

/**
 *
 * @author KTB_User
 */
public interface RoleAssignmentService {
    public String getRoleCodeDesc(String isConfig, String roleCode) throws Exception;
    public List<DropdownVo> getRoleList(String isConfig) throws Exception;
    public List<UserVo> getUserMtRolePrivilege(SearchBean searchBean) throws Exception;
    public List<UserVo> getUserMtRolePrivilegeList(String where) throws Exception;
    public PaginatedListImpl<UserVo> getUserTBList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public PaginatedListImpl<UserVo> getDepartmentList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public List<UserVo> getUserTBList(String where) throws Exception;
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeHistoryList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
    public int validateSave(UserVo userVo) throws Exception;
    public int validateUpdate(String empNo, String roleCode, String deptCode) throws Exception;
    public int saveUserMtRolePrivilege(UserVo userVo) throws Exception;
    public int saveUserMtRolePrivilegeHistory(UserVo userVo, String flag, java.util.Date paramDate) throws Exception;
    public int updateUserMtRolePrivilege(UserVo userVo, String roleCode, String deptCode)throws Exception;
    public int updateUserMtRolePrivilegeBySearch(UserVo userVo) throws Exception;
    public int updateIsActive(UserVo userVo) throws Exception;
    public int updateDeptCodeByEmployeeId(UserVo userVo) throws Exception;
    public int deleteUserMtRolePrivilege(UserVo userVo) throws Exception;
    public UserVo getUserMtRolePrivilegeByFilter(SearchBean searchBean) throws Exception;
    public UserVo getUserMtRolePrivilegeSaveHistory(SearchBean searchBean) throws Exception;
    
}
