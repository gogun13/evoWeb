/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

/**
 *
 * @author Tum_Surapong
 */
public interface CRCustReviewEwsServices {
     
    public String getLoanGrpProd(String prodGroup, String acctSubType, String marketCode) throws Exception;
    public String getLoanGrpProd(String prodGroup, String acctSubType) throws Exception;
    public String getLoanGrpProd(String marketCode) throws Exception;
}
