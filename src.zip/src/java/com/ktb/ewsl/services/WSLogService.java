/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WSLogVO;

/**
 *
 * @author KTBDevLoan
 */
public interface WSLogService {
    
    public void insertLog(WSLogVO wsLogVO)throws Exception;
}
