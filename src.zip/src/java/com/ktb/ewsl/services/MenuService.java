/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public interface MenuService {
    
    ArrayList<MenuInfoVo> getMainMenu(String userClass);

    ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass);

    ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass, String menuGroup);

    MenuInfoVo getFirstChild(String menuId, String userClass);

    MenuInfoVo getFirstChild(String menuId, String userClass, String menuGroup);
    
    String getFirstMenu(String mainMenuId);
    
    
}
