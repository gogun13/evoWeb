/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktbcs.core.vo.SearchBean;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningInfoService {
    public List<WarningInfoVo> getTaskDetailList(SearchBean searchBean) throws Exception;
    public void updateStatusByWarningIdAndType(WarningInfoVo warningInfoVo) throws Exception;
    public void updateStatusByWarningIdAndTypeRoleCodeAns(WarningInfoVo warningInfoVo) throws Exception;
    public void updateStatusByHeaderIdAndType(WarningInfoVo warningInfoVo) throws Exception;
    public Integer findMaxWarningId(WarningInfoVo warningInfoVo) throws Exception;
    public void saveWarningInfo(WarningInfoVo warningInfoVo) throws Exception; //EWS-L
    public void deleteSubTrigger(int warningHeaderId) throws Exception;
    public void updateShowAndGen(WarningInfoVo warningInfoVo) throws Exception;
    public Integer findAllApproveTrigger(int warningHeaderId) throws Exception;
    public void updateStausAndApprove(WarningInfoVo warningInfoVo) throws Exception;
    public Integer findWarningInfoNotApproveByWarningHeaderId(int warningHeaderId) throws Exception;
    public WarningInfoVo findTriggerWarningDate(int warningHeaderId, String warningType) throws Exception;
    public WarningInfoVo findLastVersion(int warningHeaderId) throws Exception;
    public List<WarningInfoVo> findWarningInfo(int warningHeaderId, String warningType) throws Exception;
    public void updateQualiSendFlag(WarningInfoVo warningInfoVo) throws Exception;
    public WarningInfoVo findWarningInfoObj(int warningHeaderId,int warningInfoId, String warningType) throws Exception;
    public List<WarningInfoVo> findEwsqCompletByCif(int cif) throws Exception;
    public List<WarningInfoVo> findWarningInfoSendEwsqComplet(int warningHeaderId, String warningType, String flag) throws Exception;
    public void deleteInfoByWarningType(int warningHeaderId, String warningType) throws Exception;
    public WarningInfoVo findWarningInfoObject(int warningHeaderId, String warningType) throws Exception ;
    public WarningInfoVo findEWSQNotSendScoreByHeaderId(int warningHeaderId) throws Exception ;
    public void updateStatusEWSQByWarningIdAndType(WarningInfoVo warningInfoVo) throws Exception;
    public void updateTriggerResult(WarningInfoVo warningInfoVo) throws Exception;
    public List<WarningInfoVo> findWarningInfoByHeaderId(int warningHeaderId) throws Exception; //---EWS-L
    public Integer findAllTriggerForCurrentHeaderTrigFlag(int warningHeaderId) throws Exception ;
    public List<WarningInfoVo> findWarningInfoByHeaderAndWarningTypeList(int warningHeaderId, List<String> warningTypeList) throws Exception;
    public void cancelTriggerAndPayment(WarningInfoVo warningInfoVo) throws Exception;
    public List<WarningInfoVo> findWarningInfoActiveByHeaderAndWarningTypeList(Integer warningHeaderId, List<String> warningTypeList , int qualiWarningInfoIdIrigGen) throws Exception;
    public void updateStatusByWarningHeadIdAndType(WarningInfoVo warningInfoVo) throws Exception;
    public void updateClosejob(WarningInfoVo warningInfoVo) throws Exception;
    public void updateStatusClosejob(WarningInfoVo warningInfoVo) throws Exception;
    public WarningInfoVo findWarningInfoObjByHeaderIdAndType(int warningHeaderId, String warningType) throws Exception;
    public void updateStatusAndCloseFlag(WarningInfoVo warningInfoVo) throws Exception;
    public List<WarningInfoVo> findFinOrQcaOrQualiComplete(int warningHeaderId) throws Exception;
    public List<WarningInfoVo> findFormConbineWithinHeader(int warningHeaderId) throws Exception;
    public WarningInfoVo findWarningInfoObjByWarningInfoId(int warningInfoId, String warningType) throws Exception ;
    public Integer findAllTriggerTempForCurrentHeaderTrigTempFlag(int warningHeaderId) throws Exception ;
    public void updateStatusByWarningInfoIdAndType(WarningInfoVo warningInfoVo) throws Exception;
    public void resetEwsqInfo(WarningInfoVo warningInfoVo) throws Exception;
    public WarningInfoVo findLastVersionByWarningTypeAndId(String warningType , int warningInfoId ) throws Exception ;
    public void updateStatusAndQuestionByWarningIdAndType(WarningInfoVo warningInfoVo) throws Exception;
    public WarningInfoVo findWarningInfoObject(int warningInfoId) throws Exception ;
    public WarningInfoVo findEWSQLastVersion(int warningHeaderId) throws Exception;
    
    public void updateStatus(WarningInfoVo warningInfoVo) throws Exception;//Add By Pound
    public WarningInfoVo getWarningIdAndStatus(WarningInfoVo warningInfoVo) throws Exception;//Add By Pound
    public void updateStatusForWayOut(WarningInfoVo warningInfoVo) throws Exception;//Add By Pound
    //public List<WarningInfoVo> findWarningInfoAllTrigByHeaderId(int warningHeaderId) throws Exception; //--EWS-L
    public void updateStatusLatePayment(WarningInfoVo warningInfoVo) throws Exception;
    public void deleteTrigger(int warningHeaderId) throws Exception ;
    public void deleteTriggerNotApprove(int warningHeaderId,String warningIdAll,int qualiWarningId ) throws Exception ;
    public void updateStatusByWarningIdAndTypeLatePayment(WarningInfoVo warningInfoVo) throws Exception;
    public void deleteLatePaymentForm(WarningInfoVo warningInfoVo) throws Exception;
    public void deleteAction1Form(WarningInfoVo warningInfoVo) throws Exception;
    public int getMinWarningId(WarningInfoVo warningInfoVo) throws Exception;
    public void updateConfirmLatepayment(String confirmLatePayment, String bcmConfirmLatePayment, String warningId) throws Exception;
    public Integer findMaxWarningId(int warningHeaderId, String warningType) throws Exception;
    public Integer cntLatePay(int warningHeaderId, String warningType) throws Exception;
    public void deleteWarningInfoId(int warningHeaderId,String warningIdStr) throws Exception;
     // R1.3
    public Integer findLatestWarningInfoByCif(String cifNo , String warningType) throws Exception ;
    public List<WarningInfoVo> findWarningInfoObjByHeaderIdArray(int warningHeaderId) throws Exception;
    public Integer checkStatusInfoByHeaderForClosePipeline(int warningHeaderId) throws Exception ;
    public WarningInfoVo findLastVersionByWarningInfoID(int warningInfoId , String warningType) throws Exception;
    public WarningInfoVo findWarningInfoObjectByMaxWarningInfo(int warningHeaderId, String warningType) throws Exception ;
    public List<WarningInfoVo> findWarningInfoAllTrigByHeaderIdAndRoleCode(int warningHeaderId , String roleCode ,int qualiWarningId ) throws Exception;
    public List<Integer> findTriggerNotApprove(int warningHeaderId,String warningIdAll,int qualiWarningId ) throws Exception ;
    public List<WarningInfoVo> findWarningInfoAllTrigByHeaderIdAndQualiId(int warningHeaderId ,int qualiWarningId ) throws Exception; 
}
