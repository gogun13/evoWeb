/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RolePrivilegeVo;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface RolePrivilegeService {
    
     List<RolePrivilegeVo> getEmployeeID(String roleCode) throws Exception;
     
     public RolePrivilegeVo getEmployeeIDByRoleCodeAndEmpNo(String roleCode , String employeeId ) throws Exception;
     
     public void  updateInActiveUserRolePrivilege(String roldCode , String employeeId)throws Exception;
}
