/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.IndividualODAccountVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class IndividualODAccountServiceImpl implements IndividualODAccountService{
    
   private static final Logger log = Logger.getLogger(IndividualODAccountServiceImpl.class);
      
   @Autowired
   private JdbcTemplate jdbcTemplate;

    @Override
    public List<IndividualODAccountVo> getWarningBeforeODOverLimit(String cif) throws Exception {
        StringBuilder sql = new StringBuilder();
        List<IndividualODAccountVo> resultList = null;
        try{
             if (log.isInfoEnabled()) {
                log.info("IndividualODAccountServiceImpl.getWarningBeforeODOverLimit");
            }
            sql.append(" SELECT * ");
            sql.append("\n FROM ewsmadm.TBL_RPT_INDIVIDUAL_OD_ACCOUNT ");
            sql.append("\n WHERE CIF = ? ");
            sql.append("\n AND Delinq_Date IS NULL ");
            sql.append("\n AND BOOK_VALUE_BALANCE > LIMIT_AMT ");
        
             if(!ValidatorUtil.isNullOrEmpty(sql.toString())){
                resultList = (ArrayList<IndividualODAccountVo>) jdbcTemplate.query(sql.toString(),new Object[]{cif}, new RowMapper() {
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return getResultSetODAccount(rs);
                }});
           }
        } catch (Exception e) {
            log.error("Error occur in while process IndividualODAccountServiceImpl.getWarningBeforeODOverLimit: " + e.getMessage(), e);
            throw e;
        }
       return resultList;
    }

    @Override
    public List<IndividualODAccountVo> getWarningODOverLimit(String cif) throws Exception {
        
        StringBuilder sql = new StringBuilder();
        List<IndividualODAccountVo> resultList = null;
        try{
            if (log.isInfoEnabled()) {
                log.info("IndividualODAccountServiceImpl.getWarningODOverLimit");
                log.info("IndividualODAccountServiceImpl.getWarningODOverLimit cif :: " + cif);
            }
            sql.append(" SELECT * ");
            sql.append("\n FROM ewsmadm.TBL_RPT_INDIVIDUAL_OD_ACCOUNT ");
            sql.append("\n WHERE CIF = ? ");
            sql.append("\n AND Delinq_Date IS NOT NULL ");
            sql.append("\n AND PAID_DATE IS NULL ");
            
            if (log.isInfoEnabled()) {
                log.info("IndividualODAccountServiceImpl.getWarningODOverLimit sql :: " + sql);
            }
        
             if(!ValidatorUtil.isNullOrEmpty(sql.toString())){
                resultList = (ArrayList<IndividualODAccountVo>) jdbcTemplate.query(sql.toString(),new Object[]{cif}, new RowMapper() {
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return getResultSetODAccount(rs);
                }});
           }
        } catch (Exception e) {
            log.error("Error occur in while process IndividualODAccountServiceImpl.getWarningODOverLimit: " + e.getMessage(), e);
            throw e;
        }
       return resultList;
    }
    
    private IndividualODAccountVo getResultSetODAccount(ResultSet rs){
       IndividualODAccountVo item = new IndividualODAccountVo();
       try{
            item.setAccountNo(rs.getString("ACCOUNT_NO"));
            item.setAvgMonthlyInt(rs.getBigDecimal("AVG_MONTHLY_INT"));
            item.setAvgMonthlyIntStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("AVG_MONTHLY_INT"), MoneyUtil.pattern_bigDecimal));
            item.setBookValueBalance(rs.getBigDecimal("BOOK_VALUE_BALANCE"));
            item.setBookValueBalanceStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("BOOK_VALUE_BALANCE"), MoneyUtil.pattern_bigDecimal));
            item.setCFinal(rs.getString("C_FINAL"));
            item.setCif(rs.getString("CIF"));
            item.setDelinqDate(rs.getDate("DELINQ_DATE"));
            item.setDelinqDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("DELINQ_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("DELINQ_DATE")));
            item.setLastBatchDate(rs.getDate("LAST_BATCH_DATE"));
            item.setLastBatchDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("LAST_BATCH_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("LAST_BATCH_DATE")));
            item.setLimitAmt(rs.getBigDecimal("LIMIT_AMT"));
            item.setLimitAmtStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("LIMIT_AMT"), MoneyUtil.pattern_bigDecimal));
            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
            item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
            item.setNegAccruedAuth(rs.getBigDecimal("NEG_ACCRUED_AUTH"));
            item.setNegAccruedAuthStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("NEG_ACCRUED_AUTH"), MoneyUtil.pattern_bigDecimal));
            item.setNegAccruedUnAuth(rs.getBigDecimal("NEG_ACCRUED_UNAUTH"));
            item.setNegAccruedUnAuthStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("NEG_ACCRUED_UNAUTH"), MoneyUtil.pattern_bigDecimal));
            item.setOdOverLimit(rs.getBigDecimal("OD_OVER_LIMIT"));
            item.setOdOverLimitStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("OD_OVER_LIMIT"), MoneyUtil.pattern_bigDecimal));
            item.setOutstandingAmt(rs.getBigDecimal("OUTSTANDING_AMT"));
            item.setOutstandingAmtStr(MoneyUtil.convertBigDecimalToStringByFormat(rs.getBigDecimal("OUTSTANDING_AMT"), MoneyUtil.pattern_bigDecimal));
            item.setPaidDate(rs.getDate("PAID_DATE"));
            item.setPaidDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("PAID_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("PAID_DATE")));
            try{
                BigDecimal bookValue = rs.getBigDecimal("BOOK_VALUE_BALANCE") != null ?  rs.getBigDecimal("BOOK_VALUE_BALANCE")  : BigDecimal.ZERO ;
                BigDecimal limitAmt = rs.getBigDecimal("LIMIT_AMT") != null ?  rs.getBigDecimal("LIMIT_AMT")  : BigDecimal.ZERO ;
                BigDecimal outstandingOverLimitAmt = bookValue.subtract(limitAmt);
            item.setOutstandingOverLimitAmt(outstandingOverLimitAmt);
             item.setOutstandingOverLimitAmtStr(MoneyUtil.convertBigDecimalToStringByFormat(outstandingOverLimitAmt, MoneyUtil.pattern_bigDecimal));
            }catch(Exception ex){
               log.error("Error occur in while process IndividualODAccountServiceImpl.getResultSetODAccount: " + ex.getMessage());
            }
       }catch(Exception e){
            log.error("Error occur in while process IndividualODAccountServiceImpl.getResultSetODAccount: " + e.getMessage());
       }
       return item;
    }

    @Override
    public List<IndividualODAccountVo> getWarningODOverLimit12Month(String cif) throws Exception {
        
        StringBuilder sql = new StringBuilder();
        List<IndividualODAccountVo> resultList = null;
        try{
            String startDt = DateUtil.getFirstMonthPeriousOneYear(); 
            String endDt = DateUtil.getLastDayOfMonth();  
            if (log.isInfoEnabled()) {
                log.info("IndividualODAccountServiceImpl.getWarningODOverLimit12Month");
            }
            sql.append(" SELECT * ");
            sql.append("\n FROM ewsmadm.TBL_RPT_INDIVIDUAL_OD_ACCOUNT ");
            sql.append("\n WHERE CIF = ? ");
            sql.append("\n AND PAID_DATE IS NOT NULL ");
        //--- 20/11/2015 By ANN Coz,mail P'Oon Track Record 16/11/2015 --//
            if((!ValidatorUtil.isNullOrEmpty(startDt))&&(!ValidatorUtil.isNullOrEmpty(endDt))){
                  sql.append("  AND ( DELINQ_DATE BETWEEN TO_DATE('").append(startDt).append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY')) ");
            }
         //------------  
        
             if(!ValidatorUtil.isNullOrEmpty(sql.toString())){
                resultList = (ArrayList<IndividualODAccountVo>) jdbcTemplate.query(sql.toString(),new Object[]{cif}, new RowMapper() {
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return getResultSetODAccount(rs);
                }});
           }
        } catch (Exception e) {
            log.error("Error occur in while process IndividualODAccountServiceImpl.getWarningODOverLimit12Month: " + e.getMessage(), e);
            throw e;
        }
       return resultList;
    }
}
