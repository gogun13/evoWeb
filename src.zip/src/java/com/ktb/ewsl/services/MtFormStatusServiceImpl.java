/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.MtFormStatusVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author pumin
 */
@Repository
public class MtFormStatusServiceImpl implements MtFormStatusService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(MtFormStatusServiceImpl.class);

    @Override
    public ArrayList<MtFormStatusVo> getFormConfigDetail() throws Exception {

        ArrayList<MtFormStatusVo> result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("MtFormConfigServiceImpl");
            }

            StringBuilder sql = new StringBuilder("SELECT * FROM TBL_MT_FORM_STATUS WHERE IS_ACTIVE =? ORDER BY SEQ ");
            result = (ArrayList<MtFormStatusVo>) jdbcTemplate.query(sql.toString(), new Object[]{"Y"}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    MtFormStatusVo vo = new MtFormStatusVo();
                    vo.setFormStatusFlg(rs.getString("FORM_STATUS_FLG"));
                    vo.setFormStatusName(rs.getString("FORM_STATUS_NAME"));
                    vo.setIsActive(rs.getString("IS_ACTIVE"));
                    vo.setSeq(rs.getString("SEQ"));
                    return vo;
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process MtFormConfigServiceImpl.getFormConfigDetail: " + e.getMessage(), e);
        }
        return result;
    }
    
    @Override
    public ArrayList<MtFormStatusVo> getStatusNameAndSeq() throws Exception {

        ArrayList<MtFormStatusVo> result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("getStatusNameAndSeq");
            }

            StringBuilder sql = new StringBuilder("SELECT DISTINCT FORM_STATUS_NAME, SEQ FROM TBL_MT_FORM_STATUS WHERE IS_ACTIVE =? ORDER BY SEQ ");
            result = (ArrayList<MtFormStatusVo>) jdbcTemplate.query(sql.toString(), new Object[]{"Y"}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    MtFormStatusVo vo = new MtFormStatusVo();
                    vo.setFormStatusName(rs.getString("FORM_STATUS_NAME"));
                    vo.setSeq(rs.getString("SEQ"));
                    return vo;
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process MtFormConfigServiceImpl.getStatusNameAndSeq: " + e.getMessage(), e);
        }
        return result;
    }
}
