/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ActionAccountVo;
import java.util.ArrayList;

/**
 *
 * @author pratya
 */
public interface ActionAccountService {
    public ArrayList<ActionAccountVo> getActionAccountList (String warningHeadId, String warningId) throws Exception;
    public void insert(ActionAccountVo actionAccountVo) throws Exception;
    public void updateActionFlag(ActionAccountVo actionAccountVo) throws Exception;
    public void deleteByWarningHeadIdAndWarningId(int warningHeadId, int warningId) throws Exception;
}
