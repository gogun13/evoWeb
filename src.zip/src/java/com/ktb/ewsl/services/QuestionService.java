/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AnswerVo;
import com.ktb.ewsl.vo.QuestionVo;
import java.util.List;

/**
 *
 * @author surapong
 */
public interface QuestionService {
    public List<QuestionVo> findQuestionByFilter(QuestionVo filter) throws Exception;
    public List<AnswerVo> findChoiceByQuestion(List<Integer> questIdList) throws Exception;
    public List<QuestionVo> findAssessmentAnswerByWraningIdAndQuestId(int wraningId, int questId) throws Exception;
    public void saveQuestion(QuestionVo questionVo) throws Exception;
    public void updateQuestion(QuestionVo questionVo) throws Exception;
}
