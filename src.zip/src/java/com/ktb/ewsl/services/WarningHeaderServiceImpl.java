/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.EWSConstantValue;
import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.CountDataVo;
import com.ktb.ewsl.vo.CustomerPortfolioVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class WarningHeaderServiceImpl extends AbstractJdbcService implements WarningHeaderService {

    private static Logger log = Logger.getLogger(WarningHeaderServiceImpl.class);
    /* TBL_WARNING_HEADER */
    private final static String A_WARNING_HEAD_ID = "WARNING_HEAD_ID";
    private final static String A_WARNING_DATE = "WARNING_DATE";
    private final static String A_STATUS = "STATUS";
    private final static String A_EWS_RISK_LEVEL = "EWS_RISK_LEVEL";
    private final static String A_DPD = "DPD";
    private final static String A_QCA_FLAG = "QCA_FLAG";
    private final static String A_FIN_FLAG = "FIN_FLAG";
    private final static String A_EWS_FLAG = "EWS_FLAG";
    private final static String A_TRIG_FLAG = "TRIG_FLAG";
    private final static String A_PAY_FLAG = "PAY_FLAG";
    private final static String A_CR_FLAG = "CR_FLAG";
    private final static String A_TA_FLAG = "TA_FLAG";
    private final static String A_SLA = "SLA";
    private final static String A_CR_EXPIRY_DT = "CR_EXPIRY_DT";
    private final static String A_OVER_LIMIT_FLAG = "OVER_LIMIT_FLAG";
    private final static String A_DISABLE_FLAG = "DISABLE_FLAG";
    private final static String CIF = "CIF";
    private final static String CREATED_DT = "CREATED_DT";
    private final static String CREATED_BY = "CREATED_BY";
    private final static String UPDATED_DT = "UPDATED_DT";
    private final static String UPDATED_BY = "UPDATED_BY";

  @Override
    public void updateFlagInWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateFlagInWarningHeader");
        }
        String field = ""; 
        if (warningHeaderVo.getFinFlg() != null && warningHeaderVo.getFinFlg().trim().length() > 0) {
            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field +  "FIN_FLG = '" + warningHeaderVo.getFinFlg() + "'";
        } 
        if ((warningHeaderVo.getEwsFlag() != null && warningHeaderVo.getEwsFlag().trim().length() > 0)||
                 (warningHeaderVo.getQualiFlg() != null && warningHeaderVo.getQualiFlg().trim().length() > 0)) {
            String valueOfQuali = "";
            if(warningHeaderVo.getEwsFlag() != null && warningHeaderVo.getEwsFlag().trim().length() > 0){
               valueOfQuali = warningHeaderVo.getEwsFlag();
            }else{
               valueOfQuali = warningHeaderVo.getQualiFlg();
            }
            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + "QUALI_FLG = '"+ valueOfQuali+"'";
        } 
        if (warningHeaderVo.getLatePayFlg() != null && warningHeaderVo.getLatePayFlg().trim().length() > 0) {
            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " LATE_PAY_FLG = '" + warningHeaderVo.getLatePayFlg() + "'";
        } 
        //if (warningHeaderVo.getBucketDpd() != null && warningHeaderVo.getBucketDpd().trim().length() > 0) {
        if (warningHeaderVo.getBucketDpd() != null) {//Fix R1.3 It can return ""
            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " BUCKET_DPD = '" + warningHeaderVo.getBucketDpd() + "'";
        }
        if (warningHeaderVo.getCrBucket() != null && warningHeaderVo.getCrBucket().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " CR_BUCKET = '" + warningHeaderVo.getCrBucket() + "'";
        }
        if (warningHeaderVo.getFormAssign() != null && warningHeaderVo.getFormAssign().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " ASSIGN_TASK = '" + warningHeaderVo.getFormAssign() + "'";
        }
        if (warningHeaderVo.getCrFormAssign() != null && warningHeaderVo.getCrFormAssign().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " ASSIGN_ACTION = '" + warningHeaderVo.getCrFormAssign() + "'";
        }
        if (warningHeaderVo.getEwsRiskLevel() != null) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " EWS_RISK_LEVEL = '" + warningHeaderVo.getEwsRiskLevel() + "'";
        }
        
        if (warningHeaderVo.getQualiRiskLevel() != null) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " QUALI_RISK_LEVEL = '" + warningHeaderVo.getQualiRiskLevel() + "'";
        }
        if (warningHeaderVo.getQuantiRiskLevel() != null) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " QUANTI_RISK_LEVEL = '" + warningHeaderVo.getQuantiRiskLevel() + "'";
        }
        //-------CR-L R3
        if (warningHeaderVo.getBucketRenewalFinal() != null) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " BUCKET_RENEWAL_FINAL = '" + warningHeaderVo.getBucketRenewalFinal() + "'";
        }
         if (warningHeaderVo.getBucketRating() != null) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " BUCKET_RATING = '" + warningHeaderVo.getBucketRating() + "'";
        }
        if (warningHeaderVo.getBucketRatingFinal()!= null) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " BUCKET_RATING_FINAL = '" + warningHeaderVo.getBucketRatingFinal() + "'";
        }
         if (warningHeaderVo.getReviewDateFinal()!= null && warningHeaderVo.getReviewDateFinalStr()!= null && warningHeaderVo.getReviewDateFinalStr().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            //field = field + " REVIEW_DATE_FINAL = " + warningHeaderVo.getReviewDateFinal() + "";
            field = field + " REVIEW_DATE_FINAL = TO_DATE('" + warningHeaderVo.getReviewDateFinalStr() + "','YYYYMMDD') ";
        }
        if (warningHeaderVo.getReasonRenewal() != null && warningHeaderVo.getReasonRenewal().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            field = field + " REASON_RENEWAL = '" + warningHeaderVo.getReasonRenewal() + "'";
        }
        if (warningHeaderVo.getTypesFlg() != null && warningHeaderVo.getTypesFlg().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
          field = field + " TYPES_FLG = '" + warningHeaderVo.getTypesFlg() + "'";
        }
        if (warningHeaderVo.getRatingDateFinal()!= null && warningHeaderVo.getRatingDateFinalStr()!= null && warningHeaderVo.getRatingDateFinalStr().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
            //field = field + " RATING_DATE_FINAL = " + warningHeaderVo.getRatingDateFinal() + "";
            field = field + " RATING_DATE_FINAL = TO_DATE('" + warningHeaderVo.getRatingDateFinalStr()+ "','YYYYMMDD') ";
        }
        if (warningHeaderVo.getAssignRating() != null && warningHeaderVo.getAssignRating().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
          field = field + " ASSIGN_RATING = '" + warningHeaderVo.getAssignRating() + "'";
        }
         if (warningHeaderVo.getReasonRating() != null && warningHeaderVo.getReasonRating().trim().length() > 0) {

            if (field.trim().length() > 0) {
                field = field + ",";
            }
          field = field + " REASON_RATING = '" + warningHeaderVo.getReasonRating() + "'";
        }
      
        if(field != null && !"".equals(field)){
        StringBuilder sql = new StringBuilder();
        sql.append("  UPDATE TBL_WARNING_HEADER SET ").append(field).append(", UPDATED_DT = ?, UPDATED_BY = ? ");
        sql.append("  WHERE WARNING_HEAD_ID = ? ");
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderVo.getUpdatedDate(),
            warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId()});
        }
    }

    @Override
    public void updateStatusAndFlagInWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateStatusAndFlagInWarningHeader");
            log.info("Fin >> "+warningHeaderVo.getFinFlg());
            log.info("EWS >> "+warningHeaderVo.getEwsFlag());
            log.info("LATE_PAY_FLG >> "+warningHeaderVo.getLatePayFlg());
            log.info(" getStatus >> "+warningHeaderVo.getStatus());
        }

        String field = "";
        if (warningHeaderVo.getFinFlg() != null && warningHeaderVo.getFinFlg().trim().length() > 0) {
            field = "FIN_FLG = '" + warningHeaderVo.getFinFlg() + "',";
        } else if (warningHeaderVo.getQualiFlg() != null && warningHeaderVo.getQualiFlg().trim().length() > 0) {
            field = "QUALI_FLG = '" + warningHeaderVo.getQualiFlg() + "',";
        } else if (warningHeaderVo.getLatePayFlg() != null && warningHeaderVo.getLatePayFlg().trim().length() > 0) {
            field = "LATE_PAY_FLG = '" + warningHeaderVo.getLatePayFlg() + "',";
        } 

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER SET ").append(field).append(" STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\n WHERE WARNING_HEAD_ID = ?");

        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getStatus(), warningHeaderVo.getUpdatedDate(),
            warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId()});
    }

    @Override
    public void updateStatusWarningHeaderAndFinFlag(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateStatusWarningHeaderAndFinFlag");
        }

        StringBuilder sql = new StringBuilder();
        sql.append(" UPDATE TBL_WARNING_HEADER SET STATUS = ?, FIN_FLAG = ? ,UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderVo.getStatus(),warningHeaderVo.getFinFlg(), warningHeaderVo.getUpdatedDate(),
            warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId()});
    }

    @Override
    public WarningHeaderVo findWarningHeaderObject(int warningHeaderId, String cifNo) throws Exception {
        WarningHeaderVo result = null;
        List<WarningHeaderVo> warningHeaderVoList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findWarningHeaderObject");
                log.info("warningHeaderId = " + warningHeaderId);
                log.info("cifNo = " + cifNo);
            }
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT WH.*, CR_ACCT_CNT, WI.ALERT_CNT as CR_WARNING_CNT");
            sql.append("\n FROM TBL_WARNING_HEADER WH ");
            sql.append("\n LEFT JOIN TBL_WARNING_INFO   WI  ON WH.WARNING_HEAD_ID  = WI.WARNING_HEAD_ID AND WI.WARNING_TYPE = 'CR' ");
            sql.append("\n WHERE WARNING_HEAD_ID = ? AND CIF = ? ");
            
            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }
            warningHeaderVoList =(ArrayList<WarningHeaderVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, cifNo}, new RowMapper(){
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        WarningHeaderVo item = new WarningHeaderVo();
                        item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                        item.setCif(rs.getString(CIF));
                        item.setWarningDate(rs.getDate(A_WARNING_DATE));
                        item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                        item.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                        item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                        item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                        item.setRespUnit(rs.getInt("RESP_UNIT"));
                        item.setRespUnitStr(StringUtil.getValue(rs.getString("RESP_UNIT")));
                        item.setEwsRiskLevel(StringUtil.getValue(rs.getString(A_EWS_RISK_LEVEL)));
                        item.setcFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                        item.setDpd(rs.getInt(A_DPD));
                        item.setDpdAcctCnt(rs.getInt("DPD_ACCT_CNT"));
                        item.setUnpaidAmt(rs.getBigDecimal("UNPAID_AMT"));
                        item.setOdOverAmt(rs.getBigDecimal("OD_OVER_AMT"));
                        item.setOdAcctCnt(rs.getInt("OD_ACCT_CNT"));
                        item.setOdAcctCntStr(rs.getInt("OD_ACCT_CNT") == 0 ? "" : rs.getString("OD_ACCT_CNT"));
                        item.setLatePayFlg(rs.getString("LATE_PAY_FLG"));
                        item.setAction1Flg(rs.getString("ACTION1_FLG"));
                        item.setAction2Flg(rs.getString("ACTION2_FLG"));
                        item.setQualiFlg(rs.getString("QUALI_FLG"));
                        item.setEwsFlag(rs.getString("QUALI_FLG"));
                        item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                        item.setFinFlg(rs.getString("FIN_FLG"));
                        item.setCrFlg(rs.getString("CR_FLG"));
//                        item.setCrAcctCnt(rs.getInt("CR_ACCT_CNT"));
//                        item.setCrWarningCnt(rs.getInt("CR_WARNING_CNT"));
                        
                        item.setCrAcctCnt(rs.getString("CR_ACCT_CNT"));
                        item.setCrWarningCnt(rs.getString("CR_WARNING_CNT"));
                        
                        item.setStatus(rs.getString("STATUS"));
                        item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                        item.setCreatedDate(rs.getDate("CREATED_DT"));
                        item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                        item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                        item.setTrigPayResult(rs.getString("TRIG_PAY_RESULT"));
                       // item.setFormAssign(StringUtil.getValue(rs.getString("FORMASSIGN"))); //---Change Field in DB
                        item.setBucketDpd(StringUtil.getValue(rs.getString("BUCKET_DPD")));
                       // item.setCrFormAssign(StringUtil.getValue(rs.getString("CR_FORMASSIGN"))); //---Change Field in DB
                        item.setFormAssign(StringUtil.getValue(rs.getString("ASSIGN_TASK")));
                        item.setCrFormAssign(StringUtil.getValue(rs.getString("ASSIGN_ACTION")));  
                        item.setCrBucket(StringUtil.getValue(rs.getString("CR_BUCKET")));
                        item.setQualiRiskLevel(StringUtil.getValue(rs.getString("QUALI_RISK_LEVEL")));
                        item.setQuantiRiskLevel(StringUtil.getValue(rs.getString("QUANTI_RISK_LEVEL")));
                        try {
                            if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString(A_DPD))) {
                                item.setDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt(A_DPD), MoneyUtil.patternDPD));
                            } else {
                                item.setDpdStrFormat("");
                            }
                            if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString("DPD_ACCT_CNT"))) {
                                item.setDpdAcctCntStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD_ACCT_CNT"), MoneyUtil.patternDPD));
                            } else {
                                item.setDpdAcctCntStr("");
                            }
                            if(rs.getBigDecimal("UNPAID_AMT") != null){
                               item.setUnpaidAmtStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("UNPAID_AMT"), MoneyUtil.pattern_bigDecimal));
                            }else{
                                item.setUnpaidAmtStr("");
                            }
                            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
                            item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getDate("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("MATURITY_DATE")));
                        } catch (Exception e) {
                        }
                       return item;
                    }
                });
      
            if (!warningHeaderVoList.isEmpty()) {
                result = (WarningHeaderVo) warningHeaderVoList.get(0);
            }
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.findWarningHeaderObject: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public Integer findWarningInfoALLNewOrBlank(int warningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findWarningInfoALLNewOrBlank");
        }
        StringBuilder sql = new StringBuilder();
        // --- For Change Other Flag before update STATUS  Firsttime 'I' and Backward to 'N '//
        sql.append("    SELECT COUNT(*) FROM (   ");
        sql.append("\n  SELECT     ");
        sql.append("\n  (CASE WHEN ACTION1_FLG IS NULL OR NULLIF(ACTION1_FLG, '') IS NULL OR ACTION1_FLG IN ('D','N') THEN 1 ELSE 0 END) AS ACTION1_FLG_S ,  ");
        sql.append("\n  (CASE WHEN CR_FLG IS NULL OR NULLIF(CR_FLG, '') IS NULL OR CR_FLG IN ('D','N') THEN 1 ELSE 0 END) AS CR_FLG_S ,  ");
        sql.append("\n  (CASE WHEN FIN_FLG IS NULL OR NULLIF(FIN_FLG, '') IS NULL OR FIN_FLG IN ('D','N') THEN 1 ELSE 0 END) AS FIN_FLG_S ,  ");
        sql.append("\n  (CASE WHEN CREDIT_RATING_FLG IS NULL OR NULLIF(CREDIT_RATING_FLG, '') IS NULL OR CREDIT_RATING_FLG IN ('D','N') THEN 1 ELSE 0 END) AS CREDIT_RATING_FLG_S , "); 
        sql.append("\n  (CASE WHEN LATE_PAY_FLG IS NULL OR NULLIF(LATE_PAY_FLG, '') IS NULL OR LATE_PAY_FLG IN ('D','N') THEN 1 ELSE 0 END) AS LATE_PAY_FLG_S ,  ");
        sql.append("\n (CASE WHEN QUALI_FLG IS NULL OR NULLIF(QUALI_FLG, '') IS NULL OR QUALI_FLG IN ('D','N') THEN 1 ELSE 0 END) AS QUALI_FLG_S ,  ");
        sql.append("\n (CASE WHEN ACTION2_FLG IS NULL OR NULLIF(ACTION2_FLG, '') IS NULL OR ACTION2_FLG IN ('D','N') THEN 1 ELSE 0 END) AS ACTION2_FLG_S ");
        sql.append("\n  FROM TBL_WARNING_HEADER WHERE WARNING_HEAD_ID =  ?  )  ");
        sql.append("\n  WHERE ACTION1_FLG_S = 1 AND CR_FLG_S = 1 AND FIN_FLG_S = 1 AND CREDIT_RATING_FLG_S= 1 AND LATE_PAY_FLG_S = 1 AND QUALI_FLG_S = 1 AND ACTION2_FLG_S = 1 ");
        //-- 0 is I , C  :: 1 is NULL , NA , Blank and N
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId}, Integer.class);
    }


    public boolean isNotNullOrNotEmptyOrMoreThanEqualZero(Object strParam) {
        boolean result = false;
        if ((strParam != null && strParam.toString().length() > 0)) {
            int data = Integer.parseInt(strParam.toString());
            if (data > 0) { //--Note DPD <= 0 display blank
                result = true;
            } else {
                result = false;
            }
        }
        return result;
    }

    @Override
    public List<QuestionHistoryVo> findWarningIdForQuestion(String cif ,String warningType) throws Exception {

        List<QuestionHistoryVo> warningList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findWarningIdForQuestion");
            }
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT H.WARNING_HEAD_ID,H.WARNING_DATE AS H_WARNING_DATE, W.WARNING_DATE AS W_WARNING_DATE, W.WARNING_ID, H.maturity_date FROM TBL_WARNING_HEADER H \n");
            sql.append("JOIN TBL_WARNING_INFO W ON \n");
            sql.append("H.WARNING_HEAD_ID = W.WARNING_HEAD_ID \n");
            sql.append("AND H.CIF= ? \n");
            sql.append("AND W.CLOSE_FLG <>'Y' \n");
            sql.append("AND W.WARNING_TYPE = ? \n");
            sql.append("AND H.STATUS = 'C'");
            sql.append("\n ORDER BY H_WARNING_DATE DESC ");
    
            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }

            warningList = jdbcTemplate.query(sql.toString(), new Object[]{cif,warningType}, new RowMapper() {
            public QuestionHistoryVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                QuestionHistoryVo vo = new QuestionHistoryVo();
                vo.setWarningId((String) rs.getString("WARNING_ID"));
                vo.setWarningDateInfo((String) rs.getString("W_WARNING_DATE"));
                vo.setWarningDateHeader((String) rs.getString("H_WARNING_DATE"));
                vo.setHeaderId((String) rs.getString("WARNING_HEAD_ID"));
                vo.setWarningDateInfoStrFormat(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("W_WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("W_WARNING_DATE")));
                vo.setMaturityDateStrFormat(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("maturity_date")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("maturity_date")));
                
                return vo;
                }
            });
            
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.findWarningIdForQuestion: " + e.getMessage(), e);
        }
        return warningList;
    }

    // ------------------------------- EWS SME SIZE L ------------------------------//
    @Override
    public PaginatedListImpl getPipeline(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        ArrayList<WarningHeaderVo> taskList = null;
        ArrayList<CountDataVo> cdList = null;
        try {
            String sql = getSQLPipeline(searchBean);
            
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                String rowNumSql;
                if (paginate.getIndex() < 0) {
                    rowNumSql = sql.toString();
                } else {
                    rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize());
                }
                taskList = (ArrayList<WarningHeaderVo>) jdbcTemplate.query(rowNumSql.toString(), new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        WarningHeaderVo item = new WarningHeaderVo();
                        item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                        item.setWarningDate(rs.getDate("WARNING_DATE"));
                        item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                        item.setCif(rs.getString("CIF"));
                        item.setRmId(rs.getString("RM_ID"));
                        item.setAeId(rs.getString("AE_ID"));
                        item.setAoId(rs.getString("AO_ID"));
                        item.setRespUnit(rs.getInt("RESP_UNIT"));
                        item.setRespUnitStr(rs.getInt("RESP_UNIT") == 0 ? "" : rs.getString("RESP_UNIT"));
                        item.setCoRmId(rs.getString("CO_RM_ID"));
                        item.setCoAeId(rs.getString("CO_AE_ID"));
                        item.setCoRespUnit(rs.getInt("CO_RESPONSE_UNIT"));
                        item.setCoRespUnitStr(rs.getInt("CO_RESPONSE_UNIT") == 0 ? "" : rs.getString("CO_RESPONSE_UNIT"));
                        item.setEwsRiskLevel(rs.getString("EWS_RISK_LEVEL"));
                        item.setcFinal(rs.getString("C_FINAL"));
                        item.setDpd(rs.getInt("DPD"));
                        item.setDpdAcctCnt(rs.getInt("DPD_ACCT_CNT"));
                        item.setDpdAcctCntStr(rs.getInt("DPD_ACCT_CNT") == 0 ? "" : rs.getString("DPD_ACCT_CNT"));
                        item.setUnpaidAmt(rs.getBigDecimal("UNPAID_AMT"));
                        item.setOdAcctCnt(rs.getInt("OD_ACCT_CNT"));
                        item.setOdAcctCntStr(rs.getInt("OD_ACCT_CNT") == 0 ? "" : rs.getString("OD_ACCT_CNT"));
                        item.setOdOverAmt(rs.getBigDecimal("OD_OVER_AMT"));
                        item.setLatePayFlg(rs.getString("LATE_PAY_FLG"));
                        item.setAction1Flg(rs.getString("ACTION1_FLG"));
                        item.setAction2Flg(rs.getString("ACTION2_FLG"));
                        item.setQualiFlg(rs.getString("QUALI_FLG"));
                        item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                        item.setFinFlg(rs.getString("FIN_FLG"));
                        item.setCrFlg(rs.getString("CR_FLG"));
//                        item.setCrAcctCnt(rs.getInt("CR_ACCT_CNT"));
//                        item.setCrWarningCnt(rs.getInt("CR_WARNING_CNT"));
                        item.setCrAcctCnt(rs.getString("CR_ACCT_CNT"));
                        item.setCrWarningCnt(rs.getString("CR_WARNING_CNT"));
                        item.setStatus(rs.getString("STATUS"));
                        item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                        item.setCreatedDate(rs.getDate("CREATED_DT"));
                        item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                        item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                        item.setSpAccount("");
                        item.setCountAlertLp(StringUtil.getValue(rs.getString("COUNT_ALERT_LP")));
                        item.setCountAlertAf1(StringUtil.getValue(rs.getString("COUNT_ALERT_AF1")));
                        item.setCountAlertAf2(StringUtil.getValue(rs.getString("COUNT_ALERT_AF2")));
                        item.setCountAlertQf(StringUtil.getValue(rs.getString("COUNT_ALERT_QF")));
                        item.setCountAlertFf(StringUtil.getValue(rs.getString("COUNT_ALERT_FF")));
                        item.setCrSla(rs.getInt("cr_sla"));
                        
                        try {
                            if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString("DPD"))) {
                                item.setDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD"), MoneyUtil.patternDPD));
                            } else {
                                item.setDpdStrFormat("");
                            }
                            item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                            if (rs.getString("OD_OVER_LIMIT") != null) {
                                item.setOdOverLimitStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_LIMIT"), MoneyUtil.patternDPD));
                            } else {
                                item.setOdOverLimitStr("");
                            }
                            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
                            item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getDate("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("MATURITY_DATE")));
                            if(rs.getBigDecimal("UNPAID_AMT") != null){
                                item.setUnpaidAmtStr(MoneyUtil.formatMoney(rs.getString("UNPAID_AMT"))); 
                            }else{
                                item.setUnpaidAmtStr("");
                            }
                            item.setTypesFlg(rs.getString("TYPES_FLG"));
                            item.setReviewDateFinal(rs.getDate("REVIEW_DATE_FINAL"));
                            item.setReviewDateFinalStr(ValidatorUtil.isNullOrEmpty(rs.getDate("REVIEW_DATE_FINAL")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("REVIEW_DATE_FINAL")));
                            item.setRatingDateFinal(rs.getDate("RATING_DATE_FINAL"));
                            item.setRatingDateFinalStr(ValidatorUtil.isNullOrEmpty(rs.getDate("RATING_DATE_FINAL")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("RATING_DATE_FINAL")));
                        } catch (Exception e) {
                        }
                        CustomerVo cv = new CustomerVo();
                        cv.setCustName(rs.getString("CUST_NAME"));
                        cv.setBusinessSize(rs.getString("BUSINESS_SIZE"));
                        cv.setResponseUnitName(rs.getString("COSTCENTER_NAME"));
                        cv.setResponseUnit(StringUtil.getValue(rs.getString("RESP_UNIT")));
                        cv.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                        cv.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                        cv.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                        cv.setRmName(StringUtil.getValue(rs.getString("RM_FULL_NAME")));
                        cv.setAeName(StringUtil.getValue(rs.getString("AE_FULL_NAME")));
                        cv.setAoName(StringUtil.getValue(rs.getString("AO_FULL_NAME")));
                        cv.setCoResponseUnitName(rs.getString("CO_COSTCENTER_NAME"));
                        cv.setCoResponseUnit(StringUtil.getValue(rs.getString("CO_RESPONSE_UNIT")));
                        cv.setCoRmId(StringUtil.getValue(rs.getString("CO_RM_ID")));
                        cv.setCoAeId(StringUtil.getValue(rs.getString("CO_AE_ID")));
                        cv.setCoRmName(StringUtil.getValue(rs.getString("CO_RM_FULL_NAME")));
                        cv.setCoAeName(StringUtil.getValue(rs.getString("CO_AE_FULL_NAME")));
                        item.setCustomerVo(cv);
                        return item;
                    }
                });

                String sqlCount = getSQLPipelineCount(sql.toString());
                cdList = (ArrayList<CountDataVo>) jdbcTemplate.query(sqlCount, new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        CountDataVo cd = new CountDataVo();
                        cd.setLatePayFlgCount(rs.getInt("LATE_PAY_FLG_COUNT"));
                        cd.setLatePayFlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("LATE_PAY_FLG_COUNT"), MoneyUtil.patternDPD));
                        cd.setAction1FlgCount(rs.getInt("ACTION1_FLG_COUNT"));
                        cd.setAction1FlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("ACTION1_FLG_COUNT"), MoneyUtil.patternDPD));
                        cd.setAction2FlgCount(rs.getInt("ACTION2_FLG_COUNT"));
                        cd.setAction2FlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("ACTION2_FLG_COUNT"), MoneyUtil.patternDPD));
                        cd.setQualiFlgCount(rs.getInt("QUALI_FLG_COUNT"));
                        cd.setQualiFlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("QUALI_FLG_COUNT"), MoneyUtil.patternDPD));
                        cd.setCreditRatingFlgCount(rs.getInt("CREDIT_RATING_FLG_COUNT"));
                        cd.setCreditRatingFlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("CREDIT_RATING_FLG_COUNT"), MoneyUtil.patternDPD));
                        cd.setFinFlgCount(rs.getInt("FIN_FLG_COUNT"));
                        cd.setFinFlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("FIN_FLG_COUNT"), MoneyUtil.patternDPD));
                        cd.setCrFlgCount(rs.getInt("CR_FLG_COUNT"));
                        cd.setCrFlgCountStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("CR_FLG_COUNT"), MoneyUtil.patternDPD));
                        return cd;
                    }
                });
                if ((cdList != null) && (!cdList.isEmpty())) {
                    paginate.setCountObjData(cdList.get(0));
                }
            }//SQL IS NULL
            if (taskList != null) {
                log.info("getTaskList.size() =  " + taskList.size());
            }
            int totalRecord = countTotal(sql.toString());
            paginate.setTotalRecord(totalRecord);
            paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
            paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
            paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
            paginate.setList(taskList);

        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getPipeline: " + e.getMessage(), e);
        }
        return paginate;
    }

    private String getSQLPipeline(SearchBean searchBean) {
        StringBuilder sql = new StringBuilder();
        if (searchBean != null) {
            log.info(" getRoleId ==> " + searchBean.getRoleId());
            log.info(" getEmpNo ==> " + searchBean.getEmpNo());
            log.info(" getResponseUnit ==> " + searchBean.getResponseUnit());
            log.info(" getTextSearch ==> " + searchBean.getTextSearch());
            log.info(" getByName ==> " + searchBean.getByName());
            log.info(" getSortField ==> " + searchBean.getSortField());
            log.info(" getSortType ==> " + searchBean.getSortType());
        }
        try {
            sql.append("\n SELECT  ");
            sql.append("\n WH.WARNING_HEAD_ID, WH.WARNING_DATE, WH.CIF, ");
            sql.append("\n WH.RM_ID, WH.AE_ID, WH.AO_ID, WH.RESP_UNIT, ");
            sql.append("\n WH.CO_RM_ID, WH.CO_AE_ID, WH.CO_RESPONSE_UNIT, ");
            sql.append("\n WH.C_FINAL, WH.DPD, ");
            sql.append("\n WH.DPD_ACCT_CNT, WH.UNPAID_AMT, WH.OD_OVER_LIMIT, WH.OD_ACCT_CNT, WH.OD_OVER_AMT,  ");
            sql.append("\n WH.LATE_PAY_FLG, WH.ACTION1_FLG, WH.ACTION2_FLG, WH.QUALI_FLG, WH.CREDIT_RATING_FLG,  ");
            //sql.append("\n WH.FIN_FLG, WH.CR_FLG, WH.MATURITY_DATE, WH.CR_ACCT_CNT, WI.ALERT_CNT as CR_WARNING_CNT, ");
            sql.append("\n WH.FIN_FLG, WH.CR_FLG, WH.MATURITY_DATE, WH.CR_ACCT_CNT, ALERT_CRF.ALERT_CNT as CR_WARNING_CNT, ");
            sql.append("\n WH.STATUS, WH.CREATED_DT, WH.CREATED_BY, WH.UPDATED_DT, WH.UPDATED_BY, NVL(WH.cr_sla, 16) cr_sla, ");
            sql.append("\n C.CUST_NAME ,C.BUSINESS_SIZE, ");
            sql.append("\n ERM.DEPT_CODE , CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(ERM.TITLE_NAME, '')),''),TRIM(NVL(ERM.EMP_NAME, ''))),' '),TRIM(NVL(ERM.EMP_SURNAME, ''))) AS RM_FULL_NAME,   ");
            sql.append("\n EAE.DEPT_CODE , CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(EAE.TITLE_NAME, '')),''),TRIM(NVL(EAE.EMP_NAME, ''))),' '),TRIM(NVL(EAE.EMP_SURNAME, ''))) AS AE_FULL_NAME,   ");
            sql.append("\n EAO.DEPT_CODE , CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(EAO.TITLE_NAME, '')),''),TRIM(NVL(EAO.EMP_NAME, ''))),' '),TRIM(NVL(EAO.EMP_SURNAME, ''))) AS AO_FULL_NAME ,  ");
            sql.append("\n O.COSTCENTER_NAME,  ");
            sql.append("\n ECORM.DEPT_CODE , CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(ECORM.TITLE_NAME, '')),''),TRIM(NVL(ECORM.EMP_NAME, ''))),' '),TRIM(NVL(ECORM.EMP_SURNAME, ''))) AS CO_RM_FULL_NAME,   ");
            sql.append("\n ECOAE.DEPT_CODE , CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(ECOAE.TITLE_NAME, '')),''),TRIM(NVL(ECOAE.EMP_NAME, ''))),' '),TRIM(NVL(ECOAE.EMP_SURNAME, ''))) AS CO_AE_FULL_NAME,   ");
            sql.append("\n CO_ORG.COSTCENTER_NAME AS CO_COSTCENTER_NAME,  ");
            sql.append("\n LP.SEQ AS SORT_LATE_PAY_FORM, AF1.SEQ  AS SORT_ACTION1_FROM , AF2.SEQ  AS SORT_ACTION2_FROM,  ");
            sql.append("\n QF.SEQ  AS SORT_QUALI,QR.SEQ AS SORT_CREDIT_RATING , FF.SEQ  AS SORT_FIN,CRF.SEQ  AS SORT_CREDIT_REVIEW  ");
            sql.append("\n , RL.RISK_LEVEL_SHORT_NAME  AS EWS_RISK_LEVEL ,  RL.SEQ  AS SORT_EWS_RISK_LEVEL , ");
            sql.append("\n CASE     ");
            sql.append("\n        WHEN WH.LATE_PAY_FLG IS NULL  OR NULLIF(WH.LATE_PAY_FLG, '') IS NULL OR (WH.LATE_PAY_FLG = 'D') THEN 0     ");
            sql.append("\n        ELSE 1     ");
            sql.append("\n  END as  LATE_PAY_FLG_FOR_COUNT ,     ");
            sql.append("\n   CASE     ");
            sql.append("\n        WHEN WH.ACTION1_FLG IS NULL  OR NULLIF(WH.ACTION1_FLG, '') IS NULL OR (WH.ACTION1_FLG = 'D') THEN 0     ");
            sql.append("\n        ELSE 1     ");
            sql.append("\n  END as  ACTION1_FLG_FOR_COUNT,  ");
            sql.append("\n    CASE     ");
            sql.append("\n        WHEN WH.ACTION2_FLG IS NULL  OR NULLIF(WH.ACTION2_FLG, '') IS NULL OR (WH.ACTION2_FLG = 'D') THEN 0     ");
            sql.append("\n        ELSE 1     ");
            sql.append("\n  END as  ACTION2_FLG_FOR_COUNT,  ");
            sql.append("\n    CASE     ");
            sql.append("\n        WHEN WH.QUALI_FLG IS NULL  OR NULLIF(WH.QUALI_FLG, '') IS NULL OR (WH.QUALI_FLG = 'D') THEN 0     ");
            sql.append("\n        ELSE 1     ");
            sql.append("\n  END as  QUALI_FLG_FOR_COUNT,  ");
            sql.append("\n    CASE     ");
            sql.append("\n        WHEN WH.CREDIT_RATING_FLG IS NULL  OR NULLIF(WH.CREDIT_RATING_FLG, '') IS NULL OR (WH.CREDIT_RATING_FLG = 'D') THEN 0     ");
            sql.append("\n         ELSE 1    ");
            sql.append("\n  END as  CREDIT_RATING_FLG_FOR_COUNT,  ");
            sql.append("\n    CASE     ");
            sql.append("\n        WHEN WH.FIN_FLG IS NULL  OR NULLIF(WH.FIN_FLG, '') IS NULL OR (WH.FIN_FLG = 'D') THEN 0     ");
            sql.append("\n        ELSE 1     ");
            sql.append("\n  END as  FIN_FLG_FOR_COUNT,  ");
            sql.append("\n    CASE     ");
            sql.append("\n        WHEN WH.CR_FLG IS NULL  OR NULLIF(WH.CR_FLG, '') IS NULL OR (WH.CR_FLG = 'D') THEN 0    ");
            sql.append("\n        ELSE 1     ");
            sql.append("\n  END as  CR_FLG_FOR_COUNT  ");
            sql.append("\n ,CASE  ");
            sql.append("\n     WHEN WH.DPD <= 0  OR  WH.DPD IS NULL THEN  0 ");
            sql.append("\n     ELSE  WH.DPD ");
            sql.append("\n END as SORT_DPD  ");   
            sql.append("\n , NVL(ALERT_LP.ALERT_CNT, 0) + NVL(ALERT_LP.ALERT_EXCEED_SLA_CNT, 0) as COUNT_ALERT_LP ");
            sql.append("\n , NVL(ALERT_AF1.ALERT_CNT, 0) + NVL(ALERT_AF1.ALERT_EXCEED_SLA_CNT, 0) as COUNT_ALERT_AF1 ");
            sql.append("\n , NVL(ALERT_AF2.ALERT_CNT, 0) + NVL(ALERT_AF2.ALERT_EXCEED_SLA_CNT, 0) as COUNT_ALERT_AF2 ");
            sql.append("\n , NVL(ALERT_QF.ALERT_CNT, 0) + NVL(ALERT_QF.ALERT_EXCEED_SLA_CNT, 0) as COUNT_ALERT_QF ");
            sql.append("\n , NVL(ALERT_FF.ALERT_CNT, 0) + NVL(ALERT_FF.ALERT_EXCEED_SLA_CNT, 0) as COUNT_ALERT_FF ");
            sql.append("\n , WH.TYPES_FLG , WH.REVIEW_DATE_FINAL  , WH.RATING_DATE_FINAL  ");
            sql.append("\n FROM TBL_WARNING_HEADER WH   ");
            sql.append("\n LEFT JOIN TBL_CUSTOMER C ON C.CIF = WH.CIF  ");
            sql.append("\n LEFT JOIN TBL_MT_KTB_ORGANIZATION O ON WH.RESP_UNIT = O.COSTCENTER_CODE  ");
            sql.append("\n LEFT JOIN TBL_EMPLOYEE ERM ON WH.RM_ID = ERM.EMP_NO  ");
            sql.append("\n LEFT JOIN TBL_EMPLOYEE EAE ON WH.AE_ID = EAE.EMP_NO  ");
            sql.append("\n LEFT JOIN TBL_EMPLOYEE EAO ON WH.AO_ID = EAO.EMP_NO  ");
            sql.append("\n LEFT JOIN TBL_MT_KTB_ORGANIZATION CO_ORG ON WH.CO_RESPONSE_UNIT = CO_ORG.COSTCENTER_CODE  ");
            sql.append("\n LEFT JOIN TBL_EMPLOYEE ECORM ON WH.CO_RM_ID = ECORM.EMP_NO  ");
            sql.append("\n LEFT JOIN TBL_EMPLOYEE ECOAE ON WH.CO_AE_ID = ECOAE.EMP_NO  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS LP ON WH.LATE_PAY_FLG = LP.FORM_STATUS_FLG AND   LP.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS AF1 ON WH.ACTION1_FLG = AF1.FORM_STATUS_FLG AND  AF1.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS AF2 ON WH.ACTION2_FLG = AF2.FORM_STATUS_FLG AND  AF2.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS QF ON WH.QUALI_FLG = QF.FORM_STATUS_FLG AND  QF.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS QR ON WH.QUALI_FLG = QR.FORM_STATUS_FLG AND  QR.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS FF ON WH.FIN_FLG = FF.FORM_STATUS_FLG AND  FF.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_FORM_STATUS CRF ON WH.CR_FLG = CRF.FORM_STATUS_FLG AND  CRF.IS_ACTIVE = 'Y'  ");
            sql.append("\n LEFT JOIN TBL_MT_RISK_LEVEL  RL  ON WH.EWS_RISK_LEVEL  = RL.RISK_LEVEL  ");
          //  sql.append("\n LEFT JOIN TBL_WARNING_INFO   WI  ON WH.WARNING_HEAD_ID  = WI.WARNING_HEAD_ID AND WI.WARNING_TYPE = 'CR' ");
            sql.append("\n LEFT JOIN (SELECT I_ORG.WARNING_HEAD_ID , I_MAX.WARNING_ID ,  I_ORG.ALERT_CNT , I_ORG.ALERT_EXCEED_SLA_CNT    ");
            sql.append("\n            FROM TBL_WARNING_INFO I_ORG    ");
            sql.append("\n            INNER JOIN (SELECT MAX(WARNING_ID) AS WARNING_ID ,WARNING_HEAD_ID    ");
            sql.append("\n                        FROM TBL_WARNING_INFO   ");
            sql.append("\n                        WHERE WARNING_TYPE = 'CR' AND STATUS != 'CC'  ");
            sql.append("\n                        GROUP BY WARNING_HEAD_ID ) I_MAX   ");
            sql.append("\n            ON I_ORG.WARNING_ID = I_MAX.WARNING_ID AND I_ORG.WARNING_HEAD_ID = I_MAX.WARNING_HEAD_ID)   ALERT_CRF    ");
            sql.append("\n  ON WH.WARNING_HEAD_ID  = ALERT_CRF.WARNING_HEAD_ID  ");
          //  sql.append("\n LEFT JOIN TBL_WARNING_INFO   ALERT_LP  ON WH.WARNING_HEAD_ID  = ALERT_LP.WARNING_HEAD_ID AND ALERT_LP.WARNING_TYPE = 'LATE_PAY'");
            sql.append("\n LEFT JOIN (  SELECT I_ORG.WARNING_HEAD_ID , I_MIN.WARNING_ID ,  I_ORG.ALERT_CNT , I_ORG.ALERT_EXCEED_SLA_CNT  FROM TBL_WARNING_INFO I_ORG  ");
            sql.append("\n INNER JOIN (SELECT MIN(WARNING_ID) AS WARNING_ID ,WARNING_HEAD_ID  FROM TBL_WARNING_INFO WHERE WARNING_TYPE = 'LATE_PAY' GROUP BY WARNING_HEAD_ID ) I_MIN ");
            sql.append("\n ON I_ORG.WARNING_ID = I_MIN.WARNING_ID AND I_ORG.WARNING_HEAD_ID = I_MIN.WARNING_HEAD_ID ) ALERT_LP ON WH.WARNING_HEAD_ID  = ALERT_LP.WARNING_HEAD_ID         ");
            sql.append("\n LEFT JOIN TBL_WARNING_INFO   ALERT_AF1  ON WH.WARNING_HEAD_ID  = ALERT_AF1.WARNING_HEAD_ID AND ALERT_AF1.WARNING_TYPE = 'ACTION1'");
            sql.append("\n LEFT JOIN TBL_WARNING_INFO   ALERT_AF2  ON WH.WARNING_HEAD_ID  = ALERT_AF2.WARNING_HEAD_ID AND ALERT_AF2.WARNING_TYPE = 'ACTION2'");
            sql.append("\n LEFT JOIN (SELECT I_ORG.WARNING_HEAD_ID , I_MAX.WARNING_ID ,  I_ORG.ALERT_CNT , I_ORG.ALERT_EXCEED_SLA_CNT  ");
            sql.append("\n                      FROM TBL_WARNING_INFO I_ORG  ");
            sql.append("\n                        INNER JOIN (SELECT MAX(WARNING_ID) AS WARNING_ID ,WARNING_HEAD_ID  ");
            sql.append("\n                                      FROM TBL_WARNING_INFO ");
            sql.append("\n                                      WHERE WARNING_TYPE = 'EWSQ' ");
            sql.append("\n                                      GROUP BY WARNING_HEAD_ID ) I_MAX ");
            sql.append("\n                          ON I_ORG.WARNING_ID = I_MAX.WARNING_ID AND I_ORG.WARNING_HEAD_ID = I_MAX.WARNING_HEAD_ID) ALERT_QF  ");
            sql.append("\n  ON WH.WARNING_HEAD_ID  = ALERT_QF.WARNING_HEAD_ID");
            sql.append("\n LEFT JOIN (SELECT I_ORG.WARNING_HEAD_ID , I_MAX.WARNING_ID ,  I_ORG.ALERT_CNT , I_ORG.ALERT_EXCEED_SLA_CNT  ");
            sql.append("\n                      FROM TBL_WARNING_INFO I_ORG  ");
            sql.append("\n                        INNER JOIN (SELECT MAX(WARNING_ID) AS WARNING_ID ,WARNING_HEAD_ID  ");
            sql.append("\n                                      FROM TBL_WARNING_INFO ");
            sql.append("\n                                      WHERE WARNING_TYPE = 'FIN' ");
            sql.append("\n                                      GROUP BY WARNING_HEAD_ID ) I_MAX ");
            sql.append("\n                          ON I_ORG.WARNING_ID = I_MAX.WARNING_ID AND I_ORG.WARNING_HEAD_ID = I_MAX.WARNING_HEAD_ID)   ALERT_FF  ");
            sql.append("\n  ON WH.WARNING_HEAD_ID  = ALERT_FF.WARNING_HEAD_ID");
            sql.append("\n WHERE WH.STATUS != 'C' AND WH.STATUS IS NOT NULL ");
            sql.append("\n AND WH.WARNING_DATE <= CURRENT TIMESTAMP ");
            //----Start---- Criteria-------
            if (BusinessConst.UserRole.RM.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getEmpNo()))&& (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) { //--- RM
                sql.append(" AND WH.RM_ID = '").append(searchBean.getEmpNo().trim()).append("' AND WH.RESP_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            if (BusinessConst.UserRole.AE.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getEmpNo()))&& (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) {
                sql.append(" AND WH.AE_ID = '").append(searchBean.getEmpNo().trim()).append("' AND WH.RESP_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            if (BusinessConst.UserRole.AO.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getEmpNo()))&& (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) {
                sql.append(" AND WH.AO_ID = '").append(searchBean.getEmpNo().trim()).append("' AND WH.RESP_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            
            if (BusinessConst.UserRole.BCM.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) {
                sql.append(" AND WH.RESP_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            if (BusinessConst.UserRole.CO_RM.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getEmpNo()))&& (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) { //--- RM
                sql.append(" AND WH.CO_RM_ID = '").append(searchBean.getEmpNo().trim()).append("' AND WH.CO_RESPONSE_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            if (BusinessConst.UserRole.CO_AE.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getEmpNo()))&& (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) {
                sql.append(" AND WH.CO_AE_ID = '").append(searchBean.getEmpNo().trim()).append("' AND WH.CO_RESPONSE_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            if (BusinessConst.UserRole.CO_AO.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getEmpNo()))&& (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) {
                sql.append(" AND WH.CO_AO_ID = '").append(searchBean.getEmpNo().trim()).append("' AND WH.CO_RESPONSE_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
            if (BusinessConst.UserRole.CO_BCM.equals(searchBean.getRoleId()) && (!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit()))) {
                sql.append(" AND WH.CO_RESPONSE_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' ");
            }
           //**** 07/06/2016 Change Condition For Search Data By Role "VW" and VW1-4 see data like RE , RV , AD
           // if (EWSConstantValue.USER_ROLE_WITH_ORGANIZATION.contains(searchBean.getRoleId()) && !ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit())) {
           
            if(!ValidatorUtil.isNullOrEmpty(searchBean.getResponseUnit())){
                 if (BusinessConst.UserRole.VIEWER.equals(searchBean.getRoleId())) {
                    sql.append("\n  AND WH.RESP_UNIT  IN (  ");
                    sql.append("\n SELECT distinct(COSTCENTER_CODE)  ");
                    sql.append("\n FROM TBL_MT_KTB_ORGANIZATION  ");
                    sql.append("\n WHERE COSTCENTER_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                    sql.append("\n OR BUSINESSUNIT_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                    sql.append("\n OR GROUP_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                    sql.append("\n OR REGION_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                    sql.append("\n OR DEPARTMENT_CODE = '").append(searchBean.getResponseUnit().trim()).append("' ) ");
                }else if (BusinessConst.UserRole.AMD.equals(searchBean.getRoleId())) {
                    sql.append("\n  AND WH.RESP_UNIT  IN (  ");
                    sql.append("\n select COSTCENTER_CODE");
                    sql.append("\n FROM TBL_MT_AMD_COSTCENTER_MAPPING  ");
                    sql.append("\n WHERE DEPARTMENT_CODE = '").append(searchBean.getResponseUnit().trim()).append("'");
                    sql.append("\n group by COSTCENTER_CODE)");
                } 
            }
            
          /* ---- 15/12/2558 P'Oon mail to change RE should be see all port same RV
           * if (EWSConstantValue.USER_ROLE_WITH_ORGANIZATION_CTRL.contains(searchBean.getRoleId())) {
                sql.append("\n  AND WH.RESP_UNIT  IN (  ");
                sql.append("\n SELECT SUB_COSTCENTER_CODE FROM TBL_MT_KTB_ORGANIZATION_CTRL  ");
                sql.append("\n WHERE COSTCENTER_CODE = '").append(searchBean.getResponseUnit().trim()).append("' ) ");
            }*/
             
             if(EWSConstantValue.ROLE_SEARCH_BUSINESS_SIZE.contains(searchBean.getRoleId())){
                 sql.append("\n  AND C.BUSINESS_SIZE IN ( SELECT SME_SIZE FROM TBL_ROLE_ACCESS WHERE ROLE_CODE = '").append(searchBean.getRoleId()).append("') ");
             }
             
            //----END---- Criteria-------    
            //-- Start : Search Condition --//
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getTextSearch())) {
                
                if ("L".equals(searchBean.getTextSearch()) || "CBC1".equals(searchBean.getTextSearch()) || "CBC2".equals(searchBean.getTextSearch())) {
                    sql.append("\n AND C.BUSINESS_SIZE = '").append(searchBean.getTextSearch().trim()).append("' ");
                }else if ("CBC1_CBC2".equals(searchBean.getTextSearch())) {
                    sql.append("\n AND C.BUSINESS_SIZE IN ('CBC1', 'CBC2') ");
                }else if ("L_CBC1_CBC2".equals(searchBean.getTextSearch())) {
                    sql.append("\n AND C.BUSINESS_SIZE IN ('L', 'CBC1', 'CBC2') ");
                }
                
                
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getByName())) {
                    if (BusinessConst.SearchTitle.CIF.equals(searchBean.getTextSearch())) {
                        //sql.append("\n AND C.CIF LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                        sql.append("\n AND WH.CIF LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                    if (BusinessConst.SearchTitle.NAME.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND C.CUST_NAME LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                    if (BusinessConst.SearchTitle.RM_ID.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND WH.RM_ID LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                    if (BusinessConst.SearchTitle.RM_NAME.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND (ERM.TITLE_NAME LIKE '%").append(searchBean.getByName().trim()).append("%' OR ERM.EMP_NAME LIKE '%").append(searchBean.getByName().trim()).append("%' OR  ERM.EMP_SURNAME LIKE '%").append(searchBean.getByName().trim()).append("%')  ");
                    }
                    if (BusinessConst.SearchTitle.COSTCENTER.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND WH.RESP_UNIT LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                    if (BusinessConst.SearchTitle.COSTCENTER_NAME.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND O.COSTCENTER_NAME LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                    if (BusinessConst.SearchTitle.CO_RM_ID.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND WH.CO_RM_ID LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                    if (BusinessConst.SearchTitle.CO_OP_ID.equals(searchBean.getTextSearch())) {
                        sql.append("\n AND WH.CO_RESPONSE_UNIT LIKE '%").append(searchBean.getByName().trim()).append("%' ");
                    }
                }
            }
            //-- END : Search Condition --//
            //--------------------------ORDER- : SORT-----------------------------------
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getSortField()) && !ValidatorUtil.isNullOrEmpty(searchBean.getSortType())) {
                if ("C_FINAL".equals(searchBean.getSortField())) {
                    sql.append(" ORDER BY case when C_FINAL IS NULL OR NULLIF(C_FINAL, '') is null then 1 else 0 end, C_FINAL ").append(searchBean.getSortType());
                } else if ("OD_OVER_LIMIT".equals(searchBean.getSortField())) {
                    sql.append(" ORDER BY  case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT ").append(searchBean.getSortType());
                } else {
                    sql.append(" ORDER BY ");
                    sql.append(searchBean.getSortField()).append("  ").append(searchBean.getSortType());
                }
            } else {
                sql.append(" ORDER BY  SORT_DPD  DESC  , SORT_LATE_PAY_FORM DESC , SORT_CREDIT_REVIEW DESC , SORT_QUALI DESC , SORT_CREDIT_RATING DESC , SORT_FIN DESC , SORT_EWS_RISK_LEVEL DESC ");
            }
            //--------------------------ORDER- : SORT-----------------------------------

        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getSQLPipeline: " + e.getMessage(), e);
        }
        return sql.toString();
    }

    private String getSQLPipelineCount(String subSql) {
        StringBuilder sql = new StringBuilder();
        try {
            sql.append("  SELECT SUM(LATE_PAY_FLG_FOR_COUNT) AS LATE_PAY_FLG_COUNT, ");
            sql.append("  SUM(ACTION1_FLG_FOR_COUNT)  AS ACTION1_FLG_COUNT, ");
            sql.append("  SUM(ACTION2_FLG_FOR_COUNT)  AS ACTION2_FLG_COUNT, ");
            sql.append("  SUM(QUALI_FLG_FOR_COUNT) AS QUALI_FLG_COUNT , ");
            sql.append("  SUM(CREDIT_RATING_FLG_FOR_COUNT)  AS CREDIT_RATING_FLG_COUNT, ");
            sql.append("  SUM(FIN_FLG_FOR_COUNT)  AS FIN_FLG_COUNT, ");
            sql.append("  SUM(CR_FLG_FOR_COUNT)  AS CR_FLG_COUNT ");
            sql.append("  FROM(  ");
            sql.append(subSql);
            sql.append("  ) ");
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getSQLPipelineCount: " + e.getMessage(), e);
        }
        return sql.toString();
    }
    
    @Override
    public void updateStatusWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateStatusWarningHeader");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" UPDATE TBL_WARNING_HEADER SET STATUS = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderVo.getStatus(),
            warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId()});
    }

    @Override
    public WarningHeaderVo findWarningHeaderByPK(int warningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findWarningHeaderByPK");
        }
        StringBuilder sql = new StringBuilder();
        
        sql.append("SELECT * ");
        sql.append("\n  FROM TBL_WARNING_HEADER");
        sql.append("\n  WHERE WARNING_HEAD_ID = ?");
        
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

      
        WarningHeaderVo result = new WarningHeaderVo();
         ArrayList<WarningHeaderVo> resultList =(ArrayList<WarningHeaderVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper(){
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningHeaderVo item = new WarningHeaderVo();
                    item.setWarningHeaderId((rs.getInt("WARNING_HEAD_ID")));
                    item.setWarningDate(rs.getDate("WARNING_DATE"));
                    item.setDpd((rs.getInt("DPD")));
                    item.setOdOverAmt((rs.getBigDecimal("OD_OVER_LIMIT")));
                    item.setCrFlg(rs.getString("CR_FLG"));
                    item.setStatus(rs.getString("STATUS"));
                    item.setDpdOd((rs.getInt("DPD_OD")));
                    
                    /*begin Release 3.1*/
                    item.setAoId(rs.getString("AO_ID"));
                    item.setAeId(rs.getString("AE_ID"));
                    item.setRmId(rs.getString("RM_ID"));
                    item.setRespUnitStr(rs.getString("RESP_UNIT"));
                    item.setCoAoId(rs.getString("CO_AO_ID"));
                    item.setCoAeId(rs.getString("CO_AE_ID"));
                    item.setCoRmId(rs.getString("CO_RM_ID"));
                    item.setCoRespUnitStr(rs.getString("CO_RESPONSE_UNIT"));
                    /*end Release 3.1*/
                    
                    /*Begin [EWS-L for CR-L R3] แก้ไขการปิดงาน by CIF*/
                    item.setCrFlg(rs.getString("CR_FLG"));
                    item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                    /*End [EWS-L for CR-L R3] แก้ไขการปิดงาน by CIF*/
                    
                    return item;
                }
            });
        if(resultList !=null && !resultList.isEmpty()){
            result = (WarningHeaderVo) resultList.get(0);
        }
        
        return result;
    }
    
    @Override
    public void updateAction1Flg(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateAction1Flg");
            log.info("Action1Flg         :: "+warningHeaderVo.getAction1Flg());
            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER SET ACTION1_FLG = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getAction1Flg()
                                                         ,warningHeaderVo.getUpdatedBy()
                                                         ,warningHeaderVo.getWarningHeaderId()
                            });
    }
    
    @Override
    public void updateAction2Flg(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateAction2Flg");
            log.info("Action2Flg         :: "+warningHeaderVo.getAction2Flg());
            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER SET ACTION2_FLG = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getAction2Flg()
                                                         ,warningHeaderVo.getUpdatedBy()
                                                         ,warningHeaderVo.getWarningHeaderId()
                            });
    }

//    @Override
//    public void updateWayOutFlg(WarningHeaderVo warningHeaderVo) throws Exception {
//        if (log.isInfoEnabled()) {
//            log.info("updateWayOutFlg");
//            log.info("WayOutFlg         :: "+warningHeaderVo.getWayOutFlg());
//            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
//        }
//
//        StringBuilder sql = new StringBuilder();
//        sql.append("UPDATE TBL_WARNING_HEADER SET WAY_OUT_FLG = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
//        sql.append("\nWHERE WARNING_HEAD_ID = ?");
//        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getWayOutFlg()
//                                                         ,warningHeaderVo.getUpdatedBy()
//                                                         ,warningHeaderVo.getWarningHeaderId()
//                            });
//    }
    
    @Override
    public void updateCrAcctCnt(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateCrAcctCnt");
            log.info("cif         :: " + warningHeaderVo.getCif());
            log.info("updatedBy   :: " + warningHeaderVo.getUpdatedBy());
        }

        StringBuilder sql = new StringBuilder();
        
        sql.append("UPDATE TBL_WARNING_HEADER SET");
        sql.append("\n  CR_ACCT_CNT = (SELECT COUNT(*) FROM TBL_CR_WARNING_ACCOUNT WHERE RENEW_FLG = 'N' AND CIF = ?)");
        sql.append("\n  ,UPDATED_DT = CURRENT TIMESTAMP");
        sql.append("\n  ,UPDATED_BY = ?");
        sql.append("\n WHERE WARNING_HEAD_ID = (SELECT MAX(WARNING_HEAD_ID) FROM TBL_WARNING_HEADER WHERE CIF = ? AND STATUS <> 'C')");
        
        log.info("sql   :: " + sql.toString());
        
        
        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getCif()
                                                         ,warningHeaderVo.getUpdatedBy()
                                                         ,warningHeaderVo.getCif()
                                                        });
    }

    @Override
    public WarningHeaderVo findWarningHeaderObjectOriginal(int warningHeaderId, String cifNo) throws Exception {
         WarningHeaderVo result = null;
        List<WarningHeaderVo> warningHeaderVoList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findWarningHeaderObjectOriginal");
                log.info("warningHeaderId = " + warningHeaderId);
                log.info("cifNo = " + cifNo);
            }
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT WARNING_HEAD_ID, WARNING_DATE, CIF, RM_ID, AE_ID, ");
            sql.append("        AO_ID, RESP_UNIT, EWS_RISK_LEVEL, C_FINAL, DPD, DPD_ACCT_CNT, ");
            sql.append("        UNPAID_AMT, OD_OVER_LIMIT, OD_ACCT_CNT, OD_OVER_AMT, ");
            sql.append("        LATE_PAY_FLG, ACTION1_FLG, ACTION2_FLG, QUALI_FLG, CREDIT_RATING_FLG,");
            sql.append("        FIN_FLG, CR_FLG, MATURITY_DATE, CR_ACCT_CNT, STATUS, CREATED_DT, CREATED_BY, ");
            sql.append("        UPDATED_DT, UPDATED_BY, SLA, TRIG_PAY_RESULT, ASSIGN_TASK AS FORMASSIGN, BUCKET_DPD, ASSIGN_ACTION AS CR_FORMASSIGN, ");
            sql.append("        CR_BUCKET, QUALI_RISK_LEVEL, QUANTI_RISK_LEVEL, DPD_OD, BUCKET_DPD_OD, ");
            sql.append("        BUCKET_DPD_FINAL, DELINQ_DATE, HV_DELINQ_DATE, CR_SLA , BUCKET_RATING  , BUCKET_RENEWAL");
            sql.append("  FROM TBL_WARNING_HEADER   ");
            sql.append("  WHERE WARNING_HEAD_ID = ?   AND CIF =  ?  ");
    
            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }
             warningHeaderVoList =(ArrayList<WarningHeaderVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, cifNo}, new RowMapper(){
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            WarningHeaderVo item = new WarningHeaderVo();
                            item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                            item.setWarningDate(rs.getDate(A_WARNING_DATE));
                            item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                            item.setCif(rs.getString("CIF"));
                            item.setRmId(rs.getString("RM_ID"));
                            item.setAeId(rs.getString("AE_ID"));
                            item.setAoId(rs.getString("AO_ID"));
                            item.setRespUnit(rs.getInt("RESP_UNIT"));
                            item.setRespUnitStr(rs.getString("RESP_UNIT"));
                            item.setEwsRiskLevel(StringUtil.getValue(rs.getString(A_EWS_RISK_LEVEL)));
                            item.setcFinal(rs.getString("C_FINAL"));
                            item.setDpd(rs.getInt(A_DPD));
                            item.setDpdAcctCnt(rs.getInt("DPD_ACCT_CNT"));
                            item.setUnpaidAmt(rs.getBigDecimal("UNPAID_AMT"));
                            item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                            item.setOdAcctCnt(rs.getInt("OD_ACCT_CNT"));
                            item.setOdOverAmt(rs.getBigDecimal("OD_OVER_AMT"));
                            item.setLatePayFlg(rs.getString("LATE_PAY_FLG"));
                            item.setAction1Flg(rs.getString("ACTION1_FLG"));
                            item.setAction2Flg(rs.getString("ACTION2_FLG"));
                            item.setQualiFlg(rs.getString("QUALI_FLG"));
                             item.setEwsFlag(rs.getString("QUALI_FLG"));
                            item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                            item.setFinFlg(rs.getString("FIN_FLG"));
                            item.setCrFlg(rs.getString("CR_FLG"));
                            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
                            item.setCrAcctCnt(rs.getString("CR_ACCT_CNT"));
                            item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                            item.setCreatedBy(StringUtil.getValue(rs.getString(CREATED_BY)));
                            item.setCreatedDate(rs.getDate(CREATED_DT));
                            item.setUpdatedBy(StringUtil.getValue(rs.getString(UPDATED_BY)));
                            item.setUpdatedDate(rs.getDate(UPDATED_DT));
                             item.setTrigPayResult(rs.getString("TRIG_PAY_RESULT"));
                            try {
                                item.setDpdStr(rs.getString(A_DPD)); //-- FOR GET NULL ,0
                                if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString(A_DPD))) {
                                    item.setDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt(A_DPD), MoneyUtil.patternDPD));
                                } else {
                                    item.setDpdStrFormat("");
                                }
                                 item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
                                 item.setSla(rs.getInt(A_SLA));
                                if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                                    item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                                }else{
                                    item.setSlaStr("");
                                }
                            } catch (Exception e) {
                            }
                            item.setFormAssign(StringUtil.getValue(rs.getString("FORMASSIGN")));
                            item.setBucketDpd(StringUtil.getValue(rs.getString("BUCKET_DPD")));
                            item.setCrFormAssign(StringUtil.getValue(rs.getString("CR_FORMASSIGN")));
                            item.setCrBucket(StringUtil.getValue(rs.getString("CR_BUCKET")));
                            item.setQualiRiskLevel(StringUtil.getValue(rs.getString("QUALI_RISK_LEVEL")));
                            item.setQuantiRiskLevel(StringUtil.getValue(rs.getString("QUANTI_RISK_LEVEL")));
                            item.setDpdOdBigdecimal(rs.getBigDecimal("DPD_OD"));
                            item.setBucketDpdOd(rs.getString("BUCKET_DPD_OD"));
                            item.setBucketDpdFinal(rs.getString("BUCKET_DPD_FINAL"));
                            item.setDelinqDate(rs.getDate("DELINQ_DATE"));
                            item.setHvDelinqDate(rs.getString("HV_DELINQ_DATE"));
                            //item.setRiskLevelChange(rs.getString("RISK_LEVEL_CHANGE"));
                            item.setCrSlaBigDecimal(rs.getBigDecimal("CR_SLA"));
                            item.setBucketRating(rs.getString("BUCKET_RATING"));
                            item.setBucketRenewal(rs.getString("BUCKET_RENEWAL"));
                           return item;
                        }
                    });
      
            if (!warningHeaderVoList.isEmpty()) {
                result = (WarningHeaderVo) warningHeaderVoList.get(0);
            }
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.findWarningHeaderObject: " + e.getMessage(), e);
        }
        return result;
    }
    
    @Override
    public Integer checkDataBeforeCloseOutOfPipeline(int warningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("checkDataBeforeCloseOutOfPipeline");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("  SELECT COUNT(*) FROM TBL_WARNING_HEADER ");
        sql.append("\n WHERE WARNING_HEAD_ID = ?  ");
        sql.append("\n AND (DPD IS NULL OR DPD = 0) ");
        sql.append("\n AND (DPD_OD IS NULL OR DPD_OD = 0) ");
        sql.append("\n AND LATE_PAY_FLG IN ('C','D') ");
        sql.append("\n AND ACTION1_FLG IN ('C','D') ");
        sql.append("\n AND ACTION2_FLG IN ('C','D') ");
        sql.append("\n AND QUALI_FLG IN ('C','D','E') ");
        sql.append("\n AND CREDIT_RATING_FLG IN ('C','D') ");
        sql.append("\n AND FIN_FLG IN ('C','D','E') ");
        sql.append("\n AND CR_FLG IN ('C','D') ");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId}, Integer.class);
    }

    @Override
    public int updateStateAfterCheckDataBeforeCloseOutOfPipeline(String updateBy , int warningHeaderId) throws Exception {
       if (log.isDebugEnabled()) {
            log.debug("updateStateAfterCheckDataBeforeCloseOutOfPipeline");
        }
       int rowEffiected = 0;
       
        StringBuilder sql = new StringBuilder();
  /*     ----- Change Code Follow Mail ------- 
   *    sql.append(" UPDATE TBL_WARNING_HEADER  ");
        sql.append("\n SET STATUS = 'C', UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ? ");
        sql.append("\n WHERE WARNING_HEAD_ID = ?  ");
        sql.append("\n AND (DPD IS NULL OR DPD = 0)  ");
        sql.append("\n AND (DPD_OD IS NULL OR DPD_OD = 0)  ");
        sql.append("\n AND LATE_PAY_FLG IN ('C','D')  ");
        sql.append("\n AND ACTION1_FLG IN ('C','D')  ");
        sql.append("\n AND ACTION2_FLG IN ('C','D')  ");
        sql.append("\n AND QUALI_FLG IN ('C','D','E')  ");
        sql.append("\n AND CREDIT_RATING_FLG IN ('C','D')  ");
        sql.append("\n AND FIN_FLG IN ('C','D','E')  ");
        sql.append("\n AND CR_FLG IN ('C','D')  ");*/
        
    /*--DEFECT--    sql.append(" UPDATE TBL_WARNING_HEADER    ");
        sql.append("\n SET STATUS = 'C', UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?   ");
        sql.append("\n WHERE WARNING_HEAD_ID = ? ");
        sql.append("\n  AND  'TRUE' =  ( ");
        sql.append("\n SELECT ");
        sql.append("\n CASE  ");
        sql.append("\n WHEN WARNING_HEAD_ID IS NOT NULL AND NULLIF(WARNING_HEAD_ID, 0) IS NOT NULL THEN 'TRUE' ");
        sql.append("\n ELSE 'FALSE' ");
        sql.append("\n END AS RESULT_CHECK ");
        sql.append("\n FROM TBL_WARNING_HEADER ");
        sql.append("\n        WHERE WARNING_HEAD_ID = ? ");
        sql.append("\n         AND (DPD IS NULL OR DPD = 0)    ");
        sql.append("\n         AND (DPD_OD IS NULL OR DPD_OD = 0)    ");
        sql.append("\n        AND LATE_PAY_FLG IN ('C','D')    ");
        sql.append("\n         AND ACTION1_FLG IN ('C','D')    ");
        sql.append("\n         AND ACTION2_FLG IN ('C','D')    ");
        sql.append("\n         AND QUALI_FLG IN ('C','D','E')    ");
        sql.append("\n         AND FIN_FLG IN ('C','D','E')    ");
        sql.append("\n  ) AND  'TRUE' =       ");
        sql.append("\n ( SELECT ");
        sql.append("\n  CASE  ");
        sql.append("\n      WHEN C.CIF IS NOT NULL AND NULLIF(C.CIF, 0) IS NOT NULL THEN 'TRUE' ");
        sql.append("\n   ELSE 'FALSE' ");
        sql.append("\n  END AS RESULT_CHECK ");
        sql.append("\n FROM  TBL_WARNING_HEADER H ");
        sql.append("\n INNER JOIN TBL_CUSTOMER C ");
        sql.append("\n ON C.CIF = H.CIF ");
        sql.append("\n AND H.WARNING_HEAD_ID = ? AND H.STATUS != 'C' ");
        sql.append("\n AND  ( C.AMD_RESPONSE_UNIT IS NOT NULL AND NULLIF(C.AMD_RESPONSE_UNIT, 0) IS NOT NULL ) ");
        sql.append("\n INNER JOIN TBL_WARNING_INFO I ");
        sql.append("\n ON H.WARNING_HEAD_ID = I.WARNING_HEAD_ID ");
        sql.append("\n AND I.WARNING_HEAD_ID  = ? ");
        sql.append("\n AND ((I.WARNING_TYPE = 'ACTION1' AND I.AMD_FLG = 'C')");
        sql.append("\n  OR (I.WARNING_TYPE = 'ACTION2' AND I.AMD_FLG = 'C')))");
 */
        
        sql.append("\n UPDATE TBL_WARNING_HEADER  ");         
        sql.append("\n SET STATUS = 'C', UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?   ");          
        sql.append("\n WHERE WARNING_HEAD_ID = (  ");
        sql.append("\n SELECT DISTINCT H.WARNING_HEAD_ID    ");    
        sql.append("\n FROM  TBL_WARNING_HEADER H         ");    
        sql.append("\n INNER JOIN TBL_CUSTOMER C ON C.CIF = H.CIF  ");    
        sql.append("\n INNER JOIN TBL_WARNING_INFO I ON H.WARNING_HEAD_ID = I.WARNING_HEAD_ID ");    
        sql.append("\n WHERE H.WARNING_HEAD_ID  =  ? ");    
        sql.append("\n AND H.STATUS != 'C' ");    
        sql.append("\n AND (H.DPD IS NULL OR DPD = 0)        ");        
        sql.append("\n AND (H.DPD_OD IS NULL OR DPD_OD = 0)     ");           
        sql.append("\n AND H.LATE_PAY_FLG IN ('C','D')        ");        
        sql.append("\n AND H.ACTION1_FLG IN ('C','D')       ");         
        sql.append("\n AND H.ACTION2_FLG IN ('C','D')      ");          
        sql.append("\n AND H.QUALI_FLG IN ('C','D','E')    ");            
        sql.append("\n AND H.FIN_FLG IN ('C','D','E')    ");   
        sql.append("\n AND H.CR_FLG IN ('C','D','E')   ");             //CR-L R3
        sql.append("\n AND H.CREDIT_RATING_FLG IN ('C','D','E')  ");   //CR-L R3
        sql.append("\n AND (I.WARNING_TYPE IN ('LATE_PAY','EWSQ','FIN','CR','CREDIT_RATING') ");    //CR-L R3      
        sql.append("\n OR I.WARNING_TYPE IN ('ACTION1','ACTION2') AND CASE WHEN(NVL(I.BCM_AMD_FLG,'-') = '-') THEN I.AMD_FLG ELSE I.BCM_AMD_FLG END = 'C' AND C.AMD_RESPONSE_UNIT IS NOT NULL AND NVL(C.AMD_RESPONSE_UNIT, 0) != 0)  ");        
        sql.append("\n ) ");
        
        if (log.isDebugEnabled()) {
             log.info("sql ==> " + sql.toString());
        }
               
        rowEffiected = jdbcTemplate.update(sql.toString(), new Object[]{updateBy,warningHeaderId});
        return rowEffiected;
    }
    @Override
    public void updateResultTrigger(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateResultTrigger");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" UPDATE TBL_WARNING_HEADER SET TRIG_PAY_RESULT = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderVo.getTrigPayResult(), warningHeaderVo.getUpdatedDate(),
            warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId()});
    }

    @Override
    public int updateForApprove(WarningHeaderVo warningHeaderVo) throws Exception {
        
        int rowEffiected = 0;
        
        if (log.isInfoEnabled()) {
            log.info("updateForApprove");
            log.info("UpdatedBy         :: "+warningHeaderVo.getUpdatedBy());
            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER");
        sql.append("    SET STATUS = 'C', UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
        sql.append("    WHERE WARNING_HEAD_ID = ?");
        sql.append("        AND (DPD IS NULL OR DPD = 0)");
        sql.append("        AND (DPD_OD IS NULL OR DPD_OD = 0)");
        sql.append("        AND LATE_PAY_FLG IN ('C','D')");
        sql.append("        AND ACTION1_FLG IN ('C','D')");
        sql.append("        AND ACTION2_FLG IN ('C','D')");
        sql.append("        AND QUALI_FLG IN ('C','D','E')");
        sql.append("        AND CREDIT_RATING_FLG IN ('C','D')");
        sql.append("        AND FIN_FLG IN ('C','D','E')");
        sql.append("        AND CR_FLG IN ('C','D')");
        
        if (log.isInfoEnabled()) {
            log.info("sql :: " + sql.toString());
        }
        
        rowEffiected = jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getUpdatedBy()
                                                                        ,warningHeaderVo.getWarningHeaderId()
                       });
        
        return rowEffiected;
        
    }
    
    @Override
    public void updateCrFlg(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateCrFlg");
            log.info("crFlg             :: "+warningHeaderVo.getCrFlg());
            log.info("updatedBy         :: "+warningHeaderVo.getUpdatedBy());
            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER");
        sql.append("    SET");
        sql.append("        CR_FLG = ?");
        sql.append("        ,UPDATED_DT = CURRENT TIMESTAMP");
        sql.append("        ,UPDATED_BY = ?");
        sql.append("    WHERE WARNING_HEAD_ID = ?");
        sql.append("        AND CR_ACCT_CNT = 0");
        sql.append("        AND CR_FLG != 'C'");
        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getCrFlg()
                                                         ,warningHeaderVo.getUpdatedBy()
                                                         ,warningHeaderVo.getWarningHeaderId()
                            });
    }
    
    @Override
    public int getWarningHeaderIdbyCif(String cif) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("getWarningHeaderIdbyCif");
        }
        int             warningHeaderId   = 0;
        StringBuilder   sql               = new StringBuilder();
        
        sql.append("SELECT MAX(WARNING_HEAD_ID) FROM TBL_WARNING_HEADER WHERE CIF = ? AND STATUS <> 'C'");
        
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        ArrayList<WarningHeaderVo> resultList =(ArrayList<WarningHeaderVo>) jdbcTemplate.query(sql.toString(), new Object[]{cif}, new RowMapper(){
               @Override
               public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                   WarningHeaderVo item = new WarningHeaderVo();
                   item.setWarningHeaderId((rs.getInt("WARNING_HEAD_ID")));
                   return item;
               }
           });
        if(resultList !=null && !resultList.isEmpty()){
            warningHeaderId = resultList.get(0).getWarningHeaderId();
        }
        
        return warningHeaderId;
    } 
    
    @Override
    public int updateForApproveForCloaseByCif(WarningHeaderVo warningHeaderVo) throws Exception {
        
        int rowEffiected = 0;
        
        if (log.isInfoEnabled()) {
            log.info("updateForApproveForCloaseByCif");
            log.info("UpdatedBy         :: "+warningHeaderVo.getUpdatedBy());
            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER");
        sql.append("    SET STATUS = 'C', UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
        sql.append("    WHERE WARNING_HEAD_ID = ?");
//        sql.append("        AND (DPD IS NULL OR DPD = 0)");
//        sql.append("        AND (DPD_OD IS NULL OR DPD_OD = 0)");
        
        if (log.isInfoEnabled()) {
            log.info("sql :: " + sql.toString());
        }
        
        rowEffiected = jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getUpdatedBy()
                                                                        ,warningHeaderVo.getWarningHeaderId()
                       });
        
        return rowEffiected;
        
    }
    
    @Override
    public int countForCloseByCif(int warningHeaderId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("countForCloseByCif");
        }
        StringBuilder   sql = new StringBuilder();
        int             cnt = 0;
        sql.append("SELECT COUNT(*)");
        sql.append("    FROM TBL_WARNING_HEADER");
        sql.append("    WHERE WARNING_HEAD_ID = ?");
        sql.append("        AND LATE_PAY_FLG IN ('N','D') ");
        sql.append("        AND ACTION1_FLG IN ('N','D') ");
        sql.append("        AND ACTION2_FLG IN ('N','D') ");
        sql.append("        AND QUALI_FLG IN ('N','D') ");
        sql.append("        AND CREDIT_RATING_FLG IN ('N','D') ");
        sql.append("        AND FIN_FLG IN ('N','D') ");
        sql.append("        AND CR_FLG IN ('N','D')");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }
        
        cnt = jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId}, Integer.class);

        return cnt;
    }
    
    @Override
    public void updateAction1FlgAndLatePayMentFlg(WarningHeaderVo warningHeaderVo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("updateAction1FlgAndLatePayMentFlg");
            log.info("LatePayFlg        :: "+warningHeaderVo.getLatePayFlg());
            log.info("Action1Flg        :: "+warningHeaderVo.getAction1Flg());
            log.info("UpdatedBy         :: "+warningHeaderVo.getUpdatedBy());
            log.info("WarningHeaderId   :: "+warningHeaderVo.getWarningHeaderId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_HEADER SET LATE_PAY_FLG = ?, ACTION1_FLG = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{ warningHeaderVo.getLatePayFlg()
                                                         ,warningHeaderVo.getAction1Flg()
                                                         ,warningHeaderVo.getUpdatedBy()
                                                         ,warningHeaderVo.getWarningHeaderId()
                            });
    }

    @Override
    public WarningHeaderVo findWarningHeaderObjectOriginalFromWarningId(int warningId) throws Exception {
       WarningHeaderVo result = null;
        List<WarningHeaderVo> warningHeaderVoList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findWarningHeaderObjectOriginalFromWarningId");
                log.info("warningId = " + warningId);
            }
            StringBuilder sql = new StringBuilder();
              sql.append(" SELECT H.WARNING_HEAD_ID, H.WARNING_DATE, H.CIF, H.RM_ID, H.AE_ID,  "); 
              sql.append(" H.AO_ID, H.RESP_UNIT, H.EWS_RISK_LEVEL, H.C_FINAL, DPD, H.DPD_ACCT_CNT,   ");
              sql.append(" H.UNPAID_AMT, H.OD_OVER_LIMIT, H.OD_ACCT_CNT, H.OD_OVER_AMT,   ");
              sql.append(" H.LATE_PAY_FLG, H.ACTION1_FLG, H.ACTION2_FLG, H.QUALI_FLG, H.CREDIT_RATING_FLG,  ");
              sql.append(" H.FIN_FLG, H.CR_FLG, H.MATURITY_DATE, H.CR_ACCT_CNT, H.STATUS, H.CREATED_DT, H.CREATED_BY,   ");
              sql.append(" H.UPDATED_DT, H.UPDATED_BY, H.SLA, H.TRIG_PAY_RESULT, H.ASSIGN_TASK AS FORMASSIGN, H.BUCKET_DPD, H.ASSIGN_ACTION AS CR_FORMASSIGN,   ");
              sql.append(" H.CR_BUCKET,H.QUALI_RISK_LEVEL, H.QUANTI_RISK_LEVEL, H.DPD_OD, H.BUCKET_DPD_OD,   ");
              sql.append(" H.BUCKET_DPD_FINAL, H.DELINQ_DATE, H.HV_DELINQ_DATE, H.CR_SLA   ");
              sql.append(" FROM TBL_WARNING_HEADER H    ");
              sql.append(" JOIN TBL_WARNING_INFO I ");
              sql.append(" ON  I.WARNING_HEAD_ID = H.WARNING_HEAD_ID ");
              sql.append(" WHERE I.WARNING_ID =   ?  ");
        
            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }
             warningHeaderVoList =(ArrayList<WarningHeaderVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new RowMapper(){
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            WarningHeaderVo item = new WarningHeaderVo();
                            item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                            item.setWarningDate(rs.getDate(A_WARNING_DATE));
                            item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                            item.setCif(rs.getString("CIF"));
                            item.setRmId(rs.getString("RM_ID"));
                            item.setAeId(rs.getString("AE_ID"));
                            item.setAoId(rs.getString("AO_ID"));
                            item.setRespUnit(rs.getInt("RESP_UNIT"));
                            item.setRespUnitStr(rs.getString("RESP_UNIT"));
                            item.setEwsRiskLevel(StringUtil.getValue(rs.getString(A_EWS_RISK_LEVEL)));
                            item.setcFinal(rs.getString("C_FINAL"));
                            item.setDpd(rs.getString(A_DPD) != null && !rs.getString(A_DPD).equals("") ? Integer.parseInt(rs.getString(A_DPD)) :  null);
                            item.setDpdAcctCnt(rs.getInt("DPD_ACCT_CNT"));
                            item.setUnpaidAmt(rs.getBigDecimal("UNPAID_AMT"));
                            item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                            item.setOdAcctCnt(rs.getInt("OD_ACCT_CNT"));
                            item.setOdOverAmt(rs.getBigDecimal("OD_OVER_AMT"));
                            item.setLatePayFlg(rs.getString("LATE_PAY_FLG"));
                            item.setAction1Flg(rs.getString("ACTION1_FLG"));
                            item.setAction2Flg(rs.getString("ACTION2_FLG"));
                            item.setQualiFlg(rs.getString("QUALI_FLG"));
                             item.setEwsFlag(rs.getString("QUALI_FLG"));
                            item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                            item.setFinFlg(rs.getString("FIN_FLG"));
                            item.setCrFlg(rs.getString("CR_FLG"));
                            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
                            item.setCrAcctCnt(rs.getString("CR_ACCT_CNT"));
                            item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                            item.setCreatedBy(StringUtil.getValue(rs.getString(CREATED_BY)));
                            item.setCreatedDate(rs.getDate(CREATED_DT));
                            item.setUpdatedBy(StringUtil.getValue(rs.getString(UPDATED_BY)));
                            item.setUpdatedDate(rs.getDate(UPDATED_DT));
                             item.setTrigPayResult(rs.getString("TRIG_PAY_RESULT"));
                            try {
                                    if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString(A_DPD))) {
                                        item.setDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt(A_DPD), MoneyUtil.patternDPD));
                                    } else {
                                        item.setDpdStrFormat("");
                                    }
                                     item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
                                     item.setSla(rs.getInt(A_SLA));
                                    if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                                        item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                                    }else{
                                        item.setSlaStr("");
                                    }
                            } catch (Exception e) {
                            }
                            item.setFormAssign(StringUtil.getValue(rs.getString("FORMASSIGN")));
                            item.setBucketDpd(StringUtil.getValue(rs.getString("BUCKET_DPD")));
                            item.setCrFormAssign(StringUtil.getValue(rs.getString("CR_FORMASSIGN")));
                            item.setCrBucket(StringUtil.getValue(rs.getString("CR_BUCKET")));
                            item.setQualiRiskLevel(StringUtil.getValue(rs.getString("QUALI_RISK_LEVEL")));
                            item.setQuantiRiskLevel(StringUtil.getValue(rs.getString("QUANTI_RISK_LEVEL")));
                            item.setDpdOdBigdecimal(rs.getBigDecimal("DPD_OD"));
                            item.setBucketDpdOd(rs.getString("BUCKET_DPD_OD"));
                            item.setBucketDpdFinal(rs.getString("BUCKET_DPD_FINAL"));
                            item.setDelinqDate(rs.getDate("DELINQ_DATE"));
                            item.setHvDelinqDate(rs.getString("HV_DELINQ_DATE"));
                            //item.setRiskLevelChange(rs.getString("RISK_LEVEL_CHANGE"));
                            item.setCrSlaBigDecimal(rs.getBigDecimal("CR_SLA"));
                           return item;
                        }
                    });
      
            if (!warningHeaderVoList.isEmpty()) {
                result = (WarningHeaderVo) warningHeaderVoList.get(0);
            }
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.findWarningHeaderObjectOriginalFromWarningId: " + e.getMessage(), e);
            throw e;
        }
        return result;
    }
     @Override
    public List<QuestionHistoryVo> findWarningIdForHistory(String cif, String warningType) throws Exception {
        if (log.isInfoEnabled()) {
           log.info("findWarningIdForHistory");
        }
        List<QuestionHistoryVo> warningList = null;
           
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT WARNING_HEAD_ID ,WARNING_ID ,WARNING_DATE FROM TBL_WARNING_INFO ");
            sql.append("\n WHERE WARNING_HEAD_ID IN (SELECT WARNING_HEAD_ID FROM TBL_WARNING_HEADER WHERE CIF = ? ) ");
            sql.append("\n AND WARNING_TYPE = ? ");
            sql.append("\n AND STATUS = 'C' ");
            sql.append("\n AND CLOSE_FLG <>'Y' ");
            sql.append("\n ORDER BY WARNING_DATE DESC ");
    
            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }

            warningList = jdbcTemplate.query(sql.toString(), new Object[]{cif,warningType}, new RowMapper() {
            public QuestionHistoryVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                QuestionHistoryVo vo = new QuestionHistoryVo();
                vo.setWarningId((String) rs.getString("WARNING_ID"));
                vo.setWarningDateInfo((String) rs.getString("WARNING_DATE"));
                vo.setWarningDateInfoStrFormat(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                vo.setHeaderId((String) rs.getString("WARNING_HEAD_ID"));
                return vo;
                }
            });
        return warningList;
    }
    @Override
    public PaginatedListImpl getCustomerPortfolioListForPaging(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        ArrayList<CustomerPortfolioVo> taskList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("WarningHeaderServiceImpl.getCustomerPortfolioListForPaging");
            }

//            StringBuilder sql = getSQLCustomerPortfolioListForPaging(searchBean);
            StringBuilder sql = getSQLIndividualReportList_1(searchBean, null);
           
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                String rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize());
                    taskList = (ArrayList<CustomerPortfolioVo>) jdbcTemplate.query(rowNumSql.toString(), new RowMapper() {
                        @Override
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                             CustomerPortfolioVo item = new CustomerPortfolioVo();
                                item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                                item.setCif(rs.getInt("CIF"));
                                item.setWarningDate(rs.getDate("WARNING_DATE"));
                                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                                //item.setCreditReviewFlag(StringUtil.getValue(rs.getString("CR_FLAG")));
                                item.setMaxDpd(rs.getInt("DPD"));
                                 if(isNullOrEmptyOrMoreAndEqualZero(rs.getString("DPD"))){
                                        item.setMaxDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD"), MoneyUtil.patternDPD));
                                    }else{
                                        item.setMaxDpdStrFormat("");
                                    }
                                item.setEwsRiskLevel(StringUtil.getValue(rs.getString("DATA_EWS_RISK_LEVEL")));
                                //item.setEwsRiskLevel(DisplayUtil.getRiskLevelForDisplay(rs.getString("EWS_RISK_LEVEL")));
                                item.setStatus(StringUtil.getValue(rs.getString("STATUS")));
                                item.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                                item.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                                item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                                item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                                item.setAmdResponseUnit(StringUtil.getValue(rs.getString("AMD_RESPONSE_UNIT")));
                                item.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                                item.setCostcenterName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                                item.setBusinessUnitCode(StringUtil.getValue(rs.getString("BUSINESSUNIT_CODE")));
                                item.setGroupCode(StringUtil.getValue(rs.getString("GROUP_CODE")));
                                item.setCostcenterCode(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                                item.setQuantiBehavModle(StringUtil.getValue(rs.getString("DATA_QUANTI_RISK_LEVEL")));
                                item.setQualitativeAssessment(StringUtil.getValue(rs.getString("DATA_QUALI_RISK_LEVEL")));
                             return item;
                        }
                    });

            }//SQL IS NULL
            int totalRecord = countTotal(sql.toString());
            paginate.setTotalRecord(totalRecord);
            paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
            paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
            paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
            paginate.setList(taskList);

        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getCustomerPortfolioListForPaging: " + e.getMessage(), e);
            throw e;
        }
        return paginate;
    }
    
    private StringBuilder getSQLCustomerPortfolioListForPaging(SearchBean searchBean)throws Exception {
       StringBuilder sql = new StringBuilder();
       try {
            sql.append(" SELECT DATA.WARNING_HEAD_ID AS WARNING_HEAD_ID , DATA.CIF AS CIF , DATA.WARNING_DATE AS WARNING_DATE , ");
            sql.append("\n DATA.STATUS AS STATUS , DATA.DPD AS DPD , ");
            sql.append("\n DATA.CUST_NAME  AS CUST_NAME ,DATA.RM_ID AS RM_ID,DATA.AE_ID AS AE_ID,DATA.AO_ID AS AO_ID, ");
            sql.append("\n DATA.AMD_RESPONSE_UNIT AS AMD_RESPONSE_UNIT ,");
            sql.append("\n DATA.MAX_BATCH_DATE,");
            sql.append("\n DATA.RESPONSE_UNIT AS RESPONSE_UNIT ,DATA.COSTCENTER_NAME AS COSTCENTER_NAME,DATA.BUSINESSUNIT_CODE AS BUSINESSUNIT_CODE , ");
            sql.append("\n DATA.GROUP_CODE AS GROUP_CODE ,DATA.COSTCENTER_CODE AS COSTCENTER_CODE ,RLM_1.ORDER_SEQ AS SORT_EWS_RISK_LEVEL , ");
            sql.append("\n RLM_1.RISK_LEVEL_IND_RPT_DISP AS DATA_EWS_RISK_LEVEL , RLM_2.ORDER_SEQ  AS SORT_QUALI_RISK_LEVEL , ");
            sql.append("\n RLM_2.RISK_LEVEL_IND_RPT_DISP AS DATA_QUALI_RISK_LEVEL ,RLM_3.ORDER_SEQ  AS SORT_QUANTI_RISK_LEVEL , ");
            sql.append("\n RLM_3.RISK_LEVEL_IND_RPT_DISP AS DATA_QUANTI_RISK_LEVEL, ");
            sql.append("\n CASE ");
            sql.append("\n        WHEN DATA.DPD <= 0 OR DATA.DPD   IS NULL ");
            sql.append("\n        THEN 0 ");
            sql.append("\n        ELSE DATA.DPD ");
            sql.append("\n  END AS SORT_DPD ");
            sql.append("\n FROM ( ");
            sql.append("\n SELECT  C.CUST_NAME   , C.RM_ID ,  C.AE_ID ,  C.AO_ID  ,   C.RESPONSE_UNIT  , C.AMD_RESPONSE_UNIT , ");
            sql.append("\n C.MAX_BATCH_DATE , ");
            sql.append("\n O.COSTCENTER_NAME  ,  O.BUSINESSUNIT_CODE  , O.GROUP_CODE  , O.COSTCENTER_CODE , ");
            sql.append("\n H.WARNING_HEAD_ID ,  C.CIF   ,  H.WARNING_DATE  ,   H.STATUS  ,   H.DPD   ,  ");
            sql.append("\n IR.FINAL_RISK_DATE ,IR.FINAL_RISK_LEVEL , ");
            sql.append("\n IR.QUALI_RISK_DATE ,IR.QUALI_RISK_LEVEL , ");
            sql.append("\n IR.QUANTI_RISK_DATE ,IR.QUANTI_RISK_LEVEL ");
//            sql.append("\n IMP.FINAL_RISK_LEVEL AS FINAL_RISK_LEVEL , IMP.QUALI_RESULT AS QUALI_RISK_LEVEL , IMP.FIRST_PD_USE AS  QUANTI_RISK_LEVEL ");
            sql.append("\n FROM  ");
            
            sql.append(getSQLCustomerByCriteria(searchBean));
            
//            sql.append("\n LEFT JOIN TBL_IMPORT_ALL_EWSPROCESS IMP ON IMP.CIF = C.CIF ");
//            sql.append("\n AND IMP.BATCH_DATE = C.BATCH_DATE ");
            
            sql.append("\n LEFT JOIN TBL_MT_KTB_ORGANIZATION O ON C.RESPONSE_UNIT = O.COSTCENTER_CODE ");
            sql.append("\n LEFT JOIN  ");
            sql.append("\n (SELECT A1.* FROM TBL_WARNING_HEADER A1 , ");
            sql.append("\n (SELECT CIF , MAX(WARNING_HEAD_ID) AS WARNING_HEAD_ID_MAX FROM TBL_WARNING_HEADER  GROUP BY CIF) A2 ");
            sql.append("\n WHERE A1.CIF = A2.CIF AND A1.WARNING_HEAD_ID  = A2.WARNING_HEAD_ID_MAX  ");
            sql.append("\n AND  A1.WARNING_DATE <= CURRENT TIMESTAMP ");
          //----- previous 1 year from currentDate
            String startDt = DateUtil.getFirstMonthPeriousOneYear();
            String endDt = DateUtil.getLastDayOfMonth();
            if((!ValidatorUtil.isNullOrEmpty(startDt))&&(!ValidatorUtil.isNullOrEmpty(endDt))){
                  sql.append("  AND ( A1.CREATED_DT BETWEEN TO_DATE('").append(startDt).append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY'))");
            }
           // ---------------------
            sql.append("\n ) H ON  C.CIF = H.CIF ");
            sql.append("\n LEFT JOIN ");
            sql.append("\n (SELECT R1.* FROM TBL_RPT_INDIVIDUAL_RISKLEVEL R1 , ");
            sql.append("\n (SELECT CIF, MAX(CREATED_DT) AS CREATED_DT_MAX FROM TBL_RPT_INDIVIDUAL_RISKLEVEL GROUP BY CIF)R2 ");
            sql.append("\n WHERE R1.CIF = R2.CIF AND R1.CREATED_DT  = R2.CREATED_DT_MAX) IR ON  IR.CIF = H.CIF ");
           //-------------------------------------         
            sql.append("\n WHERE 1=1 ");
             if (BusinessConst.UserRole.AE.equals(searchBean.getRoleId())) { 
                sql.append(" AND C.AE_ID = '").append(searchBean.getRmId().trim()).append("'");
            }
            if (BusinessConst.UserRole.RM.equals(searchBean.getRoleId())) { 
                sql.append(" AND C.RM_ID = '").append(searchBean.getRmId().trim()).append("'");
            }
            if (BusinessConst.UserRole.AO.equals(searchBean.getRoleId())) { 
                sql.append(" AND C.AO_ID = '").append(searchBean.getRmId().trim()).append("'");
            }
            if (BusinessConst.UserRole.BCM.equals(searchBean.getRoleId())) { 
                sql.append(" AND ( C.RESPONSE_UNIT = '").append(searchBean.getResponseUnit().trim()).append("' OR  C.RM_ID = '").append(searchBean.getRmId().trim()).append("' ) ");
            }
            if (BusinessConst.UserRole.SCM.equals(searchBean.getRoleId())) { 
               sql.append(" AND C.RESPONSE_UNIT IN (  SELECT SUB_COSTCENTER_CODE FROM TBL_MT_KTB_ORGANIZATION_CTRL  WHERE COSTCENTER_CODE = '").append(searchBean.getResponseUnit().trim()).append("' )");
            }
            if (BusinessConst.UserRole.VIEWER.equals(searchBean.getRoleId())) {
                sql.append("  AND C.RESPONSE_UNIT IN (  ");
                sql.append(" SELECT distinct(COSTCENTER_CODE)  ");
                sql.append(" FROM TBL_MT_KTB_ORGANIZATION  ");
                sql.append(" WHERE COSTCENTER_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                sql.append(" OR BUSINESSUNIT_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                sql.append(" OR GROUP_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                sql.append(" OR REGION_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                sql.append(" OR DEPARTMENT_CODE = '").append(searchBean.getResponseUnit().trim()).append("' ) ");
            }        
            sql.append("\n )DATA ");
            sql.append("\n  LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM_1 ON DATA.FINAL_RISK_LEVEL = RLM_1.RISK_LEVEL ");
            sql.append("\n LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM_2 ON DATA.QUALI_RISK_LEVEL = RLM_2.RISK_LEVEL ");
            sql.append("\n LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM_3 ON DATA.QUANTI_RISK_LEVEL = RLM_3.RISK_LEVEL ");
//-----------SEARCH -----------//     
             sql.append("\n WHERE 1=1 ");
            //R4 : ถ้าไม่มีการกรอก cifNo, custName ให้ดึงข้อมูล tbl_customer วันที่ batch_date ล่าสุด
            if (ValidatorUtil.isNullOrEmpty(searchBean.getCifNo()) && ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())){
                sql.append("\n AND DATA.MAX_BATCH_DATE = (SELECT max(BATCH_DATE) from TBL_CUSTOMER) ");
            }
            
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo())){
                sql.append(" AND DATA.CIF = '").append(searchBean.getCifNo().trim()).append("' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())){
                sql.append(" AND DATA.CUST_NAME LIKE '%").append(searchBean.getCustomerName().trim()).append("%' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())){
                sql.append(" AND ( DATA.AE_ID = '").append(searchBean.getRmIdOrAeId().trim()).append("' OR DATA.RM_ID = '").append(searchBean.getRmIdOrAeId().trim()).append("' OR DATA.AO_ID = '").append(searchBean.getRmIdOrAeId().trim()).append("') ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())){
                sql.append(" AND  DATA.BUSINESSUNIT_CODE = '").append(searchBean.getWorkLine().trim()).append("' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup())){
                sql.append(" AND  ( DATA.BUSINESSUNIT_CODE = '").append(searchBean.getWorkLine().trim()).append("' AND DATA.GROUP_CODE = '").append(searchBean.getOrganizationGroup().trim()).append("' ) ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup())&&!ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())){
                sql.append(" AND  ( DATA.BUSINESSUNIT_CODE = '").append(searchBean.getWorkLine().trim()).append("' AND DATA.GROUP_CODE = '").append(searchBean.getOrganizationGroup().trim()).append("' AND DATA.COSTCENTER_CODE = '").append(searchBean.getCostCenter().trim()).append("') ");
            } 
  //----------------------------------  
            sql.append("\n ORDER BY BUSINESSUNIT_CODE DESC,GROUP_CODE DESC,COSTCENTER_CODE DESC, ");
            sql.append("\n SORT_DPD DESC,SORT_EWS_RISK_LEVEL DESC ,SORT_QUANTI_RISK_LEVEL DESC ");
          
          
        } catch (Exception e) {
           log.error("Error occur in while process WarningHeaderServiceImpl.getSQLCustomerPortfolioListForPaging: " + e.getMessage(), e);
           throw e;
        }     
      return  sql;
     }
    
    public boolean isNullOrEmptyOrMoreAndEqualZero(Object strParam) {
         boolean result = false;
             if((strParam != null && strParam.toString().length() > 0)){
               int data = Integer.parseInt(strParam.toString());
               if(data > 0){ //DPD <= 0 display blank
                 result = true;
               }else{
                 result = false;
               }
             }
        return result;
    }
    
    @Override
    public ArrayList<CustomerPortfolioVo> getCustomerPortfolioList(SearchBean searchBean) throws Exception {
        ArrayList<CustomerPortfolioVo> customerPortfolioList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("WarningHeaderServiceImpl.getCustomerPortfolioList");
            }

//            StringBuilder sql = getSQLCustomerPortfolioListForPaging(searchBean);
            StringBuilder sql = getSQLIndividualReportList_1(searchBean, null);
            
            if (log.isDebugEnabled()) {
                log.debug("WarningHeaderServiceImpl.getCustomerPortfolioList : "+sql);
            }
           
            if(!ValidatorUtil.isNullOrEmpty(sql.toString())){
            customerPortfolioList = (ArrayList<CustomerPortfolioVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                             CustomerPortfolioVo item = new CustomerPortfolioVo();
                                item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                                item.setCif(rs.getInt("CIF"));
                                item.setWarningDate(rs.getDate("WARNING_DATE"));
                                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                                item.setMaxDpd(rs.getInt("DPD"));
                                 if(isNullOrEmptyOrMoreAndEqualZero(rs.getString("DPD"))){
                                        item.setMaxDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD"), MoneyUtil.patternDPD));
                                    }else{
                                        item.setMaxDpdStrFormat("");
                                    }
                                item.setEwsRiskLevel(StringUtil.getValue(rs.getString("DATA_EWS_RISK_LEVEL")));
                                item.setStatus(StringUtil.getValue(rs.getString("STATUS")));
                                item.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                                item.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                                item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                                item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                                item.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                                item.setAmdResponseUnit(StringUtil.getValue(rs.getString("AMD_RESPONSE_UNIT")));
                                item.setCostcenterName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                                item.setBusinessUnitCode(StringUtil.getValue(rs.getString("BUSINESSUNIT_CODE")));
                                item.setGroupCode(StringUtil.getValue(rs.getString("GROUP_CODE")));
                                item.setCostcenterCode(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                                item.setQuantiBehavModle(StringUtil.getValue(rs.getString("DATA_QUANTI_RISK_LEVEL")));
                                item.setQualitativeAssessment(StringUtil.getValue(rs.getString("DATA_QUALI_RISK_LEVEL")));
                             return item;
                        }
                    });

            }//SQL IS NULL

        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getCustomerPortfolioList: " + e.getMessage(), e);
            throw e;
        }
        return customerPortfolioList;
    }

    @Override
    public Integer countPipelineHaveCoOp(SearchBean searchBean) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("countPipelineHaveCoOp");
        }
        String sql = getSQLPipeline(searchBean);
        if(StringUtil.isNotEmpty(sql)){
        StringBuilder sqlCount = new StringBuilder();
        sqlCount.append("  SELECT COUNT(*) FROM (   ");
        sqlCount.append(sql);
        sqlCount.append("\n   )DATA_SEL  ");
        sqlCount.append("\n  WHERE DATA_SEL.CO_RESPONSE_UNIT IS NOT NULL AND DATA_SEL.CO_RESPONSE_UNIT > 0");
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sqlCount.toString());
        }
        return jdbcTemplate.queryForObject(sqlCount.toString(), new Object[]{}, Integer.class);
        }
        return null;
    }

    @Override
    public List<CustomerPortfolioVo> getCustomerPortfolioList(SearchBean searchBean, String breakBy) throws Exception {
        List<CustomerPortfolioVo> resultList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("WarningHeaderServiceImpl.getCustomerPortfolioList");
            }
            
            StringBuilder sql = getSQLIndividualReportList_1(searchBean , breakBy);//getSQLIndividualReportList(searchBean , breakBy);
            
            if (log.isDebugEnabled()) {
                log.debug("WarningHeaderServiceImpl.getCustomerPortfolioList : "+sql);
            }
            
            if(!ValidatorUtil.isNullOrEmpty(sql.toString())){
            resultList = (ArrayList<CustomerPortfolioVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CustomerPortfolioVo item = new CustomerPortfolioVo();
                    item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                    item.setCif(rs.getInt("CIF"));
                    item.setWarningDate(rs.getDate("WARNING_DATE"));
                    item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
//                    item.setCreditReviewFlag(StringUtil.getValue(rs.getString("CR_FLAG")));
                    item.setMaxDpd(rs.getInt("DPD"));
                     if(isNullOrEmptyOrMoreAndEqualZero(rs.getString("DPD"))){
                            item.setMaxDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD"), MoneyUtil.patternDPD));
                        }else{
                            item.setMaxDpdStrFormat("");
                        }
                    item.setEwsRiskLevel(StringUtil.getValue(rs.getString("DATA_EWS_RISK_LEVEL")));
                    //item.setEwsRiskLevel(DisplayUtil.getRiskLevelForDisplay(rs.getString("EWS_RISK_LEVEL")));
                    item.setStatus(StringUtil.getValue(rs.getString("STATUS")));
                    item.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                    item.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                    item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                    item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                    item.setAmdResponseUnit(StringUtil.getValue(rs.getString("AMD_RESPONSE_UNIT")));
                    item.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                    item.setCostcenterName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    item.setBusinessUnitCode(StringUtil.getValue(rs.getString("BUSINESSUNIT_CODE")));
                    item.setGroupCode(StringUtil.getValue(rs.getString("GROUP_CODE")));
                    item.setCostcenterCode(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setQuantiBehavModle(StringUtil.getValue(rs.getString("DATA_QUANTI_RISK_LEVEL")));
                    item.setQualitativeAssessment(StringUtil.getValue(rs.getString("DATA_QUALI_RISK_LEVEL")));
                    //item.setQuantiBehavModle(DisplayUtil.getRiskLevelForDisplay(rs.getString("QUANTI_RISK_LEVEL")));
                    //item.setQualitativeAssessment(DisplayUtil.getRiskLevelForDisplay(rs.getString("QUALI_RISK_LEVEL")));
                    return item;
                }});
           }
        } catch (Exception e) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getTaskListWithTrackingHistory: " + e.getMessage(), e);
            throw e;
        }
        return resultList;
    }
    
    public Date findMaxDateHistory(String cif , String customerName) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findMaxDateHistory");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT MAX(DATETIME) AS MAX_DATE FROM TBL_CUSTOMER_HISTORY WHERE BUSINESS_SIZE  IN ('L') ");
      
        if(!ValidatorUtil.isNullOrEmpty(cif)){
            sql.append(" AND CIF = '").append(cif.trim()).append("' ");
        }
        if (!ValidatorUtil.isNullOrEmpty(customerName)){
            sql.append(" AND CUST_NAME LIKE '%").append(customerName.trim()).append("%' ");
        }
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        Date lastedDate = jdbcTemplate.queryForObject(sql.toString(), new Object[]{}, Date.class);

        if (log.isDebugEnabled()) {
            log.debug("lastedDate >>> " + lastedDate);
        }
        return lastedDate;
    }
    
    private StringBuilder getSQLIndividualReportList_1(SearchBean searchBean, String breakBy) throws Exception {
        
        StringBuilder sql = new StringBuilder();
        
        try {
                sql.append(" SELECT DATA.WARNING_HEAD_ID AS WARNING_HEAD_ID , DATA.CIF AS CIF , DATA.WARNING_DATE AS WARNING_DATE , ");
                sql.append("\n DATA.STATUS AS STATUS , DATA.DPD AS DPD , ");
                // sql.append("\n DATA.CR_FLAG AS CR_FLAG , ");
                sql.append("\n DATA.CUST_NAME  AS CUST_NAME ,DATA.RM_ID AS RM_ID,DATA.AE_ID AS AE_ID, ");
                sql.append("\n DATA.AO_ID AS AO_ID, DATA.AMD_RESPONSE_UNIT AS AMD_RESPONSE_UNIT ,");
                sql.append("\n DATA.MAX_BATCH_DATE,");
                sql.append("\n DATA.RESPONSE_UNIT AS RESPONSE_UNIT ,DATA.COSTCENTER_NAME AS COSTCENTER_NAME,DATA.BUSINESSUNIT_CODE AS BUSINESSUNIT_CODE , ");
                sql.append("\n DATA.GROUP_CODE AS GROUP_CODE ,DATA.COSTCENTER_CODE AS COSTCENTER_CODE ,RLM_1.ORDER_SEQ AS SORT_EWS_RISK_LEVEL , ");
                sql.append("\n RLM_1.RISK_LEVEL_IND_RPT_DISP AS DATA_EWS_RISK_LEVEL , RLM_2.ORDER_SEQ  AS SORT_QUALI_RISK_LEVEL , ");
                sql.append("\n RLM_2.RISK_LEVEL_IND_RPT_DISP AS DATA_QUALI_RISK_LEVEL ,RLM_3.ORDER_SEQ  AS SORT_QUANTI_RISK_LEVEL , ");
                sql.append("\n RLM_3.RISK_LEVEL_IND_RPT_DISP AS DATA_QUANTI_RISK_LEVEL, ");
                sql.append("\n CASE ");
                sql.append("\n        WHEN DATA.DPD <= 0 OR DATA.DPD   IS NULL ");
                sql.append("\n        THEN 0 ");
                sql.append("\n        ELSE DATA.DPD ");
                sql.append("\n  END AS SORT_DPD ");
                sql.append("\n FROM ( ");
                sql.append("\n SELECT  C.CUST_NAME   , C.RM_ID ,  C.AE_ID  ,   C.RESPONSE_UNIT  , ");
                sql.append("\n C.AO_ID  ,   C.AMD_RESPONSE_UNIT, ");
                sql.append("\n C.MAX_BATCH_DATE, ");
                sql.append("\n O.COSTCENTER_NAME  ,  O.BUSINESSUNIT_CODE  , O.GROUP_CODE  , O.COSTCENTER_CODE , ");
                sql.append("\n H.WARNING_HEAD_ID ,  C.CIF   ,  H.WARNING_DATE  ,   H.STATUS  ,   H.DPD   , ");
                // sql.append("\n H.CR_FLAG , ");
                sql.append("\n IR.FINAL_RISK_DATE ,IR.FINAL_RISK_LEVEL ,IR.FINAL_RISK_UPDATE_FLAG , ");
                sql.append("\n IR.QUALI_RISK_DATE ,IR.QUALI_RISK_LEVEL ,IR.QUALI_RISK_UPDATE_FLAG , ");
                sql.append("\n IR.QUANTI_RISK_DATE ,IR.QUANTI_RISK_LEVEL ,IR.QUANTI_RISK_UPDATE_FLAG ");
//                sql.append("\n IMP.FINAL_RISK_LEVEL AS FINAL_RISK_LEVEL , IMP.QUALI_RESULT AS QUALI_RISK_LEVEL , IMP.FIRST_PD_USE AS  QUANTI_RISK_LEVEL ");
                sql.append("\n FROM  ");

                sql.append(getSQLCustomerByCriteria(searchBean));
                
//                sql.append("\n LEFT JOIN TBL_IMPORT_ALL_EWSPROCESS IMP ");
//                sql.append("\n ON IMP.CIF = C.CIF ");
//                sql.append("\n AND IMP.BATCH_DATE = C.BATCH_DATE ");
                
                sql.append("\n LEFT JOIN TBL_MT_KTB_ORGANIZATION O ON C.RESPONSE_UNIT = O.COSTCENTER_CODE ");
                sql.append("\n LEFT JOIN  ");
                sql.append("\n (SELECT A1.* FROM TBL_WARNING_HEADER A1 , ");
                sql.append("\n (SELECT CIF , MAX(WARNING_HEAD_ID) AS WARNING_HEAD_ID_MAX FROM TBL_WARNING_HEADER  GROUP BY CIF) A2 ");
                sql.append("\n WHERE A1.CIF = A2.CIF AND A1.WARNING_HEAD_ID  = A2.WARNING_HEAD_ID_MAX  ");
                sql.append("\n AND  A1.WARNING_DATE <= CURRENT TIMESTAMP ");
                // ----- previous 1 year from currentDate
                String startDt = DateUtil.getFirstMonthPeriousOneYear();
                String endDt = DateUtil.getLastDayOfMonth();
                if ((!ValidatorUtil.isNullOrEmpty(startDt)) && (!ValidatorUtil.isNullOrEmpty(endDt))) {
                        sql.append("  AND ( A1.CREATED_DT BETWEEN TO_DATE('").append(startDt)
                           .append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY'))");
                }
                // ---------------------
                sql.append("\n ) H ON  C.CIF = H.CIF ");
                sql.append("\n LEFT JOIN ");
                sql.append("\n (SELECT R1.* FROM TBL_RPT_INDIVIDUAL_RISKLEVEL R1 , ");
                sql.append("\n (SELECT CIF, MAX(CREATED_DT) AS CREATED_DT_MAX FROM TBL_RPT_INDIVIDUAL_RISKLEVEL GROUP BY CIF)R2 ");
                sql.append("\n WHERE R1.CIF = R2.CIF AND R1.CREATED_DT  = R2.CREATED_DT_MAX) IR ON C.CIF = IR.CIF  ");
                // -------------------------------------
                sql.append("\n WHERE 1=1 ");
                if (BusinessConst.UserRole.AE.equals(searchBean.getRoleId())) {
                        sql.append(" AND C.AE_ID = '").append(searchBean.getRmId().trim()).append("'");
                }
                if (BusinessConst.UserRole.RM.equals(searchBean.getRoleId())) {
                        sql.append(" AND C.RM_ID = '").append(searchBean.getRmId().trim()).append("'");
                }
                if (BusinessConst.UserRole.AO.equals(searchBean.getRoleId())) {
                        sql.append(" AND C.AO_ID = '").append(searchBean.getRmId().trim()).append("'");
                }
                if (BusinessConst.UserRole.BCM.equals(searchBean.getRoleId())) {
                        sql.append(" AND ( C.RESPONSE_UNIT = '").append(searchBean.getResponseUnit().trim())
                                        .append("' OR  C.RM_ID = '").append(searchBean.getRmId().trim()).append("' OR  C.AO_ID = '")
                                        .append(searchBean.getRmId().trim()).append("' ) ");
                }
                if (BusinessConst.UserRole.SCM.equals(searchBean.getRoleId())) {
                        sql.append(" AND C.RESPONSE_UNIT IN (  SELECT SUB_COSTCENTER_CODE FROM TBL_MT_KTB_ORGANIZATION_CTRL  WHERE COSTCENTER_CODE = '")
                           .append(searchBean.getResponseUnit().trim()).append("' )");
                }
                if (BusinessConst.UserRole.VIEWER.equals(searchBean.getRoleId())) {
                        sql.append("  AND C.RESPONSE_UNIT IN (  ");
                        sql.append(" SELECT distinct(COSTCENTER_CODE)  ");
                        sql.append(" FROM TBL_MT_KTB_ORGANIZATION  ");
                        sql.append(" WHERE COSTCENTER_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                        sql.append(" OR BUSINESSUNIT_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                        sql.append(" OR GROUP_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                        sql.append(" OR REGION_CODE = '").append(searchBean.getResponseUnit().trim()).append("'  ");
                        sql.append(" OR DEPARTMENT_CODE = '").append(searchBean.getResponseUnit().trim()).append("' ) ");
                }else if (BusinessConst.UserRole.AMD.equals(searchBean.getRoleId())) {
                    sql.append("\n  AND C.RESPONSE_UNIT  IN (  ");
                    sql.append("\n select COSTCENTER_CODE");
                    sql.append("\n FROM TBL_MT_AMD_COSTCENTER_MAPPING  ");
                    sql.append("\n WHERE DEPARTMENT_CODE = '").append(searchBean.getResponseUnit().trim()).append("'");
                    sql.append("\n group by COSTCENTER_CODE)");
                } 
                sql.append("\n )DATA  ");
                
				sql.append("\n  LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM_1 ON DATA.FINAL_RISK_LEVEL = RLM_1.RISK_LEVEL ");
				sql.append("\n LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM_2 ON DATA.QUALI_RISK_LEVEL = RLM_2.RISK_LEVEL ");
				sql.append("\n LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM_3 ON DATA.QUANTI_RISK_LEVEL = RLM_3.RISK_LEVEL ");
					
                // -----------SEARCH -----------//
                sql.append("\n WHERE 1=1 ");
                
                //R4 : ถ้าไม่มีการกรอก cifNo, custName ให้ดึงข้อมูล tbl_customer วันที่ batch_date ล่าสุด
                if (ValidatorUtil.isNullOrEmpty(searchBean.getCifNo()) && ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())){
                    sql.append("\n AND DATA.MAX_BATCH_DATE = (SELECT max(BATCH_DATE) from TBL_CUSTOMER) ");
                }
                        
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo())) {
                        sql.append(" AND DATA.CIF = '").append(searchBean.getCifNo().trim()).append("' ");
                }
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())) {
                        sql.append(" AND DATA.CUST_NAME LIKE '%").append(searchBean.getCustomerName().trim()).append("%' ");
                }
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getRmIdOrAeId())) {
                        sql.append(" AND ( DATA.AE_ID = '").append(searchBean.getRmIdOrAeId().trim())
                            .append("' OR DATA.RM_ID = '").append(searchBean.getRmIdOrAeId().trim())
                            .append("' OR DATA.AO_ID = '").append(searchBean.getRmIdOrAeId().trim()).append("') ");
                }
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())) {
                        sql.append(" AND  DATA.BUSINESSUNIT_CODE = '").append(searchBean.getWorkLine().trim()).append("' ");
                }
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())
                                && !ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup())) {
                        sql.append(" AND  ( DATA.BUSINESSUNIT_CODE = '").append(searchBean.getWorkLine().trim())
                            .append("' AND DATA.GROUP_CODE = '").append(searchBean.getOrganizationGroup().trim())
                            .append("' ) ");
                }
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getWorkLine())
                                && !ValidatorUtil.isNullOrEmpty(searchBean.getOrganizationGroup())
                                && !ValidatorUtil.isNullOrEmpty(searchBean.getCostCenter())) {
                        sql.append(" AND  ( DATA.BUSINESSUNIT_CODE = '").append(searchBean.getWorkLine().trim())
                            .append("' AND DATA.GROUP_CODE = '").append(searchBean.getOrganizationGroup().trim())
                            .append("' AND DATA.COSTCENTER_CODE = '").append(searchBean.getCostCenter().trim())
                            .append("') ");
                }
                /// --------- Order
                if ((breakBy != null) && (BusinessConst.BREAK_BY.DATA_NO_WORKLINE.equals(breakBy))) {
                        sql.append(" ORDER BY SORT_DPD DESC, SORT_EWS_RISK_LEVEL DESC , SORT_QUANTI_RISK_LEVEL DESC ");
                } else if ((breakBy != null) && (BusinessConst.BREAK_BY.HAVE_GROUP_CODE.equals(breakBy))) {
                        sql.append(" ORDER BY BUSINESSUNIT_CODE DESC, GROUP_CODE DESC, SORT_DPD DESC, SORT_EWS_RISK_LEVEL DESC , SORT_QUANTI_RISK_LEVEL DESC ");
                } else if ((breakBy != null) && (BusinessConst.BREAK_BY.HAVE_DEPARTMENT.equals(breakBy)))  { // Break by Department
                        sql.append(" ORDER BY BUSINESSUNIT_CODE DESC, GROUP_CODE DESC,COSTCENTER_CODE DESC, SORT_DPD DESC, SORT_EWS_RISK_LEVEL DESC , SORT_QUANTI_RISK_LEVEL DESC ");
                }else{
                	sql.append("\n ORDER BY BUSINESSUNIT_CODE DESC,GROUP_CODE DESC,COSTCENTER_CODE DESC, ");
                    sql.append("\n SORT_DPD DESC,SORT_EWS_RISK_LEVEL DESC ,SORT_QUANTI_RISK_LEVEL DESC ");
                }

        } catch (Exception e) {
                log.error("Error occur in while process WarningHeaderServiceImpl.getSQLIndividualReportList_1: "
                                + e.getMessage(), e);
                throw e;
        }
        return sql;
    }

    @Override
    public String getMaxBatchDate(SearchBean searchBean) throws Exception {
            if (log.isInfoEnabled()) {
                    log.info("getMaxBatchDate");
            }

            String maxBatchDateStr = "";

            /*
             * Build SQL for query max batch date from tbl_customer_history by check cif and
             * customer name condition.
             */
            // ถ้ามี maxDateStr ส่งมาให้ query จาก tbl_customer_history
            try {
//                    StringBuilder r = getSQLCustomerPortfolioListForPaging(searchBean);
            		StringBuilder r = getSQLIndividualReportList_1(searchBean,null);
                    StringBuilder sql = new StringBuilder();

                    sql.append("select max(MAX_BATCH_DATE) MAX_BATCH_DATE from (");
                    sql.append(r);
                    sql.append(") ttt");
                    
                    if (!ValidatorUtil.isNullOrEmpty(sql)) {
                        if (log.isDebugEnabled()) {
                            log.debug("SQL >>> " + sql.toString());
                        }

                        ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {

                            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return ValidatorUtil.isNullOrEmpty(rs.getDate("MAX_BATCH_DATE")) ? "" : DateUtil.format(rs.getDate("MAX_BATCH_DATE"));
                            }
                        });
                        if (result != null && result.size() > 0) {
                            if (log.isDebugEnabled()) {
                                log.debug("maxBatchDateStr >>> " + result.get(0));
                            }
                            return result.get(0);
                        }
                    }
            } catch (Exception e) {
                    log.error("Error occur in while process IndividualReportServiceImpl.getLastBatchDate: " + e.getMessage(),
                                    e);
            }

            return maxBatchDateStr;
    }
    private String getCustomerHistoryMaxBatchDate(SearchBean searchBean) throws Exception {
        String custHistMaxBatchDate = null;
        try {
                StringBuilder sql = new StringBuilder();

                sql.append("SELECT MAX(BATCH_DATE) BATCH_DATE FROM TBL_CUSTOMER_HISTORY ");
                sql.append("\n WHERE BUSINESS_SIZE in ('L') ");
                
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo())) {
                    sql.append(" AND CIF = '").append(searchBean.getCifNo().trim()).append("' ");
                }
                if (!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())) {
                    sql.append(" AND CUST_NAME LIKE '%").append(searchBean.getCustomerName().trim()).append("%' ");
                }
                
                if (!ValidatorUtil.isNullOrEmpty(sql)) {
                    if (log.isDebugEnabled()) {
                        log.debug("SQL >>> " + sql.toString());
                    }
                    
                    ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {

                        public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                            return ValidatorUtil.isNullOrEmpty(rs.getDate("BATCH_DATE")) ? "" : DateUtil.format(rs.getDate("BATCH_DATE"));
                        }
                    });
                    if (result != null && result.size() > 0) {
                        return result.get(0);
                    }
                    
                    if (log.isDebugEnabled()) {
                        log.debug(" custHistMaxBatchDate >>" + custHistMaxBatchDate );
                    }
                    
                }
                
        } catch (Exception e) {
                log.error("Error occur in while process WarningHeaderServiceImpl.getLastBatchDate: " + e.getMessage(), e);
        }
        return custHistMaxBatchDate;
    }
    
    public StringBuilder getSQLCustomerHistory(SearchBean searchBean){
        StringBuilder sql = new StringBuilder();
        try {
            String maxBatchDate = getCustomerHistoryMaxBatchDate(searchBean);
            sql.append("\n (SELECT H.*,H.BATCH_DATE AS MAX_BATCH_DATE FROM TBL_CUSTOMER_HISTORY H");
            
            //แก้เรื่องดึง max batch date จาก TBL_CUSTOMER_SIZE_HISTORY
//            sql.append("\n (SELECT H.*,S.BATCH_DATE AS MAX_BATCH_DATE FROM TBL_CUSTOMER_HISTORY H");
//            sql.append("\n LEFT JOIN TBL_CUSTOMER_SIZE_HISTORY S ON H.CIF = S.CIF AND H.BUSINESS_SIZE = S.BUSINESS_SIZE ");
            
            sql.append("\n WHERE H.BUSINESS_SIZE = 'L' ");
            if(ValidatorUtil.isNullOrEmpty(maxBatchDate)){
                sql.append("\n AND (H.BATCH_DATE) is not null ");
            }else{
                sql.append("\n AND (H.BATCH_DATE) = TO_DATE('").append(maxBatchDate).append("','DD/MM/YYYY') ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo())) {
                sql.append(" AND H.CIF = '").append(searchBean.getCifNo().trim()).append("' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())) {
                sql.append(" AND H.CUST_NAME LIKE '%").append(searchBean.getCustomerName().trim()).append("%' ");
            }
            sql.append("\n ) C ");
            
        } catch (Exception ex) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getSQLCustomerHistory: " + ex.getMessage(), ex);
        }
        return sql;
    }
    
    public StringBuilder getSQLCustomerByCriteria(SearchBean searchBean){
        
        StringBuilder sqlCustomer = new StringBuilder();
        
        try {
             
            if (ValidatorUtil.isNullOrEmpty(searchBean.getCifNo()) && ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())) {
                //กรณีที่ไม่ได้ระบุ cif, ชื่อลูกค้า
                sqlCustomer.append("\n (SELECT CUST.*, CUST.BATCH_DATE AS MAX_BATCH_DATE FROM  TBL_CUSTOMER CUST WHERE BUSINESS_SIZE in ('L')) C ");
                
            }else {
                //กรณีที่ระบุ cif หรือ ชื่อลูกค้า ให้หาที่ tbl_customer ก่อน ถ้าไม่มีให้หาที่ tbl_customer_history
                if(existsCustomerData(searchBean)){
                    sqlCustomer.append("\n (SELECT CUST.*, CUST.BATCH_DATE AS MAX_BATCH_DATE FROM  TBL_CUSTOMER CUST WHERE BUSINESS_SIZE in ('L')) C ");
                }else{
                    sqlCustomer = getSQLCustomerHistory(searchBean);
                }
            }
            
        } catch (Exception ex) {
            log.error("Error occur in while process WarningHeaderServiceImpl.getSQLCustomerByCriteria: " + ex.getMessage(), ex);
        }
        return sqlCustomer;
    }
    
    private Boolean existsCustomerData(SearchBean searchBean) {

        List<Object> params = new ArrayList<Object>();

        StringBuilder sql = new StringBuilder();
        sql.append("select count(*) FROM TBL_CUSTOMER WHERE business_size in ('L') ");
        if (!ValidatorUtil.isNullOrEmpty(searchBean.getCifNo().trim())) {
                sql.append(" AND CIF = ? ");
                params.add(searchBean.getCifNo().trim());
        }
        if (!ValidatorUtil.isNullOrEmpty(searchBean.getCustomerName())) {
                sql.append(" AND CUST_NAME LIKE ? ");
                params.add("%"+searchBean.getCustomerName()+"%");
        }

        Long count = jdbcTemplate.queryForObject(sql.toString(), params.toArray(),Long.class);

        return count>0;
    }
}
