/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class CRCustReviewEwsServicesImpl implements CRCustReviewEwsServices {
    
    @Autowired
    public JdbcTemplate jdbcTemplate;
    
    private static Logger logger = Logger.getLogger(CRCustReviewEwsServicesImpl.class);

    @Override
    public String getLoanGrpProd(String prodGroup, String acctSubType, String marketCode) throws Exception {
        StringBuilder sql = null;
        try{
            sql = new StringBuilder();
            
            sql.append(" SELECT LOAN_GROUP_PROD ");
            sql.append(" FROM TBL_MT_LOAN_GROUP_MAPPING ");
            sql.append(" WHERE PRODUCT_GROUP_CD      = '" + prodGroup + "' ");
            sql.append(" AND ACCOUNT_SUB_TYPE    = '" + acctSubType + "' ");
            sql.append(" AND MARKET_CD           = '" + marketCode + "'  ");

            if (logger.isDebugEnabled()) {
                logger.debug(sql.toString());
            }

            ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {

                public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getString("LOAN_GROUP_PROD");
                }
            });
            if (result != null && result.size() > 0) {
                return result.get(0);
            }
        }catch(Exception e){
            throw e;
        }
        return null;
    }

    @Override
    public String getLoanGrpProd(String prodGroup, String acctSubType) throws Exception {
        StringBuilder sql = new StringBuilder();

        sql.append(" SELECT DISTINCT SME.LOAN_GRP_PROD ");
        sql.append(" FROM TBL_MT_MARKET_CODE MKT ");
        sql.append(" INNER JOIN TBL_CL_LOAN_GRP_SME_TEMP SME ON MKT.MARKET_CD = SME.LOAN_TP_ID ");
        sql.append(" WHERE MKT.PRODUCT_GROUP_CD = '" + prodGroup + "' ");
        sql.append(" AND MKT.ACCOUNT_SUB_TYPE = '" + acctSubType + "' ");

        if (logger.isDebugEnabled()) {
            logger.debug(sql.toString());
        }

        ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {

            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("LOAN_GRP_PROD");
            }
        });
        if (result != null && result.size() > 0) {
            return result.get(0);
        }
        return null;
    }

    @Override
    public String getLoanGrpProd(String marketCode) throws Exception {
        StringBuilder sql = new StringBuilder();

        sql.append(" SELECT LOAN_GRP_PROD ");
        sql.append(" FROM TBL_CL_LOAN_GRP_SME_TEMP ");
        sql.append(" WHERE LOAN_TP_ID = '" + marketCode + "' ");
        
        if (logger.isDebugEnabled()) {
            logger.debug(sql.toString());
        }
        
        ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("LOAN_GRP_PROD");
            }
        });
        if (result != null && result.size() > 0) {
            return result.get(0);
        }
        return null;
    }
}
