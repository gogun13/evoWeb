/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.MtWayOutFormVo;
import java.util.ArrayList;

/**
 *
 * @author Pratya
 */
public interface MtWayOutFormService {
    public ArrayList<MtWayOutFormVo> getQuestionList () throws Exception;
}
