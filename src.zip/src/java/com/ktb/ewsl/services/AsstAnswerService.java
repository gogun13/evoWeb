/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AsstAnswerVo;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public interface AsstAnswerService {
    public void saveQuestion(AsstAnswerVo asstAnswerVo) throws Exception;  //--- EWS-L
    public void updateQuestion(AsstAnswerVo asstAnswerVo,List<String> roleList) throws Exception; //--- EWS-L
    public List<AsstAnswerVo> findAsstAnswerByPK(AsstAnswerVo filter) throws Exception; //--- EWS-L
    public List<AsstAnswerVo> findAsstAnswerByWarningIdAndQuestId(int warningId, String questionId) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerForGenTrigger(int warningId,String version) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerForSendData(AsstAnswerVo filter) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerByRole(String role, String version, int warningId, String questionId) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerByWarningId(int warningId) throws Exception;
    public List<AsstAnswerVo> findAnswerByWarningIdInCurrentDate(int warningId) throws Exception;
    
    public String getLastVersionAnswerOfWarningId(int warningId)throws Exception;
    public List<AsstAnswerVo> findAsstAnswer(int warningId, String questionId , String questionVersion) throws Exception;
    public String findAnswerVersionByWarningIdAndQuestionId(int warningId , String questionId)throws Exception;
    public void deleteAnswerByWarningId(String warningIdAll) throws Exception; 
    public List<AsstAnswerVo> findAsstAnswerForSendDataByRole(AsstAnswerVo filter , String roleCode) throws Exception ;
    public void deleteAnswerByPK(AsstAnswerVo filter, String roleCode) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerByPKAndManyRole(AsstAnswerVo filter , String roleCode) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerByHeaderIdForSendBackQuali(AsstAnswerVo filter , String roleCode) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerByHeaderIdForTrigger(AsstAnswerVo filter , String roleCode) throws Exception;
    public void deleteAnswerByHeaderIdAndRoleCode(int warningHeaderId, String roleCode) throws Exception;
    public void deleteAnswerByWarningIdAndRoleCode(String warningIdAll,String roleCode) throws Exception;
    public List<AsstAnswerVo> findAsstAnswerByWarningIdAndRoleCode(int warningId, String roleCode) throws Exception;
    public void deleteAnswerByWarningIdAndWarningheadId(String warningHeadId, String warningId) throws Exception;
    public void deleteAnswerQualiByWarningIdAndOtherRoleCode(int warningIdQuali,String roleCode) throws Exception;
    
    
}
