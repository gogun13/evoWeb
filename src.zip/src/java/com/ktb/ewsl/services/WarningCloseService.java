
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningCloseVo;
import java.util.ArrayList;

/**
 *
 * @author pumin
 */
public interface WarningCloseService {
    public ArrayList<WarningCloseVo> getWarningClose(String warningHeadId)throws Exception;
    public void insertWarningClose(WarningCloseVo vo) throws Exception;
    public String getReasonFlg(String warningHeadId) throws Exception;
    public String getStatusByMaxCreatedDt(String warningHeadId) throws Exception;
    
}
