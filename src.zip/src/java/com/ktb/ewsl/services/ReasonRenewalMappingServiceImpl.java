/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ReasonRenewalMappingVo;
import com.ktbcs.core.utilities.StringUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class ReasonRenewalMappingServiceImpl implements ReasonRenewalMappingService{

    private static final Logger logger = Logger.getLogger(ReasonRenewalMappingServiceImpl.class);
     
    @Autowired
    private JdbcTemplate jdbcTemplate;

    
    @Override
    public String getTypeFlg(String reasonRenewalScore) throws Exception {
         if (logger.isInfoEnabled()) {
            logger.info("ReasonRenewalMappingServiceImpl.getTypeFlg");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT TYPES_FLG FROM TBL_MT_REASON_RENEWAL_MAPPING ");
        sql.append("\n WHERE REASON_RENEWAL_SAS = ?  ");
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{reasonRenewalScore}, String.class);
    }

    @Override
    public ReasonRenewalMappingVo getObjectReasonRenewalMapping(String reasonRenewalScore) throws Exception {
      ReasonRenewalMappingVo resultVo = new ReasonRenewalMappingVo();
      StringBuilder sql = new StringBuilder();
      try{
        sql.append(" SELECT REASON_RENEWAL_SAS,REASON_RENEWAL_SCORE,TYPES_FLG FROM TBL_MT_REASON_RENEWAL_MAPPING ");
        sql.append("\n WHERE REASON_RENEWAL_SCORE = ? ");

        ArrayList<ReasonRenewalMappingVo> resultList = (ArrayList<ReasonRenewalMappingVo>) jdbcTemplate.query(sql.toString(),new Object[]{reasonRenewalScore},  new RowMapper() {
            public ReasonRenewalMappingVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                ReasonRenewalMappingVo item = new ReasonRenewalMappingVo();
                item.setReasonRenewalSAS(StringUtil.getValue(rs.getString("REASON_RENEWAL_SAS")));
                item.setReasonRenewScore(StringUtil.getValue(rs.getString("REASON_RENEWAL_SCORE")));
                item.setTypesFlg(StringUtil.getValue(rs.getString("TYPES_FLG")));
                return item;
            }
        });

        if (!resultList.isEmpty() && resultList.size() > 0) {
            resultVo = (ReasonRenewalMappingVo) resultList.get(0);
        }
       }catch(Exception e){
         logger.error("Error occur in while process ReasonRenewalMappingServiceImpl.getObjectReasonRenewalMapping : ", e);
       }
      return resultVo;
    }
    
}
