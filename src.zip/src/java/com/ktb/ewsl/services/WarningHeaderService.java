/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.CustomerPortfolioVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningHeaderService {
    
     public PaginatedListImpl getPipeline(PaginatedListImpl paginate, SearchBean searchBean , int pageAmt ) throws Exception;
     public void updateAction1Flg(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
     public void updateAction2Flg(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
     public void updateStatusWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception;
     public WarningHeaderVo findWarningHeaderByPK(int warningHeaderId) throws Exception;
     public void updateFlagInWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception;
//     public void updateWayOutFlg(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
     public Integer findWarningInfoALLNewOrBlank(int warningHeaderId) throws Exception;
     public WarningHeaderVo findWarningHeaderObject(int warningHeaderId , String cifNo) throws Exception ;
     public List<QuestionHistoryVo> findWarningIdForQuestion(String cif,String warningType) throws Exception;
     public void updateStatusWarningHeaderAndFinFlag(WarningHeaderVo warningHeaderVo) throws Exception;
     public void updateStatusAndFlagInWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception;
     public void updateCrAcctCnt(WarningHeaderVo warningHeaderVo) throws Exception;
     public WarningHeaderVo findWarningHeaderObjectOriginal(int warningHeaderId , String cifNo) throws Exception ; //--ANN
     public Integer checkDataBeforeCloseOutOfPipeline(int warningHeaderId) throws Exception;
     public int updateStateAfterCheckDataBeforeCloseOutOfPipeline(String updateBy , int warningHeaderId) throws Exception;
     public void updateResultTrigger(WarningHeaderVo warningHeaderVo) throws Exception;
     public int updateForApprove(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
     public void updateCrFlg(WarningHeaderVo warningHeaderVo) throws Exception;//Add By Pound
     public int getWarningHeaderIdbyCif(String cif) throws Exception;//Add By Pound
     public int updateForApproveForCloaseByCif(WarningHeaderVo warningHeaderVo) throws Exception;
     public int countForCloseByCif(int warningHeaderId) throws Exception;
     public void updateAction1FlgAndLatePayMentFlg(WarningHeaderVo warningHeaderVo) throws Exception;
     public WarningHeaderVo findWarningHeaderObjectOriginalFromWarningId(int warningId) throws Exception ; //--ANN
     //R1.3
     public List<QuestionHistoryVo> findWarningIdForHistory(String cif, String warningType) throws Exception;
     public PaginatedListImpl getCustomerPortfolioListForPaging(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception;
     public ArrayList<CustomerPortfolioVo> getCustomerPortfolioList(SearchBean searchBean) throws Exception;
     //R3.1
     public Integer countPipelineHaveCoOp(SearchBean searchBean) throws Exception;
      //R4
     public List<CustomerPortfolioVo> getCustomerPortfolioList(SearchBean searchBean , String breakBy) throws Exception; 
     public String getMaxBatchDate(SearchBean searchBean) throws Exception;
}
