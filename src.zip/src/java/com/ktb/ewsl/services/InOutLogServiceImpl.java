/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.InOutLogVo;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class InOutLogServiceImpl implements InOutLogService{

     private static final Logger log = Logger.getLogger(InOutLogServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void insertInOutLog(InOutLogVo inOutLogVo) throws Exception {
        try {
            if (log.isInfoEnabled()) {
                log.info("InOutLogServiceImpl.insertInOutLog");
            }
            
            StringBuilder sql = new StringBuilder();
            
            sql.append(" INSERT INTO TBL_INOUT_LOG(SESSION_ID, USER_ID, USER_NAME, POS_CODE, POS_NAME, DEP_CODE, DEP_NAME, USER_IP, SERVER_IP, LOG_IN_STATUS, LOG_IN_STATUS_DESC, LOG_OUT_STATUS, LOG_OUT_STATUS_DESC, UPDATE_DATE, UPDATE_BY, LOGIN_DATE, LOGOUT_DATE)  ");
            sql.append(" \n   VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?) ");
            
            jdbcTemplate.update(sql.toString(), new Object[]{inOutLogVo.getSessionId(),inOutLogVo.getUserId(), inOutLogVo.getUserName(), inOutLogVo.getPosCode(),inOutLogVo.getPosName(),
                inOutLogVo.getDepCode(),inOutLogVo.getDepName(),inOutLogVo.getUserIP(),inOutLogVo.getServerIP(),inOutLogVo.getLoginStatus(),
                inOutLogVo.getLoginStatusDesc(),inOutLogVo.getLogoutStatus(),inOutLogVo.getLogoutStatusDesc(),inOutLogVo.getUpdatedDate(),inOutLogVo.getUpdatedBy(),
                inOutLogVo.getLoginDate(),inOutLogVo.getLogoutDate()});
        } catch (Exception e) {
            log.error("Error occur in while process InOutLogServiceImpl.insertInOutLog : " + e.getMessage(), e);
            throw e;
        }
    }
    
    @Override
    public void updateLogout(InOutLogVo inOutLogVo) throws Exception {
         try {
            if (log.isInfoEnabled()) {
                log.info("InOutLogServiceImpl.updateLogout");
                log.info(" getLogoutStatus =" + inOutLogVo.getLogoutStatus());
                log.info(" getLogoutStatusDesc = " + inOutLogVo.getLogoutStatusDesc());
                log.info(" getUpdatedBy = " + inOutLogVo.getUpdatedBy());
                log.info(" getUserId = " + inOutLogVo.getUserId());
                log.info(" getUserIP = " + inOutLogVo.getUserIP());
                log.info(" getServerIP = " + inOutLogVo.getServerIP());
                log.info(" getSessionId = " + inOutLogVo.getSessionId());
            }
            
            StringBuilder sqlfield = new StringBuilder();
            if (inOutLogVo.getUserIP() != null && inOutLogVo.getUserIP().trim().length() > 0) {
                  sqlfield.append("  AND USER_IP = '").append(inOutLogVo.getUserIP()).append("'");
            } 
            if (inOutLogVo.getServerIP() != null && inOutLogVo.getServerIP().trim().length() > 0) {
                  sqlfield.append("  AND SERVER_IP = '").append(inOutLogVo.getServerIP()).append("'");
            } 
            StringBuilder sql = new StringBuilder();
            sql.append(" UPDATE  TBL_INOUT_LOG  SET LOG_OUT_STATUS = ? , LOG_OUT_STATUS_DESC = ? ,LOGOUT_DATE = CURRENT TIMESTAMP ,UPDATE_BY = ? ,UPDATE_DATE = CURRENT TIMESTAMP ");
            sql.append(" \n WHERE USER_ID = ?  AND  SESSION_ID = ? ");
            sql.append(sqlfield);
                
            jdbcTemplate.update(sql.toString(), new Object[]{inOutLogVo.getLogoutStatus(),inOutLogVo.getLogoutStatusDesc(),
            inOutLogVo.getUpdatedBy() , inOutLogVo.getUserId(),inOutLogVo.getSessionId()});
        } catch (Exception e) {
            log.error("Error occur in while process InOutLogServiceImpl.updateLogout : " + e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public Integer findUserIdAndDeviceIPOnJob(String userId, String userIP , String serverIP) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("InOutLogServiceImpl.findUserIdAndDeviceIPOnJob");
        }
        StringBuilder sqlfield = new StringBuilder();
          if (userIP != null && userIP.trim().length() > 0) {
                sqlfield.append("  AND USER_IP = '").append(userIP).append("'");
          } 
          if (serverIP != null && serverIP.trim().length() > 0) {
                sqlfield.append("  AND SERVER_IP = '").append(serverIP).append("'");
          } 
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT COUNT(*) FROM TBL_INOUT_LOG ");
        sql.append("\n WHERE USER_ID =  ?  ");
        sql.append(sqlfield);
        sql.append("\n AND LOG_OUT_STATUS IS NULL AND LOG_OUT_STATUS_DESC IS NULL AND LOGOUT_DATE IS NULL ");
        
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{userId}, Integer.class);
    }

    @Override
    public Integer findUserIdOnJob(String userId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("InOutLogServiceImpl.findUserIdOnJob");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT COUNT(*) FROM TBL_INOUT_LOG ");
        sql.append("\n WHERE USER_ID =  ?  ");
        sql.append("\n AND LOG_OUT_STATUS IS NULL AND LOG_OUT_STATUS_DESC IS NULL AND LOGOUT_DATE IS NULL ");
        
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{userId}, Integer.class);
    }

    @Override
    public Integer findDeviceIPOnJob( String userIP , String serverIP) throws Exception {
       if (log.isInfoEnabled()) {
            log.info("InOutLogServiceImpl.findDeviceIPOnJob");
        }
        StringBuilder sqlfield = new StringBuilder();
          if (userIP != null && userIP.trim().length() > 0) {
                sqlfield.append("  AND USER_IP = '").append(userIP).append("'");
          } 
          if (serverIP != null && serverIP.trim().length() > 0) {
                sqlfield.append("  AND SERVER_IP = '").append(serverIP).append("'");
          } 
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT COUNT(*) FROM TBL_INOUT_LOG ");
        sql.append("\n WHERE 1=1 ");
        sql.append(sqlfield);
        sql.append("\n AND LOG_OUT_STATUS IS NULL AND LOG_OUT_STATUS_DESC IS NULL AND LOGOUT_DATE IS NULL ");
        
        return jdbcTemplate.queryForObject(sql.toString(), Integer.class);
    }

    @Override
    public void updateExpire(InOutLogVo inOutLogVo) throws Exception {
        try {
            if (log.isInfoEnabled()) {
                log.info("InOutLogServiceImpl.updateExpire");
                log.info(" getLogoutStatus =" + inOutLogVo.getLogoutStatus());
                log.info(" getLogoutStatusDesc = " + inOutLogVo.getLogoutStatusDesc());
                log.info(" getUpdatedBy = " + inOutLogVo.getUpdatedBy());
                log.info(" getUserId = " + inOutLogVo.getUserId());
                log.info(" getUserIP = " + inOutLogVo.getUserIP());
                log.info(" getServerIP = " + inOutLogVo.getServerIP());
            }
            
            StringBuilder sqlfield = new StringBuilder();
            if (inOutLogVo.getUserIP() != null && inOutLogVo.getUserIP().trim().length() > 0) {
                  sqlfield.append("  AND USER_IP = '").append(inOutLogVo.getUserIP()).append("'");
            } 
            if (inOutLogVo.getServerIP() != null && inOutLogVo.getServerIP().trim().length() > 0) {
                  sqlfield.append("  AND SERVER_IP = '").append(inOutLogVo.getServerIP()).append("'");
            } 
            if (inOutLogVo.getUserId() != null && inOutLogVo.getUserId().trim().length() > 0) {
                  sqlfield.append("  AND USER_ID = '").append(inOutLogVo.getUserId()).append("'");
            } 
            StringBuilder sql = new StringBuilder();
            sql.append(" UPDATE  TBL_INOUT_LOG  SET LOG_OUT_STATUS = ? , LOG_OUT_STATUS_DESC = ? ,LOGOUT_DATE = CURRENT TIMESTAMP ,UPDATE_BY = ? ,UPDATE_DATE = CURRENT TIMESTAMP ");
            sql.append(" \n WHERE  LOG_OUT_STATUS IS NULL AND LOG_OUT_STATUS_DESC IS NULL AND LOGOUT_DATE IS NULL ");
            sql.append(sqlfield);
                
            jdbcTemplate.update(sql.toString(), new Object[]{inOutLogVo.getLogoutStatus(),inOutLogVo.getLogoutStatusDesc(),
            inOutLogVo.getUpdatedBy()});
        } catch (Exception e) {
            log.error("Error occur in while process InOutLogServiceImpl.updateExpire : " + e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public Integer findUserIdAndDeviceIPForBaseAction(String userId, String userIP, String serverIP,String sessionId) throws Exception {
         if (log.isInfoEnabled()) {
            log.info("InOutLogServiceImpl.findUserIdAndDeviceIPOnJob");
             log.info("findUserIdAndDeviceIPOnJob userId=" + userId);
        }
        StringBuilder sqlfield = new StringBuilder();
          if (userIP != null && userIP.trim().length() > 0) {
                sqlfield.append("  AND USER_IP = '").append(userIP).append("'");
          } 
           if (serverIP != null && serverIP.trim().length() > 0) {
                sqlfield.append("  AND SERVER_IP = '").append(serverIP).append("'");
          } 
          if (sessionId != null && sessionId.trim().length() > 0) {
                sqlfield.append("  AND SESSION_ID = '").append(sessionId).append("'");
          } 
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT COUNT(*) FROM TBL_INOUT_LOG ");
        sql.append("\n WHERE USER_ID =  ?  ");
        sql.append(sqlfield);
        sql.append("\n AND LOG_OUT_STATUS IS NULL AND LOG_OUT_STATUS_DESC IS NULL AND LOGOUT_DATE IS NULL ");
        
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{userId}, Integer.class);
    }
    
}
