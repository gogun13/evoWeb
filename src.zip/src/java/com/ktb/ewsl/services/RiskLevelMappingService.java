/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RiskLevelMappingVo;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface RiskLevelMappingService {
    
    public String getRiskLevelThatReq(String columnReq, String riskLevelMasterSE)throws Exception;
    public RiskLevelMappingVo getObjectRiskLevel(String riskLevelMasterSE)throws Exception;
    public List<RiskLevelMappingVo> getObjectRiskLevelList()throws Exception;
}
