/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningWayOutFormVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Pratya
 */
@Repository
public class WarningWayOutFormServiceImpl implements WarningWayOutFormService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(WarningWayOutFormServiceImpl.class);
    
       
    @Override
    public ArrayList<WarningWayOutFormVo> getDataListByWarningId (int warningId) throws Exception {

        ArrayList<WarningWayOutFormVo>  result  = null;
        StringBuilder                   sql = new StringBuilder();
        
        try {
            
            sql.append("select a.warning_id as warning_id_for_bcm");
            sql.append("\n          , b.warning_id as warning_id ");
            sql.append("\n          , a.conf_flg as conf_flg_for_bcm");
            sql.append("\n          , b.conf_flg as conf_flg");
            sql.append("\n          , a.conf_remark as conf_remark_for_bcm");
            sql.append("\n          , b.conf_remark as conf_remark ");
            sql.append("\n          , a.action_status as ACTION_STATUS_for_bcm");
            sql.append("\n          , b.action_status as ACTION_STATUS");
            sql.append("\n          , NVL(a.role_code, b.role_code) as role_code");
            sql.append("\n          , t.ACTION_ID");
            sql.append("\n          , t.ACTION_DESC");
            sql.append("\n          , t.SHOW_TYPE");
            sql.append("\n          , t.SEQ ");
            sql.append("\n          , b.conf_flg as conf_flg_not_bcm");
            sql.append("\n          , b.conf_remark as conf_remark_not_bcm");
            sql.append("\n          , b.action_status as action_status_not_bcm");
            sql.append("\n from TBL_MT_ACTION_FORM t");
            sql.append("\n     left join TBL_WARNING_ACTION_FORM a on a.WARNING_ID = ? and t.ACTION_ID   = a.ACTION_ID and a.role_code in ('BCM','CO_BCM')");
            sql.append("\n     left join TBL_WARNING_ACTION_FORM b on b.WARNING_ID = ? and t.ACTION_ID   = b.ACTION_ID and b.role_code in ('CO_RM', 'CO_AE', 'CO_AO','RM', 'AE', 'AO')");
            sql.append("\n where t.is_active = 1");
            sql.append("\n order by t.ACTION_ID asc");
            
            log("[getDataListByWarningId] sql :: " + sql.toString());
            result = (ArrayList<WarningWayOutFormVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningId,warningId}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningWayOutFormVo vo              = new WarningWayOutFormVo();
                    String              tConfFlgNotBcm  = "";
                    
                    if("BCM".equals(rs.getString("role_code")) || "CO_BCM".equals(rs.getString("role_code"))){
                        vo.setWarningId           (rs.getString("warning_id_for_bcm"));
                        vo.setConfFlg             (rs.getString("conf_flg_for_bcm"));
                        vo.setConfRemark          (rs.getString("conf_remark_for_bcm"));
                        vo.setActionStatus        (rs.getString("ACTION_STATUS_for_bcm"));
                    }else{
                        vo.setWarningId           (rs.getString("warning_id"));
                        vo.setConfFlg             (rs.getString("conf_flg"));
                        vo.setConfRemark          (rs.getString("conf_remark"));
                        vo.setActionStatus        (rs.getString("ACTION_STATUS"));
                    }
                    
                    vo.setActionId            (rs.getString("ACTION_ID"));
                    vo.setActionDesc          (rs.getString("ACTION_DESC"));
                    vo.setShowType            (rs.getString("SHOW_TYPE"));
                    vo.setSeq                 (rs.getString("SEQ"));
                    vo.setRoleCode            (rs.getString("role_code"));
                    
                    tConfFlgNotBcm = rs.getString("conf_flg_not_bcm")==null||rs.getString("conf_flg_not_bcm").equals("")?"N":rs.getString("conf_flg_not_bcm");
                    
                    vo.setConfFlgNotBcm       (tConfFlgNotBcm);
                    vo.setConfRemarkNotBcm    (rs.getString("conf_remark_not_bcm"));
                    vo.setActionStatusNotBcm  (rs.getString("action_status_not_bcm"));
                    
                    return vo;
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process WarningWayOutFormServiceImpl.getDataListByWarningId: " + e.getMessage(), e);
        }
        return result;
    }
     
    @Override
    public void deleteWarningActionForm(int warningId, String roleCode) throws Exception {
        log("[deleteWarningActionForm][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            log("[deleteWarningActionForm] warningId  :: " + warningId);
            log("[deleteWarningActionForm] roleCode   :: " + roleCode);
            
            sql.append("DELETE FROM TBL_WARNING_ACTION_FORM WHERE warning_id = ? and role_code in (").append(roleCode).append(")");
        
            jdbcTemplate.update(sql.toString(), new Object[]{warningId});
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log("[deleteWarningActionForm][End]");
        }
    }
    
    @Override
    public void insertWarningActionForm(WarningWayOutFormVo vo) throws Exception {
        log("[insertWarningActionForm][Begin]");
        
        StringBuilder   sql     = new StringBuilder();
        List<Object>    params  = new ArrayList<Object>();
        StringBuilder   column  = new StringBuilder();
        StringBuilder   value   = new StringBuilder();
        
        try{
            column.append("WARNING_ID");
            value.append("?");
            params.add(vo.getWarningId());
            log("[insertWarningActionForm] WARNING_ID :: " + vo.getWarningId());
            
            column.append(", ACTION_ID");
            value.append(", ?");
            params.add(vo.getActionId());
            log("[insertWarningActionForm] ACTION_ID :: " + vo.getActionId());
            
            column.append(", role_code");
            value.append(", ?");
            params.add(vo.getRoleCode());
            log("[insertWarningActionForm] role_code :: " + vo.getRoleCode());
            
            column.append(", CONF_FLG");
            value.append(", ?");
            params.add(updateEmpty(vo.getConfFlg()));
            log("[insertWarningActionForm] CONF_FLG :: " + vo.getConfFlg());
            
            log("[insertWarningActionForm] CONF_REMARK :: " + vo.getConfRemark());
            if(vo.getConfRemark()!=null && !vo.getConfRemark().equals("")){
                column.append(", CONF_REMARK");
                value.append(", ?");
                params.add(updateEmpty(vo.getConfRemark()));
            }
            
            log("[insertWarningActionForm] ActionStatus :: " + vo.getActionStatus());
            if(vo.getActionStatus()!=null && !vo.getActionStatus().equals("")){
                column.append(", action_status");
                value.append(", ?");
                params.add(updateEmpty(vo.getActionStatus()));
            }
            
            column.append(", created_dt");
            value.append(", CURRENT TIMESTAMP");
            
            column.append(", created_by");
            value.append(", ?");
            params.add(updateEmpty(vo.getCreatedBy()));
            log("[insertWarningActionForm] CreatedBy :: " + vo.getCreatedBy());
            
            column.append(", UPDATED_DT");
            value.append(", CURRENT TIMESTAMP");
            
            column.append(", UPDATED_BY");
            value.append(", ?");
            params.add(updateEmpty(vo.getCreatedBy()));
            
            sql.append("insert into TBL_WARNING_ACTION_FORM (").append(column.toString()).append(") values(").append(value.toString()).append(")");
            
            log("[insertWarningActionForm] sql :: " + sql.toString());
            
            jdbcTemplate.update(sql.toString(), params.toArray());
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log("[insertWarningActionForm][End]");
        }
    }
    
    @Override
    public void deleteByWarningId(int warningId) throws Exception {
        log("[deleteByWarningId][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            log("[deleteByWarningId] warningId  :: " + warningId);
            
            sql.append("DELETE FROM TBL_WARNING_ACTION_FORM WHERE warning_id = ?");
        
            jdbcTemplate.update(sql.toString(), new Object[]{warningId});
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log("[deleteByWarningId][End]");
        }
    }
    
    private String updateEmpty(Object obj){
        return obj==null || obj.toString().trim().equals("")?null:obj.toString();
    }
    
    private void log(String txt){
        if(log.isInfoEnabled()){
            log.info(txt);
        }
    }
   

//    @Override
//    public ArrayList<WarningWayOutFormVo> getDataListByWarningId (int warningId) throws Exception {
//
//        ArrayList<WarningWayOutFormVo>  result  = null;
//        String                          sqlStr  = null;
//        
//        
//        try {
//            
//            sqlStr = "select t.*, a.WAYOUT_DESC, a.SHOW_TYPE, a.SEQ"
//                    + "     from TBL_WARNING_WAYOUT_FORM t, TBL_MT_WAYOUT_FORM a"
//                    + "     where t.WAYOUT_ID       = a.WAYOUT_ID"
//                    + "         and t.WARNING_ID    = ?"
//                    + "         and t.ROLE_CODE     = 'BCM'"
////                    + "         and a.IS_ACTIVE   = 1"
//                    + "     order by a.seq asc";
//            
//            if (log.isInfoEnabled()) {
//                log.info("[getDataListByWarningId] sqlStr :: " + sqlStr);
//            }
//
//            StringBuilder sql = new StringBuilder(sqlStr);
//            result = (ArrayList<WarningWayOutFormVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new RowMapper() {
//                @Override
//                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
//                    WarningWayOutFormVo vo = new WarningWayOutFormVo();
//                    
//                    vo.setWarningId         (rs.getString("WARNING_ID"));
//                    vo.setWayOutId          (rs.getString("WAYOUT_ID"));
//                    vo.setWayOutDesc        (rs.getString("WAYOUT_DESC"));
//                    vo.setWayOutFlg         (rs.getString("WAYOUT_FLG"));
//                    vo.setWayOutRemark      (rs.getString("WAYOUT_REMARK"));
//                    vo.setConfWayOutFlg     (rs.getString("CONF_WAYOUT_FLG"));
//                    vo.setConfWayOutRemark  (rs.getString("CONF_WAYOUT_REMARK"));
//                    vo.setActionStatus      (rs.getString("ACTION_STATUS"));
//                    vo.setShowType          (rs.getString("SHOW_TYPE"));
//                    vo.setSeq               (rs.getString("SHOW_TYPE"));
//                    return vo;
//                }
//            });
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            log.error("Error occur in while process WarningWayOutFormServiceImpl.getDataListByWarningId: " + e.getMessage(), e);
//        }
//        return result;
//    }
//    
//    @Override
//    public ArrayList<WarningWayOutFormVo> getDataListByWarningId (int warningId) throws Exception {
//
//        ArrayList<WarningWayOutFormVo>  result  = null;
//        String                          sqlStr  = null;
//        
//        
//        try {
//            
//            sqlStr = "select t.warning_id as wayout_warning_id"
//                    + "    , t.wayout_id"
//                    + "    , t.wayout_flg"
//                    + "    , t.wayout_remark"
//                    + "    , NVL(b.warning_id, c.warning_id) as action_warning_id"
//                    + "    , NVL(b.conf_wayout_flg, c.conf_wayout_flg) as conf_wayout_flg"
//                    + "    , NVL(b.conf_wayout_remark, c.conf_wayout_remark) as conf_wayout_remark"
//                    + "    , NVL(b.action_status, c.action_status) as action_status"
//                    + "    , NVL(b.role_code, c.role_code) as role_code"
//                    + "    , a.WAYOUT_DESC"
//                    + "    , a.SHOW_TYPE"
//                    + "    , a.SEQ"
//                    + "    , c.conf_wayout_flg as conf_wayout_flg_not_bcm"
//                    + "    , c.conf_wayout_remark as conf_wayout_remark_not_bcm"
//                    + "    , c.action_status as action_status_not_bcm"
//                    + " from TBL_WARNING_WAYOUT_FORM t"
//                    + "     inner join TBL_MT_WAYOUT_FORM a on t.WAYOUT_ID   = a.WAYOUT_ID"
//                    + "     left join TBL_WARNING_ACTION_FORM b on b.wayout_warning_id = t.warning_id and b.wayout_id = t.wayout_id and b.role_code = 'BCM'"
//                    + "     left join TBL_WARNING_ACTION_FORM c on c.wayout_warning_id = t.warning_id and c.wayout_id = t.wayout_id and c.role_code in ('RM', 'AE', 'AO')"
//                    + " where t.WARNING_ID  = ?"
//                    + "     and t.role_code = 'BCM'"
//                    + " order by a.seq asc";
//            
//            log("[getDataListByWarningId] sqlStr :: " + sqlStr);
//
//            StringBuilder sql = new StringBuilder(sqlStr);
//            result = (ArrayList<WarningWayOutFormVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new RowMapper() {
//                @Override
//                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
//                    WarningWayOutFormVo vo                  = new WarningWayOutFormVo();
//                    String              tConfWayOutFlgNotBcm = "";
//                    
//                    vo.setWarningId                 (rs.getString("wayout_warning_id"));
//                    vo.setWayOutId                  (rs.getString("WAYOUT_ID"));
//                    vo.setWayOutDesc                (rs.getString("WAYOUT_DESC"));
//                    vo.setWayOutFlg                 (rs.getString("WAYOUT_FLG"));
//                    vo.setWayOutRemark              (rs.getString("WAYOUT_REMARK"));
//                    vo.setConfWayOutFlg             (rs.getString("CONF_WAYOUT_FLG"));
//                    vo.setConfWayOutRemark          (rs.getString("CONF_WAYOUT_REMARK"));
//                    vo.setActionStatus              (rs.getString("ACTION_STATUS"));
//                    vo.setShowType                  (rs.getString("SHOW_TYPE"));
//                    vo.setSeq                       (rs.getString("SEQ"));
//                    vo.setRoleCode                  (rs.getString("role_code"));
//                    
//                    tConfWayOutFlgNotBcm = rs.getString("conf_wayout_flg_not_bcm")==null||rs.getString("conf_wayout_flg_not_bcm").equals("")?"N":rs.getString("conf_wayout_flg_not_bcm");
//                    
//                    vo.setConfWayOutFlgNotBcm       (tConfWayOutFlgNotBcm);
//                    vo.setConfWayOutRemarkNotBcm    (rs.getString("conf_wayout_remark_not_bcm"));
//                    vo.setActionStatusNotBcm        (rs.getString("action_status_not_bcm"));
//                    
//                    return vo;
//                }
//            });
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            log.error("Error occur in while process WarningWayOutFormServiceImpl.getDataListByWarningId: " + e.getMessage(), e);
//        }
//        return result;
//    }
   
//    @Override
//    public void updateConfirmAnswer(WarningWayOutFormVo vo) throws Exception{
//        log("[updateConfirmAnswer][Begin]");
//            
//        log("[updateConfirmAnswer] ConfWayOutFlg       :: " + vo.getConfWayOutFlg());
//        log("[updateConfirmAnswer] ConfWayOutRemark    :: " + vo.getConfWayOutRemark());
//        log("[updateConfirmAnswer] ActionStatus        :: " + vo.getActionStatus());
//        log("[updateConfirmAnswer] UpdatedBy           :: " + vo.getUpdatedBy());
//        log("[updateConfirmAnswer] ActionWarningId     :: " + vo.getActionWarningId());
//        log("[updateConfirmAnswer] WarningId           :: " + vo.getWarningId());
//        log("[updateConfirmAnswer] WayOutId            :: " + vo.getWayOutId());
//        
//        StringBuilder sql = new StringBuilder();
//        sql.append("UPDATE TBL_WARNING_WAYOUT_FORM SET CONF_WAYOUT_FLG = ?, CONF_WAYOUT_REMARK = ?, ACTION_STATUS = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?, ACTION_WARNING_ID = ?");
//        sql.append("\nWHERE WARNING_ID = ? AND WAYOUT_ID = ?");
//        
//        log("[updateConfirmAnswer] sql :: " + sql.toString());
//        
//        jdbcTemplate.update(sql.toString(), new Object[]{ updateEmpty(vo.getConfWayOutFlg())
//                                                        , updateEmpty(vo.getConfWayOutRemark())
//                                                        , updateEmpty(vo.getActionStatus())
//                                                        , vo.getUpdatedBy()
//                                                        , vo.getActionWarningId()
//                                                        , vo.getWarningId()
//                                                        , vo.getWayOutId()
//                                                        }
//        );
//        
//        log("[updateConfirmAnswer][End]");
//    }
   
}
