package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningFileAttachmentVo;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Thanakorn Ch.
 */
@Repository
public class WarningFileAttachmentsServiceImpl implements WarningFileAttachmentsService{
    private static final Logger log = Logger.getLogger(WarningFileAttachmentsServiceImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;


    @Override
    public List<WarningFileAttachmentVo> findByWarningHeaderID( int warnHeadID ) throws Exception {
        if(log.isInfoEnabled()){
            log.info("findByWarningHeaderID");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_ATTACH_ID warningAttachId, WARNING_HEAD_ID warningHeadId, FILE_PATH filePath, FILE_NAME fileName, CREATED_DT createdDate, CREATED_BY createdBy, CREATED_BY_NAME createdByName, MAPPING_FILE_NAME fileLogicalName");
        sql.append("\nFROM TBL_WARNING_ATTACH_FILE");
        sql.append("\nWHERE WARNING_HEAD_ID = ?");
        sql.append("\nORDER BY createdDate");

        List<WarningFileAttachmentVo> listVo = jdbcTemplate.query(sql.toString(), new Object[]{ warnHeadID }, new BeanPropertyRowMapper<WarningFileAttachmentVo>(WarningFileAttachmentVo.class));

        return listVo;
    }

    @Override
    public void deleteFile(int warnHeadID, int seq) throws Exception {
        if(log.isInfoEnabled()){
            log.info("deleteFile");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_ATTACH_FILE");
        sql.append("\nWHERE WARNING_ATTACH_ID = ? AND WARNING_HEAD_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{ seq, warnHeadID });
    }

    @Override
    public void saveFile(WarningFileAttachmentVo vo) throws Exception {
        if(log.isInfoEnabled()){
            log.info("saveFile");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_WARNING_ATTACH_FILE (WARNING_HEAD_ID, FILE_NAME, FILE_PATH, CREATED_BY, CREATED_DT, CREATED_BY_NAME, MAPPING_FILE_NAME)");
        sql.append("\nVALUES(?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{ vo.getWarningHeadId(), vo.getFileName(), vo.getFilePath(), vo.getCreatedBy(), vo.getCreatedDate(), vo.getCreatedByName(), vo.getFileLogicalName() });
    }

    @Override
    public WarningFileAttachmentVo findFileName( int warnHeadID, int seq ) throws Exception {
        if(log.isInfoEnabled()){
            log.info("findFileName");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_ATTACH_ID warningAttachId, WARNING_HEAD_ID warningHeadId, FILE_PATH filePath, FILE_NAME fileName, CREATED_DT createdDate, CREATED_BY createdBy, CREATED_BY_NAME createdByName, MAPPING_FILE_NAME fileLogicalName");
        sql.append("\nFROM TBL_WARNING_ATTACH_FILE");
        sql.append("\nWHERE WARNING_ATTACH_ID = ? AND WARNING_HEAD_ID = ?");

        try {
            WarningFileAttachmentVo listVo = jdbcTemplate.queryForObject(sql.toString(), new Object[]{ seq, warnHeadID }, new BeanPropertyRowMapper<WarningFileAttachmentVo>(WarningFileAttachmentVo.class));
            return listVo;
        } catch( EmptyResultDataAccessException e ) {
            return null;
        }
    }
}
