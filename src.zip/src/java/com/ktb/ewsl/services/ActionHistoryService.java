/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public interface ActionHistoryService {
    public void saveData(ActionHistoryVo vo) throws Exception;
    public List<ActionHistoryVo> findDataByWarningIdAndStatus(int warningId, String status) throws Exception;
    public List<ActionHistoryVo> findRemarkByWarningId(int warningId) throws Exception; 
    public List<ActionHistoryVo> findDataByWarningId(int warningId) throws Exception;
    public List<QuestionHistoryVo> findQuestionHistory(QuestionHistoryVo vo) throws Exception;
    public QuestionHistoryVo findQuestionVersion(String warningId) throws Exception;
    public boolean haveProtestFIN()throws Exception;
    public void deleteActionHistoryByWarningId(String warningIdAll) throws Exception;
    public void deleteActionHistoryByWarningIdAndRoleCode(String warningIdAll,String roleCode) throws Exception;
    public List<ActionHistoryVo> findDataByWarningIdAndStatusAndRoleCode(int warningId, String status, String roleCode) throws Exception;
    public void deleteActionHistoryByWarningIdAndStatusAndRoleCode(int warningId, String status, String roleCode) throws Exception;
    public ActionHistoryVo actionHistoryDetail(int warningId, String actionCode, String actionDetail, String status) throws Exception;
    public void updateData(ActionHistoryVo vo) throws Exception;
    public Integer checkActionHistoryBy(int warningId, String actionCode, String status) throws Exception;
    public ActionHistoryVo findActionHistory(int warningId,String actionCode , String status) throws Exception ;
    public ActionHistoryVo findData(int warningId, String actionDetail) throws Exception;
    public void updateRemarkForDraftReject(ActionHistoryVo vo) throws Exception;
}
