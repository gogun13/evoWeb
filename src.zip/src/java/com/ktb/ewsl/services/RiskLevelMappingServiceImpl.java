/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RiskLevelMappingVo;
import com.ktbcs.core.utilities.StringUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class RiskLevelMappingServiceImpl implements RiskLevelMappingService {
    
    private static final Logger logger = Logger.getLogger(RiskLevelMappingServiceImpl.class);
     
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public String getRiskLevelThatReq(String columnReq, String riskLevelMasterSE) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("RiskLevelMappingServiceImpl.getRiskLevelThatReq");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ").append(columnReq).append(" FROM TBL_MT_RISK_LEVEL_MAPPING ");
        sql.append(" WHERE RISK_LEVEL = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{riskLevelMasterSE}, String.class);
    }

    @Override
    public RiskLevelMappingVo getObjectRiskLevel(String riskLevelMasterSE) throws Exception {
        RiskLevelMappingVo resultVo = new RiskLevelMappingVo();
        StringBuilder sql = new StringBuilder();
        try{
            sql.append(" SELECT  ORDER_SEQ , RISK_LEVEL , RISK_LEVEL_DESC , RISK_LEVEL_HISTORY_DISP, ");
            sql.append(" RISK_LEVEL_IND_RPT_DISP, RISK_LEVEL_PIPELINE_DISP ,  RISK_LEVEL_RENEWAL_DISP ");
            sql.append(" FROM TBL_MT_RISK_LEVEL_MAPPING ");
            sql.append(" WHERE 0=0  ");
            sql.append(" AND RISK_LEVEL = ? ");
         
        ArrayList<RiskLevelMappingVo> resultList = (ArrayList<RiskLevelMappingVo>) jdbcTemplate.query(sql.toString(),new Object[]{riskLevelMasterSE},  new RowMapper() {
            public RiskLevelMappingVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                RiskLevelMappingVo item = new RiskLevelMappingVo();
                item.setOrderSeq(rs.getInt("ORDER_SEQ"));
                item.setRiskLevel(StringUtil.getValue(rs.getString("RISK_LEVEL")));
                item.setRiskLevelDesc(StringUtil.getValue(rs.getString("RISK_LEVEL_DESC")));
                item.setRiskLevelHistoryDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_HISTORY_DISP")));
                item.setRiskLevelIndRptDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_IND_RPT_DISP")));
                item.setRiskLevelPiplelineDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_PIPELINE_DISP")));
                item.setRiskLevelRenewalDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_RENEWAL_DISP")));
                return item;
            }
        });

        if (!resultList.isEmpty() && resultList.size() > 0) {
            resultVo = (RiskLevelMappingVo) resultList.get(0);
        }
       }catch(Exception e){
         logger.error("Error occur in while process RiskLevelMappingServiceImpl.getObjectRiskLevel : ", e);
       }
      return resultVo;
    }

    @Override
    public List<RiskLevelMappingVo> getObjectRiskLevelList() throws Exception {
        List<RiskLevelMappingVo> resultList = new ArrayList<RiskLevelMappingVo>();
        try{
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT  ORDER_SEQ , RISK_LEVEL , RISK_LEVEL_DESC , RISK_LEVEL_HISTORY_DISP, ");
        sql.append(" RISK_LEVEL_IND_RPT_DISP, RISK_LEVEL_PIPELINE_DISP ,  RISK_LEVEL_RENEWAL_DISP ");
        sql.append(" FROM TBL_MT_RISK_LEVEL_MAPPING ");
        
        resultList = (ArrayList<RiskLevelMappingVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
            public RiskLevelMappingVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                RiskLevelMappingVo item = new RiskLevelMappingVo();
                item.setOrderSeq(rs.getInt("ORDER_SEQ"));
                item.setRiskLevel(StringUtil.getValue(rs.getString("RISK_LEVEL")));
                item.setRiskLevelDesc(StringUtil.getValue(rs.getString("RISK_LEVEL_DESC")));
                item.setRiskLevelHistoryDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_HISTORY_DISP")));
                item.setRiskLevelIndRptDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_IND_RPT_DISP")));
                item.setRiskLevelPiplelineDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_PIPELINE_DISP")));
                item.setRiskLevelRenewalDisp(StringUtil.getValue(rs.getString("RISK_LEVEL_RENEWAL_DISP")));
                return item;
            }
        });
       }catch(Exception e){
         logger.error("Error occur in while process RiskLevelMappingServiceImpl.getObjectRiskLevelList : ", e);
       }
       return resultList; 
    }
}
