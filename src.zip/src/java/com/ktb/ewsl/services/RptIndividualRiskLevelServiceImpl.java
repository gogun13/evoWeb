/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RptIndividualRiskLevelVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class RptIndividualRiskLevelServiceImpl implements RptIndividualRiskLevelService{
    
   private static Logger logger = Logger.getLogger(RptIndividualRiskLevelServiceImpl.class);
    @Autowired
    public JdbcTemplate jdbcTemplate;

    @Override
    public List<RptIndividualRiskLevelVo> getIndividualRiskLevel(Integer cifNo, String rishType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("RptIndividualRiskLevelServiceImpl.getIndividualRiskLevel");
        }
        StringBuilder sql = new StringBuilder();
        if (BusinessConst.EWS_TYPE.EWS_RISK_LEVEL.equals(rishType)) {
            sql.append(" SELECT  R.CIF AS CIF ,R.CREATED_DT AS CREATED_DT,R.CREATED_BY  AS CREATED_BY,R.FINAL_RISK_DATE AS RISK_DATE,R.FINAL_RISK_LEVEL  AS RISK_LEVEL , \n");
            sql.append("  M.RISK_LEVEL_SHORT_NAME AS RISK_LEVEL_SHORT_NAME, '").append(rishType).append("' AS RISK_TYPE   \n");
            sql.append(" FROM TBL_RPT_INDIVIDUAL_RISKLEVEL R \n");
            sql.append("  LEFT JOIN TBL_MT_RISK_LEVEL M  \n");
            sql.append("  ON R.FINAL_RISK_LEVEL = M.RISK_LEVEL \n");
            sql.append("  WHERE R.CIF = ?  ");
        } else if (BusinessConst.EWS_TYPE.EWS_QUANTITATIVE_BEHAVIOR_MODEL.equals(rishType)){
            sql.append(" SELECT  R.CIF AS CIF ,R.CREATED_DT AS CREATED_DT,R.CREATED_BY  AS CREATED_BY,R.QUANTI_RISK_DATE AS RISK_DATE,R.QUANTI_RISK_LEVEL  AS RISK_LEVEL, \n");
            sql.append("   M.RISK_LEVEL_SHORT_NAME AS RISK_LEVEL_SHORT_NAME , '").append(rishType).append("' AS RISK_TYPE   \n");
            sql.append("   FROM TBL_RPT_INDIVIDUAL_RISKLEVEL R \n");
            sql.append("   LEFT JOIN TBL_MT_RISK_LEVEL M  \n");
            sql.append("  ON R.QUANTI_RISK_LEVEL = M.RISK_LEVEL \n");
            sql.append("  WHERE R.CIF = ? ");
        } else if (BusinessConst.EWS_TYPE.EWS_QUALITATIVE_ASSESSMENT.equals(rishType)) {
            sql.append("  SELECT R.CIF,R.CREATED_DT,R.CREATED_BY AS CREATED_DT,R.CREATED_BY  AS CREATED_BY ,R.QUALI_RISK_DATE AS RISK_DATE,R.QUALI_RISK_LEVEL  AS RISK_LEVEL, \n");
            sql.append("   M.RISK_LEVEL_SHORT_NAME AS RISK_LEVEL_SHORT_NAME ,'").append(rishType).append("' AS RISK_TYPE   \n");
            sql.append("   FROM TBL_RPT_INDIVIDUAL_RISKLEVEL R \n");
            sql.append("   LEFT JOIN TBL_MT_RISK_LEVEL M  \n");
            sql.append("   ON R.QUALI_RISK_LEVEL = M.RISK_LEVEL \n");
            sql.append("   WHERE R.CIF = ? ");
        }
        //----- previous 1 year from currentDate
        String startDt = DateUtil.getFirstMonthPeriousOneYear();
        String endDt = DateUtil.getLastDayOfMonth();
        if ((!ValidatorUtil.isNullOrEmpty(startDt)) && (!ValidatorUtil.isNullOrEmpty(endDt))) {
            if (BusinessConst.EWS_TYPE.EWS_RISK_LEVEL.equals(rishType)) {
                sql.append("  AND ( TRUNC(R.FINAL_RISK_DATE) BETWEEN TO_DATE('").append(startDt).append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY'))");
            } else if (BusinessConst.EWS_TYPE.EWS_QUANTITATIVE_BEHAVIOR_MODEL.equals(rishType)) {
                sql.append("  AND ( TRUNC(R.QUANTI_RISK_DATE) BETWEEN TO_DATE('").append(startDt).append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY'))");
            } else if (BusinessConst.EWS_TYPE.EWS_QUALITATIVE_ASSESSMENT.equals(rishType)) {
                sql.append("  AND ( TRUNC(R.QUALI_RISK_DATE) BETWEEN TO_DATE('").append(startDt).append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY'))");
            }
        }
        ///--------- Order
        sql.append(" ORDER BY CREATED_DT DESC ");

        List<RptIndividualRiskLevelVo> individualRiskLevelVoList = jdbcTemplate.query(sql.toString(), new Object[]{cifNo}, new RowMapper() {
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                RptIndividualRiskLevelVo item = new RptIndividualRiskLevelVo();
                item.setCif(rs.getInt("CIF"));
                item.setRiskLevel(StringUtil.getValue(rs.getString("RISK_LEVEL_SHORT_NAME")));
                item.setRiskType(StringUtil.getValue(rs.getString("RISK_TYPE")));
                item.setRiskDate(rs.getDate("RISK_DATE"));
                item.setRiskDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("RISK_DATE")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("RISK_DATE"), DateUtil.DEFAULT_DATETIME_FORMAT));
                return item;
            }
        });
        return individualRiskLevelVoList;
    }
@Override
    public void insertIndividualRiskLevel(RptIndividualRiskLevelVo irLevelVo) throws Exception {
        try{
          if (logger.isInfoEnabled()) {
            logger.info("RptIndividualRiskLevelServiceImpl.insertIndividualRiskLevel");
          }

        StringBuilder sql = new StringBuilder();
        sql.append(" INSERT INTO TBL_RPT_INDIVIDUAL_RISKLEVEL(CIF, CREATED_DT, CREATED_BY, FINAL_RISK_DATE, FINAL_RISK_LEVEL, QUANTI_RISK_DATE, QUANTI_RISK_LEVEL, QUALI_RISK_DATE, QUALI_RISK_LEVEL) ");
        sql.append(" VALUES( ? , ? , ? , ? , ? , ? , ? , ? , ? ) ");
        jdbcTemplate.update(sql.toString(), new Object[]{irLevelVo.getCif(), irLevelVo.getCreatedDate(), irLevelVo.getCreatedBy(),
            irLevelVo.getFinalRiskDate(), irLevelVo.getFinalRiskLevel(), 
            irLevelVo.getQuantiRiskDate(),  irLevelVo.getQuantiRiskLevel(), 
            irLevelVo.getQualiRiskDate(),  irLevelVo.getQualiRiskLevel()}); 
        }catch(Exception e){
          logger.error("Error occur in while process RptIndividualRiskLevelServiceImpl.insertIndividualRiskLevel: " + e.getMessage(), e);
          throw e;
        }
    }
    @Override
    public RptIndividualRiskLevelVo findLastedRecordRptIndividualRiskLevel(Integer cif ) throws Exception {
       RptIndividualRiskLevelVo rptIndividualRiskLevelVo = new RptIndividualRiskLevelVo();
        if (logger.isInfoEnabled()) {
            logger.info("RptIndividualRiskLevelServiceImpl.findLastedRecordRptIndividualRiskLevel");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT A1.CIF ,A2.CREATED_BY,A1.CREATED_DT,A2.FINAL_RISK_DATE,A2.FINAL_RISK_LEVEL, ");
        sql.append("\n A2.QUALI_RISK_DATE,A2.QUALI_RISK_LEVEL,A2.QUANTI_RISK_DATE,  ");
        sql.append("\n A2.QUANTI_RISK_LEVEL ");
        sql.append(" FROM ");
        sql.append("      ( SELECT  MAX(CREATED_DT)AS CREATED_DT ,CIF  FROM TBL_RPT_INDIVIDUAL_RISKLEVEL WHERE CIF = ? GROUP BY CIF )A1 ");
        sql.append(" LEFT JOIN   TBL_RPT_INDIVIDUAL_RISKLEVEL A2 ");
        sql.append(" ON A1.CREATED_DT = A2.CREATED_DT ");

          List<RptIndividualRiskLevelVo> rptIndividualRiskLevelVoList = jdbcTemplate.query(sql.toString(), new Object[]{cif}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    RptIndividualRiskLevelVo item = new RptIndividualRiskLevelVo();
                    item.setCif(rs.getInt("CIF"));
                    item.setFinalRiskDate(rs.getDate("FINAL_RISK_DATE"));
                    //item.setFinalRiskDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("FINAL_RISK_DATE")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("FINAL_RISK_DATE"), DateUtil.DEFAULT_DATETIME_FORMAT));
                    item.setFinalRiskLevel(StringUtil.getValue(rs.getString("FINAL_RISK_LEVEL")));
                    item.setQuantiRiskDate(rs.getDate("QUANTI_RISK_DATE"));
                    //item.setQuantiRiskDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("QUANTI_RISK_DATE")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("QUANTI_RISK_DATE"), DateUtil.DEFAULT_DATETIME_FORMAT));
                    item.setQuantiRiskLevel(StringUtil.getValue(rs.getString("QUANTI_RISK_LEVEL")));
                    item.setQualiRiskDate(rs.getDate("QUALI_RISK_DATE"));
                    //item.setQualiRiskDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("QUALI_RISK_DATE")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("QUALI_RISK_DATE"), DateUtil.DEFAULT_DATETIME_FORMAT));
                    item.setQualiRiskLevel(StringUtil.getValue(rs.getString("QUALI_RISK_LEVEL")));
                   return item;
                }
            });   
          if((!rptIndividualRiskLevelVoList.isEmpty())&&(rptIndividualRiskLevelVoList.size() > 0)){
               rptIndividualRiskLevelVo = rptIndividualRiskLevelVoList.get(0);
          }
        return rptIndividualRiskLevelVo;  
    } 
}
