/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningCompletionVo;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningCompletionService {
  
     public void InsertWarningCompletion(WarningCompletionVo vo) throws Exception;
     public void InsertWarningCompletionForApprove(WarningCompletionVo vo) throws Exception;
}
