/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ParameterVo;
import com.ktbcs.core.utilities.ValidatorUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class ParameterServiceImpl implements ParameterService{
    
    private static Logger log = Logger.getLogger(ParameterServiceImpl.class);
    
    @Autowired
    public JdbcTemplate jdbcTemplate;
    
     @Override
    public ParameterVo findByParamIdAndParamType(String paramId, String paramTypeId) throws Exception {
        ParameterVo result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findByParamIdAndParamType");
            }
            StringBuilder sql = new StringBuilder();
            sql.append("  SELECT PARAMETER_ID, PARAMETER_TYPE_ID, PARAMETER_NAME, VALUE1, VALUE2, VALUE3, VALUE4, IS_ACTIVE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY  ");  
            sql.append("\n FROM TBL_MT_PARAMETER ");  
            sql.append(" WHERE  PARAMETER_ID = ? AND PARAMETER_TYPE_ID = ?  ");         
            
           ArrayList<ParameterVo> resultList =(ArrayList<ParameterVo>) jdbcTemplate.query(sql.toString(), new Object[]{paramId, paramTypeId}, new RowMapper(){
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ParameterVo item = new ParameterVo();
                    item.setParameterId(rs.getString("PARAMETER_ID"));
                    item.setParameterTypeId(rs.getString("PARAMETER_TYPE_ID"));
                    item.setParameterName(rs.getString("PARAMETER_NAME"));
                    item.setValue1(rs.getBigDecimal("VALUE1"));
                    item.setValue2(rs.getBigDecimal("VALUE2"));
                    item.setValue3(rs.getString("VALUE3"));
                    item.setValue4(rs.getDate("VALUE4"));
                    return item;
                }
            });


            if (!resultList.isEmpty()) {
                result = (ParameterVo) resultList.get(0);
            }
        } catch (Exception e) {
            log.error("Error occur in while process ParameterServiceImpl.findByParamIdAndParamType: " + e.getMessage(), e);
            throw e;
        }
        return result;
    }

    @Override
    public List<ParameterVo> findByParamTypeId(String paramTypeId) throws Exception {
        
        List<ParameterVo> result = null;
        
        try{
            if (log.isInfoEnabled()) {
                log.info("findByParamTypeId");
            }
            StringBuilder sql = new StringBuilder();
            sql.append("  SELECT *  ");  
            sql.append("\n FROM TBL_MT_PARAMETER ");  
            sql.append(" where PARAMETER_TYPE_ID = ? and IS_ACTIVE = 1 "); 
            
            result =(ArrayList<ParameterVo>) jdbcTemplate.query(sql.toString(), new Object[]{paramTypeId}, new RowMapper(){
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ParameterVo item = new ParameterVo();
                    item.setParameterId(rs.getString("PARAMETER_ID"));
                    item.setParameterTypeId(rs.getString("PARAMETER_TYPE_ID"));
                    item.setParameterName(rs.getString("PARAMETER_NAME"));
                    item.setValue1(rs.getBigDecimal("VALUE1"));
                    item.setValue2(rs.getBigDecimal("VALUE2"));
                    item.setValue3(rs.getString("VALUE3"));
                    item.setValue4(rs.getDate("VALUE4"));
                    return item;
                }
            });
            
        }catch(Exception e){
            log.error("Error occur in while process ParameterServiceImpl.findByParamTypeId: " + e.getMessage(), e);
            throw e;
        }
        
        return result;
    }

    @Override
    public ArrayList<ParameterVo> findByParamType(String paramTypeId , String orderby) throws Exception {
        ArrayList<ParameterVo> resultList = new ArrayList();
        try {
            if (log.isInfoEnabled()) {
                log.info("findByParamType");
            }
            StringBuilder sql = new StringBuilder();
            sql.append("  SELECT PARAMETER_ID, PARAMETER_TYPE_ID, PARAMETER_NAME, VALUE1, VALUE2, VALUE3, VALUE4, IS_ACTIVE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY  ");  
            sql.append("\n FROM TBL_MT_PARAMETER ");  
            sql.append(" WHERE  PARAMETER_TYPE_ID = ?  ");    
            sql.append(" AND IS_ACTIVE = 1 ");  
            
            if(!ValidatorUtil.isNullOrEmpty(orderby)){
                 sql.append("  ORDER BY ").append(orderby).append(" ASC ");
            }
           resultList =(ArrayList<ParameterVo>) jdbcTemplate.query(sql.toString(), new Object[]{paramTypeId}, new RowMapper(){
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ParameterVo item = new ParameterVo();
                    item.setParameterId(rs.getString("PARAMETER_ID"));
                    item.setParameterTypeId(rs.getString("PARAMETER_TYPE_ID"));
                    item.setParameterName(rs.getString("PARAMETER_NAME"));
                    item.setValue1(rs.getBigDecimal("VALUE1"));
                    item.setValue2(rs.getBigDecimal("VALUE2"));
                    item.setValue3(rs.getString("VALUE3"));
                    item.setValue4(rs.getDate("VALUE4"));
                    return item;
                }
            });

        } catch (Exception e) {
            log.error("Error occur in while process ParameterServiceImpl.findByParamType: " + e.getMessage(), e);
            throw e;
        }
        return resultList;
    }
}
