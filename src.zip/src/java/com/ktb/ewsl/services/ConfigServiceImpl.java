/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ConfigVO;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class ConfigServiceImpl implements ConfigService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(ConfigServiceImpl.class);

    @Override
    public ConfigVO findByConfigGroupAndConfigCode(String configGroupCode, String configCode) throws Exception {
        ConfigVO result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findByConfigGroupAndConfigCode");
            }
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT CONFIG_GROUP_CODE, CONFIG_CODE, SEQ, CONFIG_VALUE, REMARK, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY  ");
            sql.append(" FROM ewsmadm.TBL_MT_CONFIG ");
            sql.append(" WHERE  CONFIG_GROUP_CODE = ? AND CONFIG_CODE = ?  ");

            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }

            List<ConfigVO> configVoList = jdbcTemplate.query(sql.toString(), new Object[]{configGroupCode, configCode}, new BeanPropertyRowMapper<ConfigVO>(ConfigVO.class));

            if (!configVoList.isEmpty()) {
                result = (ConfigVO) configVoList.get(0);
            }
        } catch (Exception e) {
            log.error("Error occur in while process ConfigServiceImpl.findByConfigGroupAndConfigCode: " + e.getMessage(), e);
            throw e;
        }
        return result;
    }
    
    @Override
    public List<ConfigVO> findByConfigGroup(String configGroupCode) throws Exception {
        List<ConfigVO> result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("findByConfigGroup");
            }
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT CONFIG_GROUP_CODE, CONFIG_CODE, SEQ, CONFIG_VALUE, REMARK, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY  ");
            sql.append(" FROM ewsmadm.TBL_MT_CONFIG ");
            sql.append(" WHERE  CONFIG_GROUP_CODE = ? ");

            if (log.isDebugEnabled()) {
                log.debug("SQL >>> " + sql.toString());
            }

            result = jdbcTemplate.query(sql.toString(), new Object[]{configGroupCode}, new BeanPropertyRowMapper<ConfigVO>(ConfigVO.class));
        } catch (Exception e) {
            log.error("Error occur in while process ConfigServiceImpl.findByConfigGroup: " + e.getMessage(), e);
            throw e;
        }
        return result;
    }
}
