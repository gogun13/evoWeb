/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.FormStatusControlVo;
import com.ktb.ewsl.vo.QuestionVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningWayOutVo;
import com.ktbcs.core.utilities.BusinessConst;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTB_User
 */
@Repository
public class WayOutServiceImpl implements WayOutService {
    private static final Logger log = Logger.getLogger(WayOutServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public List<QuestionVo> findQuestionWayOut(QuestionVo filter) throws Exception {
        if(log.isInfoEnabled()){            
            log.info("WayOutServiceImpl.findQuestionWayOut");
        }
        StringBuilder       sql             = new StringBuilder();
        List<Object>        params          = new ArrayList<Object>();
        ArrayList<String>   roleCodeList    = null;
        final boolean       flat            = validateData(filter.getWarningId());   
        String              sqlIn           = "";
        
        
        if(flat){
            sql.append("SELECT a.*, b.WAYOUT_FLG, b.WAYOUT_REMARK ");
            sql.append("\n FROM TBL_MT_WAYOUT_FORM a LEFT JOIN TBL_WARNING_WAYOUT_FORM b");
            sql.append("\n ON a.WAYOUT_ID = b.WAYOUT_ID ");       
            sql.append("\n WHERE b.WARNING_ID = ? ");
            
            params.add(filter.getWarningId());
            
            roleCodeList = filter.getRoleCodeList();
            if(!roleCodeList.isEmpty()){
                sqlIn = "\n and b.ROLE_CODE in(";
                for(int i=0;i<roleCodeList.size();i++){
                    if(i==0){
                        sqlIn = sqlIn + "?";
                    }else{
                        sqlIn = sqlIn + ", ?";
                    }
                    params.add(roleCodeList.get(i));
                }
                sqlIn = sqlIn + ")";
                sql.append(sqlIn);
            }
            
            sql.append("\n ORDER BY a.SEQ  ");
            
        }else{
            sql.append("SELECT * FROM TBL_MT_WAYOUT_FORM tblMtWOForm ");
            sql.append("\n WHERE tblMtWOForm.IS_ACTIVE = 1 ");
            sql.append("\n ORDER BY tblMtWOForm.SEQ ");
        }        
        if(log.isDebugEnabled()){
            log.debug("SQL >>> "+sql.toString());
        }
        List<QuestionVo> questionVoList = (ArrayList) jdbcTemplate.query(sql.toString(), params.toArray(), new RowMapper() {
            @Override
            public QuestionVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                QuestionVo item = setWayOutQuestion(rs);                
                if(flat){
                    //item.setAnswer(rs.getString("WAYOUT_FLG"));      
                    item.setRemark(rs.getString("WAYOUT_REMARK"));                         
                    item.setAnswer((BusinessConst.Flag.Y.equals(rs.getString("WAYOUT_FLG")) ? "true" : rs.getString("WAYOUT_FLG")));
                    //(rs.getString("WAYOUT_FLG").equals(BusinessConst.Flag.Y)) ? rs.getString("WAYOUT_FLG") : "true"
                    //("0".equals(rs.getString("APPROVAL_ID6")) ? "" : rs.getString("APPROVAL_ID6"))
                }                
                return item;
            }
        });                     
        return questionVoList;
    }
    
    @Override
    public List<QuestionVo> findQuestionWayOutForBCM(QuestionVo filter) throws Exception {
        if(log.isInfoEnabled()){            
            log.info("WayOutServiceImpl.findQuestionWayOutForBCM");
        }
        
        StringBuilder       sql             = new StringBuilder();
        List<Object>        params          = new ArrayList<Object>();
        
        sql.append("SELECT a.*");
        sql.append("     , b.WAYOUT_FLG");
        sql.append("     , b.WAYOUT_REMARK ");
        sql.append("     , (select c.WAYOUT_FLG from TBL_WARNING_WAYOUT_FORM c where c.WARNING_ID = b.WARNING_ID and c.WAYOUT_ID = a.WAYOUT_ID and c.role_code in ('RM','AE','AO')) as WAYOUT_FLG_NOT_BCM");
        sql.append("     , (select c.WAYOUT_REMARK from TBL_WARNING_WAYOUT_FORM c where c.WARNING_ID = b.WARNING_ID and c.WAYOUT_ID = a.WAYOUT_ID and c.role_code in ('RM','AE','AO')) as WAYOUT_REMARK_NOT_BCM");
        sql.append("\n FROM TBL_MT_WAYOUT_FORM a LEFT JOIN TBL_WARNING_WAYOUT_FORM b");
        sql.append("\n ON a.WAYOUT_ID = b.WAYOUT_ID ");       
        sql.append("\n WHERE b.WARNING_ID = ? ");
        sql.append("\n  and b.ROLE_CODE = 'BCM' ");

        params.add(filter.getWarningId());

        sql.append("\n ORDER BY a.SEQ  ");
            
        if(log.isDebugEnabled()){
            log.debug("SQL >>> "+sql.toString());
        }
        List<QuestionVo> questionVoList = (ArrayList) jdbcTemplate.query(sql.toString(), params.toArray(), new RowMapper() {
            @Override
            public QuestionVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                QuestionVo item = setWayOutQuestion(rs);            
                
                if(rs.getString("WAYOUT_FLG")==null || rs.getString("WAYOUT_FLG").equals("")){
                    item.setAnswer((BusinessConst.Flag.Y.equals(rs.getString("WAYOUT_FLG_NOT_BCM")) ? "true" : rs.getString("WAYOUT_FLG_NOT_BCM")));
                    item.setRemark(rs.getString("WAYOUT_REMARK_NOT_BCM"));
                }else{
                    item.setAnswer((BusinessConst.Flag.Y.equals(rs.getString("WAYOUT_FLG")) ? "true" : rs.getString("WAYOUT_FLG")));
                    item.setRemark(rs.getString("WAYOUT_REMARK"));
                }
                
                item.setWayoutFlgNotBcm((BusinessConst.Flag.Y.equals(rs.getString("WAYOUT_FLG_NOT_BCM")) ? "true" : rs.getString("WAYOUT_FLG_NOT_BCM")));
                item.setWayoutRemarkNotBcm(rs.getString("WAYOUT_REMARK_NOT_BCM"));
                return item;
            }
        });                     
        return questionVoList;
    }
        
    private boolean validateData(int warningId){
        boolean flat = false;
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_ID FROM TBL_WARNING_WAYOUT_FORM a ");
        sql.append("\n WHERE a.WARNING_ID = ? ");        
        if(log.isDebugEnabled()){
            log.debug("SQL >>> "+sql.toString());
        }
                
        ArrayList<String> list = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new RowMapper(){
            String desc = "";
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                desc = rs.getString("WARNING_ID");
                return desc;
            }
        });                       
        if(list != null && list.size()>0){
            flat = true;
        }        
        return flat;
    }
    
    private QuestionVo setWayOutQuestion(ResultSet rs) throws SQLException{
        QuestionVo questionVo = new QuestionVo();
//        item.setDatetime(DateUtil.toDate(rs.getTimestamp("DATETIME", Calendar.getInstance(Locale.US))));        
        questionVo.setQuestId(rs.getInt("WAYOUT_ID"));//WAYOUT_ID
        questionVo.setQuestCode(""+rs.getInt("WAYOUT_ID"));
        questionVo.setQuestDesc(rs.getString("WAYOUT_DESC"));
        questionVo.setChoiceType(rs.getString("SHOW_TYPE"));
        questionVo.setQuestSeq(rs.getInt("SEQ"));               
        return questionVo;
    }                           
        
    @Override
    public WarningWayOutVo findTblWarningWayOutForm(QuestionVo filter) throws Exception {
        WarningWayOutVo result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("WayOutServiceImpl.findTblWarningWayOutForm");
            }
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT tblWnWOForm.WARNING_ID ");
            sql.append("\n FROM TBL_WARNING_WAYOUT_FORM tblWnWOForm ");        
            sql.append("\n WHERE tblWnWOForm.WARNING_ID = ? ");
            if(log.isDebugEnabled()){
                log.debug("SQL >>> "+sql.toString());
            }
            ArrayList<WarningWayOutVo> resultList =(ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningId()}, new RowMapper(){
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningWayOutVo item = new WarningWayOutVo();
                    item.setWarningId(rs.getInt("WARNING_ID"));                    
                    return item;
                }
            });

            if (!resultList.isEmpty()) {
                result = (WarningWayOutVo) resultList.get(0);
            }
        } catch (Exception e) {
            log.error("Error occur in while process WayOutServiceImpl.findTblWarningWayOutForm: " + e.getMessage(), e);
        }
        return result;
    }
       
    //Insert TBL_WARNING_WAYOUT_FORM
    @Override
    public int insertTblWarningWayOutForm(List<WarningWayOutVo> warningWayOutList) throws Exception {
        int row = 0;
        if (log.isInfoEnabled()) {
            log.info("WayOutServiceImpl.insertTblWarningWayOutForm");                    
        }        
        for(WarningWayOutVo warningWayOutVo: warningWayOutList){
            log.info("WARNING_ID ==> " + warningWayOutVo.getWarningId());
            log.info("WAYOUT_ID ==> " + warningWayOutVo.getWayoutId());
            log.info("WAYOUT_FLG ==> " + warningWayOutVo.getWayoutFlg());                        
            StringBuilder sql = new StringBuilder();                
            sql.append("INSERT INTO TBL_WARNING_WAYOUT_FORM ");        
            sql.append("\n(WARNING_ID, WAYOUT_ID, WAYOUT_FLG, WAYOUT_REMARK, CONF_WAYOUT_FLG, ");  
            sql.append("\nCONF_WAYOUT_REMARK, ACTION_STATUS, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ROLE_CODE) ");                
            sql.append("\nVALUES(?, ?, ?, ?, ?, ?, ?, sysdate, ?, sysdate, ?, ?)");                        
            if(log.isDebugEnabled()){
                log.debug("sql >>> "+sql);
            }
            row = jdbcTemplate.update(sql.toString(), new Object[]{
                warningWayOutVo.getWarningId(), 
                warningWayOutVo.getWayoutId(), 
                warningWayOutVo.getWayoutFlg(), 
                warningWayOutVo.getWayoutRemark(), 
                warningWayOutVo.getConfWayoutFlg(), 
                
                warningWayOutVo.getConfWayoutRemark(), 
                warningWayOutVo.getActionStatus(), 
                warningWayOutVo.getCreatedBy(), 
                warningWayOutVo.getUpdatedBy(),
                warningWayOutVo.getRoleCode()});
            if(log.isDebugEnabled()){
                log.debug("row >>> "+row);
            }
        }                
        return row; 
    }
            
    //Delete TBL_WARNING_WAYOUT_FORM       
    @Override
    public int DeleteTblWarningWayOutForm(QuestionVo filter) throws Exception {
        int             row     = 0;
        List<Object>    params  = new ArrayList<Object>();
        
        if (log.isInfoEnabled()) {
            log.info("WayOutServiceImpl.DeleteTblWarningWayOutForm");
            log.info("WayOutServiceImpl.DeleteTblWarningWayOutForm WarningId :: " + filter.getWarningId());
        }
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_WAYOUT_FORM WHERE WARNING_ID = ? ");
        
        params.add(filter.getWarningId());
        
        if(filter.getRoleCode()!=null && !filter.getRoleCode().equals("")){
            sql.append(" and ROLE_CODE = ?");
            params.add(filter.getRoleCode());
        }
        
        row = jdbcTemplate.update(sql.toString(), params.toArray());
        if(log.isDebugEnabled()){
            log.debug("row >>> "+row);
        }
        return row;
    }
    
    //หา status จาก TBL_FORM_STATUS_CONTROL
    @Override
    public String findStatusTblFormStatusControl(FormStatusControlVo formStatusControlVo)throws Exception {                             
        if (log.isInfoEnabled()) {
            log.info("WayOutServiceImpl.findStatusTblFormStatusControl");
        }        
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT a.NEW_STATUS ");
        sql.append("\n FROM TBL_FORM_STATUS_CONTROL a ");        
        sql.append("\n WHERE a.WARNING_TYPE = ? ");
        sql.append("\n AND a.CURR_STATUS = ? ");
        sql.append("\n AND a.ACTION_CODE = ? ");
        if(log.isDebugEnabled()){
            log.debug("SQL >>> "+sql.toString());                        
            log.info("WARNING_TYPE ==> " + formStatusControlVo.getWarningType());
            log.info("CURR_STATUS ==> " + formStatusControlVo.getCurrStatus());
            log.info("ACTION_CODE ==> " + formStatusControlVo.getActionCode());             
        }        
        ArrayList<String> list = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{formStatusControlVo.getWarningType(), formStatusControlVo.getCurrStatus(), formStatusControlVo.getActionCode()}, new RowMapper(){
            String desc = "";
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                desc = rs.getString("NEW_STATUS");
                return desc;
            }
        });        
        return list == null || list.size() < 1 ? null : list.get(0);
    } 
    
    //Insert TBL_ACTION_HISTORY
    @Override
    public int insertTblActionHistory(ActionHistoryVo actionHistoryVo) throws Exception {
        int row = 0;
        if (log.isInfoEnabled()) {
            log.info("WayOutServiceImpl.insertTblActionHistory");       
            log.info("WARNING_ID ==> " + actionHistoryVo.getWarningId());            
            log.info("ACTION_BY ==> " + actionHistoryVo.getActionBy());
            log.info("ACTION_CODE ==> " + actionHistoryVo.getActionCode()); 
            log.info("ACTION_DETAIL ==> " + actionHistoryVo.getActionDetail());
            log.info("STATUS ==> " + actionHistoryVo.getStatus());             
        }              
        StringBuilder sql = new StringBuilder();                
        sql.append("INSERT INTO TBL_ACTION_HISTORY (WARNING_ID, ACTION_DT, ACTION_BY, ACTION_CODE, ACTION_DETAIL, ");        
        sql.append("\n STATUS, REMARK) ");                        
        sql.append("\nVALUES(?, sysdate, ?, ?, ?, ?, ?)");    
        if(log.isDebugEnabled()){
            log.debug("sql >>> "+sql);
        }
        row = jdbcTemplate.update(sql.toString(), new Object[]{
            actionHistoryVo.getWarningId(), actionHistoryVo.getActionBy(), actionHistoryVo.getActionCode(), actionHistoryVo.getActionDetail(), 
            actionHistoryVo.getStatus(), actionHistoryVo.getRemark()});
        if(log.isDebugEnabled()){
            log.debug("row >>> "+row);
        }          
        return row; 
    }            
    
    //Update TBL_WARNING_INFO ฟิลด์ STATUS  UPDATED_DT  UPDATED_BY 
    @Override
    public int updateTblWarningInfo(WarningInfoVo warningInfoVo) throws Exception {
        int row = 0;
        if (log.isInfoEnabled()) {
            log.info("WayOutServiceImpl.updateTblWarningInfo");       
            log.info("WARNING_ID ==> " + warningInfoVo.getWarningId());   
            log.info("WARNING_HEAD_ID ==> " + warningInfoVo.getWarningHeaderId()); 
            log.info("WARNING_TYPE ==> " + warningInfoVo.getWarningType());                                   
        }              
        StringBuilder sql = new StringBuilder();                
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS=?, UPDATED_DT=sysdate, UPDATED_BY=? ");        
        //sql.append("\n WHERE WARNING_ID=? AND WARNING_HEAD_ID=? AND WARNING_TYPE=? " );                                
        sql.append("\n WHERE WARNING_HEAD_ID=? AND WARNING_TYPE=? " ); 
        if(log.isDebugEnabled()){
            log.debug("sql >>> "+sql);
        }
        row = jdbcTemplate.update(sql.toString(), new Object[]{
            //warningInfoVo.getStatus(), warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId(), warningInfoVo.getWarningHeaderId(), 
            warningInfoVo.getStatus(), warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningHeaderId(),
            warningInfoVo.getWarningType()});
        if(log.isDebugEnabled()){
            log.debug("row >>> "+row);
        }          
        return row; 
    }
    
    //Update TBL_WARNING_HEADER ฟิลด์ WAY_OUT_FLG  UPDATED_DT  UPDATED_BY  
//    @Override 
//    public int updateTblWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception {
//        int row = 0;
//        if (log.isInfoEnabled()) {
//            log.info("WayOutServiceImpl.updateTblWarningHeader");                      
//            log.info("WARNING_HEAD_ID ==> " + warningHeaderVo.getWarningHeaderId()); 
//            log.info("CIF ==> " + warningHeaderVo.getCif());                                   
//        }              
//        StringBuilder sql = new StringBuilder();                    
//        sql.append("UPDATE TBL_WARNING_HEADER SET WAY_OUT_FLG=?, UPDATED_DT=sysdate, UPDATED_BY=? ");        
//        sql.append("\n WHERE WARNING_HEAD_ID=? AND CIF=? " );                                
//        if(log.isDebugEnabled()){
//            log.debug("sql >>> "+sql);
//        }
//        row = jdbcTemplate.update(sql.toString(), new Object[]{
//            warningHeaderVo.getWayOutFlg(), warningHeaderVo.getUpdatedBy(), warningHeaderVo.getWarningHeaderId(), warningHeaderVo.getCif()});
//        if(log.isDebugEnabled()){
//            log.debug("row >>> "+row);
//        }          
//        return row; 
//    }
}
