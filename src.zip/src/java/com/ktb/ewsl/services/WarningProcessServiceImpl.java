/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningProcessVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Siriwat Asamo
 */
@Repository
public class WarningProcessServiceImpl implements WarningProcessService {
    
    private static Logger logger = Logger.getLogger(WarningProcessServiceImpl.class);
    
    @Autowired
    public JdbcTemplate jdbcTemplate;

    @Override
    public void updateScoreProjectFIN(WarningProcessVo warningProcessVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateScoreProjectFIN");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_PROCESS SET FIN_SCORE = ?, FIN_PD = ?, FIN_ODDS = ? , HV_FIN = ? ");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_ID = ? ");
        jdbcTemplate.update(sql.toString(), new Object[]{warningProcessVo.getFinScore(), warningProcessVo.getFinPD(), warningProcessVo.getFinODDS(),warningProcessVo.getHvFin(),
            warningProcessVo.getWarningHeaderId(),warningProcessVo.getWarningId()});
    }
    
    public WarningProcessVo findWarningProcessByHeaderId(int warningHeaderId) throws Exception {
        WarningProcessVo warningProcessVo = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningProcessByHeaderId");
        }

        StringBuilder sql = new StringBuilder();  
        sql.append(" SELECT WARNING_HEAD_ID, HV_RATING, RATING_ODDS, HV_NCB, NCBODDS_IND_EWS, NCBODDS_IND_EWS_ONLINE, NCBODDS_IND_EWS_BACKUP, ");
        sql.append("\n NCBODDS_IND_EWS_BACKUP_ONLINE, NCBODDS_EWS, NCBODDS_EWS_ONLINE, HV_FIN, FIN_ODDS, HV_QUANTI, QUANTI_BHVODDS  ,NCB_LAST_UPDATE , FIN_PD , FIN_SCORE,WARNING_ID ");
        sql.append("\n , C_CLASS,AUTHORIZE_REVIEW_DATE,MIN_REVIEW_DATE ,");
        sql.append("\n PAUSE_FLG,MODEL_ID ,AUTHORIZE_RATING_DATE ,NEXT_RATING_DATE ,RATING_MTH , RENEWAL ");
        sql.append("\n FROM TBL_WARNING_PROCESS ");
        sql.append("\n WHERE WARNING_HEAD_ID = ?");
        sql.append("\n ORDER BY WARNING_ID DESC "); //---R1.3

       List<WarningProcessVo> warningProcessVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningProcessVo item = new WarningProcessVo();
                    item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                    item.setWarningId(rs.getInt("WARNING_ID"));
                    item.setFinODDS(rs.getBigDecimal("FIN_ODDS"));
                    item.setHvFin(rs.getString("HV_FIN"));
                    item.setHvNCB(rs.getString("HV_NCB"));
                    item.setHvQuanti(rs.getString("HV_QUANTI"));
                    item.setHvRating(rs.getString("HV_RATING"));
                    item.setNcbODDSEWS(rs.getBigDecimal("NCBODDS_EWS"));
                    item.setNcbODDSEWSOnline(rs.getBigDecimal("NCBODDS_EWS_ONLINE"));
                    item.setNcbODDSIndEWS(rs.getBigDecimal("NCBODDS_IND_EWS"));
                    item.setNcbODDSIndEWSBackup(rs.getBigDecimal("NCBODDS_IND_EWS_BACKUP"));
                    item.setNcbODDSIndEWSBackupOnline(rs.getBigDecimal("NCBODDS_IND_EWS_BACKUP_ONLINE"));
                    item.setNcbODDSIndEWSOnline(rs.getBigDecimal("NCBODDS_IND_EWS_ONLINE"));
                    item.setQuantiBhvODDS(rs.getBigDecimal("QUANTI_BHVODDS"));
                    item.setRatingODDS(rs.getBigDecimal("RATING_ODDS"));
                    item.setNcbLastUpdate(rs.getString("NCB_LAST_UPDATE"));
                    item.setFinPD(rs.getBigDecimal("FIN_PD"));
                    item.setFinScore(rs.getBigDecimal("FIN_SCORE"));
                    //--CR-L R3
                    item.setcClass(rs.getString("C_CLASS"));
                    item.setAuthorizeReviewDate(rs.getDate("AUTHORIZE_REVIEW_DATE"));
                    item.setAuthorizeReviewDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("AUTHORIZE_REVIEW_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("AUTHORIZE_REVIEW_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
                    item.setMinReviewDate(rs.getDate("MIN_REVIEW_DATE"));
                    item.setMinReviewDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MIN_REVIEW_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("MIN_REVIEW_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
                    item.setPauseFlg(rs.getString("PAUSE_FLG"));
                    item.setModelID(rs.getString("MODEL_ID"));
                    item.setAuthorizeRatingDate(rs.getDate("AUTHORIZE_RATING_DATE"));
                    item.setAuthorizeRatingDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("AUTHORIZE_RATING_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("AUTHORIZE_RATING_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
                    item.setNextRatingDate(rs.getDate("NEXT_RATING_DATE"));
                    item.setNextRatingDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("NEXT_RATING_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("NEXT_RATING_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
                    item.setRatingMth(rs.getString("RATING_MTH"));
                    item.setRenewal(rs.getString("RENEWAL"));
                    return item;
                }
            });
         
         if(!warningProcessVoList.isEmpty()){
           warningProcessVo = (WarningProcessVo)warningProcessVoList.get(0);
        }
        return warningProcessVo;
    }
       @Override
    public WarningProcessVo findWarningProcessByHeaderIdAndInfoId(int warningHeaderId, Integer warningInfoId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningProcessByHeaderIdAndInfoId");
        }
        WarningProcessVo warningProcessVo = null;
        try{
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT FIN_ODDS,FIN_PD,FIN_SCORE,HV_FIN,HV_NCB ");
        sql.append("\n ,HV_QUANTI,HV_RATING,NCB_LAST_UPDATE,NCBODDS_EWS,NCBODDS_EWS_ONLINE ");
        sql.append("\n ,NCBODDS_IND_EWS,NCBODDS_IND_EWS_BACKUP,NCBODDS_IND_EWS_BACKUP_ONLINE,NCBODDS_IND_EWS_ONLINE,QUANTI_BHVODDS, ");
        sql.append("\n RATING_ODDS,WARNING_HEAD_ID,WARNING_ID ");
        sql.append("\n , C_CLASS,AUTHORIZE_REVIEW_DATE,MIN_REVIEW_DATE ,");
        sql.append("\n PAUSE_FLG,MODEL_ID ,AUTHORIZE_RATING_DATE ,NEXT_RATING_DATE ,RATING_MTH  , RENEWAL");
        sql.append("\n FROM TBL_WARNING_PROCESS ");
        sql.append("\n WHERE WARNING_HEAD_ID = ? AND WARNING_ID = ? ");
        List<WarningProcessVo> warningProcessVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId,warningInfoId}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return getResultWarningProcess(rs);
                }   
        });
         
         if(!warningProcessVoList.isEmpty()){
           warningProcessVo = (WarningProcessVo)warningProcessVoList.get(0);
        }
        
        }catch(Exception e){
           logger.error("Error occur in while process findWarningProcessByHeaderIdAndInfoId:" + e.getMessage(),e);
           throw e;
        }
          return warningProcessVo;
    }

    @Override
    public WarningProcessVo findMaxWarningInfoWithinHeaderId(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findMaxWarningInfoWithinHeaderId");
        }
        WarningProcessVo warningProcessVo = null;
        try{
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_HEAD_ID, WARNING_ID, HV_QCA, QCA_SCORE, QCA_PD, QCA_ODDS, HV_NCB, NCB_ODDS_IND, NCB_ODDS_IND_EWS, NCB_ODDS, NCB_ODDS_BACKUP, NCB_ODDS_EWS, HV_FIN, FIN_SCORE, FIN_PD, FIN_ODDS, HV_QUANTI, QUANTIBHVODDS, NCBODDS_IND_EWS_BACKUP, NCBODDS_IND_RT, NCBODDS_IND_BACKUP  ");
        sql.append("\n FROM TBL_WARNING_PROCESS  ");
        sql.append("\n WHERE WARNING_ID = ( SELECT MAX(WARNING_ID) FROM TBL_WARNING_PROCESS WHERE WARNING_HEAD_ID = ? )  ");
        List<WarningProcessVo> warningProcessVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return getResultWarningProcess(rs);
                }   
        });
        if(!warningProcessVoList.isEmpty()){
           warningProcessVo = (WarningProcessVo)warningProcessVoList.get(0);
        }
        
        }catch(Exception e){
           logger.error("Error occur in while process findMaxWarningInfoWithinHeaderId:" + e.getMessage(),e);
           throw e;
        }
       return warningProcessVo;
    }

    private WarningProcessVo getResultWarningProcess(ResultSet rs)throws SQLException {
         WarningProcessVo item = new WarningProcessVo();
            item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
            item.setWarningId(rs.getInt("WARNING_ID"));
            item.setFinODDS(rs.getBigDecimal("FIN_ODDS"));
            item.setHvFin(rs.getString("HV_FIN"));
            item.setHvNCB(rs.getString("HV_NCB"));
            item.setHvQuanti(rs.getString("HV_QUANTI"));
            item.setHvRating(rs.getString("HV_RATING"));
            item.setNcbODDSEWS(rs.getBigDecimal("NCBODDS_EWS"));
            item.setNcbODDSEWSOnline(rs.getBigDecimal("NCBODDS_EWS_ONLINE"));
            item.setNcbODDSIndEWS(rs.getBigDecimal("NCBODDS_IND_EWS"));
            item.setNcbODDSIndEWSBackup(rs.getBigDecimal("NCBODDS_IND_EWS_BACKUP"));
            item.setNcbODDSIndEWSBackupOnline(rs.getBigDecimal("NCBODDS_IND_EWS_BACKUP_ONLINE"));
            item.setNcbODDSIndEWSOnline(rs.getBigDecimal("NCBODDS_IND_EWS_ONLINE"));
            item.setQuantiBhvODDS(rs.getBigDecimal("QUANTI_BHVODDS"));
            item.setRatingODDS(rs.getBigDecimal("RATING_ODDS"));
            item.setNcbLastUpdate(rs.getString("NCB_LAST_UPDATE"));
            item.setFinPD(rs.getBigDecimal("FIN_PD"));
            item.setFinScore(rs.getBigDecimal("FIN_SCORE"));
  //--CR-L R3
            item.setcClass(rs.getString("C_CLASS"));
            item.setAuthorizeReviewDate(rs.getDate("AUTHORIZE_REVIEW_DATE"));
            item.setAuthorizeReviewDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("AUTHORIZE_REVIEW_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("AUTHORIZE_REVIEW_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
            item.setMinReviewDate(rs.getDate("MIN_REVIEW_DATE"));
            item.setMinReviewDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MIN_REVIEW_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("MIN_REVIEW_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
            item.setPauseFlg(rs.getString("PAUSE_FLG"));
            item.setModelID(rs.getString("MODEL_ID"));
            item.setAuthorizeRatingDate(rs.getDate("AUTHORIZE_RATING_DATE"));
            item.setAuthorizeRatingDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("AUTHORIZE_RATING_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("AUTHORIZE_RATING_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
            item.setNextRatingDate(rs.getDate("NEXT_RATING_DATE"));
            item.setNextRatingDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("NEXT_RATING_DATE")) ? "" : DateUtil.getDateFormat(rs.getTimestamp("NEXT_RATING_DATE") , DateUtil.DATE_FORMAT_YYYYMMDD));
            item.setRatingMth(rs.getString("RATING_MTH"));
            item.setRenewal(rs.getString("RENEWAL"));
         return item;
    }
    
    @Override
    public void insertWarningProcess(WarningProcessVo vo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("insertWarningProcess");
        }
        try{
        StringBuilder sql = new StringBuilder();
        sql.append(" INSERT INTO TBL_WARNING_PROCESS(WARNING_HEAD_ID, WARNING_ID, ");
        sql.append("\n HV_NCB,  NCB_ODDS_IND_EWS, ");
        sql.append("\n NCB_ODDS_EWS, HV_FIN, FIN_SCORE, FIN_PD, ");
        sql.append("\n FIN_ODDS, HV_QUANTI, QUANTIBHVODDS) ");
        sql.append("\n VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ");
        jdbcTemplate.update(sql.toString(), new Object[]{
                vo.getWarningHeaderId(),vo.getWarningId(),
                vo.getHvNCB(),vo.getNcbODDSIndEWS(),
                vo.getNcbODDSEWS(),vo.getHvFin(),vo.getFinScore(),vo.getFinPD(),
                vo.getFinODDS(),vo.getHvQuanti(),vo.getQuantiBhvODDS()}
        );
        }catch(Exception e){
           logger.error("Error occur in while process insertWarningProcess:" + e.getMessage(),e);
           throw e;
        }
    }
    @Override
    public WarningProcessVo findWarningProcessByInfoId(Integer warningInfoId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningProcessByInfoId");
        }
        WarningProcessVo warningProcessVo = null;
        try{
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT FIN_ODDS,FIN_PD,FIN_SCORE,HV_FIN,HV_NCB ");
        sql.append("\n ,HV_QUANTI,HV_RATING,NCB_LAST_UPDATE,NCBODDS_EWS,NCBODDS_EWS_ONLINE ");
        sql.append("\n ,NCBODDS_IND_EWS,NCBODDS_IND_EWS_BACKUP,NCBODDS_IND_EWS_BACKUP_ONLINE,NCBODDS_IND_EWS_ONLINE,QUANTI_BHVODDS, ");
        sql.append("\n RATING_ODDS,WARNING_HEAD_ID,WARNING_ID ");
        sql.append("\n , C_CLASS,AUTHORIZE_REVIEW_DATE,MIN_REVIEW_DATE ,");
        sql.append("\n PAUSE_FLG,MODEL_ID ,AUTHORIZE_RATING_DATE ,NEXT_RATING_DATE ,RATING_MTH , RENEWAL ");
        sql.append("\n FROM TBL_WARNING_PROCESS ");
        sql.append("\n WHERE WARNING_ID = ? ");
        List<WarningProcessVo> warningProcessVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningInfoId}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return getResultWarningProcess(rs);
                }   
        });
         
         if(!warningProcessVoList.isEmpty()){
           warningProcessVo = (WarningProcessVo)warningProcessVoList.get(0);
        }
        
        }catch(Exception e){
           logger.error("Error occur in while process findWarningProcessByInfoId:" + e.getMessage(),e);
           throw e;
        }
          return warningProcessVo;
    }
}
