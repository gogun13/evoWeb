/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningCompletionVo;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author pumin
 */
@Repository
public class WarningCompletionServiceImpl implements WarningCompletionService {

    private static final Logger log = Logger.getLogger(WarningCompletionServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;


    @Override
    public void InsertWarningCompletion(WarningCompletionVo vo) throws Exception {
        try {
            log.info("InsertWarningCompletion");
            if(log.isDebugEnabled()){
            log.debug("WARNING_HEAD_ID = " + vo.getWarningHeadId());
            log.debug("COMPLETE_FLG = " + vo.getCompleteFlg());
            log.debug("REMARK = " + vo.getRemark());
            log.debug("CREATED_BY = " + vo.getCreatedBy());
            }
            StringBuilder sql = new StringBuilder("INSERT INTO TBL_WARNING_COMPLETION ( COMPLETE_FLG,CREATED_BY,CREATED_DT,REMARK,WARNING_HEAD_ID) VALUES(?,?,?,?,?) ");
            jdbcTemplate.update(sql.toString(), new Object[]{vo.getCompleteFlg(), vo.getCreatedBy(), vo.getCreatedDt(), vo.getRemark(), vo.getWarningHeadId()});

        } catch (Exception e) {
            log.error("Error occur in while process WarningCompletionServiceImpl.InsertWarningCompletion : " + e.getMessage(), e);
            throw e;
        }
    }
    
    @Override
    public void InsertWarningCompletionForApprove(WarningCompletionVo vo) throws Exception {
        try {
            log.info("InsertWarningCompletionForApprove");
            if(log.isDebugEnabled()){
            log.debug("WARNING_HEAD_ID = " + vo.getWarningHeadId());
            log.debug("COMPLETE_FLG = " + vo.getCompleteFlg());
            log.debug("CREATED_BY = " + vo.getCreatedBy());
            }
            StringBuilder sql = new StringBuilder("INSERT INTO TBL_WARNING_COMPLETION(WARNING_HEAD_ID, COMPLETE_FLG, CREATED_DT, CREATED_BY) VALUES(?,?,CURRENT TIMESTAMP,?) ");
            jdbcTemplate.update(sql.toString(), new Object[]{vo.getWarningHeadId(), vo.getCompleteFlg(), vo.getCreatedBy()});

        } catch (Exception e) {
            log.error("Error occur in while process WarningCompletionServiceImpl.InsertWarningCompletionForApprove : " + e.getMessage(), e);
            throw e;
        }
    }
}
