/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.IndividualODAccountVo;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface IndividualODAccountService {
    
    public List<IndividualODAccountVo> getWarningBeforeODOverLimit(String cif) throws Exception;
    
    public List<IndividualODAccountVo> getWarningODOverLimit(String cif) throws Exception;
    
    public List<IndividualODAccountVo> getWarningODOverLimit12Month(String cif) throws Exception;//Track Record on Turnaround(OD Over-limit only)
    
}
