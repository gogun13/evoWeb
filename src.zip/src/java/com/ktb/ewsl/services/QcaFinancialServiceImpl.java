/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.FinancialRatioVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktb.ewsl.vo.ScoreEngineVo;
import com.ktbcs.core.external.optimist.FinUtil;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.StringUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.ktbcs.core.vo.UserData;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Kat
 */
@Repository
public class QcaFinancialServiceImpl implements QcaFinancialService {

    private static final Logger logger = Logger.getLogger(QcaFinancialServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public FinancialVo getFinancialVO(String appID, String cif) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT FIN.FIN_ID, FIN.CIF, FIN.HV_FIN, FIN.REASON_CODE, FIN.REASON_DETAIL, FIN.FIN_CONFIG_ID, FIN.FIN_TRN_ID ");
        sql.append(" , FINTRN.MODEL_ID_FN_AUDIT, FINTRN.MODEL_ID_FN_ADJUST, FINTRN.MODEL_ID_PRIMARY ");
        sql.append(" , FINTRN.FIN_STATEMENT_AUDIT_DATE1, FINTRN.FIN_STATEMENT_AUDIT_DATE2, FINTRN.FIN_STATEMENT_AUDIT_DATE3 ");
        sql.append(" , FINTRN.FIN_STATEMENT_ADJUST_DATE1, FINTRN.FIN_STATEMENT_ADJUST_DATE2, FINTRN.FIN_STATEMENT_ADJUST_DATE3, FINTRN.OPTIMIST_PPN_TM ");
        sql.append(" , FIN.WARNING_ID  ");
        sql.append(" FROM TBL_QCA_FIN FIN ");
        sql.append(" LEFT JOIN TBL_QCA_FIN_TRN FINTRN ON FIN.FIN_TRN_ID = FINTRN.FIN_TRN_ID ");
//            sql.append(" WHERE FIN.APP_NO = '").append(appID).append("' AND FIN.CIF = '").append(cif).append("' ");
        sql.append(" WHERE FIN.CIF = '").append(cif).append("' ");
        sql.append(" AND FIN.IS_ACTIVE = '1' ");

        logger.info(" SQL = getFinancialVO => " + sql.toString());
        ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
            public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                FinancialVo rtnVO = new FinancialVo();
                rtnVO.setFinId(FinUtil.null2Empty(rs.getString("FIN_ID")));
                rtnVO.setCif(FinUtil.null2Empty(rs.getString("CIF")));
                rtnVO.setHvFin(FinUtil.null2Empty(rs.getString("HV_FIN")));
                rtnVO.setReasonCode(FinUtil.null2Empty(rs.getString("REASON_CODE")));
                if(rtnVO.getHvFin() !=null && !"".equals(rtnVO.getHvFin())){
                    if("Y".equalsIgnoreCase(rtnVO.getHvFin())) rtnVO.setReasonSelectY(rtnVO.getReasonCode());
                    else if("N".equalsIgnoreCase(rtnVO.getHvFin())) rtnVO.setReasonSelectN(rtnVO.getReasonCode());
                }
                rtnVO.setReasonDetail(FinUtil.null2Empty(rs.getString("REASON_DETAIL")));
                rtnVO.setFinConfigId(FinUtil.null2Empty(rs.getString("FIN_CONFIG_ID")));
                rtnVO.setTrnId(FinUtil.null2Empty(rs.getString("FIN_TRN_ID")));
                rtnVO.setModelIdFnAudit(FinUtil.null2Empty(rs.getString("MODEL_ID_FN_AUDIT")));
                rtnVO.setModelIdFnAdjust(FinUtil.null2Empty(rs.getString("MODEL_ID_FN_ADJUST")));
                rtnVO.setModelIdPrimary(FinUtil.null2Empty(rs.getString("MODEL_ID_PRIMARY")));
                rtnVO.setFinStatementAuditDate1(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE1")));
                rtnVO.setFinStatementAuditDate2(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE2")));
                rtnVO.setFinStatementAuditDate3(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE3")));
                rtnVO.setFinStatementAdjustDate1(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE1")));
                rtnVO.setFinStatementAdjustDate2(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE2")));
                rtnVO.setFinStatementAdjustDate3(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE3")));
                rtnVO.setOptimistPpnTm(FinUtil.formatDateTHFull(rs.getTimestamp("OPTIMIST_PPN_TM")));
                rtnVO.setWarningInfoId(rs.getInt("WARNING_ID"));
                return rtnVO;
            }
        });
        FinancialVo resultFinanVo = new FinancialVo();
        if (result != null && result.size()>0) {
            resultFinanVo = (FinancialVo) result.get(0);
        }

        return resultFinanVo;
    }

    @Override
    public List<FinancialRatioVo> getRatioList(String finTrnId) throws Exception {
        StringBuilder sqlBuilder = new StringBuilder("");
        sqlBuilder.append(" SELECT ORDER_NO, GROUP_CODE, ACCOUNT_CODE, DESCRIPTION_TH, UNIT, RAT1.MODEL_ID, RAT1.FIN_STATEMENT_DATE, RAT1.FIN_RATIO_VALUE_CAL ");
        sqlBuilder.append(" FROM TBL_QCA_FIN_CONFIG CONF ");
        sqlBuilder.append(" LEFT JOIN ( ");
        sqlBuilder.append(" SELECT RAT.FIN_TRN_ID, RAT.CIF, RAT.MODEL_ID, RAT.FIN_STATEMENT_DATE, RAT.FIN_RATIO_GRP_ID, RAT.FIN_RATIO_CODE, RAT.FIN_RATIO_VALUE_CAL ");
        sqlBuilder.append(" FROM TBL_QCA_FIN_RATIO RAT ");
        sqlBuilder.append(" WHERE RAT.FIN_TRN_ID = '").append(finTrnId).append("' ");
        //kat fix ก่อนเทสหน้าจอ 140426103823
//            sqlBuilder.append(" WHERE RAT.FIN_TRN_ID = '140426103823' ");
        sqlBuilder.append(" ) RAT1 ON CONF.GROUP_CODE = RAT1.FIN_RATIO_GRP_ID AND CONF.ACCOUNT_CODE = RAT1.FIN_RATIO_CODE ");
        sqlBuilder.append(" WHERE CONF.FIN_CONFIG_ID = 'OPTI1' AND CONF.IS_SHOW = '1' ");
        sqlBuilder.append(" ORDER BY CONF.ORDER_NO, RAT1.MODEL_ID, RAT1.FIN_STATEMENT_DATE DESC ");

        logger.info(" getRatioList SQL => " + sqlBuilder.toString());
        ArrayList<FinancialRatioVo> result = (ArrayList<FinancialRatioVo>) jdbcTemplate.query(sqlBuilder.toString(), new RowMapper() {
            public FinancialRatioVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                FinancialRatioVo ratioVO = new FinancialRatioVo();
                ratioVO.setOrderNo(rs.getString("ORDER_NO"));
                ratioVO.setGroupCode(rs.getString("GROUP_CODE"));
                ratioVO.setAccountCode(rs.getString("ACCOUNT_CODE"));
                ratioVO.setDescriptionTh(rs.getString("DESCRIPTION_TH"));
                ratioVO.setUnit(FinUtil.null2Empty(rs.getString("UNIT")));
                ratioVO.setModelId(rs.getString("MODEL_ID"));
                ratioVO.setFinStatementDate(rs.getString("FIN_STATEMENT_DATE"));
                ratioVO.setFinRatioValue(FinUtil.formatCurrency2DigiNA(rs.getBigDecimal("FIN_RATIO_VALUE_CAL")));
                return ratioVO;
            }
        });

        return result;
    }

    @Override
    public boolean checkDBFinancial(FinancialVo finVO) {
        boolean samedate = false;
        try {
            StringBuilder sql = new StringBuilder();
//            sql.append(" SELECT HV_FIN, APP_NO, CIF ");
            sql.append(" SELECT HV_FIN,CIF ");
            sql.append(" FROM TBL_QCA_FIN ");
//            sql.append(" WHERE APP_NO = ").append(FinUtil.formatDBString(finVO.getApplicationNo()));
            sql.append(" WHERE CIF = ").append(FinUtil.formatDBString(finVO.getCif()));
            sql.append(" AND IS_ACTIVE = '1' ");

            logger.info(" SQL = checkDBFinancial => " + sql.toString());
            ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
                public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                    FinancialVo finVO = new FinancialVo();
                    finVO.setHvFin(rs.getString("HV_FIN"));
//                    finVO.setApplicationNo(rs.getString("APP_NO"));
                    finVO.setCif(rs.getString("CIF"));
                    finVO.setCifNo(rs.getString("CIF"));
                    return finVO;
                }
            });

            String haveFin = "";
            if (result != null) {
                for (FinancialVo vo : result) {
                    haveFin = FinUtil.null2Empty(vo.getHvFin());
                }
            }
            if (haveFin.equalsIgnoreCase(finVO.getHvFin())) {
                samedate = true;
            }
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        }
        return samedate;
    }

    @Override
    public void updateFinancial(FinancialVo finVO, UserData userObj, String isActive) throws Exception {
        Date today = Calendar.getInstance().getTime();
        StringBuilder sqlUpdate = new StringBuilder();
        sqlUpdate.append(" UPDATE TBL_QCA_FIN SET ");
        sqlUpdate.append(" IS_ACTIVE = ").append(FinUtil.formatDBString(isActive));
        sqlUpdate.append(", REASON_CODE = ").append(FinUtil.formatDBString(finVO.getReasonCode()));
        sqlUpdate.append(", REASON_DETAIL = ").append(FinUtil.formatDBString(finVO.getReasonDetail()));
        //sqlUpdate.append(", UPDATED_DT = ").append(FinUtil.formatDBOraDateTime(today));
        sqlUpdate.append(", UPDATED_DT = current timestamp ");
        sqlUpdate.append(", UPDATED_BY = ").append(FinUtil.formatDBString(userObj.getEmpNo()));
        sqlUpdate.append(", ROLE = ").append(FinUtil.formatDBString(userObj.getRoleId()));
        sqlUpdate.append(", USER_ID = ").append(FinUtil.formatDBString(userObj.getEmpNo()));
        sqlUpdate.append(" WHERE FIN_ID = '").append(finVO.getFinId()).append("'");
        logger.info(" updateFinancial => " + sqlUpdate.toString());
        jdbcTemplate.update(sqlUpdate.toString(), new Object[]{});
    }

    @Override
    public void updateFinancialByAppAndCIF(FinancialVo finVO, UserData userObj, String isActive) throws Exception {
        Date today = Calendar.getInstance().getTime();
        StringBuilder sqlUpdate = new StringBuilder();
        sqlUpdate.append(" UPDATE TBL_QCA_FIN SET ");
        sqlUpdate.append(" IS_ACTIVE = ").append(FinUtil.formatDBString(isActive));
        sqlUpdate.append(", REASON_CODE = ").append(FinUtil.formatDBString(finVO.getReasonCode()));
        sqlUpdate.append(", REASON_DETAIL = ").append(FinUtil.formatDBString(finVO.getReasonDetail()));
//        sqlUpdate.append(", UPDATED_DT = ").append(FinUtil.formatDBOraDateTime(today));
        sqlUpdate.append(", UPDATED_DT = current timestamp ");
        sqlUpdate.append(", UPDATED_BY = ").append(FinUtil.formatDBString(userObj.getEmpNo()));
        sqlUpdate.append(", ROLE = ").append(FinUtil.formatDBString(userObj.getRoleId()));
        sqlUpdate.append(", USER_ID = ").append(FinUtil.formatDBString(userObj.getEmpNo()));

//        sqlUpdate.append(" WHERE APP_NO = '").append(finVO.getApplicationNo()).append("'");
        sqlUpdate.append(" WHERE CIF = '").append(finVO.getCif()).append("'");

        logger.info(" updateFinancialByAppAndCIF => " + sqlUpdate.toString());
        jdbcTemplate.update(sqlUpdate.toString(), new Object[]{});
    }

    @Override
    public void insertFinancial(FinancialVo finVO, UserData userObj, String isActive) throws Exception {
        Date today = Calendar.getInstance().getTime();

        StringBuilder sqlInsert = new StringBuilder();
        sqlInsert.append(" INSERT INTO TBL_QCA_FIN( ");
        sqlInsert.append(" FIN_ID, CIF, HV_FIN, REASON_CODE, REASON_DETAIL, FIN_CONFIG_ID ");
        sqlInsert.append(", CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY ");
//        sqlInsert.append(", FIN_TRN_ID, ROLE, USER_ID, IS_ACTIVE, APP_NO, CUST_NO) ");
        sqlInsert.append(", FIN_TRN_ID, ROLE, USER_ID, IS_ACTIVE , WARNING_ID, DELAY_REASON ) ");
        sqlInsert.append(" VALUES( ");
        sqlInsert.append(FinUtil.genKeyByDT(today));
        sqlInsert.append(", '").append(finVO.getCif()).append("'");
        sqlInsert.append(", '").append(finVO.getHvFin()).append("'");
        sqlInsert.append(", '").append(finVO.getReasonCode()).append("'");
        sqlInsert.append(", '").append(finVO.getReasonDetail()).append("'");
        sqlInsert.append(", 'OPTI1' ");
//        sqlInsert.append(", ").append(FinUtil.formatDBOraDateTime(today));
        sqlInsert.append(", current timestamp ");
        sqlInsert.append(", '").append(userObj.getEmpNo()).append("'");
//        sqlInsert.append(", ").append(FinUtil.formatDBOraDateTime(today));
        sqlInsert.append(", current timestamp ");
        sqlInsert.append(", '").append(userObj.getEmpNo()).append("'");
        //kat fix trnId ไปก่อน
//        sqlInsert.append(", '"+FinUtil.genKeyByDT(today)+"'");
        sqlInsert.append(", null");
        sqlInsert.append(", '").append(userObj.getRoleId()).append("'");
        sqlInsert.append(", '").append(userObj.getEmpNo()).append("'");
        sqlInsert.append(", ").append(FinUtil.formatDBString(isActive));
//        sqlInsert.append(", '").append(finVO.getApplicationNo()).append("'");
//        sqlInsert.append(", ").append(finVO.getCustNo());
        sqlInsert.append(", ").append(finVO.getWarningInfoId());
        sqlInsert.append(", '").append(finVO.getDelayReason()).append("'");
        sqlInsert.append(" ) ");

        logger.info(" insertFinancial => " + sqlInsert.toString());
        jdbcTemplate.update(sqlInsert.toString(), new Object[]{});
    }

    @Override
    public FinancialVo checkHVFin(String cifId) {
        String haveFin = "";
        FinancialVo vo = new FinancialVo();
        try {
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT HV_FIN,CIF ,WARNING_ID , FIN_TRN_ID  ");
            sql.append(" FROM TBL_QCA_FIN ");
            sql.append(" WHERE CIF = ").append(FinUtil.formatDBString(cifId));
            sql.append(" AND IS_ACTIVE = '1' ");

            logger.info(" SQL = checkHVFin => " + sql.toString());
            ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
                public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                    FinancialVo finVO = new FinancialVo();
                    finVO.setHvFin(rs.getString("HV_FIN"));
                    finVO.setCif(rs.getString("CIF"));
                    finVO.setCifNo(rs.getString("CIF"));
                    finVO.setWarningInfoId(rs.getInt("WARNING_ID"));
                    finVO.setFinTrnId(rs.getString("FIN_TRN_ID"));
                    return finVO;
                }
            });

            if (result != null && !result.isEmpty()) {
               /* for (FinancialVo vo : result) {
                    haveFin = FinUtil.null2Empty(vo.getHvFin());
                }*/
                vo = (FinancialVo)result.get(result.size()-1);
            }
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        }
        return vo;
    }

    @Override
    public ScoreEngineVo findDataForSendScore(int warningId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findDataForSendScore");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT qcaFinCal.STATE_TYPE,qcaFinCal.COGS_SALES,qcaFinCal.DSCR_CFO,qcaFinCal.DE,qcaFinCal.INTEREST_RATIO,qcaFinCal.OPERATING_ROTE,qcaFinCal.SLOPE_PROFIT_MARGIN,qcaFinCal.QUICK_RATIO");
        sql.append("\nFROM TBL_QCA_FIN qcaFin");
        sql.append("\nINNER JOIN TBL_QCA_FIN_CAL qcaFinCal");
        sql.append("\nON qcaFin.FIN_ID = qcaFinCal.FIN_ID");
        sql.append("\nWHERE qcaFin.IS_ACTIVE = ? AND qcaFin.WARNING_ID = ?");


        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
       // List<ScoreEngineVo> asstChoiceVoList = jdbcTemplate.query(sql.toString(), new Object[]{BusinessConst.Flag.ACTIVE, warningId}, new BeanPropertyRowMapper<ScoreEngineVo>(ScoreEngineVo.class));
         ArrayList<ScoreEngineVo> result = (ArrayList<ScoreEngineVo>) jdbcTemplate.query(sql.toString(), new Object[]{BusinessConst.Flag.ACTIVE, warningId}, new RowMapper() {
            public ScoreEngineVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                ScoreEngineVo data = new ScoreEngineVo();
                data.setStateType(StringUtil.getValue(rs.getString("STATE_TYPE")));
                data.setCogsSales(StringUtil.getValue(rs.getString("COGS_SALES")));
                data.setDsceCfo(StringUtil.getValue(rs.getString("DSCR_CFO")));
                data.setDe(StringUtil.getValue(rs.getString("DE")));
                data.setInterestRatio(StringUtil.getValue(rs.getString("INTEREST_RATIO")));
                data.setOperationRote(StringUtil.getValue(rs.getString("OPERATING_ROTE")));
                data.setSlopeProfitMargin(StringUtil.getValue(rs.getString("SLOPE_PROFIT_MARGIN")));
                data.setQuickRatio(StringUtil.getValue(rs.getString("QUICK_RATIO")));
                return data;
            }
        });
        if (result != null && result.size() > 0) {
            return result.get(0);
        }

        return null;
    }

    @Override
    public FinancialVo findCurrentQcaFin(String cifId) throws Exception {
        FinancialVo vo = null;
       if (logger.isInfoEnabled()) {
            logger.info("findCurrentQcaFin");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT FIN_ID, CIF, HV_FIN, REASON_CODE, REASON_DETAIL, FIN_CONFIG_ID, ");
        sql.append(" FIN_TRN_ID, ROLE, USER_ID, IS_ACTIVE, CREATED_DT, ");
        sql.append(" CREATED_BY, UPDATED_DT, UPDATED_BY, WARNING_ID , DELAY_REASON ");
        sql.append(" FROM TBL_QCA_FIN ");
        sql.append(" WHERE CIF = ? AND IS_ACTIVE =  ? ");
            
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
       ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new Object[]{cifId , BusinessConst.Flag.ACTIVE}, new RowMapper() {
            public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                FinancialVo finVo = new FinancialVo();
                finVo.setCifNo(rs.getString("CIF"));
                finVo.setHvFin(rs.getString("HV_FIN"));
                finVo.setReasonCode(rs.getString("REASON_CODE"));
                if(finVo.getHvFin()!=null && !"".equals(finVo.getHvFin())){
                    if("Y".equalsIgnoreCase(finVo.getHvFin())) finVo.setReasonSelectY(finVo.getReasonCode() );
                    else if("N".equalsIgnoreCase(finVo.getHvFin())) finVo.setReasonSelectN(finVo.getReasonCode() );
                }
                finVo.setReasonDetail(rs.getString("REASON_DETAIL"));
                finVo.setDelayReason(rs.getString("DELAY_REASON"));
                return finVo;
            }
        });
       if(!result.isEmpty()){
           vo = (FinancialVo)result.get(0);
       }
       return vo;
       
    }
 
     @Override
    public void updateFinancialFlagByCIF(FinancialVo finVO, UserData userObj, String isActive) throws Exception {
        
        StringBuilder sqlUpdate = new StringBuilder();
        sqlUpdate.append(" UPDATE TBL_QCA_FIN SET ");
        sqlUpdate.append(" IS_ACTIVE = ").append(FinUtil.formatDBString(isActive));
        sqlUpdate.append(", UPDATED_DT = current timestamp ");
        sqlUpdate.append(", UPDATED_BY = ").append(FinUtil.formatDBString(userObj.getEmpNo()));
        sqlUpdate.append(", ROLE = ").append(FinUtil.formatDBString(userObj.getRoleId()));
        sqlUpdate.append(", USER_ID = ").append(FinUtil.formatDBString(userObj.getEmpNo()));

        sqlUpdate.append(" WHERE CIF = '").append(finVO.getCif()).append("'");
        sqlUpdate.append(" AND IS_ACTIVE = '1'");

        logger.info(" updateFinancialFlagByCIF => " + sqlUpdate.toString());
        jdbcTemplate.update(sqlUpdate.toString(), new Object[]{});
    }

    @Override
    public FinancialVo getLastFinancialVO(String cif) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT FIN.FIN_ID, FIN.CIF, FIN.HV_FIN, FIN.REASON_CODE, FIN.REASON_DETAIL, FIN.FIN_CONFIG_ID, FIN.FIN_TRN_ID \n");
        sql.append(" , FINTRN.MODEL_ID_FN_AUDIT, FINTRN.MODEL_ID_FN_ADJUST, FINTRN.MODEL_ID_PRIMARY \n");
        sql.append(" , FINTRN.FIN_STATEMENT_AUDIT_DATE1, FINTRN.FIN_STATEMENT_AUDIT_DATE2, FINTRN.FIN_STATEMENT_AUDIT_DATE3 \n");
        sql.append(" , FINTRN.FIN_STATEMENT_ADJUST_DATE1, FINTRN.FIN_STATEMENT_ADJUST_DATE2, FINTRN.FIN_STATEMENT_ADJUST_DATE3, FINTRN.OPTIMIST_PPN_TM \n");
        sql.append(" , FIN.WARNING_ID  \n");
        sql.append(" FROM TBL_QCA_FIN FIN \n");
        sql.append(" LEFT JOIN TBL_QCA_FIN_TRN FINTRN ON FIN.FIN_TRN_ID = FINTRN.FIN_TRN_ID \n");
        sql.append(" WHERE FIN.CIF = '").append(cif).append("' \n");
        sql.append(" AND FIN.UPDATED_DT = ( \n");
        sql.append(" SELECT MAX(UPDATED_DT) FROM TBL_QCA_FIN WHERE CIF='").append(cif).append("' \n");
        sql.append(" AND HV_FIN='Y')");

        logger.info(" SQL = getLastFinancialVO => " + sql.toString());
        ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
            public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                FinancialVo rtnVO = new FinancialVo();
                rtnVO.setFinId(FinUtil.null2Empty(rs.getString("FIN_ID")));
                rtnVO.setCif(FinUtil.null2Empty(rs.getString("CIF")));
                rtnVO.setHvFin(FinUtil.null2Empty(rs.getString("HV_FIN")));
                rtnVO.setReasonCode(FinUtil.null2Empty(rs.getString("REASON_CODE")));
                if(rtnVO.getHvFin() !=null && !"".equals(rtnVO.getHvFin())){
                    if("Y".equalsIgnoreCase(rtnVO.getHvFin())) rtnVO.setReasonSelectY(rtnVO.getReasonCode());
                    else if("N".equalsIgnoreCase(rtnVO.getHvFin())) rtnVO.setReasonSelectN(rtnVO.getReasonCode());
                }
                rtnVO.setReasonDetail(FinUtil.null2Empty(rs.getString("REASON_DETAIL")));
                rtnVO.setFinConfigId(FinUtil.null2Empty(rs.getString("FIN_CONFIG_ID")));
                rtnVO.setTrnId(FinUtil.null2Empty(rs.getString("FIN_TRN_ID")));
                rtnVO.setModelIdFnAudit(FinUtil.null2Empty(rs.getString("MODEL_ID_FN_AUDIT")));
                rtnVO.setModelIdFnAdjust(FinUtil.null2Empty(rs.getString("MODEL_ID_FN_ADJUST")));
                rtnVO.setModelIdPrimary(FinUtil.null2Empty(rs.getString("MODEL_ID_PRIMARY")));
                rtnVO.setFinStatementAuditDate1(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE1")));
                rtnVO.setFinStatementAuditDate2(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE2")));
                rtnVO.setFinStatementAuditDate3(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE3")));
                rtnVO.setFinStatementAdjustDate1(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE1")));
                rtnVO.setFinStatementAdjustDate2(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE2")));
                rtnVO.setFinStatementAdjustDate3(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE3")));
                rtnVO.setOptimistPpnTm(FinUtil.formatDateTHFull(rs.getTimestamp("OPTIMIST_PPN_TM")));
                rtnVO.setWarningInfoId(rs.getInt("WARNING_ID"));
                return rtnVO;
            }
        });
        FinancialVo resultFinanVo = new FinancialVo();
        if (result != null && result.size()>0) {
            resultFinanVo = (FinancialVo) result.get(0);
        }

        return resultFinanVo;
    }

    @Override
    public FinancialVo getFinancialVOByWarningId(String warningId) throws Exception {
         StringBuilder sql = new StringBuilder();
        sql.append(" SELECT FIN.FIN_ID, FIN.CIF, FIN.HV_FIN, FIN.REASON_CODE, FIN.REASON_DETAIL, FIN.FIN_CONFIG_ID, FIN.FIN_TRN_ID ");
        sql.append(" , FINTRN.MODEL_ID_FN_AUDIT, FINTRN.MODEL_ID_FN_ADJUST, FINTRN.MODEL_ID_PRIMARY ");
        sql.append(" , FINTRN.FIN_STATEMENT_AUDIT_DATE1, FINTRN.FIN_STATEMENT_AUDIT_DATE2, FINTRN.FIN_STATEMENT_AUDIT_DATE3 ");
        sql.append(" , FINTRN.FIN_STATEMENT_ADJUST_DATE1, FINTRN.FIN_STATEMENT_ADJUST_DATE2, FINTRN.FIN_STATEMENT_ADJUST_DATE3, FINTRN.OPTIMIST_PPN_TM ");
        sql.append(" , FIN.WARNING_ID  ");
        sql.append(" FROM TBL_QCA_FIN FIN ");
        sql.append(" LEFT JOIN TBL_QCA_FIN_TRN FINTRN ON FIN.FIN_TRN_ID = FINTRN.FIN_TRN_ID ");
        sql.append(" WHERE FIN.WARNING_ID = '").append(warningId).append("' ");
        sql.append(" AND FIN.UPDATED_DT = ( SELECT MAX(UPDATED_DT) FROM TBL_QCA_FIN WHERE  WARNING_ID = '").append(warningId).append("' ) ");

        logger.info(" SQL = getFinancialVOByWarningId => " + sql.toString());
        ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
            public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                FinancialVo rtnVO = new FinancialVo();
                rtnVO.setFinId(FinUtil.null2Empty(rs.getString("FIN_ID")));
                rtnVO.setCif(FinUtil.null2Empty(rs.getString("CIF")));
                rtnVO.setHvFin(FinUtil.null2Empty(rs.getString("HV_FIN")));
                rtnVO.setReasonCode(FinUtil.null2Empty(rs.getString("REASON_CODE")));
                if(rtnVO.getHvFin() !=null && !"".equals(rtnVO.getHvFin())){
                    if("Y".equalsIgnoreCase(rtnVO.getHvFin())) rtnVO.setReasonSelectY(rtnVO.getReasonCode());
                    else if("N".equalsIgnoreCase(rtnVO.getHvFin())) rtnVO.setReasonSelectN(rtnVO.getReasonCode());
                }
                rtnVO.setReasonDetail(FinUtil.null2Empty(rs.getString("REASON_DETAIL")));
                rtnVO.setFinConfigId(FinUtil.null2Empty(rs.getString("FIN_CONFIG_ID")));
                rtnVO.setTrnId(FinUtil.null2Empty(rs.getString("FIN_TRN_ID")));
                rtnVO.setModelIdFnAudit(FinUtil.null2Empty(rs.getString("MODEL_ID_FN_AUDIT")));
                rtnVO.setModelIdFnAdjust(FinUtil.null2Empty(rs.getString("MODEL_ID_FN_ADJUST")));
                rtnVO.setModelIdPrimary(FinUtil.null2Empty(rs.getString("MODEL_ID_PRIMARY")));
                rtnVO.setFinStatementAuditDate1(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE1")));
                rtnVO.setFinStatementAuditDate2(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE2")));
                rtnVO.setFinStatementAuditDate3(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_AUDIT_DATE3")));
                rtnVO.setFinStatementAdjustDate1(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE1")));
                rtnVO.setFinStatementAdjustDate2(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE2")));
                rtnVO.setFinStatementAdjustDate3(FinUtil.null2Empty(rs.getString("FIN_STATEMENT_ADJUST_DATE3")));
                rtnVO.setOptimistPpnTm(FinUtil.formatDateTHFull(rs.getTimestamp("OPTIMIST_PPN_TM")));
                rtnVO.setWarningInfoId(rs.getInt("WARNING_ID"));
                return rtnVO;
            }
        });
        FinancialVo resultFinanVo = new FinancialVo();
        if (result != null && result.size()>0) {
            resultFinanVo = (FinancialVo) result.get(0);
        }

        return resultFinanVo;
    }
     @Override
    public FinancialVo getFinancialForCalDate(String cif, String warningId) throws Exception {
        FinancialVo vo = null;
        if (logger.isInfoEnabled()) {
             logger.info("getFinancialForCalDate");
         }
        try{
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT FIN.FIN_ID , FIN.CIF ,FIN.WARNING_ID, FIN.HV_FIN,CAL.STATE_TYPE, ");
            sql.append("\n TRN.FIN_STATEMENT_ADJUST_DATE1, ");
            sql.append("\n TRN.FIN_STATEMENT_AUDIT_DATE1, ");
            sql.append("\n TRN.MODEL_ID_FN_ADJUST, ");
            sql.append("\n TRN.MODEL_ID_FN_AUDIT ");
            sql.append("\n FROM TBL_QCA_FIN FIN ");
            sql.append("\n JOIN TBL_QCA_FIN_CAL CAL ");
            sql.append("\n ON FIN.FIN_ID = CAL.FIN_ID ");
            sql.append("\n AND FIN.FIN_TRN_ID = CAL.FIN_TRN_ID ");
            sql.append("\n AND FIN.IS_ACTIVE = '1' "); 
            sql.append("\n LEFT JOIN TBL_QCA_FIN_TRN TRN ");
            sql.append("\n ON FIN.FIN_TRN_ID = TRN.FIN_TRN_ID AND FIN.CIF = TRN.CIF ");
            sql.append("\n WHERE FIN.CIF = ?  AND FIN.WARNING_ID = ?  ");
            if (logger.isDebugEnabled()) {
                logger.debug("SQL >>> " + sql.toString());
            }
           ArrayList<FinancialVo> result = (ArrayList<FinancialVo>) jdbcTemplate.query(sql.toString(), new Object[]{cif , warningId}, new RowMapper() {
                public FinancialVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                    FinancialVo finVo = new FinancialVo();
                    finVo.setCifNo(rs.getString("CIF"));
                    finVo.setFinId(rs.getString("FIN_ID"));
                    finVo.setWarningInfoId(rs.getInt("WARNING_ID"));
                    finVo.setHvFin(rs.getString("HV_FIN"));
                    finVo.setStateType(rs.getString("STATE_TYPE"));
                    finVo.setFinStatementAdjustDate1(rs.getString("FIN_STATEMENT_ADJUST_DATE1"));
                    finVo.setFinStatementAuditDate1(rs.getString("FIN_STATEMENT_AUDIT_DATE1"));
                    finVo.setModelIdFnAdjust(rs.getString("MODEL_ID_FN_ADJUST"));
                    finVo.setModelIdFnAudit(rs.getString("MODEL_ID_FN_AUDIT"));
                    return finVo;
                }
            });
           if(!result.isEmpty()){
               vo = (FinancialVo)result.get(0);
           }
        }catch(Exception e){
           logger.error("Error occur in while process :" + e.getMessage());
        }
       return vo;
    }

    @Override
    public void updateQcaFinInDelayReason(FinancialVo finVO) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateQcaFinInDelayReason");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" UPDATE TBL_QCA_FIN SET  DELAY_REASON = ? , UPDATED_BY = ? , UPDATED_DT = ? ");
        sql.append("\n WHERE  HV_FIN = 'Y' AND IS_ACTIVE = '1' AND CIF = ? AND  WARNING_ID = ? ");

    
        jdbcTemplate.update(sql.toString(), new Object[]{finVO.getDelayReason(),finVO.getUpdatedBy() , finVO.getUpdatedDate() , finVO.getCif() , finVO.getWarningInfoId()});
    }
    
}
