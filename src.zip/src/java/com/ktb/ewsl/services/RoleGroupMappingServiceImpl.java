/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RoleVo;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.UserData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class RoleGroupMappingServiceImpl implements RoleGroupMappingService{
    
     private static Logger logger = Logger.getLogger(RoleGroupMappingServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public ArrayList<RoleVo> getRoleID(UserData entity , String currentDateStr) throws Exception {  
      ArrayList<RoleVo> result = null;
      try{
        if(logger.isInfoEnabled()){
              logger.info("RoleGroupMappingServiceImpl.getRoleID");
         }
           
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ROLE_CODE  , ROLE_NAME  FROM TBL_MT_ROLE ");
        sql.append(" WHERE ROLE_CODE IN ( ");
        sql.append("  SELECT ROLE_CODE FROM TBL_MT_ROLE_GROUP_MAPPING ");
        sql.append("  WHERE COSTCENTER_CODE = '").append(entity.getDeptCode()).append("'");
        sql.append("  AND KTB_FIELD_MAP_GROUP IN (");
        sql.append("       SELECT KTB_FIELD_MAP_GROUP FROM TBL_MT_KTB_FIELD_MAP");
        sql.append("       WHERE KTB_FIELD_MAP = '").append(entity.getKtbFieldMap()).append("')");
        sql.append("  AND IS_ACTIVE = 1     ");
        sql.append("  UNION   ");
        sql.append("  SELECT ROLE_CODE FROM  TBL_MT_ROLE_PRIVILEGE ");
        sql.append("  WHERE EMPLOYEE_ID = '").append(entity.getEmpNo()).append("' AND IS_ACTIVE = 1");
            if((!ValidatorUtil.isNullOrEmpty(currentDateStr))){
                  //sql.append("  AND  ( START_DATE <= TO_DATE('").append(currentDateStr).append("','DD/MM/YYYY') AND  END_DATE >= TO_DATE('").append(currentDateStr).append("','DD/MM/YYYY')) ");
                 sql.append("  AND  (( START_DATE <= TO_DATE('").append(currentDateStr).append("','DD/MM/YYYY') AND  END_DATE >= TO_DATE('").append(currentDateStr).append("','DD/MM/YYYY')) ");
                 sql.append("  OR  ( START_DATE <= TO_DATE('").append(currentDateStr).append("','DD/MM/YYYY') AND  END_DATE IS NULL )  ) ");
            }
        sql.append(" ) ");
        sql.append("ORDER BY SEQ ASC ");
        
        logger.info("[getRoleID] sql :: " + sql.toString());
        
         result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
                    @Override
                    public RoleVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                        RoleVo vo = new RoleVo();
                        vo.setRoleId(rs.getString("ROLE_CODE"));
                        vo.setRoleName(rs.getString("ROLE_NAME"));                       
                        return vo;
                    }
                });
      }catch(Exception e){
          logger.error("Error occur in while process RoleGroupMappingServiceImpl.getRoleID: " + e.getMessage() , e);
      }
      return result;
    }
}
