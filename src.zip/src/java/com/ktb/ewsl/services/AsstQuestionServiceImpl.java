/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AsstChoiceVo;
import com.ktb.ewsl.vo.AsstQuestionVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Tum_Surapong
 */
@Repository
public class AsstQuestionServiceImpl implements AsstQuestionService {

    private static final Logger logger = Logger.getLogger(AsstQuestionServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void saveAsstQuestion(AsstQuestionVo asstQuestionVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("saveAsstQuestion");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ASST_QUESTION (QUESTION_ID,VERSION,QUESTION_DESC,QUESTION_START_DT,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY)");
        sql.append("\nVALUEs(?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{asstQuestionVo.getQuestionId(), asstQuestionVo.getVersion(), asstQuestionVo.getQuestionDesc(), asstQuestionVo.getQuestionStartDt(),
            asstQuestionVo.getCreatedDate(), asstQuestionVo.getCreatedBy(), asstQuestionVo.getUpdatedDate(), asstQuestionVo.getUpdatedBy()});
    }

    @Override
    public void saveAsstTopic(AsstTopicVo asstTopicVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("saveAsstTopic");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ASST_TOPIC (QUESTION_ID,VERSION,TOPIC_ID,TOPIC_DESC,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY)");
        sql.append("\nVALUEs(?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{asstTopicVo.getQuestionId(), asstTopicVo.getVersion(), asstTopicVo.getTopicId(), asstTopicVo.getTopicDesc(),
            asstTopicVo.getCreatedDate(), asstTopicVo.getCreatedBy(), asstTopicVo.getUpdatedDate(), asstTopicVo.getUpdatedBy()});
    }

    @Override
    public void saveAsstSubTopic(AsstSubtopicVo asstSubtopicVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("saveAsstSubTopic");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ASST_SUBTOPIC (QUESTION_ID,VERSION,TOPIC_ID,SUB_TOPIC_ID,SUB_TOPIC_DESC,NEED_CHOICE,CHOICE_TYPE,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY)");
        sql.append("\nVALUEs(?,?,?,?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{asstSubtopicVo.getQuestionId(), asstSubtopicVo.getVersion(), asstSubtopicVo.getTopicId(), asstSubtopicVo.getSubTopicId(), asstSubtopicVo.getSubTopicDesc(), asstSubtopicVo.getNeedChoice(), asstSubtopicVo.getChoiceType(),
            asstSubtopicVo.getCreatedDate(), asstSubtopicVo.getCreatedBy(), asstSubtopicVo.getUpdatedDate(), asstSubtopicVo.getUpdatedBy()});
    }

    @Override
    public void saveAsstChoice(AsstChoiceVo asstChoiceVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("saveAsstChoice");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ASST_CHOICE (QUESTION_ID,VERSION,TOPIC_ID,SUB_TOPIC_ID,CHOICE_ID,CHOICE_DESC,CHOICE_REASON_FLAG,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY)");
        sql.append("\nVALUEs(?,?,?,?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{asstChoiceVo.getQuestionId(), asstChoiceVo.getVersion(), asstChoiceVo.getTopicId(), asstChoiceVo.getSubTopicId(), asstChoiceVo.getChoiceId(), asstChoiceVo.getChoiceDesc(), asstChoiceVo.getChoiceReasonFlag(),
            asstChoiceVo.getCreatedDate(), asstChoiceVo.getCreatedBy(), asstChoiceVo.getUpdatedDate(), asstChoiceVo.getUpdatedBy()});
    }

    @Override
    public List<AsstTopicVo> findTopicByQuestion(String questionId, String version) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findTopicByQuestion");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstTopic.QUESTION_ID,asstTopic.VERSION,asstTopic.TOPIC_ID,asstTopic.TOPIC_DESC");
        sql.append("\nFROM TBL_ASST_TOPIC asstTopic");
        sql.append("\nWHERE asstTopic.QUESTION_ID = ?");
        sql.append("\nAND asstTopic.VERSION = ?");
        sql.append("\nORDER BY asstTopic.TOPIC_ID");

        List<AsstTopicVo> asstTopicVoList = jdbcTemplate.query(sql.toString(), new Object[]{questionId, version}, new BeanPropertyRowMapper<AsstTopicVo>(AsstTopicVo.class));

        return asstTopicVoList;
    }

    @Override
    public List<AsstSubtopicVo> findSubtopicByTopic(List<Integer> topicIdList, String questionId, String version, int warningId , String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findSubtopicByTopic >> "+warningId+","+questionId+","+version +","+roleCode);
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT asstSubtopic.QUESTION_ID,asstSubtopic.VERSION,asstSubtopic.TOPIC_ID, asstSubtopic.SUB_TOPIC_ID ,asstSubtopic.SUB_TOPIC_DESC,asstSubtopic.NEED_CHOICE,asstSubtopic.CHOICE_TYPE ");
        sql.append("\n ,asstAnswer.CHOICE_ID as answer,asstAnswer.CHOICE_REASON ");
        sql.append("\n FROM TBL_ASST_SUBTOPIC asstSubtopic ");
        sql.append("\n LEFT JOIN TBL_ASST_ANSWER asstAnswer  ");
        sql.append("\n ON asstSubtopic.QUESTION_ID = asstAnswer.QUESTION_ID  ");
        sql.append("\n AND asstSubtopic.VERSION = asstAnswer.VERSION  ");
        sql.append("\n AND asstSubtopic.TOPIC_ID = asstAnswer.TOPIC_ID ");
        sql.append("\n AND asstSubtopic.SUB_TOPIC_ID = asstAnswer.SUB_TOPIC_ID AND asstAnswer.WARNING_ID = ?  AND asstAnswer.ROLE_CODE IN ( ").append(roleCode).append(" )");
        sql.append("\n WHERE asstSubtopic.QUESTION_ID = ?  ");
        sql.append("\n AND asstSubtopic.VERSION = ? ");

        int allSize = topicIdList.size();
        Object[] obj = new Object[allSize + 3];
        obj[0] = warningId;
        //obj[1] = roleCode;
        obj[1] = questionId;
        obj[2] = version;
        int idx = 3;
        if (!topicIdList.isEmpty()) {
            int size = topicIdList.size();
            sql.append("\n AND asstSubtopic.TOPIC_ID IN (");

            for (int i = 0; i < size; i++) {
                obj[idx] = topicIdList.get(i);
                if (i > 0) {
                    sql.append(",");
                }
                sql.append("?");
                idx++;
            }
            sql.append(")");
        }

        sql.append("\n ORDER BY asstSubtopic.TOPIC_ID,asstSubtopic.SUB_TOPIC_ID  ");

        List<AsstSubtopicVo> asstSubtopicVoList = jdbcTemplate.query(sql.toString(), obj, new BeanPropertyRowMapper<AsstSubtopicVo>(AsstSubtopicVo.class));
        return asstSubtopicVoList;
    }

    @Override
    public List<AsstChoiceVo> findChoiceByFilter(List<Integer> topicIdList, List<Integer> subtopicIdList, String questionId, String version) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findChoiceByFilter");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstchoice.QUESTION_ID,asstchoice.VERSION,asstchoice.TOPIC_ID,asstchoice.SUB_TOPIC_ID,asstchoice.CHOICE_ID,asstchoice.CHOICE_DESC,asstchoice.CHOICE_REASON_FLAG");
        sql.append("\nFROM TBL_ASST_CHOICE asstchoice");
        sql.append("\nWHERE asstchoice.QUESTION_ID = ?");
        sql.append("\nAND asstchoice.VERSION = ?");

        int allSize = topicIdList.size() + subtopicIdList.size();
        Object[] obj = new Object[allSize + 2];
        obj[0] = questionId;
        obj[1] = version;
        int idx = 2;
        if (!topicIdList.isEmpty()) {
            int size = topicIdList.size();
            sql.append("\nAND asstchoice.TOPIC_ID IN (");

            for (int i = 0; i < size; i++) {
                obj[idx] = topicIdList.get(i);
                if (i > 0) {
                    sql.append(",");
                }
                sql.append("?");
                idx++;
            }
            sql.append(")");
        }

        if (!subtopicIdList.isEmpty()) {
            int size = subtopicIdList.size();
            sql.append("\nAND asstchoice.SUB_TOPIC_ID IN (");
            for (int i = 0; i < size; i++) {
                obj[idx] = subtopicIdList.get(i);
                if (i > 0) {
                    sql.append(",");
                }
                sql.append("?");
                idx++;
            }
            sql.append(")");
        }

        sql.append("\nORDER BY asstchoice.TOPIC_ID,asstchoice.SUB_TOPIC_ID,asstchoice.CHOICE_ID");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<AsstChoiceVo> asstChoiceVoList = jdbcTemplate.query(sql.toString(), obj, new BeanPropertyRowMapper<AsstChoiceVo>(AsstChoiceVo.class));

        return asstChoiceVoList;
    }
    
    @Override
    public List<AsstTopicVo> findTopicByWarningType(String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findTopicByWarningType");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstTopic.QUESTION_ID,asstTopic.VERSION,asstTopic.TOPIC_ID,asstTopic.TOPIC_DESC,warningType.WARNING_TYPE_DESC ");
        sql.append("\nFROM TBL_ASST_TOPIC asstTopic");
        sql.append("\nINNER JOIN TBL_WARNING_TYPE warningType");
        sql.append("\nON asstTopic.QUESTION_ID = warningType.QUESTION_ID");
        sql.append("\nAND asstTopic.VERSION = warningType.QUESTION_VERSION");
        sql.append("\nAND warningType.WARNING_TYPE_CODE = ?");
        
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<AsstTopicVo> asstTopicVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningType}, new BeanPropertyRowMapper<AsstTopicVo>(AsstTopicVo.class));

        return asstTopicVoList;
    }

    @Override
    public List<AsstSubtopicVo> findSubtopic(int topicId , String questionId, String version) throws Exception {
        List<AsstSubtopicVo> subtopic = null;
        try{
        if (logger.isInfoEnabled()) {
            logger.info("findSubtopic");
            logger.info(" topicId =>" + topicId);
            logger.info(" questionId =>" + questionId);
            logger.info(" version =>" + version);
        }

        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT  QUESTION_ID,VERSION,TOPIC_ID,SUB_TOPIC_ID, SUB_TOPIC_DESC,NEED_CHOICE,CHOICE_TYPE ");
        sql.append("\n FROM TBL_ASST_SUBTOPIC ");
        sql.append("\n WHERE TOPIC_ID = ? AND QUESTION_ID = ? AND VERSION = ? ");
        sql.append("\n ORDER BY SUB_TOPIC_ID ASC ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
         subtopic = jdbcTemplate.query(sql.toString(), new Object[]{topicId ,questionId, version}, new BeanPropertyRowMapper<AsstSubtopicVo>(AsstSubtopicVo.class));        
        }catch(Exception e){
           e.printStackTrace();
        }
        return subtopic;
    }

    @Override
    public Integer getLastSubTopic(String questionId, String version) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("getLastSubTopic");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT MAX(SUB_TOPIC_ID) FROM TBL_ASST_SUBTOPIC ");
        sql.append(" WHERE QUESTION_ID = ? AND VERSION = ? ");

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{questionId,version}, Integer.class);
    }
}