/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.AnnouncementVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KapookZa
 */
@Repository
public class AnnouncementServiceImpl extends AbstractJdbcService implements AnnouncementService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private static final Logger logger = Logger.getLogger(AnnouncementServiceImpl.class);

    @Override
    public Integer saveAnnouncement(AnnouncementVo announcementVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("AnnouncementServiceImpl.saveAnnouncement");
        }

        try {

            StringBuilder sql = new StringBuilder();
            StringBuilder column = new StringBuilder("");
            StringBuilder statment = new StringBuilder("");
            List<Object> params = new ArrayList<Object>();

            column.append("SEQ");
            statment.append("?");
            params.add(announcementVo.getSeq());
            logger.info("SEQ :: " + announcementVo.getSeq());

            column.append(",ANNOUNCE_DATE");
            statment.append(",to_date(?, 'ddMMyyyy')");
            params.add(DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStr(), true));
            logger.info(",ANNOUNCE_DATE :: " + DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStr(), true));

            column.append(",ANNOUNCE_TITLE");
            statment.append(",?");
            params.add(announcementVo.getAnnounceTitle());
            logger.info("ANNOUNCE_TITLE :: " + announcementVo.getAnnounceTitle());

            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceStartDateStr())) {
                column.append(",ANNOUNCE_START_DT");
                statment.append(",to_date(?, 'ddMMyyyy')");
                params.add(DateUtil.convertThEnYearStr(announcementVo.getAnnounceStartDateStr(), true));
                logger.info("ANNOUNCE_START_DT :: " + DateUtil.convertThEnYearStr(announcementVo.getAnnounceStartDateStr(), true));
            }
            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceStartDateStr())) {
                column.append(",ANNOUNCE_END_DT");
                statment.append(",to_date(?, 'ddMMyyyy')");
                params.add(DateUtil.convertThEnYearStr(announcementVo.getAnnounceEndDateStr(), true));
                logger.info("ANNOUNCE_END_DT :: " + DateUtil.convertThEnYearStr(announcementVo.getAnnounceEndDateStr(), true));
            }

            column.append(",NEW_FLAG");
            statment.append(",?");
            params.add(announcementVo.getNewFlag());
            logger.info("NEW_FLAG :: " + announcementVo.getNewFlag());

            column.append(",UPDATE_FLAG");
            statment.append(",?");
            params.add(announcementVo.getUpdateFlag());
            logger.info("UPDATE_FLAG :: " + announcementVo.getUpdateFlag());

            column.append(",CREATED_DT");
            statment.append(",?");
            params.add(announcementVo.getCreatedDate());
            logger.info("CREATED_DT :: " + announcementVo.getCreatedDate());

            column.append(",CREATED_BY");
            statment.append(",?");
            params.add(announcementVo.getCreatedBy());
            logger.info("CREATED_BY :: " + announcementVo.getCreatedBy());

            column.append(",UPDATED_DT");
            statment.append(",?");
            params.add(announcementVo.getUpdatedDate());
            logger.info("UPDATED_DT :: " + announcementVo.getUpdatedDate());

            column.append(",UPDATED_BY");
            statment.append(",?");
            params.add(announcementVo.getUpdatedBy());
            logger.info("UPDATED_BY :: " + announcementVo.getUpdatedBy());

            column.append(",IS_ACTIVE");
            statment.append(",?");
            params.add(announcementVo.getIsActive());
            logger.info("IS_ACTIVE :: " + announcementVo.getIsActive());

            column.append(",ANNOUNCE_DETAIL");
            statment.append(",?");
            params.add(announcementVo.getAnnounceDetail());
            logger.info("ANNOUNCE_DETAIL :: " + announcementVo.getAnnounceDetail());

            sql.append("INSERT INTO TBL_ANNOUNCEMENT (").append(column.toString()).append(")");
            sql.append("\n VALUES(").append(statment.toString()).append(")");

            logger.info("[saveAnnouncement] sql :: " + sql.toString());

            int rows = jdbcTemplate.update(sql.toString(), params.toArray());

            logger.info("[saveAnnouncement] rows :: " + rows);

        } catch (Exception e) {
            logger.error(e);
            throw e;
        }
        return announcementVo.getSeq();
    }

    @Override
    public Integer getSeq() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("AnnouncementServiceImpl.getSeq");
        }
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT MAX(SEQ) FROM TBL_ANNOUNCEMENT ");
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{}, Integer.class);
    }

    @Override
    public void deleteAnnouncement(int seq,String updatedBy) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("AnnouncementServiceImpl.deleteAnnouncement");
        }

        StringBuilder sql = new StringBuilder();

        try {

            sql.append("UPDATE TBL_ANNOUNCEMENT ");            
            sql.append("SET IS_ACTIVE = 0 ,UPDATED_DT= sysdate , UPDATED_BY = ? WHERE SEQ = ? ");
            if (logger.isInfoEnabled()) {
                logger.info("sql=>" + sql.toString());
            }
            jdbcTemplate.update(sql.toString(), new Object[]{updatedBy ,seq});
        } catch (Exception e) {
            logger.error(e);
            throw e;
        }
    }
    
    @Override
    public PaginatedListImpl<AnnouncementVo> getListPostAnnouncement(PaginatedListImpl<AnnouncementVo> paginate) throws Exception{
    	List<AnnouncementVo> resultList = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("AnnouncementServiceImpl.getListPostAnnouncement");
            }
            StringBuilder sql = new StringBuilder();

            sql.append(" SELECT *  ");
            sql.append("\n FROM TBL_ANNOUNCEMENT ");
            sql.append("\n WHERE 1=1 ")
            .append("\n AND IS_ACTIVE=1")
            .append("\n AND current date between announce_start_dt and ANNOUNCE_END_DT");
            
            sql.append("\n ORDER BY  ANNOUNCE_DATE DESC ");
            if (logger.isInfoEnabled()) {
                logger.info("sql=>" + sql.toString());
            }
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
            	
                String rowNumSql = null;
                if(paginate.getPageSize()>0)
                	decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize());
                else
                	rowNumSql = sql.toString();
                
                resultList = jdbcTemplate.query(rowNumSql.toString(), new RowMapper<AnnouncementVo>() {
                    @Override
                    public AnnouncementVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                        AnnouncementVo item = new AnnouncementVo();
                        item.setSeq(rs.getInt("SEQ"));
                        item.setAnnounceDate(rs.getDate("ANNOUNCE_DATE"));
                        item.setAnnounceDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_DATE")));
                        item.setAnnounceTitle(rs.getString("ANNOUNCE_TITLE"));
                        item.setAnnounceStartDate(rs.getDate("ANNOUNCE_START_DT"));
                        item.setAnnounceStartDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_START_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_START_DT")));
                        item.setAnnounceEndDate(rs.getDate("ANNOUNCE_END_DT"));
                        item.setAnnounceEndDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_END_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_END_DT")));
                        item.setNewFlag(rs.getString("NEW_FLAG"));
                        item.setUpdateFlag(rs.getString("UPDATE_FLAG"));
                        item.setCreatedDate(rs.getDate("CREATED_DT"));
                        item.setCreatedDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CREATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CREATED_DT")));
                        item.setCreatedBy(rs.getString("CREATED_BY"));
                        item.setIsActive(rs.getInt("IS_ACTIVE"));
                        if (item.getIsActive() == 1) {
                            item.setStatusDesc("Active");
                        } else {
                            item.setStatusDesc("In Active");
                        }
                        item.setAnnounceDetail(rs.getString("ANNOUNCE_DETAIL"));

                        return item;
                    }
                });

            }//SQL IS NULL
            int totalRecord = countTotal(sql.toString());
            paginate.setTotalRecord(totalRecord);
//            paginate.setFullListSizeWithPaging(totalRecord, paginate.getPageSize());
            paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
            paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
            paginate.setList((ArrayList<AnnouncementVo>)resultList);

        } catch (Exception e) {
            logger.error("Error occur in while process AnnouncementServiceImpl.getListAnnouncement: " + e.getMessage(), e);
            throw e;
        }
        return paginate;
    }

    @Override
    public PaginatedListImpl getListAnnouncement(AnnouncementVo announcementVo, PaginatedListImpl paginate, int pageAmt) throws Exception {
        ArrayList<AnnouncementVo> resultList = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("AnnouncementServiceImpl.getListAnnouncement");
                if (announcementVo != null) {
                    logger.info("announcementVo.getAnnounceTitle():" + announcementVo.getAnnounceTitle());
                    logger.info("announcementVo.getAnnounceDateStrFrom():" + announcementVo.getAnnounceDateStrFrom());
                    logger.info("announcementVo.getAnnounceDateStrTo():" + announcementVo.getAnnounceDateStrTo());
                    logger.info("announcementVo.getIsActive():" + announcementVo.getIsActive());
                }
            }
            StringBuilder sql = new StringBuilder();

            sql.append(" SELECT *  ");
            sql.append("\n FROM TBL_ANNOUNCEMENT ");
            sql.append("\n WHERE 1=1 ");

            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getIsActive())) {
                sql.append(" AND IS_ACTIVE = ").append(announcementVo.getIsActive());
            }
            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceTitle())) {
                sql.append(" AND UPPER(ANNOUNCE_TITLE) LIKE '%").append(announcementVo.getAnnounceTitle().toUpperCase().trim()).append("%' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceDateStrFrom())) {
                sql.append(" AND trunc(ANNOUNCE_DATE) >= TO_DATE('").append(DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStrFrom(), true)).append("','ddMMyyyy') ");
            }
            if(!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceDateStrTo())) {
            	sql.append(" AND trunc(ANNOUNCE_DATE) <= TO_DATE('").append(DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStrTo(), true)).append("','ddMMyyyy') ");
            }

            sql.append("\n ORDER BY  ANNOUNCE_DATE DESC ");
            if (logger.isInfoEnabled()) {
                logger.info("sql=>" + sql.toString());
            }
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                String rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize());
                resultList = (ArrayList<AnnouncementVo>) jdbcTemplate.query(rowNumSql.toString(), new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        AnnouncementVo item = new AnnouncementVo();
                        item.setSeq(rs.getInt("SEQ"));
                        item.setAnnounceDate(rs.getDate("ANNOUNCE_DATE"));
                        item.setAnnounceDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_DATE")));
                        item.setAnnounceTitle(rs.getString("ANNOUNCE_TITLE"));
                        item.setAnnounceStartDate(rs.getDate("ANNOUNCE_START_DT"));
                        item.setAnnounceStartDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_START_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_START_DT")));
                        item.setAnnounceEndDate(rs.getDate("ANNOUNCE_END_DT"));
                        item.setAnnounceEndDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_END_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_END_DT")));
                        item.setNewFlag(rs.getString("NEW_FLAG"));
                        item.setUpdateFlag(rs.getString("UPDATE_FLAG"));
                        item.setCreatedDate(rs.getDate("CREATED_DT"));
                        item.setCreatedDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CREATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CREATED_DT")));
                        item.setCreatedBy(rs.getString("CREATED_BY"));
                        item.setIsActive(rs.getInt("IS_ACTIVE"));
                        if (item.getIsActive() == 1) {
                            item.setStatusDesc("Active");
                        } else {
                            item.setStatusDesc("In Active");
                        }
                        item.setAnnounceDetail(rs.getString("ANNOUNCE_DETAIL"));

                        return item;
                    }
                });

            }//SQL IS NULL
            int totalRecord = countTotal(sql.toString());
            paginate.setTotalRecord(totalRecord);
            paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
            paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
            paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
            paginate.setList(resultList);

        } catch (Exception e) {
            logger.error("Error occur in while process AnnouncementServiceImpl.getListAnnouncement: " + e.getMessage(), e);
            throw e;
        }
        return paginate;
    }

    @Override
    public AnnouncementVo getAnnouncementVo(AnnouncementVo announcementVo) throws Exception {
        AnnouncementVo announcementVoRtn = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("AnnouncementServiceImpl.getAnnouncementVo" + announcementVo.getSeq());
            }
            StringBuilder sql = new StringBuilder();

            sql.append(" SELECT  A.*,length(ANNOUNCE_DETAIL) detail_length  ");
            sql.append("\n FROM TBL_ANNOUNCEMENT A ");
            sql.append("\n WHERE 1=1 ");

            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getSeq())) {
                sql.append(" AND SEQ = ").append(announcementVo.getSeq());
            }

            if (logger.isInfoEnabled()) {
                logger.info("sql getAnnouncementVo=>" + sql.toString());
            }

            List<AnnouncementVo> resultList = jdbcTemplate.query(sql.toString(), new RowMapper() {
                @Override
                public AnnouncementVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                    AnnouncementVo item = new AnnouncementVo();
                    item.setSeq(rs.getInt("SEQ"));
                    item.setAnnounceDate(rs.getDate("ANNOUNCE_DATE"));
                    item.setAnnounceDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_DATE")));
                    item.setAnnounceTitle(rs.getString("ANNOUNCE_TITLE"));
                    item.setAnnounceStartDate(rs.getDate("ANNOUNCE_START_DT"));
                    item.setAnnounceStartDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_START_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_START_DT")));
                    item.setAnnounceEndDate(rs.getDate("ANNOUNCE_END_DT"));
                    item.setAnnounceEndDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ANNOUNCE_END_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("ANNOUNCE_END_DT")));
                    item.setNewFlag(rs.getString("NEW_FLAG"));
                    item.setUpdateFlag(rs.getString("UPDATE_FLAG"));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setCreatedDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CREATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CREATED_DT")));
                    item.setCreatedBy(rs.getString("CREATED_BY"));
                    item.setIsActive(rs.getInt("IS_ACTIVE"));
                    java.sql.Clob aclob = rs.getClob("ANNOUNCE_DETAIL");
                    String announceDetail = new String(aclob.getSubString(1l, (int) aclob.length()));
                    item.setAnnounceDetail(announceDetail);
                    if (item.getIsActive() == 1) {
                        item.setStatusDesc("Active");
                    } else {
                        item.setStatusDesc("In Active");
                    }
                    //item.setAnnounceDetail(rs.getString("ANNOUNCE_DETAIL"));
                    item.setAnnounceDetailLength(rs.getInt("detail_length"));

                    return item;
                }
            });
            if (resultList != null && resultList.size() > 0) {
                announcementVoRtn = (AnnouncementVo) resultList.get(0);
//                setClobData(announcementVoRtn);
            }


        } catch (Exception e) {
            logger.error("Error occur in while process AnnouncementServiceImpl.getAnnouncementVo: " + e.getMessage(), e);
            throw e;
        }
        return announcementVoRtn;
    }

    @Override
    public void updateAnnouncement(AnnouncementVo announcementVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("AnnouncementServiceImpl.updateAnnouncement");
        }

        StringBuilder sql = new StringBuilder();

        try {
            StringBuilder field = new StringBuilder("");


            if ("99999999".equals(announcementVo.getAnnounceStartDateStr()) && ("99999999".equals(announcementVo.getAnnounceEndDateStr()))) {
                announcementVo.setAnnounceStartDateStr(null);
                announcementVo.setAnnounceEndDateStr(null);
            }

            field.append("ANNOUNCE_TITLE = '");
            field.append(announcementVo.getAnnounceTitle());
            field.append("'");
            logger.info("ANNOUNCE_TITLE :: " + announcementVo.getAnnounceTitle());

            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceDateStr())) {
                field.append(",ANNOUNCE_DATE = ");
                field.append("to_date('").append(DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStr(), true)).append("', 'ddMMyyyy')");
                logger.info(",ANNOUNCE_DATE :: " + DateUtil.convertThEnYearStr(announcementVo.getAnnounceDateStr(), true));
            }

            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceStartDateStr())) {
                field.append(",ANNOUNCE_START_DT = ");
                field.append("to_date('").append(DateUtil.convertThEnYearStr(announcementVo.getAnnounceStartDateStr(), true)).append("', 'ddMMyyyy')");
                logger.info("ANNOUNCE_START_DT :: " + DateUtil.convertThEnYearStr(announcementVo.getAnnounceStartDateStr(), true));
            }
            if (!ValidatorUtil.isNullOrEmpty(announcementVo.getAnnounceEndDateStr())) {
                field.append(",ANNOUNCE_END_DT = ");
                field.append("to_date('").append(DateUtil.convertThEnYearStr(announcementVo.getAnnounceEndDateStr(), true)).append("', 'ddMMyyyy')");
                logger.info("ANNOUNCE_END_DT :: " + DateUtil.convertThEnYearStr(announcementVo.getAnnounceEndDateStr(), true));
            }

            field.append(",NEW_FLAG = '");
            field.append(announcementVo.getNewFlag());
            field.append("'");
            logger.info("NEW_FLAG :: " + announcementVo.getNewFlag());

            field.append(",UPDATE_FLAG = '");
            field.append(announcementVo.getUpdateFlag());
            field.append("'");
            logger.info("UPDATE_FLAG :: " + announcementVo.getUpdateFlag());

            field.append(",UPDATED_DT = sysdate");


            field.append(",UPDATED_BY= '");
            field.append(announcementVo.getUpdatedBy());
            field.append("'");
            logger.info("UPDATED_BY :: " + announcementVo.getUpdatedBy());

            field.append(",IS_ACTIVE =");
            field.append(announcementVo.getIsActive());
            logger.info("IS_ACTIVE :: " + announcementVo.getIsActive());

            field.append(",ANNOUNCE_DETAIL=?");
       
//            logger.info("ANNOUNCE_DETAIL :: " + announcementVo.getAnnounceDetail());

            sql.append("UPDATE TBL_ANNOUNCEMENT SET ").append(field);
            sql.append(" WHERE SEQ = ? ");
            if (logger.isInfoEnabled()) {
                logger.info("sql=>" + sql.toString());
            }
            jdbcTemplate.update(sql.toString(), new Object[]{announcementVo.getAnnounceDetail(),announcementVo.getSeq()});
        } catch (Exception e) {
            logger.error("Error occur in while process AnnouncementServiceImpl.updateAnnouncement: " + e.getMessage(), e);
            throw e;
        }
    }

    private void setClobData(AnnouncementVo vo) throws Exception {
        logger.info("[setClobData][Begin]");

        String sql = "";
        int announcementDetailLength = 0;
        int byteNum = 32000;
        int begin = 1;
        int end = 0;
        String detail = "";


        try {
            announcementDetailLength = vo.getAnnounceDetailLength();

            logger.info("[setClobData] getAnnounceDetailLength  :: " + announcementDetailLength);


            if (announcementDetailLength > 0) {
                while (begin < announcementDetailLength) {

                    end = (begin + end) < announcementDetailLength ? byteNum : (announcementDetailLength - begin);

                    sql = "select cast(substr(ANNOUNCE_DETAIL, " + begin + ", " + end + ") as varchar(" + byteNum + ")) as detail "
                            + " from EWSWDBA.TBL_ANNOUNCEMENT "
                            + " where seq = " + vo.getSeq();

                    ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql, new RowMapper() {
                        @Override
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            return rs.getString("detail");
                        }
                    });

                    detail += result.get(0) == null ? "" : result.get(0);
                    begin = begin + byteNum;

                }
            }
            vo.setAnnounceDetail(detail);
        } catch (Exception e) {
            logger.error("setClobData error :: " + e);
            throw e;
        } finally {
            logger.info("[setClobData][End]");
        }
    }
}
