/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktb.ewsl.vo.CountDataVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.ReportCloseJobVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Tum_Surapong
 */
@Repository
public class ActionCloseServiceImpl extends AbstractJdbcService implements ActionCloseService{
    private static final Logger log = Logger.getLogger(ActionCloseServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void saveData(ActionCloseVo vo) throws Exception{
        if(log.isInfoEnabled()){
            log.info("saveData");
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ACTION_CLOSE (WARNING_HEAD_ID,ACTION_DT,ACTION_BY,REASON_DESC,STATUS,REMARK,WARNING_ID,ROLE_CODE)");
        sql.append("\nVALUES(?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{vo.getWarningHeadId(), vo.getActionDt(), vo.getActionBy(), vo.getReasonDetail(),
                vo.getStatus(),vo.getRemark(), vo.getWarningId(),vo.getRoleCode()}
        );
    }
    
    @Override
    public List<ActionCloseVo> findDataByWarningHeadId(Integer warningHeadId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataByWarningHeadId");
        }
        StringBuilder sql = new StringBuilder();
//        sql.append("SELECT actionClose.ACTION_DT,actionClose.ACTION_BY,actionClose.REMARK,actionClose.REASON_CODE,mtConfig.CONFIG_VALUE as reasonDetail FROM TBL_ACTION_CLOSE actionClose");
//        sql.append("\nLEFT JOIN TBL_MT_CONFIG mtConfig ON actionClose.REASON_CODE = mtConfig.CONFIG_CODE AND mtConfig.CONFIG_GROUP_CODE = ?");
//        sql.append("\nWHERE actionClose.WARNING_HEAD_ID = ? AND actionClose.WARNING_ID = 0");
//        sql.append("\nORDER BY actionClose.ACTION_DT DESC");
        
        sql.append(" SELECT actionClose.ACTION_DT,actionClose.ACTION_BY,actionClose.REMARK,actionClose.REASON_CODE,actionClose.REASON_DESC as reasonDetail \n");
        sql.append(" FROM TBL_ACTION_CLOSE actionClose                                                                                                     \n");
        sql.append(" WHERE actionClose.WARNING_HEAD_ID = ? AND actionClose.WARNING_ID = 0                                                                  \n");
        sql.append(" ORDER BY actionClose.ACTION_DT DESC                                                                                                   \n");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }
        
//        List<ActionCloseVo> actionCloseVoList = jdbcTemplate.query(sql.toString(), new Object[]{BusinessConst.CONFIG_GROUP.CLOSEJOB,warningHeadId}, new BeanPropertyRowMapper<ActionCloseVo>(ActionCloseVo.class));
        List<ActionCloseVo> actionCloseVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId}, new BeanPropertyRowMapper<ActionCloseVo>(ActionCloseVo.class));
        return actionCloseVoList;
    }
     
    @Override
    public List<ReportCloseJobVo> getDataByWarningHeadIdForEwsl(Integer warningHeadId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("getDataByWarningHeadIdForEwsl");
        }
        StringBuilder sql = new StringBuilder();
        
        sql.append("select t.* from (");
        sql.append("    (select ACTION_CLOSE.WARNING_HEAD_ID");
        sql.append("            ,'JOB' as close_job_flg");
        sql.append("            ,'Job-'||WARNING_TYPE.warning_type_desc as close_job_type");
        sql.append("            ,nvl(ACTION_CLOSE.REASON_DESC, '') as REASON_DESC");
        sql.append("            ,nvl(ACTION_CLOSE.REMARK, '') REMARK");
        sql.append("            ,ACTION_CLOSE.action_dt as created_dt");
        sql.append("            ,ACTION_CLOSE.action_by as created_by");
        sql.append("        from TBL_ACTION_CLOSE ACTION_CLOSE");
        sql.append("            inner JOIN TBL_WARNING_INFO WARNING_INFO on ACTION_CLOSE.warning_id = WARNING_INFO.warning_id");
        sql.append("            inner JOIN TBL_WARNING_TYPE WARNING_TYPE on WARNING_INFO.warning_type = WARNING_TYPE.warning_type_code)");
        sql.append("    union");
        sql.append("    (SELECT WARNING_CLOSE.WARNING_HEAD_ID");
        sql.append("            ,'CIF' as close_job_flg");
        sql.append("            ,'CIF' as close_job_type");
        sql.append("            ,nvl(MT_PARAMETER.PARAMETER_NAME, '') AS REASON_DESC");
        sql.append("            ,nvl(WARNING_CLOSE.REMARK, '') as REMARK");
        sql.append("            ,WARNING_CLOSE.created_dt");
        sql.append("            ,WARNING_CLOSE.created_by");
        sql.append("        FROM TBL_WARNING_CLOSE WARNING_CLOSE");
        sql.append("            LEFT JOIN TBL_MT_PARAMETER MT_PARAMETER ON WARNING_CLOSE.REASON_FLG = MT_PARAMETER.PARAMETER_ID AND MT_PARAMETER.PARAMETER_TYPE_ID = 'CLOSE_BY_CIF_REASON')");
        sql.append("     ) t");
        sql.append("    where t.WARNING_HEAD_ID  = ? order by t.created_dt asc");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }
        
        ArrayList<ReportCloseJobVo> reportList = (ArrayList<ReportCloseJobVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId}, new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ReportCloseJobVo vo = new ReportCloseJobVo();
                            vo.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            vo.setCloseJobFlg(StringUtil.getValue(rs.getString("close_job_flg")));
                            vo.setCloseJobType(StringUtil.getValue(rs.getString("close_job_type")));
                            vo.setReasonDetail(StringUtil.getValue(rs.getString("REASON_DESC")));
                            vo.setRemark(StringUtil.getValue(rs.getString("REMARK")));
                            vo.setCrDt(rs.getDate("created_dt"));
                            vo.setCrDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("created_dt")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("created_dt")));
                            vo.setCrBy(StringUtil.getValue(rs.getString("created_by")));
                            
                            return vo;
                            
                        }
                    });
        
        return reportList;
    }
   
    @Override
    public PaginatedListImpl getCloseListReportEwsl(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt, String roleQuery) throws Exception {
        ArrayList<ReportCloseJobVo> reportList  = null;
        ArrayList<CountDataVo>      cdList      = null;
        
        try {
            if (log.isInfoEnabled()) {
                log.info("ActionCloseServiceImpl.getCloseListReportEwsl");
            }
          
            StringBuilder sql = getSQLCloseListReportEwsl(searchBean);//getSQLCloseListReport(searchBean);
            
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                String rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize());
                    reportList = (ArrayList<ReportCloseJobVo>) jdbcTemplate.query(rowNumSql.toString(), new RowMapper() {
                        @Override
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ReportCloseJobVo closeVo = new ReportCloseJobVo();
                            closeVo.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            closeVo.setWarningType(StringUtil.getValue(rs.getString("warning_type")));
                            closeVo.setCloseJobType(StringUtil.getValue(rs.getString("close_job_type")));
                            closeVo.setReasonDetail(StringUtil.getValue(rs.getString("REASON_DESC")));
                            closeVo.setRemark(StringUtil.getValue(rs.getString("REMARK")));
                            closeVo.setApproveBy(StringUtil.getValue(rs.getString("approv_user")));
                            closeVo.setApproveDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("approv_date")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("approv_date")));
                            closeVo.setActionBy(StringUtil.getValue(rs.getString("trans_user")));
                            closeVo.setActionDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("trans_date")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("trans_date")));
                            closeVo.setSortLatePayForm(StringUtil.getValue(rs.getString("SORT_LATE_PAY_FORM")));
                            closeVo.setSortAction1Form(StringUtil.getValue(rs.getString("SORT_ACTION1_FROM")));
                            closeVo.setSortAction2Form(StringUtil.getValue(rs.getString("SORT_ACTION2_FROM")));
                            closeVo.setSortQuali(StringUtil.getValue(rs.getString("SORT_QUALI")));
                            closeVo.setSortCreditRating(StringUtil.getValue(rs.getString("SORT_CREDIT_RATING")));
                            closeVo.setSortFin(StringUtil.getValue(rs.getString("SORT_FIN")));
                            closeVo.setSortCreditReview(StringUtil.getValue(rs.getString("SORT_CREDIT_REVIEW")));
                            WarningHeaderVo item = new WarningHeaderVo();
                            item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            item.setWarningDate(rs.getDate("WARNING_DATE"));
                            item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                            item.setCif(rs.getString("CIF"));
                            item.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                            item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                            item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                            item.setRespUnit(rs.getInt("RESP_UNIT"));
                            item.setRespUnitStr(rs.getInt("RESP_UNIT") == 0 ? "" : rs.getString("RESP_UNIT"));
//                            item.setEwsRiskLevel(StringUtil.getValue(rs.getString("EWS_RISK_LEVEL")));
                            item.setEwsRiskLevel(StringUtil.getValue(rs.getString("EWS_RISK_LEVEL_1")));
                            item.setCFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                            item.setDpd(rs.getInt("DPD"));
                            
                            if(rs.getInt("DPD") > 0){
                                item.setDpdStr(StringUtil.getValue(rs.getString("DPD")));
                            }else{
                                item.setDpdStr("");
                            }
                            
                            item.setDpdAcctCnt(rs.getInt("DPD_ACCT_CNT"));
                            item.setDpdAcctCntStr(rs.getInt("DPD_ACCT_CNT") == 0 ? "" : rs.getString("DPD_ACCT_CNT"));
                            item.setUnpaidAmt(rs.getBigDecimal("UNPAID_AMT"));
                            item.setUnpaidAmtStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("UNPAID_AMT"), MoneyUtil.patternDPD));
                            
                            item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                            if (rs.getString("OD_OVER_LIMIT") != null) {
                                item.setOdOverLimitStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_LIMIT"), MoneyUtil.patternDPD));
                            } else {
                                item.setOdOverLimitStr("");
                            }
                            item.setOdAcctCnt(rs.getInt("OD_ACCT_CNT"));
                            item.setOdAcctCntStr(rs.getInt("OD_ACCT_CNT") == 0 ? "" : rs.getString("OD_ACCT_CNT"));
                            item.setOdOverAmt(rs.getBigDecimal("OD_OVER_AMT"));
                            item.setOdOverAmtStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_AMT"), MoneyUtil.patternDPD));
                            item.setLatePayFlg(rs.getString("LATE_PAY_FLG"));
                            item.setAction1Flg(rs.getString("ACTION1_FLG"));
                            item.setAction2Flg(rs.getString("ACTION2_FLG"));
                            item.setQualiFlg(rs.getString("QUALI_FLG"));
                            item.setFinFlg(rs.getString("FIN_FLG"));
                            item.setTypesFlg(rs.getString("TYPES_FLG"));
                            item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                            item.setCrFlg(rs.getString("CR_FLG"));
                            item.setReviewDateFinal(rs.getDate("REVIEW_DATE_FINAL"));
                            item.setReviewDateFinalStr(ValidatorUtil.isNullOrEmpty(rs.getDate("REVIEW_DATE_FINAL")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("REVIEW_DATE_FINAL")));
                            item.setRatingDateFinal(rs.getDate("RATING_DATE_FINAL"));
                            item.setRatingDateFinalStr(ValidatorUtil.isNullOrEmpty(rs.getDate("RATING_DATE_FINAL")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("RATING_DATE_FINAL")));
                            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
                            item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getDate("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("MATURITY_DATE")));
//                            item.setCrAcctCnt(rs.getInt("CR_ACCT_CNT"));
//                            item.setCrWarningCnt(rs.getInt("CR_WARNING_CNT"));
                            item.setCrAcctCnt(rs.getString("CR_ACCT_CNT"));
                            item.setCrWarningCnt(rs.getString("CR_WARNING_CNT"));
                            item.setStatus(rs.getString("STATUS"));
                            item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                            item.setCreatedDate(rs.getDate("CREATED_DT"));
                            item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                            item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                            
                            CustomerVo custv = new CustomerVo();
                            custv.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                            custv.setRmName(StringUtil.getValue(rs.getString("RM_FULL_NAME")));
                            custv.setAeName(StringUtil.getValue(rs.getString("AE_FULL_NAME")));
                            custv.setAoName(StringUtil.getValue(rs.getString("AO_FULL_NAME")));
                            custv.setResponseUnitName(rs.getString("COSTCENTER_NAME"));
                            item.setCustomerVo(custv);
                            
                            item.setCountAlertLp(StringUtil.getValue(rs.getString("COUNT_ALERT_LP")));
                            item.setCountAlertAf1(StringUtil.getValue(rs.getString("COUNT_ALERT_AF1")));
                            item.setCountAlertAf2(StringUtil.getValue(rs.getString("COUNT_ALERT_AF2")));
                            item.setCountAlertQf(StringUtil.getValue(rs.getString("COUNT_ALERT_QF")));
                            item.setCountAlertFf(StringUtil.getValue(rs.getString("COUNT_ALERT_FF")));
                            
                            closeVo.setWarningHeaderVo(item);
                            return closeVo;
                            
                        }
                    });

                StringBuilder sqlCount = getSQLCloseListReportForCountEwsl(sql.toString());
                    cdList = (ArrayList<CountDataVo>) jdbcTemplate.query(sqlCount.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            CountDataVo cd = new CountDataVo();
                            cd.setLatePayFlgCount       (rs.getInt("late_pay_cou"));
                            cd.setAction1FlgCount        (rs.getInt("action1_cou"));
                            cd.setAction2FlgCount        (rs.getInt("action2_cou"));
                            cd.setQualiFlgCount         (rs.getInt("quali_cou"));
                            cd.setCreditRatingFlgCount  (rs.getInt("credit_rating_cou"));
                            cd.setFinFlgCount           (rs.getInt("fin_cou"));
                            cd.setCrFlgCount            (rs.getInt("cr_cou"));
                            
                            cd.setLatePayFlgCountStr        (MoneyUtil.convertNumberToStringByFormat(rs.getInt("late_pay_cou"), MoneyUtil.patternDPD));
                            cd.setAction1FlgCountStr         (MoneyUtil.convertNumberToStringByFormat(rs.getInt("action1_cou"), MoneyUtil.patternDPD));
                            cd.setAction2FlgCountStr         (MoneyUtil.convertNumberToStringByFormat(rs.getInt("action2_cou"), MoneyUtil.patternDPD));
                            cd.setQualiFlgCountStr          (MoneyUtil.convertNumberToStringByFormat(rs.getInt("quali_cou"), MoneyUtil.patternDPD));
                            cd.setCreditRatingFlgCountStr   (MoneyUtil.convertNumberToStringByFormat(rs.getInt("credit_rating_cou"), MoneyUtil.patternDPD));
                            cd.setFinFlgCountStr            (MoneyUtil.convertNumberToStringByFormat(rs.getInt("fin_cou"), MoneyUtil.patternDPD));
                            cd.setCrFlgCountStr             (MoneyUtil.convertNumberToStringByFormat(rs.getInt("cr_cou"), MoneyUtil.patternDPD));
                            
                            return cd;
                        }
                    });
                if ((cdList != null) && (!cdList.isEmpty())) {
                    paginate.setCountObjData(cdList.get(0));
                }
            }//SQL IS NULL
            if (reportList != null) {
                log.info("reportList.size() =  " + reportList.size());
            }
            int totalRecord = countTotal(sql.toString());
            paginate.setTotalRecord(totalRecord);
            paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
            paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
            paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
            paginate.setList(reportList);

        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getCloseListReportEwsl: " + e.getMessage(), e);
            throw e;
        }
        return paginate;
    }
   
    @Override
    public PaginatedListImpl getCloseListReport(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt, String roleQuery) throws Exception {
        ArrayList<ReportCloseJobVo> reportList = null;
        ArrayList<CountDataVo> cdList = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("ActionCloseServiceImpl.getCloseListReport");
            }
          
            StringBuilder sql = getSQLCloseListReport_1(searchBean);//getSQLCloseListReport(searchBean);
            
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                String rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize());
                    reportList = (ArrayList<ReportCloseJobVo>) jdbcTemplate.query(rowNumSql.toString(), new RowMapper() {
                        @Override
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ReportCloseJobVo closeVo = new ReportCloseJobVo();
                            closeVo.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            closeVo.setWarningId(rs.getInt("WARNING_ID"));
                            closeVo.setReasonDetail(StringUtil.getValue(rs.getString("REASON_DESC")));
                            closeVo.setRemark(StringUtil.getValue(rs.getString("REMARK")));
                            closeVo.setActionDt(rs.getDate("EWS_CLOSE_DT"));
                            closeVo.setActionDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("EWS_CLOSE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("EWS_CLOSE_DT")));
                            closeVo.setActionBy(StringUtil.getValue(rs.getString("EWS_CLOSE_BY")));
                            closeVo.setApproveDt(rs.getDate("EWS_APPROVE_DT"));
                            closeVo.setApproveDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("EWS_APPROVE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("EWS_APPROVE_DT")));
                            closeVo.setApproveBy(StringUtil.getValue(rs.getString("EWS_APPROVE_BY")));
                            closeVo.setCrDt(rs.getDate("CR_APPROVE_DT"));
                            closeVo.setCrDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CR_APPROVE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("CR_APPROVE_DT")));
                            closeVo.setCrBy(StringUtil.getValue(rs.getString("CR_APPROVE_BY")));
                            closeVo.setTaDt(rs.getDate("TA_APPROVE_DT"));
                            closeVo.setTaDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("TA_APPROVE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("TA_APPROVE_DT")));
                            closeVo.setTaBy(StringUtil.getValue(rs.getString("TA_APPROVE_BY")));
                            
                            WarningHeaderVo item = new WarningHeaderVo();
                            item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            item.setCrFlag(StringUtil.getValue(rs.getString("CR_FLAG")));
                            item.setDpd(rs.getInt("DPD"));
                            item.setEwsFlag(StringUtil.getValue(rs.getString("EWS_FLAG")));
                            item.setEwsRiskLevel(StringUtil.getValue(rs.getString("EWS_RISK_LEVEL")));
                            item.setFinFlg(StringUtil.getValue(rs.getString("FIN_FLAG")));
                            item.setStatus(StringUtil.getValue(rs.getString("STATUS")));
                            item.setTaFlag(StringUtil.getValue(rs.getString("TA_FLAG")));
                            item.setWarningDate(rs.getDate("WARNING_DATE"));
                            item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                            item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                            item.setCreatedDate(rs.getDate("CREATED_DT"));
                            item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                            item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                            item.setCif(rs.getString("CIF"));
                            item.setSumTrackingEwsq(rs.getInt("SUM_TRACK_EWS"));
                            item.setSumTrackingFin(rs.getInt("SUM_TRACK_FIN"));
                            item.setSumTrackingTrigAndPay(rs.getInt("SUM_TRIG_PAY"));
                            item.setTrigAndPayFlag(StringUtil.getValue(rs.getString("TRIG_PAY_FLAG")));
                            item.setCFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                            item.setEwsRiskDt(rs.getDate("EWS_RISK_DT"));
                            item.setDisableFlag(StringUtil.getValue(rs.getString("DISABLE_FLAG")));
                            item.setEwsRiskDtStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("EWS_RISK_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("EWS_RISK_DT")));
                            try {
                                item.setCrExpiryDt(rs.getDate("CR_EXPIRY_DT"));
                                item.setCrExpiryDtStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CR_EXPIRY_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CR_EXPIRY_DT")));
                                if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString("DPD"))) {
                                    item.setDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD"), MoneyUtil.patternDPD));
                                } else {
                                    item.setDpdStrFormat("");
                                }
                                item.setSla(rs.getInt("SLA"));
                                if(rs.getString("SLA") != null && rs.getString("SLA").length() > 0){
                                    item.setSlaStr(MoneyUtil.formatMoney(rs.getInt("SLA"), 0));
                                }else{
                                    item.setSlaStr("");
                                }
                                item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                                item.setOverLimitFlag(StringUtil.getValue(rs.getString("OVER_LIMIT_FLAG")));
                                if (rs.getString("OD_OVER_LIMIT") != null) {
                                    item.setOdOverLimitStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_LIMIT"), MoneyUtil.patternDPD));
                                } else {
                                    item.setOdOverLimitStr("");
                                }
                            } catch (Exception e) {
                                 e.printStackTrace();
                            }

                            CustomerVo custv = new CustomerVo();
                            custv.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                            custv.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                            custv.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                            custv.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                            custv.setResponseUnitName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                            custv.setRmName(StringUtil.getValue(rs.getString("RM_NAME")));
                            custv.setAeName(StringUtil.getValue(rs.getString("AE_NAME")));
                            item.setCustomerVo(custv);
                            
                            closeVo.setWarningHeaderVo(item);
                            return closeVo;
                        }
                    });

                StringBuilder sqlCount = getSQLCloseListReportForCount(sql.toString());
                    cdList = (ArrayList<CountDataVo>) jdbcTemplate.query(sqlCount.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            CountDataVo cd = new CountDataVo();
                            cd.setCountEwsq(rs.getInt("EWS_COUNT"));
                            cd.setCountFin(rs.getInt("FIN_COUNT"));                            
                            cd.setCountTa(rs.getInt("TA_COUNT"));
                            cd.setCountCr(rs.getInt("CR_COUNT"));
                            cd.setCountTrigAndPay(rs.getInt("TRIG_PAY_COUNT"));
                            cd.setCountEwsqStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("EWS_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountFinStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("FIN_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountTaStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("TA_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountCrStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("CR_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountTrigAndPayStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("TRIG_PAY_COUNT"), MoneyUtil.patternDPD));
                            return cd;
                        }
                    });
                if ((cdList != null) && (!cdList.isEmpty())) {
                    paginate.setCountObjData(cdList.get(0));
                }
            }//SQL IS NULL
            if (reportList != null) {
                log.info("reportList.size() =  " + reportList.size());
            }
            int totalRecord = countTotal(sql.toString());
            paginate.setTotalRecord(totalRecord);
            paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
            paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
            paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
            paginate.setList(reportList);

        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getCloseListReport: " + e.getMessage(), e);
            throw e;
        }
        return paginate;
    }
    
    private StringBuilder getSQLCloseListReport(SearchBean search)throws Exception{
        StringBuilder sql = new StringBuilder();
        try{
        sql.append("   SELECT  D1.WARNING_HEAD_ID ,  D1.CIF,  D1.WARNING_DATE,D1.STATUS, D1.DPD,  D1.FIN_FLAG,  D1.EWS_FLAG, ");
        sql.append("\n D1.CR_FLAG,  D1.TA_FLAG,  D1.TRIG_PAY_FLAG ,D1.CREATED_DT,  D1.CREATED_BY ,  D1.UPDATED_DT, D1.UPDATED_BY, ");
        sql.append("\n D1.CUST_NAME,  D1.BUSINESS_SIZE, D1.RM_NAME, D1.AE_NAME ,  ");
        sql.append("\n D1.AE_ID,  D1.RM_ID ,  D1.SLA , D1.CR_EXPIRY_DT  , ");
        sql.append("\n D1.RESPONSE_UNIT ,  D1.COSTCENTER_NAME , D1.OVER_LIMIT_FLAG, D1.SUM_TRIG_PAY ,");
        sql.append("\n D1.SUM_TRACK_EWS, D1.SUM_TRACK_FIN ,D1.C_FINAL , D1.EWS_RISK_DT, ");
        sql.append("\n D1.SORT_CR,D1.SORT_FIN,D1.SORT_TA,D1.SORT_EWSQ, ");
        sql.append("\n D1.EWS_RISK_LEVEL,D1.SORT_EWS_RISK_LEVEL,D1.SORT_DPD, ");
        sql.append("\n D1.DATA_SORT_CR_EXPIRY_DT,D1.SORT_TRIG_PAY,D1.SORT_C_FINAL, ");
        sql.append("\n D1.EWS_FOR_COUNT,D1.FIN_FOR_COUNT,D1.CR_FOR_COUNT,D1.TA_FOR_COUNT,D1.TRIG_PAY_FOR_COUNT,D1.OD_OVER_LIMIT, ");
        sql.append("\n D2.WARNING_ID,D2.EWS_CLOSE_BY  , D2.EWS_CLOSE_DT , D2.REASON_DESC  , D2.REMARK , ");
        sql.append("\n D2.EWS_APPROVE_BY  , D2.EWS_APPROVE_DT ,D2.CR_APPROVE_BY  , D2.CR_APPROVE_DT ,D2.TA_APPROVE_BY  , D2.TA_APPROVE_DT , D1.DISABLE_FLAG ");
        sql.append("\n FROM( ");
        //-------------------------------------------ORIGINAL HEADER------------------------------------------------------------------------------------
        sql.append("\n      SELECT DATA.WARNING_HEAD_ID , DATA.CIF , DATA.WARNING_DATE ,DATA.STATUS ,DATA.DPD , DATA.FIN_FLAG , DATA.EWS_FLAG , ");
        sql.append("\n      DATA.CR_FLAG , DATA.TA_FLAG , DATA.TRIG_PAY_FLAG  , DATA.CREATED_DT , DATA.CREATED_BY  , DATA.UPDATED_DT, DATA.UPDATED_BY , ");
        sql.append("\n      DATA.CUST_NAME , DATA.BUSINESS_SIZE , DATA.RM_NAME, DATA.AE_NAME , DATA.AE_ID , DATA.RM_ID ,  DATA.SLA   , DATA.CR_EXPIRY_DT   , ");
        sql.append("\n      DATA.RESPONSE_UNIT ,  DATA.COSTCENTER_NAME ,DATA.OVER_LIMIT_FLAG  , DATA.SUM_TRACK_EWS, DATA.SUM_TRACK_FIN  , ");
        sql.append("\n      DATA.C_FINAL ,DATA.EWS_RISK_DT ,DATA.DISABLE_FLAG , DATA.SUM_TRIG_PAY ");
        sql.append("\n      , CASE   ");
        sql.append("\n            WHEN DATA.CR_FLAG = 'N' AND DATA.STATUS != 'R' THEN 5 ");
        sql.append("\n            WHEN DATA.CR_FLAG = 'N' AND DATA.STATUS = 'R' THEN 4 ");
        sql.append("\n            WHEN DATA.CR_FLAG = 'I' AND DATA.STATUS != 'R' THEN 3 ");
        sql.append("\n            WHEN DATA.CR_FLAG = 'I' AND DATA.STATUS = 'R' THEN 2 ");
        sql.append("\n            WHEN DATA.CR_FLAG = 'C' THEN 1  ");
        sql.append("\n       ELSE 0  ");
        sql.append("\n      END as SORT_CR  ");
        sql.append("\n      , CASE   ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'N' AND DATA.STATUS != 'R' THEN 7 ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'RN' OR ( DATA.FIN_FLAG = 'N' AND DATA.STATUS = 'R')  THEN 6 ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'P' AND DATA.STATUS != 'R'THEN 5 ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'RP' OR ( DATA.FIN_FLAG = 'P' AND DATA.STATUS = 'R')  THEN 4 ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'I' AND DATA.STATUS != 'R'THEN 3 ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'RI' OR ( DATA.FIN_FLAG = 'I' AND DATA.STATUS = 'R')  THEN 2 ");
        sql.append("\n            WHEN DATA.FIN_FLAG = 'C' THEN 1  ");
        sql.append("\n         ELSE 0  ");
        sql.append("\n      END as SORT_FIN ");
        sql.append("\n      , CASE   ");
        sql.append("\n            WHEN DATA.TA_FLAG = 'N'  AND DATA.STATUS != 'R' THEN 5 ");
        sql.append("\n            WHEN DATA.TA_FLAG = 'N' AND DATA.STATUS = 'R' THEN 4 ");
        sql.append("\n            WHEN DATA.TA_FLAG = 'I'  AND DATA.STATUS != 'R'THEN 3 ");
        sql.append("\n            WHEN DATA.TA_FLAG = 'I'  AND DATA.STATUS = 'R'THEN 2 ");
        sql.append("\n            WHEN DATA.TA_FLAG = 'C' THEN 1  ");
        sql.append("\n      ELSE 0  ");
        sql.append("\n     END as SORT_TA ");
        sql.append("\n  , CASE   ");
        sql.append("\n          WHEN DATA.EWS_FLAG = 'N' AND DATA.STATUS != 'R' THEN 5 ");
        sql.append("\n          WHEN DATA.EWS_FLAG = 'RN' OR ( DATA.EWS_FLAG = 'N' AND DATA.STATUS = 'R') THEN 4 ");
        sql.append("\n          WHEN DATA.EWS_FLAG = 'I' AND DATA.STATUS != 'R' THEN 3 ");
        sql.append("\n          WHEN DATA.EWS_FLAG = 'RI'  OR ( DATA.EWS_FLAG = 'I' AND DATA.STATUS = 'R')  THEN 2 ");
        sql.append("\n          WHEN DATA.EWS_FLAG = 'C' THEN 1  ");
        sql.append("\n    ELSE 0  ");
        sql.append("\n   END as SORT_EWSQ ");
        sql.append("\n  , DATA.RISK_LEVEL_PIPELINE_DISP as EWS_RISK_LEVEL ");
        sql.append("\n  , DATA.ORDER_SEQ as SORT_EWS_RISK_LEVEL ");
        sql.append("\n  ,CASE  ");
        sql.append("\n     WHEN DATA.DPD <= 0  OR  DATA.DPD IS NULL THEN  0 ");
        sql.append("\n     ELSE  DATA.DPD ");
        sql.append("\n   END as SORT_DPD  ");
        sql.append("\n   ,CASE  ");
        sql.append("\n     WHEN DATA.CR_FLAG IS NULL  OR NULLIF(DATA.CR_FLAG, '') IS NULL THEN NULL ");
        sql.append("\n     ELSE DATA.CR_EXPIRY_DT ");
        sql.append("\n    END as  DATA_SORT_CR_EXPIRY_DT    ");
        sql.append("\n   , CASE   ");
        sql.append("\n      WHEN DATA.TRIG_PAY_FLAG = 'N' AND DATA.STATUS != 'R' THEN 5 ");
        sql.append("\n      WHEN DATA.TRIG_PAY_FLAG = 'RN' OR ( DATA.TRIG_PAY_FLAG = 'N' AND DATA.STATUS = 'R') THEN 4 ");
        sql.append("\n      WHEN DATA.TRIG_PAY_FLAG = 'I' AND DATA.STATUS != 'R' THEN 3 ");
        sql.append("\n      WHEN DATA.TRIG_PAY_FLAG = 'RI' OR ( DATA.TRIG_PAY_FLAG = 'I' AND DATA.STATUS = 'R') THEN 2 ");
        sql.append("\n      WHEN DATA.TRIG_PAY_FLAG = 'C' THEN 1  ");
        sql.append("\n    ELSE 0  ");
        sql.append("\n   END as SORT_TRIG_PAY ");
        sql.append("\n   , CASE  ");
        sql.append("\n   WHEN DATA.C_FINAL IS NULL  OR NULLIF(DATA.C_FINAL, '') IS NULL THEN -9999 ");
        sql.append("\n   ELSE DATA.C_FINAL ");
        sql.append("\n END as  SORT_C_FINAL   ");
        //---------------------  FOR SUM ALL  
        sql.append("\n    , CASE      ");
        sql.append("\n          WHEN DATA.EWS_FLAG IS NULL  OR NULLIF(DATA.EWS_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n          ELSE 1     ");
        sql.append("\n    END as  EWS_FOR_COUNT         ");
        sql.append("\n    , CASE      ");
        sql.append("\n           WHEN DATA.FIN_FLAG IS NULL  OR NULLIF(DATA.FIN_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n           ELSE 1     ");
        sql.append("\n    END as FIN_FOR_COUNT      ");
        sql.append("\n    , CASE      ");
        sql.append("\n           WHEN DATA.CR_FLAG IS NULL  OR NULLIF(DATA.CR_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n           ELSE 1     ");
        sql.append("\n    END as CR_FOR_COUNT      ");
        sql.append("\n    , CASE      ");
        sql.append("\n           WHEN DATA.TA_FLAG IS NULL  OR NULLIF(DATA.TA_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n               ELSE 1     ");
        sql.append("\n        END as TA_FOR_COUNT      ");
        sql.append("\n        , CASE      ");
        sql.append("\n             WHEN DATA.TRIG_PAY_FLAG IS NULL  OR NULLIF(DATA.TRIG_PAY_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n              ELSE 1     ");
        sql.append("\n        END as TRIG_PAY_FOR_COUNT      ");
        sql.append("\n        , DATA.OD_OVER_LIMIT AS OD_OVER_LIMIT    "); 
        sql.append("\n   FROM ( ");
        //--------------------- AO , Senior AO
        sql.append("\n     SELECT  SUB_DATA.WARNING_HEAD_ID  , SUB_DATA.CIF , SUB_DATA.WARNING_DATE, ");
        sql.append("\n             SUB_DATA.STATUS , SUB_DATA.EWS_RISK_LEVEL , SUB_DATA.DPD , ");
        sql.append("\n             SUB_DATA.FIN_FLAG , SUB_DATA.EWS_FLAG , SUB_DATA.CR_FLAG, SUB_DATA.TA_FLAG , ");
        sql.append("\n             SUB_DATA.CREATED_DT , SUB_DATA.CREATED_BY  , SUB_DATA.UPDATED_DT , SUB_DATA.UPDATED_BY , ");
        sql.append("\n             SUB_DATA.CUST_NAME , SUB_DATA.BUSINESS_SIZE , ");
        sql.append("\n             SUB_DATA.AE_ID , SUB_DATA.RM_ID  , SUB_DATA.SLA   , SUB_DATA.CR_EXPIRY_DT , ");
        sql.append("\n             SUB_DATA.RESPONSE_UNIT  ,SUB_DATA.COSTCENTER_NAME  ,SUB_DATA.OVER_LIMIT_FLAG , ");
        sql.append("\n             NVL(SUM_TRACK.SUM_TRACK_EWS, 0) AS SUM_TRACK_EWS , NVL(SUM_TRACK.SUM_TRACK_FIN, 0) AS SUM_TRACK_FIN, ");
        sql.append("\n             SUB_DATA.TRIG_PAY_FLAG AS  TRIG_PAY_FLAG , SUB_DATA.DISABLE_FLAG , ");
        sql.append("\n             NVL(SUM_TRACK.SUM_TRIG_PAY, 0) AS SUM_TRIG_PAY , ");
        sql.append("\n             SUB_DATA.C_FINAL , SUB_DATA.EWS_RISK_DT , ");
        sql.append("\n             RLM.RISK_LEVEL_PIPELINE_DISP , RLM.ORDER_SEQ , SUB_DATA.OD_OVER_LIMIT , SUB_DATA.RM_NAME , SUB_DATA.AE_NAME ");
        sql.append("\n     FROM  ");
        //-----------
        sql.append("\n        (SELECT  ");
        sql.append("\n             A.WARNING_HEAD_ID AS WARNING_HEAD_ID , A.CIF AS CIF, A.WARNING_DATE AS WARNING_DATE, ");
        sql.append("\n             A.STATUS AS STATUS, A.EWS_RISK_LEVEL AS EWS_RISK_LEVEL, A.DPD AS DPD,  ");
        sql.append("\n             A.FIN_FLAG AS FIN_FLAG, A.EWS_FLAG AS EWS_FLAG,  ");
        sql.append("\n             A.CR_FLAG AS CR_FLAG, A.TA_FLAG AS TA_FLAG, ");
        sql.append("\n             A.CREATED_DT AS CREATED_DT, A.CREATED_BY AS CREATED_BY , A.UPDATED_DT AS UPDATED_DT, A.UPDATED_BY AS UPDATED_BY, ");
        sql.append("\n             C.CUST_NAME AS CUST_NAME, C.BUSINESS_SIZE AS BUSINESS_SIZE, ");
        sql.append("\n             C.AE_ID AS AE_ID, C.RM_ID AS RM_ID , A.SLA  AS SLA  , A.CR_EXPIRY_DT AS CR_EXPIRY_DT ,  ");
        sql.append("\n             C.RESPONSE_UNIT AS RESPONSE_UNIT ,O.COSTCENTER_NAME AS COSTCENTER_NAME , A.OVER_LIMIT_FLAG ,  ");
        sql.append("\n             A.TRIG_PAY_FLAG , A.C_FINAL ,A.EWS_RISK_DT ,A.OD_OVER_LIMIT ,C.RM_NAME ,C.AE_NAME , A.DISABLE_FLAG ");
        sql.append("\n        FROM  TBL_WARNING_HEADER A , ");
        sql.append("\n              TBL_CUSTOMER C , ");
        sql.append("\n              TBL_MT_KTB_ORGANIZATION O  ");
        sql.append("\n        WHERE 1=1  AND A.CIF = C.CIF  AND C.RESPONSE_UNIT = O.COSTCENTER_CODE ");
         //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getCifNo())){
            sql.append("\n AND C.CIF = '").append(search.getCifNo().trim()).append("' ");
        }  
        if (!ValidatorUtil.isNullOrEmpty(search.getRmIdOrAeId())){
            sql.append("\n AND ( C.RM_ID = '").append(search.getRmIdOrAeId().trim()).append("' OR C.AE_ID= '").append(search.getRmIdOrAeId().trim()).append("') ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getCustomerName())){
            sql.append("\n AND C.CUST_NAME LIKE '%").append(search.getCustomerName().trim()).append("%' ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())){
            sql.append("\n AND  O.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())){
            sql.append("\n AND  ( O.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND O.GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' ) ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())&&!ValidatorUtil.isNullOrEmpty(search.getCostCenter())){
            sql.append("\n AND  ( O.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND O.GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' AND O.COSTCENTER_CODE = '").append(search.getCostCenter().trim()).append("') ");
        } 
       //--End---------SEARCH -----------//
        sql.append("\n        )SUB_DATA ");
        sql.append("\n       LEFT JOIN ");
        //--------------------------TRACKING_HISTORY-----------------------------------
        sql.append("\n    (SELECT TWH.WARNING_HEAD_ID , SUM(TRACK_EWS_FLAG)AS SUM_TRACK_EWS ,SUM(TRACK_FIN_FLAG) AS SUM_TRACK_FIN ,SUM(TRACK_TRIG_PAY_FLAG) AS SUM_TRIG_PAY ");
        sql.append("\n         FROM TBL_WARNING_HEADER TWH , TBL_TRACKING_HISTORY TTH ");
        sql.append("\n         WHERE  TWH.WARNING_HEAD_ID = TTH.WARNING_HEAD_ID ");
        sql.append("\n          GROUP BY TWH.WARNING_HEAD_ID  ");
        sql.append("\n    )SUM_TRACK ");
        sql.append("\n    ON SUB_DATA.WARNING_HEAD_ID =  SUM_TRACK.WARNING_HEAD_ID ");
        sql.append("\n    LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM ");
        sql.append("\n    ON RLM.RISK_LEVEL = SUB_DATA.EWS_RISK_LEVEL ");
        //------------------Condition Close JOB---------------------------------------------------------------
        sql.append("\n   )DATA ");
        sql.append("\n   WHERE 1=1 AND ");
        sql.append("\n   DATA.STATUS IN ('R','W','C') OR ");
        sql.append("\n   DATA.FIN_FLAG IN ('E','RN','RI','RA','RP') OR ");
        sql.append("\n   DATA.EWS_FLAG IN ('E','RN','RI','RA','RP') OR ");
        sql.append("\n   DATA.TRIG_PAY_FLAG IN('E','RN','RI','RA','RP')  ");
        sql.append("\n  )D1 ");
//        sql.append("\n  LEFT JOIN  ");
        sql.append("\n   INNER JOIN ");
       
//--------------------------ORDER------------------------------------
//---ORDER BY SORT_DPD  desc,
// --       --OD_OVER_LIMIT desc , 
// ----       case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT desc ,
//  --      SORT_TRIG desc,SORT_PAY desc, SORT_TA desc,SORT_CR desc, SORT_EWSQ desc ,SORT_QCA desc, SORT_FIN desc,SORT_EWS_RISK_LEVEL desc
//--------------------------SORT------------------------------------
//--ORDER BY CIF ASC
        sql.append("\n  ( SELECT DATA_R.WARNING_HEAD_ID , DATA_R.WARNING_ID, ");
        sql.append("\n    DATA_R.ACTION_BY AS EWS_CLOSE_BY  , DATA_R.ACTION_DT_SEL AS EWS_CLOSE_DT , DATA_R.REASON_DESC AS REASON_DESC  , DATA_R.REMARK AS REMARK , ");
        sql.append("\n    DATA_C.ACTION_BY AS EWS_APPROVE_BY  , DATA_C.ACTION_DT_SEL AS EWS_APPROVE_DT , ");
        sql.append("\n    DATA_CRC.ACTION_BY AS CR_APPROVE_BY  , DATA_CRC.ACTION_DT_SEL AS CR_APPROVE_DT , ");
        sql.append("\n    DATA_TAC.ACTION_BY AS TA_APPROVE_BY  , DATA_TAC.ACTION_DT_SEL AS TA_APPROVE_DT  ");
        sql.append("\n    FROM ( ");
        sql.append("\n    ( ");
        //-----------------R------------------------------------------------------------
        sql.append("\n  SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE , DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_MAX.ACTION_DT_SEL ");
        sql.append("\n  FROM( ");
        sql.append("\n  (SELECT WARNING_HEAD_ID , WARNING_ID , STATUS, REMARK , REASON_CODE , REASON_DESC , ACTION_BY ,ACTION_DT FROM TBL_ACTION_CLOSE ) DATA_CLOSE ");
        sql.append("\n  RIGHT JOIN  ( SELECT WARNING_HEAD_ID , WARNING_ID  , MAX(ACTION_DT) AS ACTION_DT_SEL ");
        sql.append("\n               FROM TBL_ACTION_CLOSE WHERE STATUS = 'R'  ");
        sql.append("\n               GROUP BY WARNING_HEAD_ID , WARNING_ID ");
        sql.append("\n             ) DATA_MAX ");
        sql.append("\n  ON DATA_MAX.WARNING_HEAD_ID = DATA_CLOSE.WARNING_HEAD_ID AND DATA_MAX.WARNING_ID = DATA_CLOSE.WARNING_ID AND DATA_MAX.ACTION_DT_SEL  = DATA_CLOSE.ACTION_DT ");
        sql.append("\n   ) WHERE DATA_CLOSE.WARNING_HEAD_ID IS NOT NULL   ");//WHERE 1=1
        //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
             sql.append("\n  AND  ( DATE(DATA_MAX.ACTION_DT_SEL) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
        }
        String subCloseFlag = "";
        if((search.isSystemCloseFlagY()) || (search.isSystemCloseFlagN()) || (search.isAdminCloseFlagY()) || (search.isAdminCloseFlagN())){
                if(search.isSystemCloseFlagY()){
                   subCloseFlag  = subCloseFlag +" DATA_CLOSE.ACTION_BY  IN ('System' , 'EWSL BATCH') ";
                }
                if(search.isSystemCloseFlagN()){
                  if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                    subCloseFlag = subCloseFlag + " OR " ;  
                  }
                  subCloseFlag  = subCloseFlag +" DATA_CLOSE.ACTION_BY  NOT IN ('System' , 'EWSL BATCH') ";
                }
                if(search.isAdminCloseFlagY() && !ValidatorUtil.isNullOrEmpty(search.getAdminAllId())){
                   if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                    subCloseFlag = subCloseFlag + " OR " ;  
                   }
                   subCloseFlag  = subCloseFlag +" DATA_CLOSE.ACTION_BY  IN ( "+search.getAdminAllId()+" ) ";
                }
                if(search.isAdminCloseFlagN()  && !ValidatorUtil.isNullOrEmpty(search.getAdminAllId())){
                    if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                        subCloseFlag = subCloseFlag + " OR " ;  
                    }
                   subCloseFlag  = subCloseFlag + " DATA_CLOSE.ACTION_BY NOT IN ( "+search.getAdminAllId()+" ) ";
                }
                
            sql.append("\n  AND ( ").append(subCloseFlag).append(" ) ");
         }
         //--End---------SEARCH -----------//
        //-----------------------------------------------------------------------------
        sql.append(" ) DATA_R ");
        sql.append("  FULL OUTER JOIN ( ");
        //-----------------C------------------------------------------------------------
        sql.append("\n       SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE ,DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_MAX.ACTION_DT_SEL ");
        sql.append("\n       FROM( ");
        sql.append("\n       (SELECT WARNING_HEAD_ID , WARNING_ID , STATUS, REMARK , REASON_CODE ,REASON_DESC , ACTION_BY ,ACTION_DT FROM TBL_ACTION_CLOSE ) DATA_CLOSE ");
        sql.append("\n       RIGHT JOIN  ( SELECT WARNING_HEAD_ID , WARNING_ID  , MAX(ACTION_DT) AS ACTION_DT_SEL ");
        sql.append("\n                    FROM TBL_ACTION_CLOSE WHERE STATUS = 'C'  ");
        sql.append("\n                    GROUP BY WARNING_HEAD_ID , WARNING_ID ");
        sql.append("\n                  ) DATA_MAX ");
        sql.append("\n       ON DATA_MAX.WARNING_HEAD_ID = DATA_CLOSE.WARNING_HEAD_ID AND DATA_MAX.WARNING_ID = DATA_CLOSE.WARNING_ID AND DATA_MAX.ACTION_DT_SEL  = DATA_CLOSE.ACTION_DT ");
        sql.append("\n        )  WHERE DATA_CLOSE.WARNING_HEAD_ID IS NOT NULL  "); // WHERE 1=1
       //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
            sql.append("\n  AND  ( DATE(DATA_MAX.ACTION_DT_SEL) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
        }
        if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){
            sql.append("\n  AND ( ").append(subCloseFlag).append(" ) ");
        }
        //--End---------SEARCH -----------//
        //-----------------------------------------------------------------------------
         sql.append("\n  ) DATA_C  ON DATA_R.WARNING_HEAD_ID = DATA_C.WARNING_HEAD_ID  AND COALESCE(DATA_R.WARNING_ID,0) = COALESCE(DATA_C.WARNING_ID,0) ");
         sql.append("   FULL OUTER JOIN ( ");
        //-----------------CRC------------------------------------------------------------
        sql.append("\n    SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE ,DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_MAX.ACTION_DT_SEL ");
        sql.append("\n    FROM( ");
        sql.append("\n    (SELECT WARNING_HEAD_ID , WARNING_ID , STATUS, REMARK , REASON_CODE ,REASON_DESC , ACTION_BY ,ACTION_DT FROM TBL_ACTION_CLOSE ) DATA_CLOSE ");
        sql.append("\n     RIGHT JOIN  ( SELECT WARNING_HEAD_ID , WARNING_ID  , MAX(ACTION_DT) AS ACTION_DT_SEL ");
        sql.append("\n                  FROM TBL_ACTION_CLOSE WHERE STATUS = 'CRC'  ");
        sql.append("\n                  GROUP BY WARNING_HEAD_ID , WARNING_ID ");
        sql.append("\n                ) DATA_MAX ");
        sql.append("\n     ON DATA_MAX.WARNING_HEAD_ID = DATA_CLOSE.WARNING_HEAD_ID AND DATA_MAX.WARNING_ID = DATA_CLOSE.WARNING_ID AND DATA_MAX.ACTION_DT_SEL  = DATA_CLOSE.ACTION_DT ");
        sql.append("\n      )  WHERE DATA_CLOSE.WARNING_HEAD_ID IS NOT NULL   ");//WHERE 1=1
        //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
            sql.append("\n  AND  ( DATE(DATA_MAX.ACTION_DT_SEL) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
        }
        if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){
            sql.append("\n  AND ( ").append(subCloseFlag).append(" ) ");
        }
        //--End---------SEARCH -----------//
        //-----------------------------------------------------------------------------
        sql.append("\n     ) DATA_CRC ON DATA_R.WARNING_HEAD_ID = DATA_CRC.WARNING_HEAD_ID  AND COALESCE(DATA_R.WARNING_ID,0) = COALESCE(DATA_CRC.WARNING_ID,0) ");
        sql.append("\n      FULL OUTER JOIN  ( ");
        //-----------------CRC------------------------------------------------------------
        sql.append("\n     SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE ,DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_MAX.ACTION_DT_SEL ");
        sql.append("\n     FROM( ");
        sql.append("\n     (SELECT WARNING_HEAD_ID , WARNING_ID , STATUS, REMARK , REASON_CODE ,REASON_DESC , ACTION_BY ,ACTION_DT FROM TBL_ACTION_CLOSE ) DATA_CLOSE ");
        sql.append("\n     RIGHT JOIN  ( SELECT WARNING_HEAD_ID , WARNING_ID  , MAX(ACTION_DT) AS ACTION_DT_SEL ");
        sql.append("\n                  FROM TBL_ACTION_CLOSE WHERE STATUS = 'TAC'  ");
        sql.append("\n                   GROUP BY WARNING_HEAD_ID , WARNING_ID ");
        sql.append("\n                ) DATA_MAX ");
        sql.append("\n      ON DATA_MAX.WARNING_HEAD_ID = DATA_CLOSE.WARNING_HEAD_ID AND DATA_MAX.WARNING_ID = DATA_CLOSE.WARNING_ID AND DATA_MAX.ACTION_DT_SEL  = DATA_CLOSE.ACTION_DT ");
        sql.append("\n      )  WHERE DATA_CLOSE.WARNING_HEAD_ID IS NOT NULL  ");//WHERE 1=1
         //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
             sql.append("\n  AND  ( DATE(DATA_MAX.ACTION_DT_SEL) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
        }
        if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){
            sql.append("\n  AND ( ").append(subCloseFlag).append(" ) ");
        }
        //--End---------SEARCH -----------//
        //-----------------------------------------------------------------------------
        sql.append("\n     ) DATA_TAC ON DATA_R.WARNING_HEAD_ID = DATA_TAC.WARNING_HEAD_ID  AND COALESCE(DATA_R.WARNING_ID,0) = COALESCE(DATA_TAC.WARNING_ID,0) ");
        sql.append("\n     ))D2 ON D1.WARNING_HEAD_ID = D2.WARNING_HEAD_ID ");

        //--------------------------ORDER------------------------------------
        if (!ValidatorUtil.isNullOrEmpty(search.getSortField()) && !ValidatorUtil.isNullOrEmpty(search.getSortType())) {
            if("C_FINAL".equals(search.getSortField())){
                sql.append(" ORDER BY case when C_FINAL IS NULL OR NULLIF(C_FINAL, '') is null then 1 else 0 end, C_FINAL ").append(search.getSortType());
            }else if("OD_OVER_LIMIT".equals(search.getSortField())){
                sql.append(" ORDER BY  case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT ").append(search.getSortType());
            }else{
                sql.append(" ORDER BY ");
                sql.append(search.getSortField()).append("  ").append(search.getSortType());
            }
        } else {
            sql.append("  ORDER BY   EWS_CLOSE_DT  DESC");
        }
        //--------------------------SORT------------------------------------
            
            
        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getSQLCloseListReport: " + e.getMessage(), e);
            throw e;
        }
        return sql;
    }
    
     private StringBuilder getSQLCloseListReportForCount(String subSql) throws Exception {
        StringBuilder sql = new StringBuilder();
        try {
            sql.append("  SELECT SUM(EWS_FOR_COUNT)  AS EWS_COUNT, ");
            sql.append("  SUM(FIN_FOR_COUNT)  AS FIN_COUNT, ");
            sql.append("  SUM(CR_FOR_COUNT)  AS CR_COUNT, ");
            sql.append("  SUM(TA_FOR_COUNT)  AS TA_COUNT, ");
            sql.append("  SUM(TRIG_PAY_FOR_COUNT)  AS TRIG_PAY_COUNT ");
            sql.append("  FROM(  ");
            sql.append(subSql);
            sql.append("  ) ");

        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getSQLCloseListReportForCount: " + e.getMessage(), e);
            throw e;
        }
        return sql;
    }
     
    private StringBuilder getSQLCloseListReportForCountEwsl(String subSql) throws Exception {
        StringBuilder sql = new StringBuilder();
        try {
            sql.append("  select sum(DECODE(t.late_pay_flg, 'D', 0, 1)) as late_pay_cou");
            sql.append("        ,sum(DECODE(t.action1_flg, 'D', 0, 1)) as action1_cou");
            sql.append("        ,sum(DECODE(t.action2_flg, 'D', 0, 1)) as action2_cou");
            sql.append("        ,sum(DECODE(t.quali_flg, 'D', 0, 1)) as quali_cou");
            sql.append("        ,sum(DECODE(t.credit_rating_flg, 'D', 0, 1)) as credit_rating_cou");
            sql.append("        ,sum(DECODE(t.fin_flg, 'D', 0, 1)) as fin_cou");
            sql.append("        ,sum(DECODE(t.cr_flg, 'D', 0, 1)) as cr_cou");
            sql.append("  FROM(  ");
            sql.append(subSql);
            sql.append("  ) t");

        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getSQLCloseListReportForCountEwsl: " + e.getMessage(), e);
            throw e;
        }
        return sql;
    } 
    
     public boolean isNotNullOrNotEmptyOrMoreThanEqualZero(Object strParam) {
        boolean result = false;
        if ((strParam != null && strParam.toString().length() > 0)) {
            int data = Integer.parseInt(strParam.toString());
            if (data > 0) { //--Note DPD <= 0 display blank
                result = true;
            } else {
                result = false;
            }
        }
        return result;
    }

    @Override
    public PaginatedListImpl getCloseListReportForExport(SearchBean searchBean) throws Exception {
       ArrayList<ReportCloseJobVo> reportList = null;
       PaginatedListImpl paginated = new PaginatedListImpl() ;
        try {
            if (log.isInfoEnabled()) {
                log.info("ActionCloseServiceImpl.getCloseListReportForExport");
            }
          
            StringBuilder sql = getSQLCloseListReport_1(searchBean);//getSQLCloseListReport(searchBean);
            
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                    reportList = (ArrayList<ReportCloseJobVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ReportCloseJobVo closeVo = new ReportCloseJobVo();
                            closeVo.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            closeVo.setWarningId(rs.getInt("WARNING_ID"));
                            closeVo.setReasonDetail(StringUtil.getValue(rs.getString("REASON_DESC")));
                            closeVo.setRemark(StringUtil.getValue(rs.getString("REMARK")));
                            closeVo.setActionDt(rs.getDate("EWS_CLOSE_DT"));
                            closeVo.setActionDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("EWS_CLOSE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("EWS_CLOSE_DT")));
                            closeVo.setActionBy(StringUtil.getValue(rs.getString("EWS_CLOSE_BY")));
                            closeVo.setApproveDt(rs.getDate("EWS_APPROVE_DT"));
                            closeVo.setApproveDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("EWS_APPROVE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("EWS_APPROVE_DT")));
                            closeVo.setApproveBy(StringUtil.getValue(rs.getString("EWS_APPROVE_BY")));
                            closeVo.setCrDt(rs.getDate("CR_APPROVE_DT"));
                            closeVo.setCrDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CR_APPROVE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("CR_APPROVE_DT")));
                            closeVo.setCrBy(StringUtil.getValue(rs.getString("CR_APPROVE_BY")));
                            closeVo.setTaDt(rs.getDate("TA_APPROVE_DT"));
                            closeVo.setTaDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("TA_APPROVE_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("TA_APPROVE_DT")));
                            closeVo.setTaBy(StringUtil.getValue(rs.getString("TA_APPROVE_BY")));
                            
                            WarningHeaderVo item = new WarningHeaderVo();
                            item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            item.setCrFlag(StringUtil.getValue(rs.getString("CR_FLAG")));
                            item.setDpd(rs.getInt("DPD"));
                            item.setEwsFlag(StringUtil.getValue(rs.getString("EWS_FLAG")));
                            item.setEwsRiskLevel(StringUtil.getValue(rs.getString("EWS_RISK_LEVEL")));
                            item.setFinFlg(StringUtil.getValue(rs.getString("FIN_FLAG")));
                            item.setStatus(StringUtil.getValue(rs.getString("STATUS")));
                            item.setTaFlag(StringUtil.getValue(rs.getString("TA_FLAG")));
                            item.setWarningDate(rs.getDate("WARNING_DATE"));
                            item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                            item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                            item.setCreatedDate(rs.getDate("CREATED_DT"));
                            item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                            item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                            item.setCif(rs.getString("CIF"));
                            item.setSumTrackingEwsq(rs.getInt("SUM_TRACK_EWS"));
                            item.setSumTrackingFin(rs.getInt("SUM_TRACK_FIN"));
                            item.setSumTrackingTrigAndPay(rs.getInt("SUM_TRIG_PAY"));
                            item.setTrigAndPayFlag(StringUtil.getValue(rs.getString("TRIG_PAY_FLAG")));
                            item.setCFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                            item.setEwsRiskDt(rs.getDate("EWS_RISK_DT"));
                            item.setDisableFlag(StringUtil.getValue(rs.getString("DISABLE_FLAG")));
                            item.setEwsRiskDtStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("EWS_RISK_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("EWS_RISK_DT")));
                            try {
                                item.setCrExpiryDt(rs.getDate("CR_EXPIRY_DT"));
                                item.setCrExpiryDtStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CR_EXPIRY_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CR_EXPIRY_DT")));
                                if (isNotNullOrNotEmptyOrMoreThanEqualZero(rs.getString("DPD"))) {
                                    item.setDpdStrFormat(MoneyUtil.convertNumberToStringByFormat(rs.getInt("DPD"), MoneyUtil.patternDPD));
                                } else {
                                    item.setDpdStrFormat("");
                                }
                                item.setSla(rs.getInt("SLA"));
                                if(rs.getString("SLA") != null && rs.getString("SLA").length() > 0){
                                    item.setSlaStr(MoneyUtil.formatMoney(rs.getInt("SLA"), 0));
                                }else{
                                    item.setSlaStr("");
                                }
                                item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                                item.setOverLimitFlag(StringUtil.getValue(rs.getString("OVER_LIMIT_FLAG")));
                                if (rs.getString("OD_OVER_LIMIT") != null) {
                                    item.setOdOverLimitStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_LIMIT"), MoneyUtil.patternDPD));
                                } else {
                                    item.setOdOverLimitStr("");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            CustomerVo custv = new CustomerVo();
                            custv.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                            custv.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                            custv.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                            custv.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                            custv.setResponseUnitName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                            custv.setRmName(StringUtil.getValue(rs.getString("RM_NAME")));
                            custv.setAeName(StringUtil.getValue(rs.getString("AE_NAME")));
                            item.setCustomerVo(custv);
                            
                            closeVo.setWarningHeaderVo(item);
                            return closeVo;
                        }
                    });
                    
                    paginated.setList(reportList);
                    
                    StringBuilder sqlCount = getSQLCloseListReportForCount(sql.toString());
                    ArrayList<CountDataVo> cdList = (ArrayList<CountDataVo>) jdbcTemplate.query(sqlCount.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            CountDataVo cd = new CountDataVo();
                            cd.setCountEwsq(rs.getInt("EWS_COUNT"));
                            cd.setCountFin(rs.getInt("FIN_COUNT"));                            
                            cd.setCountTa(rs.getInt("TA_COUNT"));
                            cd.setCountCr(rs.getInt("CR_COUNT"));
                            cd.setCountTrigAndPay(rs.getInt("TRIG_PAY_COUNT"));
                            cd.setCountEwsqStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("EWS_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountFinStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("FIN_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountTaStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("TA_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountCrStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("CR_COUNT"), MoneyUtil.patternDPD));
                            cd.setCountTrigAndPayStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("TRIG_PAY_COUNT"), MoneyUtil.patternDPD));
                            return cd;
                        }
                    });
                    
                    if ((cdList != null) && (!cdList.isEmpty())) {
                    paginated.setCountObjData(cdList.get(0));
                }
                    
            }
        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getCloseListReportForExport: " + e.getMessage(), e);
            throw e;
        }
        return paginated;
    }
    
    @Override
    public PaginatedListImpl getCloseListReportForExportEwsl(SearchBean searchBean) throws Exception {
       ArrayList<ReportCloseJobVo> reportList = null;
       PaginatedListImpl paginated = new PaginatedListImpl() ;
        try {
            if (log.isInfoEnabled()) {
                log.info("ActionCloseServiceImpl.getCloseListReportForExportEwsl");
            }
          
            StringBuilder sql = getSQLCloseListReportEwsl(searchBean);//getSQLCloseListReport(searchBean);
            
            if (!ValidatorUtil.isNullOrEmpty(sql.toString())) {
                    reportList = (ArrayList<ReportCloseJobVo>) jdbcTemplate.query(sql.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ReportCloseJobVo closeVo = new ReportCloseJobVo();
                            closeVo.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            closeVo.setCloseJobType(StringUtil.getValue(rs.getString("close_job_type")));
                            closeVo.setReasonDetail(StringUtil.getValue(rs.getString("REASON_DESC")));
                            closeVo.setRemark(StringUtil.getValue(rs.getString("REMARK")));
                            closeVo.setApproveBy(StringUtil.getValue(rs.getString("approv_user")));
                            closeVo.setApproveDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("approv_date")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("approv_date")));
                            closeVo.setActionBy(StringUtil.getValue(rs.getString("trans_user")));
                            closeVo.setActionDtS(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("trans_date")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("trans_date")));
                            
                            closeVo.setSortLatePayForm(StringUtil.getValue(rs.getString("SORT_LATE_PAY_FORM")));
                            closeVo.setSortAction1Form(StringUtil.getValue(rs.getString("SORT_ACTION1_FROM")));
                            closeVo.setSortAction2Form(StringUtil.getValue(rs.getString("SORT_ACTION2_FROM")));
                            closeVo.setSortQuali(StringUtil.getValue(rs.getString("SORT_QUALI")));
                            closeVo.setSortCreditRating(StringUtil.getValue(rs.getString("SORT_CREDIT_RATING")));
                            closeVo.setSortFin(StringUtil.getValue(rs.getString("SORT_FIN")));
                            closeVo.setSortCreditReview(StringUtil.getValue(rs.getString("SORT_CREDIT_REVIEW")));
                            
                            WarningHeaderVo item = new WarningHeaderVo();
                            item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                            item.setWarningDate(rs.getDate("WARNING_DATE"));
                            item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                            item.setCif(rs.getString("CIF"));
                            item.setRmId(StringUtil.getValue(rs.getString("RM_ID")));
                            item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                            item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                            item.setRespUnit(rs.getInt("RESP_UNIT"));
                            item.setRespUnitStr(rs.getInt("RESP_UNIT") == 0 ? "" : rs.getString("RESP_UNIT"));
                            //item.setEwsRiskLevel(StringUtil.getValue(rs.getString("EWS_RISK_LEVEL")));
							item.setEwsRiskLevel(StringUtil.getValue(rs.getString("EWS_RISK_LEVEL_1")));
                            item.setCFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                            item.setDpd(rs.getInt("DPD"));
                            
                            if(rs.getInt("DPD") > 0){
                                item.setDpdStr(StringUtil.getValue(rs.getString("DPD")));
                            }else{
                                item.setDpdStr("");
                            }
                            
                            item.setDpdAcctCnt(rs.getInt("DPD_ACCT_CNT"));
                            item.setDpdAcctCntStr(rs.getInt("DPD_ACCT_CNT") == 0 ? "" : rs.getString("DPD_ACCT_CNT"));
                            item.setUnpaidAmt(rs.getBigDecimal("UNPAID_AMT"));
                            item.setUnpaidAmtStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("UNPAID_AMT"), MoneyUtil.patternDPD));
                            
                            item.setOdOverLimit(rs.getInt("OD_OVER_LIMIT"));
                            if (rs.getString("OD_OVER_LIMIT") != null) {
                                item.setOdOverLimitStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_LIMIT"), MoneyUtil.patternDPD));
                            } else {
                                item.setOdOverLimitStr("");
                            }
                            item.setOdAcctCnt(rs.getInt("OD_ACCT_CNT"));
                            item.setOdAcctCntStr(rs.getInt("OD_ACCT_CNT") == 0 ? "" : rs.getString("OD_ACCT_CNT"));
                            item.setOdOverAmt(rs.getBigDecimal("OD_OVER_AMT"));
                            item.setOdOverAmtStr(MoneyUtil.convertNumberToStringByFormat(rs.getInt("OD_OVER_AMT"), MoneyUtil.patternDPD));
                            item.setLatePayFlg(rs.getString("LATE_PAY_FLG"));
                            item.setAction1Flg(rs.getString("ACTION1_FLG"));
                            item.setAction2Flg(rs.getString("ACTION2_FLG"));
                            item.setQualiFlg(rs.getString("QUALI_FLG"));
                            item.setFinFlg(rs.getString("FIN_FLG"));
                            item.setTypesFlg(rs.getString("TYPES_FLG"));
                            item.setCrFlg(rs.getString("CR_FLG"));
                            item.setCreditRatingFlg(rs.getString("CREDIT_RATING_FLG"));
                            item.setReviewDateFinal(rs.getDate("REVIEW_DATE_FINAL"));
                            item.setReviewDateFinalStr(ValidatorUtil.isNullOrEmpty(rs.getDate("REVIEW_DATE_FINAL")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("REVIEW_DATE_FINAL")));
                            item.setRatingDateFinal(rs.getDate("RATING_DATE_FINAL"));
                            item.setRatingDateFinalStr(ValidatorUtil.isNullOrEmpty(rs.getDate("RATING_DATE_FINAL")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("RATING_DATE_FINAL")));
                            item.setMaturityDate(rs.getDate("MATURITY_DATE"));
                            item.setMaturityDateStr(ValidatorUtil.isNullOrEmpty(rs.getDate("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getDate("MATURITY_DATE")));
//                            item.setCrAcctCnt(rs.getInt("CR_ACCT_CNT"));
//                            item.setCrWarningCnt(rs.getInt("CR_WARNING_CNT"));
                            item.setCrAcctCnt(rs.getString("CR_ACCT_CNT"));
                            item.setCrWarningCnt(rs.getString("CR_WARNING_CNT"));
                            item.setStatus(rs.getString("STATUS"));
                            item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                            item.setCreatedDate(rs.getDate("CREATED_DT"));
                            item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                            item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                            
                            CustomerVo custv = new CustomerVo();
                            custv.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                            custv.setRmName(StringUtil.getValue(rs.getString("RM_FULL_NAME")));
                            custv.setAeName(StringUtil.getValue(rs.getString("AE_FULL_NAME")));
                            custv.setAoName(StringUtil.getValue(rs.getString("AO_FULL_NAME")));
                            custv.setResponseUnitName(rs.getString("COSTCENTER_NAME"));
                            item.setCustomerVo(custv);
                            
                            item.setCountAlertLp(StringUtil.getValue(rs.getString("COUNT_ALERT_LP")));
                            item.setCountAlertAf1(StringUtil.getValue(rs.getString("COUNT_ALERT_AF1")));
                            item.setCountAlertAf2(StringUtil.getValue(rs.getString("COUNT_ALERT_AF2")));
                            item.setCountAlertQf(StringUtil.getValue(rs.getString("COUNT_ALERT_QF")));
                            item.setCountAlertFf(StringUtil.getValue(rs.getString("COUNT_ALERT_FF")));
                            
                            closeVo.setWarningHeaderVo(item);
                            return closeVo;
                        }
                    });
                    
                    paginated.setList(reportList);
                    
                    StringBuilder sqlCount = getSQLCloseListReportForCountEwsl(sql.toString());
                    ArrayList<CountDataVo> cdList = (ArrayList<CountDataVo>) jdbcTemplate.query(sqlCount.toString(), new RowMapper() {
                        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                            CountDataVo cd = new CountDataVo();
                            cd.setLatePayFlgCount       (rs.getInt("late_pay_cou"));
                            cd.setAction1FlgCount        (rs.getInt("action1_cou"));
                            cd.setAction2FlgCount        (rs.getInt("action2_cou"));
                            cd.setQualiFlgCount         (rs.getInt("quali_cou"));
                            cd.setCreditRatingFlgCount  (rs.getInt("credit_rating_cou"));
                            cd.setFinFlgCount           (rs.getInt("fin_cou"));
                            cd.setCrFlgCount            (rs.getInt("cr_cou"));
                            
                            cd.setLatePayFlgCountStr        (MoneyUtil.convertNumberToStringByFormat(rs.getInt("late_pay_cou"), MoneyUtil.patternDPD));
                            cd.setAction1FlgCountStr         (MoneyUtil.convertNumberToStringByFormat(rs.getInt("action1_cou"), MoneyUtil.patternDPD));
                            cd.setAction2FlgCountStr         (MoneyUtil.convertNumberToStringByFormat(rs.getInt("action2_cou"), MoneyUtil.patternDPD));
                            cd.setQualiFlgCountStr          (MoneyUtil.convertNumberToStringByFormat(rs.getInt("quali_cou"), MoneyUtil.patternDPD));
                            cd.setCreditRatingFlgCountStr   (MoneyUtil.convertNumberToStringByFormat(rs.getInt("credit_rating_cou"), MoneyUtil.patternDPD));
                            cd.setFinFlgCountStr            (MoneyUtil.convertNumberToStringByFormat(rs.getInt("fin_cou"), MoneyUtil.patternDPD));
                            cd.setCrFlgCountStr             (MoneyUtil.convertNumberToStringByFormat(rs.getInt("cr_cou"), MoneyUtil.patternDPD));
                            return cd;
                        }
                    });
                    
                    if ((cdList != null) && (!cdList.isEmpty())) {
                    paginated.setCountObjData(cdList.get(0));
                }
                    
            }
        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getCloseListReportForExportEwsl: " + e.getMessage(), e);
            throw e;
        }
        return paginated;
    }

//   private StringBuilder getSQLCloseListReportEwsl(SearchBean search)throws Exception{
//        StringBuilder sql                   = new StringBuilder();
//        
//        try{
//            
//            sql.append("select WARNING_HEADER.*");
//            sql.append("\n      ,WI.ALERT_CNT as CR_WARNING_CNT");
//            sql.append("\n      ,CUSTOMER.cust_name");
//            sql.append("\n      ,CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(ERM.TITLE_NAME, '')),''),TRIM(NVL(ERM.EMP_NAME, ''))),' '),TRIM(NVL(ERM.EMP_SURNAME, ''))) AS RM_FULL_NAME");
//            sql.append("\n      ,CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(EAE.TITLE_NAME, '')),''),TRIM(NVL(EAE.EMP_NAME, ''))),' '),TRIM(NVL(EAE.EMP_SURNAME, ''))) AS AE_FULL_NAME");
//            sql.append("\n      ,CONCAT(CONCAT(CONCAT(CONCAT(TRIM(NVL(EAO.TITLE_NAME, '')),''),TRIM(NVL(EAO.EMP_NAME, ''))),' '),TRIM(NVL(EAO.EMP_SURNAME, ''))) AS AO_FULL_NAME");
//            sql.append("\n      ,O.COSTCENTER_NAME");
//            sql.append("\n      ,LP.SEQ AS SORT_LATE_PAY_FORM");
//            sql.append("\n      ,AF1.SEQ  AS SORT_ACTION1_FROM");
//            sql.append("\n      ,AF2.SEQ  AS SORT_ACTION2_FROM");
//            sql.append("\n      ,QF.SEQ  AS SORT_QUALI");
//            sql.append("\n      ,CR.SEQ AS SORT_CREDIT_RATING");
//            sql.append("\n      ,FF.SEQ  AS SORT_FIN");
//            sql.append("\n      ,CRF.SEQ  AS SORT_CREDIT_REVIEW");
//            sql.append("\n      ,RL.SEQ  AS SORT_EWS_RISK_LEVEL");
//            sql.append("\n      ,RL.RISK_LEVEL_SHORT_NAME  AS EWS_RISK_LEVEL_1");
//            sql.append("\n      ,CASE");
//            sql.append("\n          WHEN WARNING_HEADER.DPD <= 0  OR  WARNING_HEADER.DPD IS NULL THEN  0");
//            sql.append("\n          ELSE  WARNING_HEADER.DPD");
//            sql.append("\n       END as SORT_DPD");
//            sql.append("\n       ,b.warning_type");
//            sql.append("\n       ,b.close_job_flg");
//            sql.append("\n       ,b.close_job_type");
//            sql.append("\n       ,b.REASON_DESC");
//            sql.append("\n       ,b.REMARK");
//            sql.append("\n       ,b.action_dt");
//            sql.append("\n       ,b.trans_user");
//            sql.append("\n       ,b.trans_date");
//            sql.append("\n       ,b.approv_user");
//            sql.append("\n       ,b.approv_date");
//            sql.append("\n       , NVL(ALERT_LP.ALERT_CNT, 0) as COUNT_ALERT_LP");
//            sql.append("\n       , NVL(ALERT_AF1.ALERT_CNT, 0) as COUNT_ALERT_AF1");
//            sql.append("\n       , NVL(ALERT_AF2.ALERT_CNT, 0) as COUNT_ALERT_AF2");
//            sql.append("\n       , NVL(ALERT_QF.ALERT_CNT, 0) as COUNT_ALERT_QF");
//            sql.append("\n       , NVL(ALERT_FF.ALERT_CNT, 0) as COUNT_ALERT_FF");
//            sql.append("\n    from TBL_WARNING_HEADER WARNING_HEADER");
//            sql.append("\n        inner join TBL_CUSTOMER CUSTOMER on WARNING_HEADER.cif = CUSTOMER.cif");
//            sql.append("\n        inner join TBL_MT_KTB_ORGANIZATION KTB_ORG on CUSTOMER.RESPONSE_UNIT = KTB_ORG.COSTCENTER_CODE");
//            sql.append("\n        inner join (");
//            sql.append("\n            select ACTION_CLOSE.WARNING_HEAD_ID as WARNING_HEAD_ID");
//            sql.append("\n                  , WARNING_INFO.warning_type as warning_type");
//            sql.append("\n                  ,'JOB' as close_job_flg");
//            sql.append("\n                  ,'Job-'||WARNING_TYPE.warning_type_desc as close_job_type");
////            sql.append("\n                  ,ACTION_CLOSE.REASON_DESC as REASON_DESC");
////            sql.append("\n                  ,nvl(ACTION_CLOSE.REMARK, '') as REMARK");
//            sql.append("\n                  ,(selecT T1.REASON_DESC");
//            sql.append("\n                                        From Tbl_Action_Close T1");
//            sql.append("\n                                        Where T1.Status In ('R')");
//            sql.append("\n                                            And T1.Warning_Head_Id = Action_Close.Warning_Head_Id");
//            sql.append("\n                                            And T1.Action_Dt <= Nvl((Select Max(T2.Action_Dt)");
//            sql.append("\n                                                                        From Tbl_Action_Close T2");
//            sql.append("\n                                                                        Where T2.Warning_Head_Id = T1.Warning_Head_Id");
//            sql.append("\n                                                                            and T2.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                                                                                    from TBL_WARNING_INFO ");
//            sql.append("\n                                                                                                    where warning_head_id = T1.Warning_Head_Id ");
//            sql.append("\n                                                                                                      and WARNING_TYPE = WARNING_INFO.warning_type)");
//            sql.append("\n                                                                            And T2.Status = 'C' ), T1.Action_Dt)");
//            sql.append("\n                                                                        Order By Action_dt desc fetch first 1 rows only) as REASON_DESC");
//            sql.append("\n                                    ,(selecT T1.Remark");
//            sql.append("\n                                        From Tbl_Action_Close T1");
//            sql.append("\n                                        Where T1.Status In ('R')");
//            sql.append("\n                                            And T1.Warning_Head_Id = Action_Close.Warning_Head_Id");
//            sql.append("\n                                            And T1.Action_Dt <= Nvl((Select Max(T2.Action_Dt)");
//            sql.append("\n                                                                        From Tbl_Action_Close T2");
//            sql.append("\n                                                                        Where T2.Warning_Head_Id = T1.Warning_Head_Id");
//            sql.append("\n                                                                            and T2.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                                                                                    from TBL_WARNING_INFO ");
//            sql.append("\n                                                                                                    where warning_head_id = T1.Warning_Head_Id ");
//            sql.append("\n                                                                                                      and WARNING_TYPE = WARNING_INFO.warning_type)");
//            sql.append("\n                                                                            And T2.Status = 'C' ), T1.Action_Dt)");
//            sql.append("\n                                                                        Order By Action_dt desc fetch first 1 rows only) as REMARK");
//            sql.append("\n                                    ,ACTION_CLOSE.action_dt as action_dt");
//            sql.append("\n                                    ,(select t1.action_BY");
//            sql.append("\n                                        from TBL_ACTION_CLOSE t1");
//            sql.append("\n                                        where t1.status in ('R', 'I')");
//            sql.append("\n                                            and t1.WARNING_HEAD_ID = ACTION_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                                            and t1.action_dt <= nvl((select max(t2.action_dt)");
//            sql.append("\n                                                                    from TBL_ACTION_CLOSE t2");
//            sql.append("\n                                                                    where t2.WARNING_HEAD_ID = t1.WARNING_HEAD_ID");
//            sql.append("\n                                                                        and T2.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                                                                                    from TBL_WARNING_INFO ");
//            sql.append("\n                                                                                                    where warning_head_id = T1.Warning_Head_Id ");
//            sql.append("\n                                                                                                      and WARNING_TYPE = WARNING_INFO.warning_type)");
//            sql.append("\n                                                                        and t2.status = 'C' ), t1.action_dt)");
//            sql.append("\n                                                                    order by action_dt desc fetch first 1 rows only) as trans_user");
//            sql.append("\n                                    ,(select t1.action_dt");
//            sql.append("\n                                        from TBL_ACTION_CLOSE t1");
//            sql.append("\n                                        where t1.status in ('R', 'I')");
//            sql.append("\n                                            and t1.WARNING_HEAD_ID = ACTION_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                                            and t1.action_dt <= nvl((select max(t2.action_dt)");
//            sql.append("\n                                                                    from TBL_ACTION_CLOSE t2");
//            sql.append("\n                                                                    where t2.WARNING_HEAD_ID = t1.WARNING_HEAD_ID");
//            sql.append("\n                                                                        and T2.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                                                                                    from TBL_WARNING_INFO ");
//            sql.append("\n                                                                                                    where warning_head_id = T1.Warning_Head_Id ");
//            sql.append("\n                                                                                                      and WARNING_TYPE = WARNING_INFO.warning_type)");
//            sql.append("\n                                                                        and t2.status = 'C' ), t1.action_dt)");
//            sql.append("\n                                                                    order by action_dt desc fetch first 1 rows only) as trans_date");
//            sql.append("\n                                    ,(select t.action_BY");
//            sql.append("\n                                            from TBL_ACTION_CLOSE t");
//            sql.append("\n                                            where t.WARNING_HEAD_ID = ACTION_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                                                and t.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                                                        from TBL_WARNING_INFO ");
//            sql.append("\n                                                                        where warning_head_id = t.Warning_Head_Id ");
//            sql.append("\n                                                                          and WARNING_TYPE = WARNING_INFO.warning_type)");
//            sql.append("\n                                                and t.status = 'C'");
//            sql.append("\n                                            order by t.action_dt desc fetch first 1 rows only) as approv_user");
//            sql.append("\n                                    ,(select t.action_dt");
//            sql.append("\n                                            from TBL_ACTION_CLOSE t");
//            sql.append("\n                                            where t.WARNING_HEAD_ID = ACTION_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                                                and t.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                                                        from TBL_WARNING_INFO ");
//            sql.append("\n                                                                        where warning_head_id = t.Warning_Head_Id ");
//            sql.append("\n                                                                          and WARNING_TYPE = WARNING_INFO.warning_type)");
//            sql.append("\n                                                and t.status = 'C'");
//            sql.append("\n                                            order by t.action_dt desc fetch first 1 rows only) as approv_date");
//            sql.append("\n                from TBL_ACTION_CLOSE ACTION_CLOSE");
//            sql.append("\n                  inner JOIN TBL_WARNING_INFO WARNING_INFO on ACTION_CLOSE.warning_id = WARNING_INFO.warning_id");
//            sql.append("\n                  inner JOIN TBL_WARNING_TYPE WARNING_TYPE on WARNING_INFO.warning_type = WARNING_TYPE.warning_type_code");
//            sql.append("\n                where ACTION_CLOSE.action_dt = ( select max(t.action_dt) ");
//            sql.append("\n                                                  from TBL_ACTION_CLOSE t ");
//            sql.append("\n                                                  where ACTION_CLOSE.WARNING_HEAD_ID = t.WARNING_HEAD_ID");
//            sql.append("\n                                                      and ACTION_CLOSE.warning_id = t.warning_id");
//            sql.append("\n                                               )");
//            sql.append("\n             union");
//            sql.append("\n             SELECT WARNING_CLOSE.WARNING_HEAD_ID as WARNING_HEAD_ID");
//            sql.append("\n                  ,'CIF' as warning_type");
//            sql.append("\n                  ,'CIF' as close_job_flg");
//            sql.append("\n                  ,'CIF' as close_job_type");
//            sql.append("\n                  ,MT_PARAMETER.PARAMETER_NAME as REASON_DESC");
////            sql.append("\n                  ,nvl(WARNING_CLOSE.REMARK, '') as REMARK");
//            sql.append("\n                  ,(select t1.REMARK");
//            sql.append("\n                      from TBL_WARNING_CLOSE t1");
//            sql.append("\n                      where t1.status in ('R')");
//            sql.append("\n                          and t1.WARNING_HEAD_ID = WARNING_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                          and t1.created_dt <= NVL((select max(t2.created_dt)");
//            sql.append("\n                                                      from TBL_WARNING_CLOSE t2");
//            sql.append("\n                                                      where t2.WARNING_HEAD_ID = t1.WARNING_HEAD_ID");
//            sql.append("\n                                                          and t2.status = 'C' ), t1.created_dt)");
//            sql.append("\n                                                      order by created_dt desc fetch first 1 rows only) as REMARK");
//            sql.append("\n                  ,WARNING_CLOSE.created_dt as action_dt");
//            sql.append("\n                  ,(select t1.CREATED_BY as trans_user");
//            sql.append("\n                      from TBL_WARNING_CLOSE t1");
//            sql.append("\n                      where t1.status in ('R', 'I') ");
//            sql.append("\n                          and t1.WARNING_HEAD_ID = WARNING_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                          and t1.created_dt <= NVL((select max(t2.created_dt)");
//            sql.append("\n                                                  from TBL_WARNING_CLOSE t2 ");
//            sql.append("\n                                                  where t2.WARNING_HEAD_ID = t1.WARNING_HEAD_ID");
//            sql.append("\n                                                      and t2.status = 'C' ), t1.created_dt)");
//            sql.append("\n                                                  order by created_dt desc fetch first 1 rows only) as trans_user");
//            sql.append("\n                    ,(select t1.created_dt");
//            sql.append("\n                          from TBL_WARNING_CLOSE t1 ");
//            sql.append("\n                          where t1.status in ('R', 'I')");
//            sql.append("\n                              and t1.WARNING_HEAD_ID = WARNING_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                              and t1.created_dt <= NVL((select max(t2.created_dt)");
//            sql.append("\n                                                      from TBL_WARNING_CLOSE t2 ");
//            sql.append("\n                                                      where t2.WARNING_HEAD_ID = t1.WARNING_HEAD_ID ");
//            sql.append("\n                                                          and t2.status = 'C' ), t1.created_dt)");
//            sql.append("\n                                                      order by created_dt desc fetch first 1 rows only) as trans_date");
//            sql.append("\n                     ,(select t.CREATED_BY");
//            sql.append("\n                          from TBL_WARNING_CLOSE t ");
//            sql.append("\n                          where t.WARNING_HEAD_ID = WARNING_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                              and t.status = 'C'");
//            sql.append("\n                          order by t.created_dt desc fetch first 1 rows only) as approv_user");
//            sql.append("\n                     ,(select t.created_dt");
//            sql.append("\n                          from TBL_WARNING_CLOSE t");
//            sql.append("\n                          where t.WARNING_HEAD_ID = WARNING_CLOSE.WARNING_HEAD_ID");
//            sql.append("\n                              and t.status = 'C'");
//            sql.append("\n                          order by t.created_dt desc fetch first 1 rows only) as approv_date");
//            sql.append("\n             FROM TBL_WARNING_CLOSE WARNING_CLOSE");
//            sql.append("\n                LEFT JOIN TBL_MT_PARAMETER MT_PARAMETER ON WARNING_CLOSE.REASON_FLG = MT_PARAMETER.PARAMETER_ID AND MT_PARAMETER.PARAMETER_TYPE_ID = 'CLOSE_BY_CIF_REASON'");
//            sql.append("\n             where WARNING_CLOSE.created_dt = (select max(a.created_dt) from TBL_WARNING_CLOSE a where a.WARNING_HEAD_ID = WARNING_CLOSE.WARNING_HEAD_ID)");
//            sql.append("\n        ) b ON WARNING_HEADER.WARNING_HEAD_ID = b.WARNING_HEAD_ID");
//            
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS LP");
//            sql.append("\n          ON LP.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.LATE_PAY_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.LATE_PAY_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.LATE_PAY_FLG");
//            sql.append("\n                                  end");
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS AF1");
//            sql.append("\n          ON AF1.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.ACTION1_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.ACTION1_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.ACTION1_FLG");
//            sql.append("\n                                  end");
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS AF2");
//            sql.append("\n          ON AF2.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.ACTION2_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.ACTION2_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.ACTION2_FLG");
//            sql.append("\n                                  end");
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS QF");
//            sql.append("\n          ON QF.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.QUALI_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.QUALI_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.QUALI_FLG");
//            sql.append("\n                                  end");
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS CR");
//            sql.append("\n          ON CR.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.CREDIT_RATING_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.CREDIT_RATING_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.CREDIT_RATING_FLG");
//            sql.append("\n                                  end");
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS FF");
//            sql.append("\n          ON FF.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.FIN_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.FIN_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.FIN_FLG");
//            sql.append("\n                                  end");
//            sql.append("\n        LEFT JOIN TBL_MT_FORM_STATUS CRF");
//            sql.append("\n          ON CRF.FORM_STATUS_FLG = case");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'W' and WARNING_HEADER.CR_FLG <> 'D' then 'E'");
//            sql.append("\n                                      when WARNING_HEADER.STATUS = 'R' and WARNING_HEADER.CR_FLG <> 'D' then 'RN'");
//            sql.append("\n                                      ELSE WARNING_HEADER.CR_FLG");
//            sql.append("\n                                   end");
//            sql.append("\n        LEFT JOIN TBL_MT_RISK_LEVEL  RL  ON WARNING_HEADER.EWS_RISK_LEVEL  = RL.RISK_LEVEL");
//            sql.append("\n        LEFT JOIN TBL_WARNING_INFO   WI  ON WARNING_HEADER.WARNING_HEAD_ID  = WI.WARNING_HEAD_ID AND WI.WARNING_TYPE = 'CR'");
//            sql.append("\n        LEFT JOIN TBL_WARNING_INFO   ALERT_LP  ");
//            sql.append("\n                  ON ALERT_LP.WARNING_ID in (select min(warning_id) ");
//            sql.append("\n                                              from TBL_WARNING_INFO ");
//            sql.append("\n                                              where warning_head_id = WARNING_HEADER.WARNING_HEAD_ID ");
//            sql.append("\n                                                and WARNING_TYPE = 'LATE_PAY')");
//            sql.append("\n        LEFT JOIN TBL_WARNING_INFO   ALERT_AF1  ON WARNING_HEADER.WARNING_HEAD_ID  = ALERT_AF1.WARNING_HEAD_ID AND ALERT_AF1.WARNING_TYPE = 'ACTION1'");
//            sql.append("\n        LEFT JOIN TBL_WARNING_INFO   ALERT_AF2  ON WARNING_HEADER.WARNING_HEAD_ID  = ALERT_AF2.WARNING_HEAD_ID AND ALERT_AF2.WARNING_TYPE = 'ACTION2'");
//            sql.append("\n        LEFT JOIN TBL_WARNING_INFO   ALERT_QF  ");
//            sql.append("\n                  ON ALERT_QF.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                              from TBL_WARNING_INFO ");
//            sql.append("\n                                              where warning_head_id = WARNING_HEADER.WARNING_HEAD_ID ");
//            sql.append("\n                                                and WARNING_TYPE = 'EWSQ')");
//            sql.append("\n                LEFT JOIN TBL_WARNING_INFO   ALERT_FF  ");
//            sql.append("\n                  ON ALERT_FF.WARNING_ID in (select max(warning_id) ");
//            sql.append("\n                                              from TBL_WARNING_INFO ");
//            sql.append("\n                                              where warning_head_id = WARNING_HEADER.WARNING_HEAD_ID ");
//            sql.append("\n                                                and WARNING_TYPE = 'FIN')");
//            sql.append("\n        LEFT JOIN TBL_EMPLOYEE ERM ON WARNING_HEADER.RM_ID = ERM.EMP_NO");
//            sql.append("\n        LEFT JOIN TBL_EMPLOYEE EAE ON WARNING_HEADER.AE_ID = EAE.EMP_NO");
//            sql.append("\n        LEFT JOIN TBL_EMPLOYEE EAO ON WARNING_HEADER.AO_ID = EAO.EMP_NO");
//            sql.append("\n        LEFT JOIN TBL_MT_KTB_ORGANIZATION O ON WARNING_HEADER.RESP_UNIT = O.COSTCENTER_CODE");
//            sql.append("\n    where 1=1");
//        
//            //--Start---------SEARCH -----------//
//            if (!ValidatorUtil.isNullOrEmpty(search.getCifNo())){
//                sql.append(" AND WARNING_HEADER.CIF LIKE '%").append(search.getCifNo().trim()).append("%' ");
//            }
//            if (!ValidatorUtil.isNullOrEmpty(search.getCustomerName())){
//                sql.append(" AND CUSTOMER.CUST_NAME LIKE '%").append(search.getCustomerName().trim()).append("%' ");
//            }
//            if (!ValidatorUtil.isNullOrEmpty(search.getRmIdOrAeId())){
//                sql.append(" AND ( WARNING_HEADER.RM_ID LIKE '%").append(search.getRmIdOrAeId().trim()).append("%'")
//                        .append(" OR WARNING_HEADER.AE_ID LIKE '%").append(search.getRmIdOrAeId().trim()).append("%'")
//                        .append(" OR WARNING_HEADER.AO_ID LIKE '%").append(search.getRmIdOrAeId().trim()).append("%') ");
//            }
//            if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())){
//                sql.append(" AND  KTB_ORG.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' ");
//            }
//            if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())){
//                sql.append(" AND  ( KTB_ORG.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND KTB_ORG.GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' ) ");
//            }
//            if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())&&!ValidatorUtil.isNullOrEmpty(search.getCostCenter())){
//                sql.append(" AND  ( KTB_ORG.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND KTB_ORG.GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' AND KTB_ORG.COSTCENTER_CODE = '").append(search.getCostCenter().trim()).append("') ");
//            }
//            if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
//                sql.append(" AND b.trans_date is not null and TO_DATE(VARCHAR_FORMAT(b.trans_date, 'DD/MM/YYYY'),'DD/MM/YYYY') BETWEEN TO_DATE('" + search.getFromDateCloseJobStr().trim() + "','DD/MM/YYYY') AND TO_DATE('" + search.getToDateCloseJobStr().trim() + "','DD/MM/YYYY')");
//            }
//            
//            if((search.isSystemCloseFlagY()) || (search.isAdminCloseFlagY()) || (search.isBcCloseFlagY())){
//                sql.append("\n  AND (( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isAdminCloseFlagY(),search.isBcCloseFlagY(),search.getAdminAllId(),"b.trans_user")).append(" ) ");
//                sql.append("\n  OR ( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isAdminCloseFlagY(),search.isBcCloseFlagY(),search.getAdminAllId(),"b.approv_user")).append(" ) ");
//                sql.append("\n   ) ");
//            }
//            
//            //--------------------------ORDER------------------------------------
//            if (!ValidatorUtil.isNullOrEmpty(search.getSortField()) && !ValidatorUtil.isNullOrEmpty(search.getSortType())) {
//                if("C_FINAL".equals(search.getSortField())){
//                    sql.append(" ORDER BY case when C_FINAL IS NULL OR NULLIF(C_FINAL, '') is null then 1 else 0 end, C_FINAL ").append(search.getSortType());
//                }else if("OD_OVER_LIMIT".equals(search.getSortField())){
//                    sql.append(" ORDER BY  case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT ").append(search.getSortType());
//                }else{
//                    sql.append(" ORDER BY ");
//                    sql.append(search.getSortField()).append("  ").append(search.getSortType());
//                }
//            } else {
//                sql.append(" ORDER BY  SORT_DPD  DESC  , SORT_LATE_PAY_FORM DESC , SORT_CREDIT_REVIEW DESC , SORT_QUALI DESC , SORT_CREDIT_RATING DESC , SORT_FIN DESC , SORT_EWS_RISK_LEVEL DESC ");
//            }
//            
//            
//        } catch (Exception e) {
//            log.error("Error occur in while process ActionCloseServiceImpl.getSQLCloseListReportEwsl: " + e.getMessage(), e);
//            throw e;
//        }
//        return sql;
//    }
    
    private StringBuilder getSQLCloseListReportEwsl(SearchBean search)throws Exception{
        StringBuilder sql                   = new StringBuilder();
        
        try{
            sql.append("select * from VW_CLOSE_JOB_REPORT where 1=1");
        
            //--Start---------SEARCH -----------//
            if (!ValidatorUtil.isNullOrEmpty(search.getCifNo())){
                sql.append("\n AND CIF LIKE '%").append(search.getCifNo().trim()).append("%' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(search.getCustomerName())){
                sql.append("\n AND CUST_NAME LIKE '%").append(search.getCustomerName().trim()).append("%' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(search.getRmIdOrAeId())){
                sql.append("\n AND ( RM_ID LIKE '%").append(search.getRmIdOrAeId().trim()).append("%'")
                        .append("\n OR AE_ID LIKE '%").append(search.getRmIdOrAeId().trim()).append("%'")
                        .append("\n OR AO_ID LIKE '%").append(search.getRmIdOrAeId().trim()).append("%') ");
            }
            if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())){
                sql.append("\n AND BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' ");
            }
            if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())){
                sql.append("\n AND  ( BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' ) ");
            }
            if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())&&!ValidatorUtil.isNullOrEmpty(search.getCostCenter())){
                sql.append("\n AND  ( BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' AND COSTCENTER_CODE = '").append(search.getCostCenter().trim()).append("') ");
            }
            if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
                sql.append("\n AND trans_date is not null and TO_DATE(VARCHAR_FORMAT(trans_date, 'DD/MM/YYYY'),'DD/MM/YYYY') BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY')");
            }
            
            if((search.isSystemCloseFlagY()) || (search.isAdminCloseFlagY()) || (search.isBcCloseFlagY())){
                sql.append("\n  AND (( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isAdminCloseFlagY(),search.isBcCloseFlagY(),search.getAdminAllId(),"trans_user")).append(" ) ");
                sql.append("\n  OR ( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isAdminCloseFlagY(),search.isBcCloseFlagY(),search.getAdminAllId(),"approv_user")).append(" ) ");
                sql.append("\n   ) ");
            }
            
            //--------------------------ORDER------------------------------------
            if (!ValidatorUtil.isNullOrEmpty(search.getSortField()) && !ValidatorUtil.isNullOrEmpty(search.getSortType())) {
                if("C_FINAL".equals(search.getSortField())){
                    sql.append("\n ORDER BY case when C_FINAL IS NULL OR NULLIF(C_FINAL, '') is null then 1 else 0 end, C_FINAL ").append(search.getSortType());
                }else if("OD_OVER_LIMIT".equals(search.getSortField())){
                    sql.append("\n ORDER BY  case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT ").append(search.getSortType());
                }else{
                    sql.append("\n ORDER BY ");
                    sql.append(search.getSortField()).append("  ").append(search.getSortType());
                }
            } else {
                sql.append("\n ORDER BY  SORT_DPD  DESC  , SORT_LATE_PAY_FORM DESC , SORT_CREDIT_REVIEW DESC , SORT_QUALI DESC , SORT_CREDIT_RATING DESC , SORT_FIN DESC , SORT_EWS_RISK_LEVEL DESC ");
            }
            
            
        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getSQLCloseListReportEwsl: " + e.getMessage(), e);
            throw e;
        }
        return sql;
    }
   
   private String sqlConditionActionBy(boolean isSystemCloseFlagY , boolean isAdminCloseFlagY , boolean isBCCloseFlagY ,String adminAllId,String columnName)throws Exception{
     log.debug(" isSystemCloseFlagY >> " + isSystemCloseFlagY);
     log.debug(" isAdminCloseFlagY >>" +  isAdminCloseFlagY);
     log.debug(" isBCCloseFlagY >>" + isBCCloseFlagY);
     log.debug(" columnName >>" + columnName);
     log.debug(" adminAllId >>" + adminAllId);
       String subCloseFlag = "";     
     //--Start---------SEARCH -----------//
        if((isSystemCloseFlagY) || (isAdminCloseFlagY) || (isBCCloseFlagY)){
                if(isSystemCloseFlagY){
                   subCloseFlag  = subCloseFlag +" "+columnName+" IN ('System' , 'EWSL BATCH') ";
                }
                if(isAdminCloseFlagY && !ValidatorUtil.isNullOrEmpty(adminAllId)){
                   if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                    subCloseFlag = subCloseFlag + " OR " ;  
                   }
                   subCloseFlag  = subCloseFlag +" ( "+columnName+"  IN ( "+adminAllId+" ) )";
                }
                if(isBCCloseFlagY && !ValidatorUtil.isNullOrEmpty(adminAllId)){
                    if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                        subCloseFlag = subCloseFlag + " OR " ;  
                    }
                   subCloseFlag  = subCloseFlag +" ( "+columnName+" NOT IN ('System' , 'EWSL BATCH') AND "+columnName+ " NOT IN ( "+adminAllId+" ) ) ";
                }
         }
         //--End---------SEARCH -----------//
     return subCloseFlag;
  }
  
   private StringBuilder getSQLCloseListReport_1(SearchBean search)throws Exception{
        StringBuilder sql = new StringBuilder();
        try{
        sql.append("   SELECT  D1.WARNING_HEAD_ID ,  D1.CIF,  D1.WARNING_DATE,D1.STATUS, D1.DPD,  D1.FIN_FLAG,  D1.EWS_FLAG, ");
        sql.append("\n D1.CR_FLAG,  D1.TA_FLAG,  D1.TRIG_PAY_FLAG ,D1.CREATED_DT,  D1.CREATED_BY ,  D1.UPDATED_DT, D1.UPDATED_BY, ");
        sql.append("\n D1.CUST_NAME,  D1.BUSINESS_SIZE, D1.RM_NAME, D1.AE_NAME ,  ");
        sql.append("\n D1.AE_ID,  D1.RM_ID ,  D1.SLA , D1.CR_EXPIRY_DT  , ");
        sql.append("\n D1.RESPONSE_UNIT ,  D1.COSTCENTER_NAME , D1.OVER_LIMIT_FLAG, D1.SUM_TRIG_PAY ,");
        sql.append("\n D1.SUM_TRACK_EWS, D1.SUM_TRACK_FIN ,D1.C_FINAL , D1.EWS_RISK_DT, ");
        sql.append("\n D1.SORT_CR,D1.SORT_FIN,D1.SORT_TA,D1.SORT_EWSQ, ");
        sql.append("\n D1.EWS_RISK_LEVEL,D1.SORT_EWS_RISK_LEVEL,D1.SORT_DPD, ");
        sql.append("\n D1.DATA_SORT_CR_EXPIRY_DT,D1.SORT_TRIG_PAY,D1.SORT_C_FINAL, ");
        sql.append("\n D1.EWS_FOR_COUNT,D1.FIN_FOR_COUNT,D1.CR_FOR_COUNT,D1.TA_FOR_COUNT,D1.TRIG_PAY_FOR_COUNT,D1.OD_OVER_LIMIT, ");
        sql.append("\n D2.WARNING_ID,D2.EWS_CLOSE_BY  , D2.EWS_CLOSE_DT , D2.REASON_DESC  , D2.REMARK , ");
        sql.append("\n D2.EWS_APPROVE_BY  , D2.EWS_APPROVE_DT ,D2.CR_APPROVE_BY  , D2.CR_APPROVE_DT ,D2.TA_APPROVE_BY  , D2.TA_APPROVE_DT , D1.DISABLE_FLAG ");
        sql.append("\n FROM( ");
        //-------------------------------------------ORIGINAL HEADER------------------------------------------------------------------------------------
        sql.append("\n   SELECT  ");
        sql.append("\n     SUB_DATA.WARNING_HEAD_ID  , SUB_DATA.CIF , SUB_DATA.WARNING_DATE,  ");
        sql.append("\n     SUB_DATA.STATUS , SUB_DATA.EWS_RISK_LEVEL AS EWS_RISK_LEVEL_ORG , SUB_DATA.DPD , ");
        sql.append("\n     SUB_DATA.FIN_FLAG , SUB_DATA.EWS_FLAG ,  ");
        sql.append("\n     SUB_DATA.CR_FLAG, SUB_DATA.TA_FLAG , ");
        sql.append("\n     SUB_DATA.CREATED_DT , SUB_DATA.CREATED_BY  , SUB_DATA.UPDATED_DT , SUB_DATA.UPDATED_BY , ");
        sql.append("\n     SUB_DATA.CUST_NAME , SUB_DATA.BUSINESS_SIZE , ");
        sql.append("\n     SUB_DATA.AE_ID , SUB_DATA.RM_ID  , SUB_DATA.SLA   , SUB_DATA.CR_EXPIRY_DT , ");
        sql.append("\n     SUB_DATA.RESPONSE_UNIT  ,SUB_DATA.COSTCENTER_NAME  ,SUB_DATA.OVER_LIMIT_FLAG , ");
        sql.append("\n     NVL(SUM_TRACK.SUM_TRACK_EWS, 0) AS SUM_TRACK_EWS , NVL(SUM_TRACK.SUM_TRACK_FIN, 0) AS SUM_TRACK_FIN, ");
        sql.append("\n     SUB_DATA.TRIG_PAY_FLAG AS  TRIG_PAY_FLAG ,  SUB_DATA.DISABLE_FLAG ,  ");
        sql.append("\n     NVL(SUM_TRACK.SUM_TRIG_PAY, 0) AS SUM_TRIG_PAY , ");
        sql.append("\n     SUB_DATA.C_FINAL , SUB_DATA.EWS_RISK_DT , ");
        sql.append("\n     RLM.RISK_LEVEL_PIPELINE_DISP  as EWS_RISK_LEVEL, RLM.ORDER_SEQ AS SORT_EWS_RISK_LEVEL, SUB_DATA.OD_OVER_LIMIT , SUB_DATA.RM_NAME , SUB_DATA.AE_NAME,  ");
        sql.append("\n    CASE  ");
        sql.append("\n    WHEN SUB_DATA.CR_FLAG = 'N' AND SUB_DATA.STATUS != 'R' THEN 6 ");
        sql.append("\n    WHEN SUB_DATA.CR_FLAG = 'N' AND SUB_DATA.STATUS = 'R' THEN 5 ");
        sql.append("\n    WHEN SUB_DATA.CR_FLAG = 'I' AND SUB_DATA.STATUS != 'R' THEN 4 ");
        sql.append("\n    WHEN SUB_DATA.CR_FLAG = 'I' AND SUB_DATA.STATUS = 'R' THEN 3 ");
        sql.append("\n    WHEN SUB_DATA.CR_FLAG = 'C' THEN 2  ");
        sql.append("\n    WHEN SUB_DATA.CR_FLAG = 'E' THEN 1  ");
        sql.append("\n       ELSE 0  ");
        sql.append("\n      END as SORT_CR  "); 
        sql.append("\n      , CASE   ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'N' AND SUB_DATA.STATUS != 'R' THEN 8 ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'RN' OR ( SUB_DATA.FIN_FLAG = 'N' AND SUB_DATA.STATUS = 'R')  THEN 7 ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'P' AND SUB_DATA.STATUS != 'R'THEN 6 ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'RP' OR ( SUB_DATA.FIN_FLAG = 'P' AND SUB_DATA.STATUS = 'R')  THEN 5 ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'I' AND SUB_DATA.STATUS != 'R'THEN 4 ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'RI' OR ( SUB_DATA.FIN_FLAG = 'I' AND SUB_DATA.STATUS = 'R')  THEN 3 ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'C' THEN 2  ");
        sql.append("\n    WHEN SUB_DATA.FIN_FLAG = 'E' THEN 1  ");
        sql.append("\n         ELSE 0  ");
        sql.append("\n      END as SORT_FIN ");
        sql.append("\n      , CASE   ");
        sql.append("\n    WHEN SUB_DATA.TA_FLAG = 'N'  AND SUB_DATA.STATUS != 'R' THEN 6 ");
        sql.append("\n    WHEN SUB_DATA.TA_FLAG = 'N' AND SUB_DATA.STATUS = 'R' THEN 5 ");
        sql.append("\n    WHEN SUB_DATA.TA_FLAG = 'I'  AND SUB_DATA.STATUS != 'R'THEN 4 ");
        sql.append("\n     WHEN SUB_DATA.TA_FLAG = 'I'  AND SUB_DATA.STATUS = 'R'THEN 3 ");
        sql.append("\n    WHEN SUB_DATA.TA_FLAG = 'C' THEN 2 ");
        sql.append("\n    WHEN SUB_DATA.TA_FLAG = 'E' THEN 1 ");
        sql.append("\n      ELSE 0  "); 
        sql.append("\n     END as SORT_TA ");
        sql.append("\n  , CASE   ");
        sql.append("\n    WHEN SUB_DATA.EWS_FLAG = 'N' AND SUB_DATA.STATUS != 'R' THEN 6 ");
        sql.append("\n    WHEN SUB_DATA.EWS_FLAG = 'RN' OR ( SUB_DATA.EWS_FLAG = 'N' AND SUB_DATA.STATUS = 'R') THEN 5 ");
        sql.append("\n    WHEN SUB_DATA.EWS_FLAG = 'I' AND SUB_DATA.STATUS != 'R' THEN 4 ");
        sql.append("\n    WHEN SUB_DATA.EWS_FLAG = 'RI'  OR ( SUB_DATA.EWS_FLAG = 'I' AND SUB_DATA.STATUS = 'R')  THEN 3 ");
        sql.append("\n    WHEN SUB_DATA.EWS_FLAG = 'C' THEN 2 ");
        sql.append("\n    WHEN SUB_DATA.EWS_FLAG = 'E' THEN 1 ");
        sql.append("\n    ELSE 0  ");
        sql.append("\n   END as SORT_EWSQ ");
        sql.append("\n  ,CASE  ");
        sql.append("\n     WHEN SUB_DATA.DPD <= 0  OR  SUB_DATA.DPD IS NULL THEN  0 ");
        sql.append("\n     ELSE  SUB_DATA.DPD ");
        sql.append("\n   END as SORT_DPD  ");
        sql.append("\n   ,CASE  ");
        sql.append("\n     WHEN SUB_DATA.CR_FLAG IS NULL  OR NULLIF(SUB_DATA.CR_FLAG, '') IS NULL THEN NULL ");
        sql.append("\n     ELSE SUB_DATA.CR_EXPIRY_DT ");
        sql.append("\n    END as  DATA_SORT_CR_EXPIRY_DT    ");
        sql.append("\n   , CASE   ");
        sql.append("\n    WHEN SUB_DATA.TRIG_PAY_FLAG = 'N' AND SUB_DATA.STATUS != 'R'THEN 6 ");
        sql.append("\n    WHEN SUB_DATA.TRIG_PAY_FLAG = 'RN' OR ( SUB_DATA.TRIG_PAY_FLAG = 'N' AND SUB_DATA.STATUS = 'R') THEN 5 ");
        sql.append("\n    WHEN SUB_DATA.TRIG_PAY_FLAG = 'I' AND SUB_DATA.STATUS != 'R' THEN 4 ");
        sql.append("\n    WHEN SUB_DATA.TRIG_PAY_FLAG = 'RI' OR ( SUB_DATA.TRIG_PAY_FLAG = 'I' AND SUB_DATA.STATUS = 'R') THEN 3 ");
        sql.append("\n    WHEN SUB_DATA.TRIG_PAY_FLAG = 'C' THEN 2  ");
        sql.append("\n    WHEN SUB_DATA.TRIG_PAY_FLAG = 'E' THEN 1  ");
        sql.append("\n    ELSE 0  ");
        sql.append("\n   END as SORT_TRIG_PAY ");
        sql.append("\n   , CASE  ");
        sql.append("\n   WHEN SUB_DATA.C_FINAL IS NULL  OR NULLIF(SUB_DATA.C_FINAL, '') IS NULL THEN -9999 ");
        sql.append("\n   ELSE SUB_DATA.C_FINAL ");
        sql.append("\n END as  SORT_C_FINAL   ");
        //---------------------  FOR SUM ALL  ---------------------//
        sql.append("\n    , CASE      ");
        sql.append("\n          WHEN SUB_DATA.EWS_FLAG IS NULL  OR NULLIF(SUB_DATA.EWS_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n          ELSE 1     ");
        sql.append("\n    END as  EWS_FOR_COUNT         ");
        sql.append("\n    , CASE      ");
        sql.append("\n           WHEN SUB_DATA.FIN_FLAG IS NULL  OR NULLIF(SUB_DATA.FIN_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n           ELSE 1     ");
        sql.append("\n    END as FIN_FOR_COUNT      ");
        sql.append("\n    , CASE      ");
        sql.append("\n           WHEN SUB_DATA.CR_FLAG IS NULL  OR NULLIF(SUB_DATA.CR_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n           ELSE 1     ");
        sql.append("\n    END as CR_FOR_COUNT      ");
        sql.append("\n    , CASE      ");
        sql.append("\n           WHEN SUB_DATA.TA_FLAG IS NULL  OR NULLIF(SUB_DATA.TA_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n               ELSE 1     ");
        sql.append("\n        END as TA_FOR_COUNT      ");
        sql.append("\n        , CASE      ");
        sql.append("\n             WHEN SUB_DATA.TRIG_PAY_FLAG IS NULL  OR NULLIF(SUB_DATA.TRIG_PAY_FLAG, '') IS NULL THEN 0     ");
        sql.append("\n              ELSE 1     ");
        sql.append("\n        END as TRIG_PAY_FOR_COUNT      ");
        sql.append("\n   FROM ( ");
        sql.append("\n   SELECT   "); 
        sql.append("\n   A.WARNING_HEAD_ID AS WARNING_HEAD_ID , A.CIF AS CIF, A.WARNING_DATE AS WARNING_DATE,  ");
       sql.append("\n   A.STATUS AS STATUS, A.EWS_RISK_LEVEL AS EWS_RISK_LEVEL, A.DPD AS DPD,   ");
       sql.append("\n   A.FIN_FLAG AS FIN_FLAG, A.EWS_FLAG AS EWS_FLAG, A.CR_FLAG AS CR_FLAG, A.TA_FLAG AS TA_FLAG,  ");
       sql.append("\n   A.CREATED_DT AS CREATED_DT, A.CREATED_BY AS CREATED_BY , A.UPDATED_DT AS UPDATED_DT, A.UPDATED_BY AS UPDATED_BY,  ");
       sql.append("\n    C.CUST_NAME AS CUST_NAME, C.BUSINESS_SIZE AS BUSINESS_SIZE, C.AE_ID AS AE_ID, C.RM_ID AS RM_ID,   ");
       sql.append("\n   A.SLA  AS SLA, A.CR_EXPIRY_DT AS CR_EXPIRY_DT, C.RESPONSE_UNIT AS RESPONSE_UNIT ,O.COSTCENTER_NAME AS COSTCENTER_NAME,  ");
       sql.append("\n   A.OVER_LIMIT_FLAG, A.TRIG_PAY_FLAG, A.C_FINAL, A.EWS_RISK_DT,  A.OD_OVER_LIMIT ,C.RM_NAME ,C.AE_NAME ,A.DISABLE_FLAG  ");
       sql.append("\n   FROM   ");
       sql.append("\n   (SELECT * FROM TBL_WARNING_HEADER  ");
       sql.append("\n   WHERE STATUS IN ('R','W') OR  ");
       sql.append("\n   (WARNING_HEAD_ID IN (SELECT X.WARNING_HEAD_ID   ");
       sql.append("\n   FROM TBL_ACTION_CLOSE X,   ");
       sql.append("\n   (select WARNING_HEAD_ID, MAX(ACTION_DT) AS ACTION_DT    ");
       sql.append("\n   from tbl_action_close   ");
       sql.append("\n   WHERE WARNING_HEAD_ID IN (SELECT warning_head_id FROM TBL_WARNING_HEADER WHERE STATUS IN ('C'))   ");
       sql.append("\n   group by WARNING_HEAD_ID) Y  ");
       sql.append("\n   WHERE X.WARNING_HEAD_ID = Y.WARNING_HEAD_ID AND X.ACTION_DT = Y.ACTION_DT  ");
       sql.append("\n   AND X.STATUS IN ('C','CRC', 'TAC'))) OR  ");
       sql.append("\n   FIN_FLAG IN ('E','RN','RI','RA','RP') OR  ");
       sql.append("\n   EWS_FLAG IN ('E','RN','RI','RA','RP') OR  ");
       sql.append("\n   TRIG_PAY_FLAG IN('E','RN','RI','RA','RP')) A ,  ");
       sql.append("\n   TBL_CUSTOMER C ,  ");
       sql.append("\n   TBL_MT_KTB_ORGANIZATION O   ");
       sql.append("\n        WHERE 1=1  AND A.CIF = C.CIF  AND C.RESPONSE_UNIT = O.COSTCENTER_CODE ");
         //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getCifNo())){
            sql.append("\n AND C.CIF = '").append(search.getCifNo().trim()).append("' ");
        }  
        if (!ValidatorUtil.isNullOrEmpty(search.getRmIdOrAeId())){
            sql.append("\n AND ( C.RM_ID = '").append(search.getRmIdOrAeId().trim()).append("' OR C.AE_ID= '").append(search.getRmIdOrAeId().trim()).append("') ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getCustomerName())){
            sql.append("\n AND C.CUST_NAME LIKE '%").append(search.getCustomerName().trim()).append("%' ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())){
            sql.append("\n AND  O.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())){
            sql.append("\n AND  ( O.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND O.GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' ) ");
        }
        if (!ValidatorUtil.isNullOrEmpty(search.getWorkLine())&&!ValidatorUtil.isNullOrEmpty(search.getOrganizationGroup())&&!ValidatorUtil.isNullOrEmpty(search.getCostCenter())){
            sql.append("\n AND  ( O.BUSINESSUNIT_CODE = '").append(search.getWorkLine().trim()).append("' AND O.GROUP_CODE = '").append(search.getOrganizationGroup().trim()).append("' AND O.COSTCENTER_CODE = '").append(search.getCostCenter().trim()).append("') ");
        } 
       //--End---------SEARCH -----------//
        sql.append("\n        )SUB_DATA ");
        sql.append("\n       LEFT JOIN ");
        //--------------------------TRACKING_HISTORY-----------------------------------
        sql.append("\n    (SELECT TWH.WARNING_HEAD_ID , SUM(TRACK_EWS_FLAG)AS SUM_TRACK_EWS ,SUM(TRACK_FIN_FLAG) AS SUM_TRACK_FIN ,SUM(TRACK_TRIG_PAY_FLAG) AS SUM_TRIG_PAY ");
        sql.append("\n         FROM TBL_WARNING_HEADER TWH , TBL_TRACKING_HISTORY TTH ");
        sql.append("\n         WHERE  TWH.WARNING_HEAD_ID = TTH.WARNING_HEAD_ID ");
        sql.append("\n          GROUP BY TWH.WARNING_HEAD_ID  ");
        sql.append("\n    )SUM_TRACK ");
        sql.append("\n    ON SUB_DATA.WARNING_HEAD_ID =  SUM_TRACK.WARNING_HEAD_ID ");
        sql.append("\n    LEFT JOIN TBL_MT_RISK_LEVEL_MAPPING RLM ");
        sql.append("\n    ON RLM.RISK_LEVEL = SUB_DATA.EWS_RISK_LEVEL ");
        //------------------Condition Close JOB---------------------------------------------------------------
        sql.append("\n  )D1 ");
        sql.append("\n  LEFT JOIN  ");
       
//--------------------------ORDER------------------------------------
//---ORDER BY SORT_DPD  desc,
// --       --OD_OVER_LIMIT desc , 
// ----       case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT desc ,
//  --      SORT_TRIG desc,SORT_PAY desc, SORT_TA desc,SORT_CR desc, SORT_EWSQ desc ,SORT_QCA desc, SORT_FIN desc,SORT_EWS_RISK_LEVEL desc
//--------------------------SORT------------------------------------
//--ORDER BY CIF ASC
        sql.append("\n  ( SELECT DATA_R.WARNING_HEAD_ID , DATA_R.WARNING_ID, ");
        sql.append("\n    DATA_R.ACTION_BY AS EWS_CLOSE_BY  , DATA_R.ACTION_DT_SEL AS EWS_CLOSE_DT , DATA_R.REASON_DESC AS REASON_DESC  , DATA_R.REMARK AS REMARK , ");
        sql.append("\n    DATA_C.ACTION_BY AS EWS_APPROVE_BY  , DATA_C.ACTION_DT_SEL AS EWS_APPROVE_DT , ");
        sql.append("\n    DATA_CRC.ACTION_BY AS CR_APPROVE_BY  , DATA_CRC.ACTION_DT_SEL AS CR_APPROVE_DT , ");
        sql.append("\n    DATA_TAC.ACTION_BY AS TA_APPROVE_BY  , DATA_TAC.ACTION_DT_SEL AS TA_APPROVE_DT  ");
        sql.append("\n    FROM ( ");
        sql.append("\n    ( ");
        //-----------------R------------------------------------------------------------
        sql.append("\n  SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE , DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_MAX.ACTION_DT_SEL ");
        sql.append("\n  FROM( ");
        sql.append("\n  (SELECT WARNING_HEAD_ID , WARNING_ID , STATUS, REMARK , REASON_CODE , REASON_DESC , ACTION_BY ,ACTION_DT FROM TBL_ACTION_CLOSE ) DATA_CLOSE ");
        sql.append("\n  RIGHT JOIN  ( SELECT WARNING_HEAD_ID , WARNING_ID  , MAX(ACTION_DT) AS ACTION_DT_SEL ");
        sql.append("\n  FROM TBL_ACTION_CLOSE WHERE STATUS = 'R' AND -- WARNING_HEAD_ID IN (SELECT WARNING_HEAD_ID FROM TBL_WARNING_HEADER WHERE STATUS = 'R') ");
        sql.append("\n                 (WARNING_HEAD_ID IN (SELECT WARNING_HEAD_ID FROM TBL_WARNING_HEADER WHERE STATUS IN ('R','W')  ");
        sql.append("\n                                      UNION  ");
        sql.append("\n                                      SELECT X.WARNING_HEAD_ID  ");
        sql.append("\n                                      FROM TBL_ACTION_CLOSE X,  ");
        sql.append("\n                                           (select WARNING_HEAD_ID, MAX(ACTION_DT) AS ACTION_DT   ");
        sql.append("\n                                            from tbl_action_close  ");
        sql.append("\n                                            WHERE WARNING_HEAD_ID IN (SELECT warning_head_id FROM TBL_WARNING_HEADER WHERE STATUS IN ('C')) ");
        sql.append("\n                                            group by WARNING_HEAD_ID) Y ");
        sql.append("\n                                      WHERE X.WARNING_HEAD_ID = Y.WARNING_HEAD_ID AND X.ACTION_DT = Y.ACTION_DT ");
        sql.append("\n                                            AND X.STATUS IN ('C','CRC', 'TAC')) ");
        sql.append("\n                ) ");
        sql.append("\n               GROUP BY WARNING_HEAD_ID , WARNING_ID ");
        sql.append("\n             ) DATA_MAX ");
        sql.append("\n  ON DATA_MAX.WARNING_HEAD_ID = DATA_CLOSE.WARNING_HEAD_ID AND DATA_MAX.WARNING_ID = DATA_CLOSE.WARNING_ID AND DATA_MAX.ACTION_DT_SEL  = DATA_CLOSE.ACTION_DT ");
        sql.append("\n   ) WHERE DATA_CLOSE.WARNING_HEAD_ID IS NOT NULL   ");//WHERE 1=1
        //-----------------------------------------------------------------------------
        sql.append(" ) DATA_R ");
        sql.append("  FULL OUTER JOIN ( ");
        //-----------------C------------------------------------------------------------
        sql.append("\n       SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE ,DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_MAX.ACTION_DT_SEL ");
        sql.append("\n       FROM( ");
        sql.append("\n       (SELECT WARNING_HEAD_ID , WARNING_ID , STATUS, REMARK , REASON_CODE ,REASON_DESC , ACTION_BY ,ACTION_DT FROM TBL_ACTION_CLOSE ) DATA_CLOSE ");
        sql.append("\n       RIGHT JOIN  ( SELECT WARNING_HEAD_ID , WARNING_ID  , MAX(ACTION_DT) AS ACTION_DT_SEL ");
        sql.append("\n       FROM TBL_ACTION_CLOSE WHERE STATUS = 'C'  AND  ");
        sql.append("\n           (WARNING_HEAD_ID IN (SELECT WARNING_HEAD_ID FROM TBL_WARNING_HEADER WHERE STATUS = 'W'  ");
        sql.append("\n           UNION   ");
        sql.append("\n           SELECT X.WARNING_HEAD_ID   ");
        sql.append("\n           FROM TBL_ACTION_CLOSE X,   ");
        sql.append("\n                (select WARNING_HEAD_ID, MAX(ACTION_DT) AS ACTION_DT    ");
        sql.append("\n                from tbl_action_close   ");
        sql.append("\n                 WHERE WARNING_HEAD_ID IN (SELECT warning_head_id FROM TBL_WARNING_HEADER WHERE STATUS IN ('C'))  ");
        sql.append("\n                 group by WARNING_HEAD_ID) Y  ");
        sql.append("\n                  WHERE X.WARNING_HEAD_ID = Y.WARNING_HEAD_ID AND X.ACTION_DT = Y.ACTION_DT  ");
        sql.append("\n                   AND X.STATUS IN ('C','CRC', 'TAC'))  ");
        sql.append("\n           )  ");
        sql.append("\n          GROUP BY WARNING_HEAD_ID , WARNING_ID  ");
        sql.append("\n         ) DATA_MAX ");
        sql.append("\n         ON DATA_MAX.WARNING_HEAD_ID = DATA_CLOSE.WARNING_HEAD_ID AND DATA_MAX.WARNING_ID = DATA_CLOSE.WARNING_ID AND DATA_MAX.ACTION_DT_SEL  = DATA_CLOSE.ACTION_DT ");
        sql.append("\n         )  WHERE DATA_CLOSE.WARNING_HEAD_ID IS NOT NULL  "); // WHERE 1=1
        //-----------------------------------------------------------------------------
         sql.append("\n  ) DATA_C  ON DATA_R.WARNING_HEAD_ID = DATA_C.WARNING_HEAD_ID  AND COALESCE(DATA_R.WARNING_ID,0) = COALESCE(DATA_C.WARNING_ID,0) ");
         sql.append("   FULL OUTER JOIN ( ");
        //-----------------CRC------------------------------------------------------------
       sql.append(" SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE ,DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_CLOSE.ACTION_DT AS ACTION_DT_SEL  ");
       sql.append(" FROM TBL_ACTION_CLOSE DATA_CLOSE,  ");
       sql.append("      (select WARNING_HEAD_ID, MAX(ACTION_DT) AS ACTION_DT   ");
       sql.append("       from tbl_action_close  ");
       sql.append("       WHERE STATUS = 'CRC' AND WARNING_HEAD_ID IN (SELECT warning_head_id FROM TBL_WARNING_HEADER WHERE CR_flag = 'E') ");
       sql.append("      group by WARNING_HEAD_ID) Y ");
       sql.append(" WHERE DATA_CLOSE.WARNING_HEAD_ID = Y.WARNING_HEAD_ID AND DATA_CLOSE.ACTION_DT = Y.ACTION_DT ");
        //-----------------------------------------------------------------------------
        sql.append("\n     ) DATA_CRC ON DATA_R.WARNING_HEAD_ID = DATA_CRC.WARNING_HEAD_ID  AND COALESCE(DATA_R.WARNING_ID,0) = COALESCE(DATA_CRC.WARNING_ID,0) ");
        sql.append("\n      FULL OUTER JOIN  ( ");
        //-----------------TAC-----------------------------------------------------------
        sql.append("\n  SELECT DATA_CLOSE.WARNING_HEAD_ID , DATA_CLOSE.WARNING_ID , DATA_CLOSE.STATUS, REMARK , DATA_CLOSE.REASON_CODE ,DATA_CLOSE.REASON_DESC , DATA_CLOSE.ACTION_BY ,DATA_CLOSE.ACTION_DT AS ACTION_DT_SEL  ");
        sql.append("\n  FROM TBL_ACTION_CLOSE DATA_CLOSE,  ");
        sql.append("\n      (select WARNING_HEAD_ID, MAX(ACTION_DT) AS ACTION_DT   ");
        sql.append("\n       from tbl_action_close  ");
        sql.append("\n       WHERE STATUS = 'TAC' AND WARNING_HEAD_ID IN (SELECT warning_head_id FROM TBL_WARNING_HEADER WHERE TA_flag = 'E') ");
        sql.append("\n       group by WARNING_HEAD_ID) Y ");
        sql.append("\n  WHERE DATA_CLOSE.WARNING_HEAD_ID = Y.WARNING_HEAD_ID AND DATA_CLOSE.ACTION_DT = Y.ACTION_DT ");
        //-----------------------------------------------------------------------------
        sql.append("\n     ) DATA_TAC ON DATA_R.WARNING_HEAD_ID = DATA_TAC.WARNING_HEAD_ID  AND COALESCE(DATA_R.WARNING_ID,0) = COALESCE(DATA_TAC.WARNING_ID,0) ");
        sql.append("\n     ))D2 ON D1.WARNING_HEAD_ID = D2.WARNING_HEAD_ID WHERE 1=1 ");

      //--Start---------SEARCH -----------//
        if (!ValidatorUtil.isNullOrEmpty(search.getFromDateCloseJobStr())&&!ValidatorUtil.isNullOrEmpty(search.getToDateCloseJobStr())){
               sql.append("\n  AND  (( DATE(D2.EWS_CLOSE_DT) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
               sql.append("\n  OR  ( DATE(D2.EWS_APPROVE_DT) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
               sql.append("\n  OR  ( DATE(D2.CR_APPROVE_DT) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') )");
               sql.append("\n  OR  ( DATE(D2.TA_APPROVE_DT) BETWEEN TO_DATE('").append(search.getFromDateCloseJobStr().trim()).append("','DD/MM/YYYY') AND TO_DATE('").append(search.getToDateCloseJobStr().trim()).append("','DD/MM/YYYY') ))");
        }
        if((search.isSystemCloseFlagY()) || (search.isSystemCloseFlagN()) || (search.isAdminCloseFlagY()) || (search.isAdminCloseFlagN())){
            sql.append("\n  AND (( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isSystemCloseFlagN(),search.isAdminCloseFlagY(),search.isAdminCloseFlagN(),search.getAdminAllId(),"D2.EWS_CLOSE_BY")).append(" ) ");
            sql.append("\n  OR ( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isSystemCloseFlagN(),search.isAdminCloseFlagY(),search.isAdminCloseFlagN(),search.getAdminAllId(),"D2.EWS_APPROVE_BY")).append(" ) ");
            sql.append("\n  OR ( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isSystemCloseFlagN(),search.isAdminCloseFlagY(),search.isAdminCloseFlagN(),search.getAdminAllId(),"D2.CR_APPROVE_BY")).append(" ) ");
            sql.append("\n  OR ( ").append(sqlConditionActionBy(search.isSystemCloseFlagY(),search.isSystemCloseFlagN(),search.isAdminCloseFlagY(),search.isAdminCloseFlagN(),search.getAdminAllId(),"D2.TA_APPROVE_BY")).append(" ) ");
            sql.append("\n   ) ");
         }
         //--End---------SEARCH -----------//
          
        //--------------------------ORDER------------------------------------
        if (!ValidatorUtil.isNullOrEmpty(search.getSortField()) && !ValidatorUtil.isNullOrEmpty(search.getSortType())) {
            if("C_FINAL".equals(search.getSortField())){
                sql.append(" ORDER BY case when C_FINAL IS NULL OR NULLIF(C_FINAL, '') is null then 1 else 0 end, C_FINAL ").append(search.getSortType());
            }else if("OD_OVER_LIMIT".equals(search.getSortField())){
                sql.append(" ORDER BY  case when OD_OVER_LIMIT IS NULL then 1 else 0 end, OD_OVER_LIMIT ").append(search.getSortType());
            }else{
                sql.append(" ORDER BY ");
                sql.append(search.getSortField()).append("  ").append(search.getSortType());
            }
        } else {
            sql.append("  ORDER BY  D2.EWS_CLOSE_DT DESC ");
        }
        //--------------------------SORT------------------------------------
            
            
        } catch (Exception e) {
            log.error("Error occur in while process ActionCloseServiceImpl.getSQLCloseListReport: " + e.getMessage(), e);
            throw e;
        }
        return sql;
    }
    
   private String sqlConditionActionBy(boolean isSystemCloseFlagY , boolean isSystemCloseFlagN, boolean isAdminCloseFlagY, boolean isAdminCloseFlagN ,String adminAllId,String columnName)throws Exception{
     String subCloseFlag = "";
     //--Start---------SEARCH -----------//
        if((isSystemCloseFlagY) || (isSystemCloseFlagN) || (isAdminCloseFlagY) || (isAdminCloseFlagN)){
                if(isSystemCloseFlagY){
                   subCloseFlag  = subCloseFlag +" "+columnName+" IN ('System' , 'EWSL BATCH') ";
                }
                if(isSystemCloseFlagN){
                  if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                    subCloseFlag = subCloseFlag + " OR " ;  
                  }
                  subCloseFlag  = subCloseFlag +" "+columnName+"  NOT IN ('System' , 'EWSL BATCH') ";
                }
                if(isAdminCloseFlagY && !ValidatorUtil.isNullOrEmpty(adminAllId)){
                   if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                    subCloseFlag = subCloseFlag + " OR " ;  
                   }
                   subCloseFlag  = subCloseFlag +" "+columnName+"  IN ( "+adminAllId+" ) ";
                }
                if(isAdminCloseFlagN && !ValidatorUtil.isNullOrEmpty(adminAllId)){
                    if(!ValidatorUtil.isNullOrEmpty(subCloseFlag)){ 
                        subCloseFlag = subCloseFlag + " OR " ;  
                    }
                   subCloseFlag  = subCloseFlag +" "+columnName+ " NOT IN ( "+adminAllId+" ) ";
                }
         }
         //--End---------SEARCH -----------//
     return subCloseFlag;
  }
       
    @Override
    public List<ActionCloseVo> getcloseJobDetailList(String warningHeadId, String warningType) throws Exception {
        log.info("[getcloseJobDetailList][Begin]");
        
        StringBuilder sql = new StringBuilder();
        List<ActionCloseVo> actionCloseVoList;
        String column;
        
        try{
            if(BusinessConst.WarningTypeCode.LATE_PAY.equals(warningType)){
                column = "min(warning_id)";
            }else{
                column = "max(warning_id)";
            }
            
            sql.append("SELECT actionClose.ACTION_DT,actionClose.ACTION_BY,actionClose.REMARK,actionClose.REASON_CODE,actionClose.REASON_DESC as reasonDetail");
            sql.append("\n FROM TBL_ACTION_CLOSE actionClose");
            sql.append("\n WHERE actionClose.WARNING_HEAD_ID = ?");
            sql.append("\n  AND actionClose.WARNING_ID in (select ").append(column).append(" ");
            sql.append("\n                                  from TBL_WARNING_INFO ");
            sql.append("\n                                  where warning_head_id = actionClose.WARNING_HEAD_ID ");
            sql.append("\n                                      and WARNING_TYPE = ?)");
            sql.append("\n ORDER BY actionClose.ACTION_DT DESC");
            
            log.debug("[getcloseJobDetailList] sql :: " + sql.toString());
            
            actionCloseVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId, warningType}, new BeanPropertyRowMapper<ActionCloseVo>(ActionCloseVo.class));
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[getcloseJobDetailList][End]");
        }
        
        return actionCloseVoList;
    }

    @Override
    public List<ActionCloseVo> getcloseJobDetailListByWarningHeadId(String warningHeadId, String warningType) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("getcloseJobDetailList");
        }
        StringBuilder sql = new StringBuilder();
        
        sql.append(" SELECT actionClose.ACTION_DT,actionClose.ACTION_BY,actionClose.REMARK,actionClose.REASON_CODE,actionClose.REASON_DESC as reasonDetail");
        sql.append("\n FROM TBL_ACTION_CLOSE actionClose");
        sql.append("\n    inner join TBL_WARNING_INFO WI on actionClose.WARNING_ID = WI.WARNING_ID and WI.warning_type = ?");
        sql.append("\n WHERE actionClose.WARNING_HEAD_ID = ?");
        sql.append("\n ORDER BY actionClose.ACTION_DT DESC");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }
        
        List<ActionCloseVo> actionCloseVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningType, warningHeadId}, new BeanPropertyRowMapper<ActionCloseVo>(ActionCloseVo.class));
        return actionCloseVoList;
    }
   
   
}
