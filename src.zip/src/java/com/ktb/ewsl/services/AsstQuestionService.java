/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AsstChoiceVo;
import com.ktb.ewsl.vo.AsstQuestionVo;
import com.ktb.ewsl.vo.AsstSubtopicVo;
import com.ktb.ewsl.vo.AsstTopicVo;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public interface AsstQuestionService {
    public void saveAsstQuestion(AsstQuestionVo asstQuestionVo) throws Exception;
    public void saveAsstTopic(AsstTopicVo asstTopicVo) throws Exception;
    public void saveAsstSubTopic(AsstSubtopicVo asstSubtopicVo) throws Exception;    
    public void saveAsstChoice(AsstChoiceVo asstChoiceVo) throws Exception;        
    public List<AsstTopicVo> findTopicByQuestion(String questionId, String version) throws Exception;
    public List<AsstSubtopicVo> findSubtopicByTopic(List<Integer> topicIdList, String questionId, String version, int warningId,String roleCode) throws Exception;
    public List<AsstChoiceVo> findChoiceByFilter(List<Integer> topicIdList, List<Integer> subtopicIdList, String questionId, String version) throws Exception;
    public List<AsstTopicVo> findTopicByWarningType(String questionId) throws Exception;
    public List<AsstSubtopicVo> findSubtopic(int topicId , String questionId, String version) throws Exception;
    public Integer getLastSubTopic(String questionId, String version) throws Exception;
}
