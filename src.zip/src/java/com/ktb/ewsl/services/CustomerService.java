/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.CustomerVo;

/**
 *
 * @author KTBDevLoan
 */
public interface CustomerService {
    
    public CustomerVo selectCustomerByCif(Integer cif) throws Exception;
    
    public CustomerVo selectCustomerByCifWithCostCenterName(Integer cif) throws Exception;
    
    public CustomerVo customerInfo(CustomerVo vo) throws Exception;//Add By Pound
}
