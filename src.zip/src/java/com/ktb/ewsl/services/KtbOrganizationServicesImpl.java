/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.KtbOrganization;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class KtbOrganizationServicesImpl implements KtbOrganizationServices{
    
    private static Logger logger = Logger.getLogger(KtbOrganizationServicesImpl.class);
    
    @Autowired
    public JdbcTemplate jdbcTemplate;
     
    @Override
    public String findCostCenterName(String responUnit) throws Exception {
       
        if (logger.isInfoEnabled()) {
            logger.info("KtbOrganizationServicesImpl.findCostCenterName");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COSTCENTER_NAME  FROM TBL_MT_KTB_ORGANIZATION ");
        sql.append(" WHERE COSTCENTER_CODE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{responUnit}, String.class);
    }

    @Override
    public ArrayList<DropdownVo> getWorkLine() throws Exception {
        ArrayList<DropdownVo> result ;
        if (logger.isInfoEnabled()) {
            logger.info("KtbOrganizationServicesImpl.getWorkLine");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" select COSTCENTER_CODE , COSTCENTER_NAME   from TBL_MT_KTB_ORGANIZATION  ");
        sql.append(" where  COSTCENTER_CODE = '108018' AND  ");
        sql.append(" (GROUP_CODE IS NULL) AND (REGION_CODE IS NULL) AND (DEPARTMENT_CODE IS NULL) AND BUSINESSUNIT_CODE = COSTCENTER_CODE  ");
  
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo item = new DropdownVo();
                    item.setId(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setDesc(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    return item;
                }
            });
        return result;
    }

    @Override
    public ArrayList<DropdownVo> getOrganizationGroup(String businessUnit) throws Exception {
        ArrayList<DropdownVo> result ;
        if (logger.isInfoEnabled()) {
            logger.info("KtbOrganizationServicesImpl.getOrganizationGroup");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" select COSTCENTER_CODE , COSTCENTER_NAME from TBL_MT_KTB_ORGANIZATION ");
        sql.append(" where BUSINESSUNIT_CODE = ? and GROUP_CODE IS NULL AND BUSINESSUNIT_CODE <> COSTCENTER_CODE ");
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{businessUnit}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo item = new DropdownVo();
                    item.setId(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setDesc(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    return item;
                }
            });
        return result;
    }

    @Override
    public ArrayList<DropdownVo> getDepartment(String businessUnit, String groupCode) throws Exception {
       ArrayList<DropdownVo> result ;
        if (logger.isInfoEnabled()) {
            logger.info("KtbOrganizationServicesImpl.getDepartment");
        }
        StringBuilder sql = new StringBuilder();
         sql.append(" select COSTCENTER_CODE , COSTCENTER_NAME from TBL_MT_KTB_ORGANIZATION  ");
         sql.append(" where BUSINESSUNIT_CODE = ? and GROUP_CODE = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{businessUnit,groupCode}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo item = new DropdownVo();
                    item.setId(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setDesc(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    return item;
                }
            });
        return result;
    }

    @Override
    public KtbOrganization getOrganizationByCostcenter(String costcenter) throws Exception {
       KtbOrganization orgVO = new KtbOrganization();
       try{
        ArrayList<KtbOrganization> result ;
        if (logger.isInfoEnabled()) {
            logger.info("KtbOrganizationServicesImpl.getOrganizationByCostcenter");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT COSTCENTER_CODE, COSTCENTER_NAME, ORGANIZATION_TYPE, PARENT_CODE, BUSINESSUNIT_CODE, GROUP_CODE, REGION_CODE, DEPARTMENT_CODE ");
        sql.append("  FROM TBL_MT_KTB_ORGANIZATION  ");
        sql.append(" WHERE COSTCENTER_CODE = ? AND IS_ACTIVE = 1  ");

        result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{costcenter}, new RowMapper() {
              public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                  KtbOrganization item = new KtbOrganization();
                  item.setCostCenterCode(rs.getInt("COSTCENTER_CODE"));
                  item.setCostCenterName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                  item.setOrganizationType(StringUtil.getValue(rs.getString("ORGANIZATION_TYPE")));
                  item.setParentCode(rs.getInt("PARENT_CODE"));
                  item.setBusinessUnitCode(rs.getInt("BUSINESSUNIT_CODE")); //สายงาน
                  item.setGroupCode(rs.getInt("GROUP_CODE")); //กลุ่มงาน
                  item.setRegionCode(rs.getInt("REGION_CODE"));
                  item.setDepartmentCode(rs.getInt("DEPARTMENT_CODE")); //หน่วยงาน
                  return item;
              }
          });
        
        if(!result.isEmpty() && result.size() > 0 ){
                orgVO = (KtbOrganization)result.get(0);
        }
       }catch(Exception e){
          throw e;
       }
       return orgVO;
    }

    @Override
    public ArrayList<DropdownVo> getResponseUnit(String businessUnit, String groupCode, String fieldOrder) throws Exception {
        ArrayList<DropdownVo> result ;
        StringBuilder sql = new StringBuilder();
         sql.append(" select COSTCENTER_CODE , COSTCENTER_NAME from TBL_MT_KTB_ORGANIZATION  ");
         sql.append(" where 0=0  AND ORGANIZATION_TYPE = 'BC-M' AND IS_ACTIVE = 1  ");
         if(!ValidatorUtil.isNullOrEmpty(businessUnit)){
             sql.append(" AND  BUSINESSUNIT_CODE = '").append(businessUnit).append("'");
         }
         if(!ValidatorUtil.isNullOrEmpty(groupCode)){
            sql.append(" AND  GROUP_CODE = '").append(groupCode).append("'");
         }
         if(!ValidatorUtil.isNullOrEmpty(fieldOrder)){
            sql.append(" ORDER BY  ").append(fieldOrder).append(" ASC ");
         }

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo item = new DropdownVo();
                    item.setId(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setDesc(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    return item;
                }
            });
        return result;
    }

    @Override
    public ArrayList<DropdownVo> getOrganizationResponseUnit(String costcenter, String fieldOrder) throws Exception {
    ArrayList<DropdownVo> result ;
    StringBuilder sql = new StringBuilder();
        sql.append("  select COSTCENTER_CODE , COSTCENTER_NAME from TBL_MT_KTB_ORGANIZATION ");
        sql.append("  where 0=0  AND ORGANIZATION_TYPE = 'BC-M' AND IS_ACTIVE = 1  ");
        sql.append("  AND (BUSINESSUNIT_CODE = '").append(costcenter).append("' OR GROUP_CODE = '").append(costcenter).append("' OR COSTCENTER_CODE = '").append(costcenter).append("') ");
        sql.append(" ORDER BY ").append(fieldOrder).append(" ASC ");
          if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo item = new DropdownVo();
                    item.setId(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setDesc(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    return item;
                }
            });
        return result;
    }

    @Override
    public ArrayList getOrganizationGroupAndEwsUse(String businessUnit) throws Exception {
       ArrayList<DropdownVo> result ;
        if (logger.isInfoEnabled()) {
            logger.info("KtbOrganizationServicesImpl.getOrganizationGroupAndEwsUse");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" select COSTCENTER_CODE , COSTCENTER_NAME from TBL_MT_KTB_ORGANIZATION ");
        sql.append(" where BUSINESSUNIT_CODE = ? and GROUP_CODE IS NULL AND BUSINESSUNIT_CODE <> COSTCENTER_CODE ");
         sql.append("  AND IS_EWSL = 1  ");
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{businessUnit}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo item = new DropdownVo();
                    item.setId(StringUtil.getValue(rs.getString("COSTCENTER_CODE")));
                    item.setDesc(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    return item;
                }
            });
        return result;
    }
     
    public String getCostCenterDescByCode(String costCenterCode) throws Exception{
        String costCenterName = "";
        if(!ValidatorUtil.isNullOrEmpty(costCenterCode)){
            KtbOrganization ktbOrganization = getOrganizationByCostcenter(costCenterCode);
            if(ktbOrganization != null){
                costCenterName = costCenterCode + " - " + ktbOrganization.getCostCenterName();
            }else{
                costCenterName = costCenterCode;
            }
        }
        return costCenterName;
        
    }
    
}
