/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningTypeVo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public interface WarningTypeService {
    public List<WarningTypeVo> findWarningType() throws Exception;
    public List<WarningTypeVo> findWarningTypeByFilter(WarningTypeVo warningTypeVo) throws Exception;
    public void updateWarningType(WarningTypeVo warningTypeVo) throws Exception;
    public Integer findSLAByWarningType(String waringTypeCode) throws Exception ;
    public List<WarningTypeVo> findWarningTypeByUnderType(String underWarningType) throws Exception;
    public List<WarningTypeVo> findWarningTypeByWarningType(String warningType) throws Exception;
    //------------------ Size L -------------------//
    public ArrayList<WarningTypeVo> getColumnByPrivilege(String roleId , String warningTypeGroup)throws Exception;
    public ArrayList<WarningTypeVo> findWarningTypeUnderWarningTypeIsNull(WarningTypeVo warningTypeVo)throws Exception;
    public void updateSlaByWarningTypeCode(int sla, String warningTypeCode,String updateBy) throws Exception;
    public void updateSlaByUnderWarningTypeCode(int sla, String warningTypeCode,String updateBy) throws Exception;
    public WarningTypeVo getWarningTypeDetail(String warningTypeCode) throws Exception;
    public void insertWarningTypeSlaHistory(WarningTypeVo warningTypeVo) throws Exception;
    public Integer countUnderWarningTypeCode(String warningTypeCode) throws Exception;
    public ArrayList<WarningTypeVo> findWarningTypeForEwsl() throws Exception;
    public ArrayList<WarningTypeVo> findWarningTypeForUnderWarningTypeEwsq() throws Exception ;
    
    
}
