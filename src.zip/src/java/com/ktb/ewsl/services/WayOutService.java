/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.FormStatusControlVo;
import com.ktb.ewsl.vo.QuestionVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningWayOutVo;
import java.util.List;

/**
 *
 * @author KTB_User
 */
public interface WayOutService {
    public List<QuestionVo> findQuestionWayOut(QuestionVo filter) throws Exception;    
    public WarningWayOutVo findTblWarningWayOutForm(QuestionVo filter) throws Exception;    
    public int insertTblWarningWayOutForm(List<WarningWayOutVo> warningWayOutList) throws Exception;
    public int DeleteTblWarningWayOutForm(QuestionVo filter) throws Exception;    
    public String findStatusTblFormStatusControl(FormStatusControlVo formStatusControlVo)throws Exception;
    public int insertTblActionHistory(ActionHistoryVo actionHistoryVo) throws Exception;
    public int updateTblWarningInfo(WarningInfoVo warningInfoVo) throws Exception;
//    public int updateTblWarningHeader(WarningHeaderVo warningHeaderVo) throws Exception;
    public List<QuestionVo> findQuestionWayOutForBCM(QuestionVo filter) throws Exception;
}
