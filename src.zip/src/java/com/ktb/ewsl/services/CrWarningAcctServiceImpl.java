/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.CrWarningAcctVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author pumin
 */
@Repository
public class CrWarningAcctServiceImpl implements CrWarningAcctService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(CrWarningAcctServiceImpl.class);

    @Override
    public ArrayList<CrWarningAcctVo> getCrWarningAcctList (String cif, String flag) throws Exception {

        ArrayList<CrWarningAcctVo> result = null;
        StringBuilder sql = new StringBuilder("");
        try {
            if (log.isInfoEnabled()) {
                log.info("[getCrWarningAcctList][Begin]");
            }

            sql.append("SELECT * FROM TBL_CR_WARNING_ACCOUNT");
            sql.append("         WHERE RENEW_FLG = 'N'");
                          
            if(flag.equals("M")){
                sql.append("        AND MATURITY_DATE > CURRENT TIMESTAMP");
            }else{
                sql.append("        AND MATURITY_DATE <= CURRENT TIMESTAMP");
            }
            sql.append("            AND CIF = ?");
            
            if (log.isInfoEnabled()) {
                log.info("[getCrWarningAcctList] sql :: " + sql.toString());
            }
            
            result = (ArrayList<CrWarningAcctVo>) jdbcTemplate.query(sql.toString(), new Object[]{cif}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CrWarningAcctVo vo = new CrWarningAcctVo();
                    
                    try{
                        vo.setAccountNo(StringUtil.getValue(rs.getString("ACCOUNT_NO")));
                        vo.setAccountSubType(StringUtil.getValue(rs.getString("ACCOUNT_SUB_TYPE")));
                        vo.setcFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                        vo.setCif(StringUtil.getValue(rs.getString("CIF")));
                        vo.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                        vo.setCreatedDt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CREATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CREATED_DT")));
                        vo.setLimitAmt(MoneyUtil.formatMoney(rs.getString("LIMIT_AMT")));
                        vo.setLoanType(StringUtil.getValue(rs.getString("LOAN_TYPE")));
                        vo.setMaturityDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
                        vo.setOutstandingAmt(MoneyUtil.formatMoney(rs.getString("OUTSTANDING_AMT")));
                        vo.setProductGroup(StringUtil.getValue(rs.getString("PRODUCT_GROUP")));
                        vo.setProductType(StringUtil.getValue(rs.getString("PRODUCT_TYPE")));
                        vo.setRenewDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("RENEW_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("RENEW_DATE")));
                        vo.setRenewFlg(StringUtil.getValue(rs.getString("RENEW_FLG")));
                        vo.setRevolveFlg(StringUtil.getValue(rs.getString("REVOLVE_FLG")));
                        vo.setSourceSystem(StringUtil.getValue(rs.getString("SOURCE_SYSTEM")));
                        vo.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                        vo.setUpdatedDt(rs.getTimestamp("UPDATED_DT"));
                        vo.setWarningDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                    }catch(Exception e){
                        log.error(e);
                    }
                    return vo;
                }
            });

        } catch (Exception e) {
            log.error("Error occur in while process MtFormConfigServiceImpl.getFormConfigDetail: " + e.getMessage(), e);
            throw e;
        }
        return result;
    }

    @Override
    public ArrayList<CrWarningAcctVo> getCrWarningAcctListByCif(String cif) throws Exception {
        ArrayList<CrWarningAcctVo> result = null;
        StringBuilder sql = new StringBuilder("");
        try {
            if (log.isInfoEnabled()) {
                log.info("[getCrWarningAcctListByCif][Begin]");
            }

            sql.append("SELECT * FROM TBL_CR_WARNING_ACCOUNT WHERE CIF = ?");
            
            if (log.isInfoEnabled()) {
                log.info("[getCrWarningAcctListByCif] sql :: " + sql.toString());
            }
            
            result = (ArrayList<CrWarningAcctVo>) jdbcTemplate.query(sql.toString(), new Object[]{cif}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CrWarningAcctVo vo = new CrWarningAcctVo();
                    
                    try{
                        vo.setAccountNo(StringUtil.getValue(rs.getString("ACCOUNT_NO")));
                        vo.setAccountSubType(StringUtil.getValue(rs.getString("ACCOUNT_SUB_TYPE")));
                        vo.setcFinal(StringUtil.getValue(rs.getString("C_FINAL")));
                        vo.setCif(StringUtil.getValue(rs.getString("CIF")));
                        vo.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                        vo.setCreatedDt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CREATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CREATED_DT")));
                        vo.setLimitAmt(MoneyUtil.formatMoney(rs.getString("LIMIT_AMT")));
                        vo.setLoanType(StringUtil.getValue(rs.getString("LOAN_TYPE")));
                        vo.setMaturityDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
                        vo.setMaturityDateDt(rs.getTimestamp("MATURITY_DATE"));
                        vo.setNextMaturityDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("NEXT_MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("NEXT_MATURITY_DATE")));
                        vo.setNextMaturityDateDt(rs.getTimestamp("NEXT_MATURITY_DATE"));
                        vo.setOutstandingAmt(MoneyUtil.formatMoney(rs.getString("OUTSTANDING_AMT")));
                        vo.setProductGroup(StringUtil.getValue(rs.getString("PRODUCT_GROUP")));
                        vo.setProductType(StringUtil.getValue(rs.getString("PRODUCT_TYPE")));
                        vo.setRenewDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("RENEW_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("RENEW_DATE")));
                        vo.setRenewFlg(StringUtil.getValue(rs.getString("RENEW_FLG")));
                        vo.setRevolveFlg(StringUtil.getValue(rs.getString("REVOLVE_FLG")));
                        vo.setSourceSystem(StringUtil.getValue(rs.getString("SOURCE_SYSTEM")));
                        vo.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
//                        vo.setUpdatedDt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("UPDATED_DT")));
                        vo.setUpdatedDt(rs.getTimestamp("UPDATED_DT"));
                        vo.setWarningDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                        vo.setWarningDateDt(rs.getTimestamp("WARNING_DATE"));
                    }catch(Exception e){
                        log.error(e);
                    }
                    return vo;
                }
            });

        } catch (Exception e) {
            log.error("Error occur in while process MtFormConfigServiceImpl.getCrWarningAcctListByCif: " + e.getMessage(), e);
            throw e;
        }
        return result;
    }
    
    @Override
    public void updateDataFormCBS(CrWarningAcctVo vo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("[updateDataFormCBS][Begin]");
        }
        
        Object[] obj = new Object[]{vo.getNextMaturityDate()
                                    , vo.getRenewFlg()
//                                    , vo.getRenewDateDt()
//                                    , vo.getUpdatedDt()
                                    , vo.getUpdatedBy()
                                    , vo.getMaturityDate()
                                    , vo.getCif()
                                    , vo.getAccountNo()
                                    };
        
        log.info("[updateDataFormCBS] obj :: " + obj.toString());
        
        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_CR_WARNING_ACCOUNT SET NEXT_MATURITY_DATE = to_date(?, 'dd/MM/yyyy'), RENEW_FLG = ?, RENEW_DATE = sysdate, UPDATED_DT = sysdate, UPDATED_BY = ? ");
        sql.append("  WHERE MATURITY_DATE = to_date(?, 'dd/MM/yyyy') and CIF = ? and ACCOUNT_NO = ?");
        
        log.info("[updateDataFormCBS] sql :: " + sql.toString());
        
        jdbcTemplate.update(sql.toString(), obj);
    }
}
