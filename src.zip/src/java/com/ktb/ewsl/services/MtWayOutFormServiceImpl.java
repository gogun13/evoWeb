/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.MtWayOutFormVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Pratya
 */
@Repository
public class MtWayOutFormServiceImpl implements MtWayOutFormService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(MtWayOutFormServiceImpl.class);

    @Override
    public ArrayList<MtWayOutFormVo> getQuestionList() throws Exception {

        ArrayList<MtWayOutFormVo> result = null;
        try {
            if (log.isInfoEnabled()) {
                log.info("MtWayOutFormServiceImpl");
            }

            StringBuilder sql = new StringBuilder("SELECT * FROM TBL_MT_WAYOUT_FORM WHERE IS_ACTIVE =? ORDER BY SEQ ");
            result = (ArrayList<MtWayOutFormVo>) jdbcTemplate.query(sql.toString(), new Object[]{"1"}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    MtWayOutFormVo vo = new MtWayOutFormVo();
                    
                    vo.setWayOutId      (rs.getString("WAYOUT_ID"));
                    vo.setWayOutDesc    (rs.getString("WAYOUT_DESC"));
                    vo.setShowType      (rs.getString("SHOW_TYPE"));
                    vo.setIsActive      (rs.getString("IS_ACTIVE"));
                    vo.setSeq           (rs.getString("SEQ"));
                    return vo;
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error occur in while process MtWayOutFormServiceImpl.getQuestionList: " + e.getMessage(), e);
        }
        return result;
    }
}
