/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.InOutLogVo;

/**
 *
 * @author KTBDevLoan
 */
public interface InOutLogService {
    
    public void insertInOutLog(InOutLogVo inOutLogVo)throws Exception;
    public void updateLogout(InOutLogVo inOutLogVo)throws Exception;
    public Integer findUserIdAndDeviceIPOnJob(String userId , String userIP , String serverIP) throws Exception;
    public Integer findUserIdOnJob(String userId) throws Exception;
    public Integer findDeviceIPOnJob( String userIP , String serverIP) throws Exception;
    public void updateExpire(InOutLogVo inOutLogVo)throws Exception;
    public Integer findUserIdAndDeviceIPForBaseAction(String userId , String userIP , String serverIP , String sessionId) throws Exception;
}
