/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningFactorVo;

/**
 *
 * @author Asamo
 */
public interface WarningFactorService {
    public void saveWarningFactor(WarningFactorVo warningFactorVo) throws Exception;
    public void deleteWarningFactor(WarningFactorVo warningFactorVo) throws Exception;
}
