/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.DropdownVo;
import com.ktb.ewsl.vo.UserVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.services.KTBEmpDirectoryService;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.CollectionUtil;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTB_User
 */
@Repository
public class RoleAssignmentServiceImpl extends AbstractJdbcService implements RoleAssignmentService{
    private static final Logger logger = Logger.getLogger(RoleAssignmentServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplateTBForEWSL;
    
    @Autowired
    KTBEmpDirectoryService ktbEmpDirectoryService;
    
    @Override
    public String getRoleCodeDesc(String isConfig, String roleCode) throws Exception {
        String result = null;
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getRoleCodeDesc");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ROLE_CODE, ROLE_NAME ");
        sql.append("FROM TBL_MT_ROLE ");
        sql.append("WHERE IS_CONFIG = ? AND ROLE_CODE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        ArrayList resultList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{isConfig, roleCode}, new RowMapper() {
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                return StringUtil.getValue(rs.getString("ROLE_NAME"));
            }
        });
        if (!resultList.isEmpty()) {
            result = (String) resultList.get(0);
        }
        return result;                
    }
                   
    @Override
    public List<DropdownVo> getRoleList(String isConfig) throws Exception {
        List<DropdownVo> dropdownList = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("RoleAssignmentServiceImpl.getRoleList");
            }
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT ROLE_CODE, ROLE_NAME ");
            sql.append("FROM TBL_MT_ROLE ");
            sql.append("WHERE IS_CONFIG = ?");            
    
            if (logger.isDebugEnabled()) {
                logger.debug("SQL >>> " + sql.toString());
            }
            dropdownList = jdbcTemplate.query(sql.toString(), new Object[]{isConfig}, new RowMapper() {
                public DropdownVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DropdownVo vo = new DropdownVo();
                    vo.setId((String) rs.getString("ROLE_CODE"));
                    vo.setDesc((String) rs.getString("ROLE_NAME"));                
                    return vo;
                }
            });            
        } catch (Exception e) {
            logger.error("Error RoleAssignmentServiceImpl.getRoleList: " + e.getMessage(), e);
        }
        return dropdownList;
    }
    
    @Override
    public List<UserVo> getUserMtRolePrivilege(SearchBean searchBean) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT EMPLOYEE_ID ");        
        sql.append(" FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append(" WHERE 1 = 1 ");         
        sql.append(" ORDER BY EMPLOYEE_ID ");
        if (logger.isInfoEnabled()) {
            logger.info("sql: " + sql.toString());
        }
        ArrayList<UserVo> list = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                int i = 1;
                UserVo vo = new UserVo();
                vo.setEmpNo(rs.getString("EMPLOYEE_ID"));
                return vo;
            }
        });
        if (logger.isInfoEnabled()) {
            logger.info("list size :" + CollectionUtil.getSize(list));
        }
        return list;
    }
        
    @Override
    public List<UserVo> getUserMtRolePrivilegeList(String where) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeList Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT * ");        
        sql.append(" FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append(" WHERE 1 = 1 ");
        sql.append(where);
        //sql.append(" ORDER BY EMPLOYEE_ID ");
        if (logger.isInfoEnabled()) {
            logger.info("sql: " + sql.toString());
        }
        ArrayList<UserVo> list = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                                
                return getResultSetUser(rs);
            }
        });
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeList list size :" + CollectionUtil.getSize(list));        
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeList Finish");
        }
        return list;
    }
        
    @Override
    public PaginatedListImpl<UserVo> getUserTBList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        StringBuilder sql = new StringBuilder();

        sql.append("  SELECT A.EMP_NO AS EMP_NO, A.EMP_NAME_ENG AS EMP_NAME_ENG, A.EMP_SURNAME_ENG AS EMP_SURNAME_ENG, A.EMP_NAME_THAI AS EMP_NAME_THAI, ");
        sql.append("         A.EMP_SURNAME_THAI AS EMP_SURNAME_THAI, A.DEPT_CODE AS DEPT_CODE, A.KTB_FIELD_MAP AS KTB_FIELD_MAP, A.TITLE_NAME_THAI AS TITLE_NAME_THAI, ");
        sql.append("         A.EMP_POSITION AS EMP_POSITION, A.EMPLOYED_STATUS AS EMPLOYED_STATUS, A.JOB_CODE AS JOB_CODE, A.EMP_TO AS EMP_TO, ");
        sql.append("         B.DEPT_NAME AS DEPT_NAME, ");
        sql.append("         A.TITLE_NAME_THAI||' '|| A.EMP_NAME_THAI||' '|| A.EMP_SURNAME_THAI AS EMP_FULL_NAME ");        
        sql.append("  FROM tbadm.USER_DETAIL A ");
        sql.append("    INNER JOIN tbadm.DEPARTMENT B ON A.DEPT_CODE = B.DEPT_CODE ");
        sql.append("  WHERE A.EMPLOYED_STATUS = 'A' ");
        
        logger.info("RoleAssignmentServiceImpl.getUserTBList ById="+StringUtil.notNull(searchBean.getById())+", TextSearch="+StringUtil.notNull(searchBean.getTextSearch()));
              
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNo())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND A.EMP_NO LIKE '%").append(searchBean.getUser().getEmpNo()).append("%' ");

        if (!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNameThai())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND A.EMP_NAME_THAI LIKE '%").append(searchBean.getUser().getEmpNameThai()).append("%' ");

        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND A.DEPT_CODE = '").append(searchBean.getUser().getDeptCode()).append("' ");        

        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND B.DEPT_NAME LIKE '%").append(searchBean.getUser().getDeptName()).append("%' ");

        if (!"".equals(StringUtil.notNull(searchBean.getStatus())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND A.EMPLOYED_STATUS = '").append(searchBean.getStatus()).append("' ");
             
        if("1".equals(StringUtil.notNull(searchBean.getById()))){               //Radio รหัส, คำอธิบาย   
            sql.append(" AND (A.EMP_NO LIKE '%").append(searchBean.getUser().getEmpNo()).append("%' OR ");
            sql.append(" A.DEPT_CODE = '").append(searchBean.getUser().getDeptCode()).append("') ");
        }else if("2".equals(StringUtil.notNull(searchBean.getById()))){         //Radio รหัส, คำอธิบาย   
            sql.append(" AND (A.EMP_NAME_THAI LIKE '%").append(searchBean.getUser().getEmpNameThai()).append("%' OR ");
            sql.append(" A.EMP_SURNAME_THAI LIKE '%").append(searchBean.getUser().getEmpNameThai()).append("%' OR ");            
            sql.append(" B.DEPT_NAME = '").append(searchBean.getUser().getDeptName()).append("') ");
        }                                                                                
        
        if (logger.isInfoEnabled()) {            
            logger.info("RoleAssignmentServiceImpl.getUserTBList sql="+sql.toString());
        }                     
        
        sql.append(" ORDER BY A.EMP_NO, A.DEPT_CODE ");
        String rowNumSql = decorateRowNumSQL(sql.toString(), paginate.getIndex(), paginate.getPageSize()); 
        ArrayList<UserVo> list = (ArrayList) jdbcTemplateTBForEWSL.query(rowNumSql, new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                int i = 1;                
                UserVo vo = new UserVo();
                vo.setEmpNo(StringUtil.notNull(rs.getString("EMP_NO")));
                vo.setEmpTitleDesc(StringUtil.notNull(rs.getString("TITLE_NAME_THAI")));
                vo.setEmpFirstName(StringUtil.notNull(rs.getString("EMP_NAME_THAI")));
                vo.setEmpLastName(StringUtil.notNull(rs.getString("EMP_SURNAME_THAI")));
                vo.setEmpFullName(StringUtil.notNull(rs.getString("EMP_FULL_NAME")));                                                
                vo.setStatus(StringUtil.notNull(""));
                vo.setRoleId(StringUtil.notNull(""));
                vo.setDeptCd(StringUtil.notNull(rs.getString("DEPT_CODE")));
                vo.setDeptName(StringUtil.notNull(rs.getString("DEPT_NAME")));
                return vo;
            }
        });               
        int totalRecord = countTotal(sql.toString(), jdbcTemplateTBForEWSL);
        paginate.setTotalRecord(totalRecord);
        paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
        paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
        paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
        paginate.setList(list);                
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getUserTBList totalRecord="+totalRecord);
        }
        return paginate;
    }
    
    @Override
    public PaginatedListImpl<UserVo> getDepartmentList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT A.DEPT_CODE, A.DEPT_NAME ");        
        sql.append(" FROM tbadm.DEPARTMENT A ");
        sql.append(" WHERE 1=1 ");
        
        logger.info("RoleAssignmentServiceImpl.getDepartmentList ById="+StringUtil.notNull(searchBean.getById())+", TextSearch="+StringUtil.notNull(searchBean.getTextSearch()));
                      
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND A.DEPT_CODE = '").append(searchBean.getUser().getDeptCode()).append("' ");        

        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName())) && "".equals(StringUtil.notNull(searchBean.getById())))
            sql.append(" AND A.DEPT_NAME LIKE '%").append(searchBean.getUser().getDeptName()).append("%' ");
             
        if("1".equals(StringUtil.notNull(searchBean.getById()))){               //Radio รหัส, คำอธิบาย               
            sql.append(" AND A.DEPT_CODE = '").append(searchBean.getUser().getDeptCode()).append("' ");
        }else if("2".equals(StringUtil.notNull(searchBean.getById()))){         //Radio รหัส, คำอธิบาย               
            sql.append(" AND A.DEPT_NAME LIKE '%").append(searchBean.getUser().getDeptName()).append("%' ");
        }                                                                                
        
        if (logger.isInfoEnabled()) {            
            logger.info("RoleAssignmentServiceImpl.getDepartmentList sql="+sql.toString());
        }                     
        
        sql.append(" ORDER BY A.DEPT_CODE ");
        String rowNumSql = decorateRowNumSQL(sql.toString(), paginate.getIndex(), paginate.getPageSize()); 
        ArrayList<UserVo> list = (ArrayList) jdbcTemplateTBForEWSL.query(rowNumSql, new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                
                UserVo vo = new UserVo();
                vo.setDeptCd(StringUtil.notNull(rs.getString("DEPT_CODE")));
                vo.setDeptName(StringUtil.notNull(rs.getString("DEPT_NAME")));
                return vo;
            }
        });               
        int totalRecord = countTotal(sql.toString(), jdbcTemplateTBForEWSL);
        paginate.setTotalRecord(totalRecord);
        paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
        paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
        paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
        paginate.setList(list);                
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getDepartmentList totalRecord="+totalRecord);
        }
        return paginate;
    }
     
    @Override
    public List<UserVo> getUserTBList(String where) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("  SELECT A.EMP_NO AS EMP_NO, A.EMP_NAME_ENG AS EMP_NAME_ENG, A.EMP_SURNAME_ENG AS EMP_SURNAME_ENG, A.EMP_NAME_THAI AS EMP_NAME_THAI, ");
        sql.append("         A.EMP_SURNAME_THAI AS EMP_SURNAME_THAI, A.DEPT_CODE AS DEPT_CODE, A.KTB_FIELD_MAP AS KTB_FIELD_MAP, A.TITLE_NAME_THAI AS TITLE_NAME_THAI, ");
        sql.append("         A.EMP_POSITION AS EMP_POSITION, A.EMPLOYED_STATUS AS EMPLOYED_STATUS, A.JOB_CODE AS JOB_CODE, A.EMP_TO AS EMP_TO, ");
        sql.append("         B.DEPT_NAME AS DEPT_NAME, ");
        sql.append("         A.TITLE_NAME_THAI||' '|| A.EMP_NAME_THAI||' '|| A.EMP_SURNAME_THAI AS EMP_FULL_NAME ");        
        sql.append("  FROM tbadm.USER_DETAIL A, tbadm.DEPARTMENT B ");
        sql.append("  WHERE 1=1 AND A.DEPT_CODE = B.DEPT_CODE ");
        sql.append(where);                
                  
        if (logger.isInfoEnabled()) {            
            logger.info("RoleAssignmentServiceImpl.getUserTBList sql="+sql.toString());
        }                                        
        sql.append(" ORDER BY A.EMP_NO, A.DEPT_CODE ");        
        ArrayList<UserVo> userVoList = (ArrayList) jdbcTemplateTBForEWSL.query(sql.toString(), new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                           
                UserVo vo = new UserVo();
                vo.setEmpNo(StringUtil.notNull(rs.getString("EMP_NO")));
                vo.setEmpTitleDesc(StringUtil.notNull(rs.getString("TITLE_NAME_THAI")));
                vo.setEmpFirstName(StringUtil.notNull(rs.getString("EMP_NAME_THAI")));
                vo.setEmpLastName(StringUtil.notNull(rs.getString("EMP_SURNAME_THAI")));
                vo.setEmpFullName(StringUtil.notNull(rs.getString("EMP_FULL_NAME")));                                
                vo.setDeptCd(StringUtil.notNull(rs.getString("DEPT_CODE")));
                vo.setDeptName(StringUtil.notNull(rs.getString("DEPT_NAME")));
                
                vo.setEmployedStatus(StringUtil.notNull(rs.getString("EMPLOYED_STATUS")));
                
                return vo;
            }
        });                                             
        if (logger.isInfoEnabled()) {
           logger.info("RoleAssignmentServiceImpl.getUserTBList siz="+CollectionUtil.getSize(userVoList));
        }               
        return userVoList;
    } 
     
    @Override
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT * ");        
        sql.append(" FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append(" WHERE ROLE_CODE != 'AD' ");
        
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNo())))
            sql.append(" AND EMPLOYEE_ID LIKE '%").append(searchBean.getUser().getEmpNo()).append("%' ");
        
        if (!"".equals(StringUtil.notNull(searchBean.getByFirstName())))
            sql.append(" AND EMPLOYEE_ID IN (").append(searchBean.getByFirstName()).append(") ");        
        
        if (!"".equals(StringUtil.notNull(searchBean.getRoleId())))
            sql.append(" AND ROLE_CODE = '").append(searchBean.getRoleId()).append("' ");
                  
        if (!"".equals(StringUtil.notNull(searchBean.getEndDateStr())))
            sql.append(" AND END_DATE = '").append(searchBean.getEndDateStr()).append("' ");                                                     
        
        if (!"".equals(StringUtil.notNull(searchBean.getStatus())))
            sql.append(" AND IS_ACTIVE = '").append(searchBean.getStatus()).append("' ");                                                     
                
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode())))
            sql.append(" AND DEPT_CODE LIKE '%").append(searchBean.getUser().getDeptCode()).append("%' ");        
        
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName())))
            sql.append(" AND DEPT_NAME LIKE '%").append(searchBean.getUser().getDeptName()).append("%' ");
        
        if (!"".equals(StringUtil.notNull(searchBean.getToDate()))){
            String thaiEnYear = DateUtil.convertToEnYearStr(searchBean.getToDate());                                    
            sql.append(" AND TO_CHAR(END_DATE,'DD/MM/YYYY') = '").append(thaiEnYear).append("' ");
        }        
        sql.append(" AND ROLE_CODE IN (SELECT ROLE_CODE FROM TBL_MT_ROLE WHERE IS_CONFIG = '").append(BusinessConst.Flag.Y).append("') ");                
        if (logger.isInfoEnabled()) {            
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeList sql="+sql.toString());
        }                             
        sql.append(" ORDER BY EMPLOYEE_ID ");
        String rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize()); 
        ArrayList<UserVo> list = (ArrayList) jdbcTemplate.query(rowNumSql, new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                                                
                return getResultSetUser(rs);
            }
        });                       
        int totalRecord = countTotal(sql.toString());
        paginate.setTotalRecord(totalRecord);
        paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
        paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
        paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
        paginate.setList(list);                
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeList totalRecord="+totalRecord);
        }
        return paginate;
    }
    
    @Override
    public PaginatedListImpl<UserVo> getUserMtRolePrivilegeHistoryList(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT * ");        
        sql.append(" FROM TBL_MT_ROLE_PRIVILEGE_HISTORY ");
        sql.append(" WHERE 1=1 ");
        
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getEmpNo())))
            sql.append(" AND EMPLOYEE_ID LIKE '%").append(searchBean.getUser().getEmpNo()).append("%' ");               
        
        if (!"".equals(StringUtil.notNull(searchBean.getByFirstName())))
            sql.append(" AND EMPLOYEE_ID IN (").append(searchBean.getByFirstName()).append(") ");                                                                              
                
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptCode())))
            sql.append(" AND DEPT_CODE LIKE '%").append(searchBean.getUser().getDeptCode()).append("%' ");        
        
        if (!"".equals(StringUtil.notNull(searchBean.getUser().getDeptName())))
            sql.append(" AND DEPT_NAME LIKE '%").append(searchBean.getUser().getDeptName()).append("%' ");
        
        /*if (!"".equals(StringUtil.notNull(searchBean.getToDate()))){
            String thaiEnYear = DateUtil.convertToEnYearStr(searchBean.getToDate());                                    
            sql.append(" AND TO_CHAR(END_DATE,'DD/MM/YYYY') = '").append(thaiEnYear).append("' ");
        }*/
        if (logger.isInfoEnabled()) {            
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeHistoryList sql="+sql.toString());
        }                             
        sql.append(" ORDER BY EMPLOYEE_ID, DATETIME DESC ");
        String rowNumSql = decorateRowNumSQLForDB2(sql.toString(), paginate.getIndex(), paginate.getPageSize()); 
        ArrayList<UserVo> list = (ArrayList) jdbcTemplate.query(rowNumSql, new RowMapper() {
            @Override
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                                                
                return getResultSetUser(rs);
            }
        });                       
        int totalRecord = countTotal(sql.toString());
        paginate.setTotalRecord(totalRecord);
        paginate.setFullListSizeWithPaging(totalRecord, pageAmt);
        paginate.setTotalRecordStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalRecord(), MoneyUtil.patternDPD));
        paginate.setTotalPageStr(MoneyUtil.convertNumberToStringByFormat(paginate.getTotalPages(), MoneyUtil.patternDPD));
        paginate.setList(list);                
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.getUserMtRolePrivilegeHistoryList totalRecord="+totalRecord);
        }
        return paginate;
    } 
    
    @Override
    public int validateSave(UserVo userVo) throws Exception {
        int result = 0;
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.validateSave Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT EMPLOYEE_ID ");
        sql.append("\nFROM TBL_MT_ROLE_PRIVILEGE ");                
        sql.append("\nWHERE EMPLOYEE_ID='").append(userVo.getEmpNo()).append("' ");
        //sql.append("\nAND ROLE_CODE='").append(userVo.getRoleId()).append("' ");
        //sql.append("\nAND DEPT_CODE='").append(userVo.getDeptCd()).append("' ");
        if (logger.isDebugEnabled()) {
            logger.debug("RoleAssignmentServiceImpl.validateSave SQL=" + sql.toString());
        }                
        ArrayList<String> list = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {                
                String result = rs.getString("EMPLOYEE_ID");
                return result;
            }
        });
        if (logger.isInfoEnabled()) {
            logger.info("list size=" + CollectionUtil.getSize(list));
        }
        if (CollectionUtil.isNotEmpty(list)) {
            result = 1;            
        }
        logger.info("RoleAssignmentServiceImpl.validateSave result=" + result);        
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.validateSave Finish");
        }
        //return jdbcTemplate.queryForObject(sql.toString(), new Object[]{byId}, Integer.class);
        return result;
    }
    
    @Override
    public int validateUpdate(String empNo, String roleCode, String deptCode) throws Exception {
        int result = 0;
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.validateUpdate Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT EMPLOYEE_ID ");
        sql.append("\nFROM TBL_MT_ROLE_PRIVILEGE ");                
        sql.append("\nWHERE EMPLOYEE_ID='").append(empNo).append("' ");
        sql.append("\nAND ROLE_CODE='").append(roleCode).append("' ");
        //sql.append("\nAND DEPT_CODE='").append(deptCode).append("' ");
        if (logger.isDebugEnabled()) {
            logger.debug("RoleAssignmentServiceImpl.validateUpdate SQL=" + sql.toString());
        }                
        ArrayList<String> list = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {                
                String result = rs.getString("EMPLOYEE_ID");
                return result;
            }
        });
        if (logger.isInfoEnabled()) {
            logger.info("list size=" + CollectionUtil.getSize(list));
        }
        if (CollectionUtil.isNotEmpty(list)) {
            result = 1;            
        }
        logger.info("RoleAssignmentServiceImpl.validateUpdate result=" + result);        
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.validateUpdate Finish");
        }        
        return result;
    }
            
    @Override
    public int saveUserMtRolePrivilege(UserVo userVo) throws Exception {
        int result = 0;
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.saveUserMtRolePrivilege Start");
        }                
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_MT_ROLE_PRIVILEGE ");
        sql.append("(EMPLOYEE_ID, ROLE_CODE, START_DATE,CREATED_DT, CREATED_BY, UPDATED_DT, ");
        sql.append(" UPDATED_BY, END_DATE, IS_ACTIVE, DEPT_CODE, DEPT_NAME) ");            
        sql.append(" VALUES(?, ?,sysdate, ?, ?, null, null, ?, ?, ?, ?)");        
        result = jdbcTemplate.update(sql.toString(), new Object[]{userVo.getEmpNo(), userVo.getRoleId(), userVo.getCreatedDate(), userVo.getCreatedBy(), userVo.getEndDate(), userVo.getIsActive(), userVo.getDeptCd(), userVo.getDeptName()}); 
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.saveUserMtRolePrivilege Finish");
        }
        return result;        
    }
    
    @Override
    public int saveUserMtRolePrivilegeHistory(UserVo userVo, String flag, java.util.Date paramDate) throws Exception {
        int result = 0;
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.saveUserMtRolePrivilegeHistory Start");
        }                
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_MT_ROLE_PRIVILEGE_HISTORY ");
        sql.append("(DATETIME, EMPLOYEE_ID, EMP_NAME, ROLE_CODE, CREATED_DT, ");
        sql.append(" CREATED_BY, UPDATED_DT, UPDATED_BY, END_DATE, IS_ACTIVE, ");                    
        sql.append(" DEPT_CODE, DEPT_NAME) ");          
        sql.append(" VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");        
        if("UPDATE".equals(flag)){
            result = jdbcTemplate.update(sql.toString(), new Object[]{
            userVo.getCreatedDate(), userVo.getEmpNo(), userVo.getEmpFullName(), userVo.getRoleId(), paramDate,
            userVo.getCreatedBy(), userVo.getUpdatedDate(), userVo.getUpdatedBy(), userVo.getEndDate(), userVo.getIsActive(),           
            ValidatorUtil.isNullOrEmpty(userVo.getDeptCd()) ? null : userVo.getDeptCd(), userVo.getDeptName()
            });
        }else{
            result = jdbcTemplate.update(sql.toString(), new Object[]{
            userVo.getCreatedDate(), userVo.getEmpNo(), userVo.getEmpFullName(), userVo.getRoleId(), userVo.getCreatedDate(),
            userVo.getCreatedBy(), userVo.getUpdatedDate(), userVo.getUpdatedBy(), userVo.getEndDate(), userVo.getIsActive(),           
            ValidatorUtil.isNullOrEmpty(userVo.getDeptCd()) ? null : userVo.getDeptCd(), userVo.getDeptName()
            });        
        }                
         
        logger.info("RoleAssignmentServiceImpl.saveUserMtRolePrivilegeHistory result="+result);
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.saveUserMtRolePrivilegeHistory Finish");
        }
        return result;        
    }

    @Override
    public int updateUserMtRolePrivilege(UserVo userVo, String oldRoleCode, String oldDeptCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateUserMtRolePrivilege Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_MT_ROLE_PRIVILEGE SET ROLE_CODE=?, UPDATED_DT=?, UPDATED_BY=?, END_DATE=?, IS_ACTIVE=?, DEPT_CODE=?, DEPT_NAME=?");
        //sql.append("\nWHERE EMPLOYEE_ID=? AND ROLE_CODE=? AND DEPT_CODE=? ");
        sql.append("\nWHERE EMPLOYEE_ID=? AND ROLE_CODE=? ");
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateUserMtRolePrivilege Finish");
        }
        int result = jdbcTemplate.update(sql.toString(), new Object[]{ 
            userVo.getRoleId(), userVo.getUpdatedDate(), userVo.getUpdatedBy(), userVo.getEndDate(), userVo.getIsActive(), 
            //userVo.getDeptCd(), userVo.getDeptName(), userVo.getEmpNo(), oldRoleCode, oldDeptCode}); 
            userVo.getDeptCd(), userVo.getDeptName(), userVo.getEmpNo(), oldRoleCode}); 
        return result;
    }
    
    @Override
    public int updateUserMtRolePrivilegeBySearch(UserVo userVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateUserMtRolePrivilegeBySearch Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_MT_ROLE_PRIVILEGE SET IS_ACTIVE=?, UPDATED_DT=?, UPDATED_BY=? ");
        sql.append("\nWHERE EMPLOYEE_ID=? AND ROLE_CODE=?");
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateUserMtRolePrivilegeBySearch Finish");
        }
        int result = jdbcTemplate.update(sql.toString(), new Object[]{userVo.getIsActive(), userVo.getUpdatedDate(), userVo.getUpdatedBy(), userVo.getEmpNo(), userVo.getRoleId()}); 
        return result;
    }
    
    @Override
    public int updateIsActive(UserVo userVo) throws Exception {        
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateIsActive Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_MT_ROLE_PRIVILEGE SET IS_ACTIVE=1, UPDATED_DT=SYSDATE, UPDATED_BY=? ");
        ///sql.append("UPDATE TBL_MT_ROLE_PRIVILEGE SET IS_ACTIVE=1 ");
        sql.append("\nWHERE IS_ACTIVE IS NULL ");
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateIsActive Finish");
        }
        int result = jdbcTemplate.update(sql.toString(), new Object[]{userVo.getUpdatedBy()});
        ///int result = jdbcTemplate.update(sql.toString(), new Object[]{}); 
        return result;
    }
    
    @Override
    public int updateDeptCodeByEmployeeId(UserVo userVo) throws Exception {        
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateDeptCodeByEmployeeId Start");
        }
        StringBuilder sql = new StringBuilder();        
        sql.append("UPDATE TBL_MT_ROLE_PRIVILEGE SET DEPT_CODE=?, DEPT_NAME=? ");
        sql.append("\nWHERE EMPLOYEE_ID=? ");
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.updateDeptCodeByEmployeeId Finish");
        }
        int result = jdbcTemplate.update(sql.toString(), new Object[]{userVo.getDeptCd(), userVo.getDeptDesc(), userVo.getEmpNo()});        
        return result;
    }
        
    @Override
    public int deleteUserMtRolePrivilege(UserVo userVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.deleteUserMtRolePrivilege Start");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append("\nWHERE EMPLOYEE_ID=?");        
        sql.append("\nAND ROLE_CODE=?");
        sql.append("\nAND DEPT_CODE=?");
        int result = jdbcTemplate.update(sql.toString(), new Object[]{userVo.getEmpNo(), userVo.getRoleId(), userVo.getDeptCd()}); 
        if (logger.isInfoEnabled()) {
            logger.info("RoleAssignmentServiceImpl.deleteUserMtRolePrivilege Finish");
        }
        return result;
    }
    
    @Override
    public UserVo getUserMtRolePrivilegeByFilter(SearchBean searchBean) throws Exception {
        List result = null;
        UserVo userVo = new UserVo();
        if (logger.isInfoEnabled()) {
            logger.info("getUserMtRolePrivilegeByFilter");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append("\nWHERE EMPLOYEE_ID = ?");
        sql.append("\nAND ROLE_CODE = ?");
        //sql.append("\nAND DEPT_CODE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }        
        result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{searchBean.getUser().getEmpNo(), searchBean.getUser().getRoleId()}, new RowMapper() {
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                                                                
                return getResultSetUser(rs);
            }
        });
        if (result != null && !result.isEmpty()) {
            userVo = (UserVo) result.get(0);
        }          
        return userVo;
    }
     
    @Override
    public UserVo getUserMtRolePrivilegeSaveHistory(SearchBean searchBean) throws Exception {
        List result = null;
        UserVo userVo = new UserVo();
        if (logger.isInfoEnabled()) {
            logger.info("getUserMtRolePrivilegeSaveHistory");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append("\nWHERE EMPLOYEE_ID = ?");
        sql.append("\nAND ROLE_CODE = ?");
        //sql.append("\nAND DEPT_CODE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }        
        result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{searchBean.getUser().getEmpNo(), searchBean.getUser().getRoleId()}, new RowMapper() {
            public UserVo mapRow(ResultSet rs, int rowNum) throws SQLException {                                                                
                UserVo vo = new UserVo();             
                vo.setCreatedDate(rs.getDate("CREATED_DT"));    
                vo.setCreatedDateTs(rs.getTimestamp("CREATED_DT"));
                vo.setCreatedBy(rs.getString("CREATED_BY"));                             
                vo.setUpdatedDate(rs.getDate("UPDATED_DT"));
                vo.setUpdatedBy(StringUtil.notNull(rs.getString("UPDATED_BY")));
                vo.setDeptCd(StringUtil.notNull(rs.getString("DEPT_CODE")));
                vo.setDeptName(StringUtil.notNull(rs.getString("DEPT_NAME")));
                return vo;    
            }
        });
        if (result != null && !result.isEmpty()) {
            userVo = (UserVo) result.get(0);
        }          
        return userVo;
    }
    
    public String getRoleDesc(String roleCode) throws SQLException {
        String result = null;                
        if (logger.isInfoEnabled()) {
            //logger.info("RoleAssignmentServiceImpl.getRoleDesc");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ROLE_NAME FROM TBL_MT_ROLE ");
        sql.append("\nWHERE ROLE_CODE = ?");

        if (logger.isDebugEnabled()) {
            //logger.debug("SQL >>> " + sql.toString());
        }        
        ArrayList resultList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{roleCode}, new RowMapper() {
             public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                 return StringUtil.getValue(rs.getString("ROLE_NAME"));
             }
         });
        
         if(!resultList.isEmpty()){
             result = (String)resultList.get(0);
         }          
        return result;
    }
    
    private UserVo getResultSetUser(ResultSet rs)throws SQLException {    
        UserVo vo = new UserVo();
        vo.setEmpNo(StringUtil.notNull(rs.getString("EMPLOYEE_ID")));
        vo.setRoleId(StringUtil.notNull(rs.getString("ROLE_CODE")));         
        vo.setRoleDesc(getRoleDesc(StringUtil.notNull(rs.getString("ROLE_CODE"))));                
        vo.setCreatedDate(rs.getDate("CREATED_DT"));                                
        vo.setCreatedBy(rs.getString("CREATED_BY"));  
        if(!"".equals(StringUtil.notNull(rs.getString("UPDATED_BY")))){
            vo.setCreatedDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("UPDATED_DT")));                                                                                                                            
            vo.setCreatedBy(StringUtil.notNull(rs.getString("UPDATED_BY")));
        }else{
            vo.setCreatedDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("CREATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("CREATED_DT")));                                                                                                                            
            vo.setCreatedBy(StringUtil.notNull(rs.getString("CREATED_BY")));
        }                
        
        vo.setUpdatedDate(rs.getDate("UPDATED_DT"));
        vo.setUpdatedBy(StringUtil.notNull(rs.getString("UPDATED_BY")));
        vo.setEndDate(rs.getDate("END_DATE"));
        vo.setEndDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("END_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("END_DATE")));
        vo.setIsActive(StringUtil.notNull(rs.getString("IS_ACTIVE")));                
        if("0".equals(StringUtil.notNull(rs.getString("IS_ACTIVE")))){
            vo.setIsActiveDesc("Inactive");
        }else if("1".equals(StringUtil.notNull(rs.getString("IS_ACTIVE")))) {
            vo.setIsActiveDesc("Active");
        }                
        try {                                                                
            vo.setEmpFullName(ktbEmpDirectoryService.searchEmpNameById(StringUtil.notNull(rs.getString("EMPLOYEE_ID"))));
        } catch (Exception ex) {
            logger.error("RoleAssignmentServiceImpl.getResultSetUser ex="+ex);
            java.util.logging.Logger.getLogger(RoleAssignmentServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        vo.setDeptCd(StringUtil.notNull(rs.getString("DEPT_CODE")));
        vo.setDeptName(StringUtil.notNull(rs.getString("DEPT_NAME")));
        return vo;    
    }
}
