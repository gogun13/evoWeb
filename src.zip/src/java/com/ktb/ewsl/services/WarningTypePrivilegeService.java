/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningTypePrivilegeVo;
import java.util.ArrayList;

/**
 *
 * @author KTBDevLoan
 */
public interface WarningTypePrivilegeService {
    
    public ArrayList<WarningTypePrivilegeVo> findWarningTypePrivilegeByRole(String roleId)throws Exception;
}
