/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AnswerVo;
import com.ktb.ewsl.vo.QuestionVo;
import com.ktbcs.core.utilities.BusinessConst;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author surapong
 */
@Repository
public class QuestionServiceImpl implements QuestionService{
    private static final Logger log = Logger.getLogger(QuestionServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public List<QuestionVo> findQuestionByFilter(QuestionVo filter) throws Exception{
        if(log.isInfoEnabled()){
            log.info("findQuestionByFilter");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstQuestion.QUEST_ID,asstQuestion.ASST_CODE,asstForm.ASST_NAME,asstQuestion.QUEST_CODE,asstQuestion.QUEST_DESC,asstQuestion.QUEST_UNDER,asstQuestion.QUEST_SEQ,asstQuestion.CHOICE_TYPE,asstQuestion.IS_REQUIRE,asstQuestion.IS_REMARK");
        sql.append("\n,assessmentAnswer.CHOICE_CODE as answer,assessmentAnswer.REMARK FROM TBL_ASSESSMENT_QUESTION asstQuestion");
        sql.append("\nINNER JOIN TBL_ASSESSMENT_FORM asstForm");
        sql.append("\nON asstQuestion.ASST_CODE = asstForm.ASST_CODE");
        sql.append("\nAND asstForm.ASST_LAST_VERSION = asstQuestion.ASST_VERSION");
        sql.append("\nLEFT JOIN TBL_ASSESSMENT_ANSWER assessmentAnswer");
        sql.append("\nON  asstQuestion.QUEST_ID = assessmentAnswer.QUEST_ID AND assessmentAnswer.WARNING_ID = ?");
        sql.append("\nWHERE asstQuestion.ASST_CODE = ? AND asstQuestion.IS_ACTIVE = ?");
        sql.append("\n ORDER BY asstQuestion.QUEST_SEQ");
        
        if(log.isDebugEnabled()){
            log.debug("SQL >>> "+sql.toString());
        }
        List<QuestionVo> questionVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningId(),filter.getAsstCode(),BusinessConst.Flag.ACTIVE}, new BeanPropertyRowMapper<QuestionVo>(QuestionVo.class));
        
        return questionVoList;
    }
    
    @Override
    public List<AnswerVo> findChoiceByQuestion(List<Integer> questIdList) throws Exception{
        if(log.isInfoEnabled()){
            log.info("findChoiceByQuestion");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT QUEST_ID,CHOICE_CODE,CHOICE_DESC FROM TBL_ASSESSMENT_CHOICE");
        sql.append("\nWHERE 0=0");
        if(!questIdList.isEmpty()){
            sql.append("\nAND QUEST_ID IN (");
            for(int i=0; i<questIdList.size(); i++){
                if(i>0){
                    sql.append(",");
                }
                sql.append("?");
            }
            sql.append(")");
        }
        sql.append("\nORDER BY QUEST_ID,CHOICE_SEQ");
        
        if(log.isDebugEnabled()){
            log.debug("SQL >>> "+sql.toString());
        }
        
        Object[] obj = new Object[questIdList.size()];
        int idx = 0;
        for(Integer questId : questIdList){
            obj[idx] = questId;
            idx++;
        }
        
        List<AnswerVo> answerVoList = jdbcTemplate.query(sql.toString(), obj, new BeanPropertyRowMapper<AnswerVo>(AnswerVo.class));
        
        return answerVoList;
    }
    
    @Override
    public void saveQuestion(QuestionVo questionVo) throws Exception{
        if(log.isInfoEnabled()){
            log.info("saveQuestion");
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ASSESSMENT_ANSWER (WARNING_ID,QUEST_ID,CHOICE_CODE,REMARK,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY)");
        sql.append("\nVALUEs(?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{questionVo.getWarningId(), questionVo.getQuestId(), questionVo.getAnswer(), questionVo.getRemark(),
                questionVo.getCreatedDate(), questionVo.getCreatedBy(), questionVo.getUpdatedDate(), questionVo.getUpdatedBy()}
        );
    }
    
    @Override
     public void updateQuestion(QuestionVo questionVo) throws Exception{
        if(log.isInfoEnabled()){
            log.info("updateQuestion");
        }
        
        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_ASSESSMENT_ANSWER SET CHOICE_CODE = ?, REMARK = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ? AND QUEST_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{questionVo.getAnswer(), questionVo.getRemark(),
                questionVo.getUpdatedDate(), questionVo.getUpdatedBy(), questionVo.getWarningId(), questionVo.getQuestId()}
        );
    }
    
    @Override
    public List<QuestionVo> findAssessmentAnswerByWraningIdAndQuestId(int wraningId, int questId) throws Exception{
        if(log.isInfoEnabled()){
            log.info("findAssessmentAnswerByWraningIdAndQuestId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CHOICE_CODE as answer,REMARK");
        sql.append("\nFROM TBL_ASSESSMENT_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUEST_ID = ?");
        
        List<QuestionVo> questionVoList = jdbcTemplate.query(sql.toString(), new Object[]{wraningId,questId}, new BeanPropertyRowMapper<QuestionVo>(QuestionVo.class));
        
        return questionVoList;
    }
}
