/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ActionHistoryVo;
import com.ktb.ewsl.vo.QuestionHistoryVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Tum_Surapong
 */
@Repository
public class ActionHistoryServiceImpl implements ActionHistoryService{
    private static final Logger log = Logger.getLogger(ActionHistoryServiceImpl.class);
     
    @Autowired
    private JdbcTemplate jdbcTemplate;
     
    @Override
    public void saveData(ActionHistoryVo vo) throws Exception{
        if(log.isInfoEnabled()){
            log.info("saveData");
        }
        
        StringBuilder   sql         = new StringBuilder();
        StringBuilder   column      = new StringBuilder("");
        StringBuilder   statment    = new StringBuilder("");
        List<Object>    params      = new ArrayList<Object>();
        
        column.append("WARNING_ID");
        statment.append("?");
        params.add(vo.getWarningId());
        log.info("WARNING_ID :: " + vo.getWarningId());
        
        column.append(", ACTION_DT");
        statment.append(",CURRENT TIMESTAMP");
        
        log.info("ACTION_BY :: " + vo.getActionBy());
        if(vo.getActionBy()!=null && !"".equals(vo.getActionBy())){
            column.append(", ACTION_BY");
            statment.append(", ?");
            params.add(vo.getActionBy());
        }
        
        log.info("ACTION_CODE :: " + vo.getActionCode());
        if(vo.getActionCode()!=null && !"".equals(vo.getActionCode())){
            column.append(", ACTION_CODE");
            statment.append(", ?");
            params.add(vo.getActionCode());
        }
        
        log.info("ACTION_DETAIL :: " + vo.getActionDetail());
        if(vo.getActionDetail()!=null && !"".equals(vo.getActionDetail())){
            column.append(", ACTION_DETAIL");
            statment.append(", ?");
            params.add(vo.getActionDetail());
        }
        
        log.info("STATUS :: " + vo.getStatus());
        if(vo.getStatus()!=null && !"".equals(vo.getStatus())){
            column.append(", STATUS");
            statment.append(", ?");
            params.add(vo.getStatus());
        }
        
        log.info("REMARK :: " + vo.getRemark());
        if(vo.getRemark()!=null && !"".equals(vo.getRemark())){
            column.append(", REMARK");
            statment.append(", ?");
            params.add(vo.getRemark());
        }
        
        log.info("ROLE_CODE :: " + vo.getRoleCode());
        if(vo.getRoleCode()!=null && !"".equals(vo.getRoleCode())){
            column.append(", ROLE_CODE");
            statment.append(", ?");
            params.add(vo.getRoleCode());
        }
        
        log.info("DPD :: " + vo.getDpd());
        if(vo.getDpd()!= null){
            column.append(", DPD");
            statment.append(", ?");
            params.add(vo.getDpd());
        }
        
        sql.append("INSERT INTO TBL_ACTION_HISTORY (").append(column.toString()).append(")");
        sql.append("\nVALUEs(").append(statment.toString()).append(")");
        
        log.info("[saveData] sql :: " + sql.toString());
        
        int rows = jdbcTemplate.update(sql.toString(), params.toArray());
        
        log.info("[saveData] rows :: " + rows);
        
//        sql.append("INSERT INTO TBL_ACTION_HISTORY (WARNING_ID,ACTION_DT,ACTION_BY,ACTION_CODE,ACTION_DETAIL,STATUS,REMARK,ROLE_CODE)");
//        sql.append("\nVALUEs(?,CURRENT TIMESTAMP,?,?,?,?,?,?)");
//
//        jdbcTemplate.update(sql.toString(), new Object[]{vo.getWarningId(), vo.getActionBy(), vo.getActionCode(),
//                vo.getActionDetail(),vo.getStatus(),vo.getRemark(),vo.getRoleCode()}
//        );
    }
    
    @Override
    public List<ActionHistoryVo> findDataByWarningIdAndStatus(int warningId, String status) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataByWarningIdAndStatus");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ACTION_BY FROM TBL_ACTION_HISTORY");
        sql.append("\nWHERE WARNING_ID = ? AND STATUS = ?");
        sql.append("\nORDER BY ACTION_DT DESC");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        List<ActionHistoryVo> actionHistoryVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, status}, new BeanPropertyRowMapper<ActionHistoryVo>(ActionHistoryVo.class));
        return actionHistoryVoList;
    }
    
    @Override
    public List<ActionHistoryVo> findRemarkByWarningId(int warningId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findRemarkByWarningId >> "+warningId);
        }
        StringBuilder sql = new StringBuilder();
        // pumin: chage query >> get close form reason  
        sql.append("SELECT ACTION_DT,ACTION_BY,REMARK ,ACTION_CODE,'' AS REASONCODE,STATUS ,'' AS REASONDETAIL FROM TBL_ACTION_HISTORY \n");
        sql.append("WHERE WARNING_ID = ? AND REMARK IS NOT NULL AND STATUS != 'RX' \n");
        sql.append("UNION ALL \n");
        sql.append("SELECT ACTION_DT,ACTION_BY,REMARK,'',REASON_CODE AS REASONCODE,STATUS ,REASON_DESC AS REASONDETAIL FROM TBL_ACTION_CLOSE \n");
        sql.append("WHERE WARNING_ID = ? ");
        
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        List<ActionHistoryVo> actionHistoryVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId,warningId}, new BeanPropertyRowMapper<ActionHistoryVo>(ActionHistoryVo.class));
        return actionHistoryVoList;
    }
    
    @Override
    public List<ActionHistoryVo> findDataByWarningId(int warningId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataByWarningId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ACTION_BY FROM TBL_ACTION_HISTORY");
        sql.append("\nWHERE WARNING_ID = ?");
        sql.append("\nORDER BY ACTION_DT DESC");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        List<ActionHistoryVo> actionHistoryVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new BeanPropertyRowMapper<ActionHistoryVo>(ActionHistoryVo.class));
        return actionHistoryVoList;
    }

    @Override
    public List<QuestionHistoryVo> findQuestionHistory(QuestionHistoryVo vo) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findQuestionHistory");
        }
      
        StringBuilder sql = new StringBuilder();
        sql.append("select  a.approve_user_id , a.approve_date,b.action_user_id,b.action_date ,a.warning_id from \n");
        sql.append("( \n");
        sql.append("  select warning_id ,action_by as approve_user_id ,to_char(action_dt + 543 years ,'DD/MM/YYYY HH24:MI:SS') as approve_date from tbl_action_history where action_dt = (\n");
        sql.append("  select max(action_dt)\n");
        sql.append("  from tbl_action_history where warning_id in(").append(vo.getWarningId()).append(" ) and action_code = 'Approve' and action_detail=? )\n");
        sql.append(" and warning_id = (").append(vo.getWarningId()).append(") and action_code = 'Approve' and action_detail=?\n");
        sql.append(") a\n");
        sql.append("join \n");
        sql.append("(\n");
        sql.append(" select warning_id ,action_by as action_user_id ,to_char(action_dt + 543 years ,'DD/MM/YYYY HH24:MI:SS') as action_date from tbl_action_history where action_dt = ( \n");
        sql.append(" select max(action_dt) \n");
        sql.append(" from tbl_action_history where warning_id in(").append(vo.getWarningId()).append(") and action_code = 'Save' and action_detail=? ) \n");
        sql.append(" and warning_id in (").append(vo.getWarningId()).append(") and action_code = 'Save' and action_detail=? \n");
        sql.append(") b \n");
        sql.append("on a.warning_id = b.warning_id  \n");
        if(BusinessConst.WarningTypeCode.FIN.equals(vo.getWarningType())){
            sql.append("   join \n");
            sql.append("( \n");
            sql.append(" select warning_id from  TBL_QCA_FIN where cif= ").append(vo.getCif()).append("\n");
            sql.append(")c \n");
            sql.append("on c.warning_id = b.warning_id \n");
        }
        sql.append("order by b.action_date desc ");
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }
        System.out.println("vo.getActionDetail()>>>>>"+vo.getActionDetail());
        List<QuestionHistoryVo> questionHistoryList = jdbcTemplate.query(sql.toString(), new Object[]{vo.getActionDetail(),vo.getActionDetail(),vo.getActionDetail(),vo.getActionDetail()}, new BeanPropertyRowMapper<QuestionHistoryVo>(QuestionHistoryVo.class));
        
        if(questionHistoryList != null &&!questionHistoryList.isEmpty()){
            System.out.println(">>>>>>"+((QuestionHistoryVo)questionHistoryList.get(0)).getApproveUserId());
        }
        
        return questionHistoryList;
    }

    @Override
    public QuestionHistoryVo findQuestionVersion(String warningId) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findQuestionVersion");
        }
        List result = null;
        QuestionHistoryVo vo = new QuestionHistoryVo();
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT QUESTION_ID,VERSION FROM TBL_ASST_ANSWER WHERE WARNING_ID=? AND UPDATED_DT =\n");
        sql.append("( SELECT MAX(UPDATED_DT) FROM TBL_ASST_ANSWER WHERE WARNING_ID=? )");

        System.out.println("warning_id >>>>"+warningId);
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningId, warningId}, new RowMapper() {
            public QuestionHistoryVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                QuestionHistoryVo vo = new QuestionHistoryVo();
                vo.setQuestionId((String) rs.getString("QUESTION_ID"));
                vo.setVersion((String) rs.getString("VERSION"));
                return vo;
            }
        });
        if (result != null && !result.isEmpty()) {
            vo = (QuestionHistoryVo) result.get(0);
        }  
        return vo;
    }

    @Override
    public boolean haveProtestFIN() throws Exception {
        boolean resultBoolean = false;
        try{
            StringBuilder sql = new StringBuilder();
            sql.append(" SELECT WARNING_ID FROM  TBL_ACTION_HISTORY ");
            sql.append(" WHERE STATUS = ? AND ACTION_DETAIL = ? ");
        
            List result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{"PRMP", "FIN"}, new RowMapper() {
            public ActionHistoryVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                ActionHistoryVo vo = new ActionHistoryVo();
                vo.setWarningId(rs.getInt("WARNING_ID"));
                return vo;
            }
        });
        if (result != null && result.size() > 0) {
            resultBoolean = true;
        }  
        
        }catch(Exception e){
           throw  e;
        }
        return resultBoolean;
    }
    
    @Override
    public void deleteActionHistoryByWarningId(String warningIdAll) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("deleteActionHistoryByWarningId");
        }
        if(!ValidatorUtil.isNullOrEmpty(warningIdAll)){
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM TBL_ACTION_HISTORY  WHERE WARNING_ID IN  (").append(warningIdAll).append(" ) ");
            jdbcTemplate.update(sql.toString());
        }
    }

    @Override
    public void deleteActionHistoryByWarningIdAndRoleCode(String warningIdAll, String roleCode) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("deleteActionHistoryByWarningIdAndRoleCode");
        }
        if(!ValidatorUtil.isNullOrEmpty(warningIdAll) && !ValidatorUtil.isNullOrEmpty(roleCode)){
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM TBL_ACTION_HISTORY  WHERE WARNING_ID IN  (").append(warningIdAll).append(" ) AND ROLE_CODE IN ( ").append(roleCode).append(" )");
            jdbcTemplate.update(sql.toString());
        }
    }

    @Override
    public List<ActionHistoryVo> findDataByWarningIdAndStatusAndRoleCode(int warningId, String status, String roleCode) throws Exception {
          if (log.isInfoEnabled()) {
            log.info("findDataByWarningIdAndStatus");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ACTION_BY FROM TBL_ACTION_HISTORY");
        sql.append("\nWHERE WARNING_ID = ? AND STATUS = ? AND ROLE_CODE IN ( ").append(roleCode).append(" )");
        sql.append("\nORDER BY ACTION_DT DESC");

        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        List<ActionHistoryVo> actionHistoryVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, status}, new BeanPropertyRowMapper<ActionHistoryVo>(ActionHistoryVo.class));
        return actionHistoryVoList;
    }

    @Override
    public void deleteActionHistoryByWarningIdAndStatusAndRoleCode(int warningId, String status, String roleCode) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("deleteActionHistoryByWarningIdAndStatusAndRoleCode");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_ACTION_HISTORY  WHERE WARNING_ID = ").append(warningId).append(" AND STATUS  = '").append(status).append("' AND ROLE_CODE IN ( ").append(roleCode).append(" )");
        jdbcTemplate.update(sql.toString());
    }
    
    @Override
    public ActionHistoryVo actionHistoryDetail(int warningId, String actionCode, String actionDetail, String status) throws Exception {
        log.info("[actionHistoryDetail][Begin]");
        
        StringBuilder   sql             = new StringBuilder();
        List<Object>    params          = new ArrayList<Object>();
        ActionHistoryVo actionHistoryVo = null;
        
        try{
            sql.append("select warning_id");
            sql.append("      ,VARCHAR_FORMAT(action_dt, 'dd/MM/yyyy') action_dt");
            sql.append("      ,action_by");
            sql.append("      ,action_code");
            sql.append("      ,action_detail");
            sql.append("      ,status");
            sql.append("      ,remark");
            sql.append("      ,role_code");
            sql.append(" from TBL_ACTION_HISTORY");
            sql.append(" where warning_id     = ?");
            sql.append("  and action_code     = ?");
            sql.append("  and action_detail   = ?");
            sql.append("  and status          = ?");
            
            log.info("[actionHistoryDetail] warningId       :: " + warningId);
            log.info("[actionHistoryDetail] actionCode      :: " + actionCode);
            log.info("[actionHistoryDetail] actionDetail    :: " + actionDetail);
            log.info("[actionHistoryDetail] status          :: " + status);
            
            params.add(warningId);
            params.add(actionCode);
            params.add(actionDetail);
            params.add(status);
            
            log.info("[actionHistoryDetail] SQL :: " + sql.toString());
            List<ActionHistoryVo> actionHistoryVoList = jdbcTemplate.query(sql.toString(), params.toArray(), new RowMapper(){
                    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                        ActionHistoryVo item    = new ActionHistoryVo();
                        DateFormat      df      = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
                        
                        try{
                            item.setWarningId(rs.getInt("warning_id"));
                            item.setActionDt(df.parse(rs.getString("action_dt")));
                            item.setActionBy(rs.getString("action_by"));
                            item.setActionCode(rs.getString("action_code"));
                            item.setActionDetail(rs.getString("action_detail"));
                            item.setStatus(rs.getString("status"));
                            item.setRemark(rs.getString("remark"));
                            item.setRoleCode(rs.getString("role_code"));
                        }catch(Exception e){
                            log.error(e);
                        }
                        
                        return item;
                    }
            });
            
            if(actionHistoryVoList!=null && !actionHistoryVoList.isEmpty()){
                actionHistoryVo = actionHistoryVoList.get(0);
            }
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[actionHistoryDetail][End]");
        }
        
        return actionHistoryVo;
    }

    @Override
    public void updateData(ActionHistoryVo vo) throws Exception {
        try{
         if(log.isInfoEnabled()){
            log.info("updateData");
            log.info("vo.getActionDetail() >>" + vo.getActionDetail());
            log.info("vo.getActionCode() >>" + vo.getActionCode());
            log.info("vo.getActionBy() >>" + vo.getActionBy());
            log.info("vo.getStatus() >>" + vo.getStatus());
            log.info("vo.getRoleCode() >>" + vo.getRoleCode());
            log.info("vo.getRemark() >>" + vo.getRemark());
            log.info("vo.getWarningId() >>" + vo.getWarningId());
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" UPDATE TBL_ACTION_HISTORY SET ACTION_DETAIL = ?  , ACTION_BY = ? ,   ");
        sql.append("\n ROLE_CODE = ? ,  ACTION_DT = ? , REMARK = ?  ");
        sql.append("\n WHERE WARNING_ID = ?  AND ACTION_CODE = ? AND STATUS = ?  ");
      
        jdbcTemplate.update(sql.toString(), new Object[]{ vo.getActionDetail(), vo.getActionBy(), 
               vo.getRoleCode(),vo.getActionDt() , vo.getRemark(),vo.getWarningId(),vo.getActionCode(),vo.getStatus()}
        );
        }catch(Exception e){
          e.printStackTrace();
        }
    }

    @Override
    public Integer checkActionHistoryBy(int warningId, String actionCode, String status) throws Exception {
         if (log.isInfoEnabled()) {
            log.info("checkActionHistoryBy");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT COUNT(*)  FROM TBL_ACTION_HISTORY  ");
        sql.append("\n WHERE  WARNING_ID = ?  AND ACTION_CODE = ? AND  STATUS = ?   ");

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{ warningId , actionCode, status}, Integer.class);
        
    }

    @Override
    public ActionHistoryVo findActionHistory(int warningId, String actionCode, String status) throws Exception {
        ActionHistoryVo result = null;
        try{
            StringBuilder sql = new StringBuilder();
            sql.append("  SELECT ACTION_BY , ACTION_CODE, ACTION_DETAIL,ACTION_DT, REMARK , ");
            sql.append("\n  ROLE_CODE, STATUS , WARNING_ID  FROM TBL_ACTION_HISTORY ");
            sql.append("\n  WHERE  WARNING_ID = ?  AND ACTION_CODE = ? AND  STATUS = ? ");
        
            List resultList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningId, actionCode , status}, new RowMapper() {
            public ActionHistoryVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                ActionHistoryVo vo = new ActionHistoryVo();
                vo.setWarningId(rs.getInt("WARNING_ID"));
                vo.setActionCode(rs.getString("ACTION_CODE"));
                vo.setActionDetail(rs.getString("ACTION_DETAIL"));
                vo.setActionDt(rs.getDate("ACTION_DT"));
                vo.setRemark(rs.getString("REMARK"));
                vo.setRoleCode(rs.getString("ROLE_CODE"));
                vo.setStatus(rs.getString("STATUS"));
                vo.setActionBy(rs.getString("ACTION_BY"));
                return vo;
            }
        });
        if (resultList != null && resultList.size() > 0) {
             result = (ActionHistoryVo)resultList.get(0);
        }  
        
        }catch(Exception e){
           throw  e;
        }
        return result;
    }
    
    @Override
    public ActionHistoryVo findData(int warningId, String actionDetail) throws Exception {
        log.info("[findData][Begin]");
        
        StringBuilder   sql             = new StringBuilder();
        ActionHistoryVo actionHistoryVo = null;
        
        try{
            sql.append("select t.* ");
            sql.append(" from TBL_ACTION_HISTORY t ");
            sql.append(" where t.action_dt      = (select max(a.action_dt) ");
            sql.append("                            from TBL_ACTION_HISTORY a");
            sql.append("                            where a.warning_id      = t.warning_id");
            sql.append("                                and a.action_detail = t.action_detail)");
            sql.append("    and t.warning_id    = ?");
            sql.append("    and t.action_detail = ?");
            
            log.debug("[findData] SQL :: " + sql.toString());
            
            List<ActionHistoryVo> actionHistoryVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, actionDetail}, new BeanPropertyRowMapper<ActionHistoryVo>(ActionHistoryVo.class));
            
            if(actionHistoryVoList!=null && !actionHistoryVoList.isEmpty()){
                actionHistoryVo = actionHistoryVoList.get(0);
            }
            
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[findData][End]");
        }
        return actionHistoryVo;
    }
     
    @Override
    public void updateRemarkForDraftReject(ActionHistoryVo vo) throws Exception{
        if(log.isInfoEnabled()){
            log.info("updateRemarkForDraftReject");
        }
        
        StringBuilder   sql         = new StringBuilder();
        
        sql.append("UPDATE TBL_ACTION_HISTORY t");
        sql.append(" SET");
        sql.append("    t.REMARK = ?, t.ACTION_DT = CURRENT TIMESTAMP");
        sql.append(" where t.action_dt = (select max(a.action_dt) ");
        sql.append("                        from TBL_ACTION_HISTORY a");
        sql.append("                        where a.warning_id      = t.warning_id");
        sql.append("                            and a.action_detail = t.action_detail)");
        sql.append("    and t.warning_id    = ?");
        sql.append("    and t.action_detail = ?");
        
        log.info("[updateRemarkForDraftReject] sql :: " + sql.toString());
        
        int row = jdbcTemplate.update(sql.toString(), vo.getRemark(), vo.getWarningId(), vo.getActionDetail());
        
        log.info("[updateRemarkForDraftReject] row :: " + row);
        
    }
      
}
