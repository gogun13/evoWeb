/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.MtFormStatusVo;
import java.util.ArrayList;

/**
 *
 * @author pumin
 */
public interface MtFormStatusService {
    public ArrayList<MtFormStatusVo> getFormConfigDetail () throws Exception;
    public ArrayList<MtFormStatusVo> getStatusNameAndSeq() throws Exception;
}
