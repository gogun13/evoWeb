/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.CustomerVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.StringUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class CustomerServiceImpl implements CustomerService{
    
    private static final Logger log = Logger.getLogger(AbstractJdbcService.class);
     
    @Autowired
    public JdbcTemplate jdbcTemplate;
        
    
    @Override
    public CustomerVo selectCustomerByCif(Integer cif) throws Exception {
        CustomerVo result = null;
        List<CustomerVo> custVoList = selectCustomer(cif);
        if(!custVoList.isEmpty()){
            result = custVoList.get(0);
        }
         log.debug("custVoList.size() >> "+ custVoList != null ? custVoList.size() : 0);
        return result;
    }
     
     
     private List<CustomerVo> selectCustomer(Integer cif) throws Exception {
      List<CustomerVo> result = null;
      try{
        if(log.isInfoEnabled()){
              log.info("CustomerServiceImpl.selectCustomer");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT CIF, CUST_NAME, BUSINESS_SIZE ,  ");
        sql.append(" CITIZEN_ID, TAX_ID, JURISTIC_ID, ISIC_CODE, AO_ID, AE_ID, RM_ID, RESPONSE_UNIT, ");
        sql.append(" CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY  ");
        sql.append(" FROM TBL_CUSTOMER ");
        sql.append("  WHERE CIF = ? ");

       //  result = jdbcTemplate.query(sql.toString(), new Object[]{cif}, new BeanPropertyRowMapper<CustomerVo>(CustomerVo.class));
        result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{cif}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CustomerVo item = new CustomerVo();
                    item.setCif(rs.getInt("CIF"));
                    item.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                    item.setBusinessSize(StringUtil.getValue(rs.getString("BUSINESS_SIZE")));
                    item.setCitizenId(StringUtil.getValue(rs.getString("CITIZEN_ID")));
                    item.setTaxId(StringUtil.getValue(rs.getString("TAX_ID")));
                    item.setJuristicId(StringUtil.getValue(rs.getString("JURISTIC_ID")));
                    item.setIsicCode(StringUtil.getValue(rs.getString("ISIC_CODE")));
                    item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                    item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                    item.setRmId(StringUtil.getValue(rs.getString("RM_ID"))); 
                    item.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                    item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                    item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                    return item;
                }
            });
        
      }catch(Exception e){
          log.error("Error occur in while process CustomerServiceImpl.selectCustomer : " + e.getMessage() , e);
          throw e;
      }
      return result;
     }

    @Override
    public CustomerVo selectCustomerByCifWithCostCenterName(Integer cif) throws Exception {
       CustomerVo result = null;
       List<CustomerVo> custVoList = null;
      try{
        if(log.isInfoEnabled()){
              log.info("CustomerServiceImpl.selectCustomer");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("   SELECT C.CIF AS CIF , C.CUST_NAME AS CUST_NAME , BUSINESS_SIZE AS BUSINESS_SIZE,    ");
        sql.append("        C.CITIZEN_ID AS CITIZEN_ID , C.TAX_ID AS TAX_ID, C.JURISTIC_ID AS JURISTIC_ID,  ");
        sql.append("        C.ISIC_CODE AS ISIC_CODE , C.AO_ID AS AO_ID , C.AE_ID AS AE_ID,  ");
        sql.append("        C.RM_ID AS RM_ID, C.RESPONSE_UNIT AS RESPONSE_UNIT,  ");
        sql.append("        C.CREATED_DT AS CREATED_DT , C.CREATED_BY AS CREATED_BY , C.UPDATED_DT AS UPDATED_DT , C.UPDATED_BY AS UPDATED_BY,  ");
        sql.append("        O.COSTCENTER_NAME AS COSTCENTER_NAME  ");
        sql.append("       FROM TBL_CUSTOMER C LEFT JOIN TBL_MT_KTB_ORGANIZATION O  ");
        sql.append("       ON C.RESPONSE_UNIT = O.COSTCENTER_CODE ");
        sql.append("   WHERE CIF = ? ");
         
        custVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{cif}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CustomerVo item = new CustomerVo();
                    item.setCif(rs.getInt("CIF"));
                    item.setCustName(StringUtil.getValue(rs.getString("CUST_NAME")));
                    item.setBusinessSize(StringUtil.getValue(rs.getString("BUSINESS_SIZE")));
                    item.setCitizenId(StringUtil.getValue(rs.getString("CITIZEN_ID")));
                    item.setTaxId(StringUtil.getValue(rs.getString("TAX_ID")));
                    item.setJuristicId(StringUtil.getValue(rs.getString("JURISTIC_ID")));
                    item.setIsicCode(StringUtil.getValue(rs.getString("ISIC_CODE")));
                    item.setAoId(StringUtil.getValue(rs.getString("AO_ID")));
                    item.setAeId(StringUtil.getValue(rs.getString("AE_ID")));
                    item.setRmId(StringUtil.getValue(rs.getString("RM_ID"))); 
                    item.setResponseUnit(StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                    item.setResponseUnitName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    item.setCreatedBy(StringUtil.getValue(rs.getString("CREATED_BY")));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setUpdatedBy(StringUtil.getValue(rs.getString("UPDATED_BY")));
                    item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                    return item;
                }
            });
        
        if(!custVoList.isEmpty()){
            result = custVoList.get(0);
        }
      }catch(Exception e){
          log.error("Error occur in while process CustomerServiceImpl.selectCustomerByCifWithCostCenterName : " + e.getMessage() , e);
          throw e;
      }
      return result;
    }

    
    @Override
    public CustomerVo customerInfo(CustomerVo vo) throws Exception {
       CustomerVo       result      = null;
       List<CustomerVo> custVoList  = null;
       String           condition   = "";
       
      try{
        if(log.isInfoEnabled()){
              log.info("[customerInfo][Begin]");
              log.info("[customerInfo] Cif      :: " + vo.getCif());
              log.info("[customerInfo] CustName :: " + vo.getCustName());
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT C.CIF, C.CUST_NAME, C.RESPONSE_UNIT, ORG.COSTCENTER_NAME");
        sql.append("       , C.RM_ID AS RM_ID ");
        sql.append("       , RM.EMP_NO AS RM_EMP_NO, RM.TITLE_NAME AS RM_TITLE_NAME, RM.EMP_NAME AS RM_EMP_NAME, RM.EMP_SURNAME AS RM_EMP_SURNAME");
        sql.append("       , AE.EMP_NO AS AE_EMP_NO, AE.TITLE_NAME AS AE_TITLE_NAME, AE.EMP_NAME AS AE_EMP_NAME, AE.EMP_SURNAME AS AE_EMP_SURNAME");
        sql.append("    FROM TBL_CUSTOMER C");
        sql.append("        LEFT JOIN TBL_EMPLOYEE RM ON C.RM_ID = RM.EMP_NO");
        sql.append("        LEFT JOIN TBL_EMPLOYEE AE ON C.AE_ID = AE.EMP_NO");
        sql.append("        LEFT JOIN TBL_MT_KTB_ORGANIZATION ORG ON C.RESPONSE_UNIT = ORG.COSTCENTER_CODE");
        sql.append("    WHERE 1 = 1 ");
        
        if(vo.getCif()!=null){
            condition += " and C.CIF = '" + vo.getCif() + "'";
        }
        
        if(vo.getCustName()!=null){
            condition += " and C.CUST_NAME = '" + vo.getCustName() + "'";
        }
        
        sql.append(condition);
         
        custVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    CustomerVo item = new CustomerVo();
                    item.setCif             (rs.getInt("CIF"));
                    item.setCustName        (StringUtil.getValue(rs.getString("CUST_NAME")));
                    item.setResponseUnit    (StringUtil.getValue(rs.getString("RESPONSE_UNIT")));
                    item.setResponseUnitName(StringUtil.getValue(rs.getString("COSTCENTER_NAME")));
                    item.setRmId            (StringUtil.getValue(rs.getString("RM_ID")));
                    item.setRmEmpNo         (StringUtil.getValue(rs.getString("RM_EMP_NO")));
                    item.setRmTitleName     (StringUtil.getValue(rs.getString("RM_TITLE_NAME")));
                    item.setRmEmpName       (StringUtil.getValue(rs.getString("RM_EMP_NAME")));
                    item.setRmEmpSurName    (StringUtil.getValue(rs.getString("RM_EMP_SURNAME")));
                    
                    item.setAeEmpNo         (StringUtil.getValue(rs.getString("AE_EMP_NO")));
                    item.setAeTitleName     (StringUtil.getValue(rs.getString("AE_TITLE_NAME")));
                    item.setAeEmpName       (StringUtil.getValue(rs.getString("AE_EMP_NAME")));
                    item.setAeEmpSurName    (StringUtil.getValue(rs.getString("AE_EMP_SURNAME")));
                    
                    return item;
                }
            });
        
        if(custVoList!=null && !custVoList.isEmpty()){
            result = custVoList.get(0);
        }
      }catch(Exception e){
          log.error("Error occur in while process CustomerServiceImpl.customerInfo : " + e.getMessage() , e);
          throw e;
      }
      return result;
    }

   
}
