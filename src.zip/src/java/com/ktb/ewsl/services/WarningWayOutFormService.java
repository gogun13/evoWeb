/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningWayOutFormVo;
import java.util.ArrayList;

/**
 *
 * @author Pratya
 */
public interface WarningWayOutFormService {
    public ArrayList<WarningWayOutFormVo> getDataListByWarningId (int warningId) throws Exception;
//    public void updateConfirmAnswer(WarningWayOutFormVo vo) throws Exception;
    public void deleteWarningActionForm(int warningId, String roleCode) throws Exception;
    public void insertWarningActionForm(WarningWayOutFormVo vo) throws Exception;
    public void deleteByWarningId(int warningId) throws Exception;
}
