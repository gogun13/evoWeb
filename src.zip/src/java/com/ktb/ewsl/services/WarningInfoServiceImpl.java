/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.WarningInfoVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import com.ktbcs.core.vo.SearchBean;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class WarningInfoServiceImpl implements WarningInfoService {

    private static Logger logger = Logger.getLogger(WarningInfoServiceImpl.class);
    @Autowired
    public JdbcTemplate jdbcTemplate;
    /* TBL_WARNING_INFO */
    private final static String TABLE_TBL_WARNING_HEADER = "TBL_WARNING_INFO A";
    private final static String A_WARNING_ID = "WARNING_ID";
    private final static String A_WARNING_HEAD_ID = "WARNING_HEAD_ID";
    private final static String A_WARNING_TYPE = "WARNING_TYPE";
    private final static String A_STATUS = "STATUS";
    private final static String A_RISK_LEVEL = "RISK_LEVEL";
    private final static String A_APPROVE = "APPROVE";
    private final static String A_CREATED_DT = "CREATED_DT";
    private final static String A_CREATED_BY = "CREATED_BY";
    private final static String A_UPDATED_DT = "UPDATED_DT";
    private final static String A_UPDATED_BY = "UPDATED_BY";
    private final static String A_WARNING_DATE = "WARNING_DATE";
    private final static String A_SLA = "SLA";
    private final static String A_SLA_DUE_DATE = "SLA_DUE_DATE";
    private final static String A_TRIG_GEN_FLAG = "TRIG_GEN_FLAG";
    private final static String A_TRIG_SHOW_FLAG = "TRIG_SHOW_FLAG";
    private final static String A_QUALI_SEND_FLG = "QUALI_SEND_FLG";
    private final static String A_HOLDER_ID = "HOLDER_ID";
    private final static String A_HOLDER_ROLE = "HOLDER_ROLE";
    private final static String A_CLOSE_FLG = "CLOSE_FLG";
    

    @Override
    public List<WarningInfoVo> getTaskDetailList(SearchBean searchBean) throws Exception {
        List<WarningInfoVo> result = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("WarningInfoServiceImpl.getTaskDetailList");
            }
            StringBuilder sql = new StringBuilder();

            sql.append("  SELECT xy.WARNING_ID AS WARNING_ID , xy.WARNING_HEAD_ID AS WARNING_HEAD_ID, xy.WARNING_TYPE AS WARNING_TYPE,  \n");
            sql.append("       xy.STATUS AS STATUS, xy.RISK_LEVEL AS RISK_LEVEL, \n");
            sql.append("       xy.CREATED_DT AS CREATED_DT, xy.CREATED_BY AS CREATED_BY, xy.UPDATED_DT AS UPDATED_DT, \n");
            sql.append("       xy.WARNING_DATE AS WARNING_DATE , xy.UPDATED_BY AS UPDATED_BY  , \n");
            sql.append("       xy.WARNING_TYPE_CODE AS WARNING_TYPE_CODE , xy.WARNING_TYPE_DESC AS WARNING_TYPE_DESC , \n");
            sql.append("       xy.QUESTION_ID AS QUESTION_ID ,xy.QUESTION_VERSION AS QUESTION_VERSION ,  xy.SLA AS SLA ,  xy.SLA_DUE_DATE AS SLA_DUE_DATE , \n");
            sql.append("       xz.ACTION_DT AS ACTION_DT , xz.ACTION_BY AS ACTION_BY , \n");
            sql.append("       xy.TRIG_GEN_FLAG AS TRIG_GEN_FLAG , xy.TRIG_SHOW_FLAG  AS TRIG_SHOW_FLAG , xy.QUALI_SEND_FLAG AS QUALI_SEND_FLAG , \n");
            sql.append("       xy.CLOSE_FLAG AS CLOSE_FLAG, \n");
            sql.append("        CASE  \n");
            sql.append("            WHEN xy.STATUS = 'C' THEN 1   \n");
            sql.append("            ELSE 0   \n");
            sql.append("         END as SORTFLAG   \n");
            sql.append("       , xy.HOLDER_ID AS HOLDER_ID , xy.HOLDER_ROLE AS HOLDER_ROLE \n");
            sql.append("       , xy.INFO_QUESTION_ID , xy.INFO_QUESTION_VERSION \n");
            sql.append(" FROM \n");
            sql.append("        (SELECT B.WARNING_ID AS WARNING_ID , B.WARNING_HEAD_ID AS WARNING_HEAD_ID, B.WARNING_TYPE AS WARNING_TYPE, \n");
            sql.append("            B.STATUS AS STATUS, B.RISK_LEVEL AS RISK_LEVEL, \n");
            sql.append("            B.CREATED_DT AS CREATED_DT, B.CREATED_BY AS CREATED_BY, B.UPDATED_DT AS UPDATED_DT, \n");
            sql.append("            B.WARNING_DATE AS WARNING_DATE , B.UPDATED_BY AS UPDATED_BY  , \n");
            sql.append("            C.WARNING_TYPE_CODE AS WARNING_TYPE_CODE , C.WARNING_TYPE_DESC AS WARNING_TYPE_DESC , \n");
            sql.append("            C.QUESTION_ID AS QUESTION_ID , C.QUESTION_VERSION AS QUESTION_VERSION ,  B.SLA AS SLA ,  B.SLA_DUE_DATE AS SLA_DUE_DATE , \n");
            sql.append("            B.QUESTION_ID AS INFO_QUESTION_ID , B.QUESTION_VERSION AS INFO_QUESTION_VERSION ,   \n"); //-----------24/06/2015 : Have QuestionId and version in INFO
            sql.append("            B.TRIG_GEN_FLAG AS TRIG_GEN_FLAG, B.TRIG_SHOW_FLAG  AS TRIG_SHOW_FLAG , B.QUALI_SEND_FLAG AS QUALI_SEND_FLAG \n");
            sql.append("        ,B.HOLDER_ID , B.HOLDER_ROLE  , B.CLOSE_FLAG \n");
            sql.append("        FROM TBL_WARNING_INFO B, TBL_WARNING_TYPE C  \n");
            sql.append("        WHERE 1=1 \n");
            sql.append("        AND B.WARNING_HEAD_ID  = ? \n");
            sql.append("        AND B.WARNING_TYPE = C.WARNING_TYPE_CODE \n");
            sql.append("        AND C.IS_ACTIVE = 1 \n");
            sql.append("        ORDER BY B.SLA ASC )xy \n");
            sql.append(" LEFT JOIN \n");
            sql.append("        (SELECT WIF.WARNING_ID , WIF.WARNING_TYPE ,YZ.ACTION_DT,YZ.ACTION_BY FROM \n");
            sql.append("            (SELECT WARNING_ID , WARNING_TYPE  FROM TBL_WARNING_INFO WHERE STATUS = 'C' AND WARNING_HEAD_ID = ?  ) WIF \n");
            sql.append("             LEFT JOIN \n");
            sql.append("            (SELECT AAA.WARNING_ID, AAA.ACTION_DT, AH.ACTION_BY , AAA.ACTION_DETAIL  FROM  \n");
            sql.append("            ( SELECT WARNING_ID, MAX(ACTION_DT) AS ACTION_DT, ACTION_DETAIL  FROM \n");
            sql.append("            TBL_ACTION_HISTORY \n");
            sql.append("            WHERE 1=1 \n");
            sql.append("            AND ACTION_CODE = 'Save' \n");
            sql.append("            GROUP BY WARNING_ID,ACTION_DETAIL \n");
            sql.append("            ) AAA  \n");
            sql.append("            LEFT JOIN TBL_ACTION_HISTORY AH  \n");
            sql.append("            ON AAA.ACTION_DT = AH.ACTION_DT AND AAA.WARNING_ID = AH.WARNING_ID )YZ \n");
            sql.append("            ON WIF.WARNING_ID = YZ.WARNING_ID  AND WIF.WARNING_TYPE = YZ.ACTION_DETAIL ) xz \n");
            sql.append(" ON xy.WARNING_ID = xz.WARNING_ID \n");
            sql.append(" ORDER BY SORTFLAG , SLA , WARNING_TYPE_CODE  ASC \n");
            result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{searchBean.getWarningHeaderId(), searchBean.getWarningHeaderId()}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningInfoVo item = new WarningInfoVo();
                    item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                    item.setWarningId(rs.getInt(A_WARNING_ID));
                    item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                    item.setWarningDate(rs.getDate(A_WARNING_DATE));
                    item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                    item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                    item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                    item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                    item.setCreatedDate(rs.getDate(A_CREATED_DT));
                    item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                    item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                    item.setSla(rs.getInt(A_SLA));
                    item.setApproveBy(StringUtil.getValue(rs.getString("ACTION_BY")));
                    item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
                    item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                    item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                    item.setHolderId(StringUtil.getValue(rs.getString(A_HOLDER_ID)));
                    item.setHolderRole(StringUtil.getValue(rs.getString(A_HOLDER_ROLE)));
                    item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                    item.setAnswerQuestionId(StringUtil.getValue(rs.getString("INFO_QUESTION_ID")));
                    item.setAnswerQuestionVersion(StringUtil.getValue(rs.getString("INFO_QUESTION_VERSION")));
                    try {
                        item.setApproveDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("ACTION_DT")) ? "" : DateUtil.getDateTimeInThaiFormat(rs.getTimestamp("ACTION_DT"), DateUtil.DEFAULT_DATETIME_FORMAT2));
                         if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                            item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                         }else{
                            item.setSlaStr("");
                         }
                        item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                        item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                    } catch (Exception e) {
                    }

                    WarningTypeVo wtVo = new WarningTypeVo();
                    wtVo.setWarningTypeCode(StringUtil.getValue(rs.getString("WARNING_TYPE_CODE")));
                    wtVo.setWarningTypeDesc(StringUtil.getValue(rs.getString("WARNING_TYPE_DESC")));
                    wtVo.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                    wtVo.setQuestionVersion(StringUtil.getValue(rs.getString("QUESTION_VERSION")));
                    item.setWarningTypeVo(wtVo);

                    return item;
                }
            });
        } catch (Exception e) {
            logger.error("Error occur in while process WarningInfoServiceImpl.getTaskDetailList: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public void updateStatusByWarningIdAndType(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByWarningIdAndType");
            logger.info("getStatus =" + warningInfoVo.getStatus());
            logger.info("getWarningId =" + warningInfoVo.getWarningId());
            logger.info("getWarningType =" + warningInfoVo.getWarningType());
            logger.info("getWarningType =" + warningInfoVo.getRoleCode());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, UPDATED_DT = ?, UPDATED_BY = ? ");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(),warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }

    @Override
    public void updateStatusByHeaderIdAndType(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByHeaderIdAndType");
            logger.info("getWarningHeaderId =" + warningInfoVo.getWarningHeaderId());
            logger.info("getWarningType =" + warningInfoVo.getWarningType());
            logger.info("getStatus =" + warningInfoVo.getStatus());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType()});
    }

    @Override
    public Integer findWarningInfoNotApproveByWarningHeaderId(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoNotApproveByWarningHeaderId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(WARNING_ID) FROM TBL_WARNING_INFO");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND STATUS != ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId, BusinessConst.Flag.COMPLETE}, Integer.class);

    }

    @Override
    public Integer findMaxWarningId(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findMaxWarningId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT max(warningInfo.WARNING_ID) FROM TBL_WARNING_INFO warningInfo");
        sql.append("\nINNER JOIN TBL_WARNING_HEADER warningHeader");
        sql.append("\nON warningInfo.WARNING_HEAD_ID = warningHeader.WARNING_HEAD_ID");
        sql.append("\nINNER JOIN TBL_ASST_ANSWER asstAnswer");
        sql.append("\nON warningInfo.WARNING_ID = asstAnswer.WARNING_ID AND asstAnswer.VERSION = ?");
        sql.append("\nwhere warningHeader.CIF = ? AND warningInfo.WARNING_TYPE = ?");
        sql.append("\nAND warningInfo.STATUS = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("Param warningInfoVo.getVersion() >>> " + warningInfoVo.getVersion());
            logger.debug("Param warningInfoVo.getCifNo() >>> " + warningInfoVo.getCifNo());
            logger.debug("Param warningInfoVo.getWarningType() >>> " + warningInfoVo.getWarningType());
            logger.debug("SQL >>> " + sql.toString());
        }

        Integer warningId = jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningInfoVo.getVersion(), warningInfoVo.getCifNo(), warningInfoVo.getWarningType(), BusinessConst.Flag.COMPLETE}, Integer.class);
        logger.debug("findMaxWarningId.warningId >>> " + warningId);
        return warningId;
    }
    
    @Override
    public Integer findMaxWarningId(int warningHeaderId, String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findMaxWarningId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT max(WARNING_ID) FROM TBL_WARNING_INFO where warning_head_id = ? and WARNING_TYPE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("warningHeaderId :: " + warningHeaderId);
            logger.debug("warningType     :: " + warningType);
            logger.debug("SQL >>> " + sql.toString());
        }

        Integer warningId = jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId, warningType}, Integer.class);
        logger.debug("findMaxWarningId.warningId >>> " + warningId);
        return warningId;
    }
    
    @Override
    public Integer cntLatePay(int warningHeaderId, String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("cntLatePay");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM TBL_WARNING_INFO where warning_head_id = ? and WARNING_TYPE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("warningHeaderId :: " + warningHeaderId);
            logger.debug("warningType     :: " + warningType);
            logger.debug("SQL >>> " + sql.toString());
        }

        Integer cnt = jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId, warningType}, Integer.class);
        logger.debug("cntLatePay.cnt >>> " + cnt);
        return cnt;
    }

    @Override
    public void saveWarningInfo(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("saveWarningInfo");
            logger.info("getWarningHeaderId ==> " + warningInfoVo.getWarningHeaderId() + ": getWarningType ==> " + warningInfoVo.getWarningType());
            logger.info("getRoleCode ==> " + warningInfoVo.getRoleCode() );
        }
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_WARNING_INFO (WARNING_HEAD_ID,WARNING_TYPE,STATUS,WARNING_DATE,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY , SLA , SLA_DUE_DATE , SLA_FLG , QUALI_WARNING_ID , QUESTION_ID , QUESTION_VERSION ,  HOLDER_ID ,HOLDER_ROLE ,ROLE_CODE, SLA_MASTER )");
        sql.append("\nVALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType(), warningInfoVo.getStatus(),
           warningInfoVo.getWarningDate(), warningInfoVo.getCreatedDate(), warningInfoVo.getCreatedBy(), warningInfoVo.getUpdatedDate(), warningInfoVo.getUpdatedBy(),
           warningInfoVo.getSla(), warningInfoVo.getSlaDueDate() ,warningInfoVo.getSlaFlag(), warningInfoVo.getQualiWarningId(),
           warningInfoVo.getQuestionId() ,  warningInfoVo.getVersion() ,  warningInfoVo.getHolderId() , warningInfoVo.getHolderRole() ,warningInfoVo.getRoleCode(),warningInfoVo.getSlaMaster()});
    }

    @Override
    public void deleteSubTrigger(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteSubTrigger");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_INFO WHERE WARNING_ID IN (");
        sql.append("\n\tSELECT WARNING_ID FROM TBL_WARNING_INFO");
        sql.append("\n\tWHERE WARNING_HEAD_ID=? AND WARNING_TYPE IN (SELECT WARNING_TYPE_CODE FROM TBL_WARNING_TYPE WHERE UNDER_WARNING_TYPE=?)");
        sql.append("\n)");
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderId, BusinessConst.WarningTypeCode.TRIG});
    }

    @Override
    public void cancelTriggerAndPayment(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("cancelTriggerAndPayment");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, TRIG_SHOW_FLAG = ?, UPDATED_DT = ?, UPDATED_BY = ? WHERE WARNING_ID IN (");
        sql.append("\n\tSELECT WARNING_ID FROM TBL_WARNING_INFO");
        sql.append("\n\tWHERE WARNING_HEAD_ID=? AND WARNING_TYPE IN (SELECT WARNING_TYPE_CODE FROM TBL_WARNING_TYPE WHERE UNDER_WARNING_TYPE=?)");
        sql.append("\n)");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getTrigShowFlag(), warningInfoVo.getUpdatedDate(), warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningHeaderId(), BusinessConst.WarningTypeCode.TRIGANDPAY});
    }

    @Override
    public void updateShowAndGen(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateApprove");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET TRIG_GEN_FLAG = ?, TRIG_SHOW_FLAG = ? , STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getTrigGenFlag(), warningInfoVo.getTrigShowFlag(), warningInfoVo.getStatus(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
    }

    @Override
    public Integer findAllApproveTrigger(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoByWarningId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(WARNING_ID) FROM TBL_WARNING_INFO");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_TYPE IN (SELECT WARNING_TYPE_CODE FROM TBL_WARNING_TYPE WHERE UNDER_WARNING_TYPE = ?) AND STATUS != ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId, BusinessConst.WarningTypeCode.TRIG, BusinessConst.Flag.COMPLETE}, Integer.class);
    }

    @Override
    public void updateStausAndApprove(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStausAndApprove");
        }

        StringBuilder sql = new StringBuilder();
        //sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, TRIG_GEN_FLAG = ?, TRIG_SHOW_FLAG = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_TYPE = ?");
        //jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getTrigGenFlag(), warningInfoVo.getTrigShowFlag(), warningInfoVo.getUpdatedDate(),
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(),  warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType()});
    }

    @Override
    public WarningInfoVo findTriggerWarningDate(int warningHeaderId, String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findTriggerWarningDate");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_DATE FROM TBL_WARNING_INFO");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_TYPE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return (WarningInfoVo) jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId, warningType}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
    }

    @Override
    public WarningInfoVo findLastVersion(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findLastVersion");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT warningInfo.WARNING_ID, warningType.QUESTION_ID, warningType.QUESTION_VERSION as version FROM TBL_WARNING_INFO warningInfo");
        sql.append("\nINNER JOIN TBL_WARNING_TYPE warningType");
        sql.append("\nON warningInfo.WARNING_TYPE = warningType.WARNING_TYPE_CODE AND warningType.WARNING_TYPE_CODE=?");
        sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return (WarningInfoVo) jdbcTemplate.queryForObject(sql.toString(), new Object[]{BusinessConst.WarningTypeCode.EWSQ, warningHeaderId}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
    }

    @Override
    public List<WarningInfoVo> findWarningInfo(int warningHeaderId, String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfo");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT warningInfo.WARNING_ID FROM TBL_WARNING_INFO warningInfo");
        sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ? AND warningInfo.WARNING_TYPE = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        //List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningType}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
         List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningType}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningId(rs.getInt("WARNING_ID"));
               return item;
            }
        });   
        return warningInfoVoList;
    }

    @Override
    public void updateQualiSendFlag(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateQualiSendFlag");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET QUALI_SEND_FLG = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND  WARNING_TYPE = ? AND WARNING_ID = ? ");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getQualiSendFlag(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType(),warningInfoVo.getWarningId()});
    }

    @Override
    public WarningInfoVo findWarningInfoObj(int warningHeaderId, int warningInfoId, String warningType) throws Exception {
        WarningInfoVo result = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoObj");
        }       
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, APPROVE, SLA, SLA_DUE_DATE, ");
        sql.append(" CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, QUALI_SEND_FLG, SLA_FLG, HOLDER_ID, HOLDER_ROLE, CLOSE_FLG, ");
        sql.append(" QUESTION_ID, QUESTION_VERSION, QUALI_WARNING_ID , LATE_PAY_ADVICE , LATE_PAY_LEVEL , BCM_LATE_PAY_ADVICE ,  BCM_LATE_PAY_LEVEL , ROLE_CODE ");
        sql.append(" FROM TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ?  AND WARNING_ID = ?  AND  WARNING_TYPE =  ?  order by WARNING_ID desc");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningInfoId, warningType}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString("QUALI_SEND_FLG")));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                item.setQualiWarningId(rs.getInt("QUALI_WARNING_ID"));
                item.setAnswerQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setAnswerQuestionVersion(StringUtil.getValue(rs.getString("QUESTION_VERSION")));
                item.setLatePayAdvice(StringUtil.getValue(rs.getString("LATE_PAY_ADVICE")));
                item.setLatePayLevel(StringUtil.getValue(rs.getString("LATE_PAY_LEVEL")));
                item.setBcmLatePayAdvice(StringUtil.getValue(rs.getString("BCM_LATE_PAY_ADVICE")));
                item.setBcmLatePayLevel(StringUtil.getValue(rs.getString("BCM_LATE_PAY_LEVEL")));
                item.setHolderId(StringUtil.getValue(rs.getString("HOLDER_ID")));
                item.setHolderRole(StringUtil.getValue(rs.getString("HOLDER_ROLE")));
                item.setRoleCode(StringUtil.getValue(rs.getString("ROLE_CODE")));
                try {
                    item.setSla(rs.getInt(A_SLA));
                     if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                            item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                     }else{
                            item.setSlaStr("");
                    }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            result = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return result;
    }
    
    @Override
    public WarningInfoVo findWarningInfoObjByHeaderIdAndType(int warningHeaderId, String warningType) throws Exception {
        WarningInfoVo result = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoObjByHeaderIdAndType");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append(" APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        //sql.append(" TRIG_GEN_FLAG, TRIG_SHOW_FLAG, QUALI_SEND_FLAG, CLOSE_FLAG  ");
        sql.append("  QUALI_SEND_FLG, CLOSE_FLG  ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ? AND  WARNING_TYPE = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        // List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId,warningInfoId, warningType}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));

        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningType}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
               // item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
              //  item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString(A_CLOSE_FLG)));
                try {
                    item.setSla(rs.getInt(A_SLA));
                     if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                        item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                     }else{
                        item.setSlaStr("");
                     }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            result = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return result;
    }

    @Override
    public List<WarningInfoVo> findEwsqCompletByCif(int cif) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findEwsqCompletByCif");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT warningI.WARNING_ID FROM TBL_WARNING_HEADER warningH");
        sql.append("\nINNER JOIN TBL_WARNING_INFO warningI");
        sql.append("\nON warningH.WARNING_HEAD_ID = warningI.WARNING_HEAD_ID");
        //sql.append("\nAND warningI.QUALI_SEND_FLAG = ? AND warningI.WARNING_TYPE = ?"); //--- Comment : 25/06/2015 
        sql.append("\nAND warningI.QUALI_SEND_FLG = ? AND warningI.WARNING_TYPE = ? AND warningI.CLOSE_FLG != 'Y' ");
        sql.append("\nWHERE warningH.CIF = ?");
        sql.append("\nORDER BY warningI.WARNING_ID DESC");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), new Object[]{BusinessConst.Flag.Y, BusinessConst.WarningTypeCode.EWSQ, cif}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
        return warningInfoVoList;
    }

    @Override
    public List<WarningInfoVo> findWarningInfoSendEwsqComplet(int warningHeaderId, String warningType, String flag) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfo");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT warningInfo.WARNING_ID FROM TBL_WARNING_INFO warningInfo");
        //sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ? AND warningInfo.WARNING_TYPE = ? AND warningInfo.QUALI_SEND_FLAG = ?"); //--- Comment : 25/06/2015 
        sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ? AND warningInfo.WARNING_TYPE = ? AND warningInfo.QUALI_SEND_FLG = ?  AND warningInfo.CLOSE_FLG != 'Y' ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningType, flag}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
        return warningInfoVoList;
    }

    @Override
    public void deleteInfoByWarningType(int warningHeaderId, String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteInfoByWarningType");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_INFO WHERE WARNING_HEAD_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderId, warningType});
    }

    @Override
    public WarningInfoVo findWarningInfoObject(int warningHeaderId, String warningType) throws Exception {
        WarningInfoVo data = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfo");
        }
        StringBuilder sql = new StringBuilder();
// EWSL
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, APPROVE, SLA, SLA_DUE_DATE, ");
        sql.append(" CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, QUALI_SEND_FLG, SLA_FLG, HOLDER_ID, HOLDER_ROLE, CLOSE_FLG, ");
        sql.append(" QUESTION_ID, QUESTION_VERSION, QUALI_WARNING_ID ");
        sql.append(" FROM TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ?  AND WARNING_TYPE =  ?  order by WARNING_ID desc");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningType}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
  // EWSM               item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
  // EWSM               item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString("QUALI_SEND_FLG")));
                try {
                    item.setSla(rs.getInt(A_SLA));
                    if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                       item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                    }else{
                       item.setSlaStr("");
                    }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            data = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return data;
    }

    @Override
    public WarningInfoVo findEWSQNotSendScoreByHeaderId(int warningHeaderId) throws Exception {
        WarningInfoVo infoVo = null;
        if (logger.isInfoEnabled()) {
            logger.info("WarningInfoServiceImpl.findEWSQNotSendScore");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, APPROVE, ");
       // sql.append(" SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, TRIG_GEN_FLAG, TRIG_SHOW_FLAG, QUALI_SEND_FLAG ");
        sql.append(" SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, QUALI_SEND_FLG ");
        sql.append(" FROM TBL_WARNING_INFO ");
        sql.append(" WHERE  WARNING_HEAD_ID = ?  AND WARNING_TYPE = ?  AND STATUS = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, BusinessConst.WarningTypeCode.EWSQ, BusinessConst.Flag.COMPLETE}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
        if (!warningInfoVoList.isEmpty()) {
            infoVo = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return infoVo;
    }

    @Override
    public void updateStatusEWSQByWarningIdAndType(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByWarningIdAndType");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, QUALI_SEND_FLG = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getQualiSendFlag(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }

    @Override
    public void updateTriggerResult(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateTriggerResult");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET TRIG_PAY_RESULT = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getTrigPayResult(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
    }

    @Override
    public List<WarningInfoVo> findWarningInfoByHeaderId(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("EWS-L findWarningInfoByHeaderId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append("        APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        sql.append("        QUALI_SEND_FLG  , CLOSE_FLG ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                return item;
            }
        });
        return warningInfoVoList;
    }

    @Override
    public Integer findAllTriggerForCurrentHeaderTrigFlag(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAllTriggerForCurrentHeaderTrigFlag");
        }
        StringBuilder sql = new StringBuilder();


        sql.append(" SELECT COUNT(WARNING_ID) FROM TBL_WARNING_INFO ");
        sql.append(" WHERE  WARNING_HEAD_ID =  ? ");
        sql.append(" AND WARNING_TYPE LIKE 'TRIG%' ");
        sql.append(" AND WARNING_TYPE != 'TRIG' ");
        sql.append(" AND STATUS IN ('RMF' , 'C') ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId}, Integer.class);
    }

    @Override
    public List<WarningInfoVo> findWarningInfoByHeaderAndWarningTypeList(int warningHeaderId, List<String> warningTypeList ) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoByHeaderAndWarningTypeList");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT warningInfo.WARNING_ID,warningInfo.WARNING_TYPE,warningInfo.STATUS FROM TBL_WARNING_INFO warningInfo");
        sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ?");

        int size = warningTypeList.size();
        Object[] obj = new Object[size + 1];
        obj[0] = warningHeaderId;
        int idx = 1;
        if (warningTypeList != null) {
            sql.append("\nAND warningInfo.WARNING_TYPE IN (");
            for (int i = 0; i < size; i++) {
                obj[idx] = warningTypeList.get(i);
                if (i > 0) {
                    sql.append(",");
                }
                sql.append("?");
                idx++;
            }
            sql.append(")");
        }

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), obj, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
        return warningInfoVoList;
    }

    @Override
    public List<WarningInfoVo> findWarningInfoActiveByHeaderAndWarningTypeList(Integer warningHeaderId, List<String> warningTypeList , int qualiWarningInfoIdIrigGen ) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoActiveByHeaderAndWarningTypeList");
        }
        StringBuilder sql = new StringBuilder();
         
        sql.append("SELECT warningInfo.WARNING_ID,warningInfo.WARNING_TYPE,warningType.QUESTION_ID,warningType.QUESTION_VERSION as version, ");
        sql.append("\n warningInfo.WARNING_HEAD_ID, warningInfo.WARNING_DATE, warningInfo.STATUS, warningInfo.RISK_LEVEL, warningInfo.SLA, warningInfo.SLA_DUE_DATE, ");
        //ql.append("\n warningInfo.TRIG_GEN_FLAG, warningInfo.TRIG_SHOW_FLAG, warningInfo.QUALI_SEND_FLAG , warningInfo.QUESTION_ID AS INFO_QUESTION_ID , warningInfo.QUESTION_VERSION AS INFO_QUESTION_VERSION ");
        sql.append("\n  warningInfo.QUALI_SEND_FLG , warningInfo.QUESTION_ID AS INFO_QUESTION_ID , warningInfo.QUESTION_VERSION AS INFO_QUESTION_VERSION ");
        sql.append("\n ,warningInfo.QUALI_WARNING_ID ");
        sql.append("\n FROM TBL_WARNING_INFO warningInfo");
        sql.append("\nINNER JOIN TBL_WARNING_TYPE warningType ON warningInfo.WARNING_TYPE = warningType.WARNING_TYPE_CODE");
        //sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ? AND warningInfo.STATUS != ? "); ---- Fix 05/05/2017 R1.3
        sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ? AND warningInfo.STATUS != ? AND warningInfo.QUALI_WARNING_ID = ? ");
        int size = warningTypeList.size();
        Object[] obj = new Object[size + 3];
        obj[0] = warningHeaderId;
        obj[1] = BusinessConst.Flag.CANCEL;
        obj[2] = qualiWarningInfoIdIrigGen;
        logger.debug(" param : obj[0] ==" + obj[0]);
        logger.debug(" param : obj[1] ==" + obj[1]);
        logger.debug(" param : obj[2] ==" + obj[2]);
        int idx = 3;
        if (warningTypeList != null) {
            sql.append("\nAND warningInfo.WARNING_TYPE IN (");
            for (int i = 0; i < size; i++) {
                obj[idx] = warningTypeList.get(i);
                logger.debug(" param : obj[idx] ==" + obj[idx]);
                if (i > 0) {
                    sql.append(",");
                }
                sql.append("?");
                idx++;
            }
            sql.append(")");
        }
        sql.append("\nORDER BY warningInfo.WARNING_ID");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

       // List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), obj, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), obj ,new RowMapper() {
        @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setVersion(StringUtil.getValue(rs.getString("version")));
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
               // item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
               // item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setQualiWarningId(rs.getInt("QUALI_WARNING_ID"));
                try {
                    item.setSla(rs.getInt(A_SLA));
                    if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                       item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                    }else{
                       item.setSlaStr("");
                    }
                 item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                 item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                 item.setAnswerQuestionId(StringUtil.getValue(rs.getString("INFO_QUESTION_ID")));
                 item.setAnswerQuestionVersion(StringUtil.getValue(rs.getString("INFO_QUESTION_VERSION")));
                } catch (Exception e) {
                }
                return item;
            }
        });
        return warningInfoVoList;
    }

    @Override
    public void updateStatusByWarningHeadIdAndType(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByWarningHeadIdAndType");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType()});
    }

    @Override
    public void updateClosejob(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateClosejob");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET CLOSE_FLG = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getCloseFlag(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
    }

    @Override
    public void updateStatusClosejob(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusClosejob");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
    }
    
    @Override
    public void updateStatusAndCloseFlag(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusAndCloseFlag");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, CLOSE_FLG = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getCloseFlag(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
    }
    
    
    @Override
    public List<WarningInfoVo> findFinOrQcaOrQualiComplete(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findFinOrQualiComplete");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_ID,WARNING_TYPE FROM TBL_WARNING_INFO ");
        sql.append("\nWHERE WARNING_HEAD_ID = ? AND WARNING_TYPE IN (?,?) AND STATUS = ? ");
        sql.append("\nAND DATE(UPDATED_DT) = DATE(CURRENT_DATE) ");
        //---- 29/06/2015 : CloseJob isn't "Y"
        sql.append("\nAND CLOSE_FLG != 'Y' ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningInfoVo> warningInfoVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId,BusinessConst.WarningTypeCode.FIN,BusinessConst.WarningTypeCode.EWSQ,BusinessConst.Flag.COMPLETE}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
        return warningInfoVoList;
    }
    @Override
    public List<WarningInfoVo> findFormConbineWithinHeader(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findFormConbineWithinHeader");
        }
        StringBuilder sql = new StringBuilder();
        //sql.append(" SELECT  WARNING_HEAD_ID , WARNING_ID , WARNING_TYPE , STATUS ,TRIG_GEN_FLAG ");
        sql.append(" SELECT  WARNING_HEAD_ID , WARNING_ID , WARNING_TYPE , STATUS ");
        sql.append(" FROM TBL_WARNING_INFO ");
        sql.append(" WHERE 0=0 ");
        sql.append(" AND WARNING_HEAD_ID = ? ");
        sql.append(" AND STATUS != 'CC'  ");
        sql.append(" AND CLOSE_FLG != 'Y'  "); //--- 03/06/2558
        sql.append(" AND WARNING_TYPE IN ( 'TRIGANDPAY','PAY','EWSQ','EWSQ_TMP' ) ");

       if (logger.isDebugEnabled()) {
            logger.debug("PARAM >>> " + warningHeaderId );
            logger.debug("SQL >>> " + sql.toString());
       }
       List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                //item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
                return item;
            }
        });
        return warningInfoVoList;
    }
    
     @Override
    public WarningInfoVo findWarningInfoObjByWarningInfoId(int warningInfoId, String warningType) throws Exception {
        WarningInfoVo result = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoObj");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append(" APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        sql.append("  QUALI_SEND_FLG, CLOSE_FLG , ROLE_CODE ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_ID = ?  AND  WARNING_TYPE = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningInfoId, warningType}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                //item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
                //item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString(A_CLOSE_FLG)));
                item.setRoleCode(StringUtil.getValue(rs.getString("ROLE_CODE")));
                try {
                    item.setSla(rs.getInt(A_SLA));
                     if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                            item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                     }else{
                            item.setSlaStr("");
                    }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            result = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return result;
    }

    @Override
    public Integer findAllTriggerTempForCurrentHeaderTrigTempFlag(int warningHeaderId) throws Exception {
       if (logger.isInfoEnabled()) {
            logger.info("findAllTriggerTempForCurrentHeaderTrigTempFlag");
        }
        StringBuilder sql = new StringBuilder();


        sql.append(" SELECT COUNT(WARNING_ID) FROM TBL_WARNING_INFO ");
        sql.append(" WHERE  WARNING_HEAD_ID =  ? ");
        sql.append(" AND WARNING_TYPE LIKE 'TRIG%_TMP' ");
        sql.append(" AND WARNING_TYPE != 'TRIG' ");
        sql.append(" AND STATUS IN ('RMF' , 'C') ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId}, Integer.class);
    }
    
    @Override
    public void updateStatusByWarningInfoIdAndType(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByWarningInfoIdAndType");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }

    @Override
    public void resetEwsqInfo(WarningInfoVo warningInfoVo) throws Exception {
         if (logger.isInfoEnabled()) {
            logger.info("resetEwsqInfo");
        }
        StringBuilder sql = new StringBuilder();      
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, UPDATED_DT = ?, UPDATED_BY = ? , "); 
        sql.append("\n QUALI_SEND_FLG = ?, HOLDER_ID = ?, HOLDER_ROLE = ?,CLOSE_FLG = ?  ");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ? ");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getUpdatedDate(),
                warningInfoVo.getUpdatedBy(), warningInfoVo.getQualiSendFlag(), warningInfoVo.getHolderId() ,
                warningInfoVo.getHolderRole(),  warningInfoVo.getCloseFlag(),  warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }
    
    @Override
    public WarningInfoVo findLastVersionByWarningTypeAndId(String warningType , int warningInfoId ) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findLastVersion");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT warningInfo.WARNING_ID, warningInfo.STATUS , warningType.QUESTION_ID, warningType.QUESTION_VERSION as version FROM TBL_WARNING_INFO warningInfo ");
        sql.append("\n INNER JOIN TBL_WARNING_TYPE warningType ");
        sql.append("\n ON warningInfo.WARNING_TYPE = warningType.WARNING_TYPE_CODE AND warningType.WARNING_TYPE_CODE= ? ");
        sql.append("\n WHERE warningInfo.WARNING_ID = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return (WarningInfoVo) jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningType, warningInfoId}, new BeanPropertyRowMapper<WarningInfoVo>(WarningInfoVo.class));
    }

    @Override
    public void updateStatusAndQuestionByWarningIdAndType(WarningInfoVo warningInfoVo) throws Exception {

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, UPDATED_DT = ?, UPDATED_BY = ? ,QUESTION_ID = ? , QUESTION_VERSION = ? , ROLE_CODE = ? ");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getAnswerQuestionId(), warningInfoVo.getAnswerQuestionVersion(),  warningInfoVo.getRoleCode(),warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }

    @Override
    public WarningInfoVo findWarningInfoObject(int warningInfoId) throws Exception {
        WarningInfoVo data = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfo");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL,");
        sql.append(" SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, QUALI_SEND_FLG ");
        sql.append(" , QUALI_WARNING_ID , QUESTION_ID , QUESTION_VERSION ");
        sql.append(" FROM TBL_WARNING_INFO ");
        sql.append("\nWHERE WARNING_ID = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningInfoId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString("QUALI_SEND_FLG")));
                item.setQualiWarningId(rs.getInt("QUALI_WARNING_ID"));
                item.setAnswerQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setAnswerQuestionVersion(StringUtil.getValue(rs.getString("QUESTION_VERSION")));
                try {
                    item.setSla(rs.getInt(A_SLA));
                    if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                       item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                    }else{
                       item.setSlaStr("");
                    }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            data = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return data;
    }
    
    
     @Override
    public WarningInfoVo findEWSQLastVersion(int warningHeaderId) throws Exception {
        WarningInfoVo data = null;
      if (logger.isInfoEnabled()) {
            logger.info("findEWSQLastVersion");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT warningInfo.WARNING_ID, warningType.QUESTION_ID, warningType.QUESTION_VERSION as version , warningInfo.QUALI_WARNING_ID , warningInfo.QUESTION_ID as INFO_QUESTION_ID ,warningInfo.QUESTION_VERSION as INFO_QUESTION_VERSION  , warningInfo.CLOSE_FLG ");
        sql.append("\nFROM TBL_WARNING_INFO warningInfo ");
        sql.append("\nINNER JOIN TBL_WARNING_TYPE warningType ");
        sql.append("\nON warningInfo.WARNING_TYPE = warningType.WARNING_TYPE_CODE AND warningType.WARNING_TYPE_CODE=?");
        sql.append("\nWHERE warningInfo.WARNING_HEAD_ID = ?");
 
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{BusinessConst.WarningTypeCode.EWSQ,warningHeaderId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningId(rs.getInt("WARNING_ID"));
                item.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setVersion(StringUtil.getValue(rs.getString("version")));
                item.setQualiWarningId(rs.getInt("QUALI_WARNING_ID"));
                item.setAnswerQuestionId(StringUtil.getValue(rs.getString("INFO_QUESTION_ID")));
                item.setAnswerQuestionVersion(StringUtil.getValue(rs.getString("INFO_QUESTION_VERSION")));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            data = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return data;
    }
 
    @Override
    public void updateStatus(WarningInfoVo warningInfoVo) throws Exception {
        logger.info("[updateStatus][Begin]");
        
        StringBuilder       sql             = new StringBuilder();
        String              columnUpdate    = "";
        String              whereCause      = "";
        ArrayList<Object>   params          = new ArrayList<Object>();
        
        try{
            logger.info("[updateStatus] STATUS :: " + warningInfoVo.getStatus());
            if(warningInfoVo.getStatus()!=null && !"".equals(warningInfoVo.getStatus())){
                if("".equals(columnUpdate)){
                    columnUpdate += " STATUS = ?";
                }else{
                    columnUpdate += " ,STATUS = ?";
                }
                params.add(warningInfoVo.getStatus());
            }
            
            if("".equals(columnUpdate)){
                columnUpdate += " UPDATED_DT = CURRENT TIMESTAMP";
            }else{
                columnUpdate += " ,UPDATED_DT = CURRENT TIMESTAMP";
            }
            
            logger.info("[updateStatus] UPDATED_BY :: " + warningInfoVo.getUpdatedBy());
            if(warningInfoVo.getUpdatedBy()!=null && !"".equals(warningInfoVo.getUpdatedBy())){
                if("".equals(columnUpdate)){
                    columnUpdate += " UPDATED_BY = ?";
                }else{
                    columnUpdate += " ,UPDATED_BY = ?";
                }
                params.add(warningInfoVo.getUpdatedBy());
            }
            
            logger.info("[updateStatus] HOLDER_ID :: " + warningInfoVo.getHolderId());
            if(warningInfoVo.getHolderId()!=null && !"".equals(warningInfoVo.getHolderId())){
                if("".equals(columnUpdate)){
                    columnUpdate += " HOLDER_ID = ?";
                }else{
                    columnUpdate += " ,HOLDER_ID = ?";
                }
                params.add(warningInfoVo.getHolderId());
            }
            
            logger.info("[updateStatus] HOLDER_ROLE :: " + warningInfoVo.getHolderRole());
            if(warningInfoVo.getHolderRole()!=null && !"".equals(warningInfoVo.getHolderRole())){
                if("".equals(columnUpdate)){
                    columnUpdate += " HOLDER_ROLE = ?";
                }else{
                    columnUpdate += " ,HOLDER_ROLE = ?";
                }
                params.add(warningInfoVo.getHolderRole());
            }
            
            if("".equals(columnUpdate)){
                columnUpdate += " AMD_FLG = ?";
            }else{
                columnUpdate += " ,AMD_FLG = ?";
            }
            params.add(warningInfoVo.getAmdFlg());
            
            if("".equals(columnUpdate)){
                columnUpdate += " BCM_AMD_FLG = ?";
            }else{
                columnUpdate += " ,BCM_AMD_FLG = ?";
            }
            params.add(warningInfoVo.getBcmAmdFlg());
            
//            logger.info("[updateStatus] AMD_FLG :: " + warningInfoVo.getAmdFlg());
//            if(warningInfoVo.getAmdFlg()!=null && !"".equals(warningInfoVo.getAmdFlg())){
//                if("".equals(columnUpdate)){
//                    columnUpdate += " AMD_FLG = ?";
//                }else{
//                    columnUpdate += " ,AMD_FLG = ?";
//                }
//                params.add(warningInfoVo.getAmdFlg());
//            }
//            
//            logger.info("[updateStatus] BCM_AMD_FLG :: " + warningInfoVo.getBcmAmdFlg());
//            if(warningInfoVo.getBcmAmdFlg()!=null && !"".equals(warningInfoVo.getBcmAmdFlg())){
//                if("".equals(columnUpdate)){
//                    columnUpdate += " BCM_AMD_FLG = ?";
//                }else{
//                    columnUpdate += " ,BCM_AMD_FLG = ?";
//                }
//                params.add(warningInfoVo.getBcmAmdFlg());
//            }
            
            logger.info("[updateStatus] WARNING_ID :: " + warningInfoVo.getWarningId());
            if(warningInfoVo.getWarningId()!=null){
                whereCause += " WARNING_ID = ?";
                params.add(warningInfoVo.getWarningId());
            }
            
            sql.append("UPDATE TBL_WARNING_INFO SET").append(columnUpdate).append("WHERE").append(whereCause);
            
            logger.info("[updateStatus] sql :: " + sql.toString());
            
            jdbcTemplate.update(sql.toString(), params.toArray());
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.info("[updateStatus][End]");
        }
    }
    
    @Override
    public void updateStatusForWayOut(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusForWayOut");
            logger.info("Status         :: " + warningInfoVo.getStatus());
            logger.info("UpdatedBy      :: " + warningInfoVo.getUpdatedBy());
            logger.info("HolderId       :: " + warningInfoVo.getHolderId());
            logger.info("HolderRole     :: " + warningInfoVo.getHolderRole());
            logger.info("WarningId      :: " + warningInfoVo.getWarningId());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = ?, HOLDER_ID = ?, HOLDER_ROLE = ?");
        sql.append("\nWHERE WARNING_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{ warningInfoVo.getStatus()
                                                        , warningInfoVo.getUpdatedBy()
                                                        , warningInfoVo.getHolderId()
                                                        , warningInfoVo.getHolderRole()
                                                        , warningInfoVo.getWarningId()});
    }

    @Override
    public WarningInfoVo getWarningIdAndStatus(WarningInfoVo warningInfoVo) throws Exception {
        
        WarningInfoVo warningInfoVoDb = null;
        
        try{
            if (logger.isInfoEnabled()) {
                logger.info("getWarningIdAndStatus");
            }
            
            StringBuilder sql = new StringBuilder();
            sql.append("select t.*, a.warning_type_desc ");
            sql.append("    from TBL_WARNING_INFO t");
            sql.append("        inner join tbl_warning_type a on a.warning_type_code = t.warning_type");
            sql.append("    WHERE t.WARNING_HEAD_ID  = ?");
            sql.append("        AND t.WARNING_TYPE    = ?");
            
            if (logger.isDebugEnabled()) {
                logger.debug("WarningHeaderId   :: " + warningInfoVo.getWarningHeaderId());
                logger.debug("WarningType       :: " + warningInfoVo.getWarningType());
                logger.debug("SQL >>> " + sql.toString());
            }
            
            List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType()}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningInfoVo item = new WarningInfoVo();
                    item.setWarningId(rs.getInt("WARNING_ID"));
                    item.setStatus(rs.getString("STATUS"));
                    item.setAmdFlg(rs.getString("AMD_FLG"));
                    item.setBcmAmdFlg(rs.getString("BCM_AMD_FLG"));
                    item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("WARNING_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("WARNING_DATE")));
                    item.setHolderRole(rs.getString("HOLDER_ROLE"));
                    item.setWarningTypeDesc(rs.getString("warning_type_desc"));
                    item.setConfirmLatePay(rs.getString("confirm_late_pay"));
                    item.setBcmConfirmLatePay(rs.getString("bcm_confirm_late_pay"));
                    return item;
                }
            });
            
            if(warningInfoVoList!=null && warningInfoVoList.size() > 0){
                warningInfoVoDb = warningInfoVoList.get(0);
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }
        
        return warningInfoVoDb;
    }
    
    @Override
    public int getMinWarningId(WarningInfoVo warningInfoVo) throws Exception {
        
        int warningId = 0;
        
        try{
            if (logger.isInfoEnabled()) {
                logger.info("getMinWarningId");
            }
            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT MIN(WARNING_ID) AS WARNING_ID ");
            sql.append("    from TBL_WARNING_INFO");
            sql.append("    WHERE WARNING_HEAD_ID  = ?");
            sql.append("        AND WARNING_TYPE    = ?");
            
            if (logger.isDebugEnabled()) {
                logger.debug("WarningHeaderId   :: " + warningInfoVo.getWarningHeaderId());
                logger.debug("WarningType       :: " + warningInfoVo.getWarningType());
                logger.debug("SQL >>> " + sql.toString());
            }
            
            List<Integer> warningIdVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningInfoVo.getWarningHeaderId(), warningInfoVo.getWarningType()}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("WARNING_ID");
                }
            });
            
            if(warningIdVoList!=null && warningIdVoList.size() > 0){
                warningId = warningIdVoList.get(0);
            }
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }
        
        return warningId;
    }
    
   /* @Override
    public List<WarningInfoVo> findWarningInfoAllTrigByHeaderId(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("EWS-L findWarningInfoAllTrigByHeaderId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append("        APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        sql.append("        QUALI_SEND_FLG  , CLOSE_FLG  , QUESTION_ID , QUESTION_VERSION ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ?   AND  WARNING_TYPE LIKE 'TRIG%'  ");
        sql.append(" ORDER BY WARNING_ID,WARNING_TYPE ASC  ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                item.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setQuestionVersionFlag(StringUtil.getValue(rs.getString("QUESTION_VERSION")));
                return item;
            }
        });
        return warningInfoVoList;
    }*/

    @Override
    public List<WarningInfoVo> findWarningInfoAllTrigByHeaderIdAndRoleCode(int warningHeaderId , String roleCode, int qualiWarningId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("EWS-L findWarningInfoAllTrigByHeaderId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append("        APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        sql.append("        QUALI_SEND_FLG  , CLOSE_FLG  , QUESTION_ID , QUESTION_VERSION ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ?   AND  WARNING_TYPE LIKE 'TRIG%' AND  ROLE_CODE IN (").append(roleCode).append(") ");
        sql.append(" AND  QUALI_WARNING_ID = ?  ");
        sql.append(" ORDER BY WARNING_ID,WARNING_TYPE ASC  ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId,qualiWarningId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                item.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setQuestionVersionFlag(StringUtil.getValue(rs.getString("QUESTION_VERSION")));
                return item;
            }
        });
        return warningInfoVoList;
    }
    
    @Override
    public void updateStatusLatePayment(WarningInfoVo warningInfoVo) throws Exception {
        StringBuilder sql = new StringBuilder();
        //sql.append(" UPDATE TBL_WARNING_INFO SET LATE_PAY_ADVICE = ?,  LATE_PAY_LEVEL = ?, UPDATED_DT = ?, UPDATED_BY = ? ");
        sql.append(" UPDATE TBL_WARNING_INFO SET UPDATED_DT = ?, UPDATED_BY = ? ");
        if (warningInfoVo.getLatePayLevel() != null && warningInfoVo.getLatePayLevel().trim().length() > 0) {
             sql.append(" ,  LATE_PAY_LEVEL = '").append(warningInfoVo.getLatePayLevel()).append("'");
        } 
        if (warningInfoVo.getLatePayAdvice() != null && warningInfoVo.getLatePayAdvice().trim().length() > 0) {
             sql.append(" ,  LATE_PAY_ADVICE = '").append(warningInfoVo.getLatePayAdvice()).append("'");
        } 
        if (warningInfoVo.getBcmLatePayLevel() != null && warningInfoVo.getBcmLatePayLevel().trim().length() > 0) {
             sql.append(" ,  BCM_LATE_PAY_LEVEL = '").append(warningInfoVo.getBcmLatePayLevel()).append("'");
        } 
        if (warningInfoVo.getBcmLatePayAdvice()!= null && warningInfoVo.getBcmLatePayAdvice().trim().length() > 0) {
             sql.append(" ,  BCM_LATE_PAY_ADVICE = '").append(warningInfoVo.getBcmLatePayAdvice()).append("'");
        }   
        sql.append("\n WHERE WARNING_ID = ? AND WARNING_TYPE = ? ");
        
        jdbcTemplate.update(sql.toString(), new Object[]{ warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }

    @Override
    public void deleteTrigger(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteTrigger");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_INFO  WHERE WARNING_HEAD_ID = ?   AND  WARNING_TYPE LIKE 'TRIG%'  ");
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderId});
    }

    @Override
    public void deleteTriggerNotApprove(int warningHeaderId, String warningIdAll , int qualiWarningId) throws Exception {
       if (logger.isInfoEnabled()) {
            logger.info("deleteTriggerNotApprove");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE TBL_WARNING_INFO ");
        sql.append("\n WHERE WARNING_HEAD_ID = ?  AND WARNING_ID NOT IN ( ").append(warningIdAll).append(" )");
        sql.append("\n AND WARNING_TYPE IN  (SELECT WARNING_TYPE_CODE FROM TBL_WARNING_TYPE");
        sql.append("\n WHERE UNDER_WARNING_TYPE = ? ) AND QUALI_WARNING_ID = ? ");
        
        logger.info(" deleteTriggerNotApprove SQL >>" + sql.toString());
        
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderId,BusinessConst.WarningTypeCode.EWSQ,qualiWarningId});
    }
    
    @Override
    public void updateStatusByWarningIdAndTypeLatePayment(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByWarningIdAndTypeLatePayment");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, UPDATED_DT = ?, UPDATED_BY = ? ,BCM_LATE_PAY_ADVICE  = ? ,BCM_LATE_PAY_LEVEL = ? ");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId(), warningInfoVo.getWarningType(),warningInfoVo.getBcmLatePayAdvice(),warningInfoVo.getBcmLatePayLevel()});
    }
    
    @Override
    public void deleteLatePaymentForm(WarningInfoVo warningInfoVo) throws Exception {
        logger.info("[deleteLatePaymentForm][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            logger.info("[deleteLatePaymentForm] WARNING_ID :: " + warningInfoVo.getWarningId());
            logger.info("[deleteLatePaymentForm] UPDATED_BY :: " + warningInfoVo.getUpdatedBy());
            
            sql.append("update TBL_WARNING_INFO");
            sql.append("    SET STATUS              = 'N'");
            sql.append("      , QUESTION_ID         = NULL");
            sql.append("      , QUESTION_VERSION    = NULL");
            sql.append("      , LATE_PAY_LEVEL      = NULL");
            sql.append("      , LATE_PAY_ADVICE     = NULL");
            sql.append("      , BCM_LATE_PAY_LEVEL  = NULL");
            sql.append("      , BCM_LATE_PAY_ADVICE = NULL");
            sql.append("      , HOLDER_ID           = NULL");
            sql.append("      , HOLDER_ROLE         = NULL");
            sql.append("      , UPDATED_DT          = CURRENT TIMESTAMP");
            sql.append("      , UPDATED_BY          = ?");
            sql.append("    WHERE WARNING_ID = ?");

            jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.info("[deleteLatePaymentForm][End]");
        }
    }
    
    @Override
    public void deleteAction1Form(WarningInfoVo warningInfoVo) throws Exception {
        logger.info("[deleteAction1Form][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            logger.info("[deleteAction1Form] WARNING_ID :: " + warningInfoVo.getWarningId());
            logger.info("[deleteAction1Form] UPDATED_BY :: " + warningInfoVo.getUpdatedBy());
            
            sql.append("update TBL_WARNING_INFO");
            sql.append("    SET STATUS              = 'N'");
            sql.append("      , AMD_FLG             = NULL");
            sql.append("      , HOLDER_ID           = NULL");
            sql.append("      , HOLDER_ROLE         = NULL");
            sql.append("      , UPDATED_DT          = CURRENT TIMESTAMP");
            sql.append("      , UPDATED_BY          = ?");
            sql.append("    WHERE WARNING_ID = ?");

            jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getUpdatedBy(), warningInfoVo.getWarningId()});
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.info("[deleteAction1Form][End]");
        }
    }
    
    @Override
    public void updateConfirmLatepayment(String confirmLatePayment, String bcmConfirmLatePayment, String warningId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateConfirmLatepayment");
            logger.info("confirmLatePayment         :: " + confirmLatePayment);
            logger.info("bcmConfirmLatePayment      :: " + bcmConfirmLatePayment);
            logger.info("warningId                  :: " + warningId);
        }

        StringBuilder       sql         = new StringBuilder();
        ArrayList<Object>   params      = new ArrayList<Object>();
        String              setUpdate   = "";
        
        sql.append("UPDATE TBL_WARNING_INFO SET ");
        
        if(confirmLatePayment!=null && !confirmLatePayment.equals("")){
            setUpdate += "CONFIRM_LATE_PAY = ?";
            
            confirmLatePayment = "Y".equals(confirmLatePayment)?"Y":"N";
            
            params.add(confirmLatePayment);
        }
        
        if(bcmConfirmLatePayment!=null && !bcmConfirmLatePayment.equals("")){
            if(setUpdate.equals("")){
                setUpdate += "BCM_CONFIRM_LATE_PAY = ?";
            }else{
                setUpdate += ",BCM_CONFIRM_LATE_PAY  = ?";
            }
            
            bcmConfirmLatePayment = "Y".equals(bcmConfirmLatePayment)?"Y":"N";
            
            params.add(bcmConfirmLatePayment);
        }
        
        sql.append(setUpdate);
        sql.append(" WHERE WARNING_ID = ?");
        params.add(warningId);
        
        jdbcTemplate.update(sql.toString(), params.toArray());
    }

    @Override
    public void deleteWarningInfoId(int warningHeaderId,String warningIdStr) throws Exception{
        if (logger.isInfoEnabled()) {
            logger.info("deleteWarningInfoId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("DELETE FROM TBL_WARNING_INFO WHERE WARNING_ID IN (").append(warningIdStr).append(" )  AND  WARNING_HEAD_ID = ?  ");
     
        jdbcTemplate.update(sql.toString(), new Object[]{warningHeaderId});
    }
    @Override
    public List<WarningInfoVo> findWarningInfoObjByHeaderIdArray(int warningHeaderId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfoObjByHeaderIdAndTypeArray");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append(" APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        sql.append(" TRIG_GEN_FLAG, TRIG_SHOW_FLAG, QUALI_SEND_FLAG, CLOSE_FLG  ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
                item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString(A_CLOSE_FLG)));
                try {
                    item.setSla(rs.getInt(A_SLA));
                     if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                        item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                     }else{
                        item.setSlaStr("");
                     }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });
        return warningInfoVoList;
    }

    @Override
    public Integer checkStatusInfoByHeaderForClosePipeline(int warningHeaderId) throws Exception {
       if (logger.isInfoEnabled()) {
            logger.info("checkStatusInfoByHeaderForClosePipeline : warningHeaderId >>" +warningHeaderId );
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(WARNING_ID) FROM TBL_WARNING_INFO");
        sql.append("\n WHERE WARNING_HEAD_ID = ? ");
        sql.append("\n AND STATUS NOT IN ('C','CC')");
        
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningHeaderId}, Integer.class);
    }
    
    @Override
    public Integer findLatestWarningInfoByCif(String cifNo, String warningType) throws Exception {
          if (logger.isInfoEnabled()) {
            logger.info("findLatestWarningInfoByCif");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT MAX(WARNING_ID) ");
        sql.append("\n FROM  TBL_WARNING_INFO   ");
        sql.append("\n WHERE WARNING_HEAD_ID IN ( SELECT WARNING_HEAD_ID FROM TBL_WARNING_HEADER WHERE CIF = ? ) ");
        sql.append("\n AND WARNING_TYPE = ? ");
        sql.append("\n AND (STATUS = 'C' AND CLOSE_FLG != 'Y') ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{cifNo,warningType}, Integer.class);
    }

     @Override
    public WarningInfoVo findLastVersionByWarningInfoID(int warningInfoId , String warningType) throws Exception {
       WarningInfoVo data = null;
        if (logger.isInfoEnabled()) {
            logger.info("findLastVersionByWarningInfoID");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT  INFO.WARNING_HEAD_ID , INFO.WARNING_ID, WT.QUESTION_ID, WT.QUESTION_VERSION as VERSION ,  INFO.QUALI_WARNING_ID ,  INFO.QUESTION_ID as INFO_QUESTION_ID , INFO.QUESTION_VERSION as INFO_QUESTION_VERSION , INFO.CLOSE_FLG ");
        sql.append("\n FROM TBL_WARNING_INFO  INFO   ");
        sql.append("\n INNER JOIN TBL_WARNING_TYPE WT   ");
        sql.append("\n ON  INFO.WARNING_TYPE = WT.WARNING_TYPE_CODE AND WT.WARNING_TYPE_CODE = ? ");
        sql.append("\n WHERE  INFO.WARNING_ID = ?   "); 
             
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningType,warningInfoId}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt("WARNING_HEAD_ID"));
                item.setWarningId(rs.getInt("WARNING_ID"));
                item.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setVersion(StringUtil.getValue(rs.getString("VERSION")));
                item.setQualiWarningId(rs.getInt("QUALI_WARNING_ID"));
                item.setAnswerQuestionId(StringUtil.getValue(rs.getString("INFO_QUESTION_ID")));
                item.setAnswerQuestionVersion(StringUtil.getValue(rs.getString("INFO_QUESTION_VERSION")));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            data = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return data;
    }

    @Override
    public WarningInfoVo findWarningInfoObjectByMaxWarningInfo(int warningHeaderId, String warningType) throws Exception {
       
        WarningInfoVo data = null;
        if (logger.isInfoEnabled()) {
            logger.info("findWarningInfo");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, APPROVE, SLA, SLA_DUE_DATE,   ");
        sql.append("\n CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, QUALI_SEND_FLG, SLA_FLG, HOLDER_ID, HOLDER_ROLE, CLOSE_FLG,   ");
        sql.append("\n QUESTION_ID, QUESTION_VERSION, QUALI_WARNING_ID   ");
        sql.append("\n FROM TBL_WARNING_INFO   ");
        sql.append("\n WHERE WARNING_ID = (SELECT MAX(WARNING_ID) FROM TBL_WARNING_INFO WHERE WARNING_HEAD_ID = ? AND WARNING_TYPE =  ? ) ");
   
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId, warningType}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
  // EWSM               item.setTrigGenFlag(StringUtil.getValue(rs.getString(A_TRIG_GEN_FLAG)));
  // EWSM               item.setTrigShowFlag(StringUtil.getValue(rs.getString(A_TRIG_SHOW_FLAG)));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString("QUALI_SEND_FLG")));
                try {
                    item.setSla(rs.getInt(A_SLA));
                    if(rs.getString(A_SLA) != null && rs.getString(A_SLA).length() > 0){
                       item.setSlaStr(MoneyUtil.formatMoney(rs.getInt(A_SLA), 0));
                    }else{
                       item.setSlaStr("");
                    }
                    item.setSlaDueDate(rs.getDate(A_SLA_DUE_DATE));
                    item.setSlaDueDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_SLA_DUE_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_SLA_DUE_DATE)));
                } catch (Exception e) {
                }
                return item;
            }
        });

        if (!warningInfoVoList.isEmpty()) {
            data = (WarningInfoVo) warningInfoVoList.get(0);
        }
        return data;
    }

    @Override
    public void updateStatusByWarningIdAndTypeRoleCodeAns(WarningInfoVo warningInfoVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateStatusByWarningIdAndTypeRoleCodeAns");
            logger.info("getStatus =" + warningInfoVo.getStatus());
            logger.info("getWarningId =" + warningInfoVo.getWarningId());
            logger.info("getWarningType =" + warningInfoVo.getWarningType());
            logger.info("getWarningType =" + warningInfoVo.getRoleCode());
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_INFO SET STATUS = ?, HOLDER_ID = ?, HOLDER_ROLE = ?, UPDATED_DT = ?, UPDATED_BY = ? , ROLE_CODE = ? ");
        sql.append("\nWHERE WARNING_ID = ? AND WARNING_TYPE = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningInfoVo.getStatus(), warningInfoVo.getHolderId(), warningInfoVo.getHolderRole(), warningInfoVo.getUpdatedDate(),
            warningInfoVo.getUpdatedBy(),  warningInfoVo.getRoleCode() ,warningInfoVo.getWarningId(), warningInfoVo.getWarningType()});
    }

    @Override
    public List<Integer> findTriggerNotApprove(int warningHeaderId, String warningIdAll, int qualiWarningId) throws Exception {
         if (logger.isInfoEnabled()) {
            logger.info("findTriggerNotApprove");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID FROM TBL_WARNING_INFO ");
        sql.append("\n WHERE WARNING_HEAD_ID = ?  AND WARNING_ID NOT IN ( ").append(warningIdAll).append(" )");
        sql.append("\n AND WARNING_TYPE IN  (SELECT WARNING_TYPE_CODE FROM TBL_WARNING_TYPE");
        sql.append("\n WHERE UNDER_WARNING_TYPE = ? ) AND QUALI_WARNING_ID = ? ");
        
        logger.info(" findTriggerNotApprove SQL >>" + sql.toString());
  
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId,BusinessConst.WarningTypeCode.EWSQ,qualiWarningId}, new RowMapper() {
        @Override
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            WarningInfoVo item = new WarningInfoVo();
            item.setWarningId(rs.getInt("WARNING_ID"));
          return item;
        
          }
        });  
            
        List<Integer> warningInfoTriggerNotApproveList = new ArrayList<Integer>();
        if(warningInfoVoList != null && !warningInfoVoList.isEmpty()){
           for(WarningInfoVo vo : warningInfoVoList){
                warningInfoTriggerNotApproveList.add(vo.getWarningId());
           }
        }
        return warningInfoTriggerNotApproveList;
    }

    @Override
    public List<WarningInfoVo> findWarningInfoAllTrigByHeaderIdAndQualiId(int warningHeaderId, int qualiWarningId) throws Exception {
         if (logger.isInfoEnabled()) {
            logger.info("EWS-L findWarningInfoAllTrigByHeaderId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, WARNING_HEAD_ID, WARNING_TYPE, WARNING_DATE, STATUS, RISK_LEVEL, ");
        sql.append("        APPROVE, SLA, SLA_DUE_DATE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ");
        sql.append("        QUALI_SEND_FLG  , CLOSE_FLG  , QUESTION_ID , QUESTION_VERSION ");
        sql.append(" FROM  TBL_WARNING_INFO ");
        sql.append(" WHERE WARNING_HEAD_ID = ?   AND  WARNING_TYPE LIKE 'TRIG%'  AND QUALI_WARNING_ID = ? ");
        sql.append(" ORDER BY WARNING_ID,WARNING_TYPE ASC  ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
        List<WarningInfoVo> warningInfoVoList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningHeaderId,qualiWarningId }, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                WarningInfoVo item = new WarningInfoVo();
                item.setWarningHeaderId(rs.getInt(A_WARNING_HEAD_ID));
                item.setWarningId(rs.getInt(A_WARNING_ID));
                item.setWarningType(StringUtil.getValue(rs.getString(A_WARNING_TYPE)));
                item.setWarningDate(rs.getDate(A_WARNING_DATE));
                item.setWarningDateStr(ValidatorUtil.isNullOrEmpty(rs.getTimestamp(A_WARNING_DATE)) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp(A_WARNING_DATE)));
                item.setRiskLevel(StringUtil.getValue(rs.getString(A_RISK_LEVEL)));
                item.setStatus(StringUtil.getValue(rs.getString(A_STATUS)));
                item.setCreatedBy(StringUtil.getValue(rs.getString(A_CREATED_BY)));
                item.setCreatedDate(rs.getDate(A_CREATED_DT));
                item.setUpdatedBy(StringUtil.getValue(rs.getString(A_UPDATED_BY)));
                item.setUpdatedDate(rs.getDate(A_UPDATED_DT));
                item.setQualiSendFlag(StringUtil.getValue(rs.getString(A_QUALI_SEND_FLG)));
                item.setCloseFlag(StringUtil.getValue(rs.getString("CLOSE_FLG")));
                item.setQuestionId(StringUtil.getValue(rs.getString("QUESTION_ID")));
                item.setQuestionVersionFlag(StringUtil.getValue(rs.getString("QUESTION_VERSION")));
                return item;
            }
        });
        return warningInfoVoList;
    }

   
}
