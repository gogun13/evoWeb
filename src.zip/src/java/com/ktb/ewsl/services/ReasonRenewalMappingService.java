/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ReasonRenewalMappingVo;

/**
 *
 * @author KTBDevLoan
 */
public interface ReasonRenewalMappingService {
    
    public String getTypeFlg(String reasonRenewalScore)throws Exception;
    public ReasonRenewalMappingVo getObjectReasonRenewalMapping(String reasonRenewalScore)throws Exception;
   
}
