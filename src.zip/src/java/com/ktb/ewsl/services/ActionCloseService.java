/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.ActionCloseVo;
import com.ktb.ewsl.vo.ReportCloseJobVo;
import com.ktbcs.core.utilities.PaginatedListImpl;
import com.ktbcs.core.vo.SearchBean;
import java.util.List;

/**
 *
 * @author Tum_Surapong
 */
public interface ActionCloseService {
    public void saveData(ActionCloseVo vo) throws Exception;
    public List<ActionCloseVo> findDataByWarningHeadId(Integer warningHeadId) throws Exception;
    public PaginatedListImpl getCloseListReport(PaginatedListImpl paginate, SearchBean searchBean , int pageAmt , String roleQuery) throws Exception;
    public PaginatedListImpl getCloseListReportForExport(SearchBean searchBean) throws Exception;
    public PaginatedListImpl getCloseListReportEwsl(PaginatedListImpl paginate, SearchBean searchBean, int pageAmt, String roleQuery) throws Exception;
    public List<ReportCloseJobVo> getDataByWarningHeadIdForEwsl(Integer warningHeadId) throws Exception;
    public PaginatedListImpl getCloseListReportForExportEwsl(SearchBean searchBean) throws Exception;
    public List<ActionCloseVo> getcloseJobDetailList(String warningHeadId, String warningType) throws Exception;
    public List<ActionCloseVo> getcloseJobDetailListByWarningHeadId(String warningHeadId, String warningType) throws Exception;
}
