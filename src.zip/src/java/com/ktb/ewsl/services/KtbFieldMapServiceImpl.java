/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.KtbFieldMapVO;
import com.ktbcs.core.utilities.StringUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class KtbFieldMapServiceImpl implements KtbFieldMapService{
    
   private static final Logger log = Logger.getLogger(KtbFieldMapServiceImpl.class);
      
   @Autowired
   private JdbcTemplate jdbcTemplate;

    @Override
    public List<KtbFieldMapVO> getKtbFieldMapList(int ktbFieldMapGroup) throws Exception {
         List<KtbFieldMapVO> result ;
        if (log.isInfoEnabled()) {
            log.info("KtbFieldMapServiceImpl.getKtbFieldMapList");
        }
        try{
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT KTB_FIELD_MAP , KTB_FIELD_MAP_GROUP , KTB_FIELD_MAP_NAME FROM TBL_MT_KTB_FIELD_MAP ");
        sql.append(" WHERE KTB_FIELD_MAP_GROUP = ? ");

          result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{ktbFieldMapGroup}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    KtbFieldMapVO item = new KtbFieldMapVO();
                    item.setKtbFieldMapCode(StringUtil.getValue(rs.getString("KTB_FIELD_MAP")));
                    item.setKtbFieldMapGroup(rs.getInt("KTB_FIELD_MAP_GROUP"));
                    item.setKtbFieldMapName(StringUtil.getValue(rs.getString("KTB_FIELD_MAP_NAME")));
                    return item;
                }
            });
        }catch(Exception e){
           throw e;
        } 
        return result;
    }

 
}
