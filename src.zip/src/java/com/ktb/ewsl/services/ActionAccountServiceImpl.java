/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.utilities.MoneyUtil;
import com.ktb.ewsl.vo.ActionAccountVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author pumin
 */
@Repository
public class ActionAccountServiceImpl implements ActionAccountService {

    @Autowired
    public JdbcTemplate jdbcTemplate;
    private static Logger log = Logger.getLogger(ActionAccountServiceImpl.class);

    @Override
    public ArrayList<ActionAccountVo> getActionAccountList (String warningHeadId, String warningId) throws Exception {
        log.info("[getActionAccountList][Begin]");
        
        ArrayList<ActionAccountVo>  result  = null;
        StringBuilder               sql     = null;
        
        try {

            sql     = new StringBuilder("SELECT * FROM TBL_ACTION_ACCOUNT WHERE WARNING_HEAD_ID = ? and WARNING_ID = ? ORDER BY DUE_DATE DESC ");
            
            result  = (ArrayList<ActionAccountVo>) jdbcTemplate.query(sql.toString(), new Object[]{warningHeadId, warningId}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ActionAccountVo vo = new ActionAccountVo();
                    try{
                        vo.setAccountNo(rs.getString("ACCOUNT_NO"));
                        vo.setAccountSubType(rs.getString("ACCOUNT_SUB_TYPE"));
//                        vo.setActionFlg(rs.getString("ACTION_FLG"));
                        vo.setBillNo(rs.getString("BILL_NO"));
                        vo.setcFinal(rs.getString("C_FINAL"));
                        vo.setDpd(rs.getString("DPD"));
                        vo.setDpdZeroDate(rs.getString("DPD_ZERO_DATE"));
                        vo.setDpdZeroDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("DPD_ZERO_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("DPD_ZERO_DATE")));
                        vo.setDueAmt(MoneyUtil.formatMoney(rs.getString("DUE_AMT")));
                        vo.setDueDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("DUE_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("DUE_DATE")));
                        vo.setInputAccountNo(rs.getString("INPUT_ACCOUNT_NO"));
                        vo.setInputBillNo(rs.getString("INPUT_BILL_NO"));
                        vo.setIsClosed(rs.getString("IS_CLOSED"));
                        vo.setLateCharge(MoneyUtil.formatMoney(rs.getString("LATE_CHARGE")));
                        vo.setLimitAmt(MoneyUtil.formatMoney(rs.getString("LIMIT_AMT")));
                        vo.setLoanType(rs.getString("LOAN_TYPE"));
                        vo.setMaturityDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("MATURITY_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("MATURITY_DATE")));
                        vo.setOdOverLimit(MoneyUtil.formatMoney(rs.getString("OD_OVER_LIMIT")));
                        vo.setOutstandingAmt(MoneyUtil.formatMoney(rs.getString("OUTSTANDING_AMT")));
                        vo.setPaidDate(rs.getString("PAID_DATE"));
                        vo.setPaidDate(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("PAID_DATE")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("PAID_DATE")));
                        vo.setProductGroup(rs.getString("PRODUCT_GROUP"));
                        vo.setProductType(rs.getString("PRODUCT_TYPE"));
                        vo.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
                        vo.setUnpaidAmt(MoneyUtil.formatMoney(rs.getString("UNPAID_AMT")));
                        vo.setUnpaidInterest(MoneyUtil.formatMoney(rs.getString("UNPAID_INTEREST")));
                        vo.setUnpaidPrincipal(MoneyUtil.formatMoney(rs.getString("UNPAID_PRINCIPAL")));
                        vo.setWarningHeadId(rs.getString("WARNING_HEAD_ID"));
                        vo.setWarningId(rs.getString("WARNING_ID"));
                    }catch(Exception e){
                        log.error(e);
                    }
                    
                    return vo;
                }
            });

        } catch (Exception e) {
            log.error(e);
        }finally{
            log.info("[getActionAccountList][End]");
        }
        return result;
    }
    
    @Override
    public void insert(ActionAccountVo actionAccountVo) throws Exception {
        log.info("[insert][Begin]");
        StringBuilder sql           = new StringBuilder();
        StringBuilder column        = new StringBuilder();
        StringBuilder columnValue   = new StringBuilder();
        List          valueArray    = new ArrayList();
        
        try{
            column.append("ACCOUNT_NO");
            columnValue.append("?");
            valueArray.add(actionAccountVo.getAccountNo());
            log.info("[insert] ACCOUNT_NO :: " + actionAccountVo.getAccountNo());
            
            column.append(", ACCOUNT_SUB_TYPE");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getAccountSubType());
            log.info("[insert] ACCOUNT_SUB_TYPE :: " + actionAccountVo.getAccountSubType());
            
            //ไม่ต้อง insert คอลัมน์  ACTION_FLG เพราะเดี๋ยวจะ drop คอลัมน์นี้ออก By พี่ออน 20160803
//            column.append(", ACTION_FLG");
//            columnValue.append(", ?");
//            valueArray.add(actionAccountVo.getActionFlg());
//            log.info("[insert] ACTION_FLG :: " + actionAccountVo.getActionFlg());
            
            column.append(", BILL_NO");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getBillNo());
            log.info("[insert] BILL_NO :: " + actionAccountVo.getBillNo());
            
            column.append(", C_FINAL");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getcFinal());
            log.info("[insert] C_FINAL :: " + actionAccountVo.getcFinal());
            
            column.append(", CREATED_BY");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getCreatedBy());
            log.info("[insert] CREATED_BY :: " + actionAccountVo.getCreatedBy());
            
            column.append(", CREATED_DT");
            columnValue.append(", CURRENT TIMESTAMP");
            
            column.append(", DPD");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getDpd());
            log.info("[insert] DPD :: " + actionAccountVo.getDpd());
            
            if(actionAccountVo.getDpdZeroDate()!=null && !actionAccountVo.getDpdZeroDate().equals("")){
                column.append(", DPD_ZERO_DATE");
                columnValue.append(", to_date(?, 'ddMMyyyy')");
                valueArray.add(DateUtil.convertThEnYearStr(actionAccountVo.getDpdZeroDate(), true));
                log.info("[insert] DPD_ZERO_DATE :: " + DateUtil.convertThEnYearStr(actionAccountVo.getDpdZeroDate(), true));
            }
            
            column.append(", DUE_AMT");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getDueAmt()));
            log.info("[insert] DUE_AMT :: " + MoneyUtil.convertDbFormat(actionAccountVo.getDueAmt()));
            
            if(actionAccountVo.getDueDate()!=null && !actionAccountVo.getDueDate().equals("")){
                column.append(", DUE_DATE");
                columnValue.append(", to_date(?, 'ddMMyyyy')");
                valueArray.add(DateUtil.convertThEnYearStr(actionAccountVo.getDueDate(), true));
                log.info("[insert] DUE_DATE :: " + DateUtil.convertThEnYearStr(actionAccountVo.getDueDate(), true));
            }
            
            column.append(", INPUT_ACCOUNT_NO");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getInputAccountNo());
            log.info("[insert] INPUT_ACCOUNT_NO :: " + actionAccountVo.getInputAccountNo());
            
            column.append(", INPUT_BILL_NO");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getInputBillNo());
            log.info("[insert] INPUT_BILL_NO :: " + actionAccountVo.getInputBillNo());
            
            column.append(", IS_CLOSED");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getIsClosed());
            log.info("[insert] IS_CLOSED :: " + actionAccountVo.getIsClosed());
            
            column.append(", LATE_CHARGE");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getLateCharge()));
            log.info("[insert] LATE_CHARGE :: " + MoneyUtil.convertDbFormat(actionAccountVo.getLateCharge()));
            
            column.append(", LIMIT_AMT");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getLimitAmt()));
            log.info("[insert] LIMIT_AMT :: " + MoneyUtil.convertDbFormat(actionAccountVo.getLimitAmt()));
            
            column.append(", LOAN_TYPE");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getLoanType());
            log.info("[insert] LOAN_TYPE :: " + actionAccountVo.getLoanType());
            
            if(actionAccountVo.getMaturityDate()!=null && !actionAccountVo.getMaturityDate().equals("")){
                column.append(", MATURITY_DATE");
                columnValue.append(", to_date(?, 'ddMMyyyy')");
                valueArray.add(DateUtil.convertThEnYearStr(actionAccountVo.getMaturityDate(), true));
                log.info("[insert] MATURITY_DATE :: " + DateUtil.convertThEnYearStr(actionAccountVo.getMaturityDate(), true));
            }
            
            column.append(", OD_OVER_LIMIT");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getOdOverLimit()));
            log.info("[insert] OD_OVER_LIMIT :: " + MoneyUtil.convertDbFormat(actionAccountVo.getOdOverLimit()));
            
            column.append(", OUTSTANDING_AMT");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getOutstandingAmt()));
            log.info("[insert] OUTSTANDING_AMT :: " + MoneyUtil.convertDbFormat(actionAccountVo.getOutstandingAmt()));
            
            if(actionAccountVo.getPaidDate()!=null && !actionAccountVo.getPaidDate().equals("")){
                column.append(", PAID_DATE");
                columnValue.append(", to_date(?, 'ddMMyyyy')");
                valueArray.add(DateUtil.convertThEnYearStr(actionAccountVo.getPaidDate(), true));
                log.info("[insert] PAID_DATE :: " + DateUtil.convertThEnYearStr(actionAccountVo.getPaidDate(), true));
            }
            
            column.append(", PRODUCT_GROUP");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getProductGroup());
            log.info("[insert] PRODUCT_GROUP :: " + actionAccountVo.getProductGroup());
            
            column.append(", PRODUCT_TYPE");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getProductType());
            log.info("[insert] PRODUCT_TYPE :: " + actionAccountVo.getProductType());
            
            column.append(", SOURCE_SYSTEM");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getSourceSystem());
            log.info("[insert] SOURCE_SYSTEM :: " + actionAccountVo.getSourceSystem());
            
            column.append(", UNPAID_AMT");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getUnpaidAmt()));
            log.info("[insert] UNPAID_AMT :: " + MoneyUtil.convertDbFormat(actionAccountVo.getUnpaidAmt()));
            
            column.append(", UNPAID_INTEREST");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getUnpaidInterest()));
            log.info("[insert] UNPAID_INTEREST :: " + MoneyUtil.convertDbFormat(actionAccountVo.getUnpaidInterest()));
            
            column.append(", UNPAID_PRINCIPAL");
            columnValue.append(", ?");
            valueArray.add(MoneyUtil.convertDbFormat(actionAccountVo.getUnpaidPrincipal()));
            log.info("[insert] UNPAID_PRINCIPAL :: " + MoneyUtil.convertDbFormat(actionAccountVo.getUnpaidPrincipal()));
            
            column.append(", UPDATED_BY");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getUpdatedBy());
            log.info("[insert] UPDATED_BY :: " + actionAccountVo.getUpdatedBy());
            
            column.append(", UPDATED_DT");
            columnValue.append(", CURRENT TIMESTAMP");
            
            column.append(", WARNING_HEAD_ID");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getWarningHeadId());
            log.info("[insert] WARNING_HEAD_ID :: " + actionAccountVo.getWarningHeadId());
            
            column.append(", WARNING_ID");
            columnValue.append(", ?");
            valueArray.add(actionAccountVo.getWarningId());
            log.info("[insert] WARNING_ID :: " + actionAccountVo.getWarningId());
            
            sql.append("insert into TBL_ACTION_ACCOUNT (").append(column.toString()).append(") values (").append(columnValue.toString()).append(")");
            jdbcTemplate.update(sql.toString(), valueArray.toArray());
        
        }catch(Exception e){
            throw e;
        }finally{
            log.info("[insert][End]");
        }
        
    }
    
    @Override
    public void updateActionFlag(ActionAccountVo actionAccountVo) throws Exception {
        log.info("[updateActionFlag][Begin]");
        
        StringBuilder   sql             = new StringBuilder();
        List            valueArray      = new ArrayList();
        
        try{
            
            sql.append("update TBL_ACTION_ACCOUNT ");
//            sql.append("    set ACTION_FLG = ?, UPDATED_BY = ?, UPDATED_DT = CURRENT TIMESTAMP");
            sql.append("    set UPDATED_BY = ?, UPDATED_DT = CURRENT TIMESTAMP");
            sql.append("    where ACCOUNT_NO        = ?");
            sql.append("        and BILL_NO         = ?");
            sql.append("        and WARNING_HEAD_ID = ?");
            sql.append("        and WARNING_ID      = ?");
            
//            valueArray.add(actionAccountVo.getActionFlg());
            valueArray.add(actionAccountVo.getUpdatedBy());
            valueArray.add(actionAccountVo.getAccountNo());
            valueArray.add(actionAccountVo.getBillNo());
            valueArray.add(actionAccountVo.getWarningHeadId());
            valueArray.add(actionAccountVo.getWarningId());
            
            jdbcTemplate.update(sql.toString(), valueArray.toArray());
        
        }catch(Exception e){
            throw e;
        }finally{
            log.info("[insert][End]");
        }
        
    }
    @Override
    public void deleteByWarningHeadIdAndWarningId(int warningHeadId, int warningId) throws Exception {
        log.info("[deleteByWarningHeadIdAndWarningId][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            log.info("[deleteByWarningHeadIdAndWarningId] warningHeadId  :: " + warningHeadId);
            log.info("[deleteByWarningHeadIdAndWarningId] warningId      :: " + warningId);
            
            sql.append("delete from TBL_ACTION_ACCOUNT where WARNING_HEAD_ID = ? AND WARNING_ID = ?");
        
            jdbcTemplate.update(sql.toString(), new Object[]{warningHeadId, warningId});
        }catch(Exception e){
            log.error(e);
            throw e;
        }finally{
            log.info("[deleteByWarningHeadIdAndWarningId][End]");
        }
    }
      
}
