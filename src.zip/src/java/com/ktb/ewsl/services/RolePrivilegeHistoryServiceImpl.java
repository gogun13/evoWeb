/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RolePrivilegeHistoryVo;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class RolePrivilegeHistoryServiceImpl implements RolePrivilegeHistoryService{
    
    private static Logger logger = Logger.getLogger(RolePrivilegeHistoryServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public int insertRolePrivilegeHistory(RolePrivilegeHistoryVo data) throws Exception {
        int result = 0;
         try {
            if (logger.isInfoEnabled()) {
                logger.info("RolePrivilegeHistoryServiceImpl.insertRolePrivilegeHistory");
            }
            
            StringBuilder sql = new StringBuilder();
            sql.append(" INSERT INTO TBL_MT_ROLE_PRIVILEGE_HISTORY(DATETIME, EMPLOYEE_ID, EMP_NAME, ROLE_CODE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, END_DATE, IS_ACTIVE, DEPT_CODE, DEPT_NAME)");
            sql.append("\n  VALUES( sysdate , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? ) ");
    
            result = jdbcTemplate.update(sql.toString(), new Object[]{ data.getEmployeeId() , data.getEmpName()
            ,data.getRoleCode(),data.getCreatedDate(),data.getCreatedBy() ,data.getUpdatedDate(),data.getUpdatedBy()
            ,data.getEndDate(),data.getIsActive(), data.getDeptCode(),data.getDeptName()});
             logger.info("RolePrivilegeHistoryServiceImpl.insertRolePrivilegeHistory result="+result);
        } catch (Exception e) {
            logger.error("Error occur in while process RolePrivilegeHistoryServiceImpl.insertRolePrivilegeHistory : " + e.getMessage(), e);
        }
      return result;
    }
}
