/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RolePrivilegeVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class RolePrivilegeServiceImpl implements RolePrivilegeService{
    
    private static Logger logger = Logger.getLogger(RolePrivilegeServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<RolePrivilegeVo> getEmployeeID(String roleCode) throws Exception {
      List<RolePrivilegeVo> result = null;
      try{
        if(logger.isInfoEnabled()){
              logger.info("RolePrivilegeServiceImpl.getEmployeeID");
         }
           
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT EMPLOYEE_ID , ROLE_CODE  FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append(" WHERE ROLE_CODE = '").append(roleCode).append("'");
        
         result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
                    public RolePrivilegeVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                        RolePrivilegeVo vo = new RolePrivilegeVo();
                        vo.setEmployeeId(rs.getString("EMPLOYEE_ID"));
                        vo.setRoleCode(rs.getString("ROLE_CODE"));
                        return vo;
                    }
                });
      }catch(Exception e){
          logger.error("Error occur in while process RolePrivilegeServiceImpl.getEmployeeID: " + e.getMessage() , e);
      }
      return result;
    }
    
    @Override
    public void updateInActiveUserRolePrivilege(String roldCode, String employeeId) throws Exception {
        try{
            if (logger.isInfoEnabled()) {
               logger.info("RolePrivilegeServiceImpl.updateActiveUserRolePrivilege");
           }

           StringBuilder sql = new StringBuilder();
           sql.append(" UPDATE  TBL_MT_ROLE_PRIVILEGE SET  IS_ACTIVE = 0, UPDATED_DT = CURRENT TIMESTAMP, UPDATED_BY = 'System' ");
           sql.append("\n WHERE EMPLOYEE_ID = ?  AND ROLE_CODE = ?  ");
          
           jdbcTemplate.update(sql.toString(), new Object[]{employeeId,roldCode});
        }catch(Exception e){
          logger.error("Error occur in while process RolePrivilegeServiceImpl.updateActiveUserRolePrivilege : " + e.getMessage() , e);
        }
    }

    @Override
    public RolePrivilegeVo getEmployeeIDByRoleCodeAndEmpNo(String roleCode, String employeeId) throws Exception {
      RolePrivilegeVo result = null;
      try{
        if(logger.isInfoEnabled()){
              logger.info("RolePrivilegeServiceImpl.getEmployeeIDByRoleCodeAndEmpNo");
         }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT EMPLOYEE_ID, ROLE_CODE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, END_DATE, IS_ACTIVE, DEPT_CODE, DEPT_NAME ");
        sql.append("\n FROM TBL_MT_ROLE_PRIVILEGE ");
        sql.append(" WHERE ROLE_CODE = '").append(roleCode).append("'  AND  EMPLOYEE_ID = '").append(employeeId).append("' ");
        
        logger.info("[getEmployeeIDByRoleCodeAndEmpNo] sql :: " + sql.toString());
        
         List<RolePrivilegeVo> resultList  = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
                    @Override
                    public RolePrivilegeVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                        RolePrivilegeVo vo = new RolePrivilegeVo();
                        vo.setEmployeeId(rs.getString("EMPLOYEE_ID"));
                        vo.setRoleCode(rs.getString("ROLE_CODE"));
                        vo.setCreatedDate(rs.getDate("CREATED_DT"));
                        vo.setCreatedBy(rs.getString("CREATED_BY"));
                        vo.setUpdatedDate(rs.getDate("UPDATED_DT"));
                        vo.setUpdatedBy(rs.getString("UPDATED_BY"));
                        vo.setEndDate(rs.getDate("END_DATE"));
                        vo.setIsActive(rs.getInt("IS_ACTIVE"));
                        vo.setDeptCode(rs.getInt("DEPT_CODE"));
                        vo.setDeptName(rs.getString("DEPT_NAME"));
                        return vo;
                    }
                });
         if(!resultList.isEmpty() && resultList.size() > 0){
              result =  resultList.get(0);
         }
      }catch(Exception e){
          logger.error("Error occur in while process RolePrivilegeServiceImpl.getEmployeeIDByRoleCodeAndEmpNo: " + e.getMessage() , e);
      }
      return result;
    }
    
    
}
