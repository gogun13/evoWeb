/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WSLogVO;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class WSLogServiceImpl implements WSLogService {

    private static final Logger log = Logger.getLogger(WSLogServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
      
    @Override
    public void insertLog(WSLogVO wsLogVO) throws Exception {
          try {
            if (log.isInfoEnabled()) {
                log.info("WSLogServiceImpl.insertLog");
                log.info(" wsLogVO.getChannelID() =" +wsLogVO.getChannelID() );
                log.info(" wsLogVO.getSystemID() =" + wsLogVO.getSystemID());
                log.info(" wsLogVO.getServiceID()=" +  wsLogVO.getServiceID());
                log.info(" wsLogVO.getRefID() =" + wsLogVO.getRefID());
                log.info(" wsLogVO.getTransType() =" + wsLogVO.getTransType());
                log.info(" wsLogVO.getDetail() =" + wsLogVO.getDetail());
                log.info(" wsLogVO.getRemark() =" + wsLogVO.getRemark());
            }
            
            StringBuilder sql = new StringBuilder();
            sql.append(" INSERT INTO TBL_WS_LOG(CHANNEL_ID, SYSTEM_ID, SERVICE_ID, REF_ID, TRANS_TYPE, DETAIL, REMARK ) ");
            sql.append(" \nVALUES(?, ?, ?, ?, ?, ?, ?) ");
    
            jdbcTemplate.update(sql.toString(), new Object[]{wsLogVO.getChannelID(),wsLogVO.getSystemID(), wsLogVO.getServiceID(), 
                wsLogVO.getRefID(), wsLogVO.getTransType(), wsLogVO.getDetail(),
                wsLogVO.getRemark()});
        } catch (Exception e) {
            log.error("Error occur in while process WSLogServiceImpl.insertLog : " + e.getMessage(), e);
            throw e;
        }
    }
    
}
