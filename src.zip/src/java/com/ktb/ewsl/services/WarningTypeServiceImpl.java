/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningCloseVo;
import com.ktb.ewsl.vo.WarningTypePrivilegeVo;
import com.ktb.ewsl.vo.WarningTypeVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Tum_Surapong
 */
@Repository
public class WarningTypeServiceImpl implements WarningTypeService {

    private static final Logger logger = Logger.getLogger(WarningTypeServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<WarningTypeVo> findWarningTypeByFilter(WarningTypeVo warningTypeVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningTypeByFilter");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_TYPE_CODE,WARNING_TYPE_DESC,QUESTION_ID,QUESTION_VERSION FROM TBL_WARNING_TYPE");
        sql.append("\nWHERE QUESTION_ID = ?");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningTypeVo> warningTypeVoList = null;
        try {
            warningTypeVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningTypeVo.getQuestionId()}, new BeanPropertyRowMapper<WarningTypeVo>(WarningTypeVo.class));
        } catch (Exception e) {
        }

        return warningTypeVoList;
    }

    @Override
    public List<WarningTypeVo> findWarningType() throws Exception {
        List<WarningTypeVo> result = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("AsstQuestionServiceImpl.findWarningType");
            }
            StringBuilder sql = new StringBuilder();

            sql.append("SELECT  WARNING_TYPE_CODE, QUESTION_ID , WARNING_TYPE_DESC,QUESTION_VERSION ,UPDATED_DT FROM TBL_WARNING_TYPE ORDER BY UPDATED_DT ASC");
            result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningTypeVo item = new WarningTypeVo();
                    item.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypeDesc(rs.getString("WARNING_TYPE_DESC"));
                    item.setQuestionId(rs.getString("QUESTION_ID"));
                    item.setQuestionVersion(rs.getString("QUESTION_VERSION"));
                    item.setUpdateDtSt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("UPDATED_DT")));
                    return item;
                }
            });
        } catch (Exception e) {
            logger.error("Error occur in while process WarningInfoServiceImpl.getTaskDetailList: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public void updateWarningType(WarningTypeVo warningTypeVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateWarningType");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("UPDATE TBL_WARNING_TYPE SET QUESTION_VERSION = ?, UPDATED_DT = ?, UPDATED_BY = ?");
        sql.append("\nWHERE QUESTION_ID = ?");
        jdbcTemplate.update(sql.toString(), new Object[]{warningTypeVo.getQuestionVersion(), warningTypeVo.getUpdatedDate(),
            warningTypeVo.getUpdatedBy(), warningTypeVo.getQuestionId()});
    }

    @Override
    public Integer findSLAByWarningType(String waringTypeCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("WarningTypeServiceImpl.findSLAByWarningType");
        }
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT  SLA  FROM TBL_WARNING_TYPE WHERE WARNING_TYPE_CODE = ? ");
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        return jdbcTemplate.queryForObject(sql.toString(), new Object[]{waringTypeCode}, Integer.class);
    }

    @Override
    public List<WarningTypeVo> findWarningTypeByUnderType(String underWarningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningTypeByUnderType");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_TYPE_CODE,WARNING_TYPE_DESC,QUESTION_ID,QUESTION_VERSION FROM TBL_WARNING_TYPE");
        sql.append("\n WHERE UNDER_WARNING_TYPE = ?");
        sql.append("\n ORDER BY WARNING_TYPE_CODE ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningTypeVo> warningTypeVoList = null;
        try {
            warningTypeVoList = jdbcTemplate.query(sql.toString(), new Object[]{underWarningType}, new BeanPropertyRowMapper<WarningTypeVo>(WarningTypeVo.class));
        } catch (Exception e) {
        }

        return warningTypeVoList;
    }

    @Override
    public List<WarningTypeVo> findWarningTypeByWarningType(String warningType) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findWarningTypeByWarningTypeType");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT WARNING_TYPE_CODE,WARNING_TYPE_DESC,QUESTION_ID,QUESTION_VERSION FROM TBL_WARNING_TYPE ");
        sql.append("\nWHERE WARNING_TYPE_CODE = ? ");

        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }

        List<WarningTypeVo> warningTypeVoList = null;
        try {
            warningTypeVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningType}, new BeanPropertyRowMapper<WarningTypeVo>(WarningTypeVo.class));
        } catch (Exception e) {
        }

        return warningTypeVoList;
    }

    @Override
    public ArrayList<WarningTypeVo> getColumnByPrivilege(String roleId, String warningTypeGroup) throws Exception {
         ArrayList<WarningTypeVo> result = null;
        try {
            if (logger.isInfoEnabled()) {
                logger.info("AsstQuestionServiceImpl.getColumnByPrivilege");
            }
            StringBuilder sql = new StringBuilder();

            sql.append(" SELECT P.ROLE_CODE, P.WARNING_TYPE_CODE , W.WARNING_TYPE_GROUP ,  W.WARNING_TYPE_DESC ,W.SEQ , W.SHORT_NAME ");
            sql.append("\n FROM TBL_WARNING_TYPE_PRIVILEGE P ");
            sql.append("\n LEFT JOIN TBL_WARNING_TYPE W ");
            sql.append("\n ON W.WARNING_TYPE_CODE  = P.WARNING_TYPE_CODE ");
            sql.append("\n WHERE P.ROLE_CODE = ? AND W.WARNING_TYPE_GROUP = ? ");
            sql.append("\n ORDER BY W.SEQ ASC ");
    
           
            result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{roleId,warningTypeGroup}, new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningTypeVo item = new WarningTypeVo();
                    item.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypeDesc(rs.getString("WARNING_TYPE_DESC"));
                    item.setWarningTypeGroup(rs.getString("WARNING_TYPE_GROUP"));
                    item.setSeq(rs.getInt("SEQ"));
                    item.setShortName(rs.getString("SHORT_NAME"));
                    WarningTypePrivilegeVo  warningTypePrivilegeVo = new WarningTypePrivilegeVo();
                    warningTypePrivilegeVo.setRoleCode(rs.getString("ROLE_CODE"));
                    warningTypePrivilegeVo.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypePrivilegeVo(warningTypePrivilegeVo);
                    return item;
                }
            });
        } catch (Exception e) {
            logger.error("Error occur in while process WarningInfoServiceImpl.getColumnByPrivilege: " + e.getMessage(), e);
        }
        return result;
    }

    @Override
    public ArrayList<WarningTypeVo> findWarningTypeUnderWarningTypeIsNull(WarningTypeVo warningTypeVo) throws Exception {
        logger.info("[findWarningTypeUnderWarningTypeIsNull][Begin]");
        
        StringBuilder               sql     = new StringBuilder();
        ArrayList<WarningTypeVo>    result  = new ArrayList<WarningTypeVo>();
        ArrayList<Object>           params  = new ArrayList<Object>();
        
        try{
            
            sql.append("SELECT * FROM TBL_WARNING_TYPE WHERE UNDER_WARNING_TYPE IS NULL");
            
            if(!ValidatorUtil.isNullOrEmpty(warningTypeVo.getWarningTypeCode())){
                sql.append(" AND WARNING_TYPE_CODE = ?");
                params.add(warningTypeVo.getWarningTypeCode());
            }
            
            if(!ValidatorUtil.isNullOrEmpty(warningTypeVo.getIsActive())){
                sql.append(" AND IS_ACTIVE = ?");
                params.add(warningTypeVo.getIsActive());
            }
            
            sql.append(" ORDER BY SLA_UPDATED_DT DESC");
            
            logger.info("[findWarningTypeUnderWarningTypeIsNull] sql :: " + sql.toString());
            
            result = (ArrayList) jdbcTemplate.query(sql.toString(), params.toArray(),new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningTypeVo item = new WarningTypeVo();
                    
                    item.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypeDesc(rs.getString("WARNING_TYPE_DESC"));
                    item.setSla(rs.getInt("SLA"));
                    item.setIsActive(rs.getString("IS_ACTIVE"));
                    item.setQuestionId(rs.getString("QUESTION_ID"));
                    item.setQuestionVersion(rs.getString("QUESTION_VERSION"));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setCreatedBy(rs.getString("CREATED_BY"));
                    item.setUpdatedDate(rs.getDate("SLA_UPDATED_DT"));
                    item.setUpdateDtSt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("SLA_UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("SLA_UPDATED_DT")));
                    item.setUpdatedBy(rs.getString("SLA_UPDATED_BY"));
                    item.setUnderWarningType(rs.getString("UNDER_WARNING_TYPE"));
                    item.setWarningTypeGroup(rs.getString("WARNING_TYPE_GROUP"));
                    item.setShortName(rs.getString("SHORT_NAME"));
                    item.setSeq(rs.getInt("SEQ"));
                    item.setAlertFirstWarningFlg(rs.getString("ALERT_FIRST_WARNING_FLG"));
                    item.setAlertType(rs.getString("ALERT_TYPE"));
                    item.setAlertValue(rs.getString("ALERT_VALUE"));
                    item.setExceedSlaAlertType(rs.getString("EXCEED_SLA_ALERT_TYPE"));
                    item.setExceedSlaAlertValue(rs.getString("EXCEED_SLA_ALERT_VALUE"));
                    item.setExceedSlaAlertLimit(rs.getString("EXCEED_SLA_ALERT_LIMIT"));
                    item.setAlertAtEndSlaFlg(rs.getString("ALERT_AT_END_SLA_FLG"));
                    
                    if("1".equals(rs.getString("IS_ACTIVE"))){
                        item.setIsActiveDesc("Active");
                    }else{
                        item.setIsActiveDesc("In Active");
                    }
                    
                    return item;
                }
            });

            
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[findWarningTypeUnderWarningTypeIsNull][End]");
        }
        
        return result;
    }
    
    @Override
    public void updateSlaByWarningTypeCode(int sla, String warningTypeCode,String updateBy) throws Exception {
        logger.info("[updateSlaByWarningTypeCode][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            sql.append("UPDATE TBL_WARNING_TYPE SET SLA = ?,SLA_UPDATED_BY = ?,SLA_UPDATED_DT = sysdate WHERE WARNING_TYPE_CODE = ?");
            
            jdbcTemplate.update(sql.toString(), new Object[]{sla,updateBy,warningTypeCode});
            
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[updateSlaByWarningTypeCode][End]");
        }
    }
    
    @Override
    public void updateSlaByUnderWarningTypeCode(int sla, String warningTypeCode,String updateBy) throws Exception {
        logger.info("[updateSlaByUnderWarningTypeCode][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            sql.append("UPDATE TBL_WARNING_TYPE SET SLA = ?,SLA_UPDATED_BY = ?,SLA_UPDATED_DT = sysdate WHERE UNDER_WARNING_TYPE = ?");
            
            jdbcTemplate.update(sql.toString(), new Object[]{sla,updateBy,warningTypeCode});
            
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[updateSlaByUnderWarningTypeCode][End]");
        }
    }
    
    @Override
    public WarningTypeVo getWarningTypeDetail(String warningTypeCode) throws Exception {
        logger.info("[getWarningTypeDetail][Begin]");
        
        StringBuilder               sql             = new StringBuilder();
        ArrayList<WarningTypeVo>    result          = new ArrayList<WarningTypeVo>();
        WarningTypeVo               warningTypeVo   = new WarningTypeVo();
        
        try{
            
            logger.info("[getWarningTypeDetail] warningTypeCode :: " + warningTypeCode);
            
            sql.append("SELECT * FROM TBL_WARNING_TYPE WHERE WARNING_TYPE_CODE = ?");
            
            result = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningTypeCode},new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningTypeVo item = new WarningTypeVo();
                    
                    item.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypeDesc(rs.getString("WARNING_TYPE_DESC"));
                    item.setSla(rs.getInt("SLA"));
                    item.setIsActive(rs.getString("IS_ACTIVE"));
                    item.setQuestionId(rs.getString("QUESTION_ID"));
                    item.setQuestionVersion(rs.getString("QUESTION_VERSION"));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setCreatedBy(rs.getString("CREATED_BY"));
                    item.setUpdatedDate(rs.getDate("SLA_UPDATED_DT"));
                    item.setUpdateDtSt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("SLA_UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("SLA_UPDATED_DT")));
                    item.setUpdatedBy(rs.getString("SLA_UPDATED_BY"));
                    item.setUnderWarningType(rs.getString("UNDER_WARNING_TYPE"));
                    item.setWarningTypeGroup(rs.getString("WARNING_TYPE_GROUP"));
                    item.setShortName(rs.getString("SHORT_NAME"));
                    item.setSeq(rs.getInt("SEQ"));
                    item.setAlertFirstWarningFlg(rs.getString("ALERT_FIRST_WARNING_FLG"));
                    item.setAlertType(rs.getString("ALERT_TYPE"));
                    item.setAlertValue(rs.getString("ALERT_VALUE"));
                    item.setExceedSlaAlertType(rs.getString("EXCEED_SLA_ALERT_TYPE"));
                    item.setExceedSlaAlertValue(rs.getString("EXCEED_SLA_ALERT_VALUE"));
                    item.setExceedSlaAlertLimit(rs.getString("EXCEED_SLA_ALERT_LIMIT"));
                    item.setAlertAtEndSlaFlg(rs.getString("ALERT_AT_END_SLA_FLG"));
                    
                    if("1".equals(rs.getString("IS_ACTIVE"))){
                        item.setIsActiveDesc("Active");
                    }else{
                        item.setIsActiveDesc("In Active");
                    }
                    
                    return item;
                }
            });
            
            if(result!=null && !result.isEmpty()){
                warningTypeVo = result.get(0);
            }
            
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[getWarningTypeDetail][End]");
        }
        
        return warningTypeVo;
    }
    
    @Override
    public void insertWarningTypeSlaHistory(WarningTypeVo warningTypeVo) throws Exception {
        logger.info("[insertWarningTypeSlaHistory][Begin]");
        
        StringBuilder               sql             = new StringBuilder();

        try {
            sql.append("INSERT INTO TBL_WARNING_TYPE_SLA_HISTORY ( WARNING_TYPE_CODE,WARNING_TYPE_DESC,SLA,IS_ACTIVE,QUESTION_ID,QUESTION_VERSION,CREATED_DT,CREATED_BY ) ");
            sql.append("\n VALUES(?,?,?,?,?,?,sysdate,?)");
            jdbcTemplate.update(sql.toString(), new Object[]{warningTypeVo.getWarningTypeCode(),warningTypeVo.getWarningTypeDesc(),warningTypeVo.getSla(),warningTypeVo.getIsActive(),warningTypeVo.getQuestionId(),warningTypeVo.getQuestionVersion(),warningTypeVo.getCreatedBy()});

        } catch (Exception e) {
            throw e;
        }finally{
            logger.info("[insertWarningTypeSlaHistory][End]");
        }
    }
    
    @Override
    public Integer countUnderWarningTypeCode(String warningTypeCode) throws Exception {
        logger.info("[countUnderWarningTypeCode][Begin]");
        
        StringBuilder   sql = new StringBuilder();
        Integer         result = 0;
        
        try{
            logger.info("[countUnderWarningTypeCode] warningTypeCode :: " + warningTypeCode);
            
            sql.append("SELECT COUNT(*) FROM TBL_WARNING_TYPE WHERE UNDER_WARNING_TYPE = ?");
            result  = jdbcTemplate.queryForObject(sql.toString(), new Object[]{warningTypeCode}, Integer.class);
            
            
            logger.info("[countUnderWarningTypeCode] result :: " + result);
            
            if(result==null)result = 0;
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[countUnderWarningTypeCode][End]");
        }

        return result;
    }
    
    @Override
    public ArrayList<WarningTypeVo> findWarningTypeForEwsl() throws Exception {
        logger.info("[findWarningTypeForEwsl][Begin]");
        
        StringBuilder               sql     = new StringBuilder();
        ArrayList<WarningTypeVo>    result  = new ArrayList<WarningTypeVo>();
        
        try{
            
            sql.append("SELECT * FROM TBL_WARNING_TYPE WHERE IS_ACTIVE = 1 AND QUESTION_ID IS NOT NULL");
            
            result = (ArrayList) jdbcTemplate.query(sql.toString(),new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningTypeVo item = new WarningTypeVo();
                    
                    item.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypeDesc(rs.getString("WARNING_TYPE_DESC"));
                    item.setSla(rs.getInt("SLA"));
                    item.setIsActive(rs.getString("IS_ACTIVE"));
                    item.setQuestionId(rs.getString("QUESTION_ID"));
                    item.setQuestionVersion(rs.getString("QUESTION_VERSION"));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setCreatedBy(rs.getString("CREATED_BY"));
                    item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                    item.setUpdateDtSt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("UPDATED_DT")));
                    item.setUpdatedBy(rs.getString("UPDATED_BY"));
                    item.setUnderWarningType(rs.getString("UNDER_WARNING_TYPE"));
                    item.setWarningTypeGroup(rs.getString("WARNING_TYPE_GROUP"));
                    item.setShortName(rs.getString("SHORT_NAME"));
                    item.setSeq(rs.getInt("SEQ"));
                    item.setAlertFirstWarningFlg(rs.getString("ALERT_FIRST_WARNING_FLG"));
                    item.setAlertType(rs.getString("ALERT_TYPE"));
                    item.setAlertValue(rs.getString("ALERT_VALUE"));
                    item.setExceedSlaAlertType(rs.getString("EXCEED_SLA_ALERT_TYPE"));
                    item.setExceedSlaAlertValue(rs.getString("EXCEED_SLA_ALERT_VALUE"));
                    item.setExceedSlaAlertLimit(rs.getString("EXCEED_SLA_ALERT_LIMIT"));
                    item.setAlertAtEndSlaFlg(rs.getString("ALERT_AT_END_SLA_FLG"));
                    
                    return item;
                }
            });

            
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[findWarningTypeForEwsl][End]");
        }
        
        return result;
    }
     @Override
    public ArrayList<WarningTypeVo> findWarningTypeForUnderWarningTypeEwsq() throws Exception {
        logger.info("[findWarningTypeForUnderWarningTypeEwsq][Begin]");
        
        StringBuilder               sql     = new StringBuilder();
        ArrayList<WarningTypeVo>    result  = new ArrayList<WarningTypeVo>();
        
        try{
            
            sql.append(" SELECT * FROM TBL_WARNING_TYPE  ");
            sql.append(" WHERE IS_ACTIVE = 1 AND UNDER_WARNING_TYPE = 'EWSQ'");
            sql.append(" ORDER BY WARNING_TYPE_CODE ASC ");
        
            result = (ArrayList) jdbcTemplate.query(sql.toString(),new RowMapper() {
                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    WarningTypeVo item = new WarningTypeVo();
                    
                    item.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                    item.setWarningTypeDesc(rs.getString("WARNING_TYPE_DESC"));
                    item.setSla(rs.getInt("SLA"));
                    item.setIsActive(rs.getString("IS_ACTIVE"));
                    item.setQuestionId(rs.getString("QUESTION_ID"));
                    item.setQuestionVersion(rs.getString("QUESTION_VERSION"));
                    item.setCreatedDate(rs.getDate("CREATED_DT"));
                    item.setCreatedBy(rs.getString("CREATED_BY"));
                    item.setUpdatedDate(rs.getDate("UPDATED_DT"));
                    item.setUpdateDtSt(ValidatorUtil.isNullOrEmpty(rs.getTimestamp("UPDATED_DT")) ? "" : DateUtil.getDateInThaiFormat(rs.getTimestamp("UPDATED_DT")));
                    item.setUpdatedBy(rs.getString("UPDATED_BY"));
                    item.setUnderWarningType(rs.getString("UNDER_WARNING_TYPE"));
                    item.setWarningTypeGroup(rs.getString("WARNING_TYPE_GROUP"));
                    item.setShortName(rs.getString("SHORT_NAME"));
                    item.setSeq(rs.getInt("SEQ"));
                    item.setAlertFirstWarningFlg(rs.getString("ALERT_FIRST_WARNING_FLG"));
                    item.setAlertType(rs.getString("ALERT_TYPE"));
                    item.setAlertValue(rs.getString("ALERT_VALUE"));
                    item.setExceedSlaAlertType(rs.getString("EXCEED_SLA_ALERT_TYPE"));
                    item.setExceedSlaAlertValue(rs.getString("EXCEED_SLA_ALERT_VALUE"));
                    item.setExceedSlaAlertLimit(rs.getString("EXCEED_SLA_ALERT_LIMIT"));
                    item.setAlertAtEndSlaFlg(rs.getString("ALERT_AT_END_SLA_FLG"));
                    
                    return item;
                }
            });

            
        }catch(Exception e){
            throw e;
        }finally{
            logger.info("[findWarningTypeForUnderWarningTypeEwsq][End]");
        }
        
        return result;
    }
}
