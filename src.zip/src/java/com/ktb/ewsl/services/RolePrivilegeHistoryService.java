/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.RolePrivilegeHistoryVo;

/**
 *
 * @author KTBDevLoan
 */
public interface RolePrivilegeHistoryService {
    
    
    public int insertRolePrivilegeHistory(RolePrivilegeHistoryVo rolePrivilegeHistoryVo) throws Exception;
}
