/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AsstAnswerVo;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.StringUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Tum_Surapong
 */
@Repository
public class AsstAnswerServiceImpl implements AsstAnswerService {

    private static final Logger logger = Logger.getLogger(AsstAnswerServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<AsstAnswerVo> findAsstAnswerByPK(AsstAnswerVo filter) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByPK");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CHOICE_ID,CHOICE_REASON");
        sql.append("\nFROM TBL_ASST_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUESTION_ID = ? AND VERSION = ? AND TOPIC_ID = ? AND SUB_TOPIC_ID = ? AND ROLE_CODE = ?");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningId(), filter.getQuestionId(), filter.getVersion(), filter.getTopicId(), filter.getSubTopicId(), filter.getRole()}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public void saveQuestion(AsstAnswerVo asstAnswerVo) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("saveQuestion");
        }
        try{

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO TBL_ASST_ANSWER (WARNING_ID,QUESTION_ID,VERSION,TOPIC_ID,SUB_TOPIC_ID,CHOICE_ID,CHOICE_REASON,ROLE_CODE,CREATED_DT,CREATED_BY,UPDATED_DT,UPDATED_BY,WARNING_HEAD_ID)");
        sql.append("\nVALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
        jdbcTemplate.update(sql.toString(), new Object[]{asstAnswerVo.getWarningId(), asstAnswerVo.getQuestionId(), asstAnswerVo.getVersion(),
            asstAnswerVo.getTopicId(), asstAnswerVo.getSubTopicId(), asstAnswerVo.getChoiceId(), asstAnswerVo.getChoiceReason(), asstAnswerVo.getRole(),
            asstAnswerVo.getCreatedDate(), asstAnswerVo.getCreatedBy(), asstAnswerVo.getUpdatedDate(), asstAnswerVo.getUpdatedBy(), asstAnswerVo.getWarningHeaderId()}); 
        }catch(Exception ex ){
             ex.printStackTrace();
        }
    }

    @Override
    public void updateQuestion(AsstAnswerVo asstAnswerVo,List<String> roleList) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("updateQuestion");
        }

        StringBuilder       sql         = new StringBuilder();
        ArrayList<Object>   params      = new ArrayList<Object>();
        String              roleId      = "";
        
        sql.append("UPDATE TBL_ASST_ANSWER");
        sql.append("\n  SET CHOICE_ID       = ?");
        sql.append("\n      , CHOICE_REASON = ?");
        sql.append("\n      , UPDATED_DT    = ?");
        sql.append("\n      , UPDATED_BY    = ? ");
        sql.append("\n      , ROLE_CODE     = ? "); 
        sql.append("\n  WHERE WARNING_ID        = ?");
        sql.append("\n      AND QUESTION_ID     = ?");
        sql.append("\n      AND VERSION         = ?");
        sql.append("\n      AND TOPIC_ID        = ?");
        sql.append("\n      AND SUB_TOPIC_ID    = ?");
        
        params.add(asstAnswerVo.getChoiceId());
        params.add(asstAnswerVo.getChoiceReason());
        params.add(asstAnswerVo.getUpdatedDate());
        params.add(asstAnswerVo.getUpdatedBy());
        params.add(asstAnswerVo.getRole());
        params.add(asstAnswerVo.getWarningId());
        params.add(asstAnswerVo.getQuestionId());
        params.add(asstAnswerVo.getVersion());
        params.add(asstAnswerVo.getTopicId());
        params.add(asstAnswerVo.getSubTopicId());
        
        if(roleList!=null && !roleList.isEmpty()){
            for(String role:roleList){
                if("".equals(roleId)){
                    roleId += "?";
                }else{
                    roleId += ",?";
                }
                params.add(role);
            }
            
            sql.append("\n      AND ROLE_CODE    in (").append(roleId).append(")");
        }
        
        
        jdbcTemplate.update(sql.toString(), params.toArray());
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerByWarningIdAndQuestId(int warningId, String questionId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByWarningIdAndQuestId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CHOICE_ID, VERSION");
        sql.append("\nFROM TBL_ASST_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUESTION_ID = ?");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, questionId}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerForGenTrigger(int warningId, String version) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerForGenTrigger");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstAnswer.TOPIC_ID,asstAnswer.SUB_TOPIC_ID,asstAnswer.CHOICE_ID FROM TBL_ASST_ANSWER asstAnswer");
        sql.append("\nWHERE asstAnswer.WARNING_ID = ? AND asstAnswer.VERSION = ?");
        sql.append("\nORDER BY asstAnswer.TOPIC_ID,asstAnswer.SUB_TOPIC_ID");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, version}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerForSendData(AsstAnswerVo filter) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerForSendData");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT TOPIC_ID,SUB_TOPIC_ID,CHOICE_ID,CHOICE_REASON");
        sql.append("\nFROM TBL_ASST_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUESTION_ID = ? AND VERSION = ? AND ROLE_CODE = ?");
        sql.append("\nORDER BY TOPIC_ID,SUB_TOPIC_ID");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningId(), filter.getQuestionId(), filter.getVersion(), filter.getRole()}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }
    
    @Override
    public List<AsstAnswerVo> findAsstAnswerForSendDataByRole(AsstAnswerVo filter , String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerForSendData");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT TOPIC_ID,SUB_TOPIC_ID,CHOICE_ID,CHOICE_REASON");
        sql.append("\nFROM TBL_ASST_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUESTION_ID = ? AND VERSION = ? AND ROLE_CODE IN ( ").append(roleCode).append(" )");
        sql.append("\nORDER BY TOPIC_ID,SUB_TOPIC_ID");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningId(), filter.getQuestionId(), filter.getVersion()}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerByRole(String role, String version, int warningId, String questionId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByRole");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT TOPIC_ID,SUB_TOPIC_ID,CHOICE_ID,CHOICE_REASON,REMARK");
        sql.append("\nFROM TBL_ASST_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUESTION_ID = ? AND VERSION = ? AND ROLE_CODE = ?");
        sql.append("\nORDER BY TOPIC_ID,SUB_TOPIC_ID");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, questionId, version, role}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerByWarningId(int warningId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByWarningId");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstAnswer.TOPIC_ID,asstAnswer.SUB_TOPIC_ID,asstAnswer.CHOICE_ID,asstAnswer.VERSION FROM TBL_ASST_ANSWER asstAnswer");
        sql.append("\nWHERE asstAnswer.WARNING_ID = ?");
        sql.append("\nORDER BY asstAnswer.CREATED_DT DESC");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }
    
    @Override
    public List<AsstAnswerVo> findAnswerByWarningIdInCurrentDate(int warningId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAnswerByWarningIdInCurrentDate");
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT asstAnswer.TOPIC_ID,asstAnswer.SUB_TOPIC_ID,asstAnswer.CHOICE_ID,asstAnswer.VERSION FROM TBL_ASST_ANSWER asstAnswer");
        sql.append("\nWHERE asstAnswer.WARNING_ID = ?");
        sql.append("\nAND DATE(asstAnswer.CREATED_DT) = DATE(CURRENT_DATE)");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public String getLastVersionAnswerOfWarningId(int warningId) throws Exception {
        String result = null;
            if (logger.isInfoEnabled()) {
            logger.info("getLastVersionAnswerOfWarningId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT  VERSION  FROM TBL_ASST_ANSWER ");
        sql.append(" WHERE WARNING_ID = ?  ");
        sql.append(" GROUP BY VERSION  ");
        sql.append(" ORDER BY VERSION DESC ");
         
        if (logger.isDebugEnabled()) {
            logger.debug("SQL >>> " + sql.toString());
        }
            ArrayList resultList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningId}, new RowMapper() {
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return StringUtil.getValue(rs.getString("VERSION"));
                }
            });
        
            if(!resultList.isEmpty()){
                result = (String)resultList.get(0);
            }
        return result;
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswer(int warningId, String questionId, String questionVersion) throws Exception {
          if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswer");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, QUESTION_ID, VERSION, TOPIC_ID, SUB_TOPIC_ID, CHOICE_ID,");
        sql.append("\n CHOICE_REASON, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ROLE_CODE, REMARK  ");
        sql.append("\n FROM TBL_ASST_ANSWER");
        sql.append("\n WHERE WARNING_ID = ? AND QUESTION_ID = ?  AND VERSION = ?  ");
        sql.append("\n ORDER BY TOPIC_ID,SUB_TOPIC_ID ");
        
        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, questionId, questionVersion}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));
        return asstAnswerVoList;
    }

    @Override
    public String findAnswerVersionByWarningIdAndQuestionId(int warningId, String questionId) throws Exception {
        String result = null;
        if (logger.isInfoEnabled()) {
            logger.info("findAnswerVersionByWarningIdAndQuestionId");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT MAX(VERSION) AS version FROM TBL_ASST_ANSWER  ");
        sql.append(" \nWHERE WARNING_ID = ? ");
        sql.append(" \nAND QUESTION_ID = ? ");
        sql.append(" \nGROUP BY VERSION ");

        ArrayList resultList = (ArrayList) jdbcTemplate.query(sql.toString(), new Object[]{warningId,questionId}, new RowMapper() {
             public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                 return StringUtil.getValue(rs.getString("version"));
             }
         });

         if(!resultList.isEmpty()){
             result = (String)resultList.get(0);
         }
       return result ;
    }

    @Override
    public void deleteAnswerByWarningId(String warningIdAll) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteAnswerByWarningId");
        }
        if(!ValidatorUtil.isNullOrEmpty(warningIdAll)){
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM TBL_ASST_ANSWER  WHERE WARNING_ID IN  (").append(warningIdAll).append(" ) ");
            jdbcTemplate.update(sql.toString());
        }
    }

    @Override
    public void deleteAnswerByWarningIdAndRoleCode(String warningIdAll,String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteAnswerByWarningIdAndRoleCode");
        }
        if(!ValidatorUtil.isNullOrEmpty(warningIdAll) && !ValidatorUtil.isNullOrEmpty(roleCode)){
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM TBL_ASST_ANSWER  WHERE WARNING_ID IN  (").append(warningIdAll).append(" ) AND ROLE_CODE IN ( ").append(roleCode).append(" )");
            jdbcTemplate.update(sql.toString());
        }
    }
     
    @Override
    public void deleteAnswerByPK(AsstAnswerVo filter, String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteAnswerByWarningId");
            logger.info("getWarningId = " + filter.getWarningId());
            logger.info("getQuestionId = "+ filter.getQuestionId());
            logger.info("getVersion = "+ filter.getVersion());
            logger.info("getTopicId = "+ filter.getTopicId());
            logger.info("getSubTopicId = "+ filter.getSubTopicId());
            logger.info("getRoleCode = " + filter.getRoleCode());
        }
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE TBL_ASST_ANSWER ");
            sql.append("\n WHERE WARNING_ID  = ").append(filter.getWarningId()).append("  ");
            sql.append("\n AND QUESTION_ID  = '").append(filter.getQuestionId()).append("'  ");
            sql.append("\n AND VERSION  = '").append(filter.getVersion()).append("'  ");
            sql.append("\n AND TOPIC_ID  = ").append(filter.getTopicId()).append("  ");
            sql.append("\n AND SUB_TOPIC_ID  = ").append(filter.getSubTopicId()).append("  ");
            sql.append("\n AND ROLE_CODE   IN ( ").append(roleCode).append(" )");
            jdbcTemplate.update(sql.toString());
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerByPKAndManyRole(AsstAnswerVo filter, String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByPKAndManyRole");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CHOICE_ID,CHOICE_REASON");
        sql.append("\nFROM TBL_ASST_ANSWER");
        sql.append("\nWHERE WARNING_ID = ? AND QUESTION_ID = ? AND VERSION = ? AND TOPIC_ID = ? AND SUB_TOPIC_ID = ? AND ROLE_CODE IN ( ").append(roleCode).append(" )");

        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningId(), filter.getQuestionId(), filter.getVersion(), filter.getTopicId(), filter.getSubTopicId()}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));
        return asstAnswerVoList;
    }
    
    
    @Override
    public List<AsstAnswerVo> findAsstAnswerByHeaderIdForTrigger(AsstAnswerVo filter , String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByHeaderIdForTrigger");
            logger.info(" getWarningId : " + filter.getWarningId());
        }
        StringBuilder sql = new StringBuilder();
        //-------- 04/05/2017 : R1.3 -----------//
        sql.append(" SELECT I.WARNING_ID FROM TBL_WARNING_INFO I  ");
   //   sql.append("\n LEFT JOIN ( "); 26/07/2017
        sql.append("\n INNER JOIN ( ");
        sql.append("\n  SELECT WARNING_ID   ");
        sql.append("\n         FROM TBL_ASST_ANSWER   ");
        sql.append("\n        WHERE WARNING_HEAD_ID = ?  AND ROLE_CODE IN  ( ").append(roleCode).append(" ) ");
        sql.append("\n        AND QUESTION_ID IN  (SELECT QUESTION_ID FROM TBL_WARNING_TYPE   ");
        sql.append("\n        WHERE UNDER_WARNING_TYPE =  ? )   ");
        sql.append("\n        GROUP BY WARNING_ID   ");
        sql.append("\n       ) ANS ");
        sql.append("\n ON I.WARNING_ID = ANS.WARNING_ID     ");
        sql.append("\n WHERE I.QUALI_WARNING_ID =  ?  ");
        sql.append("\n ORDER BY WARNING_ID ASC ");
         
        logger.debug(" SQL : " + sql.toString());
        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningHeaderId(), BusinessConst.WarningTypeCode.EWSQ , filter.getWarningId()}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }

    @Override
    public void deleteAnswerByHeaderIdAndRoleCode(int warningHeaderId, String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteAnswerByHeaderIdAndRoleCode  warningHeaderId = " +warningHeaderId + " : roleCode=" + roleCode);
        }
        if(warningHeaderId != 0 && !ValidatorUtil.isNullOrEmpty(roleCode)){
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM TBL_ASST_ANSWER  WHERE WARNING_HEAD_ID = ").append(warningHeaderId).append(" AND ROLE_CODE IN ( ").append(roleCode).append(" ) ");
            jdbcTemplate.update(sql.toString());
        }
    }

    @Override
    public List<AsstAnswerVo> findAsstAnswerByHeaderIdForSendBackQuali(AsstAnswerVo filter, String roleCode) throws Exception {
       if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByHeaderId");
        }
        StringBuilder sql = new StringBuilder();
         sql.append(" SELECT I.WARNING_ID FROM TBL_WARNING_INFO I  ");
         sql.append("\n INNER JOIN ( ");
         sql.append("\n  SELECT WARNING_ID   ");
         sql.append("\n         FROM TBL_ASST_ANSWER   ");
         sql.append("\n        WHERE WARNING_HEAD_ID = ?  AND ROLE_CODE IN ( ").append(roleCode).append(" )   ");
         sql.append("\n        AND QUESTION_ID IN  (SELECT QUESTION_ID FROM TBL_WARNING_TYPE   ");
         sql.append("\n        WHERE UNDER_WARNING_TYPE = ? )   ");
         sql.append("\n        GROUP BY WARNING_ID   ");
         sql.append("\n        ) ANS ");
         sql.append("\n ON I.WARNING_ID = ANS.WARNING_ID     ");
         sql.append("\n WHERE I.QUALI_WARNING_ID = ? ");
         sql.append("\n ORDER BY WARNING_ID ASC  ");
         
        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{filter.getWarningHeaderId(),BusinessConst.WarningTypeCode.EWSQ, filter.getWarningId()}, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));

        return asstAnswerVoList;
    }
    
    
    @Override
    public List<AsstAnswerVo> findAsstAnswerByWarningIdAndRoleCode(int warningId, String roleCode) throws Exception {
          if (logger.isInfoEnabled()) {
            logger.info("findAsstAnswerByWarningIdAndRoleCode");
        }
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT WARNING_ID, QUESTION_ID, VERSION, TOPIC_ID, SUB_TOPIC_ID, CHOICE_ID,");
        sql.append("\n CHOICE_REASON, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY, ROLE_CODE ,WARNING_HEAD_ID ");
        sql.append("\n FROM TBL_ASST_ANSWER");
        sql.append("\n WHERE WARNING_ID = ? AND ROLE_CODE IN ( ").append(roleCode).append(" ) ");
        sql.append("\n ORDER BY TOPIC_ID,SUB_TOPIC_ID ");
        
        List<AsstAnswerVo> asstAnswerVoList = jdbcTemplate.query(sql.toString(), new Object[]{warningId, }, new BeanPropertyRowMapper<AsstAnswerVo>(AsstAnswerVo.class));
        return asstAnswerVoList;
    }
    
    @Override
    public void deleteAnswerByWarningIdAndWarningheadId(String warningHeadId, String warningId) throws Exception {
        logger.info("[deleteAnswerByWarningIdAndWarningheadId][Begin]");
        
        StringBuilder sql = new StringBuilder();
        
        try{
            logger.info("[deleteAnswerByWarningIdAndWarningheadId] warningHeadId :: " + warningHeadId);
            logger.info("[deleteAnswerByWarningIdAndWarningheadId] warningId     :: " + warningId);
            
            sql.append("delete from TBL_ASST_ANSWER where WARNING_HEAD_ID = ? AND WARNING_ID = ?");
            jdbcTemplate.update(sql.toString(), new Object[]{warningHeadId, warningId});
            
        }catch(Exception e){
            logger.error(e);
            throw e;
        }finally{
            logger.info("[deleteAnswerByWarningIdAndWarningheadId][End]");
        }
    }

    //Before Approve Delete Answer not used (DRAFT , BEFROE BCM edit answer)
    @Override
    public void deleteAnswerQualiByWarningIdAndOtherRoleCode(int warningIdQuali, String roleCode) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("deleteAnswerQualiByWarningIdAndOtherRoleCode");
        }
        if(!ValidatorUtil.isNullOrEmpty(warningIdQuali) && !ValidatorUtil.isNullOrEmpty(roleCode)){
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM TBL_ASST_ANSWER  WHERE WARNING_ID = ").append(warningIdQuali).append(" AND ROLE_CODE NOT IN ( '").append(roleCode).append("' ) ");
            logger.info("SQL = " + sql.toString());
            
            jdbcTemplate.update(sql.toString());
        }
    }
   
}
