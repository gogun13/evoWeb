/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WebSqlVo;
import com.ktbcs.core.services.AbstractJdbcService;
import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.StringUtil;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class WebSqlServiceImpl extends AbstractJdbcService implements WebSqlService{
    
    private static final Logger log = Logger.getLogger(WebSqlServiceImpl.class);
    
    @Override
    public WebSqlVo run(String sqlString) throws Exception {
        ResultSet rs = null;
        PreparedStatement ps = null;
        int rowResult = 0;
        WebSqlVo webSqlVo = new WebSqlVo();
        try {
            
            if (log.isDebugEnabled()) {
                log.debug("sqlString SQL : " + sqlString);
            }
            
            //If perform call StoreProcedure
            if (StringUtil.isNotEmpty(sqlString) && sqlString.trim().toLowerCase().startsWith("execute")) {
                sqlString = sqlString.replace("execute", "call");
                if (log.isDebugEnabled()) {
                    log.debug("call procedure statement:" + sqlString);
                }
                
                CallableStatement cs =  jdbcTemplate.getDataSource().getConnection().prepareCall("{" + sqlString + "}");
                webSqlVo.setFlag(BusinessConst.SQLType.PROCEDURE);
                cs.execute();
            } else {
                //Perform ExecuteQuery or ExecuteUpdate
                //Check SQL command Type
                ps = jdbcTemplate.getDataSource().getConnection().prepareStatement(sqlString);
                if (StringUtil.isNotEmpty(sqlString) && sqlString.trim().toLowerCase().startsWith("select")) {
                    rs = ps.executeQuery();
                    rowResult = rs.getRow();
                    webSqlVo.setFlag(BusinessConst.SQLType.SELECT);
                } else if (StringUtil.isNotEmpty(sqlString) && sqlString.trim().toLowerCase().startsWith("update")) {
                    rowResult = ps.executeUpdate();
                    webSqlVo.setFlag(BusinessConst.SQLType.UPDATE);
                } else {
                    rowResult = ps.executeUpdate();
                    webSqlVo.setFlag(BusinessConst.SQLType.UPDATE);
                }
            }
            webSqlVo.setReturnRows(rowResult);

            
            //System.out.println("rowResult :"+rowResult);
            //if rs is not null then get result
            if (rs != null) {
                //Set All column name
                ArrayList columnNames = new ArrayList();
                ArrayList resultList = new ArrayList();
                ResultSetMetaData md = rs.getMetaData();
                int count = md.getColumnCount();
                for (int i = 1; i <= count; i++) {
                    columnNames.add(md.getColumnName(i));
                }
                webSqlVo.setColumnNames(columnNames);
                
                while (rs.next()) {
                    HashMap map = new HashMap();
                    //List list = new ArrayList();
                    for (int i = 1; i <= count; i++) {
                        map.put(columnNames.get(i-1), StringUtil.notNull(rs.getString(i)));
                    }
                    resultList.add(map);
                    map=null;
                }
                webSqlVo.setRowList(resultList);
            }

        } catch (SQLException ex) {
            log.error("SQL Error:" + ex.getMessage());
            throw ex;
        } finally {
                if (rs != null) { rs.close();}
                if (ps != null) { ps.close();}
        }

        return webSqlVo;
     }
    
}
