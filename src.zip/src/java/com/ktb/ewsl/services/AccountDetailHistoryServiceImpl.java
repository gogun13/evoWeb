/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.AccountDetailVo;
import com.ktbcs.core.utilities.DateUtil;
import com.ktbcs.core.utilities.ValidatorUtil;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Thanakorn Ch.
 */
@Repository
public class AccountDetailHistoryServiceImpl implements AccountDetailHistoryService {

    private static final Logger log = Logger.getLogger(AccountDetailHistoryServiceImpl.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<AccountDetailVo> findDataByCifForTodayMovement(Integer cif) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataByCifForTodayMovement");
        }
        StringBuilder sql = new StringBuilder();

//        sql.append(" SELECT AD1.ACCOUNT_NO,AD1.BILL_NO,AD1.LIMIT_AMT AS LIMITAMT,AD1.LIMIT_AMT AS MAINLIMITAMT");
//        sql.append(" ,AD1.OUTSTANDING_AMT AS OUTSTANDINGAMT,AD1.OUTSTANDING_AMT AS MAINOUTSTANDINGAMT \n");
//        sql.append(" ,AD1.MATURITY_DATE,AD1.DUE_DATE,AD1.DPD,AD1.DUE_AMT,AD1.UNPAID_AMT, AD1.UNPAID_INTEREST, AD1.UNPAID_PRINCIPAL, AD1.LATE_CHARGE \n");
//        sql.append(" ,AD1.ACCOUNT_SUB_TYPE ACCTSUBTYPE, AD1.PRODUCT_GROUP PRODGRP, AD1.PRODUCT_TYPE PRODTYPE, AD1.LOAN_TYPE MARKETCD \n");
//        sql.append(" FROM TBL_RPT_INDIVIDUAL_ACCOUNT  AD1 \n");
//        sql.append("JOIN ( \n");
//        sql.append(" SELECT CIF ,ACCOUNT_NO , BILL_NO FROM    TBL_RPT_INDIVIDUAL_ACCOUNT \n");
//        sql.append("WHERE ( DPD > 0 OR LATE_CHARGE > 0 ) AND  DPD_ZERO_DATE IS NULL AND PAID_DATE IS NULL \n");
//        sql.append("AND CIF =? GROUP BY  CIF ,ACCOUNT_NO , BILL_NO ) AD \n");
//        sql.append("ON AD1.CIF = AD.CIF  \n");
//        sql.append("AND AD1.ACCOUNT_NO = AD.ACCOUNT_NO  \n");
//        sql.append("AND  AD1.BILL_NO = AD.BILL_NO \n");
//        sql.append("ORDER BY AD1.DUE_DATE DESC \n");

        sql.append(" SELECT AD1.PAID_DATE,AD1.DPD_ZERO_DATE, AD1.ACCOUNT_NO,AD1.BILL_NO,AD1.LIMIT_AMT AS LIMITAMT,AD1.LIMIT_AMT AS MAINLIMITAMT ");
        sql.append("\n  ,AD1.OUTSTANDING_AMT AS OUTSTANDINGAMT,AD1.OUTSTANDING_AMT AS MAINOUTSTANDINGAMT ");
        sql.append("\n ,AD1.MATURITY_DATE,AD1.DUE_DATE,AD1.DPD,AD1.DUE_AMT,AD1.UNPAID_AMT, AD1.UNPAID_INTEREST, AD1.UNPAID_PRINCIPAL, AD1.LATE_CHARGE ");
        sql.append("\n ,AD1.ACCOUNT_SUB_TYPE ACCTSUBTYPE, AD1.PRODUCT_GROUP PRODGRP, AD1.PRODUCT_TYPE PRODTYPE, AD1.LOAN_TYPE MARKETCD ");
        sql.append("\n FROM TBL_RPT_INDIVIDUAL_ACCOUNT  AD1  ");
        sql.append("\n  WHERE CIF = ? ");
        sql.append("\n  AND ( DPD > 0 OR LATE_CHARGE > 0 )  ");
        sql.append("\n  AND  DPD_ZERO_DATE IS NULL AND PAID_DATE IS NULL ");
        sql.append("\n ORDER BY AD1.DUE_DATE DESC ");
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        List<AccountDetailVo> accountDetailVoList = jdbcTemplate.query(sql.toString(), new Object[]{cif}, new BeanPropertyRowMapper<AccountDetailVo>(AccountDetailVo.class));
        return accountDetailVoList;

    }

    @Override
    public List<AccountDetailVo> findDataByCifAndCloseJob(Integer cif) throws Exception {
        if (log.isInfoEnabled()) {
            log.info("findDataByCifAndCloseJob");
        }
        String startDt = DateUtil.getFirstMonthPeriousOneYear(); //--- 20/11/2015 By ANN Coz,mail P'Oon Track Record 16/11/2015
        String endDt = DateUtil.getLastDayOfMonth();  //--- 20/11/2015 By ANN Coz,mail P'Oon Track Record 16/11/2015
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT CIF,ACCOUNT_NO,BILL_NO,LIMIT_AMT AS LIMITAMT,LIMIT_AMT AS MAINLIMITAMT  \n");
        sql.append(",OUTSTANDING_AMT AS OUTSTANDINGAMT,OUTSTANDING_AMT AS MAINOUTSTANDINGAMT  \n");
        sql.append(" ,MATURITY_DATE,DUE_DATE,PAID_DATE AS PAIDDATE,DPD,DUE_AMT,UNPAID_AMT,DPD AS LAST_DPD, UNPAID_INTEREST, UNPAID_PRINCIPAL, LATE_CHARGE  \n");
        sql.append(",ACCOUNT_SUB_TYPE ACCTSUBTYPE, PRODUCT_GROUP PRODGRP, PRODUCT_TYPE PRODTYPE, LOAN_TYPE MARKETCD  \n");
        sql.append(" FROM TBL_RPT_INDIVIDUAL_ACCOUNT WHERE CIF = ? AND ( DPD > 0 OR LATE_CHARGE > 0 ) AND ( DPD_ZERO_DATE IS NOT NULL  OR PAID_DATE IS NOT NULL ) \n");
         //--- 20/11/2015 By ANN Coz,mail P'Oon Track Record 16/11/2015 --//
            if((!ValidatorUtil.isNullOrEmpty(startDt))&&(!ValidatorUtil.isNullOrEmpty(endDt))){
                  sql.append("  AND ( DUE_DATE BETWEEN TO_DATE('").append(startDt).append("','DD/MM/YYYY') AND TO_DATE('").append(endDt).append("','DD/MM/YYYY')) ");
            }
         //------------   
        sql.append(" ORDER BY DUE_DATE ,ACCOUNT_NO ,BILL_NO  ");

        
        if (log.isDebugEnabled()) {
            log.debug("SQL >>> " + sql.toString());
        }

        List<AccountDetailVo> accountDetailVoList = jdbcTemplate.query(sql.toString(), new Object[]{cif}, new BeanPropertyRowMapper<AccountDetailVo>(AccountDetailVo.class));
        return accountDetailVoList;
    }
}
