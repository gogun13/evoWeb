/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.HolidayVo;
import com.ktbcs.core.utilities.DateUtil;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class HolidayServiceImpl implements HolidayService{
     private static Logger log = Logger.getLogger(HolidayServiceImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<HolidayVo> getHoliday() throws Exception {
        
      List<HolidayVo> result = null;
      try{
        if(log.isInfoEnabled()){
              log.info("HolidayServiceImpl.getHoliday");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("   SELECT HOLIDAY_DATE, HOLIDAY_YEAR ");
        sql.append("   FROM TBL_MT_HOLIDAY  ");

         result = jdbcTemplate.query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<HolidayVo>(HolidayVo.class));
         
      }catch(Exception e){
          log.error("Error occur in while process HolidayServiceImpl.getHoliday : " + e.getMessage() , e);
          throw e;
      }
      return result;
    }
    
    @Override
    public List<HolidayVo> getHolidayForThisYear() throws Exception {
        
      List<HolidayVo> result = null;
      try{
        if(log.isInfoEnabled()){
              log.info("HolidayServiceImpl.getHolidayForThisYear");
        }
        StringBuilder sql = new StringBuilder();
        sql.append("   SELECT HOLIDAY_DATE, HOLIDAY_YEAR ");
        sql.append("   FROM TBL_MT_HOLIDAY where holiday_year = YEAR(CURRENT TIMESTAMP) ");

         result = jdbcTemplate.query(sql.toString(), new Object[]{}, new BeanPropertyRowMapper<HolidayVo>(HolidayVo.class));
         
      }catch(Exception e){
          log.error("Error occur in while process HolidayServiceImpl.getHolidayForThisYear : " + e.getMessage() , e);
          throw e;
      }
      return result;
    }
    
    @Override
    public Date getHolidayByDate(Date date) throws Exception {
        
      List<HolidayVo>   result          = null;
      Date              holidayDate     = null;
      
      
      try{
        if(log.isInfoEnabled()){
              log.info("HolidayServiceImpl.getHolidayByDate");
              log.info("HolidayServiceImpl.getHolidayByDate date :: " + DateUtil.getDateFormat(date, DateUtil.DEFAULT_DATE_FORMAT));
        }
        StringBuilder sql = new StringBuilder();
        sql.append("   SELECT HOLIDAY_DATE, HOLIDAY_YEAR ");
        sql.append("   FROM TBL_MT_HOLIDAY where holiday_date = to_date(?, 'dd/MM/yyyy') ");

        result = jdbcTemplate.query(sql.toString(), new Object[]{DateUtil.getDateFormat(date, DateUtil.DEFAULT_DATE_FORMAT)}, new BeanPropertyRowMapper<HolidayVo>(HolidayVo.class));
        
        if(result!=null && result.size() > 0){
            holidayDate = result.get(0).getHolidayDate();
        }
        
         
      }catch(Exception e){
          log.error("Error occur in while process HolidayServiceImpl.getHolidayByDate : " + e.getMessage() , e);
          throw e;
      }
      return holidayDate;
    }
    
}
