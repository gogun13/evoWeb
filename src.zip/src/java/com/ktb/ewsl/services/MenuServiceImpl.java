/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktbcs.core.utilities.BusinessConst;
import com.ktbcs.core.utilities.StringUtil;
import com.ktb.ewsl.vo.MenuInfoVo;
import com.ktb.ewsl.vo.MenuLevelVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author aon
 */
@Repository
public class MenuServiceImpl  implements MenuService {

    private static final Logger logger = Logger.getLogger(MenuServiceImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    public ArrayList<MenuInfoVo> getMainMenu(String userClass) {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT");
        sql.append(" DECODE (M.MENU_UNDER, NULL, LPAD(M.MENU_SEQ,2,'0') || '0', LPAD(MN.MENU_SEQ,2,'0') || LPAD(M.MENU_SEQ,2,'0') ) SEQ, ");
        sql.append(" M.MENU_ID ,M.MENU_UNDER ,M.MENU_LEVEL ,M.MENU_SEQ , ");
        sql.append(" M.MENU_LABEL ,M.MENU_TYPE ,M.MAIN_MENU_FLG ,M.MENU_GROUP , ");
        sql.append(" M.ACTION_NAME ,M.COMMAND_NAME ,M.MENU_REMARK ,M.IS_ACTIVE , ");
        sql.append(" NVL(M.ACTION_NAME,'')||NVL(M.COMMAND_NAME,'') LINK,M.AUTO_SHOW_FLG ");
        sql.append(" FROM TBL_MENU_INFO M ");
        sql.append(" INNER JOIN TBL_MENU_PRIVILEGE P ON M.MENU_ID=P.MENU_ID ");
        sql.append(" LEFT OUTER JOIN TBL_MENU_INFO MN ON M.MENU_UNDER=MN.MENU_ID ");
        sql.append(" WHERE M.IS_ACTIVE=1 AND P.IS_ACTIVE=1 ");
        sql.append(" AND M.MAIN_MENU_FLG='Y' ");
//        sql.append(" AND M.MENU_LEVEL=1 ");
        if (userClass != null && !"".equals(userClass)) {
            sql.append(" AND P.ROLE_ID ='").append(userClass).append("' ");
        } else {
            sql.append(" AND 1=2 ");
        }
        sql.append(" ORDER BY DECODE (M.MENU_UNDER, NULL, LPAD(M.MENU_SEQ,2,'0') || '0', LPAD(MN.MENU_SEQ,2,'0') || LPAD(M.MENU_SEQ,2,'0') ) ");

            ArrayList<MenuInfoVo> result = (ArrayList)jdbcTemplate.query(sql.toString(), new RowMapper() {
            public MenuInfoVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                MenuInfoVo item = new MenuInfoVo();
                item.setMenuId(rs.getString("MENU_ID"));
                item.setMenuUnder(rs.getString("MENU_UNDER"));
                item.setMenuLevel(rs.getInt("MENU_LEVEL"));
                item.setMenuSeq(rs.getInt("MENU_SEQ"));
                item.setMenuLabel(rs.getString("MENU_LABEL"));
                item.setMenuType(rs.getInt("MENU_TYPE"));
                item.setMainMenuFlg(rs.getString("MAIN_MENU_FLG"));
                item.setMenuGroup(rs.getString("MENU_GROUP"));
                item.setActionName(rs.getString("ACTION_NAME"));
                item.setCommandName(rs.getString("COMMAND_NAME"));
                item.setMenuRemark(rs.getString("MENU_REMARK"));
                item.setIsActive(rs.getInt("IS_ACTIVE"));
                item.setAutoShowFlg(rs.getInt("AUTO_SHOW_FLG"));

//                item.setMainMenuId(rs.getString(""));
                item.setLevel(rs.getString("MENU_LEVEL"));
                item.setDivTarget("page_main");
                item.setLink(rs.getString("LINK"));

                return item;
            }
        });
        return result;
    }

    public ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass) {
        return getTabMenu(mainMenuId, userClass, null);
    }

    public ArrayList<MenuLevelVo> getTabMenu(String mainMenuId, String userClass, String menuGroup) {

        StringBuilder temp = new StringBuilder();
        String strMenu = getParent(temp.append("'").append(mainMenuId).append("',"), mainMenuId);
       
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT");
        sql.append(" M.MENU_ID ,M.MENU_UNDER ,M.MENU_LEVEL ,M.MENU_SEQ , ");
        sql.append(" M.MENU_LABEL ,M.MENU_TYPE ,M.MAIN_MENU_FLG ,M.MENU_GROUP , ");
        sql.append(" M.ACTION_NAME ,M.COMMAND_NAME ,M.MENU_REMARK ,M.IS_ACTIVE , ");
        sql.append(" NVL(M.ACTION_NAME,'')||NVL(M.COMMAND_NAME,'') LINK, M.AUTO_SHOW_FLG ");
        sql.append("       FROM TBL_MENU_INFO M INNER JOIN TBL_MENU_PRIVILEGE P ");
        sql.append("            ON M.MENU_ID = P.MENU_ID ");
        if (userClass != null && !"".equals(userClass)) {
            sql.append(" AND P.USERCLASS='").append(userClass).append("' ");
        } else {
            sql.append(" AND 1=2 ");
        }
        sql.append("      WHERE P.IS_ACTIVE = 1 ");
        sql.append("        AND M.IS_ACTIVE = 1 ");
        sql.append("        AND NVL (M.MAIN_MENU_FLG, 'N') <> 'Y' ");
        sql.append(" AND M.MENU_UNDER IN ( ").append(strMenu).append(")   ");
        sql.append(" START WITH M.MENU_ID = ");
        sql.append("               (SELECT MENU_ID ");
        sql.append("                  FROM (SELECT     M.MENU_ID ");
        sql.append("                              FROM  TBL_MENU_INFO M ");
        sql.append("                             WHERE 1 = 1 ");
        sql.append("                               AND M.IS_ACTIVE = 1 ");
        sql.append("                               AND (M.MAIN_MENU_FLG = 'Y' OR M.MENU_UNDER IS NULL) ");
        sql.append("                        START WITH M.MENU_ID IN ( ").append(strMenu).append(")   ");
        sql.append("                        CONNECT BY PRIOR M.MENU_UNDER = M.MENU_ID ");
        sql.append("                          ORDER BY MENU_LEVEL DESC) ");
        sql.append("                 WHERE ROWNUM = 1) ");
        sql.append(" CONNECT BY PRIOR M.MENU_ID = M.MENU_UNDER ");
        sql.append(" ORDER BY M.MENU_LEVEL, M.MENU_SEQ, M.MENU_ID ");

        ArrayList<MenuInfoVo> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            public MenuInfoVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                MenuInfoVo item = new MenuInfoVo();
                item.setMenuId(rs.getString("MENU_ID"));
                item.setMenuUnder(rs.getString("MENU_UNDER"));
                item.setMenuLevel(rs.getInt("MENU_LEVEL"));
                item.setMenuSeq(rs.getInt("MENU_SEQ"));
                item.setMenuLabel(rs.getString("MENU_LABEL"));
                item.setMenuType(rs.getInt("MENU_TYPE"));
                item.setMainMenuFlg(rs.getString("MAIN_MENU_FLG"));
                item.setMenuGroup(rs.getString("MENU_GROUP"));
                item.setActionName(rs.getString("ACTION_NAME"));
                item.setCommandName(rs.getString("COMMAND_NAME"));
                item.setMenuRemark(rs.getString("MENU_REMARK"));
                item.setIsActive(rs.getInt("IS_ACTIVE"));
                item.setAutoShowFlg(rs.getInt("AUTO_SHOW_FLG"));


                item.setMainMenuId(rs.getString("MENU_UNDER"));
                item.setLevel(rs.getString("MENU_LEVEL"));
                item.setDivTarget("page_main");
                item.setLink(rs.getString("LINK"));
                item.setWidth(140);
                return item;
            }
        });

        ArrayList<MenuLevelVo> menuLevelList = new ArrayList<MenuLevelVo>();
        if (result != null && result.size() > 0) {
            int level = 0;
            MenuLevelVo menuLevel = null;
            String selectedParent = "";
            int selectedLevel = 0;

            for (MenuInfoVo menu : result) {


                if (mainMenuId.equals(menu.getMenuId())) {
                    selectedParent = menu.getMenuUnder();
                    selectedLevel = menu.getMenuLevel();
                }

                if (level < menu.getMenuLevel().intValue()) {
                    menuLevel = new MenuLevelVo(menu.getMenuLevel().intValue());

                    menuLevelList.add(menuLevel);
                    level = menu.getMenuLevel().intValue();
                }

//                logger.info("Find parent active of first child ");
//                String s1 = StringUtil.Left(mainMenuId, (5 + ((menu.getMenuLevel().intValue() + 0) * 2)));
//                String s2 = StringUtils.repeat("0", mainMenuId.length() - (5 + ((menu.getMenuLevel().intValue() + 0) * 2)));

//                if (menu.getMenuId().equals(s1.concat(s2))) {
//                    menu.setIsCurrent(BusinessConst.ActiveType.ACTIVE);
//                } else {
//                    menu.setIsCurrent(BusinessConst.ActiveType.IN_ACTIVE);
//                }
                menu.setIsCurrent(BusinessConst.ActiveType.IN_ACTIVE);
                menuLevel.getMenuInfoList().add(menu);
            }

            logger.info("Find current active menu. ");
            Object[] menuLO = menuLevelList.toArray();
            if (menuLO != null) {

                String parentId = "";
                for (int i = menuLO.length - 1; i >= 0; i--) {
                    MenuLevelVo menuLItem = (MenuLevelVo) menuLO[i];
                    if (menuLItem != null) {
                        Object[] menuList = menuLItem.getMenuInfoList().toArray();
                        for (int j = menuList.length - 1; j >= 0; j--) {
                            MenuInfoVo menu = (MenuInfoVo) menuList[j];
                            if (menu != null && (menu.getMenuId().equals(mainMenuId) || menu.getMenuId().equals(parentId))) {
//                            if (j == 0){
                                menu.setIsCurrent(BusinessConst.ActiveType.ACTIVE);
                                parentId = menu.getMenuUnder();
                                break;
                            }
                            if (j==0 && StringUtil.isEmpty(parentId)){
                                menu = (MenuInfoVo) menuList[0];
                                menu.setIsCurrent(BusinessConst.ActiveType.ACTIVE);
                                parentId = menu.getMenuUnder();
                            }
                        }

                        boolean isMenuGroup = false;
                        ArrayList<MenuInfoVo> removeList = new ArrayList<MenuInfoVo>();
                        for (int k = menuList.length - 1; k >= 0; k--) {
                            MenuInfoVo menux = (MenuInfoVo) menuList[k];
                            String menuUnder = menux.getMenuUnder();
                            if (parentId != null && !"".equals(parentId) && menuUnder != null && !menuUnder.equals(parentId)) {
                                removeList.add(menux);
                            }
//                            if (k==(menuList.length - 1)&&menux.getMenuGroup() != null && !menux.getMenuGroup().equals(menuGroup)) {
//                                removeList.add(menux);
//                            }
                            if (menuGroup != null && menuGroup.equals(menux.getMenuGroup())) {
                                isMenuGroup = true;
                            }
                        }

                        if (isMenuGroup) {
                            for (int k = menuList.length - 1; k >= 0; k--) {
                                MenuInfoVo menux = (MenuInfoVo) menuList[k];
                                if (menuGroup != null && !menuGroup.equals(menux.getMenuGroup())) {
                                    removeList.add(menux);
                                }
                            }
                        }

                        menuLItem.getMenuInfoList().removeAll(removeList);
                    }
                }
            }

            logger.info("Remove menu in another parent with mainMenuId. ");
//            if (menuLevelList != null && menuLevelList.size() > 0) {
//
//                ArrayList<MenuInfoVo> removeAnoList = new ArrayList<MenuInfoVo>();
//                ArrayList<MenuInfoVo> lastLevelList = menuLevelList.get(menuLevelList.size() - 1).getMenuInfoList();
//
//                if (lastLevelList != null) {
//                    for (MenuInfoVo menu : lastLevelList) {
//                        if (selectedParent.equals(menu.getMenuUnder()) && selectedLevel == menu.getMenuLevel().intValue()) {
//                            removeAnoList.add(menu);
//                        }
//                    }
//                }
//                lastLevelList.removeAll(removeAnoList);
//            }



            Object[] menuArray = result.toArray();
            int menuLength = menuArray.length;
            for (int i = 0; i < menuArray.length; i++) {
                MenuInfoVo menu = (MenuInfoVo) menuArray[i];

                if (i > 0) {
                    MenuInfoVo prvMenu = (MenuInfoVo) menuArray[i - 1];
                    if (menu.getMenuLevel().intValue() == prvMenu.getMenuLevel().intValue()) {
                        menu.setPreviousMenuId(prvMenu.getMenuId());
                    }
                }

                if (i < menuLength - 1) {
                    MenuInfoVo nextMenu = (MenuInfoVo) menuArray[i + 1];
                    if (menu.getMenuLevel().intValue() == nextMenu.getMenuLevel().intValue()) {
                        menu.setNextMenuId(nextMenu.getMenuId());
                    }
                }
            }

        }
        return menuLevelList;
    }

    public MenuInfoVo getFirstChild(String menuId, String userClass) {
        return getFirstChild(menuId, userClass, null);
    }

    public MenuInfoVo getFirstChild(String menuId, String userClass, String menuGroup) {
        MenuInfoVo menu = null;
        StringBuilder sql = new StringBuilder();

        sql.append(" SELECT M.MENU_ID, ");
                 sql.append(" M.MENU_UNDER, ");
                 sql.append(" M.MENU_LEVEL, ");
                 sql.append(" M.MENU_SEQ, ");
                 sql.append(" M.MENU_LABEL, ");
                 sql.append(" M.MENU_TYPE, ");
                 sql.append(" M.MAIN_MENU_FLG, ");
                 sql.append(" M.MENU_GROUP, ");
                 sql.append(" M.ACTION_NAME, ");
                 sql.append(" M.COMMAND_NAME, ");
                 sql.append(" M.MENU_REMARK, ");
                 sql.append(" M.IS_ACTIVE, ");
                 sql.append(" NVL (M.ACTION_NAME, '') || NVL (M.COMMAND_NAME, '') LINK, ");
                 sql.append(" M.AUTO_SHOW_FLG ");
      sql.append(" FROM  TBL_MENU_INFO M ");
      sql.append(" INNER JOIN  TBL_MENU_PRIVILEGE P ON M.MENU_ID = P.MENU_ID ");
      sql.append(" WHERE  P.IS_ACTIVE = 1 ");
      sql.append(" AND M.IS_ACTIVE = 1 ");
      if (userClass != null && !"".equals(userClass)) {
        sql.append(" AND P.ROLE_ID = '").append(userClass).append("' ");
      }
      if (menuGroup != null && !"".equals(menuGroup)) {
        sql.append(" AND M.MENU_GROUP = '").append(menuGroup).append("' ");
      }
      sql.append(" and M.MENU_UNDER = '").append(menuId).append("' ");
      sql.append(" and  NVL (M.MAIN_MENU_FLG, 'N') <> 'Y' ");
      sql.append(" order by m.MENU_level DESC, m.MENU_SEQ ");

        System.out.println("getFirstChild("+menuId+","+userClass+","+menuGroup+")");
        logger.info(sql.toString());

        ArrayList<MenuInfoVo> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {

            public MenuInfoVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                MenuInfoVo item = new MenuInfoVo();
                item.setMenuId(rs.getString("MENU_ID"));
                item.setMenuUnder(rs.getString("MENU_UNDER"));
                item.setMenuLevel(rs.getInt("MENU_LEVEL"));
                item.setMenuSeq(rs.getInt("MENU_SEQ"));
                item.setMenuLabel(rs.getString("MENU_LABEL"));
                item.setMenuType(rs.getInt("MENU_TYPE"));
                item.setMainMenuFlg(rs.getString("MAIN_MENU_FLG"));
                item.setMenuGroup(rs.getString("MENU_GROUP"));
                item.setActionName(rs.getString("ACTION_NAME"));
                item.setCommandName(rs.getString("COMMAND_NAME"));
                item.setMenuRemark(rs.getString("MENU_REMARK"));
                item.setIsActive(rs.getInt("IS_ACTIVE"));
                item.setAutoShowFlg(rs.getInt("AUTO_SHOW_FLG"));

                item.setLink(rs.getString("LINK"));

                return item;
            }
        });

        if (result != null && result.size() > 0) {
            menu = (MenuInfoVo) result.get(0);
        }
        return menu;
    }
    
    public MenuInfoVo getFirstChildOld(String menuId, String userClass, String menuGroup) {
        MenuInfoVo menu = null;
        StringBuilder sql = new StringBuilder();
        

        sql.append(" SELECT MENU_ID, MENU_UNDER, MENU_LEVEL, MENU_SEQ, MENU_LABEL, MENU_TYPE,");
        sql.append("        MAIN_MENU_FLG, MENU_GROUP, ACTION_NAME, COMMAND_NAME, MENU_REMARK,");
        sql.append("        IS_ACTIVE,LINK ,AUTO_SHOW_FLG ");
        sql.append(" FROM (  ");

        sql.append(" SELECT  ");
        sql.append(" MENU_ID ,MENU_UNDER ,MENU_LEVEL ,MENU_SEQ ,MENU_LABEL  ");
        sql.append(" ,MENU_TYPE ,MAIN_MENU_FLG ,MENU_GROUP ,ACTION_NAME ,COMMAND_NAME  ");
        sql.append(" ,MENU_REMARK ,IS_ACTIVE ");
        sql.append(" ,NVL(ACTION_NAME,'')||NVL(COMMAND_NAME,'') LINK, AUTO_SHOW_FLG ");
        sql.append(" FROM ( ");
//        sql.append(" 	SELECT (DECODE(PRIOR M.MAIN_MENU_FLG,'Y',99999,PRIOR M.MENU_LEVEL))||(PRIOR M.MENU_SEQ)||(M.MENU_LEVEL)||(M.MENU_SEQ) PAR ");
        sql.append(" 	SELECT (DECODE( M.MAIN_MENU_FLG,'Y',99999, M.MENU_LEVEL))||( M.MENU_SEQ)||(M.MENU_LEVEL)||(M.MENU_SEQ) PAR ");//ตัด PRIOR ออก เพราะมัน error บน DB2
        sql.append(" 	, M.*  ");
        sql.append(" 	FROM  TBL_MENU_INFO M    ");
        sql.append("    INNER JOIN TBL_MENU_PRIVILEGE P ON M.MENU_ID=P.MENU_ID ");
        sql.append(" 	WHERE P.IS_ACTIVE=1 AND M.IS_ACTIVE=1 ");
        sql.append("    AND  P.ROLE_ID = '").append(userClass).append("'");
//        sql.append("    AND PRIOR M.ACTION_NAME IS NULL ");
        sql.append("    AND  M.ACTION_NAME IS NULL ");//ตัด PRIOR ออก เพราะมัน error บน DB2
        sql.append("    AND M.MENU_ID <> '").append(menuId).append("'  ");
//        sql.append(" 	AND M.ACTION_NAME IS NOT NULL  ");
        sql.append(" 	START WITH M.MENU_ID= '").append(menuId).append("' ");
        sql.append(" 	CONNECT BY PRIOR M.MENU_ID=M.MENU_UNDER ");
//        sql.append(" 	ORDER BY (DECODE(PRIOR M.MAIN_MENU_FLG,'Y',99999,PRIOR M.MENU_LEVEL))||(PRIOR M.MENU_SEQ)||(M.MENU_LEVEL)||(M.MENU_SEQ) ");
        sql.append(" 	ORDER BY (DECODE( M.MAIN_MENU_FLG,'Y',99999, M.MENU_LEVEL))||( M.MENU_SEQ)||(M.MENU_LEVEL)||(M.MENU_SEQ) ");//ตัด PRIOR ออก เพราะมัน error บน DB2
        sql.append(" ) ");
        sql.append(" WHERE ROWNUM=1 ");

        sql.append(" UNION");
        sql.append(" (");
        sql.append("     SELECT M.MENU_ID, M.MENU_UNDER, M.MENU_LEVEL, M.MENU_SEQ, M.MENU_LABEL, M.MENU_TYPE,");
        sql.append("            M.MAIN_MENU_FLG, M.MENU_GROUP, M.ACTION_NAME, M.COMMAND_NAME, M.MENU_REMARK,");
        sql.append("            M.IS_ACTIVE, NVL (M.ACTION_NAME, '') || NVL (M.COMMAND_NAME, '') LINK, M.AUTO_SHOW_FLG ");
        sql.append("     FROM TBL_MENU_INFO M ");
        sql.append("     INNER JOIN TBL_MENU_PRIVILEGE P ON M.MENU_ID=P.MENU_ID ");
        sql.append(" 	 WHERE P.IS_ACTIVE=1 AND M.IS_ACTIVE=1 ");
        sql.append("     AND  P.ROLE_ID = '").append(userClass).append("'");
        sql.append("     AND  M.MENU_ID = '").append(menuId).append("'");
        sql.append(" )");
        sql.append(" )");
        sql.append(" WHERE NVL(MAIN_MENU_FLG,'N')<>'Y' ");
        if (menuGroup != null && !"".equals(menuGroup)) {
            sql.append(" AND MENU_GROUP='").append(menuGroup).append("' ");
        }
        sql.append(" ORDER BY MENU_LEVEL DESC,MENU_SEQ");

        System.out.println("getFirstChild("+menuId+","+userClass+","+menuGroup+")");
        logger.info(sql.toString());

        ArrayList<MenuInfoVo> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {

            public MenuInfoVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                MenuInfoVo item = new MenuInfoVo();
                item.setMenuId(rs.getString("MENU_ID"));
                item.setMenuUnder(rs.getString("MENU_UNDER"));
                item.setMenuLevel(rs.getInt("MENU_LEVEL"));
                item.setMenuSeq(rs.getInt("MENU_SEQ"));
                item.setMenuLabel(rs.getString("MENU_LABEL"));
                item.setMenuType(rs.getInt("MENU_TYPE"));
                item.setMainMenuFlg(rs.getString("MAIN_MENU_FLG"));
                item.setMenuGroup(rs.getString("MENU_GROUP"));
                item.setActionName(rs.getString("ACTION_NAME"));
                item.setCommandName(rs.getString("COMMAND_NAME"));
                item.setMenuRemark(rs.getString("MENU_REMARK"));
                item.setIsActive(rs.getInt("IS_ACTIVE"));
                item.setAutoShowFlg(rs.getInt("AUTO_SHOW_FLG"));

                item.setLink(rs.getString("LINK"));

                return item;
            }
        });

        if (result != null && result.size() > 0) {
            menu = (MenuInfoVo) result.get(0);
        }
        return menu;
    }

    @Override
    public String getFirstMenu(String mainMenuId) {
        String menuId = null;
        StringBuilder sql = new StringBuilder();
        sql.append("WITH N(MENU_UNDER, MENU_ID, IS_ACTIVE, MAIN_MENU_FLG, MENU_LEVEL) AS ");
        sql.append("( ");
        sql.append("SELECT M.MENU_UNDER, M.MENU_ID, IS_ACTIVE, MAIN_MENU_FLG, MENU_LEVEL ");
        sql.append("FROM TBL_MENU_INFO M ");
        sql.append("WHERE M.MENU_ID = '").append(mainMenuId).append("' ");
        sql.append("UNION ALL ");
        sql.append("SELECT NPLUS1.MENU_UNDER, NPLUS1.MENU_ID, NPLUS1.IS_ACTIVE, NPLUS1.MAIN_MENU_FLG, NPLUS1.MENU_LEVEL ");
        sql.append("FROM TBL_MENU_INFO as NPLUS1, N ");
        sql.append("WHERE N.MENU_UNDER = NPLUS1.MENU_ID ");
        sql.append(") ");
        sql.append("SELECT MENU_ID ");
        sql.append("FROM N ");
        sql.append("WHERE IS_ACTIVE = 1 ");
        sql.append("AND (MAIN_MENU_FLG = 'Y' OR MENU_UNDER IS NULL) ");
        sql.append("ORDER BY MENU_LEVEL DESC ");
        ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("MENU_ID");
            }
        });

        if (result != null && result.size() > 0) {
            menuId = (String) result.get(0);
        }
        return menuId;
    }
    
    /**
     * 
     * @param strResult
     * @param childMenuId
     * @return 
     */
    private String getParent(StringBuilder strResult, String childMenuId) {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT MENU_UNDER FROM TBL_MENU_INFO WHERE MENU_ID = '").append(childMenuId).append("'");

        ArrayList<String> result = (ArrayList) jdbcTemplate.query(sql.toString(), new RowMapper() {
        @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("MENU_UNDER");
            }
        });

        if (result != null && result.size() > 0 && StringUtil.isNotEmpty(result.get(0))) {
            strResult.append("'").append(result.get(0)).append("',");
            getParent(strResult, result.get(0));
        }
        return strResult.toString().substring(0, strResult.length() - 1);        
    }    

     
         
}