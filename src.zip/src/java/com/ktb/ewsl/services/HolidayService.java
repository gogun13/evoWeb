/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.HolidayVo;
import java.util.Date;
import java.util.List;

/**
 *
 * @author KTBDevLoan
 */
public interface HolidayService {
    
    public List<HolidayVo> getHoliday() throws Exception;
    List<HolidayVo> getHolidayForThisYear() throws Exception;
    public Date getHolidayByDate(Date date) throws Exception;
}
