/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.FinancialRatioVo;
import com.ktb.ewsl.vo.FinancialVo;
import com.ktb.ewsl.vo.ScoreEngineVo;
import com.ktbcs.core.vo.UserData;
import java.util.List;

/**
 *
 * @author Kat
 */
public interface QcaFinancialService {
     public FinancialVo getFinancialVO(String appID, String cif)throws Exception;
     public List<FinancialRatioVo> getRatioList(String finTrnId) throws Exception;
     public boolean checkDBFinancial(FinancialVo finVO);
     public void updateFinancial(FinancialVo finVO, UserData userObj, String isActive) throws Exception;
     public void updateFinancialByAppAndCIF(FinancialVo finVO, UserData userObj, String isActive) throws Exception;
     public void insertFinancial(FinancialVo finVO, UserData userObj, String isActive) throws Exception;
     public FinancialVo checkHVFin(String cifId);
     public ScoreEngineVo findDataForSendScore(int warningId) throws Exception;
     public FinancialVo findCurrentQcaFin(String cifId)throws Exception;
     public void updateFinancialFlagByCIF(FinancialVo finVO, UserData userObj, String isActive) throws Exception;
     public FinancialVo getLastFinancialVO(String cif)throws Exception;
     public FinancialVo getFinancialVOByWarningId(String warningId)throws Exception;
     public FinancialVo getFinancialForCalDate(String cif , String warningId)throws Exception;
     public void updateQcaFinInDelayReason(FinancialVo finVO)throws Exception;
}
