/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.services;

import com.ktb.ewsl.vo.WarningTypePrivilegeVo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author KTBDevLoan
 */
@Repository
public class WarningTypePrivilegeServiceImpl  implements WarningTypePrivilegeService{
    
    private static Logger logger = Logger.getLogger(WarningTypePrivilegeServiceImpl.class);
    
    @Autowired
    public JdbcTemplate jdbcTemplate;

    @Override
    public ArrayList<WarningTypePrivilegeVo> findWarningTypePrivilegeByRole(String roleId) throws Exception {
      ArrayList<WarningTypePrivilegeVo> resultList = null;
      try{
        StringBuilder sql = new StringBuilder();
 	
        sql.append(" SELECT ROLE_CODE, WARNING_TYPE_CODE, CREATED_DT, CREATED_BY, UPDATED_DT, UPDATED_BY  ");
        sql.append("\n FROM TBL_WARNING_TYPE_PRIVILEGE ");
        sql.append("\n WHERE ROLE_CODE = ? ");
    
           resultList =(ArrayList<WarningTypePrivilegeVo>) jdbcTemplate.query(sql.toString(), new Object[]{roleId}, new RowMapper(){
                    public WarningTypePrivilegeVo mapRow(ResultSet rs, int rowNum) throws SQLException {
                        WarningTypePrivilegeVo vo = new WarningTypePrivilegeVo();
                        vo.setRoleCode(rs.getString("ROLE_CODE"));
                        vo.setWarningTypeCode(rs.getString("WARNING_TYPE_CODE"));
                        return vo;
                    }
                });
      
      }catch(Exception e){
          logger.error("Error occur in while process WarningTypePrivilegeServiceImpl.findWarningTypePrivilegeByRole: " + e.getMessage() , e);
      }
      return resultList;
    }
    
    
}
