/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktb.ewsl.export;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

import com.ktb.ewsl.vo.CountDataVo;
import com.ktb.ewsl.vo.CustomerVo;
import com.ktb.ewsl.vo.MtFormStatusVo;
import com.ktb.ewsl.vo.ReportCloseJobVo;
import com.ktb.ewsl.vo.WarningHeaderVo;
import com.ktbcs.core.vo.SearchBean;

/**
 *
 * @author somphop.h
 */
public class CloseJobDataExporter implements ExcelDataExporter {

	/*
	 * Variable keep flag of open session state when the file is open state = true,
	 * close state = false.
	 */
	private Boolean isOpenSession = false;
	/*
	 * Variable keep last table row index when fetched data in that row.
	 */
	private int lastRowIndex = 0;
	// data start at 1
	private int dataCnt = 0;

	// HSSF variable
	private HSSFWorkbook wb;
	private HSSFSheet sheet;
	private Map<String, CellStyle> styles;

	// Define constant.
	final String SHEET_NAME = "Pipe Line";

	private Map<ColumnName, Integer> columnsIndex = new HashMap<ColumnName, Integer>();
//	List<String> assessmentRoles = new ArrayList<String>(Arrays.asList("VW1", "RE", "AD"));
        List<String> assessmentRoles = new ArrayList<String>(Arrays.asList("VW1", "RE", "AD", "RV"));//[EWS-L : R11]

	private Map<String, Object> params = new HashMap<String, Object>();

	private String roleId;

	public CloseJobDataExporter() {

	}

	@Override
	protected void finalize() throws Throwable {
		isOpenSession = false;
		if (wb != null) {
			wb = null;
		}
		super.finalize();
	}

	public static void main(String[] args) throws FileNotFoundException, IOException {
		CloseJobDataExporter exporter = new CloseJobDataExporter();
		List<ReportCloseJobVo> data = new ArrayList<ReportCloseJobVo>();
		for (int i = 0; i < 50; i++) {
			ReportCloseJobVo rvo = new ReportCloseJobVo();
			WarningHeaderVo whv = new WarningHeaderVo();
			whv.setWarningDate(new Date());
			whv.setAeId("000000" + i);
			whv.setAoId("000000" + i);
			whv.setRespUnit(i + 100556);
			whv.setRmId("000000" + i);
			whv.setCFinal("N/A");
			whv.setCif("108009");
			whv.setDpd(55);
			whv.setCustomerVo(new CustomerVo());
			whv.getCustomerVo().setCif(i + 100500);
			whv.getCustomerVo().setCustName("N/A");

			rvo.setWarningHeaderVo(whv);
			data.add(rvo);
		}
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("dataList", data);
		FileOutputStream out = new FileOutputStream("C:\\Users\\somphop.h\\Desktop\\Temp\\workbook.xls");
		HSSFWorkbook wb = exporter.setParams(params).export();
		wb.write(out);
		out.flush();
		out.close();
	}

	public CloseJobDataExporter openFile() {
		if (isOpenSession) {
			return this;
		}

		try {
			isOpenSession = true;
			/*
			 * Define workbook instance.
			 */
			wb = new HSSFWorkbook();
			/*
			 * Define the workbook's sheet.
			 */
			sheet = wb.createSheet("Pipeline");
			/*
			 * Create workbook's style.
			 */
			styles = createStylesReconcile(wb);
			/*
			 * Build Column size before add data.
			 */
			createColumnSize(sheet);

			/*
			 * Build Document header.
			 */
			SearchBean search = null;
			if (params.get("searchBean") != null) {
				search = (SearchBean) params.get("searchBean");
			}

			if (params.get("roleId") != null) {
				roleId = (String) params.get("roleId");
			}

			createDocHeader(search, sheet, styles);

			createTableHeader(sheet, styles, roleId);

		} catch (Exception e) {
			isOpenSession = false;
		}
		return this;
	}

	@Override
	public HSSFWorkbook export() throws IOException {

		if (!isOpenSession) {

			openFile();

			List<ReportCloseJobVo> data = null;
			if (params.get("dataList") != null) {
				data = (List<ReportCloseJobVo>) params.get("dataList");
			}
			addData(data);
		}

		/*
		 * Create table footer.
		 */
		createTableFooter(sheet, styles);
		/*
		 * Create document footer
		 */
		createDocFooter(sheet, styles);

		isOpenSession = false;

		return wb;
	}

	public CloseJobDataExporter addData(List<ReportCloseJobVo> data) throws IOException {
		lastRowIndex = createTableData(data, lastRowIndex, sheet, styles, roleId);

		return this;
	}

	/**
	 * Set table column size before add data.
	 * 
	 * @param sheet
	 */
	private void createColumnSize(HSSFSheet sheet) {
		int colnum = 33;
		int colSize = 17;

		HSSFRow row = sheet.createRow(0);
		for (int i = 0; i <= colnum; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellValue(emptyData(colSize));
			sheet.autoSizeColumn(i);
		}

		for (int i = 0; i <= colnum; i++) {
			HSSFCell cell = row.getCell(i);
			cell.setCellValue("");
		}

	}

	private String emptyData(int length) {
		String data = "";
		for (int i = 0; i < length; i++) {
			data += "_";
		}
		return data;
	}

	private void createDocHeader(SearchBean search, HSSFSheet sheet, Map<String, CellStyle> styles) {

		// Sheet Header row 1
		HSSFRow row1 = sheet.createRow(1);
		HSSFRow row2 = sheet.createRow(2);
		HSSFRow row3 = sheet.createRow(3);
		HSSFRow row4 = sheet.createRow(4);
		HSSFRow row5 = sheet.createRow(5);
		HSSFRow row7 = sheet.createRow(7);

		HSSFCell cell;

		/*
		 * Label row 1
		 */
		cell = row1.createCell(0);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("CIF No:");

		cell = row1.createCell(3);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("สายงาน:");

		/*
		 * Label row 2
		 */
		cell = row2.createCell(0);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("ชื่อลูกค้า:");

		cell = row2.createCell(3);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("กลุ่มงาน:");

		/*
		 * Label row 3
		 */
		cell = row3.createCell(0);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("รหัสผู้ดูแล:");

		cell = row3.createCell(3);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("หน่วยงาน:");

		if (search != null) {
			cell = row1.createCell(1);
			cell.setCellStyle(styles.get(Style.DEFAULT));
			cell.setCellValue(search.getCifNo());

			cell = row1.createCell(4);
			cell.setCellStyle(styles.get(Style.DEFAULT));
			cell.setCellValue(search.getWorkLine());

			cell = row2.createCell(1);
			cell.setCellStyle(styles.get(Style.DEFAULT));
			cell.setCellValue(search.getCustomerName());

			cell = row2.createCell(4);
			cell.setCellStyle(styles.get(Style.DEFAULT));
			cell.setCellValue(search.getOrganizationGroup());

			cell = row3.createCell(1);
			cell.setCellStyle(styles.get(Style.DEFAULT));
			cell.setCellValue(search.getRmIdOrAeId());

			cell = row3.createCell(4);
			cell.setCellStyle(styles.get(Style.DEFAULT));
			cell.setCellValue(search.getCostCenter());
		}
		/*
		 * Label row 4
		 */
		cell = row4.createCell(0);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("ช่วงวันที่ปิดงาน:");

		cell = row4.createCell(3);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("สิ้นสุดวันที่ปิดงาน:");

		cell = row4.createCell(1);
		cell.setCellStyle(styles.get(Style.DEFAULT));
		cell.setCellValue(params.get("fromDateCloseJobStr") != null ? (String) params.get("fromDateCloseJobStr") : "");

		cell = row4.createCell(4);
		cell.setCellStyle(styles.get(Style.DEFAULT));
		cell.setCellValue(params.get("toDateCloseJobStr") != null ? (String) params.get("toDateCloseJobStr") : "");

		/*
		 * Label row 5
		 */
		cell = row5.createCell(0);
		cell.setCellStyle(styles.get(Style.HEADER_LABLE));
		cell.setCellValue("ผู้ทำรายการปิดงาน:");

		cell = row5.createCell(1);
		cell.setCellStyle(styles.get(Style.DEFAULT));
		cell.setCellValue(params.get("closeBy") != null ? (String) params.get("closeBy") : "");

		cell = row7.createCell(0);
		cell.setCellStyle(styles.get(Style.DEFAULT));

		StringBuilder sb = new StringBuilder();
		sb.append("จำนวนทั้งหมด ").append(params.get("totalRecs") != null ? params.get("totalRecs").toString() : "")
				.append(" รายการ ณ วันที่ ")
				.append(params.get("reportDate") != null ? (String) params.get("reportDate") : "").append(" เวลา ")
				.append(params.get("reportTime") != null ? (String) params.get("reportTime") : "").append(" น. ");
		cell.setCellValue(sb.toString());

		lastRowIndex = 7;
	}

	private void createDocFooter(HSSFSheet sheet, Map<String, CellStyle> styles) {
		final String remarkTitleStr = "หมายเหตุ สถานะการแจ้งเตือน";
		final List<MtFormStatusVo> remarks = (List<MtFormStatusVo>) params.get("remark");

		if (remarks != null) {
			// Create Remark title
			final int remarkStartRow = lastRowIndex + 2;
			HSSFRow row = sheet.createRow(remarkStartRow);
			HSSFCell cell = row.createCell(1);
			cell.setCellStyle(styles.get(Style.REMARK_TITLE));
			cell.setCellValue(remarkTitleStr);

			for (int i = 0; i < remarks.size(); i++) {
				row = sheet.createRow(remarkStartRow + 1 + i);
				cell = row.createCell(1);
				cell.setCellStyle(styles.get(Style.REMARK));
				cell.setCellValue(remarks.get(i).getSeq() + " หมายถึง " + remarks.get(i).getFormStatusName());
			}
		}
	}

	private int createTableData(List<ReportCloseJobVo> list, Integer rowIndex, HSSFSheet sheet,
			Map<String, CellStyle> styles, String roleId) {
		int curRowIndex = rowIndex + 1;
		// increase data counter.
		if (list != null && !list.isEmpty()) {
			dataCnt = 1;
		} else {
			return curRowIndex;
		}
		for (int i = 0; i < list.size(); i++, curRowIndex++, dataCnt++) {
			ReportCloseJobVo en = list.get(i);
			HSSFRow row = sheet.createRow(curRowIndex);
			int colIndexStack = 0;

			// No.
			HSSFCell cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(dataCnt);
			colIndexStack++;

			// Warning Date
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			if (en.getWarningHeaderVo() != null && en.getWarningHeaderVo().getWarningDate() != null) {
				SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", new Locale("th", "TH"));
				cell.setCellValue(df.format(en.getWarningHeaderVo().getWarningDate()));
			} else {
				cell.setCellValue("");
			}
			colIndexStack++;

			// CIF No.
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getCif()));
			colIndexStack++;

			// ชื่อลูกค้า
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TEXT_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getCustomerVo().getCustName()));
			colIndexStack++;

			// RM ID
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getRmId()));
			colIndexStack++;

			// AE ID
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getAeId()));
			colIndexStack++;

			// AO ID
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getAoId()));
			colIndexStack++;

			// Response Unit
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getRespUnitStr()));
			colIndexStack++;

			// EWS Risk
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getEwsRiskLevel()));
			colIndexStack++;

			// C Final
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getCFinal()));
			colIndexStack++;

			// DPDs
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getDpdStr()));
			colIndexStack++;

			// #A/Cs
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getDpdAcctCntStr()));
			colIndexStack++;

			// Unpaid Amount(บาท)
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_NUMBER_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getUnpaidAmtStr()));
			colIndexStack++;

			// OD Over-Limit
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getOdOverLimit().toString()));
			colIndexStack++;

			// #A/Cs
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getOdAcctCntStr()));
			colIndexStack++;

			// ยอดหนี้ที่เกินวงเงิน (บาท)
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_NUMBER_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getOdOverAmtStr()));
			colIndexStack++;

			// Late Payment Form
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getSortLatePayForm()));
			colIndexStack++;

			// Action Form 1
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getSortAction1Form()));
			colIndexStack++;

			// Action Form 2
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getSortAction2Form()));
			colIndexStack++;

			// Quali
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getSortQuali()));
			colIndexStack++;

			// Fin
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getSortFin()));
			colIndexStack++;

			/*
			 * การต่ออายุ/ทบทวนสินเชื่อ
			 */
			// Types
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getTypesFlg()));
			colIndexStack++;

			// Credit Review
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getCrFlg()));
			colIndexStack++;

			// Review Date
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getReviewDateFinalStr()));
			colIndexStack++;

			// Credit Rating
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getCreditRatingFlg()));
			colIndexStack++;

			// Rating Date
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getWarningHeaderVo().getRatingDateFinalStr()));
			colIndexStack++;

			// ประเภทการปิดงาน
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getCloseJobType()));
			colIndexStack++;

			// เหตุผลการปิดงาน
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_TEXT_DATA));
			cell.setCellValue(data(en.getReasonDetail()));
			colIndexStack++;

			// หมายเหตุ
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_TEXT_DATA));
			cell.setCellValue(data(en.getRemark()));
			colIndexStack++;

			// ผู้ทำรายการ
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getActionBy()));
			colIndexStack++;

			// วันที่ทำรายการ
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getActionDtS()));
			colIndexStack++;

			// ผู้อนุมัติ
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getApproveBy()));
			colIndexStack++;

			// วันที่อนุมัติรายการ
			cell = row.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(data(en.getApproveDtS()));
			colIndexStack++;

		}

		return curRowIndex;
	}

	private void createTableFooter(HSSFSheet sheet, Map<String, CellStyle> styles) {

		HSSFRow row = sheet.createRow(lastRowIndex);
		
		HSSFCell cell = null;
		
		cell = row.createCell(15);
		cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
		cell.setCellValue("รวม:");
		
		CountDataVo cnt = (CountDataVo) params.get("countObjData");
		if (cnt != null) {
			cell = row.createCell(16);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getLatePayFlgCountStr());

			cell = row.createCell(17);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getAction1FlgCountStr());

			cell = row.createCell(18);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getAction2FlgCountStr());

			cell = row.createCell(19);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getQualiFlgCountStr());

			cell = row.createCell(20);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getFinFlgCountStr());
			
			cell = row.createCell(21);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			
			cell = row.createCell(22);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getCrFlgCountStr());
			
			cell = row.createCell(23);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			
			cell = row.createCell(24);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
			cell.setCellValue(cnt.getCreditRatingFlgCountStr());
		}
		
		for(int i=25;i<33;i++) {
			cell = row.createCell(i);
			cell.setCellStyle(styles.get(Style.DEFAULT_TABLE_DATA));
		}
		row.getSheet().addMergedRegion(new CellRangeAddress(row.getRowNum(), row.getRowNum(), 25, 32));
		
		
		lastRowIndex++;
	}

	/**
	 * Build export table header.
	 * 
	 * @param sheet
	 * @param styles
	 * @param roleId
	 * @return
	 */
	private Integer createTableHeader(HSSFSheet sheet, Map<String, CellStyle> styles, String roleId) {
		// Define constant.
		final List<ColumnName> BASE_COLUMNS1 = new ArrayList<ColumnName>(
				Arrays.asList(ColumnName.NO, ColumnName.WARNING_DATE, ColumnName.CIF_NO, ColumnName.CUSTOMER_NAME));
		final List<ColumnName> BASE_COLUMNS2 = new ArrayList<ColumnName>(
				Arrays.asList(ColumnName.EWS_RISK, ColumnName.C_FINAL));

		final int hRowI1 = lastRowIndex + 1, hRowI2 = lastRowIndex + 2;
		lastRowIndex = lastRowIndex + 2;
		HSSFCell cell;
		// Table Header 1
		HSSFRow row_tbHeader1 = sheet.createRow(hRowI1);
		// Table Header 2
		HSSFRow row_tbHeader2 = sheet.createRow(hRowI2);

		/*
		 * Write Column "No.","Warning Date","CIF No.","ชื่อลูกค้า".
		 */
		for (int i = 0; i < BASE_COLUMNS1.size(); i++) {
			cell = row_tbHeader1.createCell(i);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER1));
			cell.setCellValue(BASE_COLUMNS1.get(i).getText());
			// ignore some column for auto adjust column size
			cell = row_tbHeader2.createCell(i);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER1));

			// Remind Column index
			columnsIndex.put(BASE_COLUMNS1.get(i), i);

			sheet.addMergedRegion(new CellRangeAddress(hRowI1, hRowI2, i, i));

		}

		// Dynamic Column
		/*
		 * Write column "Account Owner".
		 */
		cell = row_tbHeader1.createCell(4);
		cell.setCellValue(ColumnName.ACCOUNT_OWNER.getText());

		/*
		 * Write Account Owner child column.
		 * 
		 * RM ID,AE ID,AO ID,Response Unit
		 */
		int colIndexStack = 4, firstIndex = 4;
		if (!"RM".equals(roleId)) {
			cell = row_tbHeader2.createCell(colIndexStack);
			cell.setCellValue(ColumnName.RM.getText());
			cell.setCellStyle(styles.get(Style.TABLE_HEADER3));

			columnsIndex.put(ColumnName.RM, colIndexStack);

			colIndexStack++;
		}
		if (!"AE".equals(roleId)) {
			cell = row_tbHeader2.createCell(colIndexStack);
			cell.setCellValue(ColumnName.AE.getText());
			cell.setCellStyle(styles.get(Style.TABLE_HEADER3));

			columnsIndex.put(ColumnName.AE, colIndexStack);

			colIndexStack++;
		}
		if (!"AO".equals(roleId)) {
			cell = row_tbHeader2.createCell(colIndexStack);
			cell.setCellValue(ColumnName.AO.getText());
			cell.setCellStyle(styles.get(Style.TABLE_HEADER3));

			columnsIndex.put(ColumnName.AO, colIndexStack);

			colIndexStack++;
		}
		if (Arrays.asList("RM", "AE", "AO", "BCM").indexOf(roleId) < 0) {
			cell = row_tbHeader2.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER3));
			cell.setCellValue(ColumnName.RESPONSE_UNIT.getText());

			columnsIndex.put(ColumnName.RESPONSE_UNIT, colIndexStack);

			colIndexStack++;
		}

		sheet.addMergedRegion(new CellRangeAddress(hRowI1, hRowI1, firstIndex, colIndexStack - 1));
		// Fill header style on merged cell.
		for (int i = firstIndex; i < colIndexStack; i++) {
			if (row_tbHeader1.getCell(i) == null) {
				row_tbHeader1.createCell(i).setCellStyle(styles.get(Style.TABLE_HEADER3));
			} else {
				row_tbHeader1.getCell(i).setCellStyle(styles.get(Style.TABLE_HEADER3));
			}
		}

		/*
		 * EWS Risk & C Final
		 */
		for (int i = 0; i < BASE_COLUMNS2.size(); i++, colIndexStack++) {
			cell = row_tbHeader1.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER2));
			cell.setCellValue(BASE_COLUMNS2.get(i).getText());

			cell = row_tbHeader2.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER2));

			columnsIndex.put(BASE_COLUMNS2.get(i), colIndexStack);

			sheet.addMergedRegion(new CellRangeAddress(hRowI1, hRowI2, colIndexStack, colIndexStack));
		}
		/*
		 * Daily DPD Monitor DPDs, #A/Cs, Unpaid Amount(บาท)
		 */
		List<ColumnName> subColumns = new ArrayList<ColumnName>(
				Arrays.asList(ColumnName.DPDS, ColumnName.DPDS_ACS, ColumnName.DPDS_UNPAID_AMOUNT));

		colIndexStack = buildHeader2RowCell(ColumnName.DAILY_DPD_MONITORING, subColumns, row_tbHeader1, row_tbHeader2,
				colIndexStack, styles.get(Style.TABLE_HEADER2), styles.get(Style.TABLE_HEADER2));

		/*
		 * Daily DPD Monitoring, OD Over-Limit, #A/Cs, ยอดหนี้ที่เกินวงเงิน (บาท)
		 */
		subColumns = new ArrayList<ColumnName>(
				Arrays.asList(ColumnName.OD_OVER_LIMIT, ColumnName.DPDS_ACS, ColumnName.OD_OVER_LIMIT_AMOUNT));

		colIndexStack = buildHeader2RowCell(ColumnName.DAILY_OD_MONITORING, subColumns, row_tbHeader1, row_tbHeader2,
				colIndexStack, styles.get(Style.TABLE_HEADER2), styles.get(Style.TABLE_HEADER2));

		/*
		 * Turn around,Late Payment Form, Action Form 1, Action Form 2
		 */
		subColumns = new ArrayList<ColumnName>(
				Arrays.asList(ColumnName.LATE_PAYMENT_FORM, ColumnName.ACTION_FORM1, ColumnName.ACTION_FORM2));
		colIndexStack = buildHeader2RowCell(ColumnName.TRUN_AROUND, subColumns, row_tbHeader1, row_tbHeader2,
				colIndexStack, styles.get(Style.TABLE_HEADER2), styles.get(Style.TABLE_HEADER2));

		/*
		 * Assessment Updated,Quali,Credit Rating,FIN
		 * 
		 */
		subColumns = new ArrayList<ColumnName>(Arrays.asList(ColumnName.QUALI, ColumnName.FIN));
		colIndexStack = buildHeader2RowCell(ColumnName.ASSESSMENT_UPDATED, subColumns, row_tbHeader1, row_tbHeader2,
				colIndexStack, styles.get(Style.TABLE_HEADER2), styles.get(Style.TABLE_HEADER2));

		/*
		 * การทบทวนต่ออายุ Types,Credit Review,Review Date,Credit Rating,Rating Date
		 */
		subColumns = new ArrayList<ColumnName>(Arrays.asList(ColumnName.TYPES, ColumnName.CREDIT_REVIEW_S,
				ColumnName.REVIEW_DATE, ColumnName.CREDIT_RATING, ColumnName.CREDIT_RATING_DATE));
		colIndexStack = buildHeader2RowCell(ColumnName.CREDIT_REVIEW, subColumns, row_tbHeader1, row_tbHeader2,
				colIndexStack, styles.get(Style.TABLE_HEADER2), styles.get(Style.TABLE_HEADER2));

		/*
		 * Write Column
		 * ประเภทการปิดงาน,เหตุผลการปิดงาน,หมายเหตุ,ผู้ทำรายการ,วันที่ทำรายการ,
		 * ผู้อนุมัติ,วันที่อนุมัติรายการ
		 */
		List<ColumnName> baseColumns = new ArrayList<ColumnName>(
				Arrays.asList(ColumnName.JOB_CLOSE_TYPE, ColumnName.JOB_CLOSE_REASON, ColumnName.REMARK,
						ColumnName.TX_USER, ColumnName.TX_DATE, ColumnName.APPROVE_USER, ColumnName.APPROVE_DATE));

		for (int i = 0; i < baseColumns.size(); i++, colIndexStack++) {
			cell = row_tbHeader1.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER1));
			cell.setCellValue(baseColumns.get(i).getText());

			cell = row_tbHeader2.createCell(colIndexStack);
			cell.setCellStyle(styles.get(Style.TABLE_HEADER1));

			columnsIndex.put(baseColumns.get(i), colIndexStack);

			sheet.addMergedRegion(new CellRangeAddress(hRowI1, hRowI2, colIndexStack, colIndexStack));
		}

		return colIndexStack;
	}

	/**
	 * Build 2 row cell header and return last create cell index.
	 * 
	 * @param parent
	 *            Parent column name.
	 * @param childs
	 *            Children column name.
	 * @param row1
	 * @param row2
	 * @param createIndex
	 * @param parentStyle
	 * @param childStyle
	 * @return Last create cell index.
	 */
	private int buildHeader2RowCell(ColumnName parent, List<ColumnName> childs, HSSFRow row1, HSSFRow row2,
			int createIndex, CellStyle parentStyle, CellStyle childStyle) {
		HSSFCell parentCell = row1.createCell(createIndex);
		parentCell.setCellValue(parent.getText());

		/*
		 * Keep start column index for merge parent column cell.
		 */
		int firstIndex = createIndex;

		for (int i = 0; i < childs.size(); i++, createIndex++) {
			HSSFCell cell = row2.createCell(createIndex);
			cell.setCellStyle(childStyle);
			cell.setCellValue(childs.get(i).getText());

			columnsIndex.put(childs.get(i), createIndex);
		}

		row1.getSheet()
				.addMergedRegion(new CellRangeAddress(row1.getRowNum(), row1.getRowNum(), firstIndex, createIndex - 1));
		// Fill header style on merged cell.
		for (int i = firstIndex; i < createIndex; i++) {
			if (row1.getCell(i) == null) {
				row1.createCell(i).setCellStyle(parentStyle);
			} else {
				row1.getCell(i).setCellStyle(parentStyle);
			}
		}

		return createIndex;
	}

	private String convertFinStatus(String status, String finFlg) {
		String result = "";
		if ("R".equals(status) && (!"".equals(finFlg) && !"D".equals(finFlg))) {
			if ("N".equals(finFlg) || "RN".equals(finFlg) || "RP".equals(finFlg)) {
				result = "3";
			} else if ("I".equals(finFlg) || "RI".equals(finFlg)) {
				result = "3";
			} else if ("E".equals(finFlg) || "C".equals(finFlg)) {
				result = "2";
			} else {
				result = "1";
			}
		} else if ("W".equals(status) && (!"".equals(finFlg) && !"D".equals(finFlg))) {
			result = "2";
		} else {
			if ("N".equals(finFlg)) {
				result = "6";
			} else if ("I".equals(finFlg)) {
				result = "5";
			} else if ("C".equals(finFlg)) {
				result = "4";
			} else if ("RN".equals(finFlg) || "RP".equals(finFlg)) {
				result = "3";
			} else if ("RI".equals(finFlg)) {
				result = "3";
			} else if ("E".equals(finFlg)) {
				result = "2";
			}
		}
		return result;
	}

	class Style {

		public static final String REMARK_TITLE = "REMARK_TITLE";
		public static final String REMARK = "REMARK";
		public static final String TABLE_HEADER1 = "TABLE_HEADER1";
		public static final String TABLE_HEADER2 = "TABLE_HEADER2";
		public static final String TABLE_HEADER3 = "TABLE_HEADER3";
		public static final String TABLE_HEADER4 = "TABLE_HEADER4";
		public static final String HEADER_LABLE = "HEADER_LABLE";
		public static final String DEFAULT = "DEFAULT";
		public static final String DEFAULT_TABLE_DATA = "DEFAULT_TABLE_DATA";
		public static final String TABLE_NUMBER_DATA = "TABLE_NUMBER_DATA";
		public static final String TABLE_TEXT_DATA="TABLE_TEXT_DATA";
		public static final String START_DATA = "START_DATA";
		public static final String END_DATA = "END_DATA";
		public static final String TOTAL_LABEL = "TOTAL_LABEL";
		public static final String DATE_DATA = "DATE_DATA";
		public static final String TEXT_DATA = "TEXT_DATA";
		public static final String DEFAULT_DATA = "DEFAULT_DATA";
	}

	/*
	 * Define Column
	 */
	enum ColumnName {
		NO("No."), WARNING_DATE("Warning Date"), CIF_NO("CIF No."), CUSTOMER_NAME("ชื่อลูกค้า"), RM("RM ID"), AE(
				"AE ID"), AO("AO ID"), RESPONSE_UNIT("Response Unit"), EWS_RISK("EWS Risk"), C_FINAL("C Final"), DPDS(
						"DPDs"), DPDS_ACS("#A/Cs"), DPDS_UNPAID_AMOUNT("Unpaid Amount(บาท)"), OD_OVER_LIMIT(
								"OD Over-Limit"), OD_OVER_LIMIT_AMOUNT("ยอดหนี้ที่เกินวงเงิน (บาท)"), LATE_PAYMENT_FORM(
										"Late Payment Form"), ACTION_FORM1("Action Form 1"), ACTION_FORM2(
												"Action Form 2"), QUALI("Quali"), FIN("FIN"), JOB_CLOSE_TYPE(
														"ประเภทการปิดงาน"), JOB_CLOSE_REASON("เหตุผลการปิดงาน"), REMARK(
																"หมายเหตุ"), TX_USER("ผู้ทำรายการ"), TX_DATE(
																		"วันที่ทำรายการ"), APPROVE_USER(
																				"ผู้อนุมัติ"), APPROVE_DATE(
																						"วันที่อนุมัติรายการ")

		/*
		 * Parent column.
		 */
		, ACCOUNT_OWNER("Account Owner"), DAILY_DPD_MONITORING("Daily DPD Monitoring"), DAILY_OD_MONITORING(
				"Daily OD Monitoring"), TRUN_AROUND(
						"Turnaround"), ASSESSMENT_UPDATED("Assessment Updated"), CREDIT_REVIEW("การทบทวน/ต่ออายุวงเงิน และ Credit Rating")

		/*
		 * Credit review
		 */
		, TYPES("Types"), CREDIT_REVIEW_S("Credit Review"), REVIEW_DATE("Review Date"), CREDIT_RATING(
				"Credit Rating"), CREDIT_RATING_DATE("Rating Date");

		private final String text;

		ColumnName(String text) {
			this.text = text;
		}

		public String getText() {
			return text;
		}
	}

	private Map<String, CellStyle> createStylesReconcile(HSSFWorkbook wb) {
		// Define constant.
		final String FONT_CALIBIRI = "Calibiri";
		// Define return variable for contain defined cell style.
		Map<String, CellStyle> styles = new HashMap<String, CellStyle>();

		// Define custom color.
		HSSFPalette palette = wb.getCustomPalette();
		// Update custom color to exists index.
		palette.setColorAtIndex(HSSFColor.LIGHT_BLUE.index, (byte) 152, (byte) 242, (byte) 240);

		palette = wb.getCustomPalette();
		palette.setColorAtIndex(HSSFColor.AQUA.index, (byte) 21, (byte) 204, (byte) 204);

		palette = wb.getCustomPalette();
		palette.setColorAtIndex(HSSFColor.GREY_25_PERCENT.index, (byte) 222, (byte) 233, (byte) 201);

		// Define Font to use in style.
		Font defaultFont = wb.createFont();
		defaultFont.setFontName(FONT_CALIBIRI);
		defaultFont.setFontHeightInPoints((short) 11);

		Font labelFont = wb.createFont();
		labelFont.setFontName(FONT_CALIBIRI);
		labelFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		labelFont.setFontHeightInPoints((short) 11);

		Font titleRemarkFont = wb.createFont();
		titleRemarkFont.setFontName(FONT_CALIBIRI);
		titleRemarkFont.setFontHeightInPoints((short) 11);
		titleRemarkFont.setColor(HSSFColor.RED.index);
		titleRemarkFont.setUnderline(HSSFFont.U_SINGLE);

		Font remarkFont = wb.createFont();
		remarkFont.setFontName(FONT_CALIBIRI);
		remarkFont.setFontHeightInPoints((short) 11);
		remarkFont.setColor(HSSFColor.RED.index);

		// Default
		CellStyle style = wb.createCellStyle();
		style.setFont(defaultFont);
		styles.put(Style.DEFAULT, style);

		// Header Label.
		style = wb.createCellStyle();
		style.setFont(labelFont);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		styles.put(Style.HEADER_LABLE, style);

		// Table Header1
		style = wb.createCellStyle();
		style.setFont(labelFont);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);

		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		styles.put(Style.TABLE_HEADER1, style);

		// Table Header2
		style = wb.createCellStyle();
		style.setFont(labelFont);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);

		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setFillForegroundColor(HSSFColor.AQUA.index);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		styles.put(Style.TABLE_HEADER2, style);

		// Table Header3
		style = wb.createCellStyle();
		style.setFont(labelFont);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);

		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		styles.put(Style.TABLE_HEADER3, style);

		// Table Header4
		style = wb.createCellStyle();
		style.setFont(labelFont);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderTop(CellStyle.BORDER_THIN);

		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		styles.put(Style.TABLE_HEADER4, style);

		// Remark Title
		style = wb.createCellStyle();
		style.setFont(titleRemarkFont);
		styles.put(Style.REMARK_TITLE, style);
		// Remark
		style = wb.createCellStyle();
		style.setFont(remarkFont);
		styles.put(Style.REMARK, style);
		// Total
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		styles.put(Style.TOTAL_LABEL, style);

		// Default data
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		styles.put(Style.DEFAULT_DATA, style);
		// Default table data
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		styles.put(Style.DEFAULT_TABLE_DATA, style);
		// TABLE NUMBER DATA
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		styles.put(Style.TABLE_NUMBER_DATA, style);
		// TABLE TEXT DATA
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		styles.put(Style.TABLE_TEXT_DATA, style);
		// Text data
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		styles.put(Style.TEXT_DATA, style);
		// Start data
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		styles.put(Style.START_DATA, style);
		// End data
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setBorderBottom(CellStyle.BORDER_THIN);
		styles.put(Style.END_DATA, style);
		// Date data
		style = wb.createCellStyle();
		style.setFont(defaultFont);
		// DataFormat format = wb.createDataFormat();
		// style.setDataFormat(format.getFormat("dd/MM/yyyy"));
		styles.put(Style.DATE_DATA, style);

		return styles;
	}

	private String data(String data) {
		if (data == null) {
			return "";
		} else {
			return data;
		}
	}

	public CloseJobDataExporter setParams(Map<String, Object> params) {
		this.params = params;
		return this;
	}

	public interface DataObject<T> {
		List<T> readData();
	}
}
