/**
 * 
 */
package com.ktb.ewsl.export;

import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author somphop.h
 *
 */
public interface ExcelDataExporter {
	HSSFWorkbook export() throws IOException;
}
