package com.enjoy.demoSpringRestFul.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoderGenerator {
	public static void main(String[] args) {
		
		try {
			PasswordEncoderGenerator p = new PasswordEncoderGenerator();
			String password = "password";
			int i = 0;
			while (i < 10) {
				
				String hashedPassword = p.encodingPassword(password);
	
				System.out.println(hashedPassword);
				i++;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	  }
	
	public String encodingPassword(String pass) throws Exception {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		
		return  passwordEncoder.encode(pass);
	}
	
	
}
