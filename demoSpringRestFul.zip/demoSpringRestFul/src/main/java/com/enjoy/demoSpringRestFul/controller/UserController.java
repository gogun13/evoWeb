package com.enjoy.demoSpringRestFul.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.enjoy.demoSpringRestFul.business.UserDetailBusiness;
import com.enjoy.demoSpringRestFul.models.UserDetailVo;

@RestController
public class UserController {
	
	@Autowired
	UserDetailBusiness userDetailBusiness;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public UserDetailVo getUserDetail(String params) {
		System.out.println("getUserDetail begin " + params);
		
		UserDetailVo vo = new UserDetailVo();
		
		vo.setUserId("gogun13");
		vo.setUserName("Pratya");
		vo.setUserName("Thanuchaisak");
		
		
		return vo;

	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public HashMap<String, String> save(UserDetailVo paramsVo) {
		System.out.println("save begin");
		
		HashMap<String, String> map = new HashMap<>();
		
		try {
			userDetailBusiness.insert(paramsVo);
			
			map.put("status", "SUCCESS");
			
		}catch(Exception e) {
			map.put("status", "ERROR");
			map.put("errorDescription", "เกิดข้อผิดพลาด กรุณาติดต่อผู้ดูแลระบบ");
			e.printStackTrace();
		}
		
		
		return map;

	}
	
	
}
