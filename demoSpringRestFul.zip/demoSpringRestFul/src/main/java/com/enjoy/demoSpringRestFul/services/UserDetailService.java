package com.enjoy.demoSpringRestFul.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.enjoy.demoSpringRestFul.models.UserDetailVo;

@Repository
public class UserDetailService {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	public ArrayList<UserDetailVo> findAll() throws Exception{
		
		String sql = "SELECT * FROM tbl_user_test";

		ArrayList<UserDetailVo> result = (ArrayList<UserDetailVo>) jdbcTemplate.query(sql,new RowMapper<UserDetailVo>(){  
		    @Override  
		    public UserDetailVo mapRow(ResultSet rs, int rownumber) throws SQLException {  
		    	UserDetailVo e = new UserDetailVo();
		    	
		        e.setUserId(rs.getString("USER_ID"));
		        e.setUserPass(rs.getString("USER_PASS"));
		        e.setUserName(rs.getString("USER_NAME"));
		        e.setUserSurName(rs.getString("USER_SURNAME"));
		        
		        return e;  
		    }  
		});

        return result;

    }
	
	public UserDetailVo getUserDetail(String userId) throws Exception {
		
		String sql = "SELECT * FROM tbl_user_test where USER_ID = ?";
		UserDetailVo userDetailVo = new UserDetailVo();

		ArrayList<UserDetailVo> result = (ArrayList<UserDetailVo>) jdbcTemplate.query(sql,new Object[] {userId},new RowMapper<UserDetailVo>(){  
		    @Override  
		    public UserDetailVo mapRow(ResultSet rs, int rownumber) throws SQLException {  
		    	UserDetailVo e = new UserDetailVo();
		    	
		        e.setUserId(rs.getString("USER_ID"));
		        e.setUserPass(rs.getString("USER_PASS"));
		        e.setUserName(rs.getString("USER_NAME"));
		        e.setUserSurName(rs.getString("USER_SURNAME"));
		        
		        return e;  
		    }  
		});
		
		if(result!=null && !result.isEmpty()) {
			userDetailVo = result.get(0); 
		}

        return userDetailVo;

    }
	
	public void insert(UserDetailVo vo) throws Exception{
		String sql = "insert into tbl_user_test (USER_ID,USER_PASS,USER_NAME,USER_SURNAME) values(?,?,?,?)";
		
		jdbcTemplate.update(sql, new Object[] {vo.getUserId(),vo.getUserPass(),vo.getUserName(),vo.getUserSurName()});
	}
	
	public void insertTmp(UserDetailVo vo) throws Exception{
		String sql = "insert into tbl_user_test_tmp (USER_ID,USER_PASS,USER_NAME,USER_SURNAME) values(?,?,?,?)";
		
		jdbcTemplate.update(sql, new Object[] {vo.getUserId(),vo.getUserPass(),vo.getUserName(),vo.getUserSurName()});
	}


}
