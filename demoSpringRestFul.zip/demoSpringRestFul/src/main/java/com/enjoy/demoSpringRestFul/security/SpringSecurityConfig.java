package com.enjoy.demoSpringRestFul.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
	DataSource dataSource;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
//            .antMatchers(POST, "/account").permitAll()
//            .antMatchers(GET, "/account").hasAuthority("ROLE_ADMIN")
            .anyRequest().fullyAuthenticated()
            .and().httpBasic()
            .and().csrf().disable();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
    	
    	auth.jdbcAuthentication().dataSource(dataSource)
    	.passwordEncoder(passwordEncoder())
		.usersByUsernameQuery("select USER_ID as username,USER_PASS as password,1 as enabled from tbl_user_test where USER_ID=?")//username,password,enabled ต้อง select 3 column นี้เสมอ
		.authoritiesByUsernameQuery("select USER_ID, 'ROLE_ADMIN' from tbl_user_test where USER_ID=?");//ต้อง select role เสมอ ไม่มีก็ต้องเซตหลอกไว้

//        auth.inMemoryAuthentication()
//                .withUser("user").password("password").roles("USER")
//                .and()
//                .withUser("admin").password("password").roles("ADMIN");
    }
    
    @Bean
	public PasswordEncoder passwordEncoder(){
		PasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder;
	}
    
}
