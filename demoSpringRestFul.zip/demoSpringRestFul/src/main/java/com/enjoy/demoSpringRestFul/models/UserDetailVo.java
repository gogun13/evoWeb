package com.enjoy.demoSpringRestFul.models;

import lombok.Data;

@Data
public class UserDetailVo {
	
	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String userPass;
	private String userName;
	private String userSurName;
	private String isActive;
	private String msg;

}
