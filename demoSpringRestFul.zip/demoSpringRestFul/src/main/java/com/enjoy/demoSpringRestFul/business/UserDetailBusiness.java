package com.enjoy.demoSpringRestFul.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.enjoy.demoSpringRestFul.models.UserDetailVo;
import com.enjoy.demoSpringRestFul.security.PasswordEncoderGenerator;
import com.enjoy.demoSpringRestFul.services.UserDetailService;

@Service
@Transactional
public class UserDetailBusiness{
	
	@Autowired
    UserDetailService userDetailService;
	
	public void insert(UserDetailVo vo) throws Exception{
		System.out.print("[insert][Begin]");
		
		String passwordEncode = null;
		PasswordEncoderGenerator passwordEncoderGenerator = new PasswordEncoderGenerator();
		
		try {
			
			System.out.println("[insert] password :: " + vo.getUserPass());
			
			passwordEncode = passwordEncoderGenerator.encodingPassword(vo.getUserPass());
			
			vo.setUserPass(passwordEncode);
			userDetailService.insert(vo);
			
//			System.out.print("[insert] round 2");
//			
//			userDetailService.insertTmp(vo);
			
		}catch(Exception e) {
			throw e;
		}
		
	}
	
}
