from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.worksheet.table import Table, TableStyleInfo
from robot.libraries.BuiltIn import BuiltIn
import pdb
#import copy
import os.path

class excelReader:
    wb = None
    ws = None
    fileDir = ""

    def is_open(self):
        if wb is None:
            return False
        else:
            return True
    def get_workbook(self):
        global wb
        return wb
    def get_worksheet(self):
        global ws
        return ws

    def get_maxrow(self):
        return ws.max_row

    def get_maxcol(self):
        return ws.max_column

    def read_excel(self, path, sheetname):
        dt = []
        try:
            global wb
            global ws
            global ws_original
            global fileDir
            fileDir = path
            wb = load_workbook(path)
            #print("Path:" + path)
            ws = wb[sheetname]
            #ws_original = wb[sheetname]
            #tmp_name = ws_original.title
            #ws = wb.copy_worksheet(ws_original)
            #ws.title = "NEW"
            #print("Sheet:"+sheetname)

        except Exception as err:
            raise Exception(str(err))

    def switch_sheet(self, sheetname):
        global wb
        global ws
        ws = wb[sheetname]

    def get_row(self, rowIndex):
        actualIndex = int(rowIndex)
        try:
            global wb
            global ws
            c=1
            dataRow = {}
            for row in ws.iter_rows(min_row=actualIndex, max_col=ws.max_column, max_row=actualIndex):
                for cell in row:
                    #print type(ws.cell(row=actualIndex,column=c).value)
                    #print ws.cell(row=actualIndex,column=c).value
                    if ws.cell(row=actualIndex,column=c).value != 'None' :
                        #pdb.set_trace()
                        if str(cell.value) == 'None' :
                            dataRow[str(ws.cell(row=1,column=c).value)] = str('')
                            c+=1
                        else:
                            dataRow[str(ws.cell(row=1,column=c).value)] = str(cell.value)       
                            c+=1
            return dataRow

        except Exception as e:
            raise Exception(str(e))

    def update_row(self, rowIndex, rowData):
        try:
            global wb
            global ws
            index = int(rowIndex)
            c=1
            header = ''
            value = ''
            if ws is not None:
                for row in ws.iter_rows(min_row=index, max_col=ws.max_column, max_row=index):
                    for cell in row:
                        #print "Header="+header+", value="+value
                        header = str(ws.cell(row=1,column=c).value)
                        value = rowData[header]
                        ws.cell(row=index,column=c).value = value
                        c+=1
                    index+=1
                    c=1
                    #print ""
            #return "Success"
##        except NameError as nerr:
##            if nerr[0] == 'global name \'ws\' is not defined':
##                return "Workbook not found, Please read excel first."
##            else:
##                return nerr
        except Exception as err:
            raise Exception(str(err))

    def save(self, savePath='Undefined.xlsx', sheetName=''):
        try:
            global wb
            global ws
            global fileDir

            if sheetName == '':
                sheetName = ws.title

            if savePath.endswith(".xlsx") == False:
                savePath = savePath + ".xlsx"
            #print "Saving file..."
            #print "File name = "+savePath
            #print "Sheet name = " + sheetName

            for w in wb.sheetnames:
                if w != ws.title:
                    del wb[w]
            ws.title = sheetName
            wb.save(savePath)

        except Exception as e:
            raise Exception(str(e))
    def saveall(self, savePath='Undefined.xlsx'):
        try:
            global wb
            global ws
            global fileDir

            if savePath.endswith(".xlsx") == False:
                savePath = savePath + ".xlsx"
            #print "Saving file..."
            #print "File name = "+savePath

            wb.save(savePath)

        except Exception as e:
            raise Exception(str(e))

    def copyws(self,ws_source,ws_destination):
        maxcol = ws_source.max_column
        maxrow = ws_source.max_row
        dest_range = []
        for r in range(1,maxrow+1,1):
            dest_row = []
            for c in range(1,maxcol+1,1):
                dest_row.append(ws_source.cell(row=r,column=c).value)
            dest_range.append(dest_row)

        countRow = 0
        for i in range(1,maxrow+1,1):
            countCol = 0
            for j in range(1,maxcol+1,1):
                ws_destination.cell(row = i, column = j).value = dest_range[countRow][countCol]
                countCol += 1
            countRow += 1

ls = excelReader()
def main():
    input_Path = "D:\Robot Template\Projects\Intranet\Intranet_Test_Template.xlsx"
    read_sheet = "ContentPage"
    ls.read_excel(sheetname=read_sheet,path=input_Path)